--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    hours integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    criterion_id bigint,
    parent bigint,
    isvalid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    resourcetype bytea,
    workinghours integer,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint NOT NULL
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    code character varying(255),
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type integer,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint,
    material_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    customer character varying(255),
    dependenciesconstraintshavepriority boolean,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    mandatoryinit boolean,
    mandatoryend boolean,
    description character varying(255),
    code character varying(255),
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    calendar bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date timestamp without time zone,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    index integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart timestamp without time zone,
    clockfinish timestamp without time zone,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
3052	6	t	606
3053	6	t	606
3054	6	t	606
3042	7	t	606
2250	3	t	606
2251	3	t	606
2234	4	t	606
3056	18	f	509
3099	15	t	607
3115	14	t	607
3130	12	t	607
6178	3	t	607
6179	3	t	607
2739	22	t	606
3100	15	f	607
29406	5	t	606
29407	5	t	606
35867	11	t	606
16659	12	t	607
16660	12	t	607
16661	12	t	607
2932	19	f	606
16662	12	t	607
16663	12	t	607
6186	13	t	607
6187	13	t	607
6894	4	t	607
6895	4	t	607
6902	3	t	607
2945	7	t	606
6896	4	f	607
27689	5	t	606
27690	5	t	606
39934	8	t	606
39935	8	t	606
39936	8	t	606
39924	9	t	606
49251	10	t	606
49252	10	t	606
49253	10	t	606
49254	10	t	606
49255	10	t	606
49256	10	t	606
49257	10	t	606
49258	10	t	606
49267	9	t	606
49268	9	t	606
49269	9	t	606
49270	9	t	606
49273	7	t	606
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
19436	7	2009-12-08	25.00	16659
16728	12	2009-12-02	10.00	16659
19437	7	2009-12-08	25.00	16660
16729	12	2009-12-01	10.00	16660
16730	12	2009-12-08	20.00	16662
16731	12	2009-12-08	10.00	16663
6290	13	2009-12-08	30.00	6186
6984	4	2009-12-08	50.00	6894
6985	4	2009-12-08	40.00	6895
6991	3	2009-12-08	45.00	6902
1519	18	2009-12-25	100.00	3056
1520	18	2009-12-10	15.00	3056
1521	18	2009-12-07	5.00	3056
1522	18	2009-12-04	1.00	3056
1544	15	2009-12-04	10.00	3099
1573	14	2009-12-07	30.00	3115
1574	14	2009-12-04	10.00	3115
3233	12	2009-12-07	30.00	3130
3234	12	2009-12-04	10.00	3130
3235	12	2009-12-03	2.00	3130
6284	3	2009-12-07	30.00	6178
6285	3	2009-12-08	30.00	6179
6286	3	2009-12-07	50.00	6179
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
606	3	children	100.0000	f	0.0100	t	t
607	2	percentage	100.0000	f	0.0100	t	t
608	1	units	2147483647.0000	f	1.0000	t	f
508	1	Pactado	1000000.0000	t	1000.0000	t	f
510	1	Toneladas	4000.0000	t	1.0000	t	f
509	2	Porcentage pactado	100.0000	t	1.0000	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
3940	105
3950	106
3951	106
3952	107
3953	106
3955	110
3982	107
3983	106
3984	105
3985	105
6367	106
6368	110
6369	106
8588	107
8589	105
19897	105
19898	107
19899	105
19901	105
24143	111
28093	106
29808	106
36966	36057
38582	36057
38583	36057
38595	36057
38596	36057
38597	36057
38598	36057
38600	36057
38601	36057
41013	36057
41014	36057
41050	36057
41051	36057
41052	36057
41053	36057
41054	36057
41061	36057
41069	36057
41076	36057
41077	36057
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
4245	7
24953	2
37371	17
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
204	2	Ferrol
206	2	\N
205	2	\N
208	5	\N
26159	1	Vigo
207	3	\N
7373	6	\N
209	7	\N
210	8	\N
202	3	España
203	4	Galicia
37674	2	\N
36259	2	\N
37673	2	\N
40299	3	\N
49391	1	\N
49392	1	\N
49393	1	\N
49389	3	\N
49394	1	\N
49390	3	\N
49395	1	\N
49396	2	\N
36260	4	Pontevedra
49397	1	Pontevedra Proxecto
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
7677	1	2009-11-04	\N	206	0
7678	1	2009-11-04	\N	205	0
7679	4	2009-11-04	\N	208	0
7680	2	2009-11-04	\N	207	0
7879	5	2009-11-04	\N	7373	0
7676	4	2009-11-07	\N	209	0
7878	6	2009-11-04	\N	210	0
37876	2	2009-12-14	\N	37674	0
36461	2	2009-12-14	\N	36259	0
37875	2	2009-12-14	\N	37673	0
40501	3	2009-12-18	\N	40299	0
49593	1	2009-12-23	\N	49391	0
49594	1	2009-12-23	\N	49392	0
49595	1	2009-12-23	\N	49393	0
49591	3	2009-12-23	\N	49389	0
49596	1	2009-12-23	\N	49394	0
49592	3	2009-12-23	\N	49390	0
49597	1	2009-12-23	\N	49395	0
49598	2	2009-12-23	\N	49396	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
37775	2	202	\N	37674	0
306	2	203	\N	204	0
36360	2	202	\N	36259	0
37774	2	202	\N	37673	0
40400	3	202	\N	40299	0
308	2	202	\N	206	0
307	2	202	\N	205	0
49492	1	202	\N	49391	0
49493	1	202	\N	49392	0
310	5	202	\N	208	0
26361	1	203	\N	26159	0
309	3	202	\N	207	0
49494	1	202	\N	49393	0
49490	3	202	\N	49389	0
7474	6	202	\N	7373	0
311	7	202	\N	209	0
49495	1	36260	\N	49394	0
312	8	202	2009-12-11	210	0
31916	2	202	\N	210	1
49491	3	202	\N	49390	0
303	3	\N	\N	202	0
304	3	\N	\N	202	1
305	4	202	\N	203	0
49496	1	202	\N	49395	0
49497	2	202	\N	49396	0
36361	4	203	2010-01-01	36260	0
36362	2	203	\N	36260	1
49498	1	\N	\N	49397	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
808	2	2009-12-25	0	505	202
26260	1	2010-12-28	0	505	26159
26261	1	2010-12-27	0	505	26159
26262	1	2010-04-05	0	505	26159
26263	1	2010-12-31	0	505	26159
26264	1	2011-01-02	0	505	26159
26265	1	2010-12-30	0	505	26159
26266	1	2011-01-01	0	505	26159
26267	1	2010-12-29	0	505	26159
809	2	2010-01-01	0	505	202
36663	1	2010-04-01	0	505	202
36664	1	2010-11-01	0	505	202
36665	1	2010-12-06	0	505	202
36666	1	2010-04-02	0	505	202
36667	1	2010-10-12	0	505	202
36668	1	2010-12-08	0	505	202
36669	1	2010-01-06	0	505	202
810	2	2010-05-17	0	505	203
36670	1	2010-03-19	0	505	203
26268	1	2010-07-12	0	505	207
26269	1	2010-07-08	0	505	207
26270	1	2010-07-21	0	505	207
26271	1	2010-07-16	0	505	207
26272	1	2010-07-04	0	505	207
26273	1	2010-07-15	0	505	207
26274	1	2010-07-13	0	505	207
26275	1	2010-07-01	0	505	207
26276	1	2010-07-14	0	505	207
26277	1	2010-07-23	0	505	207
26278	1	2010-07-19	0	505	207
26279	1	2010-07-02	0	505	207
26280	1	2010-07-07	0	505	207
26281	1	2010-07-06	0	505	207
26282	1	2010-07-10	0	505	207
26283	1	2010-07-03	0	505	207
26284	1	2010-07-17	0	505	207
26285	1	2010-07-09	0	505	207
26286	1	2010-07-18	0	505	207
26287	1	2010-07-11	0	505	207
26288	1	2010-07-22	0	505	207
26289	1	2010-07-20	0	505	207
26290	1	2010-07-05	0	505	207
36671	3	2010-04-05	0	505	36260
36672	3	2010-02-17	0	505	36260
58277	1	2010-01-01	0	505	49397
58278	1	2010-01-06	0	505	49397
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, name, color, notassignable) FROM stdin;
505	6	HOLIDAY	red	t
506	5	SICK_LEAVE	red	t
507	4	LEAVE	red	t
508	3	STRIKE	red	t
509	2	BANK_HOLIDAY	red	t
510	1	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id) FROM stdin;
404	2	202
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, name, enabled) FROM stdin;
1313	1	Oficial 1º	t
1315	3	Peón	t
1314	3	Oficial 2º	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
108	4	Calderero	t	4	\N
106	4	Soldador	t	4	\N
107	4	Andamiero	t	4	\N
36057	3	Ingeniero en Informática	t	4	\N
105	4	Pintor	t	4	\N
38481	2	Diseñador gráfico	t	4	\N
49894	1	Desarrollador	t	16154624	\N
49895	1	Analista	t	16154624	\N
49896	1	Coordinador	t	16154624	\N
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
109	2	Curso de riesgos laborales	t	3	\N
110	2	Torno	t	7	\N
111	2	Plegadora	t	7	\N
25755	2	Horno	t	7	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
28007	DIRECT	3	\N	27607	109	\N	\N
28008	DIRECT	3	27792	\N	106	\N	\N
28009	INDIRECT	3	27792	\N	109	28007	t
36916	DIRECT	7	\N	35766	36057	\N	\N
36917	INDIRECT	7	\N	35791	36057	36916	t
28030	DIRECT	2	\N	27608	106	\N	\N
28031	INDIRECT	2	27793	\N	106	28030	t
36918	INDIRECT	7	35980	\N	36057	36916	t
36919	INDIRECT	7	\N	35792	36057	36916	t
36920	INDIRECT	7	35981	\N	36057	36916	t
36921	INDIRECT	7	\N	35793	36057	36916	t
36922	INDIRECT	7	35982	\N	36057	36916	t
36923	INDIRECT	7	\N	35794	36057	36916	t
36924	INDIRECT	7	35983	\N	36057	36916	t
36925	INDIRECT	7	\N	35795	36057	36916	t
29783	DIRECT	4	\N	29323	109	\N	\N
29785	INDIRECT	4	29508	\N	109	29783	t
29784	DIRECT	4	29508	\N	106	\N	\N
29786	DIRECT	4	\N	29325	106	\N	\N
29787	INDIRECT	4	29510	\N	106	29786	t
2204	DIRECT	15	\N	1150	110	\N	\N
3420	INDIRECT	14	2863	\N	110	2204	t
2205	DIRECT	15	\N	1151	111	\N	\N
4910	DIRECT	4	1435	\N	105	\N	\N
4911	DIRECT	4	1436	\N	107	\N	\N
4912	DIRECT	4	1437	\N	106	\N	\N
4913	DIRECT	4	\N	1362	108	\N	\N
2389	DIRECT	5	2880	\N	106	\N	\N
2388	DIRECT	5	1891	\N	110	\N	\N
2390	DIRECT	5	\N	1182	108	\N	\N
3421	INDIRECT	14	2864	\N	111	2205	t
2206	DIRECT	15	\N	1152	105	\N	\N
2207	INDIRECT	15	2865	\N	105	2206	t
2208	DIRECT	15	\N	1153	105	\N	\N
2209	INDIRECT	15	2866	\N	105	2208	t
2210	DIRECT	15	\N	1154	107	\N	\N
2211	INDIRECT	15	2867	\N	107	2210	t
2391	DIRECT	5	\N	1182	106	\N	\N
2392	INDIRECT	5	2882	\N	108	2390	t
2393	INDIRECT	5	2882	\N	106	2391	t
2394	DIRECT	5	\N	1183	108	\N	\N
2395	INDIRECT	5	2883	\N	108	2394	t
4914	INDIRECT	4	1438	\N	108	4913	t
4915	DIRECT	4	\N	1363	106	\N	\N
4916	INDIRECT	4	1439	\N	106	4915	t
4918	DIRECT	4	\N	1364	106	\N	\N
4917	DIRECT	4	\N	1364	105	\N	\N
4919	INDIRECT	4	1440	\N	106	4918	t
4920	INDIRECT	4	1440	\N	105	4917	t
4921	DIRECT	4	\N	1365	107	\N	\N
4922	INDIRECT	4	1441	\N	107	4921	t
1646	DIRECT	11	\N	1126	105	\N	\N
1647	INDIRECT	11	2843	\N	105	1646	t
1679	DIRECT	10	1457	\N	107	\N	\N
1678	DIRECT	10	2844	\N	106	\N	\N
1816	DIRECT	9	\N	1128	105	\N	\N
1817	INDIRECT	9	2845	\N	105	1816	t
1919	DIRECT	9	2846	\N	108	\N	\N
1935	DIRECT	8	1855	\N	106	\N	\N
1966	DIRECT	7	1856	\N	106	\N	\N
1967	DIRECT	7	2847	\N	108	\N	\N
50440	INDIRECT	10	50501	\N	36057	49998	t
50441	INDIRECT	10	\N	50374	36057	49998	t
50442	INDIRECT	10	50502	\N	36057	49998	t
50443	INDIRECT	10	\N	50375	36057	49998	t
50444	INDIRECT	10	50503	\N	36057	49998	t
50445	INDIRECT	10	\N	50376	36057	49998	t
36926	INDIRECT	7	35984	\N	36057	36916	t
36927	INDIRECT	7	\N	35796	36057	36916	t
36928	INDIRECT	7	35985	\N	36057	36916	t
36931	INDIRECT	7	\N	35798	36057	36916	t
36932	INDIRECT	7	35987	\N	36057	36916	t
36929	INDIRECT	7	\N	35797	36057	36916	t
36930	INDIRECT	7	35986	\N	36057	36916	t
38184	INDIRECT	6	\N	38080	36057	36916	t
38185	INDIRECT	6	38282	\N	36057	36916	t
40793	DIRECT	5	\N	39823	36057	\N	\N
40794	INDIRECT	5	\N	39872	36057	40793	t
40795	INDIRECT	5	40035	\N	36057	40793	t
40796	INDIRECT	5	\N	39873	36057	40793	t
40797	INDIRECT	5	40036	\N	36057	40793	t
40798	INDIRECT	5	\N	39874	36057	40793	t
40799	INDIRECT	5	\N	39875	36057	40793	t
40800	INDIRECT	5	40037	\N	36057	40793	t
40801	INDIRECT	5	\N	39876	36057	40793	t
40802	INDIRECT	5	40038	\N	36057	40793	t
40803	INDIRECT	5	\N	39877	36057	40793	t
40804	INDIRECT	5	\N	39878	36057	40793	t
40805	INDIRECT	5	40039	\N	36057	40793	t
40806	INDIRECT	5	\N	39879	36057	40793	t
40807	INDIRECT	5	40040	\N	36057	40793	t
40808	INDIRECT	5	\N	39880	36057	40793	t
40809	INDIRECT	5	40041	\N	36057	40793	t
40810	INDIRECT	5	\N	39881	36057	40793	t
40811	INDIRECT	5	40042	\N	36057	40793	t
40812	INDIRECT	5	\N	39882	36057	40793	t
51615	DIRECT	6	\N	50360	49894	\N	\N
51616	INDIRECT	6	\N	50361	49894	51615	t
51617	INDIRECT	6	50189	\N	49894	51615	t
51618	INDIRECT	6	\N	50362	49894	51615	t
51619	INDIRECT	6	50190	\N	49894	51615	t
51620	INDIRECT	6	\N	50363	49894	51615	t
51621	INDIRECT	6	50191	\N	49894	51615	t
51622	INDIRECT	6	\N	50364	49894	51615	t
51623	INDIRECT	6	50192	\N	49894	51615	t
51624	DIRECT	6	\N	50365	49894	\N	\N
51625	INDIRECT	6	\N	50366	49894	51624	t
51626	INDIRECT	6	50193	\N	49894	51624	t
51627	INDIRECT	6	\N	50367	49894	51624	t
51628	INDIRECT	6	50194	\N	49894	51624	t
51629	INDIRECT	6	\N	50368	49894	51624	t
51630	INDIRECT	6	50195	\N	49894	51624	t
51631	DIRECT	6	\N	50369	49894	\N	\N
51632	INDIRECT	6	\N	50370	49894	51631	t
56955	DIRECT	5	\N	50646	49894	\N	\N
56956	INDIRECT	5	\N	50647	49894	56955	t
50769	INDIRECT	9	\N	50647	36057	49998	t
50770	INDIRECT	9	50557	\N	36057	49998	t
56957	INDIRECT	5	50557	\N	49894	56955	t
50771	INDIRECT	9	\N	50648	36057	49998	t
50772	INDIRECT	9	\N	50649	36057	49998	t
50773	INDIRECT	9	50558	\N	36057	49998	t
40813	INDIRECT	5	40043	\N	36057	40793	t
40814	INDIRECT	5	\N	39883	36057	40793	t
40815	INDIRECT	5	\N	39884	36057	40793	t
40816	INDIRECT	5	40044	\N	36057	40793	t
40817	INDIRECT	5	\N	39885	36057	40793	t
40818	INDIRECT	5	40045	\N	36057	40793	t
40819	INDIRECT	5	\N	39886	36057	40793	t
40820	INDIRECT	5	40046	\N	36057	40793	t
40821	INDIRECT	5	\N	39887	36057	40793	t
40822	INDIRECT	5	40047	\N	36057	40793	t
49998	DIRECT	11	\N	49125	36057	\N	\N
51633	INDIRECT	6	50196	\N	49894	51631	t
51634	DIRECT	6	\N	50371	49894	\N	\N
51635	INDIRECT	6	\N	50372	49894	51634	t
51636	INDIRECT	6	50500	\N	49894	51634	t
51637	INDIRECT	6	\N	50373	49894	51634	t
51638	INDIRECT	6	50501	\N	49894	51634	t
51639	INDIRECT	6	\N	50374	49894	51634	t
51640	INDIRECT	6	50502	\N	49894	51634	t
51641	INDIRECT	6	\N	50375	49894	51634	t
50461	INDIRECT	10	\N	50386	36057	49998	t
50462	INDIRECT	10	50510	\N	36057	49998	t
50463	INDIRECT	10	\N	50387	36057	49998	t
50464	INDIRECT	10	50511	\N	36057	49998	t
50465	INDIRECT	10	\N	50388	36057	49998	t
50466	INDIRECT	10	50512	\N	36057	49998	t
50467	INDIRECT	10	\N	50389	36057	49998	t
50468	INDIRECT	10	50513	\N	36057	49998	t
50469	INDIRECT	10	\N	50390	36057	49998	t
50470	INDIRECT	10	50514	\N	36057	49998	t
50471	INDIRECT	10	\N	50391	36057	49998	t
50472	INDIRECT	10	\N	50392	36057	49998	t
50782	INDIRECT	9	50562	\N	36057	49998	t
50783	INDIRECT	9	\N	50655	36057	49998	t
50784	INDIRECT	9	50563	\N	36057	49998	t
50785	INDIRECT	9	\N	50656	36057	49998	t
50786	INDIRECT	9	50564	\N	36057	49998	t
50787	INDIRECT	9	\N	50657	36057	49998	t
50788	INDIRECT	9	50565	\N	36057	49998	t
50789	INDIRECT	9	\N	50658	36057	49998	t
50790	INDIRECT	9	50566	\N	36057	49998	t
50791	INDIRECT	9	\N	50659	36057	49998	t
50792	INDIRECT	9	50567	\N	36057	49998	t
50793	INDIRECT	9	\N	50660	36057	49998	t
50794	INDIRECT	9	50568	\N	36057	49998	t
50795	INDIRECT	9	\N	50661	36057	49998	t
50796	INDIRECT	9	50569	\N	36057	49998	t
50797	INDIRECT	9	\N	50662	36057	49998	t
50417	INDIRECT	10	\N	50360	36057	49998	t
50418	INDIRECT	10	\N	50361	36057	49998	t
50419	INDIRECT	10	50189	\N	36057	49998	t
50420	INDIRECT	10	\N	50362	36057	49998	t
50421	INDIRECT	10	50190	\N	36057	49998	t
50422	INDIRECT	10	\N	50363	36057	49998	t
50423	INDIRECT	10	50191	\N	36057	49998	t
50424	INDIRECT	10	\N	50364	36057	49998	t
50425	INDIRECT	10	50192	\N	36057	49998	t
50426	INDIRECT	10	\N	50365	36057	49998	t
50427	INDIRECT	10	\N	50366	36057	49998	t
50428	INDIRECT	10	50193	\N	36057	49998	t
50429	INDIRECT	10	\N	50367	36057	49998	t
50430	INDIRECT	10	50194	\N	36057	49998	t
50431	INDIRECT	10	\N	50368	36057	49998	t
50432	INDIRECT	10	50195	\N	36057	49998	t
50433	INDIRECT	10	\N	50369	36057	49998	t
50434	INDIRECT	10	\N	50370	36057	49998	t
50435	INDIRECT	10	50196	\N	36057	49998	t
50436	INDIRECT	10	\N	50371	36057	49998	t
51642	INDIRECT	6	50503	\N	49894	51634	t
50473	INDIRECT	10	50515	\N	36057	49998	t
50474	INDIRECT	10	\N	50393	36057	49998	t
50475	INDIRECT	10	50516	\N	36057	49998	t
50476	INDIRECT	10	\N	50394	36057	49998	t
50477	INDIRECT	10	50517	\N	36057	49998	t
50478	INDIRECT	10	\N	50395	36057	49998	t
50479	INDIRECT	10	50518	\N	36057	49998	t
50480	INDIRECT	10	\N	50396	36057	49998	t
50481	INDIRECT	10	50519	\N	36057	49998	t
50484	INDIRECT	10	\N	50398	36057	49998	t
50485	INDIRECT	10	\N	50601	36057	49998	t
50486	INDIRECT	10	50521	\N	36057	49998	t
50487	INDIRECT	10	\N	50602	36057	49998	t
50488	INDIRECT	10	50522	\N	36057	49998	t
50763	INDIRECT	9	\N	50643	36057	49998	t
50764	INDIRECT	9	\N	50644	36057	49998	t
50765	INDIRECT	9	50555	\N	36057	49998	t
50766	INDIRECT	9	\N	50645	36057	49998	t
50767	INDIRECT	9	50556	\N	36057	49998	t
50768	INDIRECT	9	\N	50646	36057	49998	t
58107	DIRECT	4	\N	50669	49894	\N	\N
50437	INDIRECT	10	\N	50372	36057	49998	t
50438	INDIRECT	10	50500	\N	36057	49998	t
50439	INDIRECT	10	\N	50373	36057	49998	t
50446	INDIRECT	10	\N	50377	36057	49998	t
50447	INDIRECT	10	50504	\N	36057	49998	t
50448	INDIRECT	10	\N	50378	36057	49998	t
56910	INDIRECT	5	\N	50379	49894	56909	t
50449	INDIRECT	10	\N	50379	36057	49998	t
50450	INDIRECT	10	50505	\N	36057	49998	t
56911	INDIRECT	5	50505	\N	49894	56909	t
50451	INDIRECT	10	\N	50380	36057	49998	t
56912	DIRECT	5	\N	50380	49894	\N	\N
56913	INDIRECT	5	\N	50381	49894	56912	t
50452	INDIRECT	10	\N	50381	36057	49998	t
56914	INDIRECT	5	50506	\N	49894	56912	t
50453	INDIRECT	10	50506	\N	36057	49998	t
50454	INDIRECT	10	\N	50382	36057	49998	t
56915	INDIRECT	5	\N	50382	49894	56912	t
50455	INDIRECT	10	50507	\N	36057	49998	t
56916	INDIRECT	5	50507	\N	49894	56912	t
56917	INDIRECT	5	\N	50383	49894	56912	t
50456	INDIRECT	10	\N	50383	36057	49998	t
56918	INDIRECT	5	50508	\N	49894	56912	t
50457	INDIRECT	10	50508	\N	36057	49998	t
50458	INDIRECT	10	\N	50384	36057	49998	t
56919	DIRECT	5	\N	50384	49894	\N	\N
50459	INDIRECT	10	\N	50385	36057	49998	t
56920	INDIRECT	5	\N	50385	49894	56919	t
56921	INDIRECT	5	50509	\N	49894	56919	t
50460	INDIRECT	10	50509	\N	36057	49998	t
56922	INDIRECT	5	\N	50386	49894	56919	t
56923	INDIRECT	5	50510	\N	49894	56919	t
56924	INDIRECT	5	\N	50387	49894	56919	t
56925	INDIRECT	5	50511	\N	49894	56919	t
56926	INDIRECT	5	\N	50388	49894	56919	t
56927	INDIRECT	5	50512	\N	49894	56919	t
56928	INDIRECT	5	\N	50389	49894	56919	t
56929	INDIRECT	5	50513	\N	49894	56919	t
56930	INDIRECT	5	\N	50390	49894	56919	t
56931	INDIRECT	5	50514	\N	49894	56919	t
56906	DIRECT	5	\N	50376	49894	\N	\N
56907	INDIRECT	5	\N	50377	49894	56906	t
56908	INDIRECT	5	50504	\N	49894	56906	t
56909	DIRECT	5	\N	50378	49894	\N	\N
56940	INDIRECT	5	50517	\N	49894	56932	t
56941	INDIRECT	5	\N	50395	49894	56932	t
56942	INDIRECT	5	50518	\N	49894	56932	t
56943	INDIRECT	5	\N	50396	49894	56932	t
56944	INDIRECT	5	50519	\N	49894	56932	t
56945	DIRECT	5	\N	50398	49894	\N	\N
56946	INDIRECT	5	\N	50601	49894	56945	t
56947	INDIRECT	5	50521	\N	49894	56945	t
56948	INDIRECT	5	\N	50602	49894	56945	t
56949	INDIRECT	5	50522	\N	49894	56945	t
56950	DIRECT	5	\N	50643	49894	\N	\N
56951	INDIRECT	5	\N	50644	49894	56950	t
56952	INDIRECT	5	50555	\N	49894	56950	t
56953	INDIRECT	5	\N	50645	49894	56950	t
56954	INDIRECT	5	50556	\N	49894	56950	t
50774	INDIRECT	9	\N	50650	36057	49998	t
50775	INDIRECT	9	\N	50651	36057	49998	t
50776	INDIRECT	9	50559	\N	36057	49998	t
50777	INDIRECT	9	\N	50652	36057	49998	t
50778	INDIRECT	9	50560	\N	36057	49998	t
50779	INDIRECT	9	\N	50653	36057	49998	t
50780	INDIRECT	9	50561	\N	36057	49998	t
50781	INDIRECT	9	\N	50654	36057	49998	t
50798	INDIRECT	9	50570	\N	36057	49998	t
50809	INDIRECT	7	\N	50669	36057	49998	t
50810	INDIRECT	7	\N	50670	36057	49998	t
50811	INDIRECT	7	50575	\N	36057	49998	t
58095	INDIRECT	4	\N	50657	49894	58082	t
58096	INDIRECT	4	50565	\N	49894	58082	t
58097	INDIRECT	4	\N	50658	49894	58082	t
56932	DIRECT	5	\N	50391	49894	\N	\N
56934	DIRECT	5	\N	50392	49895	\N	\N
56933	INDIRECT	5	\N	50392	49894	56932	f
56936	INDIRECT	5	50515	\N	49894	56932	f
56935	INDIRECT	5	50515	\N	49895	56934	t
56937	INDIRECT	5	\N	50393	49894	56932	t
56938	INDIRECT	5	50516	\N	49894	56932	t
56939	INDIRECT	5	\N	50394	49894	56932	t
58082	DIRECT	4	\N	50650	49894	\N	\N
58083	INDIRECT	4	\N	50651	49894	58082	t
58084	INDIRECT	4	50559	\N	49894	58082	t
58085	INDIRECT	4	\N	50652	49894	58082	t
58086	INDIRECT	4	50560	\N	49894	58082	t
58087	INDIRECT	4	\N	50653	49894	58082	t
58088	INDIRECT	4	50561	\N	49894	58082	t
58089	INDIRECT	4	\N	50654	49894	58082	t
58090	INDIRECT	4	50562	\N	49894	58082	t
58091	INDIRECT	4	\N	50655	49894	58082	t
58092	INDIRECT	4	50563	\N	49894	58082	t
58093	INDIRECT	4	\N	50656	49894	58082	t
58094	INDIRECT	4	50564	\N	49894	58082	t
58098	INDIRECT	4	50566	\N	49894	58082	t
58099	INDIRECT	4	\N	50659	49894	58082	t
58100	INDIRECT	4	50567	\N	49894	58082	t
58101	INDIRECT	4	\N	50660	49894	58082	t
58102	INDIRECT	4	50568	\N	49894	58082	t
58103	DIRECT	4	\N	50661	49896	\N	\N
58104	INDIRECT	4	50569	\N	49896	58103	t
58105	DIRECT	4	\N	50662	49895	\N	\N
58106	INDIRECT	4	50570	\N	49895	58105	t
58108	INDIRECT	4	\N	50670	49894	58107	t
58109	INDIRECT	4	50575	\N	49894	58107	t
50812	INDIRECT	7	\N	50671	36057	49998	t
58110	INDIRECT	4	\N	50671	49894	58107	t
50813	INDIRECT	7	50576	\N	36057	49998	t
58111	INDIRECT	4	50576	\N	49894	58107	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
49700	3	2009-12-23 13:41:16.177	\N	f	49894	49297
49701	3	2009-12-23 13:41:11.777	\N	f	36057	49297
1819	2	2009-12-07 12:14:12.984	\N	f	107	1720
1818	2	2009-12-07 12:13:55.69	\N	f	105	1718
49714	1	2009-12-23 14:05:54.245	\N	f	36057	49313
49715	1	2009-12-23 14:05:57.765	\N	f	49894	49313
49716	2	2009-12-23 14:06:21.862	\N	f	108	49315
1821	3	2009-12-07 12:15:40.633	\N	f	106	1724
1820	3	2009-12-07 12:14:39.805	\N	f	105	1722
7575	6	2009-12-08 11:38:48.256	\N	f	111	7272
1822	7	2009-12-07 12:16:13.031	\N	f	105	1726
1823	7	2009-12-07 12:22:26.956	\N	f	110	1727
37977	1	2009-12-14 13:20:50.703	\N	f	38481	37575
49693	1	2009-12-23 13:33:29.272	\N	f	49894	36159
36562	2	2009-12-14 12:02:22.226	\N	f	36057	36159
49694	1	2009-12-23 13:33:42.338	\N	f	49894	37573
37976	2	2009-12-14 12:37:38.899	\N	f	36057	37573
40602	2	2009-12-18 11:37:52.396	\N	f	36057	40199
49695	1	2009-12-23 13:33:57.905	\N	f	49894	40199
49702	1	2009-12-23 13:42:17.331	\N	f	49894	49300
49703	1	2009-12-23 13:42:13.486	\N	f	36057	49300
49704	1	2009-12-23 13:42:31.649	\N	f	49895	49302
49705	1	2009-12-23 13:42:26.88	\N	f	36057	49302
49706	1	2009-12-23 13:43:57.657	\N	f	36057	49304
49707	1	2009-12-23 13:44:09.703	\N	f	49896	49304
49692	3	2009-12-23 13:31:53.237	\N	f	36057	49289
49710	1	2009-12-23 13:47:08.42	\N	f	36057	49309
49711	1	2009-12-23 13:47:11.819	\N	f	49894	49309
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
4	9	JOB	Job	t	t	t	1
16154624	1	Rol proyecto	\N	t	t	t	0
1	15	LEAVE	Leave	f	f	t	1
2	11	CATEGORY	Professional category	t	t	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
7	2	Tipo de máquina	\N	t	f	t	2
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id) FROM stdin;
30862	GENERIC_DAY	3	3	2010-02-05	1724	\N	29808
30863	GENERIC_DAY	3	3	2010-03-09	1724	\N	29808
30864	GENERIC_DAY	3	3	2010-01-15	1724	\N	29808
30865	GENERIC_DAY	3	3	2010-02-16	1724	\N	29808
30866	GENERIC_DAY	3	3	2010-01-21	1724	\N	29808
30867	GENERIC_DAY	3	0	2010-04-10	1724	\N	29808
30868	GENERIC_DAY	3	3	2010-01-25	1724	\N	29808
30869	GENERIC_DAY	3	0	2010-03-13	1724	\N	29808
30870	GENERIC_DAY	3	2	2010-04-15	1724	\N	29808
30871	GENERIC_DAY	3	0	2010-04-11	1724	\N	29808
30872	GENERIC_DAY	3	0	2010-03-20	1724	\N	29808
30873	GENERIC_DAY	3	3	2010-03-12	1724	\N	29808
30874	GENERIC_DAY	3	0	2010-03-06	1724	\N	29808
30875	GENERIC_DAY	3	3	2010-03-31	1724	\N	29808
30876	GENERIC_DAY	3	3	2010-03-17	1724	\N	29808
30877	GENERIC_DAY	3	2	2010-04-05	1724	\N	29808
30878	GENERIC_DAY	3	0	2010-03-27	1724	\N	29808
30879	GENERIC_DAY	3	0	2010-03-21	1724	\N	29808
30880	GENERIC_DAY	3	3	2010-03-10	1724	\N	29808
30881	GENERIC_DAY	3	3	2010-03-30	1724	\N	29808
30882	GENERIC_DAY	3	3	2010-03-11	1724	\N	29808
30883	GENERIC_DAY	3	3	2010-02-02	1724	\N	29808
30884	GENERIC_DAY	3	3	2010-03-24	1724	\N	29808
30885	GENERIC_DAY	3	0	2010-03-14	1724	\N	29808
30886	GENERIC_DAY	3	0	2010-02-21	1724	\N	29808
30887	GENERIC_DAY	3	0	2010-04-04	1724	\N	29808
30888	GENERIC_DAY	3	3	2010-01-20	1724	\N	29808
30889	GENERIC_DAY	3	3	2010-02-19	1724	\N	29808
30890	GENERIC_DAY	3	3	2010-02-04	1724	\N	29808
30891	GENERIC_DAY	3	3	2010-03-05	1724	\N	29808
30892	GENERIC_DAY	3	3	2010-02-12	1724	\N	29808
30893	GENERIC_DAY	3	3	2010-01-28	1724	\N	29808
30894	GENERIC_DAY	3	2	2010-04-13	1724	\N	29808
30895	GENERIC_DAY	3	3	2010-01-22	1724	\N	29808
30896	GENERIC_DAY	3	3	2010-03-02	1724	\N	29808
30897	GENERIC_DAY	3	0	2010-02-06	1724	\N	29808
30898	GENERIC_DAY	3	3	2010-01-12	1724	\N	29808
30899	GENERIC_DAY	3	3	2010-01-18	1724	\N	29808
30900	GENERIC_DAY	3	3	2010-03-23	1724	\N	29808
30901	GENERIC_DAY	3	2	2010-04-07	1724	\N	29808
30902	GENERIC_DAY	3	3	2010-01-11	1724	\N	29808
30903	GENERIC_DAY	3	0	2010-02-07	1724	\N	29808
30904	GENERIC_DAY	3	3	2010-02-24	1724	\N	29808
30905	GENERIC_DAY	3	0	2010-04-03	1724	\N	29808
30906	GENERIC_DAY	3	2	2010-04-08	1724	\N	29808
30907	GENERIC_DAY	3	3	2010-02-25	1724	\N	29808
30908	GENERIC_DAY	3	3	2010-01-29	1724	\N	29808
30909	GENERIC_DAY	3	0	2010-01-30	1724	\N	29808
30910	GENERIC_DAY	3	3	2010-02-17	1724	\N	29808
30911	GENERIC_DAY	3	3	2010-02-10	1724	\N	29808
30912	GENERIC_DAY	3	3	2010-01-19	1724	\N	29808
30913	GENERIC_DAY	3	2	2010-04-12	1724	\N	29808
30914	GENERIC_DAY	3	0	2010-04-18	1724	\N	29808
30915	GENERIC_DAY	3	3	2010-02-08	1724	\N	29808
30916	GENERIC_DAY	3	0	2010-01-24	1724	\N	29808
30917	GENERIC_DAY	3	0	2010-03-07	1724	\N	29808
30918	GENERIC_DAY	3	0	2010-02-27	1724	\N	29808
30919	GENERIC_DAY	3	0	2010-01-23	1724	\N	29808
30920	GENERIC_DAY	3	3	2010-02-01	1724	\N	29808
30921	GENERIC_DAY	3	3	2010-03-25	1724	\N	29808
30922	GENERIC_DAY	3	3	2010-04-01	1724	\N	29808
30923	GENERIC_DAY	3	0	2010-01-17	1724	\N	29808
16002	GENERIC_DAY	3	3	2010-04-07	1726	\N	3985
16003	GENERIC_DAY	3	2	2010-04-08	1718	\N	3985
16004	GENERIC_DAY	3	1	2010-04-10	1718	\N	3985
16005	GENERIC_DAY	3	3	2010-03-29	1722	\N	3985
16006	GENERIC_DAY	3	2	2010-04-05	1718	\N	3985
16007	GENERIC_DAY	3	3	2010-04-03	1722	\N	3985
16008	GENERIC_DAY	3	3	2010-04-01	1726	\N	3985
16009	GENERIC_DAY	3	2	2010-04-09	1718	\N	3985
16010	GENERIC_DAY	3	2	2010-03-30	1718	\N	3985
16011	GENERIC_DAY	3	3	2010-04-09	1722	\N	3985
16012	GENERIC_DAY	3	2	2010-04-02	1718	\N	3985
16013	GENERIC_DAY	3	2	2010-04-03	1718	\N	3985
16014	GENERIC_DAY	3	2	2010-03-31	1718	\N	3985
16015	GENERIC_DAY	3	3	2010-04-09	1726	\N	3985
16016	GENERIC_DAY	3	3	2010-03-29	1726	\N	3985
16017	GENERIC_DAY	3	3	2010-04-05	1722	\N	3985
16018	GENERIC_DAY	3	2	2010-04-07	1718	\N	3985
16019	GENERIC_DAY	3	3	2010-04-04	1722	\N	3985
16020	GENERIC_DAY	3	2	2010-03-29	1718	\N	3985
16021	GENERIC_DAY	3	2	2010-04-04	1718	\N	3985
16022	GENERIC_DAY	3	2	2010-04-01	1718	\N	3985
16023	GENERIC_DAY	3	3	2010-03-30	1722	\N	3985
16024	GENERIC_DAY	3	3	2010-04-02	1722	\N	3985
16025	GENERIC_DAY	3	3	2010-04-07	1722	\N	3985
16026	GENERIC_DAY	3	3	2010-04-04	1726	\N	3985
16027	GENERIC_DAY	3	2	2010-04-06	1718	\N	3985
16028	GENERIC_DAY	3	3	2010-04-06	1726	\N	3985
16029	GENERIC_DAY	3	1	2010-04-10	1726	\N	3985
16030	GENERIC_DAY	3	2	2010-04-10	1722	\N	3985
16031	GENERIC_DAY	3	3	2010-04-03	1726	\N	3985
16032	GENERIC_DAY	3	3	2010-03-31	1726	\N	3985
16033	GENERIC_DAY	3	3	2010-04-06	1722	\N	3985
16034	GENERIC_DAY	3	3	2010-04-08	1726	\N	3985
38745	GENERIC_DAY	6	5	2010-03-09	37573	\N	38583
38732	GENERIC_DAY	6	0	2010-03-14	37573	\N	38583
38744	GENERIC_DAY	6	3	2010-03-02	36159	\N	38583
38752	GENERIC_DAY	6	4	2010-02-24	37573	\N	38583
38759	GENERIC_DAY	6	3	2010-03-11	36159	\N	38583
38746	GENERIC_DAY	6	5	2010-03-03	37573	\N	38583
38757	GENERIC_DAY	6	4	2010-02-26	36159	\N	38583
38736	GENERIC_DAY	6	0	2010-03-06	36159	\N	38583
38747	GENERIC_DAY	6	3	2010-03-01	36159	\N	38583
38753	GENERIC_DAY	6	5	2010-03-12	37573	\N	38583
38734	GENERIC_DAY	6	4	2010-02-25	36159	\N	38583
38733	GENERIC_DAY	6	0	2010-03-13	36159	\N	38583
38730	GENERIC_DAY	6	0	2010-03-14	36159	\N	38583
38756	GENERIC_DAY	6	3	2010-03-08	36159	\N	38583
27203	GENERIC_DAY	1	3	2009-12-09	1718	\N	3940
27204	GENERIC_DAY	1	3	2009-12-16	1726	\N	3940
27205	GENERIC_DAY	1	3	2009-12-10	1726	\N	3940
27206	GENERIC_DAY	1	1	2009-12-23	1726	\N	3940
27207	GENERIC_DAY	1	2	2009-12-08	1718	\N	3940
27208	GENERIC_DAY	1	3	2009-12-08	1722	\N	3940
27209	GENERIC_DAY	1	0	2009-12-13	1718	\N	3940
38735	GENERIC_DAY	6	3	2010-03-03	36159	\N	38583
38741	GENERIC_DAY	6	3	2010-02-22	36159	\N	38583
38742	GENERIC_DAY	6	3	2010-03-05	36159	\N	38583
31145	GENERIC_DAY	1	8	2010-03-15	1724	\N	28093
31146	GENERIC_DAY	1	0	2010-02-20	1724	\N	28093
24760	GENERIC_DAY	1	8	2010-04-15	1720	\N	19898
24748	GENERIC_DAY	1	8	2010-04-20	1720	\N	19898
24751	GENERIC_DAY	1	8	2010-04-21	1720	\N	19898
24764	GENERIC_DAY	1	8	2010-04-08	1720	\N	19898
24756	GENERIC_DAY	1	0	2010-04-10	1720	\N	19898
24745	GENERIC_DAY	1	0	2010-04-03	1720	\N	19898
24749	GENERIC_DAY	1	0	2010-04-18	1720	\N	19898
24755	GENERIC_DAY	1	0	2010-04-04	1720	\N	19898
24752	GENERIC_DAY	1	8	2010-04-09	1720	\N	19898
24753	GENERIC_DAY	1	8	2010-04-05	1720	\N	19898
24762	GENERIC_DAY	1	8	2010-04-12	1720	\N	19898
24758	GENERIC_DAY	1	8	2010-04-06	1720	\N	19898
24763	GENERIC_DAY	1	8	2010-04-01	1720	\N	19898
24750	GENERIC_DAY	1	8	2010-04-13	1720	\N	19898
24766	GENERIC_DAY	1	4	2010-04-22	1720	\N	19898
24747	GENERIC_DAY	1	8	2010-04-07	1720	\N	19898
24754	GENERIC_DAY	1	8	2010-04-02	1720	\N	19898
24757	GENERIC_DAY	1	8	2010-03-31	1720	\N	19898
24759	GENERIC_DAY	1	8	2010-04-19	1720	\N	19898
24743	GENERIC_DAY	1	8	2010-04-16	1720	\N	19898
24744	GENERIC_DAY	1	0	2010-04-11	1720	\N	19898
24746	GENERIC_DAY	1	8	2010-03-30	1720	\N	19898
24765	GENERIC_DAY	1	0	2010-04-17	1720	\N	19898
24761	GENERIC_DAY	1	8	2010-04-14	1720	\N	19898
24660	GENERIC_DAY	1	2	2010-02-10	1718	\N	19899
24694	GENERIC_DAY	1	0	2009-12-27	1726	\N	19899
24699	GENERIC_DAY	1	0	2010-01-10	1722	\N	19899
24691	GENERIC_DAY	1	2	2010-02-11	1718	\N	19899
24621	GENERIC_DAY	1	2	2010-01-05	1722	\N	19899
24732	GENERIC_DAY	1	0	2010-01-03	1726	\N	19899
24693	GENERIC_DAY	1	3	2009-12-18	1726	\N	19899
24603	GENERIC_DAY	1	2	2010-02-09	1718	\N	19899
24695	GENERIC_DAY	1	2	2009-12-22	1726	\N	19899
24684	GENERIC_DAY	1	2	2010-01-27	1726	\N	19899
24618	GENERIC_DAY	1	2	2010-02-03	1722	\N	19899
24722	GENERIC_DAY	1	2	2009-12-23	1722	\N	19899
24672	GENERIC_DAY	1	0	2010-01-30	1718	\N	19899
24737	GENERIC_DAY	1	0	2010-01-16	1722	\N	19899
24734	GENERIC_DAY	1	3	2010-01-13	1726	\N	19899
24697	GENERIC_DAY	1	2	2010-01-18	1718	\N	19899
24630	GENERIC_DAY	1	2	2009-12-24	1722	\N	19899
24656	GENERIC_DAY	1	3	2009-12-24	1718	\N	19899
24718	GENERIC_DAY	1	0	2010-01-03	1722	\N	19899
24663	GENERIC_DAY	1	2	2009-12-29	1726	\N	19899
24708	GENERIC_DAY	1	0	2009-12-26	1722	\N	19899
24644	GENERIC_DAY	1	2	2010-01-25	1718	\N	19899
24692	GENERIC_DAY	1	0	2010-01-24	1726	\N	19899
24639	GENERIC_DAY	1	3	2010-01-08	1726	\N	19899
24698	GENERIC_DAY	1	2	2009-12-28	1726	\N	19899
24742	GENERIC_DAY	1	0	2009-12-20	1722	\N	19899
24726	GENERIC_DAY	1	2	2010-01-27	1718	\N	19899
24647	GENERIC_DAY	1	0	2010-01-10	1726	\N	19899
24730	GENERIC_DAY	1	2	2010-01-13	1722	\N	19899
24641	GENERIC_DAY	1	1	2009-12-18	1722	\N	19899
24602	GENERIC_DAY	1	0	2010-02-07	1726	\N	19899
24649	GENERIC_DAY	1	2	2010-01-18	1722	\N	19899
24638	GENERIC_DAY	1	3	2010-01-05	1718	\N	19899
24655	GENERIC_DAY	1	0	2010-01-10	1718	\N	19899
24733	GENERIC_DAY	1	2	2010-01-29	1722	\N	19899
24702	GENERIC_DAY	1	2	2010-02-10	1726	\N	19899
24689	GENERIC_DAY	1	2	2010-02-09	1726	\N	19899
24711	GENERIC_DAY	1	2	2010-01-07	1718	\N	19899
24614	GENERIC_DAY	1	2	2010-02-04	1722	\N	19899
24609	GENERIC_DAY	1	2	2010-01-08	1718	\N	19899
24690	GENERIC_DAY	1	3	2009-12-31	1718	\N	19899
24611	GENERIC_DAY	1	2	2009-12-21	1726	\N	19899
24632	GENERIC_DAY	1	0	2010-01-02	1726	\N	19899
24687	GENERIC_DAY	1	0	2010-01-24	1718	\N	19899
24654	GENERIC_DAY	1	0	2009-12-26	1726	\N	19899
24619	GENERIC_DAY	1	0	2010-01-16	1726	\N	19899
24716	GENERIC_DAY	1	0	2010-01-09	1722	\N	19899
24642	GENERIC_DAY	1	0	2009-12-26	1718	\N	19899
24736	GENERIC_DAY	1	2	2010-01-20	1718	\N	19899
24653	GENERIC_DAY	1	2	2009-12-30	1722	\N	19899
24628	GENERIC_DAY	1	0	2010-01-03	1718	\N	19899
24652	GENERIC_DAY	1	2	2010-02-09	1722	\N	19899
24666	GENERIC_DAY	1	2	2010-01-04	1722	\N	19899
24741	GENERIC_DAY	1	0	2010-01-17	1726	\N	19899
24686	GENERIC_DAY	1	2	2010-01-26	1726	\N	19899
24738	GENERIC_DAY	1	2	2010-02-04	1726	\N	19899
24615	GENERIC_DAY	1	2	2010-01-26	1722	\N	19899
24723	GENERIC_DAY	1	0	2010-01-09	1726	\N	19899
24657	GENERIC_DAY	1	2	2010-01-15	1718	\N	19899
24608	GENERIC_DAY	1	2	2010-01-14	1718	\N	19899
24665	GENERIC_DAY	1	0	2009-12-19	1726	\N	19899
24648	GENERIC_DAY	1	2	2010-02-01	1726	\N	19899
24721	GENERIC_DAY	1	0	2010-01-30	1726	\N	19899
24635	GENERIC_DAY	1	3	2009-12-18	1718	\N	19899
24717	GENERIC_DAY	1	0	2010-01-24	1722	\N	19899
24673	GENERIC_DAY	1	3	2009-12-21	1718	\N	19899
24600	GENERIC_DAY	1	2	2010-01-28	1718	\N	19899
24735	GENERIC_DAY	1	0	2009-12-27	1718	\N	19899
24643	GENERIC_DAY	1	0	2010-01-31	1726	\N	19899
24682	GENERIC_DAY	1	0	2010-02-07	1718	\N	19899
24704	GENERIC_DAY	1	3	2010-01-18	1726	\N	19899
24625	GENERIC_DAY	1	2	2010-01-06	1718	\N	19899
24616	GENERIC_DAY	1	2	2009-12-31	1726	\N	19899
24613	GENERIC_DAY	1	3	2010-01-15	1726	\N	19899
24661	GENERIC_DAY	1	2	2010-01-21	1722	\N	19899
24688	GENERIC_DAY	1	3	2009-12-28	1718	\N	19899
24633	GENERIC_DAY	1	3	2009-12-23	1718	\N	19899
24667	GENERIC_DAY	1	2	2010-02-11	1726	\N	19899
24669	GENERIC_DAY	1	0	2010-02-07	1722	\N	19899
24617	GENERIC_DAY	1	2	2010-01-11	1718	\N	19899
24664	GENERIC_DAY	1	2	2010-01-21	1718	\N	19899
24677	GENERIC_DAY	1	2	2010-01-20	1722	\N	19899
24605	GENERIC_DAY	1	0	2010-01-01	1722	\N	19899
24629	GENERIC_DAY	1	2	2009-12-24	1726	\N	19899
24731	GENERIC_DAY	1	2	2010-01-07	1722	\N	19899
24681	GENERIC_DAY	1	2	2010-02-08	1726	\N	19899
24674	GENERIC_DAY	1	0	2010-01-31	1718	\N	19899
24715	GENERIC_DAY	1	3	2009-12-29	1718	\N	19899
24724	GENERIC_DAY	1	0	2009-12-25	1726	\N	19899
24739	GENERIC_DAY	1	2	2010-01-26	1718	\N	19899
24612	GENERIC_DAY	1	3	2009-12-30	1718	\N	19899
24636	GENERIC_DAY	1	2	2010-01-25	1722	\N	19899
24725	GENERIC_DAY	1	2	2010-02-08	1718	\N	19899
24679	GENERIC_DAY	1	0	2009-12-19	1722	\N	19899
24662	GENERIC_DAY	1	0	2010-01-02	1718	\N	19899
24683	GENERIC_DAY	1	0	2010-02-06	1718	\N	19899
24626	GENERIC_DAY	1	2	2010-01-27	1722	\N	19899
24645	GENERIC_DAY	1	0	2010-02-06	1722	\N	19899
24640	GENERIC_DAY	1	2	2010-02-11	1722	\N	19899
24604	GENERIC_DAY	1	0	2010-01-09	1718	\N	19899
24710	GENERIC_DAY	1	0	2010-01-23	1726	\N	19899
24610	GENERIC_DAY	1	3	2010-01-04	1718	\N	19899
24728	GENERIC_DAY	1	2	2010-01-04	1726	\N	19899
24634	GENERIC_DAY	1	2	2010-01-22	1718	\N	19899
24700	GENERIC_DAY	1	2	2010-02-05	1718	\N	19899
24729	GENERIC_DAY	1	2	2010-01-08	1722	\N	19899
24650	GENERIC_DAY	1	2	2010-01-12	1722	\N	19899
24646	GENERIC_DAY	1	3	2010-01-11	1726	\N	19899
24706	GENERIC_DAY	1	2	2010-02-04	1718	\N	19899
24701	GENERIC_DAY	1	2	2010-01-12	1718	\N	19899
24599	GENERIC_DAY	1	2	2009-12-22	1722	\N	19899
24727	GENERIC_DAY	1	2	2010-02-03	1718	\N	19899
24606	GENERIC_DAY	1	2	2010-01-14	1722	\N	19899
24712	GENERIC_DAY	1	2	2009-12-31	1722	\N	19899
24707	GENERIC_DAY	1	2	2010-02-05	1722	\N	19899
24696	GENERIC_DAY	1	2	2009-12-29	1722	\N	19899
24607	GENERIC_DAY	1	0	2010-01-02	1722	\N	19899
24740	GENERIC_DAY	1	0	2009-12-20	1726	\N	19899
24601	GENERIC_DAY	1	2	2010-01-25	1726	\N	19899
24620	GENERIC_DAY	1	2	2010-01-28	1726	\N	19899
24637	GENERIC_DAY	1	3	2010-01-14	1726	\N	19899
24680	GENERIC_DAY	1	2	2010-02-03	1726	\N	19899
24623	GENERIC_DAY	1	0	2009-12-25	1722	\N	19899
24659	GENERIC_DAY	1	2	2009-12-21	1722	\N	19899
24719	GENERIC_DAY	1	2	2010-02-01	1722	\N	19899
24703	GENERIC_DAY	1	2	2010-02-08	1722	\N	19899
24624	GENERIC_DAY	1	0	2010-01-23	1722	\N	19899
24678	GENERIC_DAY	1	2	2009-12-28	1722	\N	19899
24720	GENERIC_DAY	1	2	2010-01-21	1726	\N	19899
24705	GENERIC_DAY	1	0	2010-01-01	1718	\N	19899
24668	GENERIC_DAY	1	2	2010-01-22	1726	\N	19899
24675	GENERIC_DAY	1	2	2010-02-10	1722	\N	19899
24709	GENERIC_DAY	1	0	2010-01-23	1718	\N	19899
24676	GENERIC_DAY	1	2	2010-01-19	1718	\N	19899
24714	GENERIC_DAY	1	2	2010-01-19	1722	\N	19899
24627	GENERIC_DAY	1	2	2010-01-28	1722	\N	19899
24651	GENERIC_DAY	1	2	2010-01-29	1726	\N	19899
24622	GENERIC_DAY	1	0	2009-12-25	1718	\N	19899
24631	GENERIC_DAY	1	2	2010-02-01	1718	\N	19899
24713	GENERIC_DAY	1	0	2010-01-17	1718	\N	19899
24685	GENERIC_DAY	1	0	2009-12-19	1718	\N	19899
24658	GENERIC_DAY	1	2	2009-12-23	1726	\N	19899
24671	GENERIC_DAY	1	0	2010-02-06	1726	\N	19899
24670	GENERIC_DAY	1	3	2010-01-20	1726	\N	19899
24787	GENERIC_DAY	1	1	2010-03-01	1722	\N	19897
24820	GENERIC_DAY	1	4	2010-02-23	1718	\N	19897
24884	GENERIC_DAY	1	0	2010-03-14	1722	\N	19897
24869	GENERIC_DAY	1	2	2010-03-23	1722	\N	19897
24817	GENERIC_DAY	1	0	2010-02-28	1722	\N	19897
24826	GENERIC_DAY	1	0	2010-03-07	1726	\N	19897
24776	GENERIC_DAY	1	2	2010-03-24	1722	\N	19897
24844	GENERIC_DAY	1	3	2010-03-18	1718	\N	19897
24852	GENERIC_DAY	1	0	2010-03-13	1722	\N	19897
24785	GENERIC_DAY	1	2	2010-03-05	1722	\N	19897
24854	GENERIC_DAY	1	3	2010-02-22	1726	\N	19897
24789	GENERIC_DAY	1	0	2010-02-14	1722	\N	19897
24876	GENERIC_DAY	1	1	2010-02-19	1722	\N	19897
24804	GENERIC_DAY	1	0	2010-03-07	1718	\N	19897
24821	GENERIC_DAY	1	0	2010-03-28	1722	\N	19897
24790	GENERIC_DAY	1	0	2010-02-13	1722	\N	19897
24793	GENERIC_DAY	1	0	2010-03-06	1722	\N	19897
24846	GENERIC_DAY	1	0	2010-02-28	1718	\N	19897
24881	GENERIC_DAY	1	0	2010-02-28	1726	\N	19897
24836	GENERIC_DAY	1	2	2010-03-08	1722	\N	19897
24808	GENERIC_DAY	1	0	2010-03-27	1718	\N	19897
24875	GENERIC_DAY	1	0	2010-03-28	1726	\N	19897
24889	GENERIC_DAY	1	3	2010-03-10	1718	\N	19897
39365	GENERIC_DAY	3	0	2010-02-13	36159	\N	38596
39364	GENERIC_DAY	3	0	2010-02-06	37573	\N	38596
39375	GENERIC_DAY	3	1	2010-02-09	36159	\N	38596
39369	GENERIC_DAY	3	0	2010-02-16	37573	\N	38596
39360	GENERIC_DAY	3	0	2010-02-14	36159	\N	38596
39362	GENERIC_DAY	3	0	2010-02-15	36159	\N	38596
39374	GENERIC_DAY	3	0	2010-02-15	37573	\N	38596
39363	GENERIC_DAY	3	0	2010-02-12	37573	\N	38596
39372	GENERIC_DAY	3	0	2010-02-06	36159	\N	38596
39367	GENERIC_DAY	3	0	2010-01-24	37573	\N	38596
39358	GENERIC_DAY	3	0	2010-02-07	36159	\N	38596
39357	GENERIC_DAY	3	1	2010-01-28	37573	\N	38596
39373	GENERIC_DAY	3	0	2010-02-08	37573	\N	38596
39356	GENERIC_DAY	3	0	2010-02-17	37573	\N	38596
39371	GENERIC_DAY	3	0	2010-02-05	37573	\N	38596
39370	GENERIC_DAY	3	0	2010-02-03	37573	\N	38596
39361	GENERIC_DAY	3	0	2010-01-29	36159	\N	38596
39359	GENERIC_DAY	3	0	2010-01-22	37573	\N	38596
39366	GENERIC_DAY	3	0	2010-02-14	37573	\N	38596
39368	GENERIC_DAY	3	0	2010-01-26	37573	\N	38596
39376	GENERIC_DAY	3	0	2010-01-27	36159	\N	38596
39354	GENERIC_DAY	3	4	2010-03-16	37573	\N	38595
39355	GENERIC_DAY	3	3	2010-03-16	36159	\N	38595
31194	GENERIC_DAY	1	0	2010-02-28	1724	\N	28093
31169	GENERIC_DAY	1	8	2010-03-09	1724	\N	28093
31167	GENERIC_DAY	1	8	2010-02-01	1724	\N	28093
31229	GENERIC_DAY	1	0	2010-03-27	1724	\N	28093
31207	GENERIC_DAY	1	8	2010-03-29	1724	\N	28093
31221	GENERIC_DAY	1	8	2010-03-04	1724	\N	28093
31217	GENERIC_DAY	1	8	2010-03-08	1724	\N	28093
31185	GENERIC_DAY	1	9	2010-01-22	1724	\N	28093
31175	GENERIC_DAY	1	9	2010-01-18	1724	\N	28093
31189	GENERIC_DAY	1	8	2010-03-17	1724	\N	28093
31163	GENERIC_DAY	1	8	2010-04-09	1724	\N	28093
39385	GENERIC_DAY	3	0	2010-02-17	36159	\N	38596
39398	GENERIC_DAY	3	0	2010-01-24	36159	\N	38596
39381	GENERIC_DAY	3	0	2010-02-11	37573	\N	38596
39409	GENERIC_DAY	3	1	2010-02-03	36159	\N	38596
39397	GENERIC_DAY	3	0	2010-01-25	37573	\N	38596
39404	GENERIC_DAY	3	1	2010-02-04	36159	\N	38596
39379	GENERIC_DAY	3	0	2010-01-30	36159	\N	38596
39383	GENERIC_DAY	3	1	2010-01-29	37573	\N	38596
39380	GENERIC_DAY	3	0	2010-02-10	37573	\N	38596
39405	GENERIC_DAY	3	1	2010-01-26	36159	\N	38596
39401	GENERIC_DAY	3	1	2010-01-27	37573	\N	38596
39378	GENERIC_DAY	3	0	2010-02-13	37573	\N	38596
39392	GENERIC_DAY	3	0	2010-02-02	37573	\N	38596
39400	GENERIC_DAY	3	1	2010-01-22	36159	\N	38596
39386	GENERIC_DAY	3	1	2010-01-25	36159	\N	38596
39388	GENERIC_DAY	3	1	2010-02-05	36159	\N	38596
39399	GENERIC_DAY	3	0	2010-01-31	36159	\N	38596
39394	GENERIC_DAY	3	1	2010-02-12	36159	\N	38596
39387	GENERIC_DAY	3	1	2010-02-08	36159	\N	38596
39391	GENERIC_DAY	3	0	2010-02-16	36159	\N	38596
39377	GENERIC_DAY	3	0	2010-01-28	36159	\N	38596
39403	GENERIC_DAY	3	0	2010-01-23	37573	\N	38596
39384	GENERIC_DAY	3	0	2010-02-04	37573	\N	38596
39407	GENERIC_DAY	3	1	2010-02-01	37573	\N	38596
39395	GENERIC_DAY	3	0	2010-01-30	37573	\N	38596
39402	GENERIC_DAY	3	0	2010-02-07	37573	\N	38596
39393	GENERIC_DAY	3	1	2010-02-11	36159	\N	38596
39396	GENERIC_DAY	3	1	2010-02-10	36159	\N	38596
39390	GENERIC_DAY	3	1	2010-02-02	36159	\N	38596
39406	GENERIC_DAY	3	0	2010-01-31	37573	\N	38596
39389	GENERIC_DAY	3	0	2010-02-09	37573	\N	38596
39408	GENERIC_DAY	3	0	2010-02-01	36159	\N	38596
39382	GENERIC_DAY	3	0	2010-01-23	36159	\N	38596
39410	GENERIC_DAY	3	3	2010-02-18	37573	\N	38597
39411	GENERIC_DAY	3	4	2010-02-18	36159	\N	38597
39414	GENERIC_DAY	3	4	2010-03-17	36159	\N	38598
39412	GENERIC_DAY	3	3	2010-03-18	36159	\N	38598
39413	GENERIC_DAY	3	4	2010-03-17	37573	\N	38598
39415	GENERIC_DAY	3	3	2010-03-18	37573	\N	38598
41319	GENERIC_DAY	18	2	2010-01-12	36159	\N	41014
41325	GENERIC_DAY	18	2	2010-01-11	37573	\N	41014
41320	GENERIC_DAY	18	2	2010-01-11	36159	\N	41014
41321	GENERIC_DAY	18	2	2010-01-12	40199	\N	41014
41323	GENERIC_DAY	18	1	2010-01-13	36159	\N	41014
41324	GENERIC_DAY	18	2	2010-01-12	37573	\N	41014
41322	GENERIC_DAY	18	0	2010-01-13	40199	\N	41014
41318	GENERIC_DAY	18	1	2010-01-13	37573	\N	41014
41317	GENERIC_DAY	18	2	2010-01-11	40199	\N	41014
45744	GENERIC_DAY	6	0	2010-02-03	40199	\N	41069
45748	GENERIC_DAY	6	0	2010-02-01	40199	\N	41069
45728	GENERIC_DAY	6	0	2010-01-15	36159	\N	41069
45727	GENERIC_DAY	6	0	2010-02-04	40199	\N	41069
45735	GENERIC_DAY	6	1	2010-01-12	37573	\N	41069
45738	GENERIC_DAY	6	0	2010-01-13	40199	\N	41069
27496	GENERIC_DAY	1	8	2009-12-31	1724	\N	3953
39428	GENERIC_DAY	2	0	2010-03-21	37573	\N	38600
39429	GENERIC_DAY	2	2	2010-03-22	37573	\N	38600
39430	GENERIC_DAY	2	1	2010-03-24	36159	\N	38600
39431	GENERIC_DAY	2	0	2010-03-20	36159	\N	38600
24778	GENERIC_DAY	1	0	2010-03-14	1726	\N	19897
24883	GENERIC_DAY	1	3	2010-03-05	1718	\N	19897
24860	GENERIC_DAY	1	4	2010-02-17	1726	\N	19897
24801	GENERIC_DAY	1	3	2010-02-16	1718	\N	19897
24822	GENERIC_DAY	1	3	2010-03-08	1726	\N	19897
24772	GENERIC_DAY	1	2	2010-03-25	1726	\N	19897
24887	GENERIC_DAY	1	4	2010-02-25	1718	\N	19897
24807	GENERIC_DAY	1	4	2010-02-16	1726	\N	19897
24786	GENERIC_DAY	1	4	2010-02-26	1718	\N	19897
24857	GENERIC_DAY	1	4	2010-02-24	1718	\N	19897
24855	GENERIC_DAY	1	1	2010-02-24	1722	\N	19897
24834	GENERIC_DAY	1	2	2010-03-16	1722	\N	19897
24788	GENERIC_DAY	1	0	2010-02-27	1718	\N	19897
24864	GENERIC_DAY	1	3	2010-03-09	1718	\N	19897
24851	GENERIC_DAY	1	3	2010-03-08	1718	\N	19897
24850	GENERIC_DAY	1	2	2010-03-26	1726	\N	19897
24880	GENERIC_DAY	1	1	2010-02-12	1722	\N	19897
39432	GENERIC_DAY	2	2	2010-03-24	37573	\N	38600
39433	GENERIC_DAY	2	2	2010-03-19	36159	\N	38600
39434	GENERIC_DAY	2	0	2010-03-20	37573	\N	38600
39435	GENERIC_DAY	2	2	2010-03-22	36159	\N	38600
39436	GENERIC_DAY	2	0	2010-03-21	36159	\N	38600
39437	GENERIC_DAY	2	2	2010-03-23	37573	\N	38600
39438	GENERIC_DAY	2	1	2010-03-23	36159	\N	38600
24870	GENERIC_DAY	1	0	2010-02-20	1722	\N	19897
24856	GENERIC_DAY	1	2	2010-03-24	1726	\N	19897
24879	GENERIC_DAY	1	2	2010-03-12	1722	\N	19897
24841	GENERIC_DAY	1	3	2010-03-03	1726	\N	19897
24866	GENERIC_DAY	1	3	2010-03-17	1718	\N	19897
24799	GENERIC_DAY	1	4	2010-03-26	1718	\N	19897
24828	GENERIC_DAY	1	2	2010-03-29	1718	\N	19897
24837	GENERIC_DAY	1	1	2010-03-03	1722	\N	19897
24796	GENERIC_DAY	1	3	2010-02-17	1718	\N	19897
24775	GENERIC_DAY	1	2	2010-03-19	1726	\N	19897
24871	GENERIC_DAY	1	2	2010-03-11	1722	\N	19897
24865	GENERIC_DAY	1	0	2010-03-20	1726	\N	19897
24867	GENERIC_DAY	1	3	2010-02-23	1726	\N	19897
24814	GENERIC_DAY	1	3	2010-03-11	1718	\N	19897
24842	GENERIC_DAY	1	2	2010-03-23	1726	\N	19897
24812	GENERIC_DAY	1	4	2010-03-02	1718	\N	19897
24795	GENERIC_DAY	1	3	2010-03-12	1726	\N	19897
24774	GENERIC_DAY	1	2	2010-03-22	1726	\N	19897
24833	GENERIC_DAY	1	1	2010-03-02	1722	\N	19897
24862	GENERIC_DAY	1	3	2010-02-18	1718	\N	19897
24802	GENERIC_DAY	1	3	2010-03-16	1718	\N	19897
24845	GENERIC_DAY	1	2	2010-03-17	1722	\N	19897
24872	GENERIC_DAY	1	0	2010-02-13	1726	\N	19897
24783	GENERIC_DAY	1	0	2010-03-27	1722	\N	19897
24800	GENERIC_DAY	1	4	2010-02-18	1726	\N	19897
24838	GENERIC_DAY	1	4	2010-02-12	1718	\N	19897
24868	GENERIC_DAY	1	3	2010-02-25	1726	\N	19897
24859	GENERIC_DAY	1	0	2010-03-29	1722	\N	19897
24831	GENERIC_DAY	1	3	2010-03-04	1726	\N	19897
24847	GENERIC_DAY	1	4	2010-02-15	1726	\N	19897
24886	GENERIC_DAY	1	0	2010-03-07	1722	\N	19897
24813	GENERIC_DAY	1	3	2010-03-04	1718	\N	19897
24810	GENERIC_DAY	1	0	2010-02-21	1726	\N	19897
24861	GENERIC_DAY	1	2	2010-03-04	1722	\N	19897
24791	GENERIC_DAY	1	3	2010-03-11	1726	\N	19897
24777	GENERIC_DAY	1	3	2010-03-10	1726	\N	19897
24792	GENERIC_DAY	1	0	2010-03-06	1718	\N	19897
24874	GENERIC_DAY	1	1	2010-02-16	1722	\N	19897
24770	GENERIC_DAY	1	0	2010-03-13	1718	\N	19897
24848	GENERIC_DAY	1	2	2010-03-26	1722	\N	19897
24849	GENERIC_DAY	1	3	2010-03-18	1722	\N	19897
24882	GENERIC_DAY	1	3	2010-03-17	1726	\N	19897
24782	GENERIC_DAY	1	0	2010-02-27	1726	\N	19897
24767	GENERIC_DAY	1	3	2010-02-12	1726	\N	19897
24835	GENERIC_DAY	1	0	2010-03-28	1718	\N	19897
24769	GENERIC_DAY	1	2	2010-03-22	1722	\N	19897
24773	GENERIC_DAY	1	3	2010-03-05	1726	\N	19897
45732	GENERIC_DAY	6	0	2010-01-27	36159	\N	41069
45731	GENERIC_DAY	6	0	2010-02-04	36159	\N	41069
45736	GENERIC_DAY	6	0	2010-01-26	36159	\N	41069
45743	GENERIC_DAY	6	1	2010-01-26	40199	\N	41069
45729	GENERIC_DAY	6	0	2010-01-19	40199	\N	41069
45734	GENERIC_DAY	6	1	2010-01-25	40199	\N	41069
45750	GENERIC_DAY	6	0	2010-01-18	36159	\N	41069
45745	GENERIC_DAY	6	0	2010-01-31	40199	\N	41069
24839	GENERIC_DAY	1	4	2010-03-01	1718	\N	19897
24768	GENERIC_DAY	1	4	2010-02-22	1718	\N	19897
24781	GENERIC_DAY	1	1	2010-02-18	1722	\N	19897
24823	GENERIC_DAY	1	4	2010-03-23	1718	\N	19897
24843	GENERIC_DAY	1	1	2010-02-17	1722	\N	19897
24811	GENERIC_DAY	1	3	2010-02-26	1726	\N	19897
24829	GENERIC_DAY	1	3	2010-03-12	1718	\N	19897
24873	GENERIC_DAY	1	3	2010-03-01	1726	\N	19897
45822	GENERIC_DAY	6	1	2010-01-18	37573	\N	41069
45749	GENERIC_DAY	6	0	2010-01-16	36159	\N	41069
45746	GENERIC_DAY	6	0	2010-01-19	37573	\N	41069
45740	GENERIC_DAY	6	0	2010-02-06	36159	\N	41069
45820	GENERIC_DAY	6	0	2010-02-10	40199	\N	41069
39439	GENERIC_DAY	2	2	2010-03-19	37573	\N	38600
45741	GENERIC_DAY	6	0	2010-01-28	40199	\N	41069
45730	GENERIC_DAY	6	0	2010-01-22	37573	\N	41069
45742	GENERIC_DAY	6	0	2010-02-07	36159	\N	41069
45737	GENERIC_DAY	6	0	2010-01-29	37573	\N	41069
45739	GENERIC_DAY	6	0	2010-02-09	36159	\N	41069
45733	GENERIC_DAY	6	0	2010-01-21	40199	\N	41069
45819	GENERIC_DAY	6	0	2010-02-03	36159	\N	41069
45747	GENERIC_DAY	6	0	2010-02-04	37573	\N	41069
45821	GENERIC_DAY	6	0	2010-01-12	36159	\N	41069
43093	GENERIC_DAY	10	0	2010-01-24	37573	\N	41054
43065	GENERIC_DAY	10	0	2010-02-11	37573	\N	41054
43099	GENERIC_DAY	10	0	2010-01-12	40199	\N	41054
43064	GENERIC_DAY	10	1	2010-02-03	40199	\N	41054
43058	GENERIC_DAY	10	0	2010-01-11	37573	\N	41054
43103	GENERIC_DAY	10	1	2010-01-12	36159	\N	41054
43091	GENERIC_DAY	10	0	2010-02-10	37573	\N	41054
43029	GENERIC_DAY	10	0	2010-02-08	37573	\N	41054
43073	GENERIC_DAY	10	0	2010-01-21	36159	\N	41054
43039	GENERIC_DAY	10	0	2010-01-19	36159	\N	41054
43101	GENERIC_DAY	10	1	2010-01-26	36159	\N	41054
43098	GENERIC_DAY	10	0	2010-01-31	40199	\N	41054
43092	GENERIC_DAY	10	0	2010-01-17	36159	\N	41054
43100	GENERIC_DAY	10	0	2010-01-20	36159	\N	41054
24830	GENERIC_DAY	1	2	2010-03-15	1722	\N	19897
24780	GENERIC_DAY	1	0	2010-02-13	1718	\N	19897
24806	GENERIC_DAY	1	0	2010-03-14	1718	\N	19897
24818	GENERIC_DAY	1	0	2010-03-06	1726	\N	19897
24825	GENERIC_DAY	1	2	2010-03-18	1726	\N	19897
24858	GENERIC_DAY	1	0	2010-02-20	1726	\N	19897
24878	GENERIC_DAY	1	0	2010-03-27	1726	\N	19897
24779	GENERIC_DAY	1	3	2010-02-19	1726	\N	19897
24798	GENERIC_DAY	1	4	2010-03-19	1718	\N	19897
24877	GENERIC_DAY	1	0	2010-02-14	1726	\N	19897
24797	GENERIC_DAY	1	4	2010-03-22	1718	\N	19897
24809	GENERIC_DAY	1	1	2010-02-22	1722	\N	19897
24827	GENERIC_DAY	1	2	2010-03-25	1722	\N	19897
24853	GENERIC_DAY	1	3	2010-02-15	1718	\N	19897
24815	GENERIC_DAY	1	0	2010-02-27	1722	\N	19897
24832	GENERIC_DAY	1	1	2010-02-23	1722	\N	19897
24784	GENERIC_DAY	1	0	2010-03-29	1726	\N	19897
24794	GENERIC_DAY	1	3	2010-03-15	1718	\N	19897
24819	GENERIC_DAY	1	2	2010-03-19	1722	\N	19897
24771	GENERIC_DAY	1	0	2010-03-20	1718	\N	19897
24824	GENERIC_DAY	1	3	2010-03-02	1726	\N	19897
24885	GENERIC_DAY	1	0	2010-02-21	1722	\N	19897
24803	GENERIC_DAY	1	1	2010-02-25	1722	\N	19897
24888	GENERIC_DAY	1	3	2010-03-09	1726	\N	19897
24840	GENERIC_DAY	1	0	2010-02-20	1718	\N	19897
24805	GENERIC_DAY	1	4	2010-03-03	1718	\N	19897
24816	GENERIC_DAY	1	3	2010-03-15	1726	\N	19897
24863	GENERIC_DAY	1	1	2010-02-15	1722	\N	19897
24410	GENERIC_DAY	4	10	2009-12-04	1727	\N	3955
24469	GENERIC_DAY	4	10	2009-11-16	1727	\N	3955
24440	GENERIC_DAY	4	10	2010-01-06	1727	\N	3955
24428	GENERIC_DAY	4	2	2010-01-23	1727	\N	3955
24434	GENERIC_DAY	4	10	2010-01-07	1727	\N	3955
24413	GENERIC_DAY	4	2	2009-12-19	1727	\N	3955
24427	GENERIC_DAY	4	2	2009-12-20	1727	\N	3955
24441	GENERIC_DAY	4	10	2009-11-17	1727	\N	3955
24476	GENERIC_DAY	4	10	2010-02-12	1727	\N	3955
24423	GENERIC_DAY	4	2	2010-02-06	1727	\N	3955
24397	GENERIC_DAY	4	2	2010-01-02	1727	\N	3955
24417	GENERIC_DAY	4	10	2009-12-31	1727	\N	3955
24408	GENERIC_DAY	4	10	2009-11-05	1727	\N	3955
24481	GENERIC_DAY	4	2	2009-12-05	1727	\N	3955
24399	GENERIC_DAY	4	10	2010-01-20	1727	\N	3955
24424	GENERIC_DAY	4	2	2010-02-20	1727	\N	3955
24400	GENERIC_DAY	4	2	2010-01-31	1727	\N	3955
24450	GENERIC_DAY	4	2	2010-01-09	1727	\N	3955
24439	GENERIC_DAY	4	10	2010-01-05	1727	\N	3955
24412	GENERIC_DAY	4	10	2009-11-20	1727	\N	3955
43079	GENERIC_DAY	10	0	2010-01-25	36159	\N	41054
24447	GENERIC_DAY	4	10	2010-02-10	1727	\N	3955
24471	GENERIC_DAY	4	10	2010-02-08	1727	\N	3955
24465	GENERIC_DAY	4	10	2009-11-18	1727	\N	3955
24478	GENERIC_DAY	4	10	2009-12-07	1727	\N	3955
24404	GENERIC_DAY	4	10	2009-11-11	1727	\N	3955
24420	GENERIC_DAY	4	10	2009-11-10	1727	\N	3955
24442	GENERIC_DAY	4	10	2010-01-21	1727	\N	3955
24396	GENERIC_DAY	4	10	2009-11-30	1727	\N	3955
24426	GENERIC_DAY	4	10	2009-12-23	1727	\N	3955
24483	GENERIC_DAY	4	2	2009-12-13	1727	\N	3955
24491	GENERIC_DAY	4	10	2010-01-22	1727	\N	3955
24458	GENERIC_DAY	4	2	2009-11-14	1727	\N	3955
24401	GENERIC_DAY	4	2	2009-11-15	1727	\N	3955
24486	GENERIC_DAY	4	10	2009-11-09	1727	\N	3955
24405	GENERIC_DAY	4	2	2009-11-22	1727	\N	3955
24429	GENERIC_DAY	4	2	2009-12-26	1727	\N	3955
24411	GENERIC_DAY	4	10	2009-12-21	1727	\N	3955
24489	GENERIC_DAY	4	10	2009-12-01	1727	\N	3955
24456	GENERIC_DAY	4	10	2010-02-05	1727	\N	3955
24472	GENERIC_DAY	4	2	2010-01-10	1727	\N	3955
24436	GENERIC_DAY	4	10	2009-12-28	1727	\N	3955
24437	GENERIC_DAY	4	10	2009-11-04	1727	\N	3955
24416	GENERIC_DAY	4	10	2009-12-09	1727	\N	3955
24467	GENERIC_DAY	4	10	2010-02-02	1727	\N	3955
24477	GENERIC_DAY	4	10	2009-12-14	1727	\N	3955
24453	GENERIC_DAY	4	10	2010-01-13	1727	\N	3955
24402	GENERIC_DAY	4	2	2009-12-27	1727	\N	3955
24480	GENERIC_DAY	4	10	2009-11-25	1727	\N	3955
24485	GENERIC_DAY	4	2	2009-12-06	1727	\N	3955
24418	GENERIC_DAY	4	10	2009-12-11	1727	\N	3955
24484	GENERIC_DAY	4	10	2009-12-24	1727	\N	3955
24457	GENERIC_DAY	4	10	2009-11-12	1727	\N	3955
24433	GENERIC_DAY	4	2	2009-11-29	1727	\N	3955
24438	GENERIC_DAY	4	10	2010-02-19	1727	\N	3955
24487	GENERIC_DAY	4	2	2010-02-14	1727	\N	3955
24414	GENERIC_DAY	4	10	2010-02-17	1727	\N	3955
24461	GENERIC_DAY	4	2	2010-01-03	1727	\N	3955
24492	GENERIC_DAY	4	10	2009-12-29	1727	\N	3955
24459	GENERIC_DAY	4	10	2010-02-01	1727	\N	3955
24398	GENERIC_DAY	4	10	2009-12-03	1727	\N	3955
24475	GENERIC_DAY	4	2	2009-11-28	1727	\N	3955
24455	GENERIC_DAY	4	10	2010-01-28	1727	\N	3955
24466	GENERIC_DAY	4	10	2009-11-26	1727	\N	3955
24446	GENERIC_DAY	4	10	2009-12-08	1727	\N	3955
24468	GENERIC_DAY	4	10	2010-01-27	1727	\N	3955
24452	GENERIC_DAY	4	10	2010-02-04	1727	\N	3955
24419	GENERIC_DAY	4	10	2010-02-24	1727	\N	3955
24460	GENERIC_DAY	4	2	2010-02-07	1727	\N	3955
24479	GENERIC_DAY	4	10	2009-11-06	1727	\N	3955
24443	GENERIC_DAY	4	10	2010-01-08	1727	\N	3955
24490	GENERIC_DAY	4	10	2010-02-16	1727	\N	3955
24454	GENERIC_DAY	4	10	2009-11-27	1727	\N	3955
24488	GENERIC_DAY	4	10	2010-02-15	1727	\N	3955
24435	GENERIC_DAY	4	10	2010-01-26	1727	\N	3955
24445	GENERIC_DAY	4	2	2009-12-25	1727	\N	3955
24506	GENERIC_DAY	4	10	2009-12-16	1727	\N	3955
24482	GENERIC_DAY	4	10	2010-02-22	1727	\N	3955
24403	GENERIC_DAY	4	10	2010-02-26	1727	\N	3955
24470	GENERIC_DAY	4	2	2010-01-16	1727	\N	3955
24432	GENERIC_DAY	4	10	2010-02-09	1727	\N	3955
24430	GENERIC_DAY	4	2	2009-11-08	1727	\N	3955
24409	GENERIC_DAY	4	10	2010-02-18	1727	\N	3955
24495	GENERIC_DAY	4	10	2010-01-15	1727	\N	3955
24444	GENERIC_DAY	4	10	2009-12-30	1727	\N	3955
24449	GENERIC_DAY	4	10	2009-11-23	1727	\N	3955
24422	GENERIC_DAY	4	10	2010-02-03	1727	\N	3955
24407	GENERIC_DAY	4	2	2010-01-30	1727	\N	3955
24462	GENERIC_DAY	4	10	2010-02-23	1727	\N	3955
24474	GENERIC_DAY	4	10	2010-02-25	1727	\N	3955
24448	GENERIC_DAY	4	10	2009-12-02	1727	\N	3955
24503	GENERIC_DAY	4	10	2009-12-22	1727	\N	3955
24421	GENERIC_DAY	4	2	2010-01-17	1727	\N	3955
24406	GENERIC_DAY	4	2	2010-02-13	1727	\N	3955
24415	GENERIC_DAY	4	11	2009-11-02	1727	\N	3955
24507	GENERIC_DAY	4	2	2010-02-21	1727	\N	3955
24473	GENERIC_DAY	4	10	2009-11-13	1727	\N	3955
24511	GENERIC_DAY	4	10	2010-01-12	1727	\N	3955
24451	GENERIC_DAY	4	10	2009-11-24	1727	\N	3955
24425	GENERIC_DAY	4	10	2010-01-04	1727	\N	3955
24431	GENERIC_DAY	4	10	2009-12-18	1727	\N	3955
24463	GENERIC_DAY	4	2	2010-01-24	1727	\N	3955
24464	GENERIC_DAY	4	10	2010-01-29	1727	\N	3955
43026	GENERIC_DAY	10	0	2010-02-09	37573	\N	41054
43025	GENERIC_DAY	10	1	2010-01-15	37573	\N	41054
43068	GENERIC_DAY	10	0	2010-01-13	37573	\N	41054
43080	GENERIC_DAY	10	0	2010-02-07	37573	\N	41054
43047	GENERIC_DAY	10	0	2010-01-14	40199	\N	41054
43048	GENERIC_DAY	10	1	2010-01-29	40199	\N	41054
43057	GENERIC_DAY	10	0	2010-01-15	40199	\N	41054
43035	GENERIC_DAY	10	0	2010-02-01	40199	\N	41054
43049	GENERIC_DAY	10	0	2010-01-18	40199	\N	41054
43094	GENERIC_DAY	10	0	2010-01-24	36159	\N	41054
43041	GENERIC_DAY	10	0	2010-01-27	36159	\N	41054
43069	GENERIC_DAY	10	0	2010-01-17	37573	\N	41054
43056	GENERIC_DAY	10	0	2010-02-06	36159	\N	41054
43033	GENERIC_DAY	10	0	2010-01-20	37573	\N	41054
43028	GENERIC_DAY	10	1	2010-02-08	40199	\N	41054
43071	GENERIC_DAY	10	0	2010-01-16	40199	\N	41054
43046	GENERIC_DAY	10	0	2010-02-01	36159	\N	41054
43095	GENERIC_DAY	10	0	2010-01-28	36159	\N	41054
43081	GENERIC_DAY	10	0	2010-02-09	36159	\N	41054
43042	GENERIC_DAY	10	0	2010-01-26	37573	\N	41054
43036	GENERIC_DAY	10	1	2010-01-22	37573	\N	41054
43043	GENERIC_DAY	10	0	2010-01-26	40199	\N	41054
43076	GENERIC_DAY	10	1	2010-02-04	40199	\N	41054
43040	GENERIC_DAY	10	1	2010-02-02	40199	\N	41054
43022	GENERIC_DAY	10	0	2010-02-10	36159	\N	41054
43032	GENERIC_DAY	10	0	2010-02-04	37573	\N	41054
43084	GENERIC_DAY	10	0	2010-01-14	36159	\N	41054
43075	GENERIC_DAY	10	0	2010-02-11	36159	\N	41054
43030	GENERIC_DAY	10	0	2010-01-29	36159	\N	41054
43045	GENERIC_DAY	10	0	2010-01-27	37573	\N	41054
43110	GENERIC_DAY	10	0	2010-02-06	37573	\N	41054
43112	GENERIC_DAY	10	0	2010-01-16	37573	\N	41054
43070	GENERIC_DAY	10	0	2010-02-03	37573	\N	41054
43114	GENERIC_DAY	10	0	2010-01-30	36159	\N	41054
43021	GENERIC_DAY	10	0	2010-01-28	37573	\N	41054
43105	GENERIC_DAY	10	1	2010-01-14	37573	\N	41054
43051	GENERIC_DAY	10	0	2010-01-13	36159	\N	41054
31156	GENERIC_DAY	1	8	2010-04-06	1724	\N	28093
31158	GENERIC_DAY	1	0	2010-02-06	1724	\N	28093
31149	GENERIC_DAY	1	0	2010-04-04	1724	\N	28093
31152	GENERIC_DAY	1	8	2010-03-16	1724	\N	28093
31151	GENERIC_DAY	1	9	2010-01-19	1724	\N	28093
31157	GENERIC_DAY	1	8	2010-02-26	1724	\N	28093
31219	GENERIC_DAY	1	8	2010-01-29	1724	\N	28093
31161	GENERIC_DAY	1	8	2010-03-12	1724	\N	28093
31187	GENERIC_DAY	1	8	2010-04-05	1724	\N	28093
31193	GENERIC_DAY	1	9	2010-01-26	1724	\N	28093
31177	GENERIC_DAY	1	0	2010-03-07	1724	\N	28093
31154	GENERIC_DAY	1	8	2010-02-18	1724	\N	28093
31211	GENERIC_DAY	1	8	2010-03-05	1724	\N	28093
31199	GENERIC_DAY	1	0	2010-02-27	1724	\N	28093
31230	GENERIC_DAY	1	8	2010-03-25	1724	\N	28093
31214	GENERIC_DAY	1	0	2010-03-13	1724	\N	28093
31223	GENERIC_DAY	1	8	2010-02-05	1724	\N	28093
31206	GENERIC_DAY	1	8	2010-04-08	1724	\N	28093
31200	GENERIC_DAY	1	8	2010-03-26	1724	\N	28093
31208	GENERIC_DAY	1	0	2010-02-07	1724	\N	28093
31226	GENERIC_DAY	1	0	2010-03-06	1724	\N	28093
31180	GENERIC_DAY	1	9	2010-01-27	1724	\N	28093
31168	GENERIC_DAY	1	8	2010-02-22	1724	\N	28093
31160	GENERIC_DAY	1	1	2010-01-16	1724	\N	28093
31203	GENERIC_DAY	1	8	2010-04-02	1724	\N	28093
31174	GENERIC_DAY	1	8	2010-02-09	1724	\N	28093
31188	GENERIC_DAY	1	8	2010-02-17	1724	\N	28093
31150	GENERIC_DAY	1	8	2010-03-19	1724	\N	28093
31186	GENERIC_DAY	1	1	2010-01-23	1724	\N	28093
31213	GENERIC_DAY	1	8	2010-02-16	1724	\N	28093
31227	GENERIC_DAY	1	8	2010-02-24	1724	\N	28093
31184	GENERIC_DAY	1	8	2010-02-03	1724	\N	28093
31179	GENERIC_DAY	1	8	2010-02-10	1724	\N	28093
31176	GENERIC_DAY	1	0	2010-04-03	1724	\N	28093
31183	GENERIC_DAY	1	8	2010-03-11	1724	\N	28093
31148	GENERIC_DAY	1	9	2010-01-25	1724	\N	28093
31166	GENERIC_DAY	1	8	2010-04-01	1724	\N	28093
31155	GENERIC_DAY	1	0	2010-03-28	1724	\N	28093
31192	GENERIC_DAY	1	0	2010-01-30	1724	\N	28093
31201	GENERIC_DAY	1	8	2010-03-02	1724	\N	28093
31220	GENERIC_DAY	1	8	2010-03-22	1724	\N	28093
31159	GENERIC_DAY	1	9	2010-01-20	1724	\N	28093
31212	GENERIC_DAY	1	8	2010-03-30	1724	\N	28093
31202	GENERIC_DAY	1	8	2010-03-10	1724	\N	28093
31181	GENERIC_DAY	1	8	2010-02-12	1724	\N	28093
31198	GENERIC_DAY	1	8	2010-04-12	1724	\N	28093
31173	GENERIC_DAY	1	8	2010-03-01	1724	\N	28093
31178	GENERIC_DAY	1	0	2010-02-14	1724	\N	28093
31191	GENERIC_DAY	1	8	2010-02-25	1724	\N	28093
31209	GENERIC_DAY	1	0	2010-03-20	1724	\N	28093
31216	GENERIC_DAY	1	8	2010-03-24	1724	\N	28093
31205	GENERIC_DAY	1	8	2010-02-23	1724	\N	28093
31195	GENERIC_DAY	1	0	2010-03-21	1724	\N	28093
31147	GENERIC_DAY	1	0	2010-02-21	1724	\N	28093
31170	GENERIC_DAY	1	0	2010-04-10	1724	\N	28093
31171	GENERIC_DAY	1	8	2010-02-04	1724	\N	28093
31215	GENERIC_DAY	1	0	2010-01-31	1724	\N	28093
31225	GENERIC_DAY	1	8	2010-03-31	1724	\N	28093
31210	GENERIC_DAY	1	0	2010-03-14	1724	\N	28093
31197	GENERIC_DAY	1	8	2010-03-18	1724	\N	28093
31165	GENERIC_DAY	1	8	2010-02-11	1724	\N	28093
31182	GENERIC_DAY	1	1	2010-01-17	1724	\N	28093
31172	GENERIC_DAY	1	8	2010-02-02	1724	\N	28093
31162	GENERIC_DAY	1	8	2010-01-28	1724	\N	28093
31196	GENERIC_DAY	1	8	2010-02-19	1724	\N	28093
31218	GENERIC_DAY	1	0	2010-02-13	1724	\N	28093
31224	GENERIC_DAY	1	9	2010-01-21	1724	\N	28093
31204	GENERIC_DAY	1	8	2010-04-07	1724	\N	28093
31231	GENERIC_DAY	1	8	2010-03-03	1724	\N	28093
31190	GENERIC_DAY	1	8	2010-03-23	1724	\N	28093
31222	GENERIC_DAY	1	0	2010-04-11	1724	\N	28093
31228	GENERIC_DAY	1	8	2010-02-15	1724	\N	28093
31153	GENERIC_DAY	1	8	2010-02-08	1724	\N	28093
31164	GENERIC_DAY	1	1	2010-01-24	1724	\N	28093
39440	GENERIC_DAY	1	0	2010-02-11	37573	\N	38601
39441	GENERIC_DAY	1	0	2010-03-19	36159	\N	38601
39442	GENERIC_DAY	1	0	2010-03-07	36159	\N	38601
39443	GENERIC_DAY	1	0	2010-02-22	36159	\N	38601
43053	GENERIC_DAY	10	0	2010-02-04	36159	\N	41054
43031	GENERIC_DAY	10	0	2010-01-12	37573	\N	41054
43024	GENERIC_DAY	10	0	2010-01-30	40199	\N	41054
43060	GENERIC_DAY	10	1	2010-02-01	37573	\N	41054
43059	GENERIC_DAY	10	1	2010-01-18	36159	\N	41054
43090	GENERIC_DAY	10	0	2010-01-16	36159	\N	41054
43037	GENERIC_DAY	10	0	2010-02-08	36159	\N	41054
43085	GENERIC_DAY	10	1	2010-02-05	40199	\N	41054
43066	GENERIC_DAY	10	0	2010-01-24	40199	\N	41054
43034	GENERIC_DAY	10	0	2010-02-03	36159	\N	41054
43054	GENERIC_DAY	10	0	2010-02-11	40199	\N	41054
43097	GENERIC_DAY	10	0	2010-02-09	40199	\N	41054
43038	GENERIC_DAY	10	0	2010-02-05	37573	\N	41054
43027	GENERIC_DAY	10	0	2010-01-23	40199	\N	41054
43096	GENERIC_DAY	10	0	2010-01-23	37573	\N	41054
43023	GENERIC_DAY	10	0	2010-01-23	36159	\N	41054
43067	GENERIC_DAY	10	1	2010-01-25	40199	\N	41054
43083	GENERIC_DAY	10	0	2010-01-21	40199	\N	41054
43102	GENERIC_DAY	10	1	2010-01-13	40199	\N	41054
43044	GENERIC_DAY	10	0	2010-02-05	36159	\N	41054
27210	GENERIC_DAY	1	3	2009-12-07	1726	\N	3940
27211	GENERIC_DAY	1	2	2009-12-18	1726	\N	3940
27212	GENERIC_DAY	1	3	2009-12-14	1722	\N	3940
27213	GENERIC_DAY	1	3	2009-12-09	1726	\N	3940
27214	GENERIC_DAY	1	0	2009-12-12	1718	\N	3940
27215	GENERIC_DAY	1	0	2009-12-19	1718	\N	3940
27216	GENERIC_DAY	1	2	2009-12-22	1718	\N	3940
27217	GENERIC_DAY	1	4	2009-12-18	1722	\N	3940
27218	GENERIC_DAY	1	2	2009-12-17	1722	\N	3940
27219	GENERIC_DAY	1	0	2009-12-19	1722	\N	3940
27220	GENERIC_DAY	1	3	2009-12-15	1726	\N	3940
27221	GENERIC_DAY	1	0	2009-12-13	1722	\N	3940
27222	GENERIC_DAY	1	2	2009-12-11	1718	\N	3940
27223	GENERIC_DAY	1	3	2009-12-14	1726	\N	3940
27224	GENERIC_DAY	1	3	2009-12-21	1722	\N	3940
27225	GENERIC_DAY	1	2	2009-12-23	1722	\N	3940
27226	GENERIC_DAY	1	0	2009-12-12	1726	\N	3940
27227	GENERIC_DAY	1	2	2009-12-09	1722	\N	3940
27228	GENERIC_DAY	1	3	2009-12-17	1718	\N	3940
27229	GENERIC_DAY	1	0	2009-12-20	1722	\N	3940
27230	GENERIC_DAY	1	2	2009-12-16	1718	\N	3940
27231	GENERIC_DAY	1	3	2009-12-17	1726	\N	3940
27232	GENERIC_DAY	1	2	2009-12-10	1718	\N	3940
27233	GENERIC_DAY	1	2	2009-12-07	1718	\N	3940
27234	GENERIC_DAY	1	2	2009-12-15	1718	\N	3940
27235	GENERIC_DAY	1	0	2009-12-20	1726	\N	3940
27236	GENERIC_DAY	1	2	2009-12-21	1718	\N	3940
27237	GENERIC_DAY	1	2	2009-12-18	1718	\N	3940
27238	GENERIC_DAY	1	3	2009-12-07	1722	\N	3940
27239	GENERIC_DAY	1	3	2009-12-22	1722	\N	3940
27240	GENERIC_DAY	1	3	2009-12-10	1722	\N	3940
27241	GENERIC_DAY	1	3	2009-12-11	1722	\N	3940
27242	GENERIC_DAY	1	0	2009-12-20	1718	\N	3940
27243	GENERIC_DAY	1	0	2009-12-19	1726	\N	3940
27244	GENERIC_DAY	1	3	2009-12-22	1726	\N	3940
27245	GENERIC_DAY	1	3	2009-12-11	1726	\N	3940
27246	GENERIC_DAY	1	2	2009-12-14	1718	\N	3940
27247	GENERIC_DAY	1	1	2009-12-23	1718	\N	3940
27248	GENERIC_DAY	1	0	2009-12-13	1726	\N	3940
27249	GENERIC_DAY	1	3	2009-12-21	1726	\N	3940
27250	GENERIC_DAY	1	3	2009-12-16	1722	\N	3940
27251	GENERIC_DAY	1	0	2009-12-12	1722	\N	3940
27252	GENERIC_DAY	1	3	2009-12-08	1726	\N	3940
27253	GENERIC_DAY	1	3	2009-12-15	1722	\N	3940
27254	GENERIC_DAY	1	0	2010-01-02	1718	\N	19901
27255	GENERIC_DAY	1	0	2010-01-31	1718	\N	19901
27256	GENERIC_DAY	1	3	2010-01-27	1718	\N	19901
27257	GENERIC_DAY	1	3	2010-02-12	1722	\N	19901
27258	GENERIC_DAY	1	3	2010-01-19	1718	\N	19901
27259	GENERIC_DAY	1	3	2010-01-22	1726	\N	19901
27260	GENERIC_DAY	1	0	2010-01-31	1722	\N	19901
27261	GENERIC_DAY	1	3	2010-02-09	1726	\N	19901
27262	GENERIC_DAY	1	3	2010-01-22	1718	\N	19901
27263	GENERIC_DAY	1	1	2010-02-10	1722	\N	19901
27264	GENERIC_DAY	1	2	2010-01-26	1718	\N	19901
27265	GENERIC_DAY	1	3	2010-01-07	1718	\N	19901
27266	GENERIC_DAY	1	4	2010-01-13	1718	\N	19901
27267	GENERIC_DAY	1	2	2010-01-18	1722	\N	19901
27268	GENERIC_DAY	1	0	2010-02-07	1718	\N	19901
27269	GENERIC_DAY	1	2	2010-01-28	1722	\N	19901
27270	GENERIC_DAY	1	3	2010-01-26	1726	\N	19901
27271	GENERIC_DAY	1	1	2010-02-17	1718	\N	19901
27272	GENERIC_DAY	1	2	2010-01-14	1722	\N	19901
27273	GENERIC_DAY	1	3	2010-01-04	1718	\N	19901
27274	GENERIC_DAY	1	3	2010-01-29	1718	\N	19901
27275	GENERIC_DAY	1	0	2010-01-03	1726	\N	19901
27276	GENERIC_DAY	1	2	2010-01-11	1722	\N	19901
27277	GENERIC_DAY	1	2	2010-02-17	1726	\N	19901
27278	GENERIC_DAY	1	0	2010-02-06	1726	\N	19901
27279	GENERIC_DAY	1	4	2010-01-11	1718	\N	19901
27280	GENERIC_DAY	1	3	2010-01-07	1726	\N	19901
27281	GENERIC_DAY	1	3	2009-12-28	1726	\N	19901
27282	GENERIC_DAY	1	3	2010-02-01	1726	\N	19901
27283	GENERIC_DAY	1	3	2010-02-15	1726	\N	19901
27284	GENERIC_DAY	1	3	2010-01-21	1726	\N	19901
27285	GENERIC_DAY	1	2	2009-12-28	1718	\N	19901
27286	GENERIC_DAY	1	1	2010-02-08	1722	\N	19901
27287	GENERIC_DAY	1	0	2010-02-07	1726	\N	19901
27288	GENERIC_DAY	1	2	2009-12-29	1718	\N	19901
27289	GENERIC_DAY	1	3	2010-02-11	1726	\N	19901
27290	GENERIC_DAY	1	2	2010-02-16	1718	\N	19901
27291	GENERIC_DAY	1	3	2010-01-15	1718	\N	19901
27292	GENERIC_DAY	1	2	2010-01-05	1718	\N	19901
27293	GENERIC_DAY	1	3	2010-01-25	1726	\N	19901
27294	GENERIC_DAY	1	3	2010-02-16	1722	\N	19901
27295	GENERIC_DAY	1	3	2010-02-03	1726	\N	19901
27296	GENERIC_DAY	1	4	2010-02-11	1718	\N	19901
27297	GENERIC_DAY	1	3	2009-12-31	1722	\N	19901
27298	GENERIC_DAY	1	3	2010-02-08	1726	\N	19901
25510	GENERIC_DAY	3	7	2010-04-22	7272	\N	24143
25511	GENERIC_DAY	3	0	2010-03-14	7272	\N	24143
25512	GENERIC_DAY	3	7	2010-03-19	7272	\N	24143
27299	GENERIC_DAY	1	2	2010-01-21	1722	\N	19901
27300	GENERIC_DAY	1	0	2010-01-17	1726	\N	19901
27301	GENERIC_DAY	1	0	2010-01-03	1722	\N	19901
25513	GENERIC_DAY	3	0	2010-04-11	7272	\N	24143
25514	GENERIC_DAY	3	0	2010-04-04	7272	\N	24143
25515	GENERIC_DAY	3	0	2010-04-17	7272	\N	24143
25516	GENERIC_DAY	3	7	2010-03-24	7272	\N	24143
25517	GENERIC_DAY	3	7	2010-03-29	7272	\N	24143
25518	GENERIC_DAY	3	0	2010-04-03	7272	\N	24143
25519	GENERIC_DAY	3	0	2010-02-28	7272	\N	24143
25520	GENERIC_DAY	3	7	2010-03-03	7272	\N	24143
25521	GENERIC_DAY	3	7	2010-04-16	7272	\N	24143
25522	GENERIC_DAY	3	7	2010-04-07	7272	\N	24143
25523	GENERIC_DAY	3	0	2010-03-21	7272	\N	24143
15942	GENERIC_DAY	0	2	2010-04-22	1722	\N	3984
15943	GENERIC_DAY	0	2	2010-04-16	1722	\N	3984
15944	GENERIC_DAY	0	2	2010-04-18	1726	\N	3984
15945	GENERIC_DAY	0	2	2010-04-11	1726	\N	3984
15946	GENERIC_DAY	0	1	2010-04-17	1718	\N	3984
15947	GENERIC_DAY	0	2	2010-04-10	1722	\N	3984
15948	GENERIC_DAY	0	2	2010-04-06	1722	\N	3984
15949	GENERIC_DAY	0	2	2010-04-18	1722	\N	3984
15950	GENERIC_DAY	0	2	2010-04-11	1718	\N	3984
15951	GENERIC_DAY	0	2	2010-04-14	1726	\N	3984
15952	GENERIC_DAY	0	2	2010-04-10	1726	\N	3984
15953	GENERIC_DAY	0	1	2010-04-22	1718	\N	3984
15954	GENERIC_DAY	0	2	2010-04-17	1726	\N	3984
15955	GENERIC_DAY	0	2	2010-04-09	1718	\N	3984
15956	GENERIC_DAY	0	2	2010-04-17	1722	\N	3984
15957	GENERIC_DAY	0	2	2010-04-20	1722	\N	3984
15958	GENERIC_DAY	0	1	2010-04-19	1718	\N	3984
15959	GENERIC_DAY	0	2	2010-04-22	1726	\N	3984
15960	GENERIC_DAY	0	2	2010-04-14	1722	\N	3984
15961	GENERIC_DAY	0	2	2010-04-13	1726	\N	3984
15962	GENERIC_DAY	0	2	2010-04-07	1722	\N	3984
15963	GENERIC_DAY	0	2	2010-04-15	1722	\N	3984
15964	GENERIC_DAY	0	2	2010-04-06	1726	\N	3984
15965	GENERIC_DAY	0	1	2010-04-18	1718	\N	3984
15966	GENERIC_DAY	0	1	2010-04-16	1718	\N	3984
15967	GENERIC_DAY	0	2	2010-04-06	1718	\N	3984
15968	GENERIC_DAY	0	1	2010-04-20	1718	\N	3984
15969	GENERIC_DAY	0	2	2010-04-05	1722	\N	3984
15970	GENERIC_DAY	0	2	2010-04-13	1722	\N	3984
15971	GENERIC_DAY	0	2	2010-04-08	1718	\N	3984
15972	GENERIC_DAY	0	2	2010-04-10	1718	\N	3984
15973	GENERIC_DAY	0	2	2010-04-16	1726	\N	3984
15974	GENERIC_DAY	0	1	2010-04-21	1718	\N	3984
15975	GENERIC_DAY	0	2	2010-04-11	1722	\N	3984
15976	GENERIC_DAY	0	2	2010-04-15	1726	\N	3984
15977	GENERIC_DAY	0	2	2010-04-12	1718	\N	3984
15978	GENERIC_DAY	0	2	2010-04-19	1722	\N	3984
15979	GENERIC_DAY	0	2	2010-04-12	1726	\N	3984
15980	GENERIC_DAY	0	2	2010-04-05	1726	\N	3984
15981	GENERIC_DAY	0	2	2010-04-20	1726	\N	3984
15982	GENERIC_DAY	0	2	2010-04-19	1726	\N	3984
15983	GENERIC_DAY	0	2	2010-04-21	1722	\N	3984
15984	GENERIC_DAY	0	2	2010-04-21	1726	\N	3984
15985	GENERIC_DAY	0	2	2010-04-09	1722	\N	3984
15986	GENERIC_DAY	0	2	2010-04-14	1718	\N	3984
15987	GENERIC_DAY	0	2	2010-04-07	1718	\N	3984
15988	GENERIC_DAY	0	2	2010-04-13	1718	\N	3984
15989	GENERIC_DAY	0	2	2010-04-12	1722	\N	3984
15990	GENERIC_DAY	0	2	2010-04-09	1726	\N	3984
15991	GENERIC_DAY	0	2	2010-04-05	1718	\N	3984
15992	GENERIC_DAY	0	2	2010-04-08	1722	\N	3984
15993	GENERIC_DAY	0	2	2010-04-07	1726	\N	3984
15994	GENERIC_DAY	0	2	2010-04-08	1726	\N	3984
15995	GENERIC_DAY	0	1	2010-04-15	1718	\N	3984
25524	GENERIC_DAY	3	7	2010-04-23	7272	\N	24143
25525	GENERIC_DAY	3	7	2010-03-11	7272	\N	24143
25526	GENERIC_DAY	3	7	2010-03-02	7272	\N	24143
25527	GENERIC_DAY	3	7	2010-04-14	7272	\N	24143
25528	GENERIC_DAY	3	7	2010-03-10	7272	\N	24143
25529	GENERIC_DAY	3	7	2010-03-16	7272	\N	24143
25530	GENERIC_DAY	3	0	2010-03-28	7272	\N	24143
25531	GENERIC_DAY	3	7	2010-03-22	7272	\N	24143
25532	GENERIC_DAY	3	7	2010-03-05	7272	\N	24143
25533	GENERIC_DAY	3	7	2010-04-05	7272	\N	24143
25534	GENERIC_DAY	3	7	2010-04-12	7272	\N	24143
25535	GENERIC_DAY	3	7	2010-04-27	7272	\N	24143
25536	GENERIC_DAY	3	7	2010-03-26	7272	\N	24143
25537	GENERIC_DAY	3	7	2010-03-25	7272	\N	24143
25538	GENERIC_DAY	3	0	2010-03-07	7272	\N	24143
25539	GENERIC_DAY	3	0	2010-03-20	7272	\N	24143
25540	GENERIC_DAY	3	7	2010-04-06	7272	\N	24143
25541	GENERIC_DAY	3	7	2010-03-09	7272	\N	24143
25542	GENERIC_DAY	3	7	2010-04-26	7272	\N	24143
25543	GENERIC_DAY	3	7	2010-04-15	7272	\N	24143
25544	GENERIC_DAY	3	7	2010-03-23	7272	\N	24143
25545	GENERIC_DAY	3	0	2010-04-25	7272	\N	24143
25546	GENERIC_DAY	3	7	2010-04-21	7272	\N	24143
25547	GENERIC_DAY	3	0	2010-03-13	7272	\N	24143
25548	GENERIC_DAY	3	7	2010-04-08	7272	\N	24143
25549	GENERIC_DAY	3	0	2010-04-18	7272	\N	24143
25550	GENERIC_DAY	3	7	2010-03-15	7272	\N	24143
25551	GENERIC_DAY	3	7	2010-04-19	7272	\N	24143
25552	GENERIC_DAY	3	7	2010-03-04	7272	\N	24143
25553	GENERIC_DAY	3	7	2010-04-13	7272	\N	24143
25554	GENERIC_DAY	3	7	2010-03-30	7272	\N	24143
25555	GENERIC_DAY	3	7	2010-04-02	7272	\N	24143
25556	GENERIC_DAY	3	7	2010-03-18	7272	\N	24143
25557	GENERIC_DAY	3	7	2010-03-31	7272	\N	24143
25558	GENERIC_DAY	3	7	2010-03-08	7272	\N	24143
25559	GENERIC_DAY	3	6	2010-04-28	7272	\N	24143
25560	GENERIC_DAY	3	7	2010-04-01	7272	\N	24143
25561	GENERIC_DAY	3	0	2010-02-27	7272	\N	24143
16035	GENERIC_DAY	0	2	2010-03-04	1726	\N	8589
16036	GENERIC_DAY	0	4	2010-02-15	1722	\N	8589
16037	GENERIC_DAY	0	2	2010-02-10	1726	\N	8589
16038	GENERIC_DAY	0	3	2010-03-19	1722	\N	8589
16039	GENERIC_DAY	0	3	2010-03-13	1722	\N	8589
16040	GENERIC_DAY	0	2	2010-02-22	1726	\N	8589
16041	GENERIC_DAY	0	3	2010-03-15	1722	\N	8589
16042	GENERIC_DAY	0	3	2010-03-20	1722	\N	8589
16043	GENERIC_DAY	0	3	2010-03-16	1722	\N	8589
16044	GENERIC_DAY	0	3	2010-03-24	1726	\N	8589
16045	GENERIC_DAY	0	3	2010-03-10	1722	\N	8589
16046	GENERIC_DAY	0	2	2010-03-09	1726	\N	8589
16047	GENERIC_DAY	0	2	2010-03-08	1726	\N	8589
16048	GENERIC_DAY	0	4	2010-02-22	1722	\N	8589
16049	GENERIC_DAY	0	3	2010-03-07	1722	\N	8589
16050	GENERIC_DAY	0	2	2010-03-05	1726	\N	8589
16051	GENERIC_DAY	0	3	2010-02-18	1718	\N	8589
16052	GENERIC_DAY	0	5	2010-02-14	1722	\N	8589
16053	GENERIC_DAY	0	2	2010-02-26	1726	\N	8589
16054	GENERIC_DAY	0	2	2010-02-13	1726	\N	8589
16055	GENERIC_DAY	0	4	2010-02-19	1722	\N	8589
16056	GENERIC_DAY	0	2	2010-03-03	1726	\N	8589
16057	GENERIC_DAY	0	2	2010-02-19	1718	\N	8589
16058	GENERIC_DAY	0	2	2010-02-25	1718	\N	8589
16059	GENERIC_DAY	0	2	2010-02-21	1718	\N	8589
16060	GENERIC_DAY	0	2	2010-02-24	1718	\N	8589
16061	GENERIC_DAY	0	2	2010-03-17	1726	\N	8589
16062	GENERIC_DAY	0	2	2010-02-11	1718	\N	8589
16063	GENERIC_DAY	0	2	2010-03-24	1718	\N	8589
16064	GENERIC_DAY	0	2	2010-02-13	1718	\N	8589
16065	GENERIC_DAY	0	3	2010-03-06	1718	\N	8589
16066	GENERIC_DAY	0	4	2010-03-02	1722	\N	8589
16067	GENERIC_DAY	0	2	2010-03-25	1718	\N	8589
16068	GENERIC_DAY	0	2	2010-03-14	1726	\N	8589
16069	GENERIC_DAY	0	3	2010-03-23	1726	\N	8589
16070	GENERIC_DAY	0	3	2010-03-05	1722	\N	8589
16071	GENERIC_DAY	0	3	2010-03-20	1726	\N	8589
16072	GENERIC_DAY	0	3	2010-03-11	1722	\N	8589
16073	GENERIC_DAY	0	2	2010-02-25	1726	\N	8589
16074	GENERIC_DAY	0	3	2010-03-14	1718	\N	8589
16075	GENERIC_DAY	0	4	2010-02-13	1722	\N	8589
16076	GENERIC_DAY	0	4	2010-02-08	1722	\N	8589
16077	GENERIC_DAY	0	1	2010-02-14	1726	\N	8589
16078	GENERIC_DAY	0	4	2010-02-28	1722	\N	8589
16079	GENERIC_DAY	0	4	2010-02-26	1722	\N	8589
16080	GENERIC_DAY	0	2	2010-02-09	1718	\N	8589
16081	GENERIC_DAY	0	4	2010-02-25	1722	\N	8589
16082	GENERIC_DAY	0	1	2010-02-18	1726	\N	8589
16083	GENERIC_DAY	0	3	2010-03-16	1718	\N	8589
16084	GENERIC_DAY	0	3	2010-03-05	1718	\N	8589
16085	GENERIC_DAY	0	1	2010-02-16	1726	\N	8589
16086	GENERIC_DAY	0	2	2010-02-27	1726	\N	8589
16087	GENERIC_DAY	0	3	2010-03-04	1722	\N	8589
16088	GENERIC_DAY	0	2	2010-02-23	1726	\N	8589
16089	GENERIC_DAY	0	2	2010-03-12	1726	\N	8589
16090	GENERIC_DAY	0	3	2010-03-17	1718	\N	8589
16091	GENERIC_DAY	0	3	2010-03-13	1718	\N	8589
16092	GENERIC_DAY	0	2	2010-02-08	1718	\N	8589
16093	GENERIC_DAY	0	4	2010-02-21	1722	\N	8589
16094	GENERIC_DAY	0	2	2010-02-19	1726	\N	8589
16095	GENERIC_DAY	0	2	2010-02-26	1718	\N	8589
16096	GENERIC_DAY	0	4	2010-02-18	1722	\N	8589
16097	GENERIC_DAY	0	2	2010-02-11	1726	\N	8589
16098	GENERIC_DAY	0	2	2010-02-09	1726	\N	8589
16099	GENERIC_DAY	0	3	2010-03-14	1722	\N	8589
16100	GENERIC_DAY	0	1	2010-02-17	1726	\N	8589
16101	GENERIC_DAY	0	2	2010-02-12	1718	\N	8589
16102	GENERIC_DAY	0	2	2010-03-11	1726	\N	8589
16103	GENERIC_DAY	0	3	2010-03-24	1722	\N	8589
16104	GENERIC_DAY	0	4	2010-02-12	1722	\N	8589
16105	GENERIC_DAY	0	2	2010-02-07	1726	\N	8589
16106	GENERIC_DAY	0	3	2010-03-15	1718	\N	8589
16107	GENERIC_DAY	0	4	2010-02-11	1722	\N	8589
16108	GENERIC_DAY	0	2	2010-03-15	1726	\N	8589
16109	GENERIC_DAY	0	2	2010-03-19	1718	\N	8589
16110	GENERIC_DAY	0	2	2010-03-03	1718	\N	8589
16111	GENERIC_DAY	0	4	2010-02-20	1722	\N	8589
16112	GENERIC_DAY	0	2	2010-02-20	1726	\N	8589
16113	GENERIC_DAY	0	2	2010-02-07	1718	\N	8589
16114	GENERIC_DAY	0	3	2010-03-06	1722	\N	8589
16115	GENERIC_DAY	0	4	2010-02-24	1722	\N	8589
16116	GENERIC_DAY	0	2	2010-02-10	1718	\N	8589
16117	GENERIC_DAY	0	3	2010-03-18	1726	\N	8589
16118	GENERIC_DAY	0	3	2010-03-08	1722	\N	8589
16119	GENERIC_DAY	0	4	2010-02-09	1722	\N	8589
16120	GENERIC_DAY	0	3	2010-03-27	1726	\N	8589
16121	GENERIC_DAY	0	3	2010-03-11	1718	\N	8589
16122	GENERIC_DAY	0	3	2010-03-23	1722	\N	8589
16123	GENERIC_DAY	0	2	2010-03-21	1718	\N	8589
25562	GENERIC_DAY	3	7	2010-04-09	7272	\N	24143
25563	GENERIC_DAY	3	0	2010-03-06	7272	\N	24143
25564	GENERIC_DAY	3	7	2010-03-01	7272	\N	24143
25565	GENERIC_DAY	3	7	2010-03-17	7272	\N	24143
25566	GENERIC_DAY	3	7	2010-04-20	7272	\N	24143
25567	GENERIC_DAY	3	0	2010-03-27	7272	\N	24143
25568	GENERIC_DAY	3	7	2010-03-12	7272	\N	24143
25569	GENERIC_DAY	3	0	2010-04-24	7272	\N	24143
25570	GENERIC_DAY	3	0	2010-04-10	7272	\N	24143
27302	GENERIC_DAY	1	2	2010-01-15	1722	\N	19901
27303	GENERIC_DAY	1	0	2009-12-26	1718	\N	19901
27304	GENERIC_DAY	1	0	2010-02-14	1718	\N	19901
27305	GENERIC_DAY	1	2	2010-02-05	1722	\N	19901
16124	GENERIC_DAY	0	2	2010-03-18	1722	\N	8589
16125	GENERIC_DAY	0	3	2010-03-25	1726	\N	8589
16126	GENERIC_DAY	0	2	2010-03-06	1726	\N	8589
16127	GENERIC_DAY	0	2	2010-03-02	1726	\N	8589
16128	GENERIC_DAY	0	2	2010-03-27	1718	\N	8589
16129	GENERIC_DAY	0	4	2010-02-17	1722	\N	8589
16130	GENERIC_DAY	0	4	2010-02-10	1722	\N	8589
16131	GENERIC_DAY	0	2	2010-02-23	1718	\N	8589
16132	GENERIC_DAY	0	2	2010-02-22	1718	\N	8589
16133	GENERIC_DAY	0	3	2010-03-17	1722	\N	8589
16134	GENERIC_DAY	0	3	2010-03-28	1726	\N	8589
16135	GENERIC_DAY	0	2	2010-03-23	1718	\N	8589
16136	GENERIC_DAY	0	3	2010-03-27	1722	\N	8589
16137	GENERIC_DAY	0	1	2010-02-15	1726	\N	8589
16138	GENERIC_DAY	0	3	2010-03-10	1718	\N	8589
16139	GENERIC_DAY	0	4	2010-02-16	1722	\N	8589
16140	GENERIC_DAY	0	2	2010-03-10	1726	\N	8589
16141	GENERIC_DAY	0	4	2010-03-03	1722	\N	8589
16142	GENERIC_DAY	0	3	2010-03-08	1718	\N	8589
16143	GENERIC_DAY	0	2	2010-03-01	1726	\N	8589
16144	GENERIC_DAY	0	2	2010-03-13	1726	\N	8589
16145	GENERIC_DAY	0	3	2010-03-07	1718	\N	8589
16146	GENERIC_DAY	0	2	2010-02-14	1718	\N	8589
16147	GENERIC_DAY	0	2	2010-03-22	1718	\N	8589
16148	GENERIC_DAY	0	2	2010-03-26	1718	\N	8589
16149	GENERIC_DAY	0	3	2010-03-28	1722	\N	8589
16150	GENERIC_DAY	0	3	2010-03-21	1726	\N	8589
16151	GENERIC_DAY	0	3	2010-03-09	1722	\N	8589
16152	GENERIC_DAY	0	3	2010-03-12	1722	\N	8589
16153	GENERIC_DAY	0	4	2010-03-01	1722	\N	8589
16154	GENERIC_DAY	0	2	2010-02-21	1726	\N	8589
16155	GENERIC_DAY	0	3	2010-03-21	1722	\N	8589
16156	GENERIC_DAY	0	2	2010-02-20	1718	\N	8589
16157	GENERIC_DAY	0	2	2010-03-01	1718	\N	8589
16158	GENERIC_DAY	0	3	2010-03-26	1726	\N	8589
16159	GENERIC_DAY	0	3	2010-03-22	1722	\N	8589
16160	GENERIC_DAY	0	3	2010-03-25	1722	\N	8589
16161	GENERIC_DAY	0	3	2010-02-15	1718	\N	8589
16162	GENERIC_DAY	0	3	2010-03-18	1718	\N	8589
16163	GENERIC_DAY	0	3	2010-03-04	1718	\N	8589
16164	GENERIC_DAY	0	4	2010-02-27	1722	\N	8589
16165	GENERIC_DAY	0	2	2010-03-28	1718	\N	8589
16166	GENERIC_DAY	0	2	2010-02-28	1726	\N	8589
16167	GENERIC_DAY	0	4	2010-02-23	1722	\N	8589
16168	GENERIC_DAY	0	3	2010-03-09	1718	\N	8589
16169	GENERIC_DAY	0	4	2010-02-07	1722	\N	8589
16170	GENERIC_DAY	0	3	2010-03-12	1718	\N	8589
16171	GENERIC_DAY	0	2	2010-03-16	1726	\N	8589
16172	GENERIC_DAY	0	3	2010-03-26	1722	\N	8589
16173	GENERIC_DAY	0	3	2010-03-22	1726	\N	8589
16174	GENERIC_DAY	0	3	2010-02-16	1718	\N	8589
16175	GENERIC_DAY	0	2	2010-02-27	1718	\N	8589
16176	GENERIC_DAY	0	2	2010-02-12	1726	\N	8589
16177	GENERIC_DAY	0	2	2010-03-20	1718	\N	8589
16178	GENERIC_DAY	0	2	2010-02-28	1718	\N	8589
16179	GENERIC_DAY	0	2	2010-02-08	1726	\N	8589
16180	GENERIC_DAY	0	2	2010-02-24	1726	\N	8589
16181	GENERIC_DAY	0	3	2010-02-17	1718	\N	8589
16182	GENERIC_DAY	0	2	2010-03-07	1726	\N	8589
16183	GENERIC_DAY	0	2	2010-03-02	1718	\N	8589
16184	GENERIC_DAY	0	3	2010-03-19	1726	\N	8589
16185	GENERIC_DAY	0	8	2010-04-22	1720	\N	8588
16186	GENERIC_DAY	0	8	2010-04-12	1720	\N	8588
16187	GENERIC_DAY	0	8	2010-04-19	1720	\N	8588
16188	GENERIC_DAY	0	8	2010-04-15	1720	\N	8588
16189	GENERIC_DAY	0	8	2010-04-21	1720	\N	8588
16190	GENERIC_DAY	0	8	2010-04-11	1720	\N	8588
16191	GENERIC_DAY	0	8	2010-04-14	1720	\N	8588
16192	GENERIC_DAY	0	8	2010-04-16	1720	\N	8588
16193	GENERIC_DAY	0	8	2010-04-18	1720	\N	8588
16194	GENERIC_DAY	0	4	2010-04-23	1720	\N	8588
16195	GENERIC_DAY	0	8	2010-04-17	1720	\N	8588
27306	GENERIC_DAY	1	0	2009-12-25	1718	\N	19901
27307	GENERIC_DAY	1	3	2010-02-04	1726	\N	19901
27308	GENERIC_DAY	1	3	2010-02-16	1726	\N	19901
27309	GENERIC_DAY	1	0	2009-12-26	1726	\N	19901
27310	GENERIC_DAY	1	0	2009-12-25	1726	\N	19901
27311	GENERIC_DAY	1	0	2010-01-02	1722	\N	19901
27312	GENERIC_DAY	1	3	2009-12-29	1726	\N	19901
27313	GENERIC_DAY	1	0	2010-01-16	1726	\N	19901
27314	GENERIC_DAY	1	0	2010-01-30	1718	\N	19901
27315	GENERIC_DAY	1	0	2010-01-01	1726	\N	19901
27316	GENERIC_DAY	1	0	2010-01-30	1726	\N	19901
20789	GENERIC_DAY	1	8	2010-03-02	1724	\N	6367
20788	GENERIC_DAY	1	8	2010-03-08	1724	\N	6367
20790	GENERIC_DAY	1	8	2010-03-05	1724	\N	6367
27317	GENERIC_DAY	1	3	2009-12-29	1722	\N	19901
27318	GENERIC_DAY	1	0	2010-02-13	1722	\N	19901
27319	GENERIC_DAY	1	3	2009-12-31	1726	\N	19901
27320	GENERIC_DAY	1	3	2010-01-29	1726	\N	19901
27321	GENERIC_DAY	1	3	2010-01-20	1718	\N	19901
27322	GENERIC_DAY	1	0	2010-02-06	1718	\N	19901
27323	GENERIC_DAY	1	1	2010-02-09	1722	\N	19901
27324	GENERIC_DAY	1	1	2010-02-17	1722	\N	19901
27325	GENERIC_DAY	1	0	2010-02-06	1722	\N	19901
27326	GENERIC_DAY	1	3	2010-01-28	1718	\N	19901
27327	GENERIC_DAY	1	0	2010-01-09	1726	\N	19901
27328	GENERIC_DAY	1	2	2009-12-31	1718	\N	19901
27329	GENERIC_DAY	1	2	2009-12-30	1718	\N	19901
27330	GENERIC_DAY	1	0	2010-01-01	1718	\N	19901
27331	GENERIC_DAY	1	2	2010-02-03	1722	\N	19901
27332	GENERIC_DAY	1	3	2010-02-05	1718	\N	19901
27333	GENERIC_DAY	1	2	2010-01-29	1722	\N	19901
27334	GENERIC_DAY	1	0	2010-01-09	1718	\N	19901
27335	GENERIC_DAY	1	2	2010-01-13	1722	\N	19901
27336	GENERIC_DAY	1	3	2010-02-01	1718	\N	19901
27337	GENERIC_DAY	1	3	2010-02-03	1718	\N	19901
27338	GENERIC_DAY	1	3	2010-01-06	1726	\N	19901
27339	GENERIC_DAY	1	4	2010-01-12	1718	\N	19901
27340	GENERIC_DAY	1	3	2010-01-06	1718	\N	19901
27341	GENERIC_DAY	1	3	2010-01-20	1726	\N	19901
27342	GENERIC_DAY	1	3	2010-01-15	1726	\N	19901
27343	GENERIC_DAY	1	3	2010-02-04	1718	\N	19901
27344	GENERIC_DAY	1	3	2010-01-27	1726	\N	19901
27345	GENERIC_DAY	1	2	2010-02-04	1722	\N	19901
27346	GENERIC_DAY	1	2	2010-01-20	1722	\N	19901
27347	GENERIC_DAY	1	3	2009-12-24	1722	\N	19901
27348	GENERIC_DAY	1	3	2009-12-30	1722	\N	19901
27349	GENERIC_DAY	1	0	2010-02-14	1726	\N	19901
27350	GENERIC_DAY	1	3	2010-02-02	1726	\N	19901
27351	GENERIC_DAY	1	3	2010-02-02	1718	\N	19901
27352	GENERIC_DAY	1	0	2010-02-13	1718	\N	19901
27353	GENERIC_DAY	1	0	2010-01-01	1722	\N	19901
27354	GENERIC_DAY	1	2	2010-01-04	1722	\N	19901
27355	GENERIC_DAY	1	0	2010-02-13	1726	\N	19901
27356	GENERIC_DAY	1	0	2010-01-31	1726	\N	19901
27357	GENERIC_DAY	1	3	2010-01-18	1718	\N	19901
27358	GENERIC_DAY	1	2	2010-01-07	1722	\N	19901
27359	GENERIC_DAY	1	2	2010-02-01	1722	\N	19901
27360	GENERIC_DAY	1	0	2010-01-24	1718	\N	19901
27361	GENERIC_DAY	1	2	2010-02-15	1718	\N	19901
27362	GENERIC_DAY	1	2	2010-01-06	1722	\N	19901
27363	GENERIC_DAY	1	2	2010-01-19	1722	\N	19901
27364	GENERIC_DAY	1	2	2010-01-13	1726	\N	19901
27365	GENERIC_DAY	1	0	2010-01-09	1722	\N	19901
27366	GENERIC_DAY	1	2	2010-01-12	1726	\N	19901
27367	GENERIC_DAY	1	0	2010-01-10	1722	\N	19901
27368	GENERIC_DAY	1	3	2010-01-25	1718	\N	19901
27369	GENERIC_DAY	1	3	2010-02-15	1722	\N	19901
27370	GENERIC_DAY	1	0	2010-01-23	1718	\N	19901
27371	GENERIC_DAY	1	2	2009-12-24	1718	\N	19901
27372	GENERIC_DAY	1	3	2010-01-05	1722	\N	19901
27373	GENERIC_DAY	1	2	2010-01-12	1722	\N	19901
27374	GENERIC_DAY	1	4	2010-01-14	1718	\N	19901
27375	GENERIC_DAY	1	0	2010-01-02	1726	\N	19901
27376	GENERIC_DAY	1	3	2009-12-28	1722	\N	19901
27377	GENERIC_DAY	1	2	2010-01-27	1722	\N	19901
27378	GENERIC_DAY	1	3	2010-02-05	1726	\N	19901
27379	GENERIC_DAY	1	4	2010-02-09	1718	\N	19901
27380	GENERIC_DAY	1	3	2010-01-19	1726	\N	19901
27381	GENERIC_DAY	1	0	2010-01-17	1722	\N	19901
27382	GENERIC_DAY	1	0	2010-01-24	1722	\N	19901
27383	GENERIC_DAY	1	2	2010-01-08	1722	\N	19901
27384	GENERIC_DAY	1	3	2010-01-05	1726	\N	19901
27385	GENERIC_DAY	1	2	2010-01-14	1726	\N	19901
27386	GENERIC_DAY	1	0	2010-01-17	1718	\N	19901
27387	GENERIC_DAY	1	2	2010-01-11	1726	\N	19901
27388	GENERIC_DAY	1	3	2010-01-18	1726	\N	19901
27389	GENERIC_DAY	1	3	2009-12-30	1726	\N	19901
27390	GENERIC_DAY	1	0	2009-12-27	1718	\N	19901
27391	GENERIC_DAY	1	2	2010-02-12	1718	\N	19901
27392	GENERIC_DAY	1	3	2010-02-12	1726	\N	19901
27393	GENERIC_DAY	1	0	2010-01-30	1722	\N	19901
27394	GENERIC_DAY	1	0	2010-01-24	1726	\N	19901
27395	GENERIC_DAY	1	1	2010-02-11	1722	\N	19901
27396	GENERIC_DAY	1	0	2009-12-26	1722	\N	19901
27397	GENERIC_DAY	1	3	2010-01-26	1722	\N	19901
27398	GENERIC_DAY	1	0	2010-01-23	1722	\N	19901
27399	GENERIC_DAY	1	0	2010-01-23	1726	\N	19901
27400	GENERIC_DAY	1	0	2010-02-07	1722	\N	19901
27401	GENERIC_DAY	1	3	2010-01-28	1726	\N	19901
27402	GENERIC_DAY	1	0	2010-01-03	1718	\N	19901
27403	GENERIC_DAY	1	2	2010-02-02	1722	\N	19901
27404	GENERIC_DAY	1	0	2010-02-14	1722	\N	19901
27405	GENERIC_DAY	1	3	2010-02-10	1726	\N	19901
27406	GENERIC_DAY	1	3	2010-01-08	1726	\N	19901
27407	GENERIC_DAY	1	4	2010-02-08	1718	\N	19901
27408	GENERIC_DAY	1	0	2010-01-10	1726	\N	19901
20797	GENERIC_DAY	1	8	2010-02-26	1724	\N	6367
20794	GENERIC_DAY	1	8	2010-03-01	1724	\N	6367
20793	GENERIC_DAY	1	8	2010-02-28	1724	\N	6367
20798	GENERIC_DAY	1	8	2010-03-09	1724	\N	6367
20791	GENERIC_DAY	1	8	2010-03-07	1724	\N	6367
20796	GENERIC_DAY	1	8	2010-03-06	1724	\N	6367
20799	GENERIC_DAY	1	8	2010-02-27	1724	\N	6367
20795	GENERIC_DAY	1	8	2010-03-03	1724	\N	6367
20792	GENERIC_DAY	1	8	2010-03-04	1724	\N	6367
20800	GENERIC_DAY	1	4	2010-03-10	1724	\N	6367
27409	GENERIC_DAY	1	3	2009-12-24	1726	\N	19901
27410	GENERIC_DAY	1	0	2010-01-10	1718	\N	19901
27411	GENERIC_DAY	1	3	2010-01-21	1718	\N	19901
27412	GENERIC_DAY	1	0	2010-01-16	1722	\N	19901
27413	GENERIC_DAY	1	4	2010-02-10	1718	\N	19901
27414	GENERIC_DAY	1	2	2010-01-25	1722	\N	19901
27415	GENERIC_DAY	1	3	2010-01-08	1718	\N	19901
27416	GENERIC_DAY	1	3	2010-01-04	1726	\N	19901
27417	GENERIC_DAY	1	0	2009-12-27	1726	\N	19901
27418	GENERIC_DAY	1	0	2009-12-27	1722	\N	19901
27419	GENERIC_DAY	1	0	2010-01-16	1718	\N	19901
27420	GENERIC_DAY	1	0	2009-12-25	1722	\N	19901
27421	GENERIC_DAY	1	2	2010-01-22	1722	\N	19901
27422	GENERIC_DAY	1	7	2010-01-10	1720	\N	3952
27423	GENERIC_DAY	1	15	2010-01-11	1720	\N	3952
27424	GENERIC_DAY	1	7	2010-01-09	1720	\N	3952
27425	GENERIC_DAY	1	14	2010-01-12	1720	\N	3952
27426	GENERIC_DAY	1	14	2010-01-13	1720	\N	3952
27427	GENERIC_DAY	1	15	2010-01-08	1720	\N	3952
27428	GENERIC_DAY	1	14	2010-01-14	1720	\N	3952
27429	GENERIC_DAY	1	14	2010-01-15	1720	\N	3952
27430	GENERIC_DAY	1	14	2010-01-13	1724	\N	3951
27431	GENERIC_DAY	1	14	2010-01-12	1724	\N	3951
27432	GENERIC_DAY	1	15	2010-01-08	1724	\N	3951
27433	GENERIC_DAY	1	15	2010-01-11	1724	\N	3951
27434	GENERIC_DAY	1	7	2010-01-10	1724	\N	3951
27435	GENERIC_DAY	1	14	2010-01-15	1724	\N	3951
27436	GENERIC_DAY	1	14	2010-01-14	1724	\N	3951
27437	GENERIC_DAY	1	7	2010-01-09	1724	\N	3951
27438	GENERIC_DAY	1	0	2010-03-21	1724	\N	3950
27439	GENERIC_DAY	1	2	2010-02-19	1724	\N	3950
27440	GENERIC_DAY	1	2	2010-03-11	1724	\N	3950
27441	GENERIC_DAY	1	2	2010-03-15	1724	\N	3950
27442	GENERIC_DAY	1	2	2010-03-04	1724	\N	3950
27443	GENERIC_DAY	1	0	2010-02-28	1724	\N	3950
27444	GENERIC_DAY	1	2	2010-03-17	1724	\N	3950
27445	GENERIC_DAY	1	2	2010-03-16	1724	\N	3950
27446	GENERIC_DAY	1	2	2010-02-22	1724	\N	3950
27447	GENERIC_DAY	1	0	2010-03-20	1724	\N	3950
27448	GENERIC_DAY	1	0	2010-02-20	1724	\N	3950
27449	GENERIC_DAY	1	0	2010-03-14	1724	\N	3950
27450	GENERIC_DAY	1	2	2010-03-23	1724	\N	3950
27451	GENERIC_DAY	1	2	2010-03-08	1724	\N	3950
27452	GENERIC_DAY	1	2	2010-02-24	1724	\N	3950
27453	GENERIC_DAY	1	2	2010-03-03	1724	\N	3950
27454	GENERIC_DAY	1	2	2010-03-10	1724	\N	3950
27455	GENERIC_DAY	1	0	2010-03-06	1724	\N	3950
27456	GENERIC_DAY	1	2	2010-03-19	1724	\N	3950
27457	GENERIC_DAY	1	2	2010-03-05	1724	\N	3950
27458	GENERIC_DAY	1	0	2010-03-13	1724	\N	3950
27459	GENERIC_DAY	1	2	2010-02-23	1724	\N	3950
27460	GENERIC_DAY	1	0	2010-03-07	1724	\N	3950
27461	GENERIC_DAY	1	2	2010-03-24	1724	\N	3950
27462	GENERIC_DAY	1	2	2010-03-09	1724	\N	3950
27463	GENERIC_DAY	1	2	2010-02-26	1724	\N	3950
27464	GENERIC_DAY	1	2	2010-03-18	1724	\N	3950
27465	GENERIC_DAY	1	2	2010-02-18	1724	\N	3950
27466	GENERIC_DAY	1	2	2010-03-12	1724	\N	3950
27467	GENERIC_DAY	1	2	2010-03-02	1724	\N	3950
27468	GENERIC_DAY	1	2	2010-02-25	1724	\N	3950
27469	GENERIC_DAY	1	0	2010-02-27	1724	\N	3950
27470	GENERIC_DAY	1	2	2010-03-22	1724	\N	3950
27471	GENERIC_DAY	1	0	2010-02-21	1724	\N	3950
27472	GENERIC_DAY	1	2	2010-03-01	1724	\N	3950
27473	GENERIC_DAY	1	0	2010-01-03	1724	\N	3953
27474	GENERIC_DAY	1	0	2009-12-27	1724	\N	3953
27475	GENERIC_DAY	1	0	2009-12-26	1724	\N	3953
27476	GENERIC_DAY	1	8	2009-12-16	1724	\N	3953
27477	GENERIC_DAY	1	0	2010-01-01	1724	\N	3953
27478	GENERIC_DAY	1	8	2009-12-15	1724	\N	3953
27479	GENERIC_DAY	1	0	2009-12-25	1724	\N	3953
27480	GENERIC_DAY	1	8	2010-01-05	1724	\N	3953
27481	GENERIC_DAY	1	8	2009-12-22	1724	\N	3953
27482	GENERIC_DAY	1	8	2009-12-24	1724	\N	3953
27483	GENERIC_DAY	1	8	2009-12-23	1724	\N	3953
27484	GENERIC_DAY	1	8	2009-12-28	1724	\N	3953
27485	GENERIC_DAY	1	8	2009-12-18	1724	\N	3953
27486	GENERIC_DAY	1	8	2010-01-06	1724	\N	3953
27487	GENERIC_DAY	1	8	2009-12-21	1724	\N	3953
27488	GENERIC_DAY	1	0	2010-01-02	1724	\N	3953
27489	GENERIC_DAY	1	8	2010-01-07	1724	\N	3953
27490	GENERIC_DAY	1	8	2009-12-17	1724	\N	3953
27491	GENERIC_DAY	1	8	2010-01-04	1724	\N	3953
27492	GENERIC_DAY	1	8	2009-12-29	1724	\N	3953
27493	GENERIC_DAY	1	0	2009-12-20	1724	\N	3953
27494	GENERIC_DAY	1	8	2009-12-30	1724	\N	3953
27495	GENERIC_DAY	1	0	2009-12-19	1724	\N	3953
31454	SPECIFIC_DAY	3	0	2010-01-09	1720	31014	\N
31455	SPECIFIC_DAY	3	8	2009-12-15	1720	31014	\N
31456	SPECIFIC_DAY	3	8	2009-12-16	1720	31014	\N
31457	SPECIFIC_DAY	3	0	2009-12-12	1720	31014	\N
31458	SPECIFIC_DAY	3	8	2009-12-28	1720	31014	\N
31459	SPECIFIC_DAY	3	8	2009-12-30	1720	31014	\N
31460	SPECIFIC_DAY	3	8	2010-01-15	1720	31014	\N
31461	SPECIFIC_DAY	3	8	2009-12-22	1720	31014	\N
31462	SPECIFIC_DAY	3	0	2010-01-03	1720	31014	\N
31463	SPECIFIC_DAY	3	8	2009-12-17	1720	31014	\N
31464	SPECIFIC_DAY	3	8	2010-01-12	1720	31014	\N
31465	SPECIFIC_DAY	3	0	2009-12-26	1720	31014	\N
31466	SPECIFIC_DAY	3	8	2010-01-13	1720	31014	\N
31467	SPECIFIC_DAY	3	8	2010-01-04	1720	31014	\N
31468	SPECIFIC_DAY	3	8	2009-12-11	1720	31014	\N
31469	SPECIFIC_DAY	3	8	2009-12-18	1720	31014	\N
31470	SPECIFIC_DAY	3	8	2009-12-23	1720	31014	\N
31471	SPECIFIC_DAY	3	0	2009-12-20	1720	31014	\N
31472	SPECIFIC_DAY	3	8	2009-12-31	1720	31014	\N
31473	SPECIFIC_DAY	3	8	2009-12-14	1720	31014	\N
31474	SPECIFIC_DAY	3	8	2010-01-06	1720	31014	\N
31475	SPECIFIC_DAY	3	8	2009-12-10	1720	31014	\N
31476	SPECIFIC_DAY	3	8	2009-12-24	1720	31014	\N
31477	SPECIFIC_DAY	3	8	2010-01-11	1720	31014	\N
31478	SPECIFIC_DAY	3	0	2010-01-02	1720	31014	\N
31479	SPECIFIC_DAY	3	8	2009-12-29	1720	31014	\N
31480	SPECIFIC_DAY	3	8	2010-01-14	1720	31014	\N
31481	SPECIFIC_DAY	3	8	2009-12-21	1720	31014	\N
31482	SPECIFIC_DAY	3	0	2009-12-25	1720	31014	\N
31483	SPECIFIC_DAY	3	8	2010-01-08	1720	31014	\N
31484	SPECIFIC_DAY	3	8	2010-01-05	1720	31014	\N
31485	SPECIFIC_DAY	3	0	2009-12-27	1720	31014	\N
31486	SPECIFIC_DAY	3	8	2010-01-07	1720	31014	\N
31487	SPECIFIC_DAY	3	0	2010-01-01	1720	31014	\N
31488	SPECIFIC_DAY	3	0	2010-01-10	1720	31014	\N
31489	SPECIFIC_DAY	3	0	2009-12-19	1720	31014	\N
31490	SPECIFIC_DAY	3	0	2009-12-13	1720	31014	\N
48919	GENERIC_DAY	0	3	2010-02-08	40199	\N	41050
48920	GENERIC_DAY	0	2	2010-02-08	37573	\N	41050
48921	GENERIC_DAY	0	0	2010-02-06	36159	\N	41050
48922	GENERIC_DAY	0	3	2010-02-05	37573	\N	41050
48923	GENERIC_DAY	0	0	2010-02-06	37573	\N	41050
48924	GENERIC_DAY	0	0	2010-02-07	36159	\N	41050
48925	GENERIC_DAY	0	1	2010-02-08	36159	\N	41050
48926	GENERIC_DAY	0	3	2010-02-05	40199	\N	41050
48927	GENERIC_DAY	0	2	2010-02-05	36159	\N	41050
48928	GENERIC_DAY	0	0	2010-02-07	40199	\N	41050
48929	GENERIC_DAY	0	0	2010-02-07	37573	\N	41050
48930	GENERIC_DAY	0	0	2010-02-06	40199	\N	41050
39501	GENERIC_DAY	1	0	2010-02-05	36159	\N	38601
39502	GENERIC_DAY	1	0	2010-03-22	36159	\N	38601
39503	GENERIC_DAY	1	0	2010-02-01	37573	\N	38601
39504	GENERIC_DAY	1	0	2010-02-26	37573	\N	38601
39505	GENERIC_DAY	1	0	2010-02-10	36159	\N	38601
39506	GENERIC_DAY	1	1	2010-01-28	36159	\N	38601
16196	GENERIC_DAY	0	8	2010-04-20	1720	\N	8588
16197	GENERIC_DAY	0	8	2010-04-13	1720	\N	8588
16198	GENERIC_DAY	0	8	2010-03-24	1724	\N	3983
16199	GENERIC_DAY	0	8	2010-03-13	1724	\N	3983
16200	GENERIC_DAY	0	8	2010-03-20	1724	\N	3983
16201	GENERIC_DAY	0	8	2010-03-16	1724	\N	3983
16202	GENERIC_DAY	0	8	2010-03-04	1724	\N	3983
16203	GENERIC_DAY	0	8	2010-03-26	1724	\N	3983
16204	GENERIC_DAY	0	8	2010-04-02	1724	\N	3983
16205	GENERIC_DAY	0	8	2010-03-19	1724	\N	3983
16206	GENERIC_DAY	0	8	2010-03-18	1724	\N	3983
16207	GENERIC_DAY	0	8	2010-03-29	1724	\N	3983
16208	GENERIC_DAY	0	8	2010-04-03	1724	\N	3983
16209	GENERIC_DAY	0	8	2010-03-06	1724	\N	3983
16210	GENERIC_DAY	0	8	2010-04-01	1724	\N	3983
16211	GENERIC_DAY	0	8	2010-03-30	1724	\N	3983
16212	GENERIC_DAY	0	8	2010-03-11	1724	\N	3983
16213	GENERIC_DAY	0	8	2010-03-12	1724	\N	3983
16214	GENERIC_DAY	0	8	2010-03-09	1724	\N	3983
16215	GENERIC_DAY	0	8	2010-03-02	1724	\N	3983
16216	GENERIC_DAY	0	8	2010-03-25	1724	\N	3983
16217	GENERIC_DAY	0	8	2010-03-22	1724	\N	3983
16218	GENERIC_DAY	0	8	2010-03-27	1724	\N	3983
16219	GENERIC_DAY	0	8	2010-03-23	1724	\N	3983
16220	GENERIC_DAY	0	8	2010-03-31	1724	\N	3983
16221	GENERIC_DAY	0	8	2010-03-14	1724	\N	3983
16222	GENERIC_DAY	0	8	2010-03-28	1724	\N	3983
16223	GENERIC_DAY	0	8	2010-03-08	1724	\N	3983
16224	GENERIC_DAY	0	8	2010-03-01	1724	\N	3983
16225	GENERIC_DAY	0	8	2010-03-21	1724	\N	3983
16226	GENERIC_DAY	0	8	2010-03-15	1724	\N	3983
16227	GENERIC_DAY	0	8	2010-03-17	1724	\N	3983
16228	GENERIC_DAY	0	8	2010-03-05	1724	\N	3983
16229	GENERIC_DAY	0	8	2010-03-10	1724	\N	3983
16230	GENERIC_DAY	0	8	2010-03-07	1724	\N	3983
16231	GENERIC_DAY	0	8	2010-03-03	1724	\N	3983
16232	GENERIC_DAY	0	3	2010-04-04	1724	\N	3983
16233	GENERIC_DAY	0	8	2010-03-24	1720	\N	3982
16234	GENERIC_DAY	0	8	2010-03-31	1720	\N	3982
16235	GENERIC_DAY	0	8	2010-03-18	1720	\N	3982
16236	GENERIC_DAY	0	8	2010-03-25	1720	\N	3982
16237	GENERIC_DAY	0	8	2010-03-14	1720	\N	3982
16238	GENERIC_DAY	0	8	2010-03-11	1720	\N	3982
16239	GENERIC_DAY	0	8	2010-03-04	1720	\N	3982
16240	GENERIC_DAY	0	8	2010-03-13	1720	\N	3982
16241	GENERIC_DAY	0	8	2010-03-03	1720	\N	3982
16242	GENERIC_DAY	0	8	2010-03-29	1720	\N	3982
16243	GENERIC_DAY	0	8	2010-04-02	1720	\N	3982
16244	GENERIC_DAY	0	8	2010-03-23	1720	\N	3982
16245	GENERIC_DAY	0	8	2010-03-12	1720	\N	3982
16246	GENERIC_DAY	0	8	2010-03-22	1720	\N	3982
16247	GENERIC_DAY	0	8	2010-03-17	1720	\N	3982
16248	GENERIC_DAY	0	8	2010-03-16	1720	\N	3982
16249	GENERIC_DAY	0	8	2010-03-30	1720	\N	3982
16250	GENERIC_DAY	0	8	2010-03-15	1720	\N	3982
16251	GENERIC_DAY	0	8	2010-03-06	1720	\N	3982
16252	GENERIC_DAY	0	8	2010-03-28	1720	\N	3982
16253	GENERIC_DAY	0	8	2010-03-08	1720	\N	3982
16254	GENERIC_DAY	0	8	2010-03-26	1720	\N	3982
16255	GENERIC_DAY	0	8	2010-03-05	1720	\N	3982
16256	GENERIC_DAY	0	8	2010-04-01	1720	\N	3982
16257	GENERIC_DAY	0	8	2010-04-03	1720	\N	3982
16258	GENERIC_DAY	0	8	2010-03-01	1720	\N	3982
16259	GENERIC_DAY	0	3	2010-04-04	1720	\N	3982
16260	GENERIC_DAY	0	8	2010-03-21	1720	\N	3982
16261	GENERIC_DAY	0	8	2010-03-09	1720	\N	3982
16262	GENERIC_DAY	0	8	2010-03-10	1720	\N	3982
16263	GENERIC_DAY	0	8	2010-03-02	1720	\N	3982
16264	GENERIC_DAY	0	8	2010-03-07	1720	\N	3982
16265	GENERIC_DAY	0	8	2010-03-27	1720	\N	3982
16266	GENERIC_DAY	0	8	2010-03-20	1720	\N	3982
16267	GENERIC_DAY	0	8	2010-03-19	1720	\N	3982
15996	GENERIC_DAY	3	3	2010-03-31	1722	\N	3985
15997	GENERIC_DAY	3	3	2010-04-05	1726	\N	3985
15998	GENERIC_DAY	3	3	2010-04-01	1722	\N	3985
15999	GENERIC_DAY	3	3	2010-03-30	1726	\N	3985
16000	GENERIC_DAY	3	3	2010-04-02	1726	\N	3985
16001	GENERIC_DAY	3	3	2010-04-08	1722	\N	3985
39444	GENERIC_DAY	1	0	2010-01-23	36159	\N	38601
39445	GENERIC_DAY	1	0	2010-03-01	37573	\N	38601
39446	GENERIC_DAY	1	1	2010-01-26	37573	\N	38601
39447	GENERIC_DAY	1	0	2010-03-23	37573	\N	38601
39448	GENERIC_DAY	1	0	2010-03-05	37573	\N	38601
39449	GENERIC_DAY	1	0	2010-03-02	36159	\N	38601
39450	GENERIC_DAY	1	1	2010-02-03	37573	\N	38601
39451	GENERIC_DAY	1	0	2010-03-01	36159	\N	38601
39452	GENERIC_DAY	1	0	2010-03-06	36159	\N	38601
39453	GENERIC_DAY	1	0	2010-01-26	36159	\N	38601
39454	GENERIC_DAY	1	0	2010-02-09	36159	\N	38601
39455	GENERIC_DAY	1	0	2010-02-23	36159	\N	38601
39456	GENERIC_DAY	1	0	2010-01-31	36159	\N	38601
39457	GENERIC_DAY	1	0	2010-03-16	37573	\N	38601
39458	GENERIC_DAY	1	0	2010-02-21	36159	\N	38601
39459	GENERIC_DAY	1	0	2010-02-12	36159	\N	38601
39460	GENERIC_DAY	1	0	2010-02-14	37573	\N	38601
39461	GENERIC_DAY	1	0	2010-03-10	37573	\N	38601
39462	GENERIC_DAY	1	0	2010-02-24	36159	\N	38601
39463	GENERIC_DAY	1	0	2010-02-21	37573	\N	38601
39464	GENERIC_DAY	1	0	2010-03-13	36159	\N	38601
39465	GENERIC_DAY	1	0	2010-02-13	37573	\N	38601
39466	GENERIC_DAY	1	0	2010-02-18	36159	\N	38601
39467	GENERIC_DAY	1	0	2010-03-06	37573	\N	38601
39468	GENERIC_DAY	1	0	2010-02-11	36159	\N	38601
39469	GENERIC_DAY	1	0	2010-02-20	37573	\N	38601
39470	GENERIC_DAY	1	0	2010-02-17	37573	\N	38601
39471	GENERIC_DAY	1	1	2010-02-05	37573	\N	38601
39472	GENERIC_DAY	1	0	2010-03-04	37573	\N	38601
39473	GENERIC_DAY	1	0	2010-02-22	37573	\N	38601
39474	GENERIC_DAY	1	0	2010-02-27	36159	\N	38601
39475	GENERIC_DAY	1	0	2010-03-21	36159	\N	38601
39476	GENERIC_DAY	1	0	2010-03-20	37573	\N	38601
39477	GENERIC_DAY	1	0	2010-02-15	36159	\N	38601
39478	GENERIC_DAY	1	1	2010-02-04	37573	\N	38601
39479	GENERIC_DAY	1	0	2010-03-04	36159	\N	38601
39480	GENERIC_DAY	1	0	2010-02-08	36159	\N	38601
39481	GENERIC_DAY	1	0	2010-02-23	37573	\N	38601
39482	GENERIC_DAY	1	0	2010-03-02	37573	\N	38601
39483	GENERIC_DAY	1	0	2010-02-28	36159	\N	38601
39484	GENERIC_DAY	1	0	2010-03-09	36159	\N	38601
39485	GENERIC_DAY	1	0	2010-03-22	37573	\N	38601
39486	GENERIC_DAY	1	0	2010-01-22	36159	\N	38601
39487	GENERIC_DAY	1	1	2010-01-22	37573	\N	38601
39488	GENERIC_DAY	1	0	2010-02-04	36159	\N	38601
39489	GENERIC_DAY	1	0	2010-03-14	36159	\N	38601
39490	GENERIC_DAY	1	0	2010-03-08	37573	\N	38601
39491	GENERIC_DAY	1	1	2010-02-01	36159	\N	38601
39492	GENERIC_DAY	1	0	2010-02-20	36159	\N	38601
39493	GENERIC_DAY	1	0	2010-02-24	37573	\N	38601
39494	GENERIC_DAY	1	1	2010-02-10	37573	\N	38601
39495	GENERIC_DAY	1	0	2010-03-21	37573	\N	38601
39496	GENERIC_DAY	1	0	2010-03-14	37573	\N	38601
39497	GENERIC_DAY	1	0	2010-03-07	37573	\N	38601
39498	GENERIC_DAY	1	0	2010-03-17	37573	\N	38601
39499	GENERIC_DAY	1	0	2010-03-12	36159	\N	38601
39500	GENERIC_DAY	1	0	2010-02-16	36159	\N	38601
39507	GENERIC_DAY	1	0	2010-03-24	36159	\N	38601
39508	GENERIC_DAY	1	0	2010-03-15	37573	\N	38601
39509	GENERIC_DAY	1	0	2010-03-11	37573	\N	38601
39510	GENERIC_DAY	1	0	2010-03-20	36159	\N	38601
39511	GENERIC_DAY	1	0	2010-01-24	36159	\N	38601
39512	GENERIC_DAY	1	0	2010-02-25	36159	\N	38601
39513	GENERIC_DAY	1	1	2010-01-25	37573	\N	38601
39514	GENERIC_DAY	1	0	2010-01-30	37573	\N	38601
39515	GENERIC_DAY	1	0	2010-02-18	37573	\N	38601
39516	GENERIC_DAY	1	0	2010-03-11	36159	\N	38601
39517	GENERIC_DAY	1	0	2010-03-09	37573	\N	38601
39518	GENERIC_DAY	1	1	2010-02-09	37573	\N	38601
39519	GENERIC_DAY	1	0	2010-03-19	37573	\N	38601
39520	GENERIC_DAY	1	0	2010-03-03	36159	\N	38601
39521	GENERIC_DAY	1	0	2010-03-15	36159	\N	38601
39522	GENERIC_DAY	1	0	2010-01-25	36159	\N	38601
39523	GENERIC_DAY	1	0	2010-03-18	37573	\N	38601
39524	GENERIC_DAY	1	0	2010-02-17	36159	\N	38601
39525	GENERIC_DAY	1	0	2010-02-16	37573	\N	38601
39526	GENERIC_DAY	1	0	2010-02-07	37573	\N	38601
39527	GENERIC_DAY	1	0	2010-02-19	37573	\N	38601
39528	GENERIC_DAY	1	0	2010-02-07	36159	\N	38601
39529	GENERIC_DAY	1	0	2010-02-26	36159	\N	38601
39530	GENERIC_DAY	1	1	2010-01-29	36159	\N	38601
39531	GENERIC_DAY	1	0	2010-01-31	37573	\N	38601
39532	GENERIC_DAY	1	1	2010-02-08	37573	\N	38601
39533	GENERIC_DAY	1	0	2010-03-10	36159	\N	38601
39534	GENERIC_DAY	1	0	2010-03-16	36159	\N	38601
39535	GENERIC_DAY	1	0	2010-02-06	37573	\N	38601
39536	GENERIC_DAY	1	0	2010-02-06	36159	\N	38601
39537	GENERIC_DAY	1	0	2010-01-28	37573	\N	38601
39538	GENERIC_DAY	1	1	2010-02-02	37573	\N	38601
39539	GENERIC_DAY	1	0	2010-02-15	37573	\N	38601
39540	GENERIC_DAY	1	0	2010-01-29	37573	\N	38601
39541	GENERIC_DAY	1	0	2010-03-05	36159	\N	38601
39542	GENERIC_DAY	1	0	2010-02-28	37573	\N	38601
39543	GENERIC_DAY	1	0	2010-03-17	36159	\N	38601
39544	GENERIC_DAY	1	1	2010-01-27	36159	\N	38601
39545	GENERIC_DAY	1	0	2010-01-27	37573	\N	38601
39546	GENERIC_DAY	1	0	2010-02-03	36159	\N	38601
39547	GENERIC_DAY	1	0	2010-01-24	37573	\N	38601
39548	GENERIC_DAY	1	0	2010-03-12	37573	\N	38601
39549	GENERIC_DAY	1	0	2010-02-27	37573	\N	38601
39550	GENERIC_DAY	1	0	2010-03-08	36159	\N	38601
39551	GENERIC_DAY	1	0	2010-02-12	37573	\N	38601
39552	GENERIC_DAY	1	0	2010-02-19	36159	\N	38601
39553	GENERIC_DAY	1	0	2010-02-14	36159	\N	38601
39554	GENERIC_DAY	1	0	2010-02-13	36159	\N	38601
39555	GENERIC_DAY	1	0	2010-01-30	36159	\N	38601
39556	GENERIC_DAY	1	0	2010-03-13	37573	\N	38601
39557	GENERIC_DAY	1	0	2010-03-24	37573	\N	38601
39558	GENERIC_DAY	1	0	2010-02-02	36159	\N	38601
39559	GENERIC_DAY	1	0	2010-01-23	37573	\N	38601
39560	GENERIC_DAY	1	0	2010-02-25	37573	\N	38601
39561	GENERIC_DAY	1	0	2010-03-03	37573	\N	38601
39562	GENERIC_DAY	1	0	2010-03-23	36159	\N	38601
39563	GENERIC_DAY	1	0	2010-03-18	36159	\N	38601
48811	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077
48812	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077
48813	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077
48814	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077
48815	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077
21933	SPECIFIC_DAY	4	8	2010-02-17	1724	19903	\N
21968	SPECIFIC_DAY	4	8	2010-02-23	1724	19903	\N
21958	SPECIFIC_DAY	4	8	2010-02-04	1724	19903	\N
21964	SPECIFIC_DAY	4	8	2010-01-22	1724	19903	\N
21961	SPECIFIC_DAY	4	8	2010-02-15	1724	19903	\N
21932	SPECIFIC_DAY	4	8	2010-01-08	1724	19903	\N
21942	SPECIFIC_DAY	4	8	2010-02-12	1724	19903	\N
21960	SPECIFIC_DAY	4	0	2010-02-21	1724	19903	\N
21941	SPECIFIC_DAY	4	8	2010-02-01	1724	19903	\N
21930	SPECIFIC_DAY	4	8	2010-01-13	1724	19903	\N
21959	SPECIFIC_DAY	4	8	2010-01-04	1724	19903	\N
21928	SPECIFIC_DAY	4	8	2010-02-02	1724	19903	\N
21935	SPECIFIC_DAY	4	8	2010-02-03	1724	19903	\N
21966	SPECIFIC_DAY	4	0	2010-01-01	1724	19903	\N
21944	SPECIFIC_DAY	4	8	2010-01-27	1724	19903	\N
21975	SPECIFIC_DAY	4	8	2010-01-11	1724	19903	\N
21934	SPECIFIC_DAY	4	8	2010-01-29	1724	19903	\N
21925	SPECIFIC_DAY	4	8	2010-02-18	1724	19903	\N
21953	SPECIFIC_DAY	4	8	2010-02-09	1724	19903	\N
21974	SPECIFIC_DAY	4	8	2010-01-07	1724	19903	\N
21973	SPECIFIC_DAY	4	8	2010-01-26	1724	19903	\N
21962	SPECIFIC_DAY	4	0	2010-01-02	1724	19903	\N
21938	SPECIFIC_DAY	4	8	2010-02-19	1724	19903	\N
21957	SPECIFIC_DAY	4	0	2010-02-14	1724	19903	\N
21967	SPECIFIC_DAY	4	0	2010-02-06	1724	19903	\N
21936	SPECIFIC_DAY	4	0	2010-01-10	1724	19903	\N
21923	SPECIFIC_DAY	4	0	2010-01-24	1724	19903	\N
21952	SPECIFIC_DAY	4	8	2010-01-28	1724	19903	\N
21945	SPECIFIC_DAY	4	4	2010-02-24	1724	19903	\N
21963	SPECIFIC_DAY	4	8	2010-01-18	1724	19903	\N
21924	SPECIFIC_DAY	4	0	2010-02-13	1724	19903	\N
21927	SPECIFIC_DAY	4	8	2010-02-22	1724	19903	\N
21949	SPECIFIC_DAY	4	8	2010-02-16	1724	19903	\N
21921	SPECIFIC_DAY	4	8	2010-02-05	1724	19903	\N
21940	SPECIFIC_DAY	4	8	2010-01-06	1724	19903	\N
21947	SPECIFIC_DAY	4	8	2010-01-19	1724	19903	\N
21931	SPECIFIC_DAY	4	0	2010-02-20	1724	19903	\N
21970	SPECIFIC_DAY	4	8	2010-01-15	1724	19903	\N
21969	SPECIFIC_DAY	4	8	2010-01-12	1724	19903	\N
21946	SPECIFIC_DAY	4	0	2010-01-31	1724	19903	\N
21951	SPECIFIC_DAY	4	8	2010-02-08	1724	19903	\N
21972	SPECIFIC_DAY	4	8	2010-01-05	1724	19903	\N
21950	SPECIFIC_DAY	4	8	2010-02-11	1724	19903	\N
21922	SPECIFIC_DAY	4	0	2010-01-30	1724	19903	\N
21943	SPECIFIC_DAY	4	8	2010-01-20	1724	19903	\N
21965	SPECIFIC_DAY	4	8	2010-01-21	1724	19903	\N
21971	SPECIFIC_DAY	4	0	2010-01-09	1724	19903	\N
21956	SPECIFIC_DAY	4	0	2010-01-23	1724	19903	\N
21939	SPECIFIC_DAY	4	0	2010-01-03	1724	19903	\N
21926	SPECIFIC_DAY	4	8	2010-02-10	1724	19903	\N
21955	SPECIFIC_DAY	4	0	2010-01-17	1724	19903	\N
21929	SPECIFIC_DAY	4	0	2010-01-16	1724	19903	\N
21937	SPECIFIC_DAY	4	8	2010-01-14	1724	19903	\N
21954	SPECIFIC_DAY	4	8	2010-01-25	1724	19903	\N
21948	SPECIFIC_DAY	4	0	2010-02-07	1724	19903	\N
48816	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077
48817	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077
48818	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077
48819	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077
48820	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077
48821	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077
48822	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077
48823	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077
48824	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077
48825	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077
25621	GENERIC_DAY	0	7	2009-12-23	1724	\N	6369
25622	GENERIC_DAY	0	6	2009-12-18	1724	\N	6369
25623	GENERIC_DAY	0	0	2009-12-19	1724	\N	6369
25624	GENERIC_DAY	0	6	2009-12-16	1724	\N	6369
25625	GENERIC_DAY	0	6	2009-12-15	1724	\N	6369
25626	GENERIC_DAY	0	2	2009-12-08	1724	\N	6369
25627	GENERIC_DAY	0	5	2009-12-10	1724	\N	6369
25628	GENERIC_DAY	0	0	2009-12-25	1724	\N	6369
25629	GENERIC_DAY	0	0	2009-12-13	1724	\N	6369
25630	GENERIC_DAY	0	0	2009-12-12	1724	\N	6369
25631	GENERIC_DAY	0	0	2009-12-26	1724	\N	6369
25632	GENERIC_DAY	0	1	2009-12-09	1724	\N	6369
25633	GENERIC_DAY	0	5	2009-12-11	1724	\N	6369
25634	GENERIC_DAY	0	7	2009-12-21	1724	\N	6369
25635	GENERIC_DAY	0	7	2009-12-24	1724	\N	6369
25636	GENERIC_DAY	0	6	2009-12-31	1724	\N	6369
25637	GENERIC_DAY	0	7	2009-12-30	1724	\N	6369
25638	GENERIC_DAY	0	0	2009-12-20	1724	\N	6369
25639	GENERIC_DAY	0	7	2009-12-28	1724	\N	6369
25640	GENERIC_DAY	0	0	2009-12-27	1724	\N	6369
25641	GENERIC_DAY	0	7	2009-12-22	1724	\N	6369
25642	GENERIC_DAY	0	2	2009-12-07	1724	\N	6369
25643	GENERIC_DAY	0	7	2009-12-29	1724	\N	6369
25644	GENERIC_DAY	0	6	2009-12-17	1724	\N	6369
25645	GENERIC_DAY	0	6	2009-12-14	1724	\N	6369
25646	GENERIC_DAY	0	4	2009-12-18	1727	\N	6368
25647	GENERIC_DAY	0	4	2009-12-16	1727	\N	6368
25648	GENERIC_DAY	0	4	2009-12-08	1727	\N	6368
25649	GENERIC_DAY	0	4	2009-12-22	1727	\N	6368
25650	GENERIC_DAY	0	4	2009-12-17	1727	\N	6368
25651	GENERIC_DAY	0	4	2009-12-23	1727	\N	6368
25652	GENERIC_DAY	0	4	2009-12-31	1727	\N	6368
25653	GENERIC_DAY	0	4	2009-12-21	1727	\N	6368
25654	GENERIC_DAY	0	4	2009-12-19	1727	\N	6368
25655	GENERIC_DAY	0	4	2009-12-26	1727	\N	6368
25656	GENERIC_DAY	0	4	2009-12-12	1727	\N	6368
25657	GENERIC_DAY	0	4	2009-12-30	1727	\N	6368
25658	GENERIC_DAY	0	4	2009-12-25	1727	\N	6368
25659	GENERIC_DAY	0	4	2009-12-20	1727	\N	6368
25660	GENERIC_DAY	0	4	2009-12-29	1727	\N	6368
25661	GENERIC_DAY	0	4	2009-12-27	1727	\N	6368
48826	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077
48827	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077
48828	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077
48829	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077
48830	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077
48831	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077
48832	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013
48833	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013
48834	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013
48835	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013
48836	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013
48837	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013
48838	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013
48839	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013
48840	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013
48841	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013
48842	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013
48843	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013
48844	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013
48845	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013
48846	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013
48847	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013
48848	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013
48849	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013
48850	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013
48851	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013
48852	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013
48853	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013
48854	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013
48855	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013
48856	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013
48857	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013
48858	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013
48859	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013
25662	GENERIC_DAY	0	4	2009-12-07	1727	\N	6368
25663	GENERIC_DAY	0	4	2009-12-10	1727	\N	6368
25664	GENERIC_DAY	0	4	2009-12-11	1727	\N	6368
25665	GENERIC_DAY	0	4	2009-12-13	1727	\N	6368
25666	GENERIC_DAY	0	4	2009-12-14	1727	\N	6368
25667	GENERIC_DAY	0	4	2009-12-28	1727	\N	6368
25668	GENERIC_DAY	0	4	2009-12-15	1727	\N	6368
25669	GENERIC_DAY	0	4	2009-12-09	1727	\N	6368
25670	GENERIC_DAY	0	4	2009-12-24	1727	\N	6368
48860	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013
48861	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013
48862	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013
48863	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013
48864	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013
48865	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013
48866	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013
48867	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013
48868	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013
48869	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013
48870	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013
48871	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013
48872	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013
48873	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013
48874	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013
48875	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013
48876	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013
48877	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013
48878	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013
48879	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013
48880	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013
48881	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013
48882	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013
48883	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013
48884	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013
48885	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013
48886	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013
48887	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013
48888	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013
48889	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013
48890	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013
48891	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013
48892	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013
48893	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013
48894	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013
48895	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013
48896	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013
48897	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013
48898	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013
48899	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013
48900	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013
48901	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013
48902	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013
48903	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013
48904	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013
48905	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013
48906	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013
48907	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013
48908	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013
48909	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013
48910	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013
48911	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013
48912	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013
48913	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013
48914	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013
48915	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013
48916	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013
48917	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013
48918	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013
48931	GENERIC_DAY	3	0	2010-01-19	37573	\N	41061
48932	GENERIC_DAY	3	1	2010-01-20	36159	\N	41061
48933	GENERIC_DAY	3	3	2010-01-19	40199	\N	41061
48934	GENERIC_DAY	3	4	2010-01-20	40199	\N	41061
48935	GENERIC_DAY	3	3	2010-01-19	36159	\N	41061
48936	GENERIC_DAY	3	0	2010-01-20	37573	\N	41061
48937	GENERIC_DAY	3	1	2010-01-21	36159	\N	41051
48938	GENERIC_DAY	3	1	2010-01-21	37573	\N	41051
48939	GENERIC_DAY	3	2	2010-01-21	40199	\N	41051
48940	GENERIC_DAY	3	1	2010-01-22	36159	\N	41052
48941	GENERIC_DAY	3	1	2010-01-22	40199	\N	41052
48942	GENERIC_DAY	3	2	2010-01-22	37573	\N	41052
48943	GENERIC_DAY	3	0	2010-01-23	37573	\N	41053
48944	GENERIC_DAY	3	0	2010-01-24	40199	\N	41053
48945	GENERIC_DAY	3	0	2010-01-23	36159	\N	41053
48946	GENERIC_DAY	3	1	2010-01-25	40199	\N	41053
48947	GENERIC_DAY	3	0	2010-01-23	40199	\N	41053
48948	GENERIC_DAY	3	0	2010-01-24	36159	\N	41053
48949	GENERIC_DAY	3	2	2010-01-25	37573	\N	41053
48950	GENERIC_DAY	3	1	2010-01-25	36159	\N	41053
48951	GENERIC_DAY	3	0	2010-01-24	37573	\N	41053
24595	GENERIC_DAY	1	2	2010-02-05	1726	\N	19899
24578	GENERIC_DAY	1	3	2010-01-19	1726	\N	19899
24575	GENERIC_DAY	1	2	2010-01-13	1718	\N	19899
24583	GENERIC_DAY	1	3	2010-01-06	1726	\N	19899
24598	GENERIC_DAY	1	3	2010-01-07	1726	\N	19899
24580	GENERIC_DAY	1	0	2010-01-30	1722	\N	19899
24581	GENERIC_DAY	1	2	2010-02-02	1718	\N	19899
24597	GENERIC_DAY	1	0	2010-01-17	1722	\N	19899
24587	GENERIC_DAY	1	2	2010-02-02	1722	\N	19899
24596	GENERIC_DAY	1	2	2010-02-02	1726	\N	19899
24588	GENERIC_DAY	1	2	2010-01-29	1718	\N	19899
24585	GENERIC_DAY	1	2	2010-01-22	1722	\N	19899
24589	GENERIC_DAY	1	3	2010-01-12	1726	\N	19899
24591	GENERIC_DAY	1	0	2009-12-27	1722	\N	19899
24590	GENERIC_DAY	1	0	2010-01-01	1726	\N	19899
24582	GENERIC_DAY	1	3	2009-12-22	1718	\N	19899
24576	GENERIC_DAY	1	0	2009-12-20	1718	\N	19899
24594	GENERIC_DAY	1	0	2010-01-31	1722	\N	19899
24584	GENERIC_DAY	1	0	2010-01-16	1718	\N	19899
24593	GENERIC_DAY	1	2	2009-12-30	1726	\N	19899
24579	GENERIC_DAY	1	2	2010-01-15	1722	\N	19899
24586	GENERIC_DAY	1	2	2010-01-11	1722	\N	19899
24592	GENERIC_DAY	1	2	2010-01-05	1726	\N	19899
24577	GENERIC_DAY	1	2	2010-01-06	1722	\N	19899
37481	GENERIC_DAY	15	0	2010-01-27	36159	\N	36966
37511	GENERIC_DAY	15	1	2010-03-22	36159	\N	36966
37495	GENERIC_DAY	15	0	2010-02-27	36159	\N	36966
37488	GENERIC_DAY	15	1	2010-03-18	36159	\N	36966
37473	GENERIC_DAY	15	0	2010-02-14	36159	\N	36966
37493	GENERIC_DAY	15	1	2010-01-25	36159	\N	36966
37504	GENERIC_DAY	15	0	2010-01-29	36159	\N	36966
37498	GENERIC_DAY	15	2	2010-02-17	36159	\N	36966
37474	GENERIC_DAY	15	0	2010-02-02	36159	\N	36966
37516	GENERIC_DAY	15	0	2010-02-09	36159	\N	36966
37514	GENERIC_DAY	15	2	2010-02-16	36159	\N	36966
37499	GENERIC_DAY	15	0	2010-02-20	36159	\N	36966
37475	GENERIC_DAY	15	0	2010-02-12	36159	\N	36966
37480	GENERIC_DAY	15	1	2010-03-04	36159	\N	36966
37519	GENERIC_DAY	15	0	2010-01-24	36159	\N	36966
37491	GENERIC_DAY	15	1	2010-03-02	36159	\N	36966
37489	GENERIC_DAY	15	0	2010-01-23	36159	\N	36966
37500	GENERIC_DAY	15	0	2010-02-08	36159	\N	36966
37513	GENERIC_DAY	15	1	2010-03-25	36159	\N	36966
37517	GENERIC_DAY	15	1	2010-02-26	36159	\N	36966
45788	GENERIC_DAY	6	0	2010-01-25	36159	\N	41069
37529	GENERIC_DAY	15	0	2010-02-28	36159	\N	36966
37531	GENERIC_DAY	15	0	2010-01-28	36159	\N	36966
37526	GENERIC_DAY	15	1	2010-02-18	36159	\N	36966
37522	GENERIC_DAY	15	1	2010-01-22	36159	\N	36966
37528	GENERIC_DAY	15	1	2010-03-11	36159	\N	36966
37524	GENERIC_DAY	15	1	2010-02-24	36159	\N	36966
37521	GENERIC_DAY	15	0	2010-01-31	36159	\N	36966
37530	GENERIC_DAY	15	0	2010-02-03	36159	\N	36966
37533	GENERIC_DAY	15	1	2010-03-12	36159	\N	36966
37532	GENERIC_DAY	15	0	2010-02-21	36159	\N	36966
37527	GENERIC_DAY	15	0	2010-02-04	36159	\N	36966
37523	GENERIC_DAY	15	1	2010-03-23	36159	\N	36966
37525	GENERIC_DAY	15	0	2010-03-06	36159	\N	36966
43115	GENERIC_DAY	10	0	2010-01-22	36159	\N	41054
43078	GENERIC_DAY	10	0	2010-02-02	37573	\N	41054
43082	GENERIC_DAY	10	1	2010-01-28	40199	\N	41054
43086	GENERIC_DAY	10	0	2010-01-30	37573	\N	41054
43055	GENERIC_DAY	10	1	2010-01-19	40199	\N	41054
43107	GENERIC_DAY	10	0	2010-02-02	36159	\N	41054
43111	GENERIC_DAY	10	0	2010-01-18	37573	\N	41054
43072	GENERIC_DAY	10	0	2010-01-19	37573	\N	41054
43109	GENERIC_DAY	10	0	2010-02-07	36159	\N	41054
43087	GENERIC_DAY	10	0	2010-02-10	40199	\N	41054
43077	GENERIC_DAY	10	0	2010-01-31	37573	\N	41054
43106	GENERIC_DAY	10	0	2010-02-07	40199	\N	41054
43074	GENERIC_DAY	10	0	2010-01-31	36159	\N	41054
43116	GENERIC_DAY	10	0	2010-01-25	37573	\N	41054
43062	GENERIC_DAY	10	0	2010-01-11	40199	\N	41054
43061	GENERIC_DAY	10	0	2010-01-29	37573	\N	41054
43108	GENERIC_DAY	10	1	2010-01-11	36159	\N	41054
43089	GENERIC_DAY	10	1	2010-01-20	40199	\N	41054
43063	GENERIC_DAY	10	0	2010-01-17	40199	\N	41054
43088	GENERIC_DAY	10	1	2010-01-27	40199	\N	41054
43113	GENERIC_DAY	10	0	2010-01-15	36159	\N	41054
43052	GENERIC_DAY	10	0	2010-01-22	40199	\N	41054
43050	GENERIC_DAY	10	0	2010-02-06	40199	\N	41054
43104	GENERIC_DAY	10	1	2010-01-21	37573	\N	41054
37482	GENERIC_DAY	15	0	2010-02-15	36159	\N	36966
37471	GENERIC_DAY	15	1	2010-03-09	36159	\N	36966
37476	GENERIC_DAY	15	1	2010-03-08	36159	\N	36966
37509	GENERIC_DAY	15	1	2010-03-15	36159	\N	36966
37501	GENERIC_DAY	15	0	2010-03-20	36159	\N	36966
37485	GENERIC_DAY	15	1	2010-03-10	36159	\N	36966
37515	GENERIC_DAY	15	0	2010-03-07	36159	\N	36966
37496	GENERIC_DAY	15	0	2010-03-14	36159	\N	36966
37506	GENERIC_DAY	15	0	2010-02-10	36159	\N	36966
37508	GENERIC_DAY	15	1	2010-03-16	36159	\N	36966
37510	GENERIC_DAY	15	1	2010-03-17	36159	\N	36966
37492	GENERIC_DAY	15	1	2010-02-23	36159	\N	36966
37502	GENERIC_DAY	15	0	2010-02-07	36159	\N	36966
37483	GENERIC_DAY	15	0	2010-02-13	36159	\N	36966
37497	GENERIC_DAY	15	1	2010-01-26	36159	\N	36966
37477	GENERIC_DAY	15	1	2010-02-22	36159	\N	36966
37479	GENERIC_DAY	15	0	2010-02-05	36159	\N	36966
37512	GENERIC_DAY	15	0	2010-02-01	36159	\N	36966
37490	GENERIC_DAY	15	1	2010-03-24	36159	\N	36966
37487	GENERIC_DAY	15	0	2010-02-11	36159	\N	36966
37472	GENERIC_DAY	15	1	2010-03-05	36159	\N	36966
37486	GENERIC_DAY	15	1	2010-03-03	36159	\N	36966
37478	GENERIC_DAY	15	0	2010-02-06	36159	\N	36966
37518	GENERIC_DAY	15	0	2010-03-21	36159	\N	36966
37520	GENERIC_DAY	15	1	2010-02-25	36159	\N	36966
37494	GENERIC_DAY	15	1	2010-03-19	36159	\N	36966
37484	GENERIC_DAY	15	0	2010-03-13	36159	\N	36966
37505	GENERIC_DAY	15	1	2010-02-19	36159	\N	36966
37507	GENERIC_DAY	15	1	2010-03-01	36159	\N	36966
37503	GENERIC_DAY	15	0	2010-01-30	36159	\N	36966
37545	GENERIC_DAY	13	0	2010-01-31	37573	\N	38582
37548	GENERIC_DAY	13	0	2010-01-23	37573	\N	38582
37567	GENERIC_DAY	13	1	2010-02-19	36159	\N	38582
37538	GENERIC_DAY	13	0	2010-01-30	37573	\N	38582
37539	GENERIC_DAY	13	2	2010-01-27	37573	\N	38582
37534	GENERIC_DAY	13	0	2010-02-07	36159	\N	38582
37542	GENERIC_DAY	13	1	2010-02-10	37573	\N	38582
37562	GENERIC_DAY	13	2	2010-01-29	37573	\N	38582
37535	GENERIC_DAY	13	0	2010-02-21	37573	\N	38582
37563	GENERIC_DAY	13	0	2010-02-06	37573	\N	38582
37565	GENERIC_DAY	13	0	2010-01-24	36159	\N	38582
37558	GENERIC_DAY	13	2	2010-02-02	36159	\N	38582
37564	GENERIC_DAY	13	2	2010-02-12	36159	\N	38582
37568	GENERIC_DAY	13	2	2010-01-28	37573	\N	38582
37543	GENERIC_DAY	13	0	2010-02-14	36159	\N	38582
37557	GENERIC_DAY	13	2	2010-01-26	37573	\N	38582
37551	GENERIC_DAY	13	1	2010-02-15	37573	\N	38582
37540	GENERIC_DAY	13	0	2010-02-13	36159	\N	38582
37541	GENERIC_DAY	13	1	2010-02-03	37573	\N	38582
37554	GENERIC_DAY	13	2	2010-02-16	37573	\N	38582
37561	GENERIC_DAY	13	2	2010-01-25	36159	\N	38582
37549	GENERIC_DAY	13	2	2010-02-15	36159	\N	38582
37560	GENERIC_DAY	13	2	2010-02-17	37573	\N	38582
37546	GENERIC_DAY	13	2	2010-01-28	36159	\N	38582
37544	GENERIC_DAY	13	2	2010-02-10	36159	\N	38582
37559	GENERIC_DAY	13	0	2010-01-23	36159	\N	38582
37550	GENERIC_DAY	13	2	2010-02-19	37573	\N	38582
37536	GENERIC_DAY	13	2	2010-02-18	37573	\N	38582
37566	GENERIC_DAY	13	2	2010-02-05	36159	\N	38582
37556	GENERIC_DAY	13	2	2010-01-25	37573	\N	38582
37553	GENERIC_DAY	13	2	2010-01-29	36159	\N	38582
37555	GENERIC_DAY	13	1	2010-02-05	37573	\N	38582
37547	GENERIC_DAY	13	1	2010-02-04	37573	\N	38582
37537	GENERIC_DAY	13	2	2010-02-11	36159	\N	38582
37552	GENERIC_DAY	13	2	2010-02-01	37573	\N	38582
24901	GENERIC_DAY	1	2	2010-03-10	1722	\N	19897
24895	GENERIC_DAY	1	3	2010-02-24	1726	\N	19897
24896	GENERIC_DAY	1	4	2010-02-19	1718	\N	19897
24902	GENERIC_DAY	1	0	2010-02-21	1718	\N	19897
24890	GENERIC_DAY	1	2	2010-03-09	1722	\N	19897
24900	GENERIC_DAY	1	0	2010-03-21	1718	\N	19897
24904	GENERIC_DAY	1	0	2010-03-21	1726	\N	19897
24897	GENERIC_DAY	1	1	2010-02-26	1722	\N	19897
24899	GENERIC_DAY	1	4	2010-03-24	1718	\N	19897
24893	GENERIC_DAY	1	0	2010-02-14	1718	\N	19897
24892	GENERIC_DAY	1	0	2010-03-13	1726	\N	19897
24891	GENERIC_DAY	1	4	2010-03-25	1718	\N	19897
24898	GENERIC_DAY	1	0	2010-03-21	1722	\N	19897
24894	GENERIC_DAY	1	0	2010-03-20	1722	\N	19897
24903	GENERIC_DAY	1	3	2010-03-16	1726	\N	19897
38683	GENERIC_DAY	13	2	2010-01-22	37573	\N	38582
38702	GENERIC_DAY	13	2	2010-02-08	36159	\N	38582
38688	GENERIC_DAY	13	0	2010-02-20	36159	\N	38582
38693	GENERIC_DAY	13	0	2010-02-14	37573	\N	38582
38706	GENERIC_DAY	13	0	2010-02-06	36159	\N	38582
38687	GENERIC_DAY	13	1	2010-02-17	36159	\N	38582
38697	GENERIC_DAY	13	1	2010-02-08	37573	\N	38582
38695	GENERIC_DAY	13	2	2010-01-22	36159	\N	38582
38699	GENERIC_DAY	13	0	2010-02-07	37573	\N	38582
38700	GENERIC_DAY	13	1	2010-02-18	36159	\N	38582
47022	GENERIC_DAY	6	2	2010-01-27	36159	\N	41076
47015	GENERIC_DAY	6	0	2010-01-28	37573	\N	41076
47018	GENERIC_DAY	6	2	2010-01-27	37573	\N	41076
38698	GENERIC_DAY	13	0	2010-01-24	37573	\N	38582
37570	GENERIC_DAY	13	1	2010-02-16	36159	\N	38582
38703	GENERIC_DAY	13	0	2010-01-31	36159	\N	38582
38691	GENERIC_DAY	13	2	2010-02-09	36159	\N	38582
37571	GENERIC_DAY	13	1	2010-02-11	37573	\N	38582
38686	GENERIC_DAY	13	0	2010-02-20	37573	\N	38582
38701	GENERIC_DAY	13	1	2010-02-02	37573	\N	38582
38705	GENERIC_DAY	13	0	2010-01-30	36159	\N	38582
38696	GENERIC_DAY	13	1	2010-02-09	37573	\N	38582
38704	GENERIC_DAY	13	0	2010-02-13	37573	\N	38582
38694	GENERIC_DAY	13	2	2010-02-01	36159	\N	38582
38690	GENERIC_DAY	13	2	2010-02-03	36159	\N	38582
38685	GENERIC_DAY	13	2	2010-01-26	36159	\N	38582
38684	GENERIC_DAY	13	2	2010-02-04	36159	\N	38582
37569	GENERIC_DAY	13	2	2010-01-27	36159	\N	38582
38692	GENERIC_DAY	13	1	2010-02-12	37573	\N	38582
38689	GENERIC_DAY	13	0	2010-02-21	36159	\N	38582
45753	GENERIC_DAY	6	0	2010-02-01	36159	\N	41069
45783	GENERIC_DAY	6	0	2010-01-14	36159	\N	41069
45758	GENERIC_DAY	6	1	2010-01-22	40199	\N	41069
45781	GENERIC_DAY	6	0	2010-01-30	36159	\N	41069
45818	GENERIC_DAY	6	0	2010-01-23	37573	\N	41069
45794	GENERIC_DAY	6	0	2010-01-17	40199	\N	41069
45791	GENERIC_DAY	6	1	2010-01-21	36159	\N	41069
45811	GENERIC_DAY	6	0	2010-02-05	36159	\N	41069
45754	GENERIC_DAY	6	0	2010-01-31	37573	\N	41069
45764	GENERIC_DAY	6	0	2010-01-22	36159	\N	41069
45770	GENERIC_DAY	6	0	2010-01-31	36159	\N	41069
45755	GENERIC_DAY	6	0	2010-02-07	40199	\N	41069
45756	GENERIC_DAY	6	0	2010-02-06	40199	\N	41069
45772	GENERIC_DAY	6	0	2010-02-05	40199	\N	41069
45787	GENERIC_DAY	6	1	2010-01-14	40199	\N	41069
30814	SPECIFIC_DAY	0	8	2010-01-08	1722	29807	\N
30815	SPECIFIC_DAY	0	0	2010-01-10	1722	29807	\N
30816	SPECIFIC_DAY	0	0	2010-01-09	1722	29807	\N
30817	SPECIFIC_DAY	0	8	2010-01-18	1722	29807	\N
30818	SPECIFIC_DAY	0	8	2010-01-11	1722	29807	\N
30819	SPECIFIC_DAY	0	8	2010-01-07	1722	29807	\N
30820	SPECIFIC_DAY	0	8	2010-01-12	1722	29807	\N
30821	SPECIFIC_DAY	0	8	2010-01-15	1722	29807	\N
30822	SPECIFIC_DAY	0	8	2010-01-14	1722	29807	\N
30823	SPECIFIC_DAY	0	8	2010-01-13	1722	29807	\N
30824	SPECIFIC_DAY	0	0	2010-01-17	1722	29807	\N
30825	SPECIFIC_DAY	0	0	2010-01-16	1722	29807	\N
38723	GENERIC_DAY	6	0	2010-02-27	36159	\N	38583
38726	GENERIC_DAY	6	5	2010-03-08	37573	\N	38583
38727	GENERIC_DAY	6	5	2010-03-10	37573	\N	38583
38724	GENERIC_DAY	6	5	2010-03-04	37573	\N	38583
38722	GENERIC_DAY	6	0	2010-02-27	37573	\N	38583
38729	GENERIC_DAY	6	4	2010-03-15	37573	\N	38583
38728	GENERIC_DAY	6	5	2010-03-02	37573	\N	38583
38719	GENERIC_DAY	6	4	2010-02-23	37573	\N	38583
38721	GENERIC_DAY	6	0	2010-03-06	37573	\N	38583
38720	GENERIC_DAY	6	3	2010-03-04	36159	\N	38583
38718	GENERIC_DAY	6	4	2010-02-25	37573	\N	38583
38717	GENERIC_DAY	6	0	2010-03-13	37573	\N	38583
38725	GENERIC_DAY	6	3	2010-03-10	36159	\N	38583
45751	GENERIC_DAY	6	0	2010-02-01	37573	\N	41069
45761	GENERIC_DAY	6	0	2010-01-30	40199	\N	41069
45789	GENERIC_DAY	6	1	2010-01-15	40199	\N	41069
45785	GENERIC_DAY	6	0	2010-02-09	37573	\N	41069
45769	GENERIC_DAY	6	0	2010-01-24	40199	\N	41069
45782	GENERIC_DAY	6	0	2010-02-10	37573	\N	41069
45810	GENERIC_DAY	6	0	2010-02-07	37573	\N	41069
45775	GENERIC_DAY	6	0	2010-01-13	37573	\N	41069
45757	GENERIC_DAY	6	1	2010-01-27	40199	\N	41069
45808	GENERIC_DAY	6	0	2010-01-29	40199	\N	41069
45793	GENERIC_DAY	6	0	2010-01-16	40199	\N	41069
45816	GENERIC_DAY	6	0	2010-02-02	37573	\N	41069
45777	GENERIC_DAY	6	1	2010-01-19	36159	\N	41069
45790	GENERIC_DAY	6	0	2010-02-11	37573	\N	41069
45795	GENERIC_DAY	6	0	2010-01-16	37573	\N	41069
45786	GENERIC_DAY	6	0	2010-01-25	37573	\N	41069
45763	GENERIC_DAY	6	0	2010-01-11	36159	\N	41069
45767	GENERIC_DAY	6	0	2010-01-26	37573	\N	41069
45780	GENERIC_DAY	6	0	2010-01-17	37573	\N	41069
45809	GENERIC_DAY	6	0	2010-01-11	40199	\N	41069
45779	GENERIC_DAY	6	0	2010-01-20	36159	\N	41069
45762	GENERIC_DAY	6	0	2010-01-30	37573	\N	41069
45768	GENERIC_DAY	6	0	2010-01-27	37573	\N	41069
45759	GENERIC_DAY	6	1	2010-01-13	36159	\N	41069
45812	GENERIC_DAY	6	0	2010-01-17	36159	\N	41069
45773	GENERIC_DAY	6	0	2010-01-24	37573	\N	41069
45817	GENERIC_DAY	6	0	2010-02-08	40199	\N	41069
45814	GENERIC_DAY	6	0	2010-02-05	37573	\N	41069
45776	GENERIC_DAY	6	0	2010-02-09	40199	\N	41069
45774	GENERIC_DAY	6	0	2010-02-02	36159	\N	41069
45778	GENERIC_DAY	6	1	2010-01-20	37573	\N	41069
45813	GENERIC_DAY	6	1	2010-01-11	37573	\N	41069
45752	GENERIC_DAY	6	0	2010-01-28	36159	\N	41069
45765	GENERIC_DAY	6	0	2010-01-15	37573	\N	41069
45815	GENERIC_DAY	6	0	2010-02-11	36159	\N	41069
45766	GENERIC_DAY	6	1	2010-01-28	37573	\N	41069
45760	GENERIC_DAY	6	0	2010-01-23	40199	\N	41069
45771	GENERIC_DAY	6	0	2010-02-08	37573	\N	41069
45792	GENERIC_DAY	6	0	2010-01-29	36159	\N	41069
45784	GENERIC_DAY	6	0	2010-01-23	36159	\N	41069
38731	GENERIC_DAY	6	0	2010-02-28	36159	\N	38583
38755	GENERIC_DAY	6	5	2010-03-11	37573	\N	38583
38748	GENERIC_DAY	6	4	2010-02-23	36159	\N	38583
38740	GENERIC_DAY	6	5	2010-03-05	37573	\N	38583
38760	GENERIC_DAY	6	3	2010-03-09	36159	\N	38583
38754	GENERIC_DAY	6	0	2010-03-07	36159	\N	38583
38758	GENERIC_DAY	6	5	2010-02-22	37573	\N	38583
38749	GENERIC_DAY	6	3	2010-03-12	36159	\N	38583
38738	GENERIC_DAY	6	4	2010-02-26	37573	\N	38583
38750	GENERIC_DAY	6	5	2010-03-01	37573	\N	38583
38739	GENERIC_DAY	6	0	2010-03-07	37573	\N	38583
38743	GENERIC_DAY	6	2	2010-03-15	36159	\N	38583
38737	GENERIC_DAY	6	0	2010-02-28	37573	\N	38583
38751	GENERIC_DAY	6	4	2010-02-24	36159	\N	38583
30826	GENERIC_DAY	3	3	2010-03-29	1724	\N	29808
30827	GENERIC_DAY	3	3	2010-04-02	1724	\N	29808
30828	GENERIC_DAY	3	3	2010-02-26	1724	\N	29808
30829	GENERIC_DAY	3	3	2010-02-11	1724	\N	29808
30830	GENERIC_DAY	3	2	2010-04-14	1724	\N	29808
30831	GENERIC_DAY	3	3	2010-03-16	1724	\N	29808
30832	GENERIC_DAY	3	3	2010-02-15	1724	\N	29808
30833	GENERIC_DAY	3	3	2010-03-22	1724	\N	29808
30834	GENERIC_DAY	3	3	2010-01-27	1724	\N	29808
30835	GENERIC_DAY	3	3	2010-01-13	1724	\N	29808
30836	GENERIC_DAY	3	3	2010-02-09	1724	\N	29808
30837	GENERIC_DAY	3	3	2010-02-23	1724	\N	29808
30838	GENERIC_DAY	3	3	2010-02-22	1724	\N	29808
30839	GENERIC_DAY	3	3	2010-03-18	1724	\N	29808
30840	GENERIC_DAY	3	2	2010-04-06	1724	\N	29808
30841	GENERIC_DAY	3	3	2010-03-08	1724	\N	29808
30842	GENERIC_DAY	3	3	2010-03-04	1724	\N	29808
30843	GENERIC_DAY	3	3	2010-03-19	1724	\N	29808
30844	GENERIC_DAY	3	0	2010-02-28	1724	\N	29808
30845	GENERIC_DAY	3	3	2010-03-15	1724	\N	29808
30846	GENERIC_DAY	3	3	2010-03-01	1724	\N	29808
30847	GENERIC_DAY	3	0	2010-01-16	1724	\N	29808
24498	GENERIC_DAY	4	11	2009-11-03	1727	\N	3955
24509	GENERIC_DAY	4	10	2010-01-19	1727	\N	3955
24504	GENERIC_DAY	4	10	2010-01-11	1727	\N	3955
24499	GENERIC_DAY	4	10	2009-12-15	1727	\N	3955
24493	GENERIC_DAY	4	10	2010-01-18	1727	\N	3955
24497	GENERIC_DAY	4	10	2010-01-14	1727	\N	3955
24508	GENERIC_DAY	4	10	2009-11-19	1727	\N	3955
24496	GENERIC_DAY	4	2	2009-11-21	1727	\N	3955
24494	GENERIC_DAY	4	2	2009-11-07	1727	\N	3955
24500	GENERIC_DAY	4	2	2010-01-01	1727	\N	3955
24510	GENERIC_DAY	4	10	2009-12-10	1727	\N	3955
24502	GENERIC_DAY	4	2	2009-12-12	1727	\N	3955
24505	GENERIC_DAY	4	10	2010-01-25	1727	\N	3955
24501	GENERIC_DAY	4	10	2009-12-17	1727	\N	3955
24512	GENERIC_DAY	4	10	2010-02-11	1727	\N	3955
30848	GENERIC_DAY	3	2	2010-04-16	1724	\N	29808
30849	GENERIC_DAY	3	0	2010-02-14	1724	\N	29808
30850	GENERIC_DAY	3	0	2010-01-31	1724	\N	29808
30851	GENERIC_DAY	3	3	2010-01-26	1724	\N	29808
30852	GENERIC_DAY	3	3	2010-01-14	1724	\N	29808
30853	GENERIC_DAY	3	3	2010-02-18	1724	\N	29808
30854	GENERIC_DAY	3	3	2010-03-26	1724	\N	29808
30855	GENERIC_DAY	3	0	2010-02-20	1724	\N	29808
30856	GENERIC_DAY	3	3	2010-02-03	1724	\N	29808
30857	GENERIC_DAY	3	0	2010-02-13	1724	\N	29808
30858	GENERIC_DAY	3	3	2010-03-03	1724	\N	29808
30859	GENERIC_DAY	3	2	2010-04-09	1724	\N	29808
30860	GENERIC_DAY	3	0	2010-03-28	1724	\N	29808
30861	GENERIC_DAY	3	0	2010-04-17	1724	\N	29808
45801	GENERIC_DAY	6	0	2010-01-24	36159	\N	41069
45796	GENERIC_DAY	6	0	2010-02-08	36159	\N	41069
45797	GENERIC_DAY	6	0	2010-02-10	36159	\N	41069
45800	GENERIC_DAY	6	0	2010-01-20	40199	\N	41069
45798	GENERIC_DAY	6	0	2010-02-11	40199	\N	41069
45807	GENERIC_DAY	6	0	2010-02-02	40199	\N	41069
45804	GENERIC_DAY	6	0	2010-02-06	37573	\N	41069
45805	GENERIC_DAY	6	0	2010-01-12	40199	\N	41069
45806	GENERIC_DAY	6	0	2010-01-21	37573	\N	41069
45802	GENERIC_DAY	6	0	2010-01-18	40199	\N	41069
45799	GENERIC_DAY	6	0	2010-02-03	37573	\N	41069
45803	GENERIC_DAY	6	0	2010-01-14	37573	\N	41069
47797	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077
47798	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077
47799	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077
47800	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077
47801	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077
47802	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077
47803	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077
47804	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077
47805	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077
47806	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077
47807	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077
47808	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077
47809	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077
47810	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077
47811	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077
47812	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077
47813	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077
47814	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077
47815	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077
47816	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077
47817	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077
47818	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013
47819	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013
47820	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013
47821	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013
47822	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013
47823	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013
47824	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013
47825	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013
47826	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013
47827	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013
47828	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013
47829	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013
47830	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013
47831	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013
47832	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013
47833	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013
47834	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013
47835	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013
47836	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013
47837	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013
47838	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013
47839	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013
47840	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013
47841	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013
47842	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013
47843	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013
47844	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013
47845	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013
47846	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013
47847	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013
47848	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013
47849	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013
47850	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013
47851	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013
47852	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013
47853	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013
47854	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013
47855	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013
47856	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013
47857	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013
47858	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013
47859	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013
47860	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013
47861	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013
47862	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013
47863	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013
47864	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013
47865	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013
47866	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013
47867	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013
47868	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013
47869	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013
47870	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013
47871	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013
47872	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013
47873	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013
47874	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013
47875	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013
47876	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013
47877	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013
47878	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013
47879	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013
47880	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013
47881	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013
47882	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013
47883	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013
47884	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013
47885	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013
47886	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013
47887	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013
47888	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013
47889	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013
47890	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013
47891	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013
47892	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013
47893	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013
47894	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013
47895	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013
47896	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013
47020	GENERIC_DAY	6	2	2010-01-26	37573	\N	41076
47021	GENERIC_DAY	6	0	2010-01-26	36159	\N	41076
47014	GENERIC_DAY	6	4	2010-01-26	40199	\N	41076
47019	GENERIC_DAY	6	1	2010-01-28	40199	\N	41076
47017	GENERIC_DAY	6	2	2010-01-27	40199	\N	41076
47016	GENERIC_DAY	6	1	2010-01-28	36159	\N	41076
47897	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013
47898	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013
47899	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013
47900	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013
47901	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013
47902	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013
47903	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013
47904	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
9273344	6	27876	27878	0
13271342	18	40109	40101	0
2523137	12	1222	1223	0
2523136	12	1221	1222	0
2752524	7	3137	3150	0
2752535	7	3137	3150	0
2752514	7	3137	3150	0
2752520	7	3137	3150	0
2129932	13	1218	1219	0
2752515	7	3131	3151	0
2752525	7	3131	3151	0
2752536	7	3131	3151	0
1245231	8	3132	3131	0
1245234	8	3132	3131	0
1245229	8	3133	3137	0
1245232	8	3133	3137	0
1245230	8	3136	3133	0
1245233	8	3136	3133	0
2752521	7	3131	3151	0
2129927	5	3141	3142	0
2129929	5	3139	3140	0
2129928	5	3139	3142	0
13271320	16	40109	40101	0
13271307	18	40099	40100	0
13271083	18	40099	40100	0
1245205	7	1212	1214	0
1245192	7	1212	1214	0
1245206	6	1214	1216	0
1245191	7	1215	1213	0
1245204	7	1215	1213	0
13271316	18	40099	40100	0
13271300	18	40102	40099	0
12582947	2	36769	36771	0
13271076	18	40102	40099	0
12582948	2	36769	36771	0
13271309	18	40102	40099	0
13271306	18	40100	40110	0
13271315	18	40100	40110	0
13271082	18	40100	40110	0
13271321	16	40109	40108	0
12582924	13	36771	38389	0
12582946	5	36766	36769	0
12582932	8	36768	36766	0
12582941	8	36768	36766	0
12582934	8	38380	38388	0
12582943	8	38380	38388	0
12582925	8	38380	38388	0
12582927	8	38380	38388	0
12582929	8	38380	38388	0
12582933	8	38388	36768	0
12582942	8	38388	36768	0
12582928	8	38388	36768	0
12582926	8	38388	36768	0
12582949	2	36769	36771	0
13271343	18	40109	40108	0
13271319	16	40109	40107	0
13271341	18	40109	40107	0
13271313	18	40106	40110	0
13271304	18	40106	40110	0
13271080	18	40106	40110	0
13271081	18	40110	40111	0
13271314	18	40110	40111	0
13271305	18	40110	40111	0
13271308	18	40102	40103	0
13271075	18	40102	40103	0
13271299	18	40102	40103	0
13271301	18	40103	40104	0
13271077	18	40103	40104	0
13271310	18	40103	40104	0
13271311	18	40104	40105	0
13271302	18	40104	40105	0
13271078	18	40104	40105	0
13271303	18	40105	40106	0
13271079	18	40105	40106	0
13271312	18	40105	40106	0
13271358	3	40111	40110	0
13271352	5	\N	\N	0
13271354	5	\N	\N	0
13271355	5	\N	\N	0
13271353	5	\N	\N	0
13271362	3	40110	40115	0
13271363	3	40111	40110	0
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
3636	Incidencias	Incidencia 
26664	incidencias	No indidencia...
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
3738	Incidencia	Ninguna destacada
3739	Incidencia	Nada...
3740	Incidencia	Nada...
7171	Incidencia	Retraso por causa de falta de material
7172	Incidencia	Nada que destacar
7173	Incidencia	Nada que destacar
8201	Incidencia	Non houbo
8202	Incidencia	Non houbo
8203	Incidencia	Non houbo
8204	Incidencia	Non houbo
8205	Incidencia	Perdemos 4 horas por tronada...
8206	Incidencia	Non houbo
8207	Incidencia	Non houbo
8208	Incidencia	Non houbo
17473	Incidencia	.
17474	Incidencia	.
17475	Incidencia	.
17476	Incidencia	.
17477	Incidencia	.
17478	Incidencia	.
17479	Incidencia	.
18887	Incidencia	No
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
3056	1022	100.00
3099	1126	100.00
3115	1127	100.00
3130	1128	100.00
6178	1129	100.00
6179	1130	100.00
6894	1180	100.00
6895	1181	100.00
6902	1182	100.00
16659	1150	100.00
16660	1151	100.00
16662	1152	100.00
16663	1153	100.00
6186	1154	100.00
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
3940
3950
3951
3952
3953
3955
3981
3982
3983
3984
3985
6367
6368
6369
8588
8589
19897
19898
19899
19901
24143
28093
29808
36966
38582
38583
38595
38596
38597
38598
38600
38601
41013
41014
41046
41047
41048
41050
41051
41052
41053
41054
41061
41065
41066
41067
41068
41069
41072
41073
41074
41075
41076
41077
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, index) FROM stdin;
2526	Incidencias	200	0
21109	incidencias	300	0
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
578
578
578
578
578
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
1414	1	10.00	2009-12-07	2010-12-07	1217	1313
1415	1	15.00	2009-12-07	2010-12-07	1212	1313
20907	1	10.00	2010-01-02	\N	1217	1315
1419	3	15.00	2009-12-07	\N	1212	1315
1418	3	10.00	2009-12-07	2010-01-01	1217	1315
31815	2	30.00	2009-12-10	\N	31714	1314
1417	3	8.00	2009-12-07	2010-12-07	1217	1314
1416	3	15.00	2009-12-07	2010-12-07	1212	1314
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, name, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line) FROM stdin;
32933	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	32832
27790	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	27604
27791	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	430	1.00	f	27606
27792	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	27607
27793	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27608
27794	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27609
1435	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1356
1436	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1358
35980	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	35791
2863	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	1.00	f	1150
2864	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	300	1.00	f	1151
1437	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1359
1438	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	110	1.00	f	1362
2865	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1152
2866	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1153
2867	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	140	1.00	f	1154
1439	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1363
1440	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	1364
1441	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1365
1855	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
1856	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
35981	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	35792
32932	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	32831
29507	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	29321
29508	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29323
29509	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29324
29510	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29325
29511	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29326
2880	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1180
1891	5	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	0.50	f	1180
2881	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	350	1.00	f	1181
2882	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1182
2883	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1183
2843	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1126
1457	10	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
2844	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
32983	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	32884
2845	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1128
2846	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
2847	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
35982	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35793
35986	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35797
38282	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	38080
50511	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50387
35983	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35794
35984	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	126	1.00	f	35795
35985	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35796
35987	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35798
50512	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50388
50513	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50389
40045	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39885
40046	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	39886
40047	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39887
40035	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39872
40036	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39873
40037	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39875
40038	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	39876
40039	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39878
40040	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	11	1.00	f	39879
40041	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39880
40042	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39881
40043	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39882
40044	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39884
50555	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50644
50556	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50645
50557	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50647
50558	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50649
50559	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50651
50560	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50652
50561	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50653
50562	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50654
50563	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50655
50564	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50656
50565	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50657
50566	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50658
50567	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50659
50518	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50395
50519	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50396
50521	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50601
50522	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	84	1.00	f	50602
50568	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50660
50569	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50661
50570	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50662
50189	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	50361
50190	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50362
50191	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50363
50192	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50364
50575	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50670
50576	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50671
50193	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50366
50517	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50394
50194	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	49	1.00	f	50367
50195	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	50368
50196	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50370
50500	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50372
50501	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50373
50502	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	50374
50503	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50375
50504	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50377
50505	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50379
50506	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50381
50507	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50382
50508	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50383
50509	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50385
50510	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50386
50514	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50390
50515	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	105	1.00	f	50392
50516	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50393
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
303	8	0
303	8	1
303	8	2
303	8	3
303	8	4
303	0	5
303	0	6
26361	8	0
31916	24	0
31916	24	1
31916	24	2
31916	24	3
31916	24	4
31916	0	5
31916	0	6
36362	7	0
36362	7	1
36362	7	2
36362	7	3
36362	7	4
49498	7	0
49498	7	1
49498	7	2
49498	7	3
49498	7	4
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
16661	1149
2932	1149
6187	1035
27689	27605
27690	27603
2945	1179
6896	1179
29406	29322
29407	29320
35867	35766
3052	1357
3053	1361
3054	1360
3042	1325
2739	1022
3100	1022
49251	50360
49252	50371
49253	50376
49254	50378
49255	50380
39934	39874
39935	39877
39936	39883
39924	39823
49256	50384
49257	50391
49258	50398
49267	50643
49268	50646
49269	50648
49270	50650
49273	50669
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
912	18	Vulcano	809
910	1	Cubierta	808
911	1	Motores	808
914	1	1 (Bajo)	810
916	1	2 (Medio)	810
913	17	Navantia	809
909	7	Bodega	808
915	9	3 (Alto)	810
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
808	1	Zonas
809	1	Cliente
810	1	Riesgo
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, index) FROM stdin;
2527	Incidencias2	201	0
2525	Incidencia	200	0
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
7272	pleg2	Plegadora A	Pleg. Desc.
1727	cod2	Torno A	Desc
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
1919	107
26462	107
21614	108
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
26563	4	2009-12-09 23:57:32.242	2009-12-25 00:00:00	26462	1726
32017	1	2009-12-10 17:14:26.615	2010-12-10 00:00:00	21614	1718
21513	4	2009-12-09 10:26:10.315	\N	1919	1724
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
26462	4	New configuration unit	0.50	7272
21614	4	New configuration unit	0.25	1727
1919	6	Seleccion de criterios	1.00	1727
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
1121	6	cod1.1	tubo 3/4 pulgadas	6.00	3	f	1023
1123	7	cod2.2	Tubos 20mm	7.00	3	f	1022
1122	7	cod2.1	Tubos 12mm	6.50	3	f	1022
1124	7	cod3.1	Tornillos hexagonales	0.45	3	f	1024
25856	2	cod3.1.1	Tornillos 304	55.00	3	f	1024
1125	8	cod3	Tornillo 304	0.50	\N	f	1021
31613	1	kjgkjhg	gfdhgfd	5.00	3	f	31512
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, estimated_availability, status, order_element_id, material_id) FROM stdin;
20829	3	2	0.45	2009-12-07 16:23:24.094	0	1325	1124
20828	3	5	0.50	2009-12-07 16:23:24.094	1	1325	1125
20825	3	0	6.00	2009-12-07 16:23:24.094	1	1325	1121
20826	3	2	0.45	2009-12-07 16:23:24.094	1	1325	1124
20827	3	0	6.50	2009-12-07 16:23:24.094	1	1325	1122
20824	3	6	7.00	2009-12-07 16:23:24.094	1	1325	1123
20881	2	0	6.50	\N	1	1356	1122
20882	2	0	7.00	\N	1	1356	1123
20883	2	0	6.00	\N	1	1356	1121
3549	6	6	0.50	2009-12-07 13:59:19.527	1	1022	1125
3548	6	8	6.50	2009-12-07 13:59:19.527	1	1022	1122
3547	6	10	6.00	2009-12-07 13:59:19.527	1	1022	1121
25964	4	0	3.00	2009-11-02 00:00:00	0	1035	1121
25971	3	0	55.00	2009-11-02 00:00:00	1	1035	25856
25972	3	0	6.50	2009-11-02 00:00:00	1	1035	1122
25963	4	0	3.00	2009-11-02 00:00:00	2	1035	1121
25983	2	0	7.00	\N	0	1152	1123
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
1020	8	Tubos	\N
1023	7	Cemento	1020
1022	7	Acero	1020
1021	8	Tornillos	\N
1024	7	Hexagonales	1021
31512	1	exemplo	1024
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password) FROM stdin;
48985	2	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e
48986	1	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
1022	913
1127	909
1127	915
1128	915
1035	912
1130	915
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, base_calendar_id) FROM stdin;
1325	Xavi	...	t	202
1022	Xavi	...	t	202
1035	Xavi	\N	t	202
27603	Xavi.	\N	t	202
29320	Responsable	Cliente	t	202
32883	asdf	\N	t	202
35766	Xavier Castaño García	\N	t	202
39823	Xavier Castaño	\N	t	36260
1179	Xavi	\N	t	202
49125	Xavi	Xunta de Galicia	t	36260
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, initdate, deadline, mandatoryinit, mandatoryend, description, code, schedulingstatetype, parent, positionincontainer) FROM stdin;
27609	5	Exemplo6	\N	\N	f	f	\N	ped5.6	4	27603	3
1325	7	Contratación de muebles habitaciones	2009-12-07 16:23:24.094	2010-05-07 00:00:00	f	f	Desc.	ped4	4	\N	\N
1356	6	Tarefa1	\N	\N	f	f	\N	ped4.1	0	1325	0
1035	20	Contratación de pintado de casco	2009-11-02 00:00:00	2010-03-25 00:00:00	f	f	Desc.	ped2	3	\N	\N
1149	19	Coordinación	\N	\N	f	f	\N	ped2.1	3	1035	0
1150	19	Reuniones seguimiento 	\N	\N	f	f	\N	ped2.2	0	1149	0
1151	19	Seguimiento proyecto	\N	\N	f	f	\N	ped2.3	0	1149	1
1152	19	Montaje andamios	\N	\N	f	f	\N	ped2.4	0	1035	1
1153	19	Pintado cubierta	\N	\N	f	f	\N	ped2.5	0	1035	2
1154	19	Desmontaje andamios	\N	\N	f	f	\N	ped2.6	0	1035	3
1357	6	Tarefa2	\N	\N	f	f	\N	ped4.2	0	1325	1
1358	6	Subtarefa1.1	\N	\N	f	f	\N	ped4.3	1	1357	0
1359	6	Subtarefa1.2	\N	\N	f	f	\N	ped4.4	1	1357	1
1360	6	Tarefa3	\N	\N	f	f	\N	ped4.5	2	1325	2
1361	6	Subtarefa3.1	\N	\N	f	f	\N	ped4.6	2	1360	0
1362	6	Subsubtarefa3.1.1	\N	\N	f	f	\N	ped4.7	0	1361	0
1363	6	Subsubtarefa3.1.2	\N	\N	f	f	\N	ped4.8	4	1361	1
1364	6	Tarefa4	\N	\N	f	f	\N	ped4.9	0	1325	3
1365	6	Tarefa5	\N	\N	f	f	\N	ped4.10	0	1325	4
1022	22	Contratación de motores	2009-12-07 13:59:19.527	2009-12-25 00:00:00	f	f	Desc	ped1	4	\N	\N
1126	21	Adquisición de piezas	\N	\N	f	f	\N	ped1.1	0	1022	0
1179	7	Entrega de hélices	2009-12-07 16:12:52.395	2009-12-25 00:00:00	f	f	Desc.	ped3	4	\N	\N
1180	7	Tarea1	\N	\N	f	f	\N	ped3.1	0	1179	0
1127	21	Montaje piezas	\N	\N	f	f	\N	ped1.2	0	1022	1
1128	21	Prueba del motor	\N	\N	f	f	\N	ped1.3	0	1022	2
1129	21	Instalación de motor	\N	\N	f	f	\N	ped1.4	0	1022	3
1130	21	Validación funcionamiento	\N	\N	f	f	\N	ped1.5	0	1022	4
32832	3	Nuevo elemento de pedido	\N	\N	f	f	\N	hhhhh	4	29320	5
1181	7	Tarea2	\N	\N	f	f	\N	ped3.2	0	1179	1
1182	7	Tarea3	\N	\N	f	f	\N	ped3.3	0	1179	2
1183	7	Tarea4	\N	\N	f	f	\N	ped3.4	0	1179	3
35766	11	Portal web para Hospital Modelo	2010-01-22 00:00:00	2010-03-26 00:00:00	f	f	Desarrollo de un portal web para el Hospital Modelo de A Coruña	eng-typo3-17128	4	\N	\N
35797	10	Entorno	\N	\N	f	f	\N	ent	0	35766	7
38080	6	Diseño gráfico	\N	\N	f	f	\N	dis	0	35766	8
29320	5	Pedido de exemplo 2	2009-12-10 01:15:12.433	2010-04-16 00:00:00	f	f	Desc.	ped6	2	\N	\N
29321	5	Exemplo11	\N	\N	f	f	\N	ped6.1	0	29320	0
29322	5	Exemplo12	\N	\N	f	f	\N	ped6.2	3	29320	1
27603	5	Pedido de exemplo 	2009-12-10 00:10:01.713	2010-04-15 00:00:00	f	f	...	ped5	2	\N	\N
27604	5	Exemplo1	\N	\N	f	f	\N	ped5.1	4	27603	0
27605	5	Exemplo2	\N	\N	f	f	\N	ped5.2	2	27603	1
32883	4	pedido bug	2009-12-11 10:20:44.566	2010-01-01 00:00:00	f	f	asdf	codbug	3	\N	\N
32884	4	Exemplo	\N	\N	f	f	\N	codbug1	0	32883	0
27606	5	Exemplo3	\N	\N	f	f	\N	ped5.3	4	27605	0
27607	5	Exemplo4	\N	\N	f	f	\N	ped5.4	0	27605	1
27608	5	Exemplo5	\N	\N	f	f	\N	ped5.5	0	27603	2
35791	10	Coordinación	\N	\N	f	f	\N	coor	0	35766	0
35792	10	Análisis	\N	\N	f	f	\N	ana	0	35766	1
29323	5	Exemplo13	\N	\N	f	f	\N	ped6.3	0	29322	0
29324	5	Exemplo14	\N	\N	f	f	\N	ped6.4	0	29322	1
29325	5	Exemplo15	\N	\N	f	f	\N	ped6.5	0	29320	2
29326	5	Exemplo16	\N	\N	f	f	\N	ped6.6	4	29320	3
32831	3	Nuevo elemento de pedido	\N	\N	f	f	\N	jjjjj	4	29320	4
35793	10	Migración contenidos	\N	\N	f	f	\N	con	0	35766	2
35794	10	Módulo de usuarios	\N	\N	f	f	\N	usu	0	35766	3
35795	10	Plantillas y gestión de contenidos	\N	\N	f	f	\N	plant	0	35766	4
35796	10	Gestión de especialidades	\N	\N	f	f	\N	esp	0	35766	5
35798	10	Pruebas	\N	\N	f	f	\N	prue	0	35766	6
39823	9	Desenvolvemento dunha aplicación middleware para impresión de tickets	2009-12-14 00:00:00	2010-01-29 00:00:00	f	f	Desc.	eng-LAMP-17134	4	\N	\N
39872	8	Coordinación	\N	\N	f	f	\N	coor1	0	39823	0
39873	8	Análisis	\N	\N	f	f	\N	ana1	0	39823	1
39874	8	Módulo de comunicación con SEDA	\N	\N	f	f	\N	comseda1	3	39823	2
39875	8	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	\N	f	f	\N	comseda1.1	0	39874	0
39876	8	Implementación de páxina de impresión e fluxo de impresión	\N	\N	f	f	\N	comseda1.2	0	39874	1
39877	8	Módulo de comunicación con JANTO	\N	\N	f	f	\N	comjanto1	3	39823	3
39878	8	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	\N	f	f	\N	comjanto1.1	0	39877	0
39879	8	Mecanismo de sesión e xestión de estado	\N	\N	f	f	\N	comjanto1.2	0	39877	1
39880	8	Obtención de listado de entrada pendentes	\N	\N	f	f	\N	comjanto1.3	0	39877	2
39881	8	Obtención de información para impresión de cada entrada	\N	\N	f	f	\N	comjanto1.4	0	39877	3
39882	8	Notificación de resultado de impresión de entrada	\N	\N	f	f	\N	comjanto1.5	0	39877	4
39883	8	Entorno	\N	\N	f	f	\N	ent1	3	39823	4
39884	8	Gestión de respositorios – Integración	\N	\N	f	f	\N	ent1.1	0	39883	0
39885	8	Montaje entorno de trabajo	\N	\N	f	f	\N	ent1.2	0	39883	1
39886	8	Implantación en producción	\N	\N	f	f	\N	ent1.3	0	39883	2
50643	9	Módulo de arquitectura tecnolóxica	\N	\N	f	f	\N	arq42	3	49125	10
50644	9	Enlazar a axuda de usuario	\N	\N	f	f	\N	arq43	0	50643	0
50645	9	Desenvolvemento de paquetes  Ubuntu	\N	\N	f	f	\N	arq44	0	50643	1
50646	9	Módulo de documentación de API	\N	\N	f	f	\N	doc45	3	49125	11
50647	9	Documentación das API's públicas	\N	\N	f	f	\N	doc46	0	50646	0
50648	9	Módulo de arquivo histórico	\N	\N	f	f	\N	his47	3	49125	12
50649	9	Pasar pedidos a histórico	\N	\N	f	f	\N	his48	0	50648	0
50650	9	Módulo de extracción de informes	\N	\N	f	f	\N	inf49	3	49125	13
50651	9	Integración de Jasper Reports	\N	\N	f	f	\N	inf50	0	50650	0
50652	9	Informes sobre organizacións de traballo	\N	\N	f	f	\N	inf51	0	50650	1
50653	9	Informe sobre partes de traballo	\N	\N	f	f	\N	inf52	0	50650	2
39887	8	Pruebas	\N	\N	f	f	\N	ent1.4	0	39823	5
49125	12	Proxecto para o desenvolvemento dun sistema de xestión da produción para o sector do auxiliar do naval	2009-12-14 00:00:00	2010-01-30 00:00:00	f	f	\N	eng-java-16062	4	\N	\N
50654	9	Informes de horas traballadas por un traballador	\N	\N	f	f	\N	inf53	0	50650	3
50655	9	Lista de avances de planificación da empresa	\N	\N	f	f	\N	inf54	0	50650	4
50656	9	Lista de avances de traballo da empresa	\N	\N	f	f	\N	inf55	0	50650	5
50657	9	Informe de horas estimadas/horas realizadas	\N	\N	f	f	\N	inf56	0	50650	6
50658	9	Horas realizadas organizadas por tipo de traballo	\N	\N	f	f	\N	inf57	0	50650	7
50659	9	Horas estimadas/realizadas por tipo de traballo	\N	\N	f	f	\N	inf58	0	50650	8
50660	9	Informe de traballador indicando custos por hora	\N	\N	f	f	\N	inf59	0	50650	9
50661	9	Coordinación	\N	\N	f	f	\N	coor60	0	49125	14
50662	9	Análise	\N	\N	f	f	\N	ana61	0	49125	15
50360	10	Módulo de xestión de usuarios	\N	\N	f	f	\N	user1	3	49125	0
50361	10	Xestión de usuarios	\N	\N	f	f	\N	user2	0	50360	0
50362	10	Xestión de roles	\N	\N	f	f	\N	user3	0	50360	1
50363	10	Xestión de perfiles	\N	\N	f	f	\N	user4	0	50360	2
50364	10	Xestión de roles e pedidos	\N	\N	f	f	\N	user5	0	50360	3
50365	10	Módulo de organización do traballo	\N	\N	f	f	\N	org6	3	49125	1
50366	10	Xestión de código único	\N	\N	f	f	\N	org7	0	50365	0
50367	10	Revisión formulario de pedidos	\N	\N	f	f	\N	org8	0	50365	1
50368	10	Filtrado no listado de pedidos	\N	\N	f	f	\N	org9	0	50365	2
50369	10	Módulo de recursos	\N	\N	f	f	\N	rec10	3	49125	2
50370	10	Recursos Virtuais	\N	\N	f	f	\N	rec11	0	50369	0
50371	10	Módulo de planificación	\N	\N	f	f	\N	plan12	3	49125	3
50372	10	Compartir estado entre pestanas planificación	\N	\N	f	f	\N	plan13	0	50371	0
50373	10	Técnica de recálculo de planificación	\N	\N	f	f	\N	plan14	0	50371	1
50374	10	Filtrado de pedidos e tarefas de un pedido	\N	\N	f	f	\N	plan15	0	50371	2
50669	7	Módulo de asignación de recursos	\N	\N	f	f	\N	asig38	3	49125	16
50670	7	Interpolación polinómica na asignación avanzada	\N	\N	f	f	\N	asig62	0	50669	0
50671	7	Asignación automática de configuración de máquina	\N	\N	f	f	\N	asig63	0	50669	1
50384	10	Módulo de integración con subcontratas	\N	\N	f	f	\N	sub25	3	49125	7
50385	10	Administración de subcontratas	\N	\N	f	f	\N	sub26	0	50384	0
50386	10	Formato de intercambio	\N	\N	f	f	\N	sub27	0	50384	1
50387	10	Fluxo de importación/exportación	\N	\N	f	f	\N	sub28	0	50384	2
50388	10	Interfaz de xestión de subcontración nos pedidos	\N	\N	f	f	\N	sub29	0	50384	3
50389	10	Converter en fitos subcontratacións	\N	\N	f	f	\N	sub30	0	50384	4
50390	10	Avance e custo de subcontratas en Técnica de Valor Gañado	\N	\N	f	f	\N	sub31	0	50384	5
50391	10	Módulo de Exportación-Importación	\N	\N	f	f	\N	imp32	3	49125	8
50392	10	Definir workflows ERP pedidos	\N	\N	f	f	\N	imp33	0	50391	0
50393	10	Formato de intercambio de pedidos  e elementos de pedido	\N	\N	f	f	\N	imp34	0	50391	1
50394	10	Formato de intercambio de información de avances	\N	\N	f	f	\N	imp35	0	50391	2
50395	10	Formato de intercambio de recursos	\N	\N	f	f	\N	imp36	0	50391	3
50396	10	Formato de intercambio de materiais	\N	\N	f	f	\N	imp37	0	50391	4
50398	10	Módulo de presentación	\N	\N	f	f	\N	pres39	3	49125	9
50601	10	Imprimir o diagrama de Gantt en varias páxinas	\N	\N	f	f	\N	pres40	0	50398	0
50602	10	Imprimir información de pantalla  do planificador	\N	\N	f	f	\N	pres41	0	50398	1
50375	10	Modelos de pedidos e planificación	\N	\N	f	f	\N	plan16	0	50371	3
50376	10	Módulo de partes de traballo	\N	\N	f	f	\N	part17	3	49125	4
50377	10	Procura de partes de traballo	\N	\N	f	f	\N	part18	0	50376	0
50378	10	Módulo de materiais	\N	\N	f	f	\N	mat19	3	49125	5
50379	10	Informe de necesidades de materiais 	\N	\N	f	f	\N	mat20	0	50378	0
50380	10	Módulo de xestión da calidade	\N	\N	f	f	\N	cal21	3	49125	6
50381	10	Administración de checklists	\N	\N	f	f	\N	cal22	0	50380	0
50382	10	Cubrir formularios de calidade en planificación 	\N	\N	f	f	\N	cal23	0	50380	1
50383	10	Incorporar as listas de chequeo nos modelos de planificación	\N	\N	f	f	\N	cal24	0	50380	2
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid) FROM stdin;
1126
1127
1128
1129
1130
1150
1151
1152
1153
1154
1180
1181
1182
1183
1356
1358
1359
1362
1363
1364
1365
27604
27606
27607
27608
27609
29321
29323
29324
29325
29326
32831
32832
32884
35791
35792
35793
35794
35795
35796
35797
35798
38080
39872
39873
39875
39876
39878
39879
39880
39881
39882
39884
39885
39886
39887
50361
50362
50363
50364
50366
50367
50368
50370
50372
50373
50374
50375
50377
50379
50381
50382
50383
50385
50386
50387
50388
50389
50390
50392
50393
50394
50395
50396
50601
50602
50644
50645
50647
50649
50651
50652
50653
50654
50655
50656
50657
50658
50659
50660
50661
50662
50670
50671
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1022
1035
1149
1179
1325
1357
1360
1361
27603
27605
29320
29322
32883
35766
39823
39874
39877
39883
49125
50360
50365
50369
50371
50376
50378
50380
50384
50391
50398
50643
50646
50648
50650
50669
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, calendar) FROM stdin;
1720	2	206
1718	2	205
1724	5	208
1722	3	207
7272	6	7373
1726	7	209
1727	9	210
37575	2	37674
36159	2	36259
37573	2	37673
40199	3	40299
49300	1	49391
49302	1	49392
49304	1	49393
49289	3	49389
49309	1	49394
49297	3	49390
49313	1	49395
49315	2	49396
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
6367	3	1.00	3141	\N
6369	4	0.69	3139	24953
6368	4	0.50	3139	\N
19903	3	1.00	3140	\N
3984	6	0.69	3131	\N
3981	8	1.00	3133	\N
3985	8	1.00	3133	\N
8589	3	1.00	3136	\N
8588	3	1.00	3137	\N
3983	6	1.00	3132	\N
3982	6	1.00	3132	\N
41065	6	0.75	40099	\N
41074	6	0.75	40099	\N
41076	6	0.75	40099	\N
41072	6	0.75	40099	\N
3940	6	1.00	1212	\N
19901	3	1.00	1214	\N
3952	5	2.08	1213	\N
3951	5	2.08	1213	\N
3950	5	0.25	1216	\N
3953	5	1.00	1215	\N
41067	6	0.75	40099	\N
41075	6	0.75	40100	\N
41077	6	0.75	40100	\N
41073	6	0.75	40100	\N
41066	6	0.75	40100	\N
41068	6	0.75	40100	\N
41013	18	0.48	40108	\N
29807	0	1.00	29595	\N
29808	3	0.36	29593	\N
19898	3	1.00	1223	\N
19899	3	0.82	1221	\N
19897	3	1.00	1222	\N
3955	16	1.36	1218	\N
24143	4	0.87	1219	\N
28093	2	1.02	27878	\N
31014	3	1.00	27876	\N
41014	18	0.75	40109	\N
41050	14	1.00	40111	\N
41069	6	0.07	40098	\N
38596	3	0.11	36765	\N
38601	1	0.04	36770	\N
38595	3	1.00	36766	\N
38582	13	0.42	38380	\N
38597	3	1.00	36767	\N
38583	7	1.00	36768	\N
38600	2	0.44	36771	\N
38598	3	1.00	36769	\N
36966	17	0.09	36764	37371
41061	12	0.75	40103	\N
41051	14	0.75	40104	\N
41046	14	1.00	40104	\N
41052	14	0.75	40105	\N
41047	14	1.00	40105	\N
41048	14	1.00	40106	\N
41053	14	0.75	40106	\N
41054	10	0.11	40097	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id) FROM stdin;
205
206
207
208
209
210
7373
36259
37673
37674
40299
49389
49390
49391
49392
49393
49394
49395
49396
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, initdate, enddate, cost_category_id, resource_id) FROM stdin;
26058	1	2009-12-09	\N	1315	1724
21009	3	2009-12-09	2009-12-25	1314	1726
3434	5	2009-12-26	\N	1313	1726
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
19903	1724
29807	1722
31014	1720
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
4245	2009-12-08	0.10	0.20	0
4245	2009-12-12	0.40	0.55	1
4245	2009-12-15	0.60	0.80	2
4245	2009-12-20	1.00	1.00	3
24953	2009-12-10	0.10	0.05	0
24953	2009-12-12	0.20	0.15	1
24953	2009-12-20	0.50	0.45	2
24953	2010-01-01	1.00	1.00	3
37371	2010-02-16	0.40	0.10	0
37371	2010-03-26	1.00	1.00	1
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
4245
24953
37371
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate) FROM stdin;
1212	1	1	2009-11-28 16:06:06.476
1214	1	0	\N
1213	2	0	\N
1216	1	0	\N
1215	1	1	2009-12-15 02:35:46.838
40097	2	0	\N
40098	2	0	\N
40099	1	1	2010-01-26 06:00:00
40100	1	0	\N
40102	1	0	\N
40103	1	0	\N
40104	1	0	\N
40105	1	0	\N
40106	1	0	\N
40108	2	0	\N
40109	1	0	\N
40110	1	0	\N
40111	1	1	2010-02-05 04:48:00
58176	1	0	\N
58177	1	0	\N
58178	1	0	\N
58179	1	0	\N
58181	1	0	\N
3141	1	1	2010-02-26 03:54:19.558
3139	1	0	\N
3142	1	0	\N
3140	1	0	\N
58182	1	0	\N
58183	1	0	\N
58185	1	0	\N
58187	1	0	\N
27878	2	0	\N
27876	1	0	\N
58188	1	0	\N
58189	1	0	\N
33027	1	0	\N
33028	1	0	\N
29593	2	1	2010-01-11 12:05:14.108
29595	0	1	2010-01-07 20:25:18.472
33032	1	0	\N
1218	2	0	\N
1219	2	0	\N
1221	2	1	2009-12-18 18:15:42.474
1222	1	0	\N
1223	1	0	\N
58190	1	0	\N
58192	1	0	\N
58194	1	0	\N
58196	1	0	\N
58197	1	0	\N
58198	1	0	\N
58200	1	0	\N
58201	1	0	\N
58202	1	0	\N
58203	1	0	\N
58204	1	0	\N
58205	1	0	\N
58207	1	0	\N
3131	2	0	\N
3132	1	1	2010-03-01 19:34:15.194
3133	1	0	\N
3136	1	1	2010-02-07 21:34:41.378
3137	1	1	2010-04-09 05:03:29.372
58208	1	0	\N
58209	1	0	\N
58210	1	0	\N
58211	1	0	\N
58213	1	0	\N
58214	1	0	\N
58216	1	0	\N
58217	1	0	\N
36765	2	1	2010-01-20 21:07:33.24
36770	2	0	\N
36766	1	0	\N
38380	2	0	\N
36767	1	1	2010-02-18 22:17:25.42
36768	1	0	\N
36771	2	1	2010-03-19 04:15:21.12
36769	1	1	2010-03-16 03:11:51.036
36764	2	0	\N
58219	1	0	\N
58221	1	0	\N
58223	1	0	\N
58224	1	0	\N
58225	1	0	\N
58226	1	0	\N
58227	1	0	\N
58228	1	0	\N
58229	1	0	\N
58230	1	0	\N
58231	1	0	\N
58232	1	0	\N
58234	1	0	\N
58235	1	0	\N
58236	1	0	\N
58237	1	0	\N
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
1217	2847
1217	2846
1217	2844
1217	2843
1217	2845
1220	2863
1220	2864
36772	35987
36772	35986
1224	2863
1224	2864
1224	2865
1224	2866
1224	2867
36772	35983
36772	35981
36772	35982
36772	35985
36772	35984
36772	35980
3134	1439
3134	1438
3135	1439
3135	1438
3131	1435
3132	1436
3138	1439
3138	1435
3138	1438
3138	1440
3138	1441
3138	1436
3138	1437
3132	1437
3133	1438
3136	1440
3137	1441
3143	2881
3143	2880
3143	2883
3143	2882
1212	2843
3139	2880
3139	1891
3140	2881
3141	2882
3142	2883
1213	1457
1213	2844
1214	2845
1215	2846
1215	1855
1216	1856
1216	2847
40097	40035
40098	40036
40099	40037
40100	40038
40102	40039
1218	2863
1219	2864
1221	2865
1222	2866
1223	2867
40103	40040
27877	27792
27877	27791
40104	40041
27879	27792
27879	27793
27879	27794
27879	27791
27879	27790
40105	40042
40106	40043
40108	40044
40109	40045
40110	40046
40111	40047
58176	50189
58177	50190
58178	50191
58179	50192
58180	50189
58180	50190
58180	50191
58180	50192
58181	50193
27876	27792
27878	27793
58182	50194
29594	29509
29594	29508
58183	50195
29596	29511
29596	29507
29596	29510
29596	29509
29596	29508
58184	50193
36764	35980
36765	35981
36766	35982
33027	29507
29593	29508
33028	29509
29595	29510
36767	35983
33033	32983
33032	32983
36768	35984
36769	35985
36771	35987
36770	35986
38380	38282
58184	50194
58184	50195
58185	50196
58186	50196
40101	40038
40101	40037
58187	50500
58188	50501
58189	50502
58190	50503
58191	50500
40107	40043
40107	40041
40107	40040
40107	40039
40107	40042
58191	50501
58191	50502
58191	50503
58192	50504
40112	40045
40112	40046
40112	40044
40112	40047
40113	40045
40113	40043
40113	40040
40113	40046
40113	40039
40113	40037
40113	40036
40113	40041
40113	40038
40113	40044
40113	40035
40113	40047
40113	40042
58193	50504
58194	50505
58195	50505
58196	50506
58197	50507
58198	50508
58199	50507
58199	50508
58199	50506
58200	50509
58201	50510
58202	50511
58203	50512
58204	50513
58205	50514
58206	50513
58206	50514
58206	50510
58206	50509
58206	50512
58206	50511
58207	50515
58208	50516
58209	50517
58210	50518
58211	50519
58212	50515
58212	50519
58212	50517
58212	50518
58212	50516
58213	50521
58214	50522
58215	50522
58215	50521
58216	50555
58217	50556
58218	50555
58218	50556
58219	50557
58220	50557
58221	50558
58222	50558
58223	50559
58224	50560
58225	50561
58226	50562
58227	50563
58228	50564
58229	50565
58230	50566
58231	50567
58232	50568
58233	50568
58233	50563
58233	50562
58233	50565
58233	50564
58233	50566
58233	50560
58233	50561
58233	50559
58233	50567
58234	50569
58235	50570
58236	50575
58237	50576
58238	50576
58238	50575
58239	50563
58239	50196
58239	50501
58239	50194
58239	50517
58239	50518
58239	50192
58239	50521
58239	50505
58239	50568
58239	50569
58239	50195
58239	50565
58239	50566
58239	50509
58239	50516
58239	50570
58239	50564
58239	50506
58239	50561
58239	50513
58239	50189
58239	50500
58239	50507
58239	50576
58239	50504
58239	50502
58239	50575
58239	50522
58239	50193
58239	50514
58239	50558
58239	50557
58239	50510
58239	50562
58239	50556
58239	50191
58239	50503
58239	50512
58239	50190
58239	50555
58239	50515
58239	50508
58239	50519
58239	50560
58239	50559
58239	50511
58239	50567
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
3141	10	Tarea3	\N	2010-02-26 03:54:19.558	2010-03-11 03:54:19.558	\N	3143	\N	2
3139	11	Tarea1	\N	2009-12-07 16:12:52.395	2010-01-01 16:12:52.395	\N	3143	\N	0
3142	10	Tarea4	\N	2010-03-11 03:54:19.558	2010-03-23 15:54:19.558	\N	3143	\N	3
3140	11	Tarea2	\N	2010-01-01 16:12:52.395	2010-02-25 16:12:52.395	\N	3143	\N	1
3143	10	\N	\N	2009-12-07 16:12:52.395	2010-03-23 15:54:19.558	2009-12-25	\N	\N	\N
1212	27	Adquisición de piezas	\N	2009-12-07 13:59:19.527	2009-12-24 13:59:19.527	\N	1217	\N	0
1214	27	Prueba del motor	\N	2009-12-24 13:59:19.527	2010-02-18 13:59:19.527	\N	1217	\N	2
1213	27	Montaje piezas	\N	2010-01-08 02:35:46.838	2010-01-16 02:35:46.838	\N	1217	\N	1
1216	27	Validación funcionamiento	\N	2010-02-18 13:59:19.527	2010-03-25 13:59:19.527	\N	1217	\N	4
1215	27	Instalación de motor	\N	2009-12-15 02:35:46.838	2010-01-08 02:35:46.838	\N	1217	\N	3
1217	27	\N	\N	2009-12-07 13:59:19.527	2010-03-25 13:59:19.527	2009-12-25	\N	\N	\N
36769	26	Gestión de especialidades	\N	2010-03-17 00:00:00	2010-03-19 00:00:00	\N	36772	\N	5
1218	33	Reuniones seguimiento 	\N	2009-11-02 00:00:00	2010-02-27 00:00:00	\N	1220	\N	0
1219	33	Seguimiento proyecto	\N	2010-02-27 00:00:00	2010-04-29 00:00:00	\N	1220	\N	1
1220	32	Coordinación	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	\N	1224	\N	0
1221	33	Montaje andamios	\N	2009-12-18 18:15:42.474	2010-02-12 18:15:42.474	\N	1224	\N	1
1222	33	Pintado cubierta	\N	2010-02-12 18:15:42.474	2010-03-30 18:15:42.474	\N	1224	\N	2
1223	33	Desmontaje andamios	\N	2010-03-30 18:15:42.474	2010-04-23 18:15:42.474	\N	1224	\N	3
1224	32	\N	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	2010-03-25	\N	\N	\N
33032	3	\N	\N	\N	\N	\N	33033	\N	0
33033	3	\N	\N	\N	\N	2010-01-01	\N	\N	\N
36764	26	Coordinación	\N	2010-01-22 00:00:00	2010-03-26 00:00:00	\N	36772	\N	0
36772	26	\N	\N	2010-01-22 00:00:00	2010-03-26 15:02:48.34	2010-03-26	\N	\N	\N
40115	5	Entrega	\N	2010-02-12 15:36:00	2010-02-12 15:36:00	\N	40113	\N	5
3150	11	validacion previa	\N	2010-04-24 21:34:41.378	2010-04-24 21:34:41.378	\N	1224	\N	4
3131	12	Tarefa1	\N	2010-04-05 19:34:15.194	2010-04-23 19:34:15.194	\N	3138	\N	0
3132	12	Tarefa2	\N	2010-03-01 19:34:15.194	2010-04-05 19:34:15.194	\N	3138	\N	1
3133	12	Subsubtarefa3.1.1	\N	2010-03-29 21:34:41.378	2010-04-11 21:34:41.378	\N	3134	\N	0
27878	12	Exemplo5	\N	2010-01-16 00:10:01.713	2010-04-13 00:10:01.713	\N	27879	\N	1
27877	12	Exemplo2	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27879	\N	0
3151	11	entrega	\N	2010-04-23 19:34:15.194	2010-04-23 19:34:15.194	\N	1224	\N	5
27876	12	Exemplo4	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27877	\N	0
27879	12	\N	\N	2009-12-10 00:10:01.713	2010-04-13 00:10:01.713	2010-04-15	\N	\N	\N
36765	26	Análisis	\N	2010-01-22 00:00:00	2010-02-18 20:21:57.46	\N	36772	\N	1
38389	11	Entrega	\N	2010-03-26 15:02:48.34	2010-03-26 15:02:48.34	\N	36772	\N	10
36770	26	Entorno	\N	2010-01-22 00:00:00	2010-03-25 20:19:23.46	\N	36772	\N	6
3134	12	Subtarefa3.1	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3135	\N	0
3135	12	Tarefa3	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3138	\N	2
3136	12	Tarefa4	\N	2010-02-07 21:34:41.378	2010-03-29 21:34:41.378	\N	3138	\N	3
3137	12	Tarefa5	\N	2010-04-11 21:34:41.378	2010-04-24 21:34:41.378	\N	3138	\N	4
3138	12	\N	\N	2009-12-07 16:23:24.094	2010-04-24 21:34:41.378	2010-05-07	\N	\N	\N
36766	26	Migración contenidos	\N	2010-03-16 00:00:00	2010-03-17 00:00:00	\N	36772	\N	2
29593	6	Exemplo13	\N	2010-01-11 12:05:14.108	2010-04-19 12:05:14.108	\N	29594	\N	0
29594	6	Exemplo12	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	\N	29596	\N	0
29595	6	Exemplo15	\N	2010-01-07 20:25:18.472	2010-01-19 20:25:18.472	\N	29596	\N	1
29596	6	\N	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	2010-04-16	\N	\N	\N
38380	19	Diseño gráfico	\N	2010-01-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	8
36767	26	Módulo de usuarios	\N	2010-02-18 22:17:25.42	2010-02-19 22:17:25.42	\N	36772	\N	3
38388	11	Entrega de diseño	\N	2010-02-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	9
36768	26	Plantillas y gestión de contenidos	\N	2010-02-22 00:00:00	2010-03-16 00:00:00	\N	36772	\N	4
33027	2	\N	\N	\N	\N	\N	29596	\N	2
33028	2	\N	\N	\N	\N	\N	29594	\N	1
36771	26	Pruebas	\N	2010-03-19 04:15:21.12	2010-03-25 23:26:51.20	\N	36772	\N	7
40097	27	Coordinación	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	0
40098	27	Análisis	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	1
40099	27	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	2010-01-26 06:00:00	2010-01-29 06:00:00	\N	40101	\N	0
40100	27	Implementación de páxina de impresión e fluxo de impresión	\N	2010-01-29 06:00:00	2010-02-05 06:00:00	\N	40101	\N	1
40101	27	Módulo de comunicación con SEDA	\N	2010-01-14 00:00:00	2010-02-05 06:00:00	\N	40113	\N	2
40102	27	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	2010-01-14 00:00:00	2010-01-19 03:36:00	\N	40107	\N	0
40103	27	Mecanismo de sesión e xestión de estado	\N	2010-01-19 03:36:00	2010-01-21 03:36:00	\N	40107	\N	1
40104	27	Obtención de listado de entrada pendentes	\N	2010-01-21 03:36:00	2010-01-22 03:36:00	\N	40107	\N	2
40105	27	Obtención de información para impresión de cada entrada	\N	2010-01-22 03:36:00	2010-01-23 03:36:00	\N	40107	\N	3
40106	27	Notificación de resultado de impresión de entrada	\N	2010-01-23 03:36:00	2010-01-26 03:36:00	\N	40107	\N	4
40107	27	Módulo de comunicación con JANTO	\N	2010-01-14 00:00:00	2010-01-26 03:36:00	\N	40113	\N	3
40108	27	Gestión de respositorios – Integración	\N	2010-01-14 00:00:00	2010-02-12 00:00:00	\N	40112	\N	0
40109	27	Montaje entorno de trabajo	\N	2010-01-11 00:00:00	2010-01-14 00:00:00	\N	40112	\N	1
40110	27	Implantación en producción	\N	2010-02-10 19:12:00	2010-02-11 22:48:00	\N	40112	\N	2
40112	27	Entorno	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	4
40111	27	Prueba	\N	2010-02-05 04:48:00	2010-02-10 19:12:00	\N	40113	\N	6
40113	27	\N	\N	2010-01-11 00:00:00	2010-02-12 15:36:00	2010-02-12	\N	\N	\N
58176	2	\N	\N	\N	\N	\N	58180	\N	0
58177	2	\N	\N	\N	\N	\N	58180	\N	1
58178	2	\N	\N	\N	\N	\N	58180	\N	2
58179	2	\N	\N	\N	\N	\N	58180	\N	3
58180	2	\N	\N	\N	\N	\N	58239	\N	0
58181	2	\N	\N	\N	\N	\N	58184	\N	0
58182	2	\N	\N	\N	\N	\N	58184	\N	1
58183	2	\N	\N	\N	\N	\N	58184	\N	2
58184	2	\N	\N	\N	\N	\N	58239	\N	1
58185	2	\N	\N	\N	\N	\N	58186	\N	0
58186	2	\N	\N	\N	\N	\N	58239	\N	2
58187	2	\N	\N	\N	\N	\N	58191	\N	0
58188	2	\N	\N	\N	\N	\N	58191	\N	1
58189	2	\N	\N	\N	\N	\N	58191	\N	2
58190	2	\N	\N	\N	\N	\N	58191	\N	3
58191	2	\N	\N	\N	\N	\N	58239	\N	3
58192	2	\N	\N	\N	\N	\N	58193	\N	0
58193	2	\N	\N	\N	\N	\N	58239	\N	4
58194	2	\N	\N	\N	\N	\N	58195	\N	0
58195	2	\N	\N	\N	\N	\N	58239	\N	5
58196	2	\N	\N	\N	\N	\N	58199	\N	0
58197	2	\N	\N	\N	\N	\N	58199	\N	1
58198	2	\N	\N	\N	\N	\N	58199	\N	2
58199	2	\N	\N	\N	\N	\N	58239	\N	6
58200	2	\N	\N	\N	\N	\N	58206	\N	0
58201	2	\N	\N	\N	\N	\N	58206	\N	1
58202	2	\N	\N	\N	\N	\N	58206	\N	2
58203	2	\N	\N	\N	\N	\N	58206	\N	3
58204	2	\N	\N	\N	\N	\N	58206	\N	4
58205	2	\N	\N	\N	\N	\N	58206	\N	5
58206	2	\N	\N	\N	\N	\N	58239	\N	7
58207	2	\N	\N	\N	\N	\N	58212	\N	0
58208	2	\N	\N	\N	\N	\N	58212	\N	1
58209	2	\N	\N	\N	\N	\N	58212	\N	2
58210	2	\N	\N	\N	\N	\N	58212	\N	3
58211	2	\N	\N	\N	\N	\N	58212	\N	4
58212	2	\N	\N	\N	\N	\N	58239	\N	8
58213	2	\N	\N	\N	\N	\N	58215	\N	0
58214	2	\N	\N	\N	\N	\N	58215	\N	1
58215	2	\N	\N	\N	\N	\N	58239	\N	9
58216	2	\N	\N	\N	\N	\N	58218	\N	0
58217	2	\N	\N	\N	\N	\N	58218	\N	1
58218	2	\N	\N	\N	\N	\N	58239	\N	10
58219	2	\N	\N	\N	\N	\N	58220	\N	0
58220	2	\N	\N	\N	\N	\N	58239	\N	11
58221	2	\N	\N	\N	\N	\N	58222	\N	0
58222	2	\N	\N	\N	\N	\N	58239	\N	12
58223	2	\N	\N	\N	\N	\N	58233	\N	0
58224	2	\N	\N	\N	\N	\N	58233	\N	1
58225	2	\N	\N	\N	\N	\N	58233	\N	2
58226	2	\N	\N	\N	\N	\N	58233	\N	3
58227	2	\N	\N	\N	\N	\N	58233	\N	4
58228	2	\N	\N	\N	\N	\N	58233	\N	5
58229	2	\N	\N	\N	\N	\N	58233	\N	6
58230	2	\N	\N	\N	\N	\N	58233	\N	7
58231	2	\N	\N	\N	\N	\N	58233	\N	8
58232	2	\N	\N	\N	\N	\N	58233	\N	9
58233	2	\N	\N	\N	\N	\N	58239	\N	13
58234	2	\N	\N	\N	\N	\N	58239	\N	14
58235	2	\N	\N	\N	\N	\N	58239	\N	15
58236	2	\N	\N	\N	\N	\N	58238	\N	0
58237	2	\N	\N	\N	\N	\N	58238	\N	1
58238	2	\N	\N	\N	\N	\N	58239	\N	16
58239	2	\N	\N	\N	\N	2010-01-30	\N	\N	\N
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
1217
1220
1224
3134
3135
3138
3143
27877
27879
29594
29596
33033
36772
40101
40107
40112
40113
58180
58184
58186
58191
58193
58195
58199
58206
58212
58215
58218
58220
58222
58233
58238
58239
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
3150
3151
38388
38389
40115
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
33032	3	32884
1218	19	1150
1219	19	1151
1220	19	1149
1221	19	1152
1222	19	1153
1223	19	1154
1224	19	1035
33033	3	32883
3139	6	1180
3140	6	1181
3141	6	1182
3142	6	1183
3143	6	1179
27876	5	27607
3131	5	1356
3132	5	1357
3133	5	1362
3134	5	1361
3135	5	1360
3136	5	1364
3137	5	1365
3138	5	1325
1212	20	1126
1213	20	1127
1214	20	1128
1215	20	1129
1216	20	1130
1217	20	1022
27877	5	27605
27878	5	27608
27879	5	27603
36764	8	35791
36765	8	35792
36766	8	35793
36767	8	35794
36768	8	35795
36769	8	35796
36771	8	35798
36770	8	35797
38380	5	38080
36772	8	35766
29593	5	29323
29594	5	29322
29595	5	29325
29596	5	29320
33027	2	29321
33028	2	29324
58176	2	50361
58177	2	50362
58178	2	50363
58179	2	50364
58180	2	50360
58181	2	50366
58182	2	50367
58183	2	50368
58184	2	50365
58185	2	50370
58186	2	50369
58187	2	50372
58188	2	50373
58189	2	50374
58190	2	50375
58191	2	50371
58192	2	50377
58193	2	50376
58194	2	50379
40097	7	39872
40098	7	39873
40099	7	39875
40100	7	39876
40101	7	39874
40102	7	39878
40103	7	39879
40104	7	39880
40105	7	39881
40106	7	39882
40107	7	39877
40108	7	39884
40109	7	39885
40110	7	39886
40112	7	39883
40111	7	39887
40113	7	39823
58195	2	50378
58196	2	50381
58197	2	50382
58198	2	50383
58199	2	50380
58200	2	50385
58201	2	50386
58202	2	50387
58203	2	50388
58204	2	50389
58205	2	50390
58206	2	50384
58207	2	50392
58208	2	50393
58209	2	50394
58210	2	50395
58211	2	50396
58212	2	50391
58213	2	50601
58214	2	50602
58215	2	50398
58216	2	50644
58217	2	50645
58218	2	50643
58219	2	50647
58220	2	50646
58221	2	50649
58222	2	50648
58223	2	50651
58224	2	50652
58225	2	50653
58226	2	50654
58227	2	50655
58228	2	50656
58229	2	50657
58230	2	50658
58231	2	50659
58232	2	50660
58233	2	50650
58234	2	50661
58235	2	50662
58236	2	50670
58237	2	50671
58238	2	50669
58239	2	49125
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled) FROM stdin;
1212	1	EXTRAORDINARIA	Cod1	15.00	t
1217	1	NORMAL	Cod2	10.00	t
31714	1	FESTIVOS	FESTIVOS	30.00	t
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
48985	ROLE_BASIC_USER
48986	ROLE_ADMINISTRATION
48986	ROLE_BASIC_USER
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, work_report_type_id, resource_id, order_element_id) FROM stdin;
3636	1	2009-12-04 00:00:00	2526	1718	1126
3637	2	\N	2525	1722	\N
3638	1	\N	2525	1722	\N
7070	1	\N	2525	1724	\N
8100	1	\N	2525	1718	\N
17372	1	\N	2525	1722	\N
18786	1	\N	2525	1722	\N
26664	1	\N	21109	1718	1152
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, index, label_type_id, label_id, work_report_type_id) FROM stdin;
910	0	f	0	810	914	2526
911	0	t	0	808	909	2527
909	1	t	0	809	913	2525
21210	1	t	1	808	910	21109
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
3737	1	6	2009-12-04 00:00:00	1970-01-01 08:10:00	1970-01-01 14:11:00	3636	1718	1126	1212
3738	2	20	2009-12-07 00:00:00	\N	\N	3637	1722	1126	1217
3739	1	8	2009-12-07 00:00:00	\N	\N	3638	1722	1128	1217
3740	1	8	2009-12-04 00:00:00	\N	\N	3638	1722	1128	1217
7171	1	50	2009-12-07 00:00:00	\N	\N	7070	1724	1182	1217
7172	1	40	2009-12-08 00:00:00	\N	\N	7070	1724	1180	1217
7173	1	30	2009-12-09 00:00:00	\N	\N	7070	1724	1181	1217
8201	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8202	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8203	1	8	2009-12-11 00:00:00	\N	\N	8100	1718	1181	1217
8204	1	8	2009-12-08 00:00:00	\N	\N	8100	1718	1180	1217
8205	1	8	2009-12-14 00:00:00	\N	\N	8100	1718	1181	1217
8206	1	8	2009-12-10 00:00:00	\N	\N	8100	1718	1180	1217
8207	1	8	2009-12-07 00:00:00	\N	\N	8100	1718	1180	1217
8208	1	8	2009-12-09 00:00:00	\N	\N	8100	1718	1180	1217
17473	1	30	2009-12-09 00:00:00	\N	\N	17372	1722	1152	1217
17474	1	10	2009-12-10 00:00:00	\N	\N	17372	1722	1149	1217
17475	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1152	1217
17476	1	10	2009-12-07 00:00:00	\N	\N	17372	1722	1149	1217
17477	1	10	2009-12-09 00:00:00	\N	\N	17372	1722	1149	1217
17478	1	30	2009-12-10 00:00:00	\N	\N	17372	1722	1152	1217
17479	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1149	1217
18887	1	20	2009-12-07 00:00:00	\N	\N	18786	1722	1152	1217
26765	1	20	2009-12-09 00:00:00	\N	\N	26664	1718	1152	1217
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
2526	1	Tipo2	cod2	t	t	t	1
2527	1	Tipo3	cod3	t	f	t	2
2525	4	Tipo1	cod1	f	t	f	0
21109	4	tipo4	codparte5	f	t	t	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1720	Samuel	Lopez	22222222B
1718	Marcos	Cancela	11111111A
1724	Isabel	Dopacio	44444444D
1722	Andres	Lafuente	33333333C
1726	Silvia	Martinez	55555555E
37575	Pedro	Figueras	88888888H
36159	Lorenzo	Tilve Álvaro	66666666E
37573	Manuel	Rego Casasnovas	77777777G
40199	Jacobo	Aragunde	99999999H
49300	Oscar	González Fernández	33333333D
49302	José María 	Casanova Crespo	44444444E
49304	Xavier	Castaño García	55555555F
49289	Javier	Morán Rúa	11111111B
49309	Susana	Montes	77777777P
49297	Diego	Pino García	22222222C
49313	Fernando	Bellas	10000000C
49315	Proba1	Proba2	34343434C
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
3637	913
3638	913
7070	913
8100	913
17372	913
18786	913
26664	911
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
3737	914
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: resource_calendar_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_calendar_key UNIQUE (calendar);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282ee893ce10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282ee893ce10 FOREIGN KEY (calendar) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

