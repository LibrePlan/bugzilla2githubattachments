--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterion_type_work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion_type_work_report_type (
    work_report_type_id bigint NOT NULL,
    criterion_type_id bigint NOT NULL
);


ALTER TABLE public.criterion_type_work_report_type OWNER TO naval;

--
-- Name: criterion_work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion_work_report_line (
    work_report_line_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.criterion_work_report_line OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    criterion_id bigint,
    parent bigint,
    isvalid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: exceptionday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE exceptionday (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    hours integer,
    base_calendar_id bigint
);


ALTER TABLE public.exceptionday OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    resourcetype bytea,
    workinghours integer,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint NOT NULL
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    code character varying(255),
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type integer,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    customer character varying(255),
    dependenciesconstraintshavepriority boolean,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    mandatoryinit boolean,
    mandatoryend boolean,
    description character varying(255),
    code character varying(255),
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    calendar bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date timestamp without time zone,
    place character varying(255),
    responsible character varying(255),
    work_report_type_id bigint NOT NULL
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    numhours integer,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
2136	8	t	505
4302	6	t	505
5783	4	t	506
3558	8	f	505
5784	4	f	506
13861	2	f	12524
13862	2	f	12524
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
5884	3	\N	0.00	5783
5885	3	\N	0.00	5783
14021	2	2009-12-04	100.00	13861
14022	2	2009-12-01	50.00	13861
14023	2	2009-11-30	30.00	13861
14024	2	2009-11-24	10.00	13861
14025	2	2009-12-01	40.00	5783
14026	2	2009-11-30	30.00	5783
14027	2	2009-11-24	10.00	5783
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
505	3	children	100.0000	f	0.0100	t	t
506	2	percentage	100.0000	f	0.0100	t	t
507	1	units	2147483647.0000	f	1.0000	t	f
606	1	Presupuesto	6000000.0000	t	1000.0000	t	f
607	3	Pactado Factura	6000000.0000	t	1000.0000	t	f
12524	1	Preacordado	100.0000	t	1.0000	t	f
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
5964	1214
5965	1214
5966	1214
5979	1213
5980	1215
5981	1214
5982	1215
5983	1213
5984	1214
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
707	2	Galicia
202	4	España
708	1	Autralia
710	2	\N
712	2	\N
711	2	\N
709	2	\N
713	2	\N
716	2	\N
715	3	\N
714	3	\N
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
808	2	202	\N	707	0
303	4	\N	2009-11-26	202	0
809	1	\N	\N	202	1
810	1	\N	2009-11-26	708	0
811	1	\N	\N	708	1
813	2	202	\N	710	0
815	2	202	\N	712	0
814	2	202	\N	711	0
812	2	202	\N	709	0
816	2	202	\N	713	0
819	2	202	\N	716	0
818	3	202	\N	715	0
817	3	202	\N	714	0
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id) FROM stdin;
404	3	202
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
1212	2	Calderero	t	4	\N
1213	2	Andamiero	t	4	\N
1214	2	Pintor	t	4	\N
1215	2	Soldador	t	4	\N
1216	2	Oficial 1ª	t	2	\N
1217	2	Peon	t	2	\N
1218	2	Oficial 2ª	t	2	\N
1219	1	Torno	t	524288	\N
1220	1	Pulidora	t	524288	\N
\.


--
-- Data for Name: criterion_type_work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion_type_work_report_type (work_report_type_id, criterion_type_id) FROM stdin;
\.


--
-- Data for Name: criterion_work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion_work_report_line (work_report_line_id, criterion_id) FROM stdin;
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
3245	DIRECT	4	\N	2056	1214	\N	\N
3246	INDIRECT	4	\N	2057	1214	3245	t
3247	INDIRECT	4	2243	\N	1214	3245	t
3271	DIRECT	3	\N	2058	1213	\N	\N
3248	INDIRECT	4	\N	2058	1214	3245	f
3249	INDIRECT	4	2244	\N	1214	3245	f
3272	INDIRECT	3	2244	\N	1213	3271	t
3250	DIRECT	4	\N	2059	1213	\N	\N
3251	INDIRECT	4	2261	\N	1213	3250	t
3252	INDIRECT	4	2245	\N	1213	3250	t
3253	DIRECT	4	\N	2060	1213	\N	\N
3254	INDIRECT	4	2246	\N	1213	3253	t
3255	DIRECT	4	\N	2061	1215	\N	\N
3256	INDIRECT	4	2247	\N	1215	3255	t
3257	DIRECT	4	\N	2062	1214	\N	\N
3258	INDIRECT	4	2248	\N	1214	3257	t
3259	DIRECT	4	\N	2063	1213	\N	\N
3260	INDIRECT	4	2249	\N	1213	3259	t
4861	DIRECT	6	\N	4951	1214	\N	\N
4862	INDIRECT	6	\N	4952	1214	4861	t
4863	INDIRECT	6	4790	\N	1214	4861	t
4864	INDIRECT	6	\N	4953	1214	4861	t
4865	INDIRECT	6	4791	\N	1214	4861	t
4866	DIRECT	6	\N	4954	1212	\N	\N
4867	INDIRECT	6	4792	\N	1212	4866	t
3961	DIRECT	6	\N	3470	1212	\N	\N
3962	INDIRECT	6	3648	\N	1212	3961	t
3963	DIRECT	6	\N	3471	1213	\N	\N
3964	INDIRECT	6	3649	\N	1213	3963	t
3965	DIRECT	6	\N	3472	1214	\N	\N
3966	INDIRECT	6	3650	\N	1214	3965	t
3967	DIRECT	6	\N	3473	1214	\N	\N
3968	INDIRECT	6	3651	\N	1214	3967	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
1717	1	2009-11-25 11:51:05.074	\N	f	1215	1516
1718	1	2009-11-25 11:51:40.755	\N	f	1215	1518
1719	1	2009-11-25 11:51:49.045	\N	f	1214	1518
1720	1	2009-11-25 11:51:58.515	\N	f	1214	1517
1721	1	2009-11-25 11:52:07.246	\N	f	1213	1515
1722	1	2009-11-25 11:52:25.763	\N	f	1214	1519
1723	1	2009-11-25 11:52:15.317	\N	f	1213	1519
1725	1	2009-11-25 11:54:37.841	\N	f	1220	1522
1724	2	2009-11-25 11:54:24.917	\N	f	1219	1520
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
1	15	LEAVE	Leave	f	f	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
4	8	Tipo de trabajo	Tipología de trabajo	t	t	t	1
2	12	Categoría	Categoría profesional	t	t	t	1
524288	1	Tipo de máquina	Tipos de máquina	t	t	t	2
1081344	14	CATEGORY	Professional category	t	t	t	1
1081345	9	JOB	Job	t	t	t	1
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id) FROM stdin;
7404	GENERIC_DAY	1	2	2009-12-24	1519	\N	5966
7448	GENERIC_DAY	1	2	2009-12-28	1519	\N	5966
7435	GENERIC_DAY	1	3	2009-12-22	1518	\N	5966
7524	GENERIC_DAY	1	3	2010-01-18	1517	\N	5966
7389	GENERIC_DAY	1	3	2009-12-09	1517	\N	5966
7453	GENERIC_DAY	1	3	2009-12-08	1518	\N	5966
7484	GENERIC_DAY	1	3	2010-01-12	1518	\N	5966
7560	GENERIC_DAY	1	2	2009-11-29	1519	\N	5966
7531	GENERIC_DAY	1	3	2009-12-26	1517	\N	5966
7409	GENERIC_DAY	1	3	2010-01-17	1517	\N	5966
7494	GENERIC_DAY	1	3	2009-12-26	1518	\N	5966
7451	GENERIC_DAY	1	3	2010-01-15	1517	\N	5966
7414	GENERIC_DAY	1	3	2010-01-01	1517	\N	5966
7581	GENERIC_DAY	1	2	2010-01-31	1519	\N	5966
7611	GENERIC_DAY	1	3	2009-12-11	1518	\N	5966
7406	GENERIC_DAY	1	2	2009-12-11	1519	\N	5966
7422	GENERIC_DAY	1	2	2009-12-05	1519	\N	5966
7504	GENERIC_DAY	1	3	2009-12-14	1518	\N	5966
7419	GENERIC_DAY	1	3	2010-02-01	1518	\N	5966
7545	GENERIC_DAY	1	2	2010-01-16	1519	\N	5966
7535	GENERIC_DAY	1	2	2010-01-08	1519	\N	5966
7605	GENERIC_DAY	1	3	2010-01-08	1518	\N	5966
7587	GENERIC_DAY	1	3	2009-11-27	1518	\N	5966
7426	GENERIC_DAY	1	3	2010-02-06	1518	\N	5966
7618	GENERIC_DAY	1	2	2009-12-17	1519	\N	5966
7483	GENERIC_DAY	1	2	2009-12-30	1519	\N	5966
7407	GENERIC_DAY	1	2	2010-02-06	1519	\N	5966
7396	GENERIC_DAY	1	3	2009-12-29	1518	\N	5966
7509	GENERIC_DAY	1	2	2010-02-08	1519	\N	5966
7383	GENERIC_DAY	1	2	2009-12-21	1519	\N	5966
7507	GENERIC_DAY	1	3	2009-11-30	1517	\N	5966
7550	GENERIC_DAY	1	3	2009-12-20	1517	\N	5966
7613	GENERIC_DAY	1	3	2010-01-05	1517	\N	5966
7563	GENERIC_DAY	1	3	2010-01-13	1518	\N	5966
7547	GENERIC_DAY	1	3	2009-12-04	1518	\N	5966
7456	GENERIC_DAY	1	3	2010-01-24	1517	\N	5966
7528	GENERIC_DAY	1	3	2009-11-28	1517	\N	5966
7614	GENERIC_DAY	1	2	2010-01-17	1519	\N	5966
7425	GENERIC_DAY	1	2	2009-12-16	1519	\N	5966
7529	GENERIC_DAY	1	3	2010-02-10	1517	\N	5966
7534	GENERIC_DAY	1	3	2010-01-05	1518	\N	5966
7464	GENERIC_DAY	1	3	2009-12-17	1517	\N	5966
7492	GENERIC_DAY	1	3	2010-01-27	1517	\N	5966
7401	GENERIC_DAY	1	2	2009-12-18	1519	\N	5966
7501	GENERIC_DAY	1	3	2010-02-08	1517	\N	5966
7475	GENERIC_DAY	1	3	2010-02-05	1517	\N	5966
7525	GENERIC_DAY	1	2	2010-02-05	1519	\N	5966
7403	GENERIC_DAY	1	3	2009-11-26	1517	\N	5966
7562	GENERIC_DAY	1	3	2009-12-16	1517	\N	5966
7450	GENERIC_DAY	1	3	2010-02-02	1517	\N	5966
7459	GENERIC_DAY	1	3	2010-01-01	1518	\N	5966
7478	GENERIC_DAY	1	3	2010-01-12	1517	\N	5966
7398	GENERIC_DAY	1	2	2009-12-15	1519	\N	5966
7479	GENERIC_DAY	1	3	2010-01-22	1517	\N	5966
7391	GENERIC_DAY	1	3	2010-01-14	1517	\N	5966
7502	GENERIC_DAY	1	2	2009-11-26	1519	\N	5966
7457	GENERIC_DAY	1	3	2010-01-21	1517	\N	5966
7516	GENERIC_DAY	1	3	2009-12-27	1517	\N	5966
7540	GENERIC_DAY	1	3	2010-01-07	1517	\N	5966
7586	GENERIC_DAY	1	3	2010-01-20	1518	\N	5966
7388	GENERIC_DAY	1	3	2010-01-25	1517	\N	5966
7440	GENERIC_DAY	1	2	2009-11-25	1519	\N	5966
7491	GENERIC_DAY	1	2	2009-12-09	1519	\N	5966
7429	GENERIC_DAY	1	3	2010-02-02	1518	\N	5966
7505	GENERIC_DAY	1	3	2010-01-22	1518	\N	5966
7566	GENERIC_DAY	1	2	2010-02-09	1519	\N	5966
7386	GENERIC_DAY	1	3	2009-11-29	1518	\N	5966
7506	GENERIC_DAY	1	3	2010-01-16	1517	\N	5966
7533	GENERIC_DAY	1	3	2010-02-11	1517	\N	5966
7554	GENERIC_DAY	1	3	2010-01-10	1517	\N	5966
7447	GENERIC_DAY	1	3	2010-01-15	1518	\N	5966
7449	GENERIC_DAY	1	2	2010-01-23	1519	\N	5966
7390	GENERIC_DAY	1	2	2010-02-02	1519	\N	5966
7400	GENERIC_DAY	1	3	2009-11-28	1518	\N	5966
7416	GENERIC_DAY	1	3	2010-01-23	1517	\N	5966
7472	GENERIC_DAY	1	3	2010-01-18	1518	\N	5966
7559	GENERIC_DAY	1	3	2010-01-28	1517	\N	5966
7604	GENERIC_DAY	1	3	2010-01-10	1518	\N	5966
7532	GENERIC_DAY	1	3	2009-12-15	1517	\N	5966
7577	GENERIC_DAY	1	2	2009-12-12	1519	\N	5966
7465	GENERIC_DAY	1	3	2010-01-27	1518	\N	5966
7578	GENERIC_DAY	1	2	2010-01-25	1519	\N	5966
7468	GENERIC_DAY	1	3	2009-12-17	1518	\N	5966
7460	GENERIC_DAY	1	2	2009-12-02	1519	\N	5966
7381	GENERIC_DAY	1	2	2010-01-06	1519	\N	5966
7589	GENERIC_DAY	1	3	2010-01-26	1517	\N	5966
7461	GENERIC_DAY	1	3	2009-12-03	1518	\N	5966
7537	GENERIC_DAY	1	3	2009-12-10	1517	\N	5966
7408	GENERIC_DAY	1	3	2009-12-12	1517	\N	5966
7569	GENERIC_DAY	1	3	2010-01-03	1518	\N	5966
7557	GENERIC_DAY	1	3	2010-01-29	1517	\N	5966
7601	GENERIC_DAY	1	3	2009-12-22	1517	\N	5966
7574	GENERIC_DAY	1	3	2009-12-09	1518	\N	5966
7575	GENERIC_DAY	1	2	2010-02-04	1519	\N	5966
7469	GENERIC_DAY	1	3	2009-12-30	1517	\N	5966
7513	GENERIC_DAY	1	3	2010-01-13	1517	\N	5966
7433	GENERIC_DAY	1	3	2009-12-21	1518	\N	5966
7573	GENERIC_DAY	1	3	2009-12-02	1518	\N	5966
7393	GENERIC_DAY	1	2	2009-12-07	1519	\N	5966
7427	GENERIC_DAY	1	3	2009-12-23	1518	\N	5966
7543	GENERIC_DAY	1	2	2010-01-01	1519	\N	5966
7571	GENERIC_DAY	1	2	2009-12-27	1519	\N	5966
7500	GENERIC_DAY	1	3	2010-01-19	1517	\N	5966
7462	GENERIC_DAY	1	3	2009-12-20	1518	\N	5966
7558	GENERIC_DAY	1	3	2010-02-03	1518	\N	5966
7499	GENERIC_DAY	1	3	2009-12-12	1518	\N	5966
7431	GENERIC_DAY	1	3	2010-01-26	1518	\N	5966
7568	GENERIC_DAY	1	3	2009-12-13	1518	\N	5966
7553	GENERIC_DAY	1	3	2010-01-20	1517	\N	5966
7539	GENERIC_DAY	1	3	2010-02-07	1518	\N	5966
7477	GENERIC_DAY	1	2	2010-01-07	1519	\N	5966
7423	GENERIC_DAY	1	3	2009-12-06	1517	\N	5966
7536	GENERIC_DAY	1	3	2010-01-31	1518	\N	5966
7565	GENERIC_DAY	1	2	2009-11-28	1519	\N	5966
7555	GENERIC_DAY	1	2	2009-12-31	1519	\N	5966
7497	GENERIC_DAY	1	2	2010-01-15	1519	\N	5966
7593	GENERIC_DAY	1	3	2009-12-05	1518	\N	5966
7570	GENERIC_DAY	1	3	2010-01-06	1517	\N	5966
7438	GENERIC_DAY	1	3	2010-01-04	1517	\N	5966
7556	GENERIC_DAY	1	2	2010-01-02	1519	\N	5966
7598	GENERIC_DAY	1	3	2009-12-18	1518	\N	5966
7512	GENERIC_DAY	1	2	2010-02-12	1519	\N	5966
7385	GENERIC_DAY	1	2	2009-12-04	1519	\N	5966
7481	GENERIC_DAY	1	2	2010-01-11	1519	\N	5966
7458	GENERIC_DAY	1	3	2009-12-16	1518	\N	5966
7495	GENERIC_DAY	1	3	2009-12-21	1517	\N	5966
7561	GENERIC_DAY	1	3	2010-01-30	1518	\N	5966
7567	GENERIC_DAY	1	2	2009-12-22	1519	\N	5966
7445	GENERIC_DAY	1	3	2010-02-09	1518	\N	5966
7380	GENERIC_DAY	1	2	2010-02-11	1519	\N	5966
7582	GENERIC_DAY	1	3	2009-12-27	1518	\N	5966
7617	GENERIC_DAY	1	2	2010-01-30	1519	\N	5966
7572	GENERIC_DAY	1	3	2009-12-23	1517	\N	5966
7418	GENERIC_DAY	1	3	2009-12-15	1518	\N	5966
7588	GENERIC_DAY	1	2	2010-01-28	1519	\N	5966
7526	GENERIC_DAY	1	3	2009-11-26	1518	\N	5966
7609	GENERIC_DAY	1	2	2009-11-27	1519	\N	5966
7519	GENERIC_DAY	1	3	2009-12-25	1517	\N	5966
7395	GENERIC_DAY	1	3	2009-12-10	1518	\N	5966
7455	GENERIC_DAY	1	3	2009-12-24	1518	\N	5966
7405	GENERIC_DAY	1	3	2010-02-07	1517	\N	5966
7463	GENERIC_DAY	1	2	2010-01-12	1519	\N	5966
7490	GENERIC_DAY	1	3	2010-02-04	1518	\N	5966
7591	GENERIC_DAY	1	3	2009-12-25	1518	\N	5966
7590	GENERIC_DAY	1	2	2010-01-13	1519	\N	5966
7420	GENERIC_DAY	1	3	2010-01-31	1517	\N	5966
7592	GENERIC_DAY	1	3	2010-01-03	1517	\N	5966
7548	GENERIC_DAY	1	3	2010-01-23	1518	\N	5966
7603	GENERIC_DAY	1	3	2010-01-25	1518	\N	5966
7517	GENERIC_DAY	1	2	2009-12-26	1519	\N	5966
7410	GENERIC_DAY	1	3	2010-01-28	1518	\N	5966
7530	GENERIC_DAY	1	2	2009-12-20	1519	\N	5966
7518	GENERIC_DAY	1	2	2010-01-29	1519	\N	5966
7544	GENERIC_DAY	1	3	2010-01-09	1517	\N	5966
7549	GENERIC_DAY	1	2	2009-12-23	1519	\N	5966
7439	GENERIC_DAY	1	2	2009-12-25	1519	\N	5966
7432	GENERIC_DAY	1	3	2009-12-31	1518	\N	5966
7538	GENERIC_DAY	1	3	2010-01-17	1518	\N	5966
7610	GENERIC_DAY	1	3	2009-11-25	1517	\N	5966
7616	GENERIC_DAY	1	2	2009-12-03	1519	\N	5966
7551	GENERIC_DAY	1	3	2010-01-16	1518	\N	5966
7446	GENERIC_DAY	1	2	2009-12-10	1519	\N	5966
7379	GENERIC_DAY	1	2	2009-12-13	1519	\N	5966
7444	GENERIC_DAY	1	3	2010-02-12	1517	\N	5966
7485	GENERIC_DAY	1	3	2009-12-19	1518	\N	5966
7474	GENERIC_DAY	1	2	2010-01-05	1519	\N	5966
7510	GENERIC_DAY	1	3	2009-12-01	1517	\N	5966
7523	GENERIC_DAY	1	2	2010-01-21	1519	\N	5966
7454	GENERIC_DAY	1	3	2009-12-28	1518	\N	5966
7441	GENERIC_DAY	1	3	2009-12-04	1517	\N	5966
7430	GENERIC_DAY	1	2	2010-01-18	1519	\N	5966
7471	GENERIC_DAY	1	2	2010-01-10	1519	\N	5966
7508	GENERIC_DAY	1	3	2009-11-27	1517	\N	5966
7594	GENERIC_DAY	1	2	2010-01-24	1519	\N	5966
7498	GENERIC_DAY	1	2	2010-02-07	1519	\N	5966
7415	GENERIC_DAY	1	3	2010-02-03	1517	\N	5966
7476	GENERIC_DAY	1	3	2009-12-28	1517	\N	5966
7493	GENERIC_DAY	1	2	2009-12-08	1519	\N	5966
7394	GENERIC_DAY	1	3	2010-01-11	1517	\N	5966
7489	GENERIC_DAY	1	2	2010-01-03	1519	\N	5966
7428	GENERIC_DAY	1	2	2010-01-04	1519	\N	5966
7496	GENERIC_DAY	1	2	2010-02-03	1519	\N	5966
7387	GENERIC_DAY	1	3	2009-12-05	1517	\N	5966
7576	GENERIC_DAY	1	2	2009-11-30	1519	\N	5966
7412	GENERIC_DAY	1	3	2009-12-13	1517	\N	5966
7541	GENERIC_DAY	1	3	2010-02-10	1518	\N	5966
7443	GENERIC_DAY	1	3	2010-01-02	1518	\N	5966
7546	GENERIC_DAY	1	3	2009-12-07	1517	\N	5966
7608	GENERIC_DAY	1	2	2010-01-09	1519	\N	5966
7437	GENERIC_DAY	1	2	2009-12-19	1519	\N	5966
7480	GENERIC_DAY	1	3	2010-02-06	1517	\N	5966
7411	GENERIC_DAY	1	3	2010-02-11	1518	\N	5966
7511	GENERIC_DAY	1	3	2010-01-07	1518	\N	5966
7595	GENERIC_DAY	1	3	2009-12-29	1517	\N	5966
7521	GENERIC_DAY	1	2	2010-01-22	1519	\N	5966
7527	GENERIC_DAY	1	2	2010-02-01	1519	\N	5966
7434	GENERIC_DAY	1	2	2009-12-29	1519	\N	5966
7615	GENERIC_DAY	1	2	2010-02-10	1519	\N	5966
7514	GENERIC_DAY	1	2	2009-12-06	1519	\N	5966
7602	GENERIC_DAY	1	3	2009-11-30	1518	\N	5966
7612	GENERIC_DAY	1	2	2010-01-26	1519	\N	5966
7436	GENERIC_DAY	1	3	2010-02-04	1517	\N	5966
7596	GENERIC_DAY	1	3	2009-11-25	1518	\N	5966
7384	GENERIC_DAY	1	3	2010-01-19	1518	\N	5966
7417	GENERIC_DAY	1	3	2010-01-21	1518	\N	5966
7452	GENERIC_DAY	1	2	2009-12-01	1519	\N	5966
7467	GENERIC_DAY	1	2	2009-12-14	1519	\N	5966
7522	GENERIC_DAY	1	2	2010-01-27	1519	\N	5966
7599	GENERIC_DAY	1	3	2010-01-30	1517	\N	5966
7579	GENERIC_DAY	1	3	2010-02-01	1517	\N	5966
7482	GENERIC_DAY	1	3	2009-12-01	1518	\N	5966
7515	GENERIC_DAY	1	3	2009-12-07	1518	\N	5966
7466	GENERIC_DAY	1	3	2009-12-24	1517	\N	5966
7580	GENERIC_DAY	1	2	2010-01-19	1519	\N	5966
7399	GENERIC_DAY	1	3	2010-02-09	1517	\N	5966
7442	GENERIC_DAY	1	3	2010-01-29	1518	\N	5966
7470	GENERIC_DAY	1	3	2009-12-03	1517	\N	5966
7402	GENERIC_DAY	1	3	2009-12-08	1517	\N	5966
7520	GENERIC_DAY	1	3	2009-12-18	1517	\N	5966
7421	GENERIC_DAY	1	3	2010-01-06	1518	\N	5966
7552	GENERIC_DAY	1	3	2009-12-02	1517	\N	5966
7486	GENERIC_DAY	1	3	2009-12-30	1518	\N	5966
7564	GENERIC_DAY	1	3	2009-11-29	1517	\N	5966
7503	GENERIC_DAY	1	3	2010-01-09	1518	\N	5966
7424	GENERIC_DAY	1	2	2010-01-14	1519	\N	5966
7397	GENERIC_DAY	1	3	2009-12-19	1517	\N	5966
7487	GENERIC_DAY	1	3	2010-01-14	1518	\N	5966
7392	GENERIC_DAY	1	3	2010-01-24	1518	\N	5966
7382	GENERIC_DAY	1	3	2010-01-08	1517	\N	5966
7607	GENERIC_DAY	1	3	2009-12-14	1517	\N	5966
7585	GENERIC_DAY	1	3	2010-01-11	1518	\N	5966
7413	GENERIC_DAY	1	3	2009-12-11	1517	\N	5966
7473	GENERIC_DAY	1	3	2010-02-12	1518	\N	5966
7488	GENERIC_DAY	1	3	2010-02-05	1518	\N	5966
7101	GENERIC_DAY	1	3	2010-01-25	1519	\N	5964
7000	GENERIC_DAY	1	2	2010-01-04	1517	\N	5964
7009	GENERIC_DAY	1	3	2009-12-31	1518	\N	5964
7087	GENERIC_DAY	1	3	2010-01-02	1519	\N	5964
7086	GENERIC_DAY	1	2	2009-12-21	1517	\N	5964
7047	GENERIC_DAY	1	2	2010-01-18	1517	\N	5964
6947	GENERIC_DAY	1	2	2009-12-26	1517	\N	5964
7055	GENERIC_DAY	1	3	2009-12-09	1519	\N	5964
6950	GENERIC_DAY	1	2	2009-11-28	1517	\N	5964
6949	GENERIC_DAY	1	3	2010-01-13	1518	\N	5964
7046	GENERIC_DAY	1	3	2009-12-05	1518	\N	5964
6984	GENERIC_DAY	1	3	2009-12-06	1518	\N	5964
7068	GENERIC_DAY	1	3	2010-01-21	1518	\N	5964
7029	GENERIC_DAY	1	2	2009-12-31	1517	\N	5964
6988	GENERIC_DAY	1	2	2010-01-08	1517	\N	5964
7072	GENERIC_DAY	1	2	2010-01-16	1517	\N	5964
7062	GENERIC_DAY	1	3	2009-11-28	1518	\N	5964
7050	GENERIC_DAY	1	3	2009-11-30	1519	\N	5964
7044	GENERIC_DAY	1	3	2009-12-10	1519	\N	5964
6946	GENERIC_DAY	1	3	2009-12-12	1519	\N	5964
6992	GENERIC_DAY	1	2	2009-12-12	1517	\N	5964
7120	GENERIC_DAY	1	3	2010-01-06	1519	\N	5964
7121	GENERIC_DAY	1	2	2009-12-08	1517	\N	5964
7039	GENERIC_DAY	1	3	2009-11-29	1519	\N	5964
6985	GENERIC_DAY	1	3	2010-01-17	1518	\N	5964
6944	GENERIC_DAY	1	3	2010-01-10	1518	\N	5964
7119	GENERIC_DAY	1	3	2009-12-25	1518	\N	5964
7048	GENERIC_DAY	1	3	2010-01-09	1518	\N	5964
6987	GENERIC_DAY	1	2	2010-01-17	1517	\N	5964
6969	GENERIC_DAY	1	3	2009-12-10	1518	\N	5964
7033	GENERIC_DAY	1	3	2009-12-27	1518	\N	5964
7023	GENERIC_DAY	1	3	2010-01-20	1518	\N	5964
7089	GENERIC_DAY	1	3	2010-01-16	1518	\N	5964
7102	GENERIC_DAY	1	2	2009-12-30	1517	\N	5964
6976	GENERIC_DAY	1	3	2009-12-01	1519	\N	5964
7061	GENERIC_DAY	1	3	2009-12-15	1519	\N	5964
6956	GENERIC_DAY	1	2	2010-01-19	1517	\N	5964
6997	GENERIC_DAY	1	2	2010-01-15	1517	\N	5964
7094	GENERIC_DAY	1	2	2009-12-15	1517	\N	5964
7084	GENERIC_DAY	1	1	2010-01-26	1518	\N	5964
7067	GENERIC_DAY	1	3	2009-12-23	1518	\N	5964
7035	GENERIC_DAY	1	2	2010-01-06	1517	\N	5964
6978	GENERIC_DAY	1	2	2010-01-12	1517	\N	5964
7077	GENERIC_DAY	1	2	2009-12-20	1517	\N	5964
7083	GENERIC_DAY	1	3	2010-01-10	1519	\N	5964
6955	GENERIC_DAY	1	3	2009-12-04	1519	\N	5964
7080	GENERIC_DAY	1	3	2009-11-29	1518	\N	5964
6954	GENERIC_DAY	1	3	2009-12-28	1519	\N	5964
6993	GENERIC_DAY	1	2	2009-12-25	1517	\N	5964
6996	GENERIC_DAY	1	3	2009-12-02	1519	\N	5964
7019	GENERIC_DAY	1	3	2009-12-03	1518	\N	5964
7028	GENERIC_DAY	1	2	2010-01-10	1517	\N	5964
7063	GENERIC_DAY	1	2	2010-01-20	1517	\N	5964
6964	GENERIC_DAY	1	3	2009-12-24	1518	\N	5964
7058	GENERIC_DAY	1	1	2010-01-26	1517	\N	5964
7007	GENERIC_DAY	1	3	2009-12-16	1518	\N	5964
7095	GENERIC_DAY	1	3	2009-12-16	1519	\N	5964
7122	GENERIC_DAY	1	3	2009-12-15	1518	\N	5964
6962	GENERIC_DAY	1	2	2010-01-13	1517	\N	5964
7006	GENERIC_DAY	1	3	2009-12-31	1519	\N	5964
7092	GENERIC_DAY	1	2	2010-01-01	1517	\N	5964
7037	GENERIC_DAY	1	3	2009-12-26	1519	\N	5964
7015	GENERIC_DAY	1	3	2009-12-20	1519	\N	5964
7008	GENERIC_DAY	1	3	2010-01-01	1518	\N	5964
6980	GENERIC_DAY	1	3	2010-01-04	1518	\N	5964
6989	GENERIC_DAY	1	3	2009-11-30	1518	\N	5964
6970	GENERIC_DAY	1	2	2010-01-22	1517	\N	5964
6943	GENERIC_DAY	1	3	2009-12-14	1518	\N	5964
6966	GENERIC_DAY	1	3	2010-01-22	1519	\N	5964
6942	GENERIC_DAY	1	3	2009-12-24	1519	\N	5964
7113	GENERIC_DAY	1	3	2010-01-21	1519	\N	5964
7082	GENERIC_DAY	1	2	2009-12-04	1517	\N	5964
6998	GENERIC_DAY	1	2	2010-01-25	1517	\N	5964
7117	GENERIC_DAY	1	2	2009-12-05	1517	\N	5964
6977	GENERIC_DAY	1	2	2009-12-07	1517	\N	5964
7049	GENERIC_DAY	1	2	2009-12-18	1517	\N	5964
6994	GENERIC_DAY	1	3	2009-12-27	1519	\N	5964
6971	GENERIC_DAY	1	2	2010-01-11	1517	\N	5964
7025	GENERIC_DAY	1	3	2009-12-30	1519	\N	5964
7038	GENERIC_DAY	1	2	2009-11-30	1517	\N	5964
7097	GENERIC_DAY	1	2	2010-01-24	1517	\N	5964
7099	GENERIC_DAY	1	3	2009-12-18	1519	\N	5964
7043	GENERIC_DAY	1	3	2009-11-25	1519	\N	5964
7064	GENERIC_DAY	1	3	2009-12-02	1518	\N	5964
7052	GENERIC_DAY	1	2	2009-12-28	1517	\N	5964
7098	GENERIC_DAY	1	2	2009-12-13	1517	\N	5964
7021	GENERIC_DAY	1	2	2009-12-17	1517	\N	5964
7004	GENERIC_DAY	1	3	2009-12-17	1518	\N	5964
7005	GENERIC_DAY	1	3	2009-12-20	1518	\N	5964
6973	GENERIC_DAY	1	3	2010-01-05	1519	\N	5964
6960	GENERIC_DAY	1	3	2009-12-19	1518	\N	5964
7036	GENERIC_DAY	1	3	2010-01-19	1519	\N	5964
7115	GENERIC_DAY	1	2	2009-12-02	1517	\N	5964
7066	GENERIC_DAY	1	3	2010-01-06	1518	\N	5964
7106	GENERIC_DAY	1	3	2009-12-21	1518	\N	5964
7010	GENERIC_DAY	1	3	2009-12-28	1518	\N	5964
7104	GENERIC_DAY	1	3	2010-01-03	1519	\N	5964
7002	GENERIC_DAY	1	3	2009-12-29	1519	\N	5964
7051	GENERIC_DAY	1	2	2009-12-10	1517	\N	5964
7014	GENERIC_DAY	1	3	2010-01-03	1518	\N	5964
6959	GENERIC_DAY	1	2	2009-12-06	1517	\N	5964
7073	GENERIC_DAY	1	3	2009-11-28	1519	\N	5964
7056	GENERIC_DAY	1	3	2010-01-18	1519	\N	5964
6999	GENERIC_DAY	1	3	2010-01-16	1519	\N	5964
7126	GENERIC_DAY	1	3	2010-01-15	1518	\N	5964
7091	GENERIC_DAY	1	2	2010-01-05	1517	\N	5964
7031	GENERIC_DAY	1	3	2009-12-26	1518	\N	5964
6981	GENERIC_DAY	1	3	2009-12-14	1519	\N	5964
6951	GENERIC_DAY	1	3	2009-12-30	1518	\N	5964
6963	GENERIC_DAY	1	3	2010-01-24	1519	\N	5964
7109	GENERIC_DAY	1	2	2009-11-29	1517	\N	5964
7070	GENERIC_DAY	1	3	2009-12-13	1518	\N	5964
7017	GENERIC_DAY	1	2	2009-12-27	1517	\N	5964
7069	GENERIC_DAY	1	2	2009-12-09	1517	\N	5964
7032	GENERIC_DAY	1	3	2010-01-12	1518	\N	5964
7103	GENERIC_DAY	1	3	2009-11-27	1519	\N	5964
6952	GENERIC_DAY	1	3	2010-01-04	1519	\N	5964
7125	GENERIC_DAY	1	2	2010-01-14	1517	\N	5964
7111	GENERIC_DAY	1	2	2009-11-26	1517	\N	5964
6991	GENERIC_DAY	1	3	2010-01-22	1518	\N	5964
7013	GENERIC_DAY	1	3	2009-12-05	1519	\N	5964
6961	GENERIC_DAY	1	2	2009-12-23	1517	\N	5964
6974	GENERIC_DAY	1	3	2009-12-11	1519	\N	5964
7022	GENERIC_DAY	1	2	2009-12-22	1517	\N	5964
6957	GENERIC_DAY	1	3	2009-12-11	1518	\N	5964
7027	GENERIC_DAY	1	3	2009-12-06	1519	\N	5964
7127	GENERIC_DAY	1	2	2009-12-01	1517	\N	5964
7078	GENERIC_DAY	1	3	2009-12-29	1518	\N	5964
6990	GENERIC_DAY	1	3	2009-12-19	1519	\N	5964
6945	GENERIC_DAY	1	2	2010-01-26	1519	\N	5964
7110	GENERIC_DAY	1	3	2010-01-14	1518	\N	5964
7060	GENERIC_DAY	1	3	2009-12-07	1519	\N	5964
7108	GENERIC_DAY	1	3	2010-01-05	1518	\N	5964
7081	GENERIC_DAY	1	3	2009-12-21	1519	\N	5964
7088	GENERIC_DAY	1	3	2010-01-12	1519	\N	5964
7045	GENERIC_DAY	1	3	2009-11-26	1519	\N	5964
6948	GENERIC_DAY	1	3	2010-01-14	1519	\N	5964
6965	GENERIC_DAY	1	3	2010-01-19	1518	\N	5964
7107	GENERIC_DAY	1	3	2010-01-13	1519	\N	5964
7054	GENERIC_DAY	1	2	2010-01-03	1517	\N	5964
6982	GENERIC_DAY	1	3	2009-12-08	1519	\N	5964
7065	GENERIC_DAY	1	3	2009-12-18	1518	\N	5964
7112	GENERIC_DAY	1	3	2009-12-25	1519	\N	5964
6979	GENERIC_DAY	1	3	2009-11-27	1518	\N	5964
7011	GENERIC_DAY	1	2	2010-01-23	1517	\N	5964
7105	GENERIC_DAY	1	3	2010-01-07	1519	\N	5964
6983	GENERIC_DAY	1	2	2009-12-24	1517	\N	5964
7016	GENERIC_DAY	1	2	2009-12-11	1517	\N	5964
7018	GENERIC_DAY	1	2	2009-11-25	1517	\N	5964
7123	GENERIC_DAY	1	3	2010-01-08	1519	\N	5964
7071	GENERIC_DAY	1	3	2010-01-24	1518	\N	5964
7114	GENERIC_DAY	1	3	2009-12-23	1519	\N	5964
7090	GENERIC_DAY	1	3	2009-12-22	1519	\N	5964
6968	GENERIC_DAY	1	3	2010-01-17	1519	\N	5964
6958	GENERIC_DAY	1	3	2009-12-08	1518	\N	5964
7001	GENERIC_DAY	1	3	2010-01-02	1518	\N	5964
7040	GENERIC_DAY	1	3	2009-12-07	1518	\N	5964
7034	GENERIC_DAY	1	2	2009-12-16	1517	\N	5964
7053	GENERIC_DAY	1	2	2009-12-14	1517	\N	5964
7003	GENERIC_DAY	1	2	2010-01-09	1517	\N	5964
7075	GENERIC_DAY	1	2	2009-11-27	1517	\N	5964
6995	GENERIC_DAY	1	3	2009-11-26	1518	\N	5964
6986	GENERIC_DAY	1	3	2009-12-12	1518	\N	5964
6975	GENERIC_DAY	1	2	2010-01-02	1517	\N	5964
7079	GENERIC_DAY	1	3	2009-12-13	1519	\N	5964
6953	GENERIC_DAY	1	2	2009-12-29	1517	\N	5964
7012	GENERIC_DAY	1	3	2010-01-18	1518	\N	5964
7096	GENERIC_DAY	1	3	2009-12-22	1518	\N	5964
7093	GENERIC_DAY	1	3	2009-12-17	1519	\N	5964
6972	GENERIC_DAY	1	3	2010-01-23	1519	\N	5964
7041	GENERIC_DAY	1	3	2010-01-23	1518	\N	5964
7030	GENERIC_DAY	1	3	2010-01-20	1519	\N	5964
7118	GENERIC_DAY	1	3	2009-11-25	1518	\N	5964
7057	GENERIC_DAY	1	3	2010-01-07	1518	\N	5964
7085	GENERIC_DAY	1	3	2010-01-25	1518	\N	5964
7020	GENERIC_DAY	1	2	2009-12-19	1517	\N	5964
7076	GENERIC_DAY	1	3	2010-01-09	1519	\N	5964
7059	GENERIC_DAY	1	2	2010-01-21	1517	\N	5964
7124	GENERIC_DAY	1	3	2010-01-11	1518	\N	5964
7074	GENERIC_DAY	1	3	2009-12-04	1518	\N	5964
6967	GENERIC_DAY	1	3	2009-12-03	1519	\N	5964
7024	GENERIC_DAY	1	3	2010-01-08	1518	\N	5964
7042	GENERIC_DAY	1	3	2009-12-09	1518	\N	5964
7026	GENERIC_DAY	1	2	2009-12-03	1517	\N	5964
7116	GENERIC_DAY	1	2	2010-01-07	1517	\N	5964
7100	GENERIC_DAY	1	3	2009-12-01	1518	\N	5964
7319	GENERIC_DAY	1	3	2010-02-14	1518	\N	5965
7371	GENERIC_DAY	1	2	2010-02-18	1517	\N	5965
7310	GENERIC_DAY	1	2	2010-03-15	1517	\N	5965
7345	GENERIC_DAY	1	2	2010-03-06	1517	\N	5965
7311	GENERIC_DAY	1	3	2010-03-17	1518	\N	5965
7342	GENERIC_DAY	1	3	2010-02-23	1518	\N	5965
7338	GENERIC_DAY	1	2	2010-03-27	1517	\N	5965
7142	GENERIC_DAY	1	3	2010-03-18	1518	\N	5965
7299	GENERIC_DAY	1	3	2010-02-16	1519	\N	5965
7321	GENERIC_DAY	1	2	2010-02-16	1517	\N	5965
7284	GENERIC_DAY	1	2	2010-02-25	1517	\N	5965
7306	GENERIC_DAY	1	3	2010-02-18	1518	\N	5965
7139	GENERIC_DAY	1	3	2010-03-06	1519	\N	5965
7285	GENERIC_DAY	1	2	2010-03-16	1517	\N	5965
7296	GENERIC_DAY	1	3	2010-03-09	1519	\N	5965
7358	GENERIC_DAY	1	2	2010-03-30	1517	\N	5965
7303	GENERIC_DAY	1	2	2010-03-22	1517	\N	5965
7376	GENERIC_DAY	1	3	2010-02-24	1518	\N	5965
7320	GENERIC_DAY	1	3	2010-04-02	1519	\N	5965
7317	GENERIC_DAY	1	3	2010-02-22	1518	\N	5965
7135	GENERIC_DAY	1	3	2010-03-26	1518	\N	5965
7167	GENERIC_DAY	1	3	2010-03-08	1518	\N	5965
7375	GENERIC_DAY	1	3	2010-03-27	1518	\N	5965
7362	GENERIC_DAY	1	2	2010-03-11	1517	\N	5965
7357	GENERIC_DAY	1	2	2010-02-28	1517	\N	5965
7318	GENERIC_DAY	1	3	2010-03-11	1518	\N	5965
7274	GENERIC_DAY	1	3	2010-03-05	1519	\N	5965
7279	GENERIC_DAY	1	3	2010-02-13	1519	\N	5965
7363	GENERIC_DAY	1	3	2010-02-26	1519	\N	5965
7329	GENERIC_DAY	1	3	2010-03-15	1518	\N	5965
7283	GENERIC_DAY	1	3	2010-03-30	1518	\N	5965
7150	GENERIC_DAY	1	2	2010-03-04	1517	\N	5965
7324	GENERIC_DAY	1	3	2010-03-30	1519	\N	5965
7354	GENERIC_DAY	1	2	2010-02-27	1517	\N	5965
7298	GENERIC_DAY	1	3	2010-03-07	1518	\N	5965
7350	GENERIC_DAY	1	3	2010-03-12	1519	\N	5965
7140	GENERIC_DAY	1	3	2010-03-04	1519	\N	5965
7159	GENERIC_DAY	1	3	2010-02-28	1518	\N	5965
7341	GENERIC_DAY	1	3	2010-03-31	1518	\N	5965
7136	GENERIC_DAY	1	3	2010-02-14	1519	\N	5965
7149	GENERIC_DAY	1	3	2010-03-23	1519	\N	5965
7312	GENERIC_DAY	1	2	2010-02-14	1517	\N	5965
7316	GENERIC_DAY	1	2	2010-02-21	1517	\N	5965
7157	GENERIC_DAY	1	2	2010-02-22	1517	\N	5965
7147	GENERIC_DAY	1	3	2010-03-17	1519	\N	5965
7339	GENERIC_DAY	1	2	2010-03-10	1517	\N	5965
7280	GENERIC_DAY	1	3	2010-03-05	1518	\N	5965
7367	GENERIC_DAY	1	3	2010-03-20	1518	\N	5965
7309	GENERIC_DAY	1	2	2010-02-19	1517	\N	5965
7275	GENERIC_DAY	1	3	2010-03-03	1518	\N	5965
7146	GENERIC_DAY	1	3	2010-02-24	1519	\N	5965
7334	GENERIC_DAY	1	3	2010-03-20	1519	\N	5965
7292	GENERIC_DAY	1	3	2010-04-03	1519	\N	5965
7328	GENERIC_DAY	1	3	2010-03-21	1518	\N	5965
7378	GENERIC_DAY	1	3	2010-03-09	1518	\N	5965
7134	GENERIC_DAY	1	2	2010-04-02	1517	\N	5965
7141	GENERIC_DAY	1	3	2010-02-25	1519	\N	5965
7287	GENERIC_DAY	1	3	2010-03-10	1518	\N	5965
7330	GENERIC_DAY	1	3	2010-03-28	1518	\N	5965
7305	GENERIC_DAY	1	3	2010-03-22	1519	\N	5965
7372	GENERIC_DAY	1	2	2010-03-18	1517	\N	5965
7370	GENERIC_DAY	1	3	2010-02-19	1518	\N	5965
7368	GENERIC_DAY	1	3	2010-03-25	1518	\N	5965
7325	GENERIC_DAY	1	2	2010-03-07	1517	\N	5965
7156	GENERIC_DAY	1	2	2010-03-03	1517	\N	5965
6940	GENERIC_DAY	1	3	2010-01-11	1519	\N	5964
6941	GENERIC_DAY	1	3	2010-01-01	1519	\N	5964
6939	GENERIC_DAY	1	3	2010-01-15	1519	\N	5964
7158	GENERIC_DAY	1	2	2010-02-15	1517	\N	5965
7289	GENERIC_DAY	1	3	2010-03-12	1518	\N	5965
7295	GENERIC_DAY	1	3	2010-02-28	1519	\N	5965
7326	GENERIC_DAY	1	3	2010-02-23	1519	\N	5965
7361	GENERIC_DAY	1	2	2010-02-20	1517	\N	5965
7336	GENERIC_DAY	1	2	2010-02-13	1517	\N	5965
7273	GENERIC_DAY	1	2	2010-03-29	1517	\N	5965
7165	GENERIC_DAY	1	2	2010-03-14	1517	\N	5965
7356	GENERIC_DAY	1	3	2010-02-20	1518	\N	5965
7272	GENERIC_DAY	1	2	2010-03-26	1517	\N	5965
7131	GENERIC_DAY	1	3	2010-03-19	1519	\N	5965
7137	GENERIC_DAY	1	3	2010-03-26	1519	\N	5965
7297	GENERIC_DAY	1	3	2010-04-01	1518	\N	5965
7360	GENERIC_DAY	1	3	2010-03-02	1518	\N	5965
7332	GENERIC_DAY	1	3	2010-03-01	1518	\N	5965
7153	GENERIC_DAY	1	3	2010-03-04	1518	\N	5965
7281	GENERIC_DAY	1	2	2010-03-25	1517	\N	5965
7166	GENERIC_DAY	1	3	2010-02-17	1518	\N	5965
7369	GENERIC_DAY	1	3	2010-02-27	1519	\N	5965
7148	GENERIC_DAY	1	3	2010-02-13	1518	\N	5965
7160	GENERIC_DAY	1	3	2010-03-03	1519	\N	5965
7359	GENERIC_DAY	1	2	2010-04-01	1517	\N	5965
7313	GENERIC_DAY	1	3	2010-02-15	1519	\N	5965
7322	GENERIC_DAY	1	3	2010-03-16	1518	\N	5965
7151	GENERIC_DAY	1	2	2010-02-24	1517	\N	5965
7288	GENERIC_DAY	1	3	2010-03-29	1519	\N	5965
7301	GENERIC_DAY	1	2	2010-03-01	1517	\N	5965
7337	GENERIC_DAY	1	3	2010-03-07	1519	\N	5965
7353	GENERIC_DAY	1	2	2010-02-26	1517	\N	5965
7169	GENERIC_DAY	1	2	2010-03-09	1517	\N	5965
7164	GENERIC_DAY	1	3	2010-04-02	1518	\N	5965
7162	GENERIC_DAY	1	3	2010-03-24	1518	\N	5965
7282	GENERIC_DAY	1	2	2010-03-13	1517	\N	5965
7314	GENERIC_DAY	1	3	2010-03-15	1519	\N	5965
7128	GENERIC_DAY	1	2	2010-03-23	1517	\N	5965
7168	GENERIC_DAY	1	3	2010-03-25	1519	\N	5965
7323	GENERIC_DAY	1	3	2010-03-14	1519	\N	5965
7290	GENERIC_DAY	1	3	2010-03-31	1519	\N	5965
7315	GENERIC_DAY	1	3	2010-04-01	1519	\N	5965
7364	GENERIC_DAY	1	3	2010-03-28	1519	\N	5965
7155	GENERIC_DAY	1	3	2010-03-14	1518	\N	5965
7286	GENERIC_DAY	1	3	2010-03-23	1518	\N	5965
7347	GENERIC_DAY	1	3	2010-03-29	1518	\N	5965
7346	GENERIC_DAY	1	2	2010-03-20	1517	\N	5965
7145	GENERIC_DAY	1	2	2010-02-17	1517	\N	5965
7163	GENERIC_DAY	1	3	2010-03-16	1519	\N	5965
7365	GENERIC_DAY	1	2	2010-03-05	1517	\N	5965
7343	GENERIC_DAY	1	3	2010-03-02	1519	\N	5965
7348	GENERIC_DAY	1	2	2010-03-31	1517	\N	5965
7277	GENERIC_DAY	1	2	2010-02-23	1517	\N	5965
7377	GENERIC_DAY	1	2	2010-03-17	1517	\N	5965
7374	GENERIC_DAY	1	3	2010-03-01	1519	\N	5965
7133	GENERIC_DAY	1	3	2010-03-27	1519	\N	5965
7143	GENERIC_DAY	1	2	2010-03-08	1517	\N	5965
7293	GENERIC_DAY	1	3	2010-02-25	1518	\N	5965
7170	GENERIC_DAY	1	2	2010-04-03	1517	\N	5965
7138	GENERIC_DAY	1	3	2010-03-18	1519	\N	5965
7349	GENERIC_DAY	1	2	2010-03-21	1517	\N	5965
7327	GENERIC_DAY	1	3	2010-02-18	1519	\N	5965
7144	GENERIC_DAY	1	3	2010-03-08	1519	\N	5965
7308	GENERIC_DAY	1	3	2010-02-21	1519	\N	5965
7278	GENERIC_DAY	1	3	2010-03-11	1519	\N	5965
7331	GENERIC_DAY	1	3	2010-03-13	1518	\N	5965
7333	GENERIC_DAY	1	3	2010-02-21	1518	\N	5965
7154	GENERIC_DAY	1	3	2010-03-06	1518	\N	5965
7129	GENERIC_DAY	1	3	2010-02-27	1518	\N	5965
7302	GENERIC_DAY	1	2	2010-03-02	1517	\N	5965
7352	GENERIC_DAY	1	3	2010-04-03	1518	\N	5965
7291	GENERIC_DAY	1	3	2010-03-13	1519	\N	5965
7161	GENERIC_DAY	1	2	2010-03-24	1517	\N	5965
7294	GENERIC_DAY	1	2	2010-03-28	1517	\N	5965
7351	GENERIC_DAY	1	3	2010-02-26	1518	\N	5965
7132	GENERIC_DAY	1	3	2010-03-22	1518	\N	5965
7130	GENERIC_DAY	1	3	2010-03-24	1519	\N	5965
7355	GENERIC_DAY	1	2	2010-03-19	1517	\N	5965
7304	GENERIC_DAY	1	2	2010-03-12	1517	\N	5965
7340	GENERIC_DAY	1	3	2010-02-15	1518	\N	5965
7344	GENERIC_DAY	1	3	2010-03-19	1518	\N	5965
7373	GENERIC_DAY	1	3	2010-02-17	1519	\N	5965
7300	GENERIC_DAY	1	3	2010-02-16	1518	\N	5965
7366	GENERIC_DAY	1	3	2010-02-20	1519	\N	5965
7335	GENERIC_DAY	1	3	2010-02-22	1519	\N	5965
7276	GENERIC_DAY	1	3	2010-03-21	1519	\N	5965
7152	GENERIC_DAY	1	3	2010-02-19	1519	\N	5965
7307	GENERIC_DAY	1	3	2010-03-10	1519	\N	5965
7597	GENERIC_DAY	1	3	2010-02-08	1518	\N	5966
7606	GENERIC_DAY	1	2	2010-01-20	1519	\N	5966
7600	GENERIC_DAY	1	3	2010-01-04	1518	\N	5966
7584	GENERIC_DAY	1	3	2010-01-02	1517	\N	5966
7583	GENERIC_DAY	1	3	2009-12-31	1517	\N	5966
7542	GENERIC_DAY	1	3	2009-12-06	1518	\N	5966
9404	GENERIC_DAY	0	5	2010-02-09	1515	\N	5979
9405	GENERIC_DAY	0	3	2010-02-24	1519	\N	5979
9406	GENERIC_DAY	0	3	2010-02-14	1519	\N	5979
9407	GENERIC_DAY	0	4	2010-01-04	1515	\N	5979
9408	GENERIC_DAY	0	4	2009-12-31	1515	\N	5979
9409	GENERIC_DAY	0	4	2010-01-26	1519	\N	5979
9410	GENERIC_DAY	0	4	2010-01-12	1519	\N	5979
9411	GENERIC_DAY	0	3	2010-01-18	1515	\N	5979
9412	GENERIC_DAY	0	4	2009-12-31	1519	\N	5979
9413	GENERIC_DAY	0	3	2010-01-15	1515	\N	5979
9414	GENERIC_DAY	0	4	2010-01-13	1515	\N	5979
9415	GENERIC_DAY	0	4	2010-01-11	1515	\N	5979
9416	GENERIC_DAY	0	4	2010-01-13	1519	\N	5979
9417	GENERIC_DAY	0	5	2010-02-23	1515	\N	5979
9418	GENERIC_DAY	0	3	2010-02-01	1519	\N	5979
9419	GENERIC_DAY	0	3	2010-02-02	1519	\N	5979
9420	GENERIC_DAY	0	5	2010-02-12	1515	\N	5979
9421	GENERIC_DAY	0	3	2010-01-28	1519	\N	5979
9422	GENERIC_DAY	0	3	2010-02-23	1519	\N	5979
9423	GENERIC_DAY	0	4	2010-01-08	1515	\N	5979
9424	GENERIC_DAY	0	5	2010-02-01	1515	\N	5979
9425	GENERIC_DAY	0	3	2010-01-25	1515	\N	5979
9426	GENERIC_DAY	0	4	2010-01-06	1519	\N	5979
9427	GENERIC_DAY	0	5	2010-01-25	1519	\N	5979
9428	GENERIC_DAY	0	3	2010-02-04	1519	\N	5979
9429	GENERIC_DAY	0	3	2010-01-27	1519	\N	5979
9430	GENERIC_DAY	0	3	2010-02-10	1519	\N	5979
9431	GENERIC_DAY	0	5	2010-01-22	1519	\N	5979
9432	GENERIC_DAY	0	4	2009-12-30	1519	\N	5979
9433	GENERIC_DAY	0	4	2010-01-07	1519	\N	5979
9434	GENERIC_DAY	0	5	2010-02-18	1515	\N	5979
9435	GENERIC_DAY	0	5	2010-02-22	1515	\N	5979
9436	GENERIC_DAY	0	4	2009-12-28	1519	\N	5979
9437	GENERIC_DAY	0	3	2010-02-21	1519	\N	5979
9438	GENERIC_DAY	0	3	2010-01-22	1515	\N	5979
9439	GENERIC_DAY	0	1	2010-02-26	1519	\N	5979
9440	GENERIC_DAY	0	3	2010-01-21	1515	\N	5979
9441	GENERIC_DAY	0	5	2010-01-16	1519	\N	5979
9442	GENERIC_DAY	0	4	2010-01-08	1519	\N	5979
9443	GENERIC_DAY	0	4	2010-01-09	1519	\N	5979
9444	GENERIC_DAY	0	4	2010-01-12	1515	\N	5979
9445	GENERIC_DAY	0	4	2010-01-11	1519	\N	5979
9446	GENERIC_DAY	0	5	2010-02-24	1515	\N	5979
9447	GENERIC_DAY	0	4	2009-12-30	1515	\N	5979
9448	GENERIC_DAY	0	4	2010-01-06	1515	\N	5979
9449	GENERIC_DAY	0	3	2010-02-07	1519	\N	5979
9450	GENERIC_DAY	0	5	2010-01-15	1519	\N	5979
9451	GENERIC_DAY	0	5	2010-02-13	1515	\N	5979
9452	GENERIC_DAY	0	4	2009-12-26	1515	\N	5979
9453	GENERIC_DAY	0	4	2010-01-04	1519	\N	5979
9454	GENERIC_DAY	0	3	2010-01-29	1519	\N	5979
9455	GENERIC_DAY	0	4	2009-12-29	1519	\N	5979
9456	GENERIC_DAY	0	4	2009-12-27	1519	\N	5979
9457	GENERIC_DAY	0	3	2010-01-14	1515	\N	5979
9458	GENERIC_DAY	0	5	2010-01-24	1519	\N	5979
9459	GENERIC_DAY	0	5	2010-02-15	1515	\N	5979
9460	GENERIC_DAY	0	4	2010-01-01	1519	\N	5979
9461	GENERIC_DAY	0	4	2010-01-10	1515	\N	5979
9462	GENERIC_DAY	0	3	2010-02-22	1519	\N	5979
9463	GENERIC_DAY	0	3	2010-02-25	1519	\N	5979
9464	GENERIC_DAY	0	3	2010-02-17	1519	\N	5979
9465	GENERIC_DAY	0	3	2010-01-24	1515	\N	5979
9466	GENERIC_DAY	0	4	2010-01-07	1515	\N	5979
9467	GENERIC_DAY	0	5	2010-02-14	1515	\N	5979
9468	GENERIC_DAY	0	5	2010-02-05	1515	\N	5979
9469	GENERIC_DAY	0	5	2010-01-30	1515	\N	5979
9470	GENERIC_DAY	0	5	2010-02-16	1515	\N	5979
9471	GENERIC_DAY	0	3	2010-02-16	1519	\N	5979
9472	GENERIC_DAY	0	3	2010-02-05	1519	\N	5979
9473	GENERIC_DAY	0	5	2010-02-07	1515	\N	5979
9474	GENERIC_DAY	0	3	2010-02-03	1519	\N	5979
9475	GENERIC_DAY	0	5	2010-02-10	1515	\N	5979
9476	GENERIC_DAY	0	5	2010-01-21	1519	\N	5979
9477	GENERIC_DAY	0	5	2010-02-17	1515	\N	5979
9478	GENERIC_DAY	0	4	2010-01-02	1515	\N	5979
9479	GENERIC_DAY	0	3	2010-02-06	1519	\N	5979
9480	GENERIC_DAY	0	5	2010-02-03	1515	\N	5979
9481	GENERIC_DAY	0	3	2010-02-20	1519	\N	5979
9482	GENERIC_DAY	0	3	2010-02-08	1519	\N	5979
9483	GENERIC_DAY	0	4	2010-01-09	1515	\N	5979
9484	GENERIC_DAY	0	5	2010-02-06	1515	\N	5979
9485	GENERIC_DAY	0	5	2010-01-14	1519	\N	5979
9486	GENERIC_DAY	0	4	2010-01-01	1515	\N	5979
9487	GENERIC_DAY	0	4	2010-01-10	1519	\N	5979
9488	GENERIC_DAY	0	5	2010-02-04	1515	\N	5979
9489	GENERIC_DAY	0	3	2010-01-30	1519	\N	5979
9490	GENERIC_DAY	0	5	2010-01-18	1519	\N	5979
9491	GENERIC_DAY	0	3	2010-02-15	1519	\N	5979
9492	GENERIC_DAY	0	5	2010-02-21	1515	\N	5979
9493	GENERIC_DAY	0	5	2010-02-11	1515	\N	5979
9494	GENERIC_DAY	0	5	2010-02-19	1515	\N	5979
9495	GENERIC_DAY	0	4	2010-01-05	1519	\N	5979
9496	GENERIC_DAY	0	4	2009-12-26	1519	\N	5979
9497	GENERIC_DAY	0	5	2010-02-08	1515	\N	5979
9498	GENERIC_DAY	0	3	2010-02-09	1519	\N	5979
9499	GENERIC_DAY	0	5	2010-01-20	1519	\N	5979
9500	GENERIC_DAY	0	5	2010-01-17	1519	\N	5979
9501	GENERIC_DAY	0	3	2010-02-26	1515	\N	5979
9502	GENERIC_DAY	0	4	2009-12-29	1515	\N	5979
9503	GENERIC_DAY	0	3	2010-02-13	1519	\N	5979
9504	GENERIC_DAY	0	5	2010-01-27	1515	\N	5979
9505	GENERIC_DAY	0	3	2010-01-19	1515	\N	5979
9506	GENERIC_DAY	0	5	2010-01-29	1515	\N	5979
9507	GENERIC_DAY	0	4	2009-12-27	1515	\N	5979
9508	GENERIC_DAY	0	5	2010-01-19	1519	\N	5979
9509	GENERIC_DAY	0	3	2010-01-16	1515	\N	5979
9510	GENERIC_DAY	0	3	2010-01-17	1515	\N	5979
9511	GENERIC_DAY	0	5	2010-01-28	1515	\N	5979
9512	GENERIC_DAY	0	4	2010-01-03	1519	\N	5979
9513	GENERIC_DAY	0	3	2010-01-31	1519	\N	5979
9514	GENERIC_DAY	0	4	2010-01-05	1515	\N	5979
9515	GENERIC_DAY	0	3	2010-01-23	1515	\N	5979
9516	GENERIC_DAY	0	5	2010-02-02	1515	\N	5979
9517	GENERIC_DAY	0	4	2010-01-03	1515	\N	5979
9518	GENERIC_DAY	0	3	2010-02-11	1519	\N	5979
9519	GENERIC_DAY	0	4	2010-01-26	1515	\N	5979
9520	GENERIC_DAY	0	3	2010-01-20	1515	\N	5979
9521	GENERIC_DAY	0	5	2010-02-25	1515	\N	5979
9522	GENERIC_DAY	0	4	2010-01-02	1519	\N	5979
9523	GENERIC_DAY	0	3	2010-02-12	1519	\N	5979
9524	GENERIC_DAY	0	3	2010-02-19	1519	\N	5979
9525	GENERIC_DAY	0	3	2010-02-18	1519	\N	5979
9526	GENERIC_DAY	0	5	2010-01-31	1515	\N	5979
9527	GENERIC_DAY	0	5	2010-02-20	1515	\N	5979
9528	GENERIC_DAY	0	5	2010-01-23	1519	\N	5979
9529	GENERIC_DAY	0	4	2009-12-28	1515	\N	5979
9530	GENERIC_DAY	0	5	2010-03-06	1516	\N	5980
9531	GENERIC_DAY	0	3	2010-03-22	1518	\N	5980
9532	GENERIC_DAY	0	4	2010-04-16	1518	\N	5980
9533	GENERIC_DAY	0	4	2010-04-04	1518	\N	5980
9534	GENERIC_DAY	0	5	2010-03-20	1516	\N	5980
9535	GENERIC_DAY	0	5	2010-03-17	1516	\N	5980
9536	GENERIC_DAY	0	4	2010-04-17	1516	\N	5980
9537	GENERIC_DAY	0	4	2010-04-15	1516	\N	5980
9538	GENERIC_DAY	0	5	2010-03-23	1516	\N	5980
9539	GENERIC_DAY	0	3	2010-04-01	1518	\N	5980
9540	GENERIC_DAY	0	3	2010-03-24	1518	\N	5980
9541	GENERIC_DAY	0	3	2010-03-17	1518	\N	5980
9542	GENERIC_DAY	0	3	2010-04-02	1518	\N	5980
9543	GENERIC_DAY	0	4	2010-04-13	1516	\N	5980
9544	GENERIC_DAY	0	3	2010-03-03	1518	\N	5980
9545	GENERIC_DAY	0	4	2010-04-15	1518	\N	5980
9546	GENERIC_DAY	0	5	2010-03-03	1516	\N	5980
9547	GENERIC_DAY	0	5	2010-03-01	1516	\N	5980
9548	GENERIC_DAY	0	4	2010-04-09	1516	\N	5980
9549	GENERIC_DAY	0	3	2010-03-06	1518	\N	5980
9550	GENERIC_DAY	0	5	2010-04-02	1516	\N	5980
9551	GENERIC_DAY	0	4	2010-04-06	1518	\N	5980
9552	GENERIC_DAY	0	3	2010-03-30	1518	\N	5980
9553	GENERIC_DAY	0	4	2010-04-07	1516	\N	5980
9554	GENERIC_DAY	0	3	2010-02-28	1518	\N	5980
9555	GENERIC_DAY	0	4	2010-04-11	1516	\N	5980
9556	GENERIC_DAY	0	3	2010-03-02	1518	\N	5980
9557	GENERIC_DAY	0	3	2010-03-13	1518	\N	5980
9558	GENERIC_DAY	0	5	2010-03-16	1516	\N	5980
9559	GENERIC_DAY	0	4	2010-04-16	1516	\N	5980
9560	GENERIC_DAY	0	5	2010-03-07	1516	\N	5980
9561	GENERIC_DAY	0	4	2010-04-12	1518	\N	5980
9562	GENERIC_DAY	0	5	2010-03-09	1516	\N	5980
9563	GENERIC_DAY	0	5	2010-03-14	1516	\N	5980
9564	GENERIC_DAY	0	4	2010-04-14	1518	\N	5980
9565	GENERIC_DAY	0	4	2010-04-05	1516	\N	5980
9566	GENERIC_DAY	0	5	2010-03-30	1516	\N	5980
9567	GENERIC_DAY	0	3	2010-03-31	1518	\N	5980
9568	GENERIC_DAY	0	5	2010-02-28	1516	\N	5980
9569	GENERIC_DAY	0	3	2010-03-21	1518	\N	5980
9570	GENERIC_DAY	0	5	2010-04-03	1516	\N	5980
9571	GENERIC_DAY	0	3	2010-03-26	1518	\N	5980
9572	GENERIC_DAY	0	3	2010-03-10	1518	\N	5980
9573	GENERIC_DAY	0	4	2010-04-05	1518	\N	5980
9574	GENERIC_DAY	0	5	2010-03-08	1516	\N	5980
9575	GENERIC_DAY	0	5	2010-03-11	1516	\N	5980
9576	GENERIC_DAY	0	3	2010-03-29	1518	\N	5980
9577	GENERIC_DAY	0	3	2010-03-15	1518	\N	5980
9578	GENERIC_DAY	0	5	2010-03-21	1516	\N	5980
9579	GENERIC_DAY	0	5	2010-03-31	1516	\N	5980
9580	GENERIC_DAY	0	3	2010-03-09	1518	\N	5980
9581	GENERIC_DAY	0	3	2010-03-01	1518	\N	5980
9582	GENERIC_DAY	0	5	2010-03-27	1516	\N	5980
9583	GENERIC_DAY	0	3	2010-03-08	1518	\N	5980
9584	GENERIC_DAY	0	5	2010-03-04	1516	\N	5980
9585	GENERIC_DAY	0	4	2010-04-04	1516	\N	5980
9586	GENERIC_DAY	0	3	2010-03-05	1518	\N	5980
9587	GENERIC_DAY	0	5	2010-03-10	1516	\N	5980
9588	GENERIC_DAY	0	3	2010-03-28	1518	\N	5980
9589	GENERIC_DAY	0	5	2010-02-27	1516	\N	5980
9590	GENERIC_DAY	0	3	2010-03-07	1518	\N	5980
9591	GENERIC_DAY	0	3	2010-03-23	1518	\N	5980
9592	GENERIC_DAY	0	4	2010-04-12	1516	\N	5980
9593	GENERIC_DAY	0	3	2010-03-14	1518	\N	5980
9594	GENERIC_DAY	0	4	2010-04-09	1518	\N	5980
9595	GENERIC_DAY	0	5	2010-03-18	1516	\N	5980
9596	GENERIC_DAY	0	3	2010-02-27	1518	\N	5980
9597	GENERIC_DAY	0	5	2010-03-12	1516	\N	5980
9598	GENERIC_DAY	0	3	2010-03-11	1518	\N	5980
9599	GENERIC_DAY	0	5	2010-03-19	1516	\N	5980
9600	GENERIC_DAY	0	5	2010-03-26	1516	\N	5980
9601	GENERIC_DAY	0	5	2010-03-13	1516	\N	5980
9602	GENERIC_DAY	0	3	2010-03-16	1518	\N	5980
9603	GENERIC_DAY	0	5	2010-04-01	1516	\N	5980
9604	GENERIC_DAY	0	4	2010-04-08	1518	\N	5980
9605	GENERIC_DAY	0	5	2010-03-28	1516	\N	5980
9606	GENERIC_DAY	0	4	2010-04-10	1518	\N	5980
9607	GENERIC_DAY	0	5	2010-03-22	1516	\N	5980
9608	GENERIC_DAY	0	4	2010-04-08	1516	\N	5980
9609	GENERIC_DAY	0	5	2010-03-29	1516	\N	5980
9610	GENERIC_DAY	0	4	2010-04-11	1518	\N	5980
9611	GENERIC_DAY	0	3	2010-03-19	1518	\N	5980
9612	GENERIC_DAY	0	4	2010-04-07	1518	\N	5980
9613	GENERIC_DAY	0	4	2010-04-14	1516	\N	5980
9614	GENERIC_DAY	0	3	2010-03-27	1518	\N	5980
9615	GENERIC_DAY	0	3	2010-03-12	1518	\N	5980
9616	GENERIC_DAY	0	3	2010-03-25	1518	\N	5980
9617	GENERIC_DAY	0	5	2010-03-25	1516	\N	5980
9618	GENERIC_DAY	0	5	2010-03-02	1516	\N	5980
9619	GENERIC_DAY	0	3	2010-04-03	1518	\N	5980
9620	GENERIC_DAY	0	3	2010-03-04	1518	\N	5980
9621	GENERIC_DAY	0	4	2010-04-10	1516	\N	5980
9622	GENERIC_DAY	0	4	2010-04-17	1518	\N	5980
9623	GENERIC_DAY	0	5	2010-03-05	1516	\N	5980
9624	GENERIC_DAY	0	5	2010-03-24	1516	\N	5980
9625	GENERIC_DAY	0	4	2010-04-13	1518	\N	5980
9626	GENERIC_DAY	0	5	2010-03-15	1516	\N	5980
9627	GENERIC_DAY	0	3	2010-03-20	1518	\N	5980
9628	GENERIC_DAY	0	3	2010-03-18	1518	\N	5980
9629	GENERIC_DAY	0	4	2010-04-06	1516	\N	5980
9630	GENERIC_DAY	0	2	2010-02-10	1519	\N	5981
9631	GENERIC_DAY	0	3	2010-01-25	1517	\N	5981
9632	GENERIC_DAY	0	2	2010-02-02	1519	\N	5981
9633	GENERIC_DAY	0	2	2010-02-06	1519	\N	5981
9634	GENERIC_DAY	0	3	2010-02-11	1517	\N	5981
9635	GENERIC_DAY	0	4	2010-03-12	1517	\N	5981
9636	GENERIC_DAY	0	2	2010-01-21	1518	\N	5981
9637	GENERIC_DAY	0	4	2010-02-27	1519	\N	5981
9638	GENERIC_DAY	0	4	2010-03-15	1519	\N	5981
9639	GENERIC_DAY	0	4	2010-03-03	1517	\N	5981
9640	GENERIC_DAY	0	4	2010-03-11	1519	\N	5981
9641	GENERIC_DAY	0	3	2010-02-13	1518	\N	5981
9642	GENERIC_DAY	0	4	2010-03-06	1517	\N	5981
9643	GENERIC_DAY	0	3	2010-01-22	1517	\N	5981
9644	GENERIC_DAY	0	2	2010-01-29	1519	\N	5981
9645	GENERIC_DAY	0	0	2010-03-17	1518	\N	5981
9646	GENERIC_DAY	0	2	2010-01-28	1519	\N	5981
9647	GENERIC_DAY	0	4	2010-03-13	1519	\N	5981
9648	GENERIC_DAY	0	3	2010-02-23	1518	\N	5981
9649	GENERIC_DAY	0	3	2010-01-16	1517	\N	5981
9650	GENERIC_DAY	0	0	2010-03-14	1518	\N	5981
9651	GENERIC_DAY	0	1	2010-02-19	1519	\N	5981
9652	GENERIC_DAY	0	1	2010-02-21	1519	\N	5981
9653	GENERIC_DAY	0	4	2010-03-04	1517	\N	5981
9654	GENERIC_DAY	0	4	2010-03-01	1519	\N	5981
9655	GENERIC_DAY	0	3	2010-01-23	1517	\N	5981
9656	GENERIC_DAY	0	2	2010-02-11	1519	\N	5981
9657	GENERIC_DAY	0	1	2010-02-18	1519	\N	5981
9658	GENERIC_DAY	0	2	2010-01-17	1518	\N	5981
9659	GENERIC_DAY	0	4	2010-03-03	1519	\N	5981
9660	GENERIC_DAY	0	3	2010-02-01	1517	\N	5981
9661	GENERIC_DAY	0	3	2010-02-15	1518	\N	5981
9662	GENERIC_DAY	0	3	2010-02-26	1518	\N	5981
9663	GENERIC_DAY	0	3	2010-02-06	1518	\N	5981
9664	GENERIC_DAY	0	3	2010-02-07	1518	\N	5981
9665	GENERIC_DAY	0	4	2010-02-20	1517	\N	5981
9666	GENERIC_DAY	0	2	2010-02-03	1519	\N	5981
9667	GENERIC_DAY	0	3	2010-01-16	1519	\N	5981
9668	GENERIC_DAY	0	3	2010-02-09	1518	\N	5981
9669	GENERIC_DAY	0	3	2010-01-17	1517	\N	5981
9670	GENERIC_DAY	0	1	2010-02-20	1519	\N	5981
9671	GENERIC_DAY	0	4	2010-02-15	1517	\N	5981
9672	GENERIC_DAY	0	2	2010-01-30	1519	\N	5981
9673	GENERIC_DAY	0	2	2010-02-09	1519	\N	5981
9674	GENERIC_DAY	0	4	2010-03-16	1517	\N	5981
9675	GENERIC_DAY	0	2	2010-01-18	1518	\N	5981
9676	GENERIC_DAY	0	3	2010-01-27	1517	\N	5981
9677	GENERIC_DAY	0	4	2010-03-11	1517	\N	5981
9678	GENERIC_DAY	0	3	2010-02-02	1517	\N	5981
9679	GENERIC_DAY	0	0	2010-03-10	1518	\N	5981
9680	GENERIC_DAY	0	3	2010-02-05	1517	\N	5981
9681	GENERIC_DAY	0	4	2010-02-28	1519	\N	5981
9682	GENERIC_DAY	0	0	2010-03-08	1518	\N	5981
9683	GENERIC_DAY	0	3	2010-02-08	1517	\N	5981
9684	GENERIC_DAY	0	2	2010-03-19	1519	\N	5981
9685	GENERIC_DAY	0	1	2010-02-14	1519	\N	5981
9686	GENERIC_DAY	0	3	2010-01-24	1517	\N	5981
9687	GENERIC_DAY	0	3	2010-01-31	1517	\N	5981
9688	GENERIC_DAY	0	4	2010-03-09	1517	\N	5981
9689	GENERIC_DAY	0	3	2010-01-26	1517	\N	5981
9690	GENERIC_DAY	0	3	2010-02-16	1518	\N	5981
9691	GENERIC_DAY	0	0	2010-03-15	1518	\N	5981
9692	GENERIC_DAY	0	4	2010-03-09	1519	\N	5981
9693	GENERIC_DAY	0	4	2010-03-12	1519	\N	5981
9694	GENERIC_DAY	0	2	2010-02-08	1519	\N	5981
9695	GENERIC_DAY	0	2	2010-02-05	1519	\N	5981
9696	GENERIC_DAY	0	3	2010-01-21	1517	\N	5981
9697	GENERIC_DAY	0	3	2010-01-25	1519	\N	5981
9698	GENERIC_DAY	0	3	2010-01-20	1519	\N	5981
9699	GENERIC_DAY	0	3	2010-01-29	1518	\N	5981
9700	GENERIC_DAY	0	4	2010-02-24	1517	\N	5981
9701	GENERIC_DAY	0	4	2010-03-08	1517	\N	5981
9702	GENERIC_DAY	0	0	2010-03-06	1518	\N	5981
9703	GENERIC_DAY	0	3	2010-02-07	1517	\N	5981
9704	GENERIC_DAY	0	4	2010-03-08	1519	\N	5981
9705	GENERIC_DAY	0	4	2010-03-02	1517	\N	5981
9706	GENERIC_DAY	0	3	2010-02-09	1517	\N	5981
9707	GENERIC_DAY	0	3	2010-02-19	1518	\N	5981
9708	GENERIC_DAY	0	4	2010-03-01	1517	\N	5981
9709	GENERIC_DAY	0	3	2010-02-01	1518	\N	5981
9710	GENERIC_DAY	0	2	2010-01-27	1519	\N	5981
9711	GENERIC_DAY	0	3	2010-02-14	1518	\N	5981
9712	GENERIC_DAY	0	4	2010-03-10	1517	\N	5981
9713	GENERIC_DAY	0	3	2010-02-03	1518	\N	5981
9714	GENERIC_DAY	0	4	2010-03-10	1519	\N	5981
9715	GENERIC_DAY	0	3	2010-02-02	1518	\N	5981
9716	GENERIC_DAY	0	0	2010-03-03	1518	\N	5981
9717	GENERIC_DAY	0	0	2010-03-05	1518	\N	5981
9718	GENERIC_DAY	0	1	2010-02-23	1519	\N	5981
9719	GENERIC_DAY	0	3	2010-01-29	1517	\N	5981
9720	GENERIC_DAY	0	3	2010-01-20	1517	\N	5981
9721	GENERIC_DAY	0	0	2010-03-12	1518	\N	5981
9722	GENERIC_DAY	0	2	2010-02-01	1519	\N	5981
9723	GENERIC_DAY	0	2	2010-02-26	1519	\N	5981
9724	GENERIC_DAY	0	4	2010-03-06	1519	\N	5981
9725	GENERIC_DAY	0	4	2010-03-18	1517	\N	5981
9726	GENERIC_DAY	0	3	2010-02-21	1518	\N	5981
9727	GENERIC_DAY	0	0	2010-03-16	1518	\N	5981
9728	GENERIC_DAY	0	3	2010-01-27	1518	\N	5981
9729	GENERIC_DAY	0	3	2010-02-25	1518	\N	5981
9730	GENERIC_DAY	0	3	2010-01-19	1519	\N	5981
9731	GENERIC_DAY	0	3	2010-01-21	1519	\N	5981
9732	GENERIC_DAY	0	2	2010-02-12	1519	\N	5981
9733	GENERIC_DAY	0	4	2010-02-28	1517	\N	5981
9734	GENERIC_DAY	0	3	2010-02-04	1517	\N	5981
9735	GENERIC_DAY	0	3	2010-01-18	1517	\N	5981
9736	GENERIC_DAY	0	4	2010-03-13	1517	\N	5981
9737	GENERIC_DAY	0	4	2010-02-23	1517	\N	5981
9738	GENERIC_DAY	0	4	2010-03-04	1519	\N	5981
9739	GENERIC_DAY	0	3	2010-01-22	1519	\N	5981
9740	GENERIC_DAY	0	2	2010-01-23	1518	\N	5981
9741	GENERIC_DAY	0	3	2010-02-12	1518	\N	5981
9742	GENERIC_DAY	0	2	2010-01-16	1518	\N	5981
9743	GENERIC_DAY	0	3	2010-01-23	1519	\N	5981
9744	GENERIC_DAY	0	4	2010-02-13	1517	\N	5981
9745	GENERIC_DAY	0	4	2010-03-05	1519	\N	5981
9746	GENERIC_DAY	0	4	2010-03-07	1517	\N	5981
9747	GENERIC_DAY	0	3	2010-02-24	1518	\N	5981
9748	GENERIC_DAY	0	3	2010-02-20	1518	\N	5981
9749	GENERIC_DAY	0	4	2010-03-17	1517	\N	5981
9750	GENERIC_DAY	0	2	2010-01-24	1518	\N	5981
9751	GENERIC_DAY	0	3	2010-02-03	1517	\N	5981
9752	GENERIC_DAY	0	3	2010-02-04	1518	\N	5981
9753	GENERIC_DAY	0	2	2010-03-19	1517	\N	5981
9754	GENERIC_DAY	0	2	2010-01-25	1518	\N	5981
9755	GENERIC_DAY	0	4	2010-02-22	1517	\N	5981
9756	GENERIC_DAY	0	3	2010-01-24	1519	\N	5981
9757	GENERIC_DAY	0	3	2010-01-30	1517	\N	5981
9758	GENERIC_DAY	0	0	2010-03-18	1518	\N	5981
9759	GENERIC_DAY	0	2	2010-01-20	1518	\N	5981
9760	GENERIC_DAY	0	0	2010-02-28	1518	\N	5981
9761	GENERIC_DAY	0	0	2010-03-13	1518	\N	5981
9762	GENERIC_DAY	0	3	2010-01-31	1518	\N	5981
9763	GENERIC_DAY	0	3	2010-01-28	1518	\N	5981
9764	GENERIC_DAY	0	3	2010-02-05	1518	\N	5981
9765	GENERIC_DAY	0	3	2010-01-19	1517	\N	5981
9766	GENERIC_DAY	0	3	2010-02-11	1518	\N	5981
9767	GENERIC_DAY	0	0	2010-03-02	1518	\N	5981
9768	GENERIC_DAY	0	2	2010-01-19	1518	\N	5981
9769	GENERIC_DAY	0	4	2010-03-15	1517	\N	5981
9770	GENERIC_DAY	0	0	2010-03-09	1518	\N	5981
9771	GENERIC_DAY	0	1	2010-02-16	1519	\N	5981
9772	GENERIC_DAY	0	4	2010-03-02	1519	\N	5981
9773	GENERIC_DAY	0	3	2010-01-26	1518	\N	5981
9774	GENERIC_DAY	0	3	2010-02-18	1518	\N	5981
9775	GENERIC_DAY	0	3	2010-01-28	1517	\N	5981
9776	GENERIC_DAY	0	1	2010-02-17	1519	\N	5981
9777	GENERIC_DAY	0	2	2010-01-22	1518	\N	5981
9778	GENERIC_DAY	0	3	2010-02-22	1518	\N	5981
9779	GENERIC_DAY	0	4	2010-02-25	1517	\N	5981
9780	GENERIC_DAY	0	1	2010-02-24	1519	\N	5981
9781	GENERIC_DAY	0	2	2010-02-04	1519	\N	5981
9782	GENERIC_DAY	0	4	2010-03-14	1517	\N	5981
9783	GENERIC_DAY	0	4	2010-03-14	1519	\N	5981
9784	GENERIC_DAY	0	1	2010-02-15	1519	\N	5981
9785	GENERIC_DAY	0	3	2010-02-10	1518	\N	5981
9786	GENERIC_DAY	0	1	2010-02-13	1519	\N	5981
9787	GENERIC_DAY	0	3	2010-02-10	1517	\N	5981
9788	GENERIC_DAY	0	4	2010-02-14	1517	\N	5981
9789	GENERIC_DAY	0	4	2010-03-18	1519	\N	5981
9790	GENERIC_DAY	0	0	2010-03-04	1518	\N	5981
9791	GENERIC_DAY	0	2	2010-01-31	1519	\N	5981
9792	GENERIC_DAY	0	4	2010-03-05	1517	\N	5981
9793	GENERIC_DAY	0	4	2010-02-17	1517	\N	5981
9794	GENERIC_DAY	0	3	2010-01-18	1519	\N	5981
9795	GENERIC_DAY	0	4	2010-02-18	1517	\N	5981
9796	GENERIC_DAY	0	0	2010-02-27	1518	\N	5981
9797	GENERIC_DAY	0	3	2010-01-30	1518	\N	5981
9798	GENERIC_DAY	0	2	2010-02-07	1519	\N	5981
9799	GENERIC_DAY	0	3	2010-01-17	1519	\N	5981
9800	GENERIC_DAY	0	0	2010-03-01	1518	\N	5981
9801	GENERIC_DAY	0	3	2010-02-17	1518	\N	5981
9802	GENERIC_DAY	0	0	2010-03-19	1518	\N	5981
9803	GENERIC_DAY	0	0	2010-03-07	1518	\N	5981
9804	GENERIC_DAY	0	2	2010-01-26	1519	\N	5981
9805	GENERIC_DAY	0	0	2010-03-11	1518	\N	5981
9806	GENERIC_DAY	0	4	2010-03-17	1519	\N	5981
9807	GENERIC_DAY	0	3	2010-02-06	1517	\N	5981
9808	GENERIC_DAY	0	4	2010-03-16	1519	\N	5981
9809	GENERIC_DAY	0	4	2010-02-21	1517	\N	5981
9810	GENERIC_DAY	0	4	2010-03-07	1519	\N	5981
9811	GENERIC_DAY	0	3	2010-02-12	1517	\N	5981
9812	GENERIC_DAY	0	4	2010-02-19	1517	\N	5981
9813	GENERIC_DAY	0	1	2010-02-22	1519	\N	5981
9814	GENERIC_DAY	0	4	2010-02-27	1517	\N	5981
9815	GENERIC_DAY	0	1	2010-02-25	1519	\N	5981
9816	GENERIC_DAY	0	3	2010-02-08	1518	\N	5981
9817	GENERIC_DAY	0	4	2010-02-16	1517	\N	5981
9818	GENERIC_DAY	0	3	2010-02-26	1517	\N	5981
9819	GENERIC_DAY	0	0	2010-01-01	1518	\N	5982
9820	GENERIC_DAY	0	0	2009-12-01	1518	\N	5982
9821	GENERIC_DAY	0	8	2010-01-09	1516	\N	5982
9822	GENERIC_DAY	0	0	2009-12-15	1518	\N	5982
9823	GENERIC_DAY	0	0	2009-12-08	1518	\N	5982
9824	GENERIC_DAY	0	8	2009-12-25	1516	\N	5982
9825	GENERIC_DAY	0	0	2009-12-26	1518	\N	5982
9826	GENERIC_DAY	0	8	2009-12-26	1516	\N	5982
9827	GENERIC_DAY	0	0	2009-12-29	1518	\N	5982
9828	GENERIC_DAY	0	0	2009-11-30	1518	\N	5982
9829	GENERIC_DAY	0	8	2009-12-09	1516	\N	5982
9830	GENERIC_DAY	0	0	2009-12-28	1518	\N	5982
9831	GENERIC_DAY	0	0	2009-12-19	1518	\N	5982
9832	GENERIC_DAY	0	8	2010-01-11	1516	\N	5982
9833	GENERIC_DAY	0	0	2009-11-26	1518	\N	5982
9834	GENERIC_DAY	0	0	2010-01-02	1518	\N	5982
9835	GENERIC_DAY	0	0	2009-12-04	1518	\N	5982
9836	GENERIC_DAY	0	0	2010-01-07	1518	\N	5982
9837	GENERIC_DAY	0	8	2009-12-29	1516	\N	5982
9838	GENERIC_DAY	0	8	2009-12-28	1516	\N	5982
9839	GENERIC_DAY	0	8	2009-12-05	1516	\N	5982
9840	GENERIC_DAY	0	0	2010-01-13	1518	\N	5982
9841	GENERIC_DAY	0	8	2010-01-08	1516	\N	5982
9842	GENERIC_DAY	0	8	2009-12-15	1516	\N	5982
9843	GENERIC_DAY	0	0	2009-12-05	1518	\N	5982
9844	GENERIC_DAY	0	0	2010-01-10	1518	\N	5982
9845	GENERIC_DAY	0	0	2009-12-23	1518	\N	5982
9846	GENERIC_DAY	0	0	2009-12-03	1518	\N	5982
9847	GENERIC_DAY	0	8	2010-01-12	1516	\N	5982
9848	GENERIC_DAY	0	8	2009-12-10	1516	\N	5982
9849	GENERIC_DAY	0	0	2009-12-11	1518	\N	5982
9850	GENERIC_DAY	0	8	2009-12-12	1516	\N	5982
9851	GENERIC_DAY	0	8	2009-12-04	1516	\N	5982
9852	GENERIC_DAY	0	0	2009-12-12	1518	\N	5982
9853	GENERIC_DAY	0	8	2010-01-06	1516	\N	5982
9854	GENERIC_DAY	0	8	2010-01-10	1516	\N	5982
9855	GENERIC_DAY	0	8	2009-12-20	1516	\N	5982
9856	GENERIC_DAY	0	0	2010-01-11	1518	\N	5982
9857	GENERIC_DAY	0	8	2010-01-02	1516	\N	5982
9858	GENERIC_DAY	0	8	2010-01-01	1516	\N	5982
9859	GENERIC_DAY	0	0	2010-01-09	1518	\N	5982
9860	GENERIC_DAY	0	8	2009-12-11	1516	\N	5982
9861	GENERIC_DAY	0	8	2009-12-18	1516	\N	5982
9862	GENERIC_DAY	0	0	2009-12-20	1518	\N	5982
9863	GENERIC_DAY	0	0	2010-01-03	1518	\N	5982
9864	GENERIC_DAY	0	8	2009-12-06	1516	\N	5982
9865	GENERIC_DAY	0	8	2009-11-26	1516	\N	5982
9866	GENERIC_DAY	0	0	2009-11-25	1518	\N	5982
9867	GENERIC_DAY	0	0	2009-11-29	1518	\N	5982
9868	GENERIC_DAY	0	8	2009-12-24	1516	\N	5982
9869	GENERIC_DAY	0	8	2009-12-14	1516	\N	5982
9870	GENERIC_DAY	0	8	2009-12-13	1516	\N	5982
9871	GENERIC_DAY	0	0	2009-12-10	1518	\N	5982
9872	GENERIC_DAY	0	0	2009-11-27	1518	\N	5982
9873	GENERIC_DAY	0	0	2009-12-06	1518	\N	5982
9874	GENERIC_DAY	0	8	2009-11-27	1516	\N	5982
9875	GENERIC_DAY	0	8	2009-12-27	1516	\N	5982
9876	GENERIC_DAY	0	8	2009-12-07	1516	\N	5982
9877	GENERIC_DAY	0	8	2009-12-30	1516	\N	5982
9878	GENERIC_DAY	0	8	2009-11-28	1516	\N	5982
9879	GENERIC_DAY	0	0	2009-12-02	1518	\N	5982
9880	GENERIC_DAY	0	8	2009-12-21	1516	\N	5982
9881	GENERIC_DAY	0	8	2010-01-05	1516	\N	5982
9882	GENERIC_DAY	0	0	2009-12-17	1518	\N	5982
9883	GENERIC_DAY	0	8	2009-12-17	1516	\N	5982
9884	GENERIC_DAY	0	0	2009-12-31	1518	\N	5982
9885	GENERIC_DAY	0	8	2010-01-04	1516	\N	5982
9886	GENERIC_DAY	0	0	2009-12-18	1518	\N	5982
9887	GENERIC_DAY	0	0	2009-12-21	1518	\N	5982
9888	GENERIC_DAY	0	8	2009-12-03	1516	\N	5982
9889	GENERIC_DAY	0	0	2009-12-25	1518	\N	5982
9890	GENERIC_DAY	0	8	2009-12-19	1516	\N	5982
9891	GENERIC_DAY	0	8	2009-12-02	1516	\N	5982
9892	GENERIC_DAY	0	0	2009-11-28	1518	\N	5982
9893	GENERIC_DAY	0	0	2009-12-16	1518	\N	5982
9894	GENERIC_DAY	0	8	2010-01-03	1516	\N	5982
9895	GENERIC_DAY	0	8	2009-11-25	1516	\N	5982
9896	GENERIC_DAY	0	0	2010-01-08	1518	\N	5982
9897	GENERIC_DAY	0	0	2009-12-27	1518	\N	5982
9898	GENERIC_DAY	0	0	2010-01-12	1518	\N	5982
9899	GENERIC_DAY	0	8	2010-01-13	1516	\N	5982
9900	GENERIC_DAY	0	0	2009-12-14	1518	\N	5982
9901	GENERIC_DAY	0	8	2009-12-08	1516	\N	5982
9902	GENERIC_DAY	0	0	2010-01-04	1518	\N	5982
9903	GENERIC_DAY	0	8	2009-12-01	1516	\N	5982
9904	GENERIC_DAY	0	8	2009-12-23	1516	\N	5982
9905	GENERIC_DAY	0	8	2009-11-30	1516	\N	5982
9906	GENERIC_DAY	0	0	2009-12-09	1518	\N	5982
9907	GENERIC_DAY	0	0	2009-12-22	1518	\N	5982
9908	GENERIC_DAY	0	0	2009-12-13	1518	\N	5982
9909	GENERIC_DAY	0	0	2009-12-30	1518	\N	5982
9910	GENERIC_DAY	0	8	2009-12-31	1516	\N	5982
9911	GENERIC_DAY	0	8	2009-11-29	1516	\N	5982
9912	GENERIC_DAY	0	0	2009-12-07	1518	\N	5982
9913	GENERIC_DAY	0	0	2009-12-24	1518	\N	5982
9914	GENERIC_DAY	0	0	2010-01-06	1518	\N	5982
9915	GENERIC_DAY	0	8	2010-01-07	1516	\N	5982
9916	GENERIC_DAY	0	8	2009-12-16	1516	\N	5982
9917	GENERIC_DAY	0	8	2009-12-22	1516	\N	5982
9918	GENERIC_DAY	0	0	2010-01-05	1518	\N	5982
9919	GENERIC_DAY	0	0	2009-12-02	1519	\N	5983
9920	GENERIC_DAY	0	8	2009-12-08	1515	\N	5983
9921	GENERIC_DAY	0	8	2009-12-15	1515	\N	5983
9922	GENERIC_DAY	0	0	2009-12-19	1519	\N	5983
9923	GENERIC_DAY	0	8	2009-12-06	1515	\N	5983
9924	GENERIC_DAY	0	8	2009-12-13	1515	\N	5983
9925	GENERIC_DAY	0	0	2009-12-18	1519	\N	5983
9926	GENERIC_DAY	0	8	2009-11-26	1515	\N	5983
9927	GENERIC_DAY	0	0	2009-12-07	1519	\N	5983
9928	GENERIC_DAY	0	8	2009-12-19	1515	\N	5983
9929	GENERIC_DAY	0	8	2009-11-30	1515	\N	5983
9930	GENERIC_DAY	0	0	2009-12-11	1519	\N	5983
9931	GENERIC_DAY	0	8	2009-12-18	1515	\N	5983
9932	GENERIC_DAY	0	8	2009-11-28	1515	\N	5983
9933	GENERIC_DAY	0	8	2009-12-16	1515	\N	5983
9934	GENERIC_DAY	0	8	2009-12-07	1515	\N	5983
9935	GENERIC_DAY	0	8	2009-12-17	1515	\N	5983
9936	GENERIC_DAY	0	0	2009-11-25	1519	\N	5983
9937	GENERIC_DAY	0	0	2009-12-08	1519	\N	5983
9938	GENERIC_DAY	0	0	2009-11-29	1519	\N	5983
9939	GENERIC_DAY	0	0	2009-12-12	1519	\N	5983
9940	GENERIC_DAY	0	8	2009-12-05	1515	\N	5983
9941	GENERIC_DAY	0	0	2009-12-09	1519	\N	5983
9942	GENERIC_DAY	0	0	2009-12-05	1519	\N	5983
9943	GENERIC_DAY	0	8	2009-11-29	1515	\N	5983
9944	GENERIC_DAY	0	8	2009-11-25	1515	\N	5983
9945	GENERIC_DAY	0	8	2009-12-03	1515	\N	5983
9946	GENERIC_DAY	0	0	2009-12-10	1519	\N	5983
9947	GENERIC_DAY	0	8	2009-12-10	1515	\N	5983
9948	GENERIC_DAY	0	0	2009-11-30	1519	\N	5983
9949	GENERIC_DAY	0	0	2009-12-14	1519	\N	5983
9950	GENERIC_DAY	0	8	2009-12-14	1515	\N	5983
9951	GENERIC_DAY	0	8	2009-11-27	1515	\N	5983
9952	GENERIC_DAY	0	8	2009-12-02	1515	\N	5983
9953	GENERIC_DAY	0	0	2009-11-28	1519	\N	5983
9954	GENERIC_DAY	0	0	2009-12-06	1519	\N	5983
9955	GENERIC_DAY	0	0	2009-12-04	1519	\N	5983
9956	GENERIC_DAY	0	0	2009-12-01	1519	\N	5983
9957	GENERIC_DAY	0	0	2009-11-26	1519	\N	5983
9958	GENERIC_DAY	0	0	2009-11-27	1519	\N	5983
9959	GENERIC_DAY	0	8	2009-12-04	1515	\N	5983
9960	GENERIC_DAY	0	0	2009-12-03	1519	\N	5983
9961	GENERIC_DAY	0	8	2009-12-11	1515	\N	5983
9962	GENERIC_DAY	0	0	2009-12-15	1519	\N	5983
9963	GENERIC_DAY	0	8	2009-12-09	1515	\N	5983
9964	GENERIC_DAY	0	8	2009-12-01	1515	\N	5983
9965	GENERIC_DAY	0	0	2009-12-17	1519	\N	5983
9966	GENERIC_DAY	0	8	2009-12-12	1515	\N	5983
9967	GENERIC_DAY	0	0	2009-12-13	1519	\N	5983
9968	GENERIC_DAY	0	0	2009-12-16	1519	\N	5983
9969	GENERIC_DAY	3	2	2009-12-23	1518	\N	5984
9970	GENERIC_DAY	3	3	2009-12-30	1517	\N	5984
9971	GENERIC_DAY	3	3	2009-11-26	1519	\N	5984
9972	GENERIC_DAY	3	3	2009-12-24	1519	\N	5984
9973	GENERIC_DAY	3	3	2009-12-14	1519	\N	5984
9974	GENERIC_DAY	3	3	2009-12-12	1519	\N	5984
9975	GENERIC_DAY	3	3	2009-12-15	1517	\N	5984
9976	GENERIC_DAY	3	3	2009-12-25	1517	\N	5984
9977	GENERIC_DAY	3	2	2009-12-27	1518	\N	5984
9978	GENERIC_DAY	3	3	2010-01-09	1519	\N	5984
9979	GENERIC_DAY	3	3	2010-01-11	1519	\N	5984
9980	GENERIC_DAY	3	2	2010-01-08	1518	\N	5984
9981	GENERIC_DAY	3	2	2009-12-31	1518	\N	5984
9982	GENERIC_DAY	3	3	2009-12-17	1519	\N	5984
9983	GENERIC_DAY	3	3	2009-12-21	1519	\N	5984
9984	GENERIC_DAY	3	3	2009-12-23	1519	\N	5984
9985	GENERIC_DAY	3	3	2010-01-07	1519	\N	5984
9986	GENERIC_DAY	3	2	2009-12-21	1518	\N	5984
9987	GENERIC_DAY	3	3	2009-12-21	1517	\N	5984
9988	GENERIC_DAY	3	2	2010-01-13	1518	\N	5984
9989	GENERIC_DAY	3	3	2010-01-10	1519	\N	5984
9990	GENERIC_DAY	3	2	2009-12-14	1518	\N	5984
9991	GENERIC_DAY	3	3	2010-01-09	1517	\N	5984
9992	GENERIC_DAY	3	2	2009-12-15	1518	\N	5984
9993	GENERIC_DAY	3	3	2009-12-29	1519	\N	5984
9994	GENERIC_DAY	3	3	2009-12-15	1519	\N	5984
9995	GENERIC_DAY	3	2	2009-12-25	1518	\N	5984
9996	GENERIC_DAY	3	3	2010-01-01	1517	\N	5984
9997	GENERIC_DAY	3	3	2009-12-18	1519	\N	5984
9998	GENERIC_DAY	3	2	2009-11-26	1518	\N	5984
9999	GENERIC_DAY	3	3	2009-12-27	1519	\N	5984
10000	GENERIC_DAY	3	3	2009-11-26	1517	\N	5984
10001	GENERIC_DAY	3	3	2010-01-12	1517	\N	5984
10002	GENERIC_DAY	3	2	2009-12-28	1518	\N	5984
10003	GENERIC_DAY	3	2	2009-12-19	1518	\N	5984
10004	GENERIC_DAY	3	3	2010-01-10	1517	\N	5984
10005	GENERIC_DAY	3	3	2009-12-16	1517	\N	5984
10006	GENERIC_DAY	3	3	2009-12-01	1517	\N	5984
10007	GENERIC_DAY	3	3	2009-12-23	1517	\N	5984
10008	GENERIC_DAY	3	2	2009-12-10	1518	\N	5984
10009	GENERIC_DAY	3	2	2009-11-29	1518	\N	5984
10010	GENERIC_DAY	3	3	2009-12-14	1517	\N	5984
10011	GENERIC_DAY	3	3	2009-12-07	1517	\N	5984
10012	GENERIC_DAY	3	2	2010-01-06	1518	\N	5984
10013	GENERIC_DAY	3	3	2010-01-08	1517	\N	5984
10014	GENERIC_DAY	3	2	2009-12-08	1518	\N	5984
10015	GENERIC_DAY	3	2	2009-12-09	1518	\N	5984
10016	GENERIC_DAY	3	3	2009-12-03	1517	\N	5984
10017	GENERIC_DAY	3	3	2009-11-30	1519	\N	5984
10018	GENERIC_DAY	3	3	2009-12-20	1519	\N	5984
10019	GENERIC_DAY	3	3	2009-11-25	1519	\N	5984
10020	GENERIC_DAY	3	2	2009-12-04	1518	\N	5984
10021	GENERIC_DAY	3	3	2010-01-05	1517	\N	5984
10022	GENERIC_DAY	3	3	2009-12-31	1517	\N	5984
10023	GENERIC_DAY	3	3	2009-12-04	1519	\N	5984
10024	GENERIC_DAY	3	2	2009-12-03	1518	\N	5984
10025	GENERIC_DAY	3	3	2010-01-03	1517	\N	5984
10026	GENERIC_DAY	3	3	2009-12-13	1517	\N	5984
10027	GENERIC_DAY	3	2	2009-12-26	1518	\N	5984
10028	GENERIC_DAY	3	2	2009-11-30	1518	\N	5984
10029	GENERIC_DAY	3	3	2009-12-29	1517	\N	5984
10030	GENERIC_DAY	3	2	2009-12-20	1518	\N	5984
10031	GENERIC_DAY	3	2	2010-01-05	1518	\N	5984
10032	GENERIC_DAY	3	3	2009-12-27	1517	\N	5984
10033	GENERIC_DAY	3	3	2010-01-11	1517	\N	5984
10034	GENERIC_DAY	3	2	2010-01-07	1518	\N	5984
10035	GENERIC_DAY	3	3	2009-12-18	1517	\N	5984
10036	GENERIC_DAY	3	3	2010-01-04	1519	\N	5984
10037	GENERIC_DAY	3	3	2009-12-09	1517	\N	5984
10038	GENERIC_DAY	3	3	2009-11-29	1519	\N	5984
10039	GENERIC_DAY	3	3	2010-01-08	1519	\N	5984
10040	GENERIC_DAY	3	2	2009-12-06	1518	\N	5984
10041	GENERIC_DAY	3	3	2009-11-29	1517	\N	5984
10042	GENERIC_DAY	3	2	2009-12-22	1518	\N	5984
10043	GENERIC_DAY	3	3	2009-12-20	1517	\N	5984
10044	GENERIC_DAY	3	2	2009-12-18	1518	\N	5984
10045	GENERIC_DAY	3	2	2009-12-07	1518	\N	5984
10046	GENERIC_DAY	3	2	2009-12-16	1518	\N	5984
10047	GENERIC_DAY	3	3	2009-12-13	1519	\N	5984
10048	GENERIC_DAY	3	2	2010-01-01	1518	\N	5984
10049	GENERIC_DAY	3	3	2009-12-06	1517	\N	5984
10050	GENERIC_DAY	3	2	2010-01-11	1518	\N	5984
10051	GENERIC_DAY	3	3	2009-12-09	1519	\N	5984
10052	GENERIC_DAY	3	2	2009-12-24	1518	\N	5984
10053	GENERIC_DAY	3	2	2010-01-12	1518	\N	5984
10054	GENERIC_DAY	3	3	2010-01-07	1517	\N	5984
10055	GENERIC_DAY	3	3	2010-01-06	1517	\N	5984
10056	GENERIC_DAY	3	3	2009-12-10	1519	\N	5984
10057	GENERIC_DAY	3	2	2009-11-25	1518	\N	5984
10058	GENERIC_DAY	3	3	2009-11-30	1517	\N	5984
10059	GENERIC_DAY	3	2	2010-01-03	1518	\N	5984
10060	GENERIC_DAY	3	3	2010-01-02	1517	\N	5984
10061	GENERIC_DAY	3	3	2009-12-16	1519	\N	5984
10062	GENERIC_DAY	3	3	2009-12-30	1519	\N	5984
10063	GENERIC_DAY	3	2	2009-12-17	1518	\N	5984
10064	GENERIC_DAY	3	2	2009-12-05	1518	\N	5984
10065	GENERIC_DAY	3	3	2009-11-28	1517	\N	5984
10066	GENERIC_DAY	3	3	2009-12-22	1519	\N	5984
10067	GENERIC_DAY	3	2	2010-01-10	1518	\N	5984
10068	GENERIC_DAY	3	3	2009-12-03	1519	\N	5984
10069	GENERIC_DAY	3	3	2009-12-25	1519	\N	5984
10070	GENERIC_DAY	3	3	2009-12-22	1517	\N	5984
10071	GENERIC_DAY	3	3	2009-12-11	1519	\N	5984
10072	GENERIC_DAY	3	2	2009-12-12	1518	\N	5984
10073	GENERIC_DAY	3	3	2009-12-11	1517	\N	5984
10074	GENERIC_DAY	3	3	2010-01-05	1519	\N	5984
10075	GENERIC_DAY	3	3	2010-01-04	1517	\N	5984
10076	GENERIC_DAY	3	3	2009-12-05	1519	\N	5984
10077	GENERIC_DAY	3	3	2009-12-17	1517	\N	5984
10078	GENERIC_DAY	3	3	2010-01-03	1519	\N	5984
10079	GENERIC_DAY	3	2	2009-12-01	1518	\N	5984
10080	GENERIC_DAY	3	3	2010-01-02	1519	\N	5984
10081	GENERIC_DAY	3	3	2009-12-06	1519	\N	5984
10082	GENERIC_DAY	3	2	2009-12-11	1518	\N	5984
10083	GENERIC_DAY	3	3	2009-12-08	1519	\N	5984
10084	GENERIC_DAY	3	3	2009-12-01	1519	\N	5984
10085	GENERIC_DAY	3	3	2009-12-26	1519	\N	5984
10086	GENERIC_DAY	3	3	2009-12-31	1519	\N	5984
10087	GENERIC_DAY	3	3	2009-12-04	1517	\N	5984
10088	GENERIC_DAY	3	2	2010-01-09	1518	\N	5984
10089	GENERIC_DAY	3	2	2010-01-02	1518	\N	5984
10090	GENERIC_DAY	3	2	2009-11-28	1518	\N	5984
10091	GENERIC_DAY	3	2	2009-12-13	1518	\N	5984
10092	GENERIC_DAY	3	3	2010-01-01	1519	\N	5984
10093	GENERIC_DAY	3	2	2009-12-02	1518	\N	5984
10094	GENERIC_DAY	3	3	2009-12-24	1517	\N	5984
10095	GENERIC_DAY	3	3	2009-12-28	1517	\N	5984
10096	GENERIC_DAY	3	3	2010-01-12	1519	\N	5984
10097	GENERIC_DAY	3	3	2010-01-13	1517	\N	5984
10098	GENERIC_DAY	3	3	2009-11-28	1519	\N	5984
10099	GENERIC_DAY	3	3	2009-12-19	1519	\N	5984
10100	GENERIC_DAY	3	3	2010-01-13	1519	\N	5984
10101	GENERIC_DAY	3	3	2009-12-07	1519	\N	5984
10102	GENERIC_DAY	3	3	2009-12-02	1519	\N	5984
10103	GENERIC_DAY	3	2	2009-12-29	1518	\N	5984
10104	GENERIC_DAY	3	3	2009-12-19	1517	\N	5984
10105	GENERIC_DAY	3	3	2009-12-10	1517	\N	5984
10106	GENERIC_DAY	3	3	2009-12-12	1517	\N	5984
10107	GENERIC_DAY	3	2	2009-12-30	1518	\N	5984
10108	GENERIC_DAY	3	3	2009-12-05	1517	\N	5984
10109	GENERIC_DAY	3	3	2009-11-27	1519	\N	5984
10110	GENERIC_DAY	3	3	2009-11-25	1517	\N	5984
10111	GENERIC_DAY	3	3	2009-12-26	1517	\N	5984
10112	GENERIC_DAY	3	3	2009-12-02	1517	\N	5984
10113	GENERIC_DAY	3	2	2009-11-27	1518	\N	5984
10114	GENERIC_DAY	3	2	2010-01-04	1518	\N	5984
10115	GENERIC_DAY	3	3	2010-01-06	1519	\N	5984
10116	GENERIC_DAY	3	3	2009-12-28	1519	\N	5984
10117	GENERIC_DAY	3	3	2009-12-08	1517	\N	5984
10118	GENERIC_DAY	3	3	2009-11-27	1517	\N	5984
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
2326528	3	4040	4041	0
2326532	3	2325	2326	0
2326533	3	2328	2329	0
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
13861	3469	100.00
5783	3469	100.00
\.


--
-- Data for Name: exceptionday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY exceptionday (id, version, date, hours, base_calendar_id) FROM stdin;
914	1	2010-05-17	0	707
913	3	2009-12-25	0	708
909	3	2009-12-08	0	708
911	3	2010-01-01	0	708
910	3	2010-01-06	0	708
912	3	2009-12-07	0	708
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
5964
5965
5966
5979
5980
5981
5982
5983
5984
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
141
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, name, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line) FROM stdin;
2245	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	0.60	f	2059
2246	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	2060
2247	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	2061
2248	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	2062
2249	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	2063
3648	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	3470
3649	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	340	1.00	f	3471
3650	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	3472
3651	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	3473
4790	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	4952
4791	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	4953
4792	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	4954
5262	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	5161
2243	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	2057
2244	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	2058
2261	5	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	0.40	f	2059
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
303	8	0
303	8	1
303	8	2
303	8	3
303	8	4
303	0	5
303	0	6
809	8	0
809	8	1
809	8	2
809	8	3
809	8	4
809	4	5
810	8	0
810	8	1
810	8	2
810	8	3
810	7	4
810	0	5
810	0	6
811	8	0
811	8	1
811	8	2
811	8	3
811	8	4
811	4	5
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
2136	2056
4302	4951
13862	3453
3558	3469
5784	3453
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
1111	1	Puente	1010
1112	1	Bodegas	1010
1113	1	Cubierta	1010
1114	1	Navantia	1011
1115	1	Vulcano	1011
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
1010	1	Zona
1011	1	Clientes
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
1522	003	Pulidora A	Desc Pulidora
1521	002	Torno B	Desc B.
1520	001	Torno A	Desc.
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
1919	1	2009-11-25 11:59:33.879	\N	1819	1519
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
1818	2	Unidade de configuración 1	0.50	1521
1819	1	New configuration unit	0.25	1520
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
1415	2	11111111	Descrición material	10.00	4	f	1313
1414	2	22222222	Descrición 2 material	20.00	\N	f	1313
1416	1	0001-tubos	Tubo	100.00	\N	f	1314
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
1313	2	Tornillos	\N
1314	2	Tubos	\N
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, base_calendar_id) FROM stdin;
2031	Responsable	Cliente	t	202
4152	\N	\N	\N	202
3453	Xavi	cliente	\N	202
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, initdate, deadline, mandatoryinit, mandatoryend, description, code, schedulingstatetype, parent, positionincontainer) FROM stdin;
2031	9	Pintado de casco estribor	2009-11-25 12:03:02.143	2009-12-31 00:00:00	f	f	Desc.	ped1	4	\N	\N
2056	8	Coordinación de proxecto	\N	\N	f	f	\N	ped1.1	0	2031	0
2057	8	Organización de equipo	\N	\N	f	f	\N	ped1.1.1	1	2056	0
2058	8	Seguimiento	\N	\N	f	f	\N	ped1.1.2	1	2056	1
2059	8	Montar andamios	\N	\N	f	f	\N	ped1.2	0	2031	1
2060	8	Realizar limpado de superficie	2009-12-04 00:00:00	\N	f	f	\N	ped1.3	0	2031	2
2061	8	Pintado de casco	\N	\N	f	f	\N	ped1.4	0	2031	3
2062	8	Revisión pintado	\N	\N	f	f	\N	ped1.5	0	2031	4
2063	8	Desmontado de andamios	\N	\N	f	f	\N	ped1.6	0	2031	5
3453	9	Pedido2	2009-11-25 14:08:36.444	2009-12-25 00:00:00	f	f	Desc.	ped2	4	\N	\N
3469	8	Coordinación	\N	\N	f	f	\N	ped2.1	0	3453	0
3470	8	Organización	\N	\N	f	f	\N	ped2.1.1	1	3469	0
3471	8	Seguimento	\N	\N	f	f	\N	ped2.1.2	1	3469	1
3472	8	Análise	\N	\N	f	f	\N	ped2.2	0	3453	1
3473	8	Implementación	\N	\N	f	f	\N	ped2.3	0	3453	2
4152	7	Pedido3	2009-11-25 20:43:00.229	2010-02-01 00:00:00	f	f	\N	ped3	4	\N	\N
4951	6	Elemento1	\N	\N	f	f	\N	ped3.1	0	4152	0
4952	6	Subelemento1.1	\N	\N	f	f	\N	ped3.2	1	4951	0
4953	6	Subelemento1.2	\N	\N	f	f	\N	ped3.3	1	4951	1
4954	6	Elemento2	\N	\N	f	f	\N	ped3.4	0	4152	1
5161	4	Elemento3	\N	2009-12-03 00:00:00	f	f	\N	ped3.5	0	4152	2
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid) FROM stdin;
2057
2058
2059
2060
2061
2062
2063
3470
3471
3472
3473
4952
4953
4954
5161
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
2031
2056
3453
3469
4152
4951
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, calendar) FROM stdin;
1516	2	710
1518	2	712
1517	2	711
1515	2	709
1519	2	713
1522	2	716
1521	3	715
1520	3	714
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
5966	1	1.00	4040	\N
5964	1	1.00	4042	\N
5965	1	1.00	4041	\N
5979	0	1.00	2325	\N
5980	0	1.00	2326	\N
5981	0	1.00	2329	\N
5982	0	1.00	2328	\N
5983	0	1.00	2330	\N
5984	3	1.00	2323	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id) FROM stdin;
709
710
711
712
713
714
715
716
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate) FROM stdin;
5050	1	0	\N
5051	1	0	\N
5353	1	0	\N
2325	1	1	2009-12-26 01:35:33.746
2326	1	0	\N
2329	1	1	2010-01-16 23:35:07.562
2328	1	0	\N
2330	1	0	\N
2323	1	0	\N
4040	1	0	\N
4041	1	0	\N
4042	1	0	\N
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
2327	2246
2327	2248
2327	2247
2327	2249
2327	2245
2327	2243
2327	2244
2323	2243
2324	2244
2324	2243
2325	2261
2325	2245
2326	2246
2328	2247
2329	2248
2330	2249
4043	3651
4043	3649
4043	3650
4043	3648
5052	4792
5052	4791
5052	4790
5050	4790
5050	4791
5051	4792
5353	5262
4040	3649
4040	3648
4041	3650
4042	3651
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
5050	5	\N	\N	\N	\N	\N	5052	\N	0
5051	5	\N	\N	\N	\N	\N	5052	\N	1
5353	3	\N	\N	\N	\N	2009-12-03	5052	\N	2
5052	5	\N	\N	\N	\N	2010-02-01	\N	\N	\N
2325	8	Montar andamios	\N	2009-12-26 01:35:33.746	2010-02-27 01:35:33.746	\N	2327	\N	1
2326	8	Realizar limpado de superficie	\N	2010-02-27 01:35:33.746	2010-04-18 01:35:33.746	\N	2327	\N	2
2329	4	Revisión pintado	\N	2010-01-16 23:35:07.562	2010-03-20 23:35:07.562	\N	2327	\N	4
2328	4	Pintado de casco	\N	2009-11-25 12:03:02.143	2010-01-14 12:03:02.143	\N	2327	\N	3
2330	4	Desmontado de andamios	\N	2009-11-25 12:03:02.143	2009-12-20 12:03:02.143	\N	2327	\N	5
2324	8	Coordinación de proxecto	\N	2009-11-25 12:03:02.143	2010-01-14 12:03:02.143	\N	2327	\N	0
2323	6	Organización de equipo	\N	2009-11-25 12:03:02.143	2010-01-14 12:03:02.143	\N	2324	\N	0
2327	8	\N	\N	2009-11-25 12:03:02.143	2010-04-18 01:35:33.746	2009-12-31	\N	\N	\N
4040	7	Coordinación	\N	2009-11-25 14:08:36.444	2010-02-13 14:08:36.444	\N	4043	\N	0
4041	7	Análise	\N	2010-02-13 14:08:36.444	2010-04-04 14:08:36.444	\N	4043	\N	1
4042	7	Implementación	\N	2009-11-25 14:08:36.444	2010-01-27 14:08:36.444	\N	4043	\N	2
4043	7	\N	\N	2009-11-25 14:08:36.444	2010-04-04 14:08:36.444	2009-12-25	\N	\N	\N
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
2324
2327
4043
5052
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
5050	5	4951
5051	5	4954
5353	3	5161
5052	5	4152
2323	5	2057
4040	5	3469
4041	5	3472
4042	5	3473
4043	5	3453
2324	7	2056
2325	7	2059
2326	7	2060
2328	3	2061
2329	3	2062
2330	3	2063
2327	7	2031
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, place, responsible, work_report_type_id) FROM stdin;
5555	1	2009-11-25 00:00:00	lugar	responsable	5454
5556	1	2009-11-25 00:00:00	asdf	asdf	5454
5557	1	2009-11-27 00:00:00	asdf	asdf	5454
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, work_report_id, resource_id, order_element_id) FROM stdin;
5656	1	40	5555	1515	2056
5657	1	100	5556	1515	3469
5658	1	100	5557	1515	3469
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name) FROM stdin;
5454	1	Estandar
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1516	Silvio	Rodriguez Vázquez	22222222B
1518	Samuel	López López	44444444D
1517	Miguel	Domínguez López	33333333C
1515	Marina	Gutiérrez Fernández	11111111A
1519	Antonio	Romero Santos	55555555E
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterion_type_work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion_type_work_report_type
    ADD CONSTRAINT criterion_type_work_report_type_pkey PRIMARY KEY (work_report_type_id, criterion_type_id);


--
-- Name: criterion_work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion_work_report_line
    ADD CONSTRAINT criterion_work_report_line_pkey PRIMARY KEY (work_report_line_id, criterion_id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: exceptionday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY exceptionday
    ADD CONSTRAINT exceptionday_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: resource_calendar_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_calendar_key UNIQUE (calendar);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk4822b25e131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion_type_work_report_type
    ADD CONSTRAINT fk4822b25e131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk4822b25eff876347; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion_type_work_report_type
    ADD CONSTRAINT fk4822b25eff876347 FOREIGN KEY (criterion_type_id) REFERENCES criteriontype(id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk9654b9ef5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion_work_report_line
    ADD CONSTRAINT fk9654b9ef5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk9654b9ef61f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion_work_report_line
    ADD CONSTRAINT fk9654b9ef61f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282ee893ce10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282ee893ce10 FOREIGN KEY (calendar) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf9ce78eda44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY exceptionday
    ADD CONSTRAINT fkf9ce78eda44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

