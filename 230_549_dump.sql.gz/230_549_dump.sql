--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    hours integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255)
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    criterion_id bigint,
    parent bigint,
    isvalid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint,
    derived_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint NOT NULL,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: external_company; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE external_company (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    nif character varying(255),
    client boolean,
    subcontractor boolean,
    interactswithapplications boolean,
    appuri character varying(255),
    ourcompanylogin character varying(255),
    ourcompanypassword character varying(255),
    companyuser bigint
);


ALTER TABLE public.external_company OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    resourcetype bytea,
    workinghours integer,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint NOT NULL,
    code character varying(255)
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    code character varying(255),
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type integer,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint,
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_assigment_template; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment_template (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment_template OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_authorization; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_authorization (
    id bigint NOT NULL,
    order_authorization_subclass character varying(255) NOT NULL,
    version bigint NOT NULL,
    authorizationtype character varying(255) NOT NULL,
    order_id bigint,
    user_id bigint,
    profile_id bigint
);


ALTER TABLE public.order_authorization OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    customer character varying(255),
    dependenciesconstraintshavepriority boolean,
    base_calendar_id bigint,
    codeautogenerated boolean,
    lastorderelementsequencecode integer
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    mandatoryinit boolean,
    mandatoryend boolean,
    description character varying(255),
    code character varying(255),
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderelementtemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelementtemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    startasdaysfrombeginning integer,
    deadlineasdaysfrombeginning integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelementtemplate OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: orderlinegrouptemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegrouptemplate (
    group_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinegrouptemplate OWNER TO naval;

--
-- Name: orderlinetemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinetemplate (
    order_line_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinetemplate OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: ordertemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordertemplate (
    order_template_id bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.ordertemplate OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    calendar bigint,
    base_calendar_id bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: subcontractedtaskdata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE subcontractedtaskdata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    externalcompany bigint,
    subcontratationdate timestamp without time zone,
    subcontractcommunicationdate timestamp without time zone,
    workdescription character varying(255),
    subcontractprice numeric(19,2),
    subcontractedcode character varying(255),
    nodewithoutchildrenexported boolean,
    labelsexported boolean,
    materialassignmentsexported boolean,
    hoursgroupsexported boolean,
    criterionrequirementsexported boolean
);


ALTER TABLE public.subcontractedtaskdata OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone,
    subcontrated_task_data_id bigint
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date timestamp without time zone,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    index integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint,
    positionnumber integer
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart timestamp without time zone,
    clockfinish timestamp without time zone,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
3052	6	t	606
3053	6	t	606
3054	6	t	606
3042	7	t	606
2250	3	t	606
2251	3	t	606
2234	4	t	606
3056	18	f	509
3099	15	t	607
3115	14	t	607
3130	12	t	607
6178	3	t	607
6179	3	t	607
2739	22	t	606
3100	15	f	607
29406	5	t	606
29407	5	t	606
109312	13	t	606
109313	13	t	606
35867	11	t	606
109335	12	t	606
109336	12	t	606
109337	12	t	606
109338	12	t	606
108985	7	t	607
49251	19	t	606
16659	12	t	607
16660	12	t	607
16661	12	t	607
2932	19	f	606
16662	12	t	607
16663	12	t	607
6186	13	t	607
6187	13	t	607
6894	4	t	607
6895	4	t	607
6902	3	t	607
2945	7	t	606
6896	4	f	607
108986	7	f	607
49252	19	t	606
49253	19	t	606
109339	12	t	606
109340	12	t	606
109341	12	t	606
49254	19	t	606
27689	5	t	606
27690	5	t	606
49255	19	t	606
49256	19	t	606
49257	19	t	606
49258	19	t	606
39934	8	t	606
39935	8	t	606
39936	8	t	606
39924	9	t	606
49267	18	t	606
49268	18	t	606
49269	18	t	606
49270	18	t	606
49273	16	t	606
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
19436	7	2009-12-08	25.00	16659
16728	12	2009-12-02	10.00	16659
19437	7	2009-12-08	25.00	16660
16729	12	2009-12-01	10.00	16660
16730	12	2009-12-08	20.00	16662
16731	12	2009-12-08	10.00	16663
6290	13	2009-12-08	30.00	6186
109086	7	2010-01-05	75.00	108985
109087	7	2010-01-04	25.00	108985
6984	4	2009-12-08	50.00	6894
6985	4	2009-12-08	40.00	6895
6991	3	2009-12-08	45.00	6902
1519	18	2009-12-25	100.00	3056
1520	18	2009-12-10	15.00	3056
1521	18	2009-12-07	5.00	3056
1522	18	2009-12-04	1.00	3056
1544	15	2009-12-04	10.00	3099
1573	14	2009-12-07	30.00	3115
1574	14	2009-12-04	10.00	3115
3233	12	2009-12-07	30.00	3130
3234	12	2009-12-04	10.00	3130
3235	12	2009-12-03	2.00	3130
6284	3	2009-12-07	30.00	6178
6285	3	2009-12-08	30.00	6179
6286	3	2009-12-07	50.00	6179
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
606	3	children	100.0000	f	0.0100	t	t
607	2	percentage	100.0000	f	0.0100	t	t
608	1	units	2147483647.0000	f	1.0000	t	f
508	1	Pactado	1000000.0000	t	1000.0000	t	f
510	1	Toneladas	4000.0000	t	1.0000	t	f
509	2	Porcentage pactado	100.0000	t	1.0000	t	t
108676	1	subcontractor	100.0000	f	0.0100	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
3940	105
3950	106
3951	106
3952	107
3953	106
3955	110
3982	107
3983	106
3984	105
3985	105
6367	106
6368	110
6369	106
8588	107
8589	105
19897	105
19898	107
19899	105
19901	105
24143	111
28093	106
29808	106
36966	36057
38582	36057
38583	36057
38595	36057
38596	36057
38597	36057
38598	36057
38600	36057
38601	36057
41013	36057
41014	36057
41050	36057
41051	36057
41052	36057
41053	36057
41054	36057
41061	36057
41069	36057
41076	36057
41077	36057
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
4245	7
24953	2
37371	17
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
204	2	Ferrol
58787	3	\N
58788	2	\N
49395	2	\N
58786	3	\N
58785	2	\N
58784	2	\N
206	2	\N
205	2	\N
58782	3	\N
58789	6	\N
49399	3	Pontevedra Proxecto 2
58783	3	\N
58790	4	\N
106657	1	\N
208	5	\N
26159	1	Vigo
207	3	\N
114736	2	\N
7373	6	\N
209	7	\N
210	8	\N
202	3	España
203	4	Galicia
37674	2	\N
36259	2	\N
37673	2	\N
40299	3	\N
49391	1	\N
49392	1	\N
49393	1	\N
49389	3	\N
49394	1	\N
49390	3	\N
49396	2	\N
36260	4	Pontevedra
49397	2	Pontevedra Proxecto
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
7677	1	2009-11-04	\N	206	0
7678	1	2009-11-04	\N	205	0
58989	3	2009-12-14	\N	58787	0
58990	2	2009-12-14	\N	58788	0
49597	2	2009-12-14	\N	49395	0
58988	3	2009-12-14	\N	58786	0
58987	2	2009-12-14	\N	58785	0
58986	2	2009-12-14	\N	58784	0
58984	3	2009-12-14	\N	58782	0
58991	6	2009-12-14	2010-01-31	58789	0
7679	4	2009-11-04	\N	208	0
7680	2	2009-11-04	\N	207	0
61206	1	2010-02-01	\N	58789	1
58985	3	2009-12-14	\N	58783	0
58992	4	2009-12-14	\N	58790	0
7879	5	2009-11-04	\N	7373	0
7676	4	2009-11-07	\N	209	0
7878	6	2009-11-04	\N	210	0
106859	1	2009-12-29	\N	106657	0
114938	2	2010-01-11	2010-02-25	114736	0
37876	2	2009-12-14	\N	37674	0
36461	2	2009-12-14	\N	36259	0
37875	2	2009-12-14	\N	37673	0
40501	3	2009-12-18	\N	40299	0
49593	1	2009-12-23	\N	49391	0
49594	1	2009-12-23	\N	49392	0
49595	1	2009-12-23	\N	49393	0
49591	3	2009-12-23	\N	49389	0
49596	1	2009-12-23	\N	49394	0
49592	3	2009-12-23	\N	49390	0
49598	2	2009-12-23	\N	49396	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
37775	2	202	\N	37674	0
306	2	203	\N	204	0
58888	3	49399	\N	58787	0
58889	2	49399	\N	58788	0
36360	2	202	\N	36259	0
37774	2	202	\N	37673	0
40400	3	202	\N	40299	0
308	2	202	\N	206	0
307	2	202	\N	205	0
49496	2	202	\N	49395	0
58887	3	49399	\N	58786	0
49492	1	202	\N	49391	0
58886	2	49399	\N	58785	0
49493	1	202	\N	49392	0
58885	2	49399	\N	58784	0
310	5	202	\N	208	0
26361	1	203	\N	26159	0
309	3	202	\N	207	0
49494	1	202	\N	49393	0
49490	3	202	\N	49389	0
7474	6	202	\N	7373	0
311	7	202	\N	209	0
58883	3	49399	\N	58782	0
49495	1	36260	\N	49394	0
58890	6	49399	\N	58789	0
312	8	202	2009-12-11	210	0
31916	2	202	\N	210	1
49491	3	202	\N	49390	0
49500	3	\N	\N	49399	0
303	3	\N	\N	202	0
304	3	\N	\N	202	1
305	4	202	\N	203	0
58884	3	49399	\N	58783	0
58891	4	49399	\N	58790	0
106758	1	49399	\N	106657	0
49497	2	202	\N	49396	0
36361	4	203	2010-01-01	36260	0
36362	2	203	\N	36260	1
114837	2	202	\N	114736	0
49498	2	\N	\N	49397	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
808	2	2009-12-25	0	505	202
26260	1	2010-12-28	0	505	26159
26261	1	2010-12-27	0	505	26159
26262	1	2010-04-05	0	505	26159
26263	1	2010-12-31	0	505	26159
26264	1	2011-01-02	0	505	26159
26265	1	2010-12-30	0	505	26159
26266	1	2011-01-01	0	505	26159
26267	1	2010-12-29	0	505	26159
809	2	2010-01-01	0	505	202
36663	1	2010-04-01	0	505	202
36664	1	2010-11-01	0	505	202
36665	1	2010-12-06	0	505	202
36666	1	2010-04-02	0	505	202
36667	1	2010-10-12	0	505	202
36668	1	2010-12-08	0	505	202
36669	1	2010-01-06	0	505	202
810	2	2010-05-17	0	505	203
36670	1	2010-03-19	0	505	203
26268	1	2010-07-12	0	505	207
26269	1	2010-07-08	0	505	207
26270	1	2010-07-21	0	505	207
26271	1	2010-07-16	0	505	207
26272	1	2010-07-04	0	505	207
26273	1	2010-07-15	0	505	207
26274	1	2010-07-13	0	505	207
26275	1	2010-07-01	0	505	207
26276	1	2010-07-14	0	505	207
26277	1	2010-07-23	0	505	207
26278	1	2010-07-19	0	505	207
26279	1	2010-07-02	0	505	207
26280	1	2010-07-07	0	505	207
26281	1	2010-07-06	0	505	207
26282	1	2010-07-10	0	505	207
26283	1	2010-07-03	0	505	207
26284	1	2010-07-17	0	505	207
26285	1	2010-07-09	0	505	207
26286	1	2010-07-18	0	505	207
26287	1	2010-07-11	0	505	207
26288	1	2010-07-22	0	505	207
26289	1	2010-07-20	0	505	207
26290	1	2010-07-05	0	505	207
36671	3	2010-04-05	0	505	36260
36672	3	2010-02-17	0	505	36260
59111	5	2009-12-31	0	505	58789
59112	5	2010-01-03	0	505	58789
59108	5	2009-12-28	0	505	58789
59113	4	2010-01-26	7	505	58789
59106	5	2009-12-30	0	505	58789
59107	5	2009-12-29	0	505	58789
59109	5	2010-01-02	0	505	58789
58278	2	2010-01-06	0	505	49397
58277	2	2010-01-01	0	505	49397
58283	1	2009-12-25	0	505	49397
58282	3	2009-12-25	0	505	49399
58280	3	2010-01-01	0	505	49399
62014	1	2010-01-06	0	505	49399
59091	3	2010-01-17	0	505	58790
59092	3	2010-01-10	0	505	58790
59101	3	2010-01-24	0	505	58790
59114	4	2010-01-31	7	505	58789
59110	5	2010-01-01	0	505	58789
59134	2	2010-01-13	0	505	58786
59130	2	2010-01-16	0	505	58786
59132	2	2010-01-14	0	505	58786
59133	2	2010-01-11	0	505	58786
59131	2	2010-01-15	0	505	58786
59129	2	2010-01-17	0	505	58786
59135	2	2010-01-12	0	505	58786
59123	4	2010-01-20	7	505	58789
59124	4	2010-01-23	7	505	58789
59126	4	2010-01-28	7	505	58789
59116	4	2010-01-25	7	505	58789
59121	4	2010-01-30	7	505	58789
59117	4	2010-01-24	7	505	58789
59122	4	2010-01-19	7	505	58789
59120	4	2010-01-08	7	510	58789
59127	4	2010-01-29	7	505	58789
59115	4	2010-01-27	7	505	58789
59128	4	2010-01-06	0	505	58789
59119	4	2010-01-18	7	505	58789
59118	4	2010-01-22	7	505	58789
59125	4	2010-01-21	7	505	58789
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, name, color, notassignable) FROM stdin;
505	6	HOLIDAY	red	t
506	5	SICK_LEAVE	red	t
507	4	LEAVE	red	t
508	3	STRIKE	red	t
509	2	BANK_HOLIDAY	red	t
510	1	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode) FROM stdin;
404	5	202	B15804842
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, name, enabled) FROM stdin;
1313	1	Oficial 1º	t
1315	3	Peón	t
1314	3	Oficial 2º	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
108	4	Calderero	t	4	\N
106	4	Soldador	t	4	\N
107	4	Andamiero	t	4	\N
36057	3	Ingeniero en Informática	t	4	\N
105	4	Pintor	t	4	\N
38481	2	Diseñador gráfico	t	4	\N
49894	1	Desarrollador	t	16154624	\N
49895	1	Analista	t	16154624	\N
49896	1	Coordinador	t	16154624	\N
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
109	2	Curso de riesgos laborales	t	3	\N
110	2	Torno	t	7	\N
111	2	Plegadora	t	7	\N
25755	2	Horno	t	7	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
28007	DIRECT	3	\N	27607	109	\N	\N
28008	DIRECT	3	27792	\N	106	\N	\N
28009	INDIRECT	3	27792	\N	109	28007	t
36916	DIRECT	7	\N	35766	36057	\N	\N
36917	INDIRECT	7	\N	35791	36057	36916	t
28030	DIRECT	2	\N	27608	106	\N	\N
28031	INDIRECT	2	27793	\N	106	28030	t
36918	INDIRECT	7	35980	\N	36057	36916	t
36919	INDIRECT	7	\N	35792	36057	36916	t
36920	INDIRECT	7	35981	\N	36057	36916	t
36921	INDIRECT	7	\N	35793	36057	36916	t
36922	INDIRECT	7	35982	\N	36057	36916	t
36923	INDIRECT	7	\N	35794	36057	36916	t
36924	INDIRECT	7	35983	\N	36057	36916	t
36925	INDIRECT	7	\N	35795	36057	36916	t
29783	DIRECT	4	\N	29323	109	\N	\N
29785	INDIRECT	4	29508	\N	109	29783	t
29784	DIRECT	4	29508	\N	106	\N	\N
29786	DIRECT	4	\N	29325	106	\N	\N
29787	INDIRECT	4	29510	\N	106	29786	t
2204	DIRECT	15	\N	1150	110	\N	\N
3420	INDIRECT	14	2863	\N	110	2204	t
2205	DIRECT	15	\N	1151	111	\N	\N
4910	DIRECT	4	1435	\N	105	\N	\N
4911	DIRECT	4	1436	\N	107	\N	\N
4912	DIRECT	4	1437	\N	106	\N	\N
4913	DIRECT	4	\N	1362	108	\N	\N
2389	DIRECT	5	2880	\N	106	\N	\N
2388	DIRECT	5	1891	\N	110	\N	\N
2390	DIRECT	5	\N	1182	108	\N	\N
3421	INDIRECT	14	2864	\N	111	2205	t
2206	DIRECT	15	\N	1152	105	\N	\N
2207	INDIRECT	15	2865	\N	105	2206	t
2208	DIRECT	15	\N	1153	105	\N	\N
2209	INDIRECT	15	2866	\N	105	2208	t
2210	DIRECT	15	\N	1154	107	\N	\N
2211	INDIRECT	15	2867	\N	107	2210	t
2391	DIRECT	5	\N	1182	106	\N	\N
2392	INDIRECT	5	2882	\N	108	2390	t
2393	INDIRECT	5	2882	\N	106	2391	t
2394	DIRECT	5	\N	1183	108	\N	\N
2395	INDIRECT	5	2883	\N	108	2394	t
4914	INDIRECT	4	1438	\N	108	4913	t
4915	DIRECT	4	\N	1363	106	\N	\N
4916	INDIRECT	4	1439	\N	106	4915	t
4918	DIRECT	4	\N	1364	106	\N	\N
4917	DIRECT	4	\N	1364	105	\N	\N
4919	INDIRECT	4	1440	\N	106	4918	t
4920	INDIRECT	4	1440	\N	105	4917	t
4921	DIRECT	4	\N	1365	107	\N	\N
4922	INDIRECT	4	1441	\N	107	4921	t
1646	DIRECT	11	\N	1126	105	\N	\N
1647	INDIRECT	11	2843	\N	105	1646	t
1679	DIRECT	10	1457	\N	107	\N	\N
1678	DIRECT	10	2844	\N	106	\N	\N
50440	INDIRECT	19	50501	\N	36057	49998	t
1816	DIRECT	9	\N	1128	105	\N	\N
1817	INDIRECT	9	2845	\N	105	1816	t
1919	DIRECT	9	2846	\N	108	\N	\N
1935	DIRECT	8	1855	\N	106	\N	\N
1966	DIRECT	7	1856	\N	106	\N	\N
1967	DIRECT	7	2847	\N	108	\N	\N
50441	INDIRECT	19	\N	50374	36057	49998	t
50442	INDIRECT	19	50502	\N	36057	49998	t
50443	INDIRECT	19	\N	50375	36057	49998	t
50444	INDIRECT	19	50503	\N	36057	49998	t
50445	INDIRECT	19	\N	50376	36057	49998	t
36926	INDIRECT	7	35984	\N	36057	36916	t
36927	INDIRECT	7	\N	35796	36057	36916	t
36928	INDIRECT	7	35985	\N	36057	36916	t
36931	INDIRECT	7	\N	35798	36057	36916	t
36932	INDIRECT	7	35987	\N	36057	36916	t
36929	INDIRECT	7	\N	35797	36057	36916	t
36930	INDIRECT	7	35986	\N	36057	36916	t
38184	INDIRECT	6	\N	38080	36057	36916	t
38185	INDIRECT	6	38282	\N	36057	36916	t
40793	DIRECT	5	\N	39823	36057	\N	\N
40794	INDIRECT	5	\N	39872	36057	40793	t
40795	INDIRECT	5	40035	\N	36057	40793	t
40796	INDIRECT	5	\N	39873	36057	40793	t
40797	INDIRECT	5	40036	\N	36057	40793	t
40798	INDIRECT	5	\N	39874	36057	40793	t
40799	INDIRECT	5	\N	39875	36057	40793	t
40800	INDIRECT	5	40037	\N	36057	40793	t
40801	INDIRECT	5	\N	39876	36057	40793	t
40802	INDIRECT	5	40038	\N	36057	40793	t
40803	INDIRECT	5	\N	39877	36057	40793	t
40804	INDIRECT	5	\N	39878	36057	40793	t
40805	INDIRECT	5	40039	\N	36057	40793	t
40806	INDIRECT	5	\N	39879	36057	40793	t
40807	INDIRECT	5	40040	\N	36057	40793	t
40808	INDIRECT	5	\N	39880	36057	40793	t
40809	INDIRECT	5	40041	\N	36057	40793	t
40810	INDIRECT	5	\N	39881	36057	40793	t
40811	INDIRECT	5	40042	\N	36057	40793	t
40812	INDIRECT	5	\N	39882	36057	40793	t
51615	DIRECT	15	\N	50360	49894	\N	\N
51616	INDIRECT	15	\N	50361	49894	51615	t
51617	INDIRECT	15	50189	\N	49894	51615	t
51618	INDIRECT	15	\N	50362	49894	51615	t
51619	INDIRECT	15	50190	\N	49894	51615	t
51620	INDIRECT	15	\N	50363	49894	51615	t
51621	INDIRECT	15	50191	\N	49894	51615	t
51622	INDIRECT	15	\N	50364	49894	51615	t
51623	INDIRECT	15	50192	\N	49894	51615	t
51624	DIRECT	15	\N	50365	49894	\N	\N
51625	INDIRECT	15	\N	50366	49894	51624	t
51626	INDIRECT	15	50193	\N	49894	51624	t
51627	INDIRECT	15	\N	50367	49894	51624	t
51628	INDIRECT	15	50194	\N	49894	51624	t
51629	INDIRECT	15	\N	50368	49894	51624	t
51630	INDIRECT	15	50195	\N	49894	51624	t
51631	DIRECT	15	\N	50369	49894	\N	\N
51632	INDIRECT	15	\N	50370	49894	51631	t
56955	DIRECT	14	\N	50646	49894	\N	\N
50769	INDIRECT	18	\N	50647	36057	49998	t
56956	INDIRECT	14	\N	50647	49894	56955	t
56957	INDIRECT	14	50557	\N	49894	56955	t
50770	INDIRECT	18	50557	\N	36057	49998	t
50771	INDIRECT	18	\N	50648	36057	49998	t
50772	INDIRECT	18	\N	50649	36057	49998	t
50773	INDIRECT	18	50558	\N	36057	49998	t
40813	INDIRECT	5	40043	\N	36057	40793	t
40814	INDIRECT	5	\N	39883	36057	40793	t
40815	INDIRECT	5	\N	39884	36057	40793	t
40816	INDIRECT	5	40044	\N	36057	40793	t
40817	INDIRECT	5	\N	39885	36057	40793	t
40818	INDIRECT	5	40045	\N	36057	40793	t
40819	INDIRECT	5	\N	39886	36057	40793	t
40820	INDIRECT	5	40046	\N	36057	40793	t
40821	INDIRECT	5	\N	39887	36057	40793	t
40822	INDIRECT	5	40047	\N	36057	40793	t
49998	DIRECT	20	\N	49125	36057	\N	\N
51633	INDIRECT	15	50196	\N	49894	51631	t
51634	DIRECT	15	\N	50371	49894	\N	\N
51635	INDIRECT	15	\N	50372	49894	51634	t
51636	INDIRECT	15	50500	\N	49894	51634	t
51637	INDIRECT	15	\N	50373	49894	51634	t
51638	INDIRECT	15	50501	\N	49894	51634	t
51639	INDIRECT	15	\N	50374	49894	51634	t
51640	INDIRECT	15	50502	\N	49894	51634	t
51641	INDIRECT	15	\N	50375	49894	51634	t
50461	INDIRECT	19	\N	50386	36057	49998	t
50462	INDIRECT	19	50510	\N	36057	49998	t
50463	INDIRECT	19	\N	50387	36057	49998	t
50464	INDIRECT	19	50511	\N	36057	49998	t
50465	INDIRECT	19	\N	50388	36057	49998	t
50466	INDIRECT	19	50512	\N	36057	49998	t
50467	INDIRECT	19	\N	50389	36057	49998	t
50468	INDIRECT	19	50513	\N	36057	49998	t
50469	INDIRECT	19	\N	50390	36057	49998	t
50470	INDIRECT	19	50514	\N	36057	49998	t
50471	INDIRECT	19	\N	50391	36057	49998	t
50472	INDIRECT	19	\N	50392	36057	49998	t
50782	INDIRECT	18	50562	\N	36057	49998	t
50783	INDIRECT	18	\N	50655	36057	49998	t
50784	INDIRECT	18	50563	\N	36057	49998	t
50785	INDIRECT	18	\N	50656	36057	49998	t
50786	INDIRECT	18	50564	\N	36057	49998	t
50787	INDIRECT	18	\N	50657	36057	49998	t
50788	INDIRECT	18	50565	\N	36057	49998	t
50789	INDIRECT	18	\N	50658	36057	49998	t
50790	INDIRECT	18	50566	\N	36057	49998	t
50791	INDIRECT	18	\N	50659	36057	49998	t
50792	INDIRECT	18	50567	\N	36057	49998	t
50793	INDIRECT	18	\N	50660	36057	49998	t
50794	INDIRECT	18	50568	\N	36057	49998	t
50795	INDIRECT	18	\N	50661	36057	49998	t
50796	INDIRECT	18	50569	\N	36057	49998	t
50797	INDIRECT	18	\N	50662	36057	49998	t
50417	INDIRECT	19	\N	50360	36057	49998	t
50418	INDIRECT	19	\N	50361	36057	49998	t
50419	INDIRECT	19	50189	\N	36057	49998	t
50420	INDIRECT	19	\N	50362	36057	49998	t
50421	INDIRECT	19	50190	\N	36057	49998	t
50422	INDIRECT	19	\N	50363	36057	49998	t
50423	INDIRECT	19	50191	\N	36057	49998	t
50424	INDIRECT	19	\N	50364	36057	49998	t
50425	INDIRECT	19	50192	\N	36057	49998	t
50426	INDIRECT	19	\N	50365	36057	49998	t
50427	INDIRECT	19	\N	50366	36057	49998	t
50428	INDIRECT	19	50193	\N	36057	49998	t
50429	INDIRECT	19	\N	50367	36057	49998	t
50430	INDIRECT	19	50194	\N	36057	49998	t
50431	INDIRECT	19	\N	50368	36057	49998	t
50432	INDIRECT	19	50195	\N	36057	49998	t
50433	INDIRECT	19	\N	50369	36057	49998	t
50434	INDIRECT	19	\N	50370	36057	49998	t
50435	INDIRECT	19	50196	\N	36057	49998	t
50436	INDIRECT	19	\N	50371	36057	49998	t
51642	INDIRECT	15	50503	\N	49894	51634	t
50473	INDIRECT	19	50515	\N	36057	49998	t
50474	INDIRECT	19	\N	50393	36057	49998	t
50475	INDIRECT	19	50516	\N	36057	49998	t
50476	INDIRECT	19	\N	50394	36057	49998	t
50477	INDIRECT	19	50517	\N	36057	49998	t
50478	INDIRECT	19	\N	50395	36057	49998	t
50479	INDIRECT	19	50518	\N	36057	49998	t
50480	INDIRECT	19	\N	50396	36057	49998	t
50481	INDIRECT	19	50519	\N	36057	49998	t
50484	INDIRECT	19	\N	50398	36057	49998	t
50485	INDIRECT	19	\N	50601	36057	49998	t
50486	INDIRECT	19	50521	\N	36057	49998	t
50487	INDIRECT	19	\N	50602	36057	49998	t
50488	INDIRECT	19	50522	\N	36057	49998	t
50763	INDIRECT	18	\N	50643	36057	49998	t
50764	INDIRECT	18	\N	50644	36057	49998	t
50765	INDIRECT	18	50555	\N	36057	49998	t
50766	INDIRECT	18	\N	50645	36057	49998	t
50767	INDIRECT	18	50556	\N	36057	49998	t
50768	INDIRECT	18	\N	50646	36057	49998	t
58107	DIRECT	13	\N	50669	49894	\N	\N
50437	INDIRECT	19	\N	50372	36057	49998	t
50438	INDIRECT	19	50500	\N	36057	49998	t
50439	INDIRECT	19	\N	50373	36057	49998	t
50446	INDIRECT	19	\N	50377	36057	49998	t
50447	INDIRECT	19	50504	\N	36057	49998	t
50448	INDIRECT	19	\N	50378	36057	49998	t
56910	INDIRECT	14	\N	50379	49894	56909	t
50449	INDIRECT	19	\N	50379	36057	49998	t
56911	INDIRECT	14	50505	\N	49894	56909	t
50450	INDIRECT	19	50505	\N	36057	49998	t
50451	INDIRECT	19	\N	50380	36057	49998	t
56912	DIRECT	14	\N	50380	49894	\N	\N
56913	INDIRECT	14	\N	50381	49894	56912	t
50452	INDIRECT	19	\N	50381	36057	49998	t
50453	INDIRECT	19	50506	\N	36057	49998	t
56914	INDIRECT	14	50506	\N	49894	56912	t
56915	INDIRECT	14	\N	50382	49894	56912	t
50454	INDIRECT	19	\N	50382	36057	49998	t
56916	INDIRECT	14	50507	\N	49894	56912	t
50455	INDIRECT	19	50507	\N	36057	49998	t
50456	INDIRECT	19	\N	50383	36057	49998	t
56917	INDIRECT	14	\N	50383	49894	56912	t
56918	INDIRECT	14	50508	\N	49894	56912	t
50457	INDIRECT	19	50508	\N	36057	49998	t
50458	INDIRECT	19	\N	50384	36057	49998	t
56919	DIRECT	14	\N	50384	49894	\N	\N
50459	INDIRECT	19	\N	50385	36057	49998	t
56920	INDIRECT	14	\N	50385	49894	56919	t
50460	INDIRECT	19	50509	\N	36057	49998	t
56921	INDIRECT	14	50509	\N	49894	56919	t
56922	INDIRECT	14	\N	50386	49894	56919	t
56923	INDIRECT	14	50510	\N	49894	56919	t
56924	INDIRECT	14	\N	50387	49894	56919	t
56925	INDIRECT	14	50511	\N	49894	56919	t
56926	INDIRECT	14	\N	50388	49894	56919	t
56927	INDIRECT	14	50512	\N	49894	56919	t
56928	INDIRECT	14	\N	50389	49894	56919	t
56929	INDIRECT	14	50513	\N	49894	56919	t
56930	INDIRECT	14	\N	50390	49894	56919	t
56931	INDIRECT	14	50514	\N	49894	56919	t
50775	INDIRECT	18	\N	50651	36057	49998	t
50776	INDIRECT	18	50559	\N	36057	49998	t
50777	INDIRECT	18	\N	50652	36057	49998	t
50778	INDIRECT	18	50560	\N	36057	49998	t
50779	INDIRECT	18	\N	50653	36057	49998	t
50780	INDIRECT	18	50561	\N	36057	49998	t
50781	INDIRECT	18	\N	50654	36057	49998	t
50798	INDIRECT	18	50570	\N	36057	49998	t
50809	INDIRECT	16	\N	50669	36057	49998	t
50810	INDIRECT	16	\N	50670	36057	49998	t
50811	INDIRECT	16	50575	\N	36057	49998	t
56906	DIRECT	14	\N	50376	49894	\N	\N
56907	INDIRECT	14	\N	50377	49894	56906	t
56908	INDIRECT	14	50504	\N	49894	56906	t
56909	DIRECT	14	\N	50378	49894	\N	\N
56940	INDIRECT	14	50517	\N	49894	56932	t
56941	INDIRECT	14	\N	50395	49894	56932	t
56942	INDIRECT	14	50518	\N	49894	56932	t
56943	INDIRECT	14	\N	50396	49894	56932	t
56944	INDIRECT	14	50519	\N	49894	56932	t
56945	DIRECT	14	\N	50398	49894	\N	\N
56946	INDIRECT	14	\N	50601	49894	56945	t
56947	INDIRECT	14	50521	\N	49894	56945	t
56948	INDIRECT	14	\N	50602	49894	56945	t
56949	INDIRECT	14	50522	\N	49894	56945	t
56950	DIRECT	14	\N	50643	49894	\N	\N
56951	INDIRECT	14	\N	50644	49894	56950	t
56952	INDIRECT	14	50555	\N	49894	56950	t
56953	INDIRECT	14	\N	50645	49894	56950	t
56954	INDIRECT	14	50556	\N	49894	56950	t
50774	INDIRECT	18	\N	50650	36057	49998	t
113805	INDIRECT	9	109403	\N	36057	113801	t
113806	INDIRECT	9	\N	109234	36057	113801	t
113807	INDIRECT	9	109404	\N	36057	113801	t
56932	DIRECT	14	\N	50391	49894	\N	\N
56934	DIRECT	14	\N	50392	49895	\N	\N
56933	INDIRECT	14	\N	50392	49894	56932	f
56935	INDIRECT	14	50515	\N	49895	56934	t
56936	INDIRECT	14	50515	\N	49894	56932	f
56937	INDIRECT	14	\N	50393	49894	56932	t
56938	INDIRECT	14	50516	\N	49894	56932	t
56939	INDIRECT	14	\N	50394	49894	56932	t
58082	DIRECT	13	\N	50650	49894	\N	\N
58083	INDIRECT	13	\N	50651	49894	58082	t
58084	INDIRECT	13	50559	\N	49894	58082	t
58085	INDIRECT	13	\N	50652	49894	58082	t
58086	INDIRECT	13	50560	\N	49894	58082	t
58087	INDIRECT	13	\N	50653	49894	58082	t
58088	INDIRECT	13	50561	\N	49894	58082	t
58089	INDIRECT	13	\N	50654	49894	58082	t
58090	INDIRECT	13	50562	\N	49894	58082	t
58091	INDIRECT	13	\N	50655	49894	58082	t
58092	INDIRECT	13	50563	\N	49894	58082	t
58093	INDIRECT	13	\N	50656	49894	58082	t
58094	INDIRECT	13	50564	\N	49894	58082	t
58095	INDIRECT	13	\N	50657	49894	58082	t
58096	INDIRECT	13	50565	\N	49894	58082	t
58097	INDIRECT	13	\N	50658	49894	58082	t
58098	INDIRECT	13	50566	\N	49894	58082	t
58099	INDIRECT	13	\N	50659	49894	58082	t
58100	INDIRECT	13	50567	\N	49894	58082	t
58101	INDIRECT	13	\N	50660	49894	58082	t
58102	INDIRECT	13	50568	\N	49894	58082	t
58103	DIRECT	13	\N	50661	49896	\N	\N
58104	INDIRECT	13	50569	\N	49896	58103	t
113808	INDIRECT	9	\N	109235	36057	113801	t
113809	INDIRECT	9	109405	\N	36057	113801	t
113798	DIRECT	9	\N	109229	36057	\N	\N
113799	INDIRECT	9	\N	109230	36057	113798	t
58105	DIRECT	13	\N	50662	49895	\N	\N
58106	INDIRECT	13	50570	\N	49895	58105	t
58108	INDIRECT	13	\N	50670	49894	58107	t
58109	INDIRECT	13	50575	\N	49894	58107	t
113800	INDIRECT	9	109401	\N	36057	113798	t
113801	DIRECT	9	\N	109231	36057	\N	\N
113802	INDIRECT	9	\N	109232	36057	113801	t
113803	INDIRECT	9	109402	\N	36057	113801	t
113804	INDIRECT	9	\N	109233	36057	113801	t
50812	INDIRECT	16	\N	50671	36057	49998	t
58110	INDIRECT	13	\N	50671	49894	58107	t
58111	INDIRECT	13	50576	\N	49894	58107	t
113812	INDIRECT	9	109446	\N	36057	113810	t
113813	INDIRECT	9	\N	109504	36057	113810	t
113814	INDIRECT	9	109447	\N	36057	113810	t
113815	INDIRECT	9	\N	109505	36057	113810	t
113816	INDIRECT	9	109448	\N	36057	113810	t
113817	INDIRECT	9	\N	109506	36057	113810	t
113818	INDIRECT	9	109449	\N	36057	113810	t
113819	INDIRECT	9	\N	109507	36057	113810	t
113820	INDIRECT	9	109450	\N	36057	113810	t
113821	DIRECT	9	\N	109508	36057	\N	\N
113822	INDIRECT	9	\N	109509	36057	113821	t
113823	INDIRECT	9	109451	\N	36057	113821	t
113824	INDIRECT	9	\N	109510	36057	113821	t
113825	INDIRECT	9	109452	\N	36057	113821	t
113826	DIRECT	9	\N	109513	36057	\N	\N
113827	INDIRECT	9	\N	109514	36057	113826	t
113828	INDIRECT	9	109454	\N	36057	113826	t
113829	DIRECT	9	\N	109515	36057	\N	\N
113830	INDIRECT	9	\N	109516	36057	113829	t
50813	INDIRECT	16	50576	\N	36057	49998	t
113831	INDIRECT	9	109455	\N	36057	113829	t
113832	DIRECT	9	\N	109517	36057	\N	\N
113833	INDIRECT	9	\N	109518	36057	113832	t
113834	INDIRECT	9	109456	\N	36057	113832	t
113873	INDIRECT	3	\N	109539	36057	113832	t
113874	INDIRECT	3	109475	\N	36057	113832	t
113835	DIRECT	9	\N	109519	36057	\N	\N
113836	INDIRECT	9	\N	109520	36057	113835	t
113837	INDIRECT	9	109457	\N	36057	113835	t
113838	DIRECT	9	\N	109521	36057	\N	\N
113849	INDIRECT	5	\N	109527	36057	113801	t
113850	INDIRECT	5	109463	\N	36057	113801	t
113851	INDIRECT	5	\N	109528	36057	113801	t
113852	INDIRECT	5	109464	\N	36057	113801	t
113810	DIRECT	9	\N	109502	36057	\N	\N
113811	INDIRECT	9	\N	109503	36057	113810	t
113839	INDIRECT	9	\N	109522	36057	113838	t
113840	INDIRECT	9	109458	\N	36057	113838	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
49705	4	2009-12-23 13:42:26.88	\N	f	36057	49302
49704	4	2009-12-23 13:42:31.649	\N	f	49895	49302
49692	5	2009-12-23 13:31:53.237	\N	f	36057	49289
49715	2	2009-12-23 14:05:57.765	\N	f	49894	49313
49714	2	2009-12-23 14:05:54.245	\N	f	36057	49313
49693	4	2009-12-23 13:33:29.272	\N	f	49894	36159
36562	5	2009-12-14 12:02:22.226	\N	f	36057	36159
37976	4	2009-12-14 12:37:38.899	\N	f	36057	37573
49694	3	2009-12-23 13:33:42.338	\N	f	49894	37573
49703	3	2009-12-23 13:42:13.486	\N	f	36057	49300
1819	2	2009-12-07 12:14:12.984	\N	f	107	1720
1818	2	2009-12-07 12:13:55.69	\N	f	105	1718
49702	3	2009-12-23 13:42:17.331	\N	f	49894	49300
49716	2	2009-12-23 14:06:21.862	\N	f	108	49315
1821	3	2009-12-07 12:15:40.633	\N	f	106	1724
1820	3	2009-12-07 12:14:39.805	\N	f	105	1722
49707	6	2009-12-23 13:44:09.703	\N	f	49896	49304
49706	6	2009-12-23 13:43:57.657	\N	f	36057	49304
49695	7	2009-12-23 13:33:57.905	\N	f	49894	40199
40602	8	2009-12-18 11:37:52.396	\N	f	36057	40199
7575	6	2009-12-08 11:38:48.256	\N	f	111	7272
1822	7	2009-12-07 12:16:13.031	\N	f	105	1726
49711	7	2009-12-23 13:47:11.819	\N	f	49894	49309
1823	7	2009-12-07 12:22:26.956	\N	f	110	1727
49710	7	2009-12-23 13:47:08.42	\N	f	36057	49309
49700	7	2009-12-23 13:41:16.177	\N	f	49894	49297
37977	1	2009-12-14 13:20:50.703	\N	f	38481	37575
49701	7	2009-12-23 13:41:11.777	\N	f	36057	49297
115039	2	2010-01-11 16:05:09.333	\N	f	105	114636
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
4	9	JOB	Job	t	t	t	1
16154624	1	Rol proyecto	\N	t	t	t	0
1	15	LEAVE	Leave	f	f	t	1
2	11	CATEGORY	Professional category	t	t	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
7	2	Tipo de máquina	\N	t	f	t	2
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id, derived_allocation_id) FROM stdin;
30862	GENERIC_DAY	3	3	2010-02-05	1724	\N	29808	\N
30863	GENERIC_DAY	3	3	2010-03-09	1724	\N	29808	\N
30864	GENERIC_DAY	3	3	2010-01-15	1724	\N	29808	\N
30865	GENERIC_DAY	3	3	2010-02-16	1724	\N	29808	\N
30866	GENERIC_DAY	3	3	2010-01-21	1724	\N	29808	\N
30867	GENERIC_DAY	3	0	2010-04-10	1724	\N	29808	\N
30868	GENERIC_DAY	3	3	2010-01-25	1724	\N	29808	\N
30869	GENERIC_DAY	3	0	2010-03-13	1724	\N	29808	\N
30870	GENERIC_DAY	3	2	2010-04-15	1724	\N	29808	\N
30871	GENERIC_DAY	3	0	2010-04-11	1724	\N	29808	\N
30872	GENERIC_DAY	3	0	2010-03-20	1724	\N	29808	\N
30873	GENERIC_DAY	3	3	2010-03-12	1724	\N	29808	\N
30874	GENERIC_DAY	3	0	2010-03-06	1724	\N	29808	\N
30875	GENERIC_DAY	3	3	2010-03-31	1724	\N	29808	\N
30876	GENERIC_DAY	3	3	2010-03-17	1724	\N	29808	\N
30877	GENERIC_DAY	3	2	2010-04-05	1724	\N	29808	\N
30878	GENERIC_DAY	3	0	2010-03-27	1724	\N	29808	\N
30879	GENERIC_DAY	3	0	2010-03-21	1724	\N	29808	\N
30880	GENERIC_DAY	3	3	2010-03-10	1724	\N	29808	\N
30881	GENERIC_DAY	3	3	2010-03-30	1724	\N	29808	\N
30882	GENERIC_DAY	3	3	2010-03-11	1724	\N	29808	\N
30883	GENERIC_DAY	3	3	2010-02-02	1724	\N	29808	\N
30884	GENERIC_DAY	3	3	2010-03-24	1724	\N	29808	\N
30885	GENERIC_DAY	3	0	2010-03-14	1724	\N	29808	\N
30886	GENERIC_DAY	3	0	2010-02-21	1724	\N	29808	\N
30887	GENERIC_DAY	3	0	2010-04-04	1724	\N	29808	\N
30888	GENERIC_DAY	3	3	2010-01-20	1724	\N	29808	\N
30889	GENERIC_DAY	3	3	2010-02-19	1724	\N	29808	\N
30890	GENERIC_DAY	3	3	2010-02-04	1724	\N	29808	\N
30891	GENERIC_DAY	3	3	2010-03-05	1724	\N	29808	\N
30892	GENERIC_DAY	3	3	2010-02-12	1724	\N	29808	\N
30893	GENERIC_DAY	3	3	2010-01-28	1724	\N	29808	\N
30894	GENERIC_DAY	3	2	2010-04-13	1724	\N	29808	\N
30895	GENERIC_DAY	3	3	2010-01-22	1724	\N	29808	\N
30896	GENERIC_DAY	3	3	2010-03-02	1724	\N	29808	\N
30897	GENERIC_DAY	3	0	2010-02-06	1724	\N	29808	\N
30898	GENERIC_DAY	3	3	2010-01-12	1724	\N	29808	\N
30899	GENERIC_DAY	3	3	2010-01-18	1724	\N	29808	\N
30900	GENERIC_DAY	3	3	2010-03-23	1724	\N	29808	\N
30901	GENERIC_DAY	3	2	2010-04-07	1724	\N	29808	\N
30902	GENERIC_DAY	3	3	2010-01-11	1724	\N	29808	\N
30903	GENERIC_DAY	3	0	2010-02-07	1724	\N	29808	\N
30904	GENERIC_DAY	3	3	2010-02-24	1724	\N	29808	\N
30905	GENERIC_DAY	3	0	2010-04-03	1724	\N	29808	\N
30906	GENERIC_DAY	3	2	2010-04-08	1724	\N	29808	\N
30907	GENERIC_DAY	3	3	2010-02-25	1724	\N	29808	\N
30908	GENERIC_DAY	3	3	2010-01-29	1724	\N	29808	\N
30909	GENERIC_DAY	3	0	2010-01-30	1724	\N	29808	\N
30910	GENERIC_DAY	3	3	2010-02-17	1724	\N	29808	\N
30911	GENERIC_DAY	3	3	2010-02-10	1724	\N	29808	\N
30912	GENERIC_DAY	3	3	2010-01-19	1724	\N	29808	\N
30913	GENERIC_DAY	3	2	2010-04-12	1724	\N	29808	\N
30914	GENERIC_DAY	3	0	2010-04-18	1724	\N	29808	\N
30915	GENERIC_DAY	3	3	2010-02-08	1724	\N	29808	\N
30916	GENERIC_DAY	3	0	2010-01-24	1724	\N	29808	\N
30917	GENERIC_DAY	3	0	2010-03-07	1724	\N	29808	\N
30918	GENERIC_DAY	3	0	2010-02-27	1724	\N	29808	\N
30919	GENERIC_DAY	3	0	2010-01-23	1724	\N	29808	\N
30920	GENERIC_DAY	3	3	2010-02-01	1724	\N	29808	\N
30921	GENERIC_DAY	3	3	2010-03-25	1724	\N	29808	\N
30922	GENERIC_DAY	3	3	2010-04-01	1724	\N	29808	\N
30923	GENERIC_DAY	3	0	2010-01-17	1724	\N	29808	\N
16002	GENERIC_DAY	3	3	2010-04-07	1726	\N	3985	\N
16003	GENERIC_DAY	3	2	2010-04-08	1718	\N	3985	\N
16004	GENERIC_DAY	3	1	2010-04-10	1718	\N	3985	\N
16005	GENERIC_DAY	3	3	2010-03-29	1722	\N	3985	\N
16006	GENERIC_DAY	3	2	2010-04-05	1718	\N	3985	\N
16007	GENERIC_DAY	3	3	2010-04-03	1722	\N	3985	\N
16008	GENERIC_DAY	3	3	2010-04-01	1726	\N	3985	\N
16009	GENERIC_DAY	3	2	2010-04-09	1718	\N	3985	\N
16010	GENERIC_DAY	3	2	2010-03-30	1718	\N	3985	\N
16011	GENERIC_DAY	3	3	2010-04-09	1722	\N	3985	\N
16012	GENERIC_DAY	3	2	2010-04-02	1718	\N	3985	\N
16013	GENERIC_DAY	3	2	2010-04-03	1718	\N	3985	\N
16014	GENERIC_DAY	3	2	2010-03-31	1718	\N	3985	\N
16015	GENERIC_DAY	3	3	2010-04-09	1726	\N	3985	\N
16016	GENERIC_DAY	3	3	2010-03-29	1726	\N	3985	\N
16017	GENERIC_DAY	3	3	2010-04-05	1722	\N	3985	\N
16018	GENERIC_DAY	3	2	2010-04-07	1718	\N	3985	\N
16019	GENERIC_DAY	3	3	2010-04-04	1722	\N	3985	\N
16020	GENERIC_DAY	3	2	2010-03-29	1718	\N	3985	\N
16021	GENERIC_DAY	3	2	2010-04-04	1718	\N	3985	\N
16022	GENERIC_DAY	3	2	2010-04-01	1718	\N	3985	\N
16023	GENERIC_DAY	3	3	2010-03-30	1722	\N	3985	\N
16024	GENERIC_DAY	3	3	2010-04-02	1722	\N	3985	\N
16025	GENERIC_DAY	3	3	2010-04-07	1722	\N	3985	\N
16026	GENERIC_DAY	3	3	2010-04-04	1726	\N	3985	\N
16027	GENERIC_DAY	3	2	2010-04-06	1718	\N	3985	\N
16028	GENERIC_DAY	3	3	2010-04-06	1726	\N	3985	\N
16029	GENERIC_DAY	3	1	2010-04-10	1726	\N	3985	\N
16030	GENERIC_DAY	3	2	2010-04-10	1722	\N	3985	\N
16031	GENERIC_DAY	3	3	2010-04-03	1726	\N	3985	\N
16032	GENERIC_DAY	3	3	2010-03-31	1726	\N	3985	\N
16033	GENERIC_DAY	3	3	2010-04-06	1722	\N	3985	\N
16034	GENERIC_DAY	3	3	2010-04-08	1726	\N	3985	\N
38745	GENERIC_DAY	6	5	2010-03-09	37573	\N	38583	\N
38732	GENERIC_DAY	6	0	2010-03-14	37573	\N	38583	\N
38744	GENERIC_DAY	6	3	2010-03-02	36159	\N	38583	\N
38752	GENERIC_DAY	6	4	2010-02-24	37573	\N	38583	\N
38759	GENERIC_DAY	6	3	2010-03-11	36159	\N	38583	\N
38746	GENERIC_DAY	6	5	2010-03-03	37573	\N	38583	\N
38757	GENERIC_DAY	6	4	2010-02-26	36159	\N	38583	\N
38736	GENERIC_DAY	6	0	2010-03-06	36159	\N	38583	\N
38747	GENERIC_DAY	6	3	2010-03-01	36159	\N	38583	\N
38753	GENERIC_DAY	6	5	2010-03-12	37573	\N	38583	\N
38734	GENERIC_DAY	6	4	2010-02-25	36159	\N	38583	\N
38733	GENERIC_DAY	6	0	2010-03-13	36159	\N	38583	\N
38730	GENERIC_DAY	6	0	2010-03-14	36159	\N	38583	\N
38756	GENERIC_DAY	6	3	2010-03-08	36159	\N	38583	\N
27203	GENERIC_DAY	1	3	2009-12-09	1718	\N	3940	\N
27204	GENERIC_DAY	1	3	2009-12-16	1726	\N	3940	\N
27205	GENERIC_DAY	1	3	2009-12-10	1726	\N	3940	\N
27206	GENERIC_DAY	1	1	2009-12-23	1726	\N	3940	\N
27207	GENERIC_DAY	1	2	2009-12-08	1718	\N	3940	\N
27208	GENERIC_DAY	1	3	2009-12-08	1722	\N	3940	\N
27209	GENERIC_DAY	1	0	2009-12-13	1718	\N	3940	\N
38735	GENERIC_DAY	6	3	2010-03-03	36159	\N	38583	\N
38741	GENERIC_DAY	6	3	2010-02-22	36159	\N	38583	\N
38742	GENERIC_DAY	6	3	2010-03-05	36159	\N	38583	\N
31145	GENERIC_DAY	1	8	2010-03-15	1724	\N	28093	\N
31146	GENERIC_DAY	1	0	2010-02-20	1724	\N	28093	\N
24760	GENERIC_DAY	1	8	2010-04-15	1720	\N	19898	\N
24748	GENERIC_DAY	1	8	2010-04-20	1720	\N	19898	\N
24751	GENERIC_DAY	1	8	2010-04-21	1720	\N	19898	\N
24764	GENERIC_DAY	1	8	2010-04-08	1720	\N	19898	\N
24756	GENERIC_DAY	1	0	2010-04-10	1720	\N	19898	\N
24745	GENERIC_DAY	1	0	2010-04-03	1720	\N	19898	\N
24749	GENERIC_DAY	1	0	2010-04-18	1720	\N	19898	\N
24755	GENERIC_DAY	1	0	2010-04-04	1720	\N	19898	\N
24752	GENERIC_DAY	1	8	2010-04-09	1720	\N	19898	\N
24753	GENERIC_DAY	1	8	2010-04-05	1720	\N	19898	\N
24762	GENERIC_DAY	1	8	2010-04-12	1720	\N	19898	\N
24758	GENERIC_DAY	1	8	2010-04-06	1720	\N	19898	\N
24763	GENERIC_DAY	1	8	2010-04-01	1720	\N	19898	\N
24750	GENERIC_DAY	1	8	2010-04-13	1720	\N	19898	\N
24766	GENERIC_DAY	1	4	2010-04-22	1720	\N	19898	\N
24747	GENERIC_DAY	1	8	2010-04-07	1720	\N	19898	\N
24754	GENERIC_DAY	1	8	2010-04-02	1720	\N	19898	\N
24757	GENERIC_DAY	1	8	2010-03-31	1720	\N	19898	\N
24759	GENERIC_DAY	1	8	2010-04-19	1720	\N	19898	\N
24743	GENERIC_DAY	1	8	2010-04-16	1720	\N	19898	\N
24744	GENERIC_DAY	1	0	2010-04-11	1720	\N	19898	\N
24746	GENERIC_DAY	1	8	2010-03-30	1720	\N	19898	\N
24765	GENERIC_DAY	1	0	2010-04-17	1720	\N	19898	\N
24761	GENERIC_DAY	1	8	2010-04-14	1720	\N	19898	\N
24660	GENERIC_DAY	1	2	2010-02-10	1718	\N	19899	\N
24694	GENERIC_DAY	1	0	2009-12-27	1726	\N	19899	\N
24699	GENERIC_DAY	1	0	2010-01-10	1722	\N	19899	\N
24691	GENERIC_DAY	1	2	2010-02-11	1718	\N	19899	\N
24621	GENERIC_DAY	1	2	2010-01-05	1722	\N	19899	\N
24732	GENERIC_DAY	1	0	2010-01-03	1726	\N	19899	\N
24693	GENERIC_DAY	1	3	2009-12-18	1726	\N	19899	\N
24603	GENERIC_DAY	1	2	2010-02-09	1718	\N	19899	\N
24695	GENERIC_DAY	1	2	2009-12-22	1726	\N	19899	\N
24684	GENERIC_DAY	1	2	2010-01-27	1726	\N	19899	\N
24618	GENERIC_DAY	1	2	2010-02-03	1722	\N	19899	\N
24722	GENERIC_DAY	1	2	2009-12-23	1722	\N	19899	\N
24672	GENERIC_DAY	1	0	2010-01-30	1718	\N	19899	\N
24737	GENERIC_DAY	1	0	2010-01-16	1722	\N	19899	\N
24734	GENERIC_DAY	1	3	2010-01-13	1726	\N	19899	\N
24697	GENERIC_DAY	1	2	2010-01-18	1718	\N	19899	\N
24630	GENERIC_DAY	1	2	2009-12-24	1722	\N	19899	\N
24656	GENERIC_DAY	1	3	2009-12-24	1718	\N	19899	\N
24718	GENERIC_DAY	1	0	2010-01-03	1722	\N	19899	\N
24663	GENERIC_DAY	1	2	2009-12-29	1726	\N	19899	\N
24708	GENERIC_DAY	1	0	2009-12-26	1722	\N	19899	\N
24644	GENERIC_DAY	1	2	2010-01-25	1718	\N	19899	\N
24692	GENERIC_DAY	1	0	2010-01-24	1726	\N	19899	\N
24639	GENERIC_DAY	1	3	2010-01-08	1726	\N	19899	\N
24698	GENERIC_DAY	1	2	2009-12-28	1726	\N	19899	\N
24742	GENERIC_DAY	1	0	2009-12-20	1722	\N	19899	\N
24726	GENERIC_DAY	1	2	2010-01-27	1718	\N	19899	\N
24647	GENERIC_DAY	1	0	2010-01-10	1726	\N	19899	\N
24730	GENERIC_DAY	1	2	2010-01-13	1722	\N	19899	\N
24641	GENERIC_DAY	1	1	2009-12-18	1722	\N	19899	\N
24602	GENERIC_DAY	1	0	2010-02-07	1726	\N	19899	\N
24649	GENERIC_DAY	1	2	2010-01-18	1722	\N	19899	\N
24638	GENERIC_DAY	1	3	2010-01-05	1718	\N	19899	\N
24655	GENERIC_DAY	1	0	2010-01-10	1718	\N	19899	\N
24733	GENERIC_DAY	1	2	2010-01-29	1722	\N	19899	\N
24702	GENERIC_DAY	1	2	2010-02-10	1726	\N	19899	\N
24689	GENERIC_DAY	1	2	2010-02-09	1726	\N	19899	\N
24711	GENERIC_DAY	1	2	2010-01-07	1718	\N	19899	\N
24614	GENERIC_DAY	1	2	2010-02-04	1722	\N	19899	\N
24609	GENERIC_DAY	1	2	2010-01-08	1718	\N	19899	\N
24690	GENERIC_DAY	1	3	2009-12-31	1718	\N	19899	\N
24611	GENERIC_DAY	1	2	2009-12-21	1726	\N	19899	\N
24632	GENERIC_DAY	1	0	2010-01-02	1726	\N	19899	\N
24687	GENERIC_DAY	1	0	2010-01-24	1718	\N	19899	\N
24654	GENERIC_DAY	1	0	2009-12-26	1726	\N	19899	\N
24619	GENERIC_DAY	1	0	2010-01-16	1726	\N	19899	\N
24716	GENERIC_DAY	1	0	2010-01-09	1722	\N	19899	\N
24642	GENERIC_DAY	1	0	2009-12-26	1718	\N	19899	\N
24736	GENERIC_DAY	1	2	2010-01-20	1718	\N	19899	\N
24653	GENERIC_DAY	1	2	2009-12-30	1722	\N	19899	\N
24628	GENERIC_DAY	1	0	2010-01-03	1718	\N	19899	\N
24652	GENERIC_DAY	1	2	2010-02-09	1722	\N	19899	\N
24666	GENERIC_DAY	1	2	2010-01-04	1722	\N	19899	\N
24741	GENERIC_DAY	1	0	2010-01-17	1726	\N	19899	\N
24686	GENERIC_DAY	1	2	2010-01-26	1726	\N	19899	\N
24738	GENERIC_DAY	1	2	2010-02-04	1726	\N	19899	\N
24615	GENERIC_DAY	1	2	2010-01-26	1722	\N	19899	\N
24723	GENERIC_DAY	1	0	2010-01-09	1726	\N	19899	\N
24657	GENERIC_DAY	1	2	2010-01-15	1718	\N	19899	\N
24608	GENERIC_DAY	1	2	2010-01-14	1718	\N	19899	\N
24665	GENERIC_DAY	1	0	2009-12-19	1726	\N	19899	\N
24648	GENERIC_DAY	1	2	2010-02-01	1726	\N	19899	\N
24721	GENERIC_DAY	1	0	2010-01-30	1726	\N	19899	\N
24635	GENERIC_DAY	1	3	2009-12-18	1718	\N	19899	\N
24717	GENERIC_DAY	1	0	2010-01-24	1722	\N	19899	\N
24673	GENERIC_DAY	1	3	2009-12-21	1718	\N	19899	\N
24600	GENERIC_DAY	1	2	2010-01-28	1718	\N	19899	\N
24735	GENERIC_DAY	1	0	2009-12-27	1718	\N	19899	\N
24643	GENERIC_DAY	1	0	2010-01-31	1726	\N	19899	\N
24682	GENERIC_DAY	1	0	2010-02-07	1718	\N	19899	\N
24704	GENERIC_DAY	1	3	2010-01-18	1726	\N	19899	\N
24625	GENERIC_DAY	1	2	2010-01-06	1718	\N	19899	\N
24616	GENERIC_DAY	1	2	2009-12-31	1726	\N	19899	\N
24613	GENERIC_DAY	1	3	2010-01-15	1726	\N	19899	\N
24661	GENERIC_DAY	1	2	2010-01-21	1722	\N	19899	\N
24688	GENERIC_DAY	1	3	2009-12-28	1718	\N	19899	\N
24633	GENERIC_DAY	1	3	2009-12-23	1718	\N	19899	\N
24667	GENERIC_DAY	1	2	2010-02-11	1726	\N	19899	\N
24669	GENERIC_DAY	1	0	2010-02-07	1722	\N	19899	\N
24617	GENERIC_DAY	1	2	2010-01-11	1718	\N	19899	\N
24664	GENERIC_DAY	1	2	2010-01-21	1718	\N	19899	\N
24677	GENERIC_DAY	1	2	2010-01-20	1722	\N	19899	\N
24605	GENERIC_DAY	1	0	2010-01-01	1722	\N	19899	\N
24629	GENERIC_DAY	1	2	2009-12-24	1726	\N	19899	\N
24731	GENERIC_DAY	1	2	2010-01-07	1722	\N	19899	\N
24681	GENERIC_DAY	1	2	2010-02-08	1726	\N	19899	\N
24674	GENERIC_DAY	1	0	2010-01-31	1718	\N	19899	\N
24715	GENERIC_DAY	1	3	2009-12-29	1718	\N	19899	\N
24724	GENERIC_DAY	1	0	2009-12-25	1726	\N	19899	\N
24739	GENERIC_DAY	1	2	2010-01-26	1718	\N	19899	\N
24612	GENERIC_DAY	1	3	2009-12-30	1718	\N	19899	\N
24636	GENERIC_DAY	1	2	2010-01-25	1722	\N	19899	\N
24725	GENERIC_DAY	1	2	2010-02-08	1718	\N	19899	\N
24679	GENERIC_DAY	1	0	2009-12-19	1722	\N	19899	\N
24662	GENERIC_DAY	1	0	2010-01-02	1718	\N	19899	\N
24683	GENERIC_DAY	1	0	2010-02-06	1718	\N	19899	\N
24626	GENERIC_DAY	1	2	2010-01-27	1722	\N	19899	\N
24645	GENERIC_DAY	1	0	2010-02-06	1722	\N	19899	\N
24640	GENERIC_DAY	1	2	2010-02-11	1722	\N	19899	\N
24604	GENERIC_DAY	1	0	2010-01-09	1718	\N	19899	\N
24710	GENERIC_DAY	1	0	2010-01-23	1726	\N	19899	\N
24610	GENERIC_DAY	1	3	2010-01-04	1718	\N	19899	\N
24728	GENERIC_DAY	1	2	2010-01-04	1726	\N	19899	\N
24634	GENERIC_DAY	1	2	2010-01-22	1718	\N	19899	\N
24700	GENERIC_DAY	1	2	2010-02-05	1718	\N	19899	\N
24729	GENERIC_DAY	1	2	2010-01-08	1722	\N	19899	\N
24650	GENERIC_DAY	1	2	2010-01-12	1722	\N	19899	\N
24646	GENERIC_DAY	1	3	2010-01-11	1726	\N	19899	\N
24706	GENERIC_DAY	1	2	2010-02-04	1718	\N	19899	\N
24701	GENERIC_DAY	1	2	2010-01-12	1718	\N	19899	\N
24599	GENERIC_DAY	1	2	2009-12-22	1722	\N	19899	\N
24727	GENERIC_DAY	1	2	2010-02-03	1718	\N	19899	\N
24606	GENERIC_DAY	1	2	2010-01-14	1722	\N	19899	\N
24712	GENERIC_DAY	1	2	2009-12-31	1722	\N	19899	\N
24707	GENERIC_DAY	1	2	2010-02-05	1722	\N	19899	\N
24696	GENERIC_DAY	1	2	2009-12-29	1722	\N	19899	\N
24607	GENERIC_DAY	1	0	2010-01-02	1722	\N	19899	\N
24740	GENERIC_DAY	1	0	2009-12-20	1726	\N	19899	\N
24601	GENERIC_DAY	1	2	2010-01-25	1726	\N	19899	\N
24620	GENERIC_DAY	1	2	2010-01-28	1726	\N	19899	\N
24637	GENERIC_DAY	1	3	2010-01-14	1726	\N	19899	\N
24680	GENERIC_DAY	1	2	2010-02-03	1726	\N	19899	\N
24623	GENERIC_DAY	1	0	2009-12-25	1722	\N	19899	\N
24659	GENERIC_DAY	1	2	2009-12-21	1722	\N	19899	\N
24719	GENERIC_DAY	1	2	2010-02-01	1722	\N	19899	\N
24703	GENERIC_DAY	1	2	2010-02-08	1722	\N	19899	\N
24624	GENERIC_DAY	1	0	2010-01-23	1722	\N	19899	\N
24678	GENERIC_DAY	1	2	2009-12-28	1722	\N	19899	\N
24720	GENERIC_DAY	1	2	2010-01-21	1726	\N	19899	\N
24705	GENERIC_DAY	1	0	2010-01-01	1718	\N	19899	\N
24668	GENERIC_DAY	1	2	2010-01-22	1726	\N	19899	\N
24675	GENERIC_DAY	1	2	2010-02-10	1722	\N	19899	\N
24709	GENERIC_DAY	1	0	2010-01-23	1718	\N	19899	\N
24676	GENERIC_DAY	1	2	2010-01-19	1718	\N	19899	\N
24714	GENERIC_DAY	1	2	2010-01-19	1722	\N	19899	\N
24627	GENERIC_DAY	1	2	2010-01-28	1722	\N	19899	\N
24651	GENERIC_DAY	1	2	2010-01-29	1726	\N	19899	\N
24622	GENERIC_DAY	1	0	2009-12-25	1718	\N	19899	\N
24631	GENERIC_DAY	1	2	2010-02-01	1718	\N	19899	\N
24713	GENERIC_DAY	1	0	2010-01-17	1718	\N	19899	\N
24685	GENERIC_DAY	1	0	2009-12-19	1718	\N	19899	\N
24658	GENERIC_DAY	1	2	2009-12-23	1726	\N	19899	\N
24671	GENERIC_DAY	1	0	2010-02-06	1726	\N	19899	\N
24670	GENERIC_DAY	1	3	2010-01-20	1726	\N	19899	\N
24787	GENERIC_DAY	1	1	2010-03-01	1722	\N	19897	\N
24820	GENERIC_DAY	1	4	2010-02-23	1718	\N	19897	\N
24884	GENERIC_DAY	1	0	2010-03-14	1722	\N	19897	\N
24869	GENERIC_DAY	1	2	2010-03-23	1722	\N	19897	\N
24817	GENERIC_DAY	1	0	2010-02-28	1722	\N	19897	\N
24826	GENERIC_DAY	1	0	2010-03-07	1726	\N	19897	\N
24776	GENERIC_DAY	1	2	2010-03-24	1722	\N	19897	\N
24844	GENERIC_DAY	1	3	2010-03-18	1718	\N	19897	\N
24852	GENERIC_DAY	1	0	2010-03-13	1722	\N	19897	\N
24785	GENERIC_DAY	1	2	2010-03-05	1722	\N	19897	\N
24854	GENERIC_DAY	1	3	2010-02-22	1726	\N	19897	\N
24789	GENERIC_DAY	1	0	2010-02-14	1722	\N	19897	\N
24876	GENERIC_DAY	1	1	2010-02-19	1722	\N	19897	\N
24804	GENERIC_DAY	1	0	2010-03-07	1718	\N	19897	\N
24821	GENERIC_DAY	1	0	2010-03-28	1722	\N	19897	\N
24790	GENERIC_DAY	1	0	2010-02-13	1722	\N	19897	\N
24793	GENERIC_DAY	1	0	2010-03-06	1722	\N	19897	\N
24846	GENERIC_DAY	1	0	2010-02-28	1718	\N	19897	\N
24881	GENERIC_DAY	1	0	2010-02-28	1726	\N	19897	\N
24836	GENERIC_DAY	1	2	2010-03-08	1722	\N	19897	\N
24808	GENERIC_DAY	1	0	2010-03-27	1718	\N	19897	\N
24875	GENERIC_DAY	1	0	2010-03-28	1726	\N	19897	\N
24889	GENERIC_DAY	1	3	2010-03-10	1718	\N	19897	\N
39365	GENERIC_DAY	3	0	2010-02-13	36159	\N	38596	\N
39364	GENERIC_DAY	3	0	2010-02-06	37573	\N	38596	\N
39375	GENERIC_DAY	3	1	2010-02-09	36159	\N	38596	\N
39369	GENERIC_DAY	3	0	2010-02-16	37573	\N	38596	\N
39360	GENERIC_DAY	3	0	2010-02-14	36159	\N	38596	\N
39362	GENERIC_DAY	3	0	2010-02-15	36159	\N	38596	\N
39374	GENERIC_DAY	3	0	2010-02-15	37573	\N	38596	\N
39363	GENERIC_DAY	3	0	2010-02-12	37573	\N	38596	\N
39372	GENERIC_DAY	3	0	2010-02-06	36159	\N	38596	\N
39367	GENERIC_DAY	3	0	2010-01-24	37573	\N	38596	\N
39358	GENERIC_DAY	3	0	2010-02-07	36159	\N	38596	\N
39357	GENERIC_DAY	3	1	2010-01-28	37573	\N	38596	\N
39373	GENERIC_DAY	3	0	2010-02-08	37573	\N	38596	\N
39356	GENERIC_DAY	3	0	2010-02-17	37573	\N	38596	\N
39371	GENERIC_DAY	3	0	2010-02-05	37573	\N	38596	\N
39370	GENERIC_DAY	3	0	2010-02-03	37573	\N	38596	\N
39361	GENERIC_DAY	3	0	2010-01-29	36159	\N	38596	\N
39359	GENERIC_DAY	3	0	2010-01-22	37573	\N	38596	\N
39366	GENERIC_DAY	3	0	2010-02-14	37573	\N	38596	\N
39368	GENERIC_DAY	3	0	2010-01-26	37573	\N	38596	\N
39376	GENERIC_DAY	3	0	2010-01-27	36159	\N	38596	\N
39354	GENERIC_DAY	3	4	2010-03-16	37573	\N	38595	\N
39355	GENERIC_DAY	3	3	2010-03-16	36159	\N	38595	\N
120987	SPECIFIC_DAY	1	4	2010-02-04	49309	119897	\N	\N
120986	SPECIFIC_DAY	1	4	2010-02-12	49309	119897	\N	\N
31194	GENERIC_DAY	1	0	2010-02-28	1724	\N	28093	\N
31169	GENERIC_DAY	1	8	2010-03-09	1724	\N	28093	\N
31167	GENERIC_DAY	1	8	2010-02-01	1724	\N	28093	\N
31229	GENERIC_DAY	1	0	2010-03-27	1724	\N	28093	\N
31207	GENERIC_DAY	1	8	2010-03-29	1724	\N	28093	\N
31221	GENERIC_DAY	1	8	2010-03-04	1724	\N	28093	\N
31217	GENERIC_DAY	1	8	2010-03-08	1724	\N	28093	\N
31185	GENERIC_DAY	1	9	2010-01-22	1724	\N	28093	\N
31175	GENERIC_DAY	1	9	2010-01-18	1724	\N	28093	\N
31189	GENERIC_DAY	1	8	2010-03-17	1724	\N	28093	\N
31163	GENERIC_DAY	1	8	2010-04-09	1724	\N	28093	\N
120983	SPECIFIC_DAY	1	4	2010-02-11	49309	119897	\N	\N
120982	SPECIFIC_DAY	1	4	2010-02-10	49309	119897	\N	\N
120978	SPECIFIC_DAY	1	3	2010-02-22	49309	119897	\N	\N
120981	SPECIFIC_DAY	1	4	2010-02-09	49309	119897	\N	\N
120975	SPECIFIC_DAY	1	0	2010-02-20	49309	119897	\N	\N
120976	SPECIFIC_DAY	1	4	2010-02-05	49309	119897	\N	\N
120980	SPECIFIC_DAY	1	4	2010-02-18	49309	119897	\N	\N
120988	SPECIFIC_DAY	1	4	2010-02-15	49309	119897	\N	\N
120984	SPECIFIC_DAY	1	4	2010-02-19	49309	119897	\N	\N
120985	SPECIFIC_DAY	1	4	2010-02-08	49309	119897	\N	\N
120979	SPECIFIC_DAY	1	4	2010-02-01	49309	119897	\N	\N
120977	SPECIFIC_DAY	1	4	2010-02-17	49309	119897	\N	\N
39385	GENERIC_DAY	3	0	2010-02-17	36159	\N	38596	\N
39398	GENERIC_DAY	3	0	2010-01-24	36159	\N	38596	\N
39381	GENERIC_DAY	3	0	2010-02-11	37573	\N	38596	\N
39409	GENERIC_DAY	3	1	2010-02-03	36159	\N	38596	\N
39397	GENERIC_DAY	3	0	2010-01-25	37573	\N	38596	\N
39404	GENERIC_DAY	3	1	2010-02-04	36159	\N	38596	\N
39379	GENERIC_DAY	3	0	2010-01-30	36159	\N	38596	\N
39383	GENERIC_DAY	3	1	2010-01-29	37573	\N	38596	\N
39380	GENERIC_DAY	3	0	2010-02-10	37573	\N	38596	\N
39405	GENERIC_DAY	3	1	2010-01-26	36159	\N	38596	\N
39401	GENERIC_DAY	3	1	2010-01-27	37573	\N	38596	\N
39378	GENERIC_DAY	3	0	2010-02-13	37573	\N	38596	\N
39392	GENERIC_DAY	3	0	2010-02-02	37573	\N	38596	\N
39400	GENERIC_DAY	3	1	2010-01-22	36159	\N	38596	\N
39386	GENERIC_DAY	3	1	2010-01-25	36159	\N	38596	\N
39388	GENERIC_DAY	3	1	2010-02-05	36159	\N	38596	\N
39399	GENERIC_DAY	3	0	2010-01-31	36159	\N	38596	\N
39394	GENERIC_DAY	3	1	2010-02-12	36159	\N	38596	\N
39387	GENERIC_DAY	3	1	2010-02-08	36159	\N	38596	\N
39391	GENERIC_DAY	3	0	2010-02-16	36159	\N	38596	\N
39377	GENERIC_DAY	3	0	2010-01-28	36159	\N	38596	\N
39403	GENERIC_DAY	3	0	2010-01-23	37573	\N	38596	\N
39384	GENERIC_DAY	3	0	2010-02-04	37573	\N	38596	\N
39407	GENERIC_DAY	3	1	2010-02-01	37573	\N	38596	\N
39395	GENERIC_DAY	3	0	2010-01-30	37573	\N	38596	\N
39402	GENERIC_DAY	3	0	2010-02-07	37573	\N	38596	\N
39393	GENERIC_DAY	3	1	2010-02-11	36159	\N	38596	\N
39396	GENERIC_DAY	3	1	2010-02-10	36159	\N	38596	\N
39390	GENERIC_DAY	3	1	2010-02-02	36159	\N	38596	\N
39406	GENERIC_DAY	3	0	2010-01-31	37573	\N	38596	\N
39389	GENERIC_DAY	3	0	2010-02-09	37573	\N	38596	\N
39408	GENERIC_DAY	3	0	2010-02-01	36159	\N	38596	\N
39382	GENERIC_DAY	3	0	2010-01-23	36159	\N	38596	\N
39410	GENERIC_DAY	3	3	2010-02-18	37573	\N	38597	\N
39411	GENERIC_DAY	3	4	2010-02-18	36159	\N	38597	\N
39414	GENERIC_DAY	3	4	2010-03-17	36159	\N	38598	\N
39412	GENERIC_DAY	3	3	2010-03-18	36159	\N	38598	\N
39413	GENERIC_DAY	3	4	2010-03-17	37573	\N	38598	\N
39415	GENERIC_DAY	3	3	2010-03-18	37573	\N	38598	\N
41319	GENERIC_DAY	18	2	2010-01-12	36159	\N	41014	\N
41325	GENERIC_DAY	18	2	2010-01-11	37573	\N	41014	\N
41320	GENERIC_DAY	18	2	2010-01-11	36159	\N	41014	\N
41321	GENERIC_DAY	18	2	2010-01-12	40199	\N	41014	\N
41323	GENERIC_DAY	18	1	2010-01-13	36159	\N	41014	\N
41324	GENERIC_DAY	18	2	2010-01-12	37573	\N	41014	\N
41322	GENERIC_DAY	18	0	2010-01-13	40199	\N	41014	\N
41318	GENERIC_DAY	18	1	2010-01-13	37573	\N	41014	\N
41317	GENERIC_DAY	18	2	2010-01-11	40199	\N	41014	\N
45744	GENERIC_DAY	6	0	2010-02-03	40199	\N	41069	\N
45748	GENERIC_DAY	6	0	2010-02-01	40199	\N	41069	\N
45728	GENERIC_DAY	6	0	2010-01-15	36159	\N	41069	\N
45727	GENERIC_DAY	6	0	2010-02-04	40199	\N	41069	\N
45735	GENERIC_DAY	6	1	2010-01-12	37573	\N	41069	\N
45738	GENERIC_DAY	6	0	2010-01-13	40199	\N	41069	\N
27496	GENERIC_DAY	1	8	2009-12-31	1724	\N	3953	\N
39428	GENERIC_DAY	2	0	2010-03-21	37573	\N	38600	\N
39429	GENERIC_DAY	2	2	2010-03-22	37573	\N	38600	\N
39430	GENERIC_DAY	2	1	2010-03-24	36159	\N	38600	\N
39431	GENERIC_DAY	2	0	2010-03-20	36159	\N	38600	\N
24778	GENERIC_DAY	1	0	2010-03-14	1726	\N	19897	\N
24883	GENERIC_DAY	1	3	2010-03-05	1718	\N	19897	\N
24860	GENERIC_DAY	1	4	2010-02-17	1726	\N	19897	\N
24801	GENERIC_DAY	1	3	2010-02-16	1718	\N	19897	\N
24822	GENERIC_DAY	1	3	2010-03-08	1726	\N	19897	\N
24772	GENERIC_DAY	1	2	2010-03-25	1726	\N	19897	\N
24887	GENERIC_DAY	1	4	2010-02-25	1718	\N	19897	\N
24807	GENERIC_DAY	1	4	2010-02-16	1726	\N	19897	\N
24786	GENERIC_DAY	1	4	2010-02-26	1718	\N	19897	\N
24857	GENERIC_DAY	1	4	2010-02-24	1718	\N	19897	\N
24855	GENERIC_DAY	1	1	2010-02-24	1722	\N	19897	\N
24834	GENERIC_DAY	1	2	2010-03-16	1722	\N	19897	\N
24788	GENERIC_DAY	1	0	2010-02-27	1718	\N	19897	\N
24864	GENERIC_DAY	1	3	2010-03-09	1718	\N	19897	\N
24851	GENERIC_DAY	1	3	2010-03-08	1718	\N	19897	\N
24850	GENERIC_DAY	1	2	2010-03-26	1726	\N	19897	\N
24880	GENERIC_DAY	1	1	2010-02-12	1722	\N	19897	\N
39432	GENERIC_DAY	2	2	2010-03-24	37573	\N	38600	\N
39433	GENERIC_DAY	2	2	2010-03-19	36159	\N	38600	\N
39434	GENERIC_DAY	2	0	2010-03-20	37573	\N	38600	\N
39435	GENERIC_DAY	2	2	2010-03-22	36159	\N	38600	\N
39436	GENERIC_DAY	2	0	2010-03-21	36159	\N	38600	\N
39437	GENERIC_DAY	2	2	2010-03-23	37573	\N	38600	\N
39438	GENERIC_DAY	2	1	2010-03-23	36159	\N	38600	\N
24870	GENERIC_DAY	1	0	2010-02-20	1722	\N	19897	\N
24856	GENERIC_DAY	1	2	2010-03-24	1726	\N	19897	\N
24879	GENERIC_DAY	1	2	2010-03-12	1722	\N	19897	\N
24841	GENERIC_DAY	1	3	2010-03-03	1726	\N	19897	\N
24866	GENERIC_DAY	1	3	2010-03-17	1718	\N	19897	\N
24799	GENERIC_DAY	1	4	2010-03-26	1718	\N	19897	\N
24828	GENERIC_DAY	1	2	2010-03-29	1718	\N	19897	\N
24837	GENERIC_DAY	1	1	2010-03-03	1722	\N	19897	\N
24796	GENERIC_DAY	1	3	2010-02-17	1718	\N	19897	\N
24775	GENERIC_DAY	1	2	2010-03-19	1726	\N	19897	\N
24871	GENERIC_DAY	1	2	2010-03-11	1722	\N	19897	\N
24865	GENERIC_DAY	1	0	2010-03-20	1726	\N	19897	\N
24867	GENERIC_DAY	1	3	2010-02-23	1726	\N	19897	\N
24814	GENERIC_DAY	1	3	2010-03-11	1718	\N	19897	\N
24842	GENERIC_DAY	1	2	2010-03-23	1726	\N	19897	\N
24812	GENERIC_DAY	1	4	2010-03-02	1718	\N	19897	\N
24795	GENERIC_DAY	1	3	2010-03-12	1726	\N	19897	\N
24774	GENERIC_DAY	1	2	2010-03-22	1726	\N	19897	\N
24833	GENERIC_DAY	1	1	2010-03-02	1722	\N	19897	\N
24862	GENERIC_DAY	1	3	2010-02-18	1718	\N	19897	\N
24802	GENERIC_DAY	1	3	2010-03-16	1718	\N	19897	\N
24845	GENERIC_DAY	1	2	2010-03-17	1722	\N	19897	\N
24872	GENERIC_DAY	1	0	2010-02-13	1726	\N	19897	\N
24783	GENERIC_DAY	1	0	2010-03-27	1722	\N	19897	\N
24800	GENERIC_DAY	1	4	2010-02-18	1726	\N	19897	\N
24838	GENERIC_DAY	1	4	2010-02-12	1718	\N	19897	\N
24868	GENERIC_DAY	1	3	2010-02-25	1726	\N	19897	\N
24859	GENERIC_DAY	1	0	2010-03-29	1722	\N	19897	\N
24831	GENERIC_DAY	1	3	2010-03-04	1726	\N	19897	\N
24847	GENERIC_DAY	1	4	2010-02-15	1726	\N	19897	\N
24886	GENERIC_DAY	1	0	2010-03-07	1722	\N	19897	\N
24813	GENERIC_DAY	1	3	2010-03-04	1718	\N	19897	\N
24810	GENERIC_DAY	1	0	2010-02-21	1726	\N	19897	\N
24861	GENERIC_DAY	1	2	2010-03-04	1722	\N	19897	\N
24791	GENERIC_DAY	1	3	2010-03-11	1726	\N	19897	\N
24777	GENERIC_DAY	1	3	2010-03-10	1726	\N	19897	\N
24792	GENERIC_DAY	1	0	2010-03-06	1718	\N	19897	\N
24874	GENERIC_DAY	1	1	2010-02-16	1722	\N	19897	\N
24770	GENERIC_DAY	1	0	2010-03-13	1718	\N	19897	\N
24848	GENERIC_DAY	1	2	2010-03-26	1722	\N	19897	\N
24849	GENERIC_DAY	1	3	2010-03-18	1722	\N	19897	\N
24882	GENERIC_DAY	1	3	2010-03-17	1726	\N	19897	\N
24782	GENERIC_DAY	1	0	2010-02-27	1726	\N	19897	\N
24767	GENERIC_DAY	1	3	2010-02-12	1726	\N	19897	\N
24835	GENERIC_DAY	1	0	2010-03-28	1718	\N	19897	\N
24769	GENERIC_DAY	1	2	2010-03-22	1722	\N	19897	\N
24773	GENERIC_DAY	1	3	2010-03-05	1726	\N	19897	\N
45732	GENERIC_DAY	6	0	2010-01-27	36159	\N	41069	\N
45731	GENERIC_DAY	6	0	2010-02-04	36159	\N	41069	\N
45736	GENERIC_DAY	6	0	2010-01-26	36159	\N	41069	\N
45743	GENERIC_DAY	6	1	2010-01-26	40199	\N	41069	\N
45729	GENERIC_DAY	6	0	2010-01-19	40199	\N	41069	\N
45734	GENERIC_DAY	6	1	2010-01-25	40199	\N	41069	\N
45750	GENERIC_DAY	6	0	2010-01-18	36159	\N	41069	\N
45745	GENERIC_DAY	6	0	2010-01-31	40199	\N	41069	\N
24839	GENERIC_DAY	1	4	2010-03-01	1718	\N	19897	\N
24768	GENERIC_DAY	1	4	2010-02-22	1718	\N	19897	\N
24781	GENERIC_DAY	1	1	2010-02-18	1722	\N	19897	\N
24823	GENERIC_DAY	1	4	2010-03-23	1718	\N	19897	\N
24843	GENERIC_DAY	1	1	2010-02-17	1722	\N	19897	\N
24811	GENERIC_DAY	1	3	2010-02-26	1726	\N	19897	\N
24829	GENERIC_DAY	1	3	2010-03-12	1718	\N	19897	\N
24873	GENERIC_DAY	1	3	2010-03-01	1726	\N	19897	\N
45822	GENERIC_DAY	6	1	2010-01-18	37573	\N	41069	\N
45749	GENERIC_DAY	6	0	2010-01-16	36159	\N	41069	\N
45746	GENERIC_DAY	6	0	2010-01-19	37573	\N	41069	\N
45740	GENERIC_DAY	6	0	2010-02-06	36159	\N	41069	\N
45820	GENERIC_DAY	6	0	2010-02-10	40199	\N	41069	\N
39439	GENERIC_DAY	2	2	2010-03-19	37573	\N	38600	\N
45741	GENERIC_DAY	6	0	2010-01-28	40199	\N	41069	\N
45730	GENERIC_DAY	6	0	2010-01-22	37573	\N	41069	\N
45742	GENERIC_DAY	6	0	2010-02-07	36159	\N	41069	\N
45737	GENERIC_DAY	6	0	2010-01-29	37573	\N	41069	\N
45739	GENERIC_DAY	6	0	2010-02-09	36159	\N	41069	\N
45733	GENERIC_DAY	6	0	2010-01-21	40199	\N	41069	\N
45819	GENERIC_DAY	6	0	2010-02-03	36159	\N	41069	\N
45747	GENERIC_DAY	6	0	2010-02-04	37573	\N	41069	\N
45821	GENERIC_DAY	6	0	2010-01-12	36159	\N	41069	\N
43093	GENERIC_DAY	10	0	2010-01-24	37573	\N	41054	\N
43065	GENERIC_DAY	10	0	2010-02-11	37573	\N	41054	\N
43099	GENERIC_DAY	10	0	2010-01-12	40199	\N	41054	\N
43064	GENERIC_DAY	10	1	2010-02-03	40199	\N	41054	\N
43058	GENERIC_DAY	10	0	2010-01-11	37573	\N	41054	\N
43103	GENERIC_DAY	10	1	2010-01-12	36159	\N	41054	\N
43091	GENERIC_DAY	10	0	2010-02-10	37573	\N	41054	\N
43029	GENERIC_DAY	10	0	2010-02-08	37573	\N	41054	\N
43073	GENERIC_DAY	10	0	2010-01-21	36159	\N	41054	\N
43039	GENERIC_DAY	10	0	2010-01-19	36159	\N	41054	\N
43101	GENERIC_DAY	10	1	2010-01-26	36159	\N	41054	\N
43098	GENERIC_DAY	10	0	2010-01-31	40199	\N	41054	\N
43092	GENERIC_DAY	10	0	2010-01-17	36159	\N	41054	\N
43100	GENERIC_DAY	10	0	2010-01-20	36159	\N	41054	\N
24830	GENERIC_DAY	1	2	2010-03-15	1722	\N	19897	\N
24780	GENERIC_DAY	1	0	2010-02-13	1718	\N	19897	\N
24806	GENERIC_DAY	1	0	2010-03-14	1718	\N	19897	\N
24818	GENERIC_DAY	1	0	2010-03-06	1726	\N	19897	\N
24825	GENERIC_DAY	1	2	2010-03-18	1726	\N	19897	\N
24858	GENERIC_DAY	1	0	2010-02-20	1726	\N	19897	\N
24878	GENERIC_DAY	1	0	2010-03-27	1726	\N	19897	\N
24779	GENERIC_DAY	1	3	2010-02-19	1726	\N	19897	\N
24798	GENERIC_DAY	1	4	2010-03-19	1718	\N	19897	\N
24877	GENERIC_DAY	1	0	2010-02-14	1726	\N	19897	\N
24797	GENERIC_DAY	1	4	2010-03-22	1718	\N	19897	\N
24809	GENERIC_DAY	1	1	2010-02-22	1722	\N	19897	\N
24827	GENERIC_DAY	1	2	2010-03-25	1722	\N	19897	\N
24853	GENERIC_DAY	1	3	2010-02-15	1718	\N	19897	\N
24815	GENERIC_DAY	1	0	2010-02-27	1722	\N	19897	\N
24832	GENERIC_DAY	1	1	2010-02-23	1722	\N	19897	\N
24784	GENERIC_DAY	1	0	2010-03-29	1726	\N	19897	\N
24794	GENERIC_DAY	1	3	2010-03-15	1718	\N	19897	\N
24819	GENERIC_DAY	1	2	2010-03-19	1722	\N	19897	\N
24771	GENERIC_DAY	1	0	2010-03-20	1718	\N	19897	\N
24824	GENERIC_DAY	1	3	2010-03-02	1726	\N	19897	\N
24885	GENERIC_DAY	1	0	2010-02-21	1722	\N	19897	\N
24803	GENERIC_DAY	1	1	2010-02-25	1722	\N	19897	\N
24888	GENERIC_DAY	1	3	2010-03-09	1726	\N	19897	\N
24840	GENERIC_DAY	1	0	2010-02-20	1718	\N	19897	\N
24805	GENERIC_DAY	1	4	2010-03-03	1718	\N	19897	\N
24816	GENERIC_DAY	1	3	2010-03-15	1726	\N	19897	\N
24863	GENERIC_DAY	1	1	2010-02-15	1722	\N	19897	\N
24410	GENERIC_DAY	4	10	2009-12-04	1727	\N	3955	\N
24469	GENERIC_DAY	4	10	2009-11-16	1727	\N	3955	\N
24440	GENERIC_DAY	4	10	2010-01-06	1727	\N	3955	\N
24428	GENERIC_DAY	4	2	2010-01-23	1727	\N	3955	\N
24434	GENERIC_DAY	4	10	2010-01-07	1727	\N	3955	\N
24413	GENERIC_DAY	4	2	2009-12-19	1727	\N	3955	\N
24427	GENERIC_DAY	4	2	2009-12-20	1727	\N	3955	\N
24441	GENERIC_DAY	4	10	2009-11-17	1727	\N	3955	\N
24476	GENERIC_DAY	4	10	2010-02-12	1727	\N	3955	\N
24423	GENERIC_DAY	4	2	2010-02-06	1727	\N	3955	\N
24397	GENERIC_DAY	4	2	2010-01-02	1727	\N	3955	\N
24417	GENERIC_DAY	4	10	2009-12-31	1727	\N	3955	\N
24408	GENERIC_DAY	4	10	2009-11-05	1727	\N	3955	\N
24481	GENERIC_DAY	4	2	2009-12-05	1727	\N	3955	\N
24399	GENERIC_DAY	4	10	2010-01-20	1727	\N	3955	\N
24424	GENERIC_DAY	4	2	2010-02-20	1727	\N	3955	\N
24400	GENERIC_DAY	4	2	2010-01-31	1727	\N	3955	\N
24450	GENERIC_DAY	4	2	2010-01-09	1727	\N	3955	\N
24439	GENERIC_DAY	4	10	2010-01-05	1727	\N	3955	\N
24412	GENERIC_DAY	4	10	2009-11-20	1727	\N	3955	\N
43079	GENERIC_DAY	10	0	2010-01-25	36159	\N	41054	\N
24447	GENERIC_DAY	4	10	2010-02-10	1727	\N	3955	\N
24471	GENERIC_DAY	4	10	2010-02-08	1727	\N	3955	\N
24465	GENERIC_DAY	4	10	2009-11-18	1727	\N	3955	\N
24478	GENERIC_DAY	4	10	2009-12-07	1727	\N	3955	\N
24404	GENERIC_DAY	4	10	2009-11-11	1727	\N	3955	\N
24420	GENERIC_DAY	4	10	2009-11-10	1727	\N	3955	\N
24442	GENERIC_DAY	4	10	2010-01-21	1727	\N	3955	\N
24396	GENERIC_DAY	4	10	2009-11-30	1727	\N	3955	\N
24426	GENERIC_DAY	4	10	2009-12-23	1727	\N	3955	\N
24483	GENERIC_DAY	4	2	2009-12-13	1727	\N	3955	\N
24491	GENERIC_DAY	4	10	2010-01-22	1727	\N	3955	\N
24458	GENERIC_DAY	4	2	2009-11-14	1727	\N	3955	\N
24401	GENERIC_DAY	4	2	2009-11-15	1727	\N	3955	\N
24486	GENERIC_DAY	4	10	2009-11-09	1727	\N	3955	\N
24405	GENERIC_DAY	4	2	2009-11-22	1727	\N	3955	\N
24429	GENERIC_DAY	4	2	2009-12-26	1727	\N	3955	\N
24411	GENERIC_DAY	4	10	2009-12-21	1727	\N	3955	\N
24489	GENERIC_DAY	4	10	2009-12-01	1727	\N	3955	\N
24456	GENERIC_DAY	4	10	2010-02-05	1727	\N	3955	\N
24472	GENERIC_DAY	4	2	2010-01-10	1727	\N	3955	\N
24436	GENERIC_DAY	4	10	2009-12-28	1727	\N	3955	\N
24437	GENERIC_DAY	4	10	2009-11-04	1727	\N	3955	\N
24416	GENERIC_DAY	4	10	2009-12-09	1727	\N	3955	\N
24467	GENERIC_DAY	4	10	2010-02-02	1727	\N	3955	\N
24477	GENERIC_DAY	4	10	2009-12-14	1727	\N	3955	\N
24453	GENERIC_DAY	4	10	2010-01-13	1727	\N	3955	\N
24402	GENERIC_DAY	4	2	2009-12-27	1727	\N	3955	\N
24480	GENERIC_DAY	4	10	2009-11-25	1727	\N	3955	\N
24485	GENERIC_DAY	4	2	2009-12-06	1727	\N	3955	\N
24418	GENERIC_DAY	4	10	2009-12-11	1727	\N	3955	\N
24484	GENERIC_DAY	4	10	2009-12-24	1727	\N	3955	\N
24457	GENERIC_DAY	4	10	2009-11-12	1727	\N	3955	\N
24433	GENERIC_DAY	4	2	2009-11-29	1727	\N	3955	\N
24438	GENERIC_DAY	4	10	2010-02-19	1727	\N	3955	\N
24487	GENERIC_DAY	4	2	2010-02-14	1727	\N	3955	\N
24414	GENERIC_DAY	4	10	2010-02-17	1727	\N	3955	\N
24461	GENERIC_DAY	4	2	2010-01-03	1727	\N	3955	\N
24492	GENERIC_DAY	4	10	2009-12-29	1727	\N	3955	\N
24459	GENERIC_DAY	4	10	2010-02-01	1727	\N	3955	\N
24398	GENERIC_DAY	4	10	2009-12-03	1727	\N	3955	\N
24475	GENERIC_DAY	4	2	2009-11-28	1727	\N	3955	\N
24455	GENERIC_DAY	4	10	2010-01-28	1727	\N	3955	\N
24466	GENERIC_DAY	4	10	2009-11-26	1727	\N	3955	\N
24446	GENERIC_DAY	4	10	2009-12-08	1727	\N	3955	\N
24468	GENERIC_DAY	4	10	2010-01-27	1727	\N	3955	\N
24452	GENERIC_DAY	4	10	2010-02-04	1727	\N	3955	\N
24419	GENERIC_DAY	4	10	2010-02-24	1727	\N	3955	\N
24460	GENERIC_DAY	4	2	2010-02-07	1727	\N	3955	\N
24479	GENERIC_DAY	4	10	2009-11-06	1727	\N	3955	\N
24443	GENERIC_DAY	4	10	2010-01-08	1727	\N	3955	\N
24490	GENERIC_DAY	4	10	2010-02-16	1727	\N	3955	\N
24454	GENERIC_DAY	4	10	2009-11-27	1727	\N	3955	\N
24488	GENERIC_DAY	4	10	2010-02-15	1727	\N	3955	\N
24435	GENERIC_DAY	4	10	2010-01-26	1727	\N	3955	\N
24445	GENERIC_DAY	4	2	2009-12-25	1727	\N	3955	\N
24506	GENERIC_DAY	4	10	2009-12-16	1727	\N	3955	\N
24482	GENERIC_DAY	4	10	2010-02-22	1727	\N	3955	\N
24403	GENERIC_DAY	4	10	2010-02-26	1727	\N	3955	\N
24470	GENERIC_DAY	4	2	2010-01-16	1727	\N	3955	\N
24432	GENERIC_DAY	4	10	2010-02-09	1727	\N	3955	\N
24430	GENERIC_DAY	4	2	2009-11-08	1727	\N	3955	\N
24409	GENERIC_DAY	4	10	2010-02-18	1727	\N	3955	\N
24495	GENERIC_DAY	4	10	2010-01-15	1727	\N	3955	\N
24444	GENERIC_DAY	4	10	2009-12-30	1727	\N	3955	\N
24449	GENERIC_DAY	4	10	2009-11-23	1727	\N	3955	\N
24422	GENERIC_DAY	4	10	2010-02-03	1727	\N	3955	\N
24407	GENERIC_DAY	4	2	2010-01-30	1727	\N	3955	\N
24462	GENERIC_DAY	4	10	2010-02-23	1727	\N	3955	\N
24474	GENERIC_DAY	4	10	2010-02-25	1727	\N	3955	\N
24448	GENERIC_DAY	4	10	2009-12-02	1727	\N	3955	\N
24503	GENERIC_DAY	4	10	2009-12-22	1727	\N	3955	\N
24421	GENERIC_DAY	4	2	2010-01-17	1727	\N	3955	\N
24406	GENERIC_DAY	4	2	2010-02-13	1727	\N	3955	\N
24415	GENERIC_DAY	4	11	2009-11-02	1727	\N	3955	\N
24507	GENERIC_DAY	4	2	2010-02-21	1727	\N	3955	\N
24473	GENERIC_DAY	4	10	2009-11-13	1727	\N	3955	\N
24511	GENERIC_DAY	4	10	2010-01-12	1727	\N	3955	\N
24451	GENERIC_DAY	4	10	2009-11-24	1727	\N	3955	\N
24425	GENERIC_DAY	4	10	2010-01-04	1727	\N	3955	\N
24431	GENERIC_DAY	4	10	2009-12-18	1727	\N	3955	\N
24463	GENERIC_DAY	4	2	2010-01-24	1727	\N	3955	\N
24464	GENERIC_DAY	4	10	2010-01-29	1727	\N	3955	\N
43026	GENERIC_DAY	10	0	2010-02-09	37573	\N	41054	\N
43025	GENERIC_DAY	10	1	2010-01-15	37573	\N	41054	\N
43068	GENERIC_DAY	10	0	2010-01-13	37573	\N	41054	\N
43080	GENERIC_DAY	10	0	2010-02-07	37573	\N	41054	\N
43047	GENERIC_DAY	10	0	2010-01-14	40199	\N	41054	\N
43048	GENERIC_DAY	10	1	2010-01-29	40199	\N	41054	\N
43057	GENERIC_DAY	10	0	2010-01-15	40199	\N	41054	\N
43035	GENERIC_DAY	10	0	2010-02-01	40199	\N	41054	\N
43049	GENERIC_DAY	10	0	2010-01-18	40199	\N	41054	\N
43094	GENERIC_DAY	10	0	2010-01-24	36159	\N	41054	\N
43041	GENERIC_DAY	10	0	2010-01-27	36159	\N	41054	\N
43069	GENERIC_DAY	10	0	2010-01-17	37573	\N	41054	\N
43056	GENERIC_DAY	10	0	2010-02-06	36159	\N	41054	\N
43033	GENERIC_DAY	10	0	2010-01-20	37573	\N	41054	\N
43028	GENERIC_DAY	10	1	2010-02-08	40199	\N	41054	\N
43071	GENERIC_DAY	10	0	2010-01-16	40199	\N	41054	\N
43046	GENERIC_DAY	10	0	2010-02-01	36159	\N	41054	\N
43095	GENERIC_DAY	10	0	2010-01-28	36159	\N	41054	\N
43081	GENERIC_DAY	10	0	2010-02-09	36159	\N	41054	\N
43042	GENERIC_DAY	10	0	2010-01-26	37573	\N	41054	\N
43036	GENERIC_DAY	10	1	2010-01-22	37573	\N	41054	\N
43043	GENERIC_DAY	10	0	2010-01-26	40199	\N	41054	\N
43076	GENERIC_DAY	10	1	2010-02-04	40199	\N	41054	\N
43040	GENERIC_DAY	10	1	2010-02-02	40199	\N	41054	\N
43022	GENERIC_DAY	10	0	2010-02-10	36159	\N	41054	\N
43032	GENERIC_DAY	10	0	2010-02-04	37573	\N	41054	\N
43084	GENERIC_DAY	10	0	2010-01-14	36159	\N	41054	\N
43075	GENERIC_DAY	10	0	2010-02-11	36159	\N	41054	\N
43030	GENERIC_DAY	10	0	2010-01-29	36159	\N	41054	\N
43045	GENERIC_DAY	10	0	2010-01-27	37573	\N	41054	\N
43110	GENERIC_DAY	10	0	2010-02-06	37573	\N	41054	\N
43112	GENERIC_DAY	10	0	2010-01-16	37573	\N	41054	\N
43070	GENERIC_DAY	10	0	2010-02-03	37573	\N	41054	\N
43114	GENERIC_DAY	10	0	2010-01-30	36159	\N	41054	\N
43021	GENERIC_DAY	10	0	2010-01-28	37573	\N	41054	\N
43105	GENERIC_DAY	10	1	2010-01-14	37573	\N	41054	\N
43051	GENERIC_DAY	10	0	2010-01-13	36159	\N	41054	\N
31156	GENERIC_DAY	1	8	2010-04-06	1724	\N	28093	\N
31158	GENERIC_DAY	1	0	2010-02-06	1724	\N	28093	\N
31149	GENERIC_DAY	1	0	2010-04-04	1724	\N	28093	\N
31152	GENERIC_DAY	1	8	2010-03-16	1724	\N	28093	\N
31151	GENERIC_DAY	1	9	2010-01-19	1724	\N	28093	\N
31157	GENERIC_DAY	1	8	2010-02-26	1724	\N	28093	\N
31219	GENERIC_DAY	1	8	2010-01-29	1724	\N	28093	\N
31161	GENERIC_DAY	1	8	2010-03-12	1724	\N	28093	\N
31187	GENERIC_DAY	1	8	2010-04-05	1724	\N	28093	\N
31193	GENERIC_DAY	1	9	2010-01-26	1724	\N	28093	\N
31177	GENERIC_DAY	1	0	2010-03-07	1724	\N	28093	\N
31154	GENERIC_DAY	1	8	2010-02-18	1724	\N	28093	\N
31211	GENERIC_DAY	1	8	2010-03-05	1724	\N	28093	\N
31199	GENERIC_DAY	1	0	2010-02-27	1724	\N	28093	\N
31230	GENERIC_DAY	1	8	2010-03-25	1724	\N	28093	\N
31214	GENERIC_DAY	1	0	2010-03-13	1724	\N	28093	\N
31223	GENERIC_DAY	1	8	2010-02-05	1724	\N	28093	\N
31206	GENERIC_DAY	1	8	2010-04-08	1724	\N	28093	\N
31200	GENERIC_DAY	1	8	2010-03-26	1724	\N	28093	\N
31208	GENERIC_DAY	1	0	2010-02-07	1724	\N	28093	\N
31226	GENERIC_DAY	1	0	2010-03-06	1724	\N	28093	\N
31180	GENERIC_DAY	1	9	2010-01-27	1724	\N	28093	\N
31168	GENERIC_DAY	1	8	2010-02-22	1724	\N	28093	\N
31160	GENERIC_DAY	1	1	2010-01-16	1724	\N	28093	\N
31203	GENERIC_DAY	1	8	2010-04-02	1724	\N	28093	\N
31174	GENERIC_DAY	1	8	2010-02-09	1724	\N	28093	\N
31188	GENERIC_DAY	1	8	2010-02-17	1724	\N	28093	\N
31150	GENERIC_DAY	1	8	2010-03-19	1724	\N	28093	\N
31186	GENERIC_DAY	1	1	2010-01-23	1724	\N	28093	\N
31213	GENERIC_DAY	1	8	2010-02-16	1724	\N	28093	\N
31227	GENERIC_DAY	1	8	2010-02-24	1724	\N	28093	\N
31184	GENERIC_DAY	1	8	2010-02-03	1724	\N	28093	\N
31179	GENERIC_DAY	1	8	2010-02-10	1724	\N	28093	\N
31176	GENERIC_DAY	1	0	2010-04-03	1724	\N	28093	\N
31183	GENERIC_DAY	1	8	2010-03-11	1724	\N	28093	\N
31148	GENERIC_DAY	1	9	2010-01-25	1724	\N	28093	\N
31166	GENERIC_DAY	1	8	2010-04-01	1724	\N	28093	\N
31155	GENERIC_DAY	1	0	2010-03-28	1724	\N	28093	\N
31192	GENERIC_DAY	1	0	2010-01-30	1724	\N	28093	\N
31201	GENERIC_DAY	1	8	2010-03-02	1724	\N	28093	\N
31220	GENERIC_DAY	1	8	2010-03-22	1724	\N	28093	\N
31159	GENERIC_DAY	1	9	2010-01-20	1724	\N	28093	\N
31212	GENERIC_DAY	1	8	2010-03-30	1724	\N	28093	\N
31202	GENERIC_DAY	1	8	2010-03-10	1724	\N	28093	\N
31181	GENERIC_DAY	1	8	2010-02-12	1724	\N	28093	\N
31198	GENERIC_DAY	1	8	2010-04-12	1724	\N	28093	\N
31173	GENERIC_DAY	1	8	2010-03-01	1724	\N	28093	\N
31178	GENERIC_DAY	1	0	2010-02-14	1724	\N	28093	\N
31191	GENERIC_DAY	1	8	2010-02-25	1724	\N	28093	\N
31209	GENERIC_DAY	1	0	2010-03-20	1724	\N	28093	\N
31216	GENERIC_DAY	1	8	2010-03-24	1724	\N	28093	\N
31205	GENERIC_DAY	1	8	2010-02-23	1724	\N	28093	\N
31195	GENERIC_DAY	1	0	2010-03-21	1724	\N	28093	\N
31147	GENERIC_DAY	1	0	2010-02-21	1724	\N	28093	\N
31170	GENERIC_DAY	1	0	2010-04-10	1724	\N	28093	\N
31171	GENERIC_DAY	1	8	2010-02-04	1724	\N	28093	\N
31215	GENERIC_DAY	1	0	2010-01-31	1724	\N	28093	\N
31225	GENERIC_DAY	1	8	2010-03-31	1724	\N	28093	\N
31210	GENERIC_DAY	1	0	2010-03-14	1724	\N	28093	\N
31197	GENERIC_DAY	1	8	2010-03-18	1724	\N	28093	\N
31165	GENERIC_DAY	1	8	2010-02-11	1724	\N	28093	\N
31182	GENERIC_DAY	1	1	2010-01-17	1724	\N	28093	\N
31172	GENERIC_DAY	1	8	2010-02-02	1724	\N	28093	\N
31162	GENERIC_DAY	1	8	2010-01-28	1724	\N	28093	\N
31196	GENERIC_DAY	1	8	2010-02-19	1724	\N	28093	\N
31218	GENERIC_DAY	1	0	2010-02-13	1724	\N	28093	\N
31224	GENERIC_DAY	1	9	2010-01-21	1724	\N	28093	\N
31204	GENERIC_DAY	1	8	2010-04-07	1724	\N	28093	\N
31231	GENERIC_DAY	1	8	2010-03-03	1724	\N	28093	\N
31190	GENERIC_DAY	1	8	2010-03-23	1724	\N	28093	\N
31222	GENERIC_DAY	1	0	2010-04-11	1724	\N	28093	\N
31228	GENERIC_DAY	1	8	2010-02-15	1724	\N	28093	\N
31153	GENERIC_DAY	1	8	2010-02-08	1724	\N	28093	\N
31164	GENERIC_DAY	1	1	2010-01-24	1724	\N	28093	\N
39440	GENERIC_DAY	1	0	2010-02-11	37573	\N	38601	\N
39441	GENERIC_DAY	1	0	2010-03-19	36159	\N	38601	\N
39442	GENERIC_DAY	1	0	2010-03-07	36159	\N	38601	\N
39443	GENERIC_DAY	1	0	2010-02-22	36159	\N	38601	\N
43053	GENERIC_DAY	10	0	2010-02-04	36159	\N	41054	\N
43031	GENERIC_DAY	10	0	2010-01-12	37573	\N	41054	\N
43024	GENERIC_DAY	10	0	2010-01-30	40199	\N	41054	\N
43060	GENERIC_DAY	10	1	2010-02-01	37573	\N	41054	\N
43059	GENERIC_DAY	10	1	2010-01-18	36159	\N	41054	\N
43090	GENERIC_DAY	10	0	2010-01-16	36159	\N	41054	\N
43037	GENERIC_DAY	10	0	2010-02-08	36159	\N	41054	\N
43085	GENERIC_DAY	10	1	2010-02-05	40199	\N	41054	\N
43066	GENERIC_DAY	10	0	2010-01-24	40199	\N	41054	\N
43034	GENERIC_DAY	10	0	2010-02-03	36159	\N	41054	\N
43054	GENERIC_DAY	10	0	2010-02-11	40199	\N	41054	\N
43097	GENERIC_DAY	10	0	2010-02-09	40199	\N	41054	\N
43038	GENERIC_DAY	10	0	2010-02-05	37573	\N	41054	\N
43027	GENERIC_DAY	10	0	2010-01-23	40199	\N	41054	\N
43096	GENERIC_DAY	10	0	2010-01-23	37573	\N	41054	\N
43023	GENERIC_DAY	10	0	2010-01-23	36159	\N	41054	\N
43067	GENERIC_DAY	10	1	2010-01-25	40199	\N	41054	\N
43083	GENERIC_DAY	10	0	2010-01-21	40199	\N	41054	\N
43102	GENERIC_DAY	10	1	2010-01-13	40199	\N	41054	\N
43044	GENERIC_DAY	10	0	2010-02-05	36159	\N	41054	\N
27210	GENERIC_DAY	1	3	2009-12-07	1726	\N	3940	\N
27211	GENERIC_DAY	1	2	2009-12-18	1726	\N	3940	\N
27212	GENERIC_DAY	1	3	2009-12-14	1722	\N	3940	\N
27213	GENERIC_DAY	1	3	2009-12-09	1726	\N	3940	\N
27214	GENERIC_DAY	1	0	2009-12-12	1718	\N	3940	\N
27215	GENERIC_DAY	1	0	2009-12-19	1718	\N	3940	\N
27216	GENERIC_DAY	1	2	2009-12-22	1718	\N	3940	\N
27217	GENERIC_DAY	1	4	2009-12-18	1722	\N	3940	\N
27218	GENERIC_DAY	1	2	2009-12-17	1722	\N	3940	\N
27219	GENERIC_DAY	1	0	2009-12-19	1722	\N	3940	\N
27220	GENERIC_DAY	1	3	2009-12-15	1726	\N	3940	\N
27221	GENERIC_DAY	1	0	2009-12-13	1722	\N	3940	\N
27222	GENERIC_DAY	1	2	2009-12-11	1718	\N	3940	\N
27223	GENERIC_DAY	1	3	2009-12-14	1726	\N	3940	\N
27224	GENERIC_DAY	1	3	2009-12-21	1722	\N	3940	\N
27225	GENERIC_DAY	1	2	2009-12-23	1722	\N	3940	\N
27226	GENERIC_DAY	1	0	2009-12-12	1726	\N	3940	\N
27227	GENERIC_DAY	1	2	2009-12-09	1722	\N	3940	\N
27228	GENERIC_DAY	1	3	2009-12-17	1718	\N	3940	\N
27229	GENERIC_DAY	1	0	2009-12-20	1722	\N	3940	\N
27230	GENERIC_DAY	1	2	2009-12-16	1718	\N	3940	\N
27231	GENERIC_DAY	1	3	2009-12-17	1726	\N	3940	\N
27232	GENERIC_DAY	1	2	2009-12-10	1718	\N	3940	\N
27233	GENERIC_DAY	1	2	2009-12-07	1718	\N	3940	\N
27234	GENERIC_DAY	1	2	2009-12-15	1718	\N	3940	\N
27235	GENERIC_DAY	1	0	2009-12-20	1726	\N	3940	\N
27236	GENERIC_DAY	1	2	2009-12-21	1718	\N	3940	\N
27237	GENERIC_DAY	1	2	2009-12-18	1718	\N	3940	\N
27238	GENERIC_DAY	1	3	2009-12-07	1722	\N	3940	\N
27239	GENERIC_DAY	1	3	2009-12-22	1722	\N	3940	\N
27240	GENERIC_DAY	1	3	2009-12-10	1722	\N	3940	\N
27241	GENERIC_DAY	1	3	2009-12-11	1722	\N	3940	\N
27242	GENERIC_DAY	1	0	2009-12-20	1718	\N	3940	\N
27243	GENERIC_DAY	1	0	2009-12-19	1726	\N	3940	\N
27244	GENERIC_DAY	1	3	2009-12-22	1726	\N	3940	\N
27245	GENERIC_DAY	1	3	2009-12-11	1726	\N	3940	\N
27246	GENERIC_DAY	1	2	2009-12-14	1718	\N	3940	\N
27247	GENERIC_DAY	1	1	2009-12-23	1718	\N	3940	\N
27248	GENERIC_DAY	1	0	2009-12-13	1726	\N	3940	\N
27249	GENERIC_DAY	1	3	2009-12-21	1726	\N	3940	\N
27250	GENERIC_DAY	1	3	2009-12-16	1722	\N	3940	\N
27251	GENERIC_DAY	1	0	2009-12-12	1722	\N	3940	\N
27252	GENERIC_DAY	1	3	2009-12-08	1726	\N	3940	\N
27253	GENERIC_DAY	1	3	2009-12-15	1722	\N	3940	\N
27254	GENERIC_DAY	1	0	2010-01-02	1718	\N	19901	\N
27255	GENERIC_DAY	1	0	2010-01-31	1718	\N	19901	\N
27256	GENERIC_DAY	1	3	2010-01-27	1718	\N	19901	\N
27257	GENERIC_DAY	1	3	2010-02-12	1722	\N	19901	\N
27258	GENERIC_DAY	1	3	2010-01-19	1718	\N	19901	\N
27259	GENERIC_DAY	1	3	2010-01-22	1726	\N	19901	\N
27260	GENERIC_DAY	1	0	2010-01-31	1722	\N	19901	\N
27261	GENERIC_DAY	1	3	2010-02-09	1726	\N	19901	\N
27262	GENERIC_DAY	1	3	2010-01-22	1718	\N	19901	\N
27263	GENERIC_DAY	1	1	2010-02-10	1722	\N	19901	\N
27264	GENERIC_DAY	1	2	2010-01-26	1718	\N	19901	\N
27265	GENERIC_DAY	1	3	2010-01-07	1718	\N	19901	\N
27266	GENERIC_DAY	1	4	2010-01-13	1718	\N	19901	\N
27267	GENERIC_DAY	1	2	2010-01-18	1722	\N	19901	\N
27268	GENERIC_DAY	1	0	2010-02-07	1718	\N	19901	\N
27269	GENERIC_DAY	1	2	2010-01-28	1722	\N	19901	\N
27270	GENERIC_DAY	1	3	2010-01-26	1726	\N	19901	\N
27271	GENERIC_DAY	1	1	2010-02-17	1718	\N	19901	\N
27272	GENERIC_DAY	1	2	2010-01-14	1722	\N	19901	\N
27273	GENERIC_DAY	1	3	2010-01-04	1718	\N	19901	\N
27274	GENERIC_DAY	1	3	2010-01-29	1718	\N	19901	\N
27275	GENERIC_DAY	1	0	2010-01-03	1726	\N	19901	\N
27276	GENERIC_DAY	1	2	2010-01-11	1722	\N	19901	\N
27277	GENERIC_DAY	1	2	2010-02-17	1726	\N	19901	\N
27278	GENERIC_DAY	1	0	2010-02-06	1726	\N	19901	\N
27279	GENERIC_DAY	1	4	2010-01-11	1718	\N	19901	\N
27280	GENERIC_DAY	1	3	2010-01-07	1726	\N	19901	\N
27281	GENERIC_DAY	1	3	2009-12-28	1726	\N	19901	\N
27282	GENERIC_DAY	1	3	2010-02-01	1726	\N	19901	\N
27283	GENERIC_DAY	1	3	2010-02-15	1726	\N	19901	\N
27284	GENERIC_DAY	1	3	2010-01-21	1726	\N	19901	\N
27285	GENERIC_DAY	1	2	2009-12-28	1718	\N	19901	\N
27286	GENERIC_DAY	1	1	2010-02-08	1722	\N	19901	\N
27287	GENERIC_DAY	1	0	2010-02-07	1726	\N	19901	\N
27288	GENERIC_DAY	1	2	2009-12-29	1718	\N	19901	\N
27289	GENERIC_DAY	1	3	2010-02-11	1726	\N	19901	\N
27290	GENERIC_DAY	1	2	2010-02-16	1718	\N	19901	\N
27291	GENERIC_DAY	1	3	2010-01-15	1718	\N	19901	\N
27292	GENERIC_DAY	1	2	2010-01-05	1718	\N	19901	\N
27293	GENERIC_DAY	1	3	2010-01-25	1726	\N	19901	\N
27294	GENERIC_DAY	1	3	2010-02-16	1722	\N	19901	\N
27295	GENERIC_DAY	1	3	2010-02-03	1726	\N	19901	\N
27296	GENERIC_DAY	1	4	2010-02-11	1718	\N	19901	\N
27297	GENERIC_DAY	1	3	2009-12-31	1722	\N	19901	\N
27298	GENERIC_DAY	1	3	2010-02-08	1726	\N	19901	\N
25510	GENERIC_DAY	3	7	2010-04-22	7272	\N	24143	\N
25511	GENERIC_DAY	3	0	2010-03-14	7272	\N	24143	\N
25512	GENERIC_DAY	3	7	2010-03-19	7272	\N	24143	\N
27299	GENERIC_DAY	1	2	2010-01-21	1722	\N	19901	\N
27300	GENERIC_DAY	1	0	2010-01-17	1726	\N	19901	\N
27301	GENERIC_DAY	1	0	2010-01-03	1722	\N	19901	\N
25513	GENERIC_DAY	3	0	2010-04-11	7272	\N	24143	\N
25514	GENERIC_DAY	3	0	2010-04-04	7272	\N	24143	\N
25515	GENERIC_DAY	3	0	2010-04-17	7272	\N	24143	\N
25516	GENERIC_DAY	3	7	2010-03-24	7272	\N	24143	\N
25517	GENERIC_DAY	3	7	2010-03-29	7272	\N	24143	\N
25518	GENERIC_DAY	3	0	2010-04-03	7272	\N	24143	\N
25519	GENERIC_DAY	3	0	2010-02-28	7272	\N	24143	\N
25520	GENERIC_DAY	3	7	2010-03-03	7272	\N	24143	\N
25521	GENERIC_DAY	3	7	2010-04-16	7272	\N	24143	\N
25522	GENERIC_DAY	3	7	2010-04-07	7272	\N	24143	\N
25523	GENERIC_DAY	3	0	2010-03-21	7272	\N	24143	\N
15942	GENERIC_DAY	0	2	2010-04-22	1722	\N	3984	\N
15943	GENERIC_DAY	0	2	2010-04-16	1722	\N	3984	\N
15944	GENERIC_DAY	0	2	2010-04-18	1726	\N	3984	\N
15945	GENERIC_DAY	0	2	2010-04-11	1726	\N	3984	\N
15946	GENERIC_DAY	0	1	2010-04-17	1718	\N	3984	\N
15947	GENERIC_DAY	0	2	2010-04-10	1722	\N	3984	\N
15948	GENERIC_DAY	0	2	2010-04-06	1722	\N	3984	\N
15949	GENERIC_DAY	0	2	2010-04-18	1722	\N	3984	\N
15950	GENERIC_DAY	0	2	2010-04-11	1718	\N	3984	\N
15951	GENERIC_DAY	0	2	2010-04-14	1726	\N	3984	\N
15952	GENERIC_DAY	0	2	2010-04-10	1726	\N	3984	\N
15953	GENERIC_DAY	0	1	2010-04-22	1718	\N	3984	\N
15954	GENERIC_DAY	0	2	2010-04-17	1726	\N	3984	\N
15955	GENERIC_DAY	0	2	2010-04-09	1718	\N	3984	\N
15956	GENERIC_DAY	0	2	2010-04-17	1722	\N	3984	\N
15957	GENERIC_DAY	0	2	2010-04-20	1722	\N	3984	\N
15958	GENERIC_DAY	0	1	2010-04-19	1718	\N	3984	\N
15959	GENERIC_DAY	0	2	2010-04-22	1726	\N	3984	\N
15960	GENERIC_DAY	0	2	2010-04-14	1722	\N	3984	\N
15961	GENERIC_DAY	0	2	2010-04-13	1726	\N	3984	\N
15962	GENERIC_DAY	0	2	2010-04-07	1722	\N	3984	\N
15963	GENERIC_DAY	0	2	2010-04-15	1722	\N	3984	\N
15964	GENERIC_DAY	0	2	2010-04-06	1726	\N	3984	\N
15965	GENERIC_DAY	0	1	2010-04-18	1718	\N	3984	\N
15966	GENERIC_DAY	0	1	2010-04-16	1718	\N	3984	\N
15967	GENERIC_DAY	0	2	2010-04-06	1718	\N	3984	\N
15968	GENERIC_DAY	0	1	2010-04-20	1718	\N	3984	\N
15969	GENERIC_DAY	0	2	2010-04-05	1722	\N	3984	\N
15970	GENERIC_DAY	0	2	2010-04-13	1722	\N	3984	\N
15971	GENERIC_DAY	0	2	2010-04-08	1718	\N	3984	\N
15972	GENERIC_DAY	0	2	2010-04-10	1718	\N	3984	\N
15973	GENERIC_DAY	0	2	2010-04-16	1726	\N	3984	\N
15974	GENERIC_DAY	0	1	2010-04-21	1718	\N	3984	\N
15975	GENERIC_DAY	0	2	2010-04-11	1722	\N	3984	\N
15976	GENERIC_DAY	0	2	2010-04-15	1726	\N	3984	\N
15977	GENERIC_DAY	0	2	2010-04-12	1718	\N	3984	\N
15978	GENERIC_DAY	0	2	2010-04-19	1722	\N	3984	\N
15979	GENERIC_DAY	0	2	2010-04-12	1726	\N	3984	\N
15980	GENERIC_DAY	0	2	2010-04-05	1726	\N	3984	\N
15981	GENERIC_DAY	0	2	2010-04-20	1726	\N	3984	\N
15982	GENERIC_DAY	0	2	2010-04-19	1726	\N	3984	\N
15983	GENERIC_DAY	0	2	2010-04-21	1722	\N	3984	\N
15984	GENERIC_DAY	0	2	2010-04-21	1726	\N	3984	\N
15985	GENERIC_DAY	0	2	2010-04-09	1722	\N	3984	\N
15986	GENERIC_DAY	0	2	2010-04-14	1718	\N	3984	\N
15987	GENERIC_DAY	0	2	2010-04-07	1718	\N	3984	\N
15988	GENERIC_DAY	0	2	2010-04-13	1718	\N	3984	\N
15989	GENERIC_DAY	0	2	2010-04-12	1722	\N	3984	\N
15990	GENERIC_DAY	0	2	2010-04-09	1726	\N	3984	\N
15991	GENERIC_DAY	0	2	2010-04-05	1718	\N	3984	\N
15992	GENERIC_DAY	0	2	2010-04-08	1722	\N	3984	\N
15993	GENERIC_DAY	0	2	2010-04-07	1726	\N	3984	\N
15994	GENERIC_DAY	0	2	2010-04-08	1726	\N	3984	\N
15995	GENERIC_DAY	0	1	2010-04-15	1718	\N	3984	\N
25524	GENERIC_DAY	3	7	2010-04-23	7272	\N	24143	\N
25525	GENERIC_DAY	3	7	2010-03-11	7272	\N	24143	\N
25526	GENERIC_DAY	3	7	2010-03-02	7272	\N	24143	\N
25527	GENERIC_DAY	3	7	2010-04-14	7272	\N	24143	\N
25528	GENERIC_DAY	3	7	2010-03-10	7272	\N	24143	\N
25529	GENERIC_DAY	3	7	2010-03-16	7272	\N	24143	\N
25530	GENERIC_DAY	3	0	2010-03-28	7272	\N	24143	\N
25531	GENERIC_DAY	3	7	2010-03-22	7272	\N	24143	\N
25532	GENERIC_DAY	3	7	2010-03-05	7272	\N	24143	\N
25533	GENERIC_DAY	3	7	2010-04-05	7272	\N	24143	\N
25534	GENERIC_DAY	3	7	2010-04-12	7272	\N	24143	\N
25535	GENERIC_DAY	3	7	2010-04-27	7272	\N	24143	\N
25536	GENERIC_DAY	3	7	2010-03-26	7272	\N	24143	\N
25537	GENERIC_DAY	3	7	2010-03-25	7272	\N	24143	\N
25538	GENERIC_DAY	3	0	2010-03-07	7272	\N	24143	\N
25539	GENERIC_DAY	3	0	2010-03-20	7272	\N	24143	\N
25540	GENERIC_DAY	3	7	2010-04-06	7272	\N	24143	\N
25541	GENERIC_DAY	3	7	2010-03-09	7272	\N	24143	\N
25542	GENERIC_DAY	3	7	2010-04-26	7272	\N	24143	\N
25543	GENERIC_DAY	3	7	2010-04-15	7272	\N	24143	\N
25544	GENERIC_DAY	3	7	2010-03-23	7272	\N	24143	\N
25545	GENERIC_DAY	3	0	2010-04-25	7272	\N	24143	\N
25546	GENERIC_DAY	3	7	2010-04-21	7272	\N	24143	\N
25547	GENERIC_DAY	3	0	2010-03-13	7272	\N	24143	\N
25548	GENERIC_DAY	3	7	2010-04-08	7272	\N	24143	\N
25549	GENERIC_DAY	3	0	2010-04-18	7272	\N	24143	\N
25550	GENERIC_DAY	3	7	2010-03-15	7272	\N	24143	\N
25551	GENERIC_DAY	3	7	2010-04-19	7272	\N	24143	\N
25552	GENERIC_DAY	3	7	2010-03-04	7272	\N	24143	\N
25553	GENERIC_DAY	3	7	2010-04-13	7272	\N	24143	\N
25554	GENERIC_DAY	3	7	2010-03-30	7272	\N	24143	\N
25555	GENERIC_DAY	3	7	2010-04-02	7272	\N	24143	\N
25556	GENERIC_DAY	3	7	2010-03-18	7272	\N	24143	\N
25557	GENERIC_DAY	3	7	2010-03-31	7272	\N	24143	\N
25558	GENERIC_DAY	3	7	2010-03-08	7272	\N	24143	\N
25559	GENERIC_DAY	3	6	2010-04-28	7272	\N	24143	\N
25560	GENERIC_DAY	3	7	2010-04-01	7272	\N	24143	\N
25561	GENERIC_DAY	3	0	2010-02-27	7272	\N	24143	\N
16035	GENERIC_DAY	0	2	2010-03-04	1726	\N	8589	\N
16036	GENERIC_DAY	0	4	2010-02-15	1722	\N	8589	\N
16037	GENERIC_DAY	0	2	2010-02-10	1726	\N	8589	\N
16038	GENERIC_DAY	0	3	2010-03-19	1722	\N	8589	\N
16039	GENERIC_DAY	0	3	2010-03-13	1722	\N	8589	\N
16040	GENERIC_DAY	0	2	2010-02-22	1726	\N	8589	\N
16041	GENERIC_DAY	0	3	2010-03-15	1722	\N	8589	\N
16042	GENERIC_DAY	0	3	2010-03-20	1722	\N	8589	\N
16043	GENERIC_DAY	0	3	2010-03-16	1722	\N	8589	\N
16044	GENERIC_DAY	0	3	2010-03-24	1726	\N	8589	\N
16045	GENERIC_DAY	0	3	2010-03-10	1722	\N	8589	\N
16046	GENERIC_DAY	0	2	2010-03-09	1726	\N	8589	\N
16047	GENERIC_DAY	0	2	2010-03-08	1726	\N	8589	\N
16048	GENERIC_DAY	0	4	2010-02-22	1722	\N	8589	\N
16049	GENERIC_DAY	0	3	2010-03-07	1722	\N	8589	\N
16050	GENERIC_DAY	0	2	2010-03-05	1726	\N	8589	\N
16051	GENERIC_DAY	0	3	2010-02-18	1718	\N	8589	\N
16052	GENERIC_DAY	0	5	2010-02-14	1722	\N	8589	\N
16053	GENERIC_DAY	0	2	2010-02-26	1726	\N	8589	\N
16054	GENERIC_DAY	0	2	2010-02-13	1726	\N	8589	\N
16055	GENERIC_DAY	0	4	2010-02-19	1722	\N	8589	\N
16056	GENERIC_DAY	0	2	2010-03-03	1726	\N	8589	\N
16057	GENERIC_DAY	0	2	2010-02-19	1718	\N	8589	\N
16058	GENERIC_DAY	0	2	2010-02-25	1718	\N	8589	\N
16059	GENERIC_DAY	0	2	2010-02-21	1718	\N	8589	\N
16060	GENERIC_DAY	0	2	2010-02-24	1718	\N	8589	\N
16061	GENERIC_DAY	0	2	2010-03-17	1726	\N	8589	\N
16062	GENERIC_DAY	0	2	2010-02-11	1718	\N	8589	\N
16063	GENERIC_DAY	0	2	2010-03-24	1718	\N	8589	\N
16064	GENERIC_DAY	0	2	2010-02-13	1718	\N	8589	\N
16065	GENERIC_DAY	0	3	2010-03-06	1718	\N	8589	\N
16066	GENERIC_DAY	0	4	2010-03-02	1722	\N	8589	\N
16067	GENERIC_DAY	0	2	2010-03-25	1718	\N	8589	\N
16068	GENERIC_DAY	0	2	2010-03-14	1726	\N	8589	\N
16069	GENERIC_DAY	0	3	2010-03-23	1726	\N	8589	\N
16070	GENERIC_DAY	0	3	2010-03-05	1722	\N	8589	\N
16071	GENERIC_DAY	0	3	2010-03-20	1726	\N	8589	\N
16072	GENERIC_DAY	0	3	2010-03-11	1722	\N	8589	\N
16073	GENERIC_DAY	0	2	2010-02-25	1726	\N	8589	\N
16074	GENERIC_DAY	0	3	2010-03-14	1718	\N	8589	\N
16075	GENERIC_DAY	0	4	2010-02-13	1722	\N	8589	\N
16076	GENERIC_DAY	0	4	2010-02-08	1722	\N	8589	\N
16077	GENERIC_DAY	0	1	2010-02-14	1726	\N	8589	\N
16078	GENERIC_DAY	0	4	2010-02-28	1722	\N	8589	\N
16079	GENERIC_DAY	0	4	2010-02-26	1722	\N	8589	\N
16080	GENERIC_DAY	0	2	2010-02-09	1718	\N	8589	\N
16081	GENERIC_DAY	0	4	2010-02-25	1722	\N	8589	\N
16082	GENERIC_DAY	0	1	2010-02-18	1726	\N	8589	\N
16083	GENERIC_DAY	0	3	2010-03-16	1718	\N	8589	\N
16084	GENERIC_DAY	0	3	2010-03-05	1718	\N	8589	\N
16085	GENERIC_DAY	0	1	2010-02-16	1726	\N	8589	\N
16086	GENERIC_DAY	0	2	2010-02-27	1726	\N	8589	\N
16087	GENERIC_DAY	0	3	2010-03-04	1722	\N	8589	\N
16088	GENERIC_DAY	0	2	2010-02-23	1726	\N	8589	\N
16089	GENERIC_DAY	0	2	2010-03-12	1726	\N	8589	\N
16090	GENERIC_DAY	0	3	2010-03-17	1718	\N	8589	\N
16091	GENERIC_DAY	0	3	2010-03-13	1718	\N	8589	\N
16092	GENERIC_DAY	0	2	2010-02-08	1718	\N	8589	\N
16093	GENERIC_DAY	0	4	2010-02-21	1722	\N	8589	\N
16094	GENERIC_DAY	0	2	2010-02-19	1726	\N	8589	\N
16095	GENERIC_DAY	0	2	2010-02-26	1718	\N	8589	\N
16096	GENERIC_DAY	0	4	2010-02-18	1722	\N	8589	\N
16097	GENERIC_DAY	0	2	2010-02-11	1726	\N	8589	\N
16098	GENERIC_DAY	0	2	2010-02-09	1726	\N	8589	\N
16099	GENERIC_DAY	0	3	2010-03-14	1722	\N	8589	\N
16100	GENERIC_DAY	0	1	2010-02-17	1726	\N	8589	\N
16101	GENERIC_DAY	0	2	2010-02-12	1718	\N	8589	\N
16102	GENERIC_DAY	0	2	2010-03-11	1726	\N	8589	\N
16103	GENERIC_DAY	0	3	2010-03-24	1722	\N	8589	\N
16104	GENERIC_DAY	0	4	2010-02-12	1722	\N	8589	\N
16105	GENERIC_DAY	0	2	2010-02-07	1726	\N	8589	\N
16106	GENERIC_DAY	0	3	2010-03-15	1718	\N	8589	\N
16107	GENERIC_DAY	0	4	2010-02-11	1722	\N	8589	\N
16108	GENERIC_DAY	0	2	2010-03-15	1726	\N	8589	\N
16109	GENERIC_DAY	0	2	2010-03-19	1718	\N	8589	\N
16110	GENERIC_DAY	0	2	2010-03-03	1718	\N	8589	\N
16111	GENERIC_DAY	0	4	2010-02-20	1722	\N	8589	\N
16112	GENERIC_DAY	0	2	2010-02-20	1726	\N	8589	\N
16113	GENERIC_DAY	0	2	2010-02-07	1718	\N	8589	\N
16114	GENERIC_DAY	0	3	2010-03-06	1722	\N	8589	\N
16115	GENERIC_DAY	0	4	2010-02-24	1722	\N	8589	\N
16116	GENERIC_DAY	0	2	2010-02-10	1718	\N	8589	\N
16117	GENERIC_DAY	0	3	2010-03-18	1726	\N	8589	\N
16118	GENERIC_DAY	0	3	2010-03-08	1722	\N	8589	\N
16119	GENERIC_DAY	0	4	2010-02-09	1722	\N	8589	\N
16120	GENERIC_DAY	0	3	2010-03-27	1726	\N	8589	\N
16121	GENERIC_DAY	0	3	2010-03-11	1718	\N	8589	\N
16122	GENERIC_DAY	0	3	2010-03-23	1722	\N	8589	\N
16123	GENERIC_DAY	0	2	2010-03-21	1718	\N	8589	\N
25562	GENERIC_DAY	3	7	2010-04-09	7272	\N	24143	\N
25563	GENERIC_DAY	3	0	2010-03-06	7272	\N	24143	\N
25564	GENERIC_DAY	3	7	2010-03-01	7272	\N	24143	\N
25565	GENERIC_DAY	3	7	2010-03-17	7272	\N	24143	\N
25566	GENERIC_DAY	3	7	2010-04-20	7272	\N	24143	\N
25567	GENERIC_DAY	3	0	2010-03-27	7272	\N	24143	\N
25568	GENERIC_DAY	3	7	2010-03-12	7272	\N	24143	\N
25569	GENERIC_DAY	3	0	2010-04-24	7272	\N	24143	\N
25570	GENERIC_DAY	3	0	2010-04-10	7272	\N	24143	\N
27302	GENERIC_DAY	1	2	2010-01-15	1722	\N	19901	\N
27303	GENERIC_DAY	1	0	2009-12-26	1718	\N	19901	\N
27304	GENERIC_DAY	1	0	2010-02-14	1718	\N	19901	\N
27305	GENERIC_DAY	1	2	2010-02-05	1722	\N	19901	\N
16124	GENERIC_DAY	0	2	2010-03-18	1722	\N	8589	\N
16125	GENERIC_DAY	0	3	2010-03-25	1726	\N	8589	\N
16126	GENERIC_DAY	0	2	2010-03-06	1726	\N	8589	\N
16127	GENERIC_DAY	0	2	2010-03-02	1726	\N	8589	\N
16128	GENERIC_DAY	0	2	2010-03-27	1718	\N	8589	\N
16129	GENERIC_DAY	0	4	2010-02-17	1722	\N	8589	\N
16130	GENERIC_DAY	0	4	2010-02-10	1722	\N	8589	\N
16131	GENERIC_DAY	0	2	2010-02-23	1718	\N	8589	\N
16132	GENERIC_DAY	0	2	2010-02-22	1718	\N	8589	\N
16133	GENERIC_DAY	0	3	2010-03-17	1722	\N	8589	\N
16134	GENERIC_DAY	0	3	2010-03-28	1726	\N	8589	\N
16135	GENERIC_DAY	0	2	2010-03-23	1718	\N	8589	\N
16136	GENERIC_DAY	0	3	2010-03-27	1722	\N	8589	\N
16137	GENERIC_DAY	0	1	2010-02-15	1726	\N	8589	\N
16138	GENERIC_DAY	0	3	2010-03-10	1718	\N	8589	\N
16139	GENERIC_DAY	0	4	2010-02-16	1722	\N	8589	\N
16140	GENERIC_DAY	0	2	2010-03-10	1726	\N	8589	\N
16141	GENERIC_DAY	0	4	2010-03-03	1722	\N	8589	\N
16142	GENERIC_DAY	0	3	2010-03-08	1718	\N	8589	\N
16143	GENERIC_DAY	0	2	2010-03-01	1726	\N	8589	\N
16144	GENERIC_DAY	0	2	2010-03-13	1726	\N	8589	\N
16145	GENERIC_DAY	0	3	2010-03-07	1718	\N	8589	\N
16146	GENERIC_DAY	0	2	2010-02-14	1718	\N	8589	\N
16147	GENERIC_DAY	0	2	2010-03-22	1718	\N	8589	\N
16148	GENERIC_DAY	0	2	2010-03-26	1718	\N	8589	\N
16149	GENERIC_DAY	0	3	2010-03-28	1722	\N	8589	\N
16150	GENERIC_DAY	0	3	2010-03-21	1726	\N	8589	\N
16151	GENERIC_DAY	0	3	2010-03-09	1722	\N	8589	\N
16152	GENERIC_DAY	0	3	2010-03-12	1722	\N	8589	\N
16153	GENERIC_DAY	0	4	2010-03-01	1722	\N	8589	\N
16154	GENERIC_DAY	0	2	2010-02-21	1726	\N	8589	\N
16155	GENERIC_DAY	0	3	2010-03-21	1722	\N	8589	\N
16156	GENERIC_DAY	0	2	2010-02-20	1718	\N	8589	\N
16157	GENERIC_DAY	0	2	2010-03-01	1718	\N	8589	\N
16158	GENERIC_DAY	0	3	2010-03-26	1726	\N	8589	\N
16159	GENERIC_DAY	0	3	2010-03-22	1722	\N	8589	\N
16160	GENERIC_DAY	0	3	2010-03-25	1722	\N	8589	\N
16161	GENERIC_DAY	0	3	2010-02-15	1718	\N	8589	\N
16162	GENERIC_DAY	0	3	2010-03-18	1718	\N	8589	\N
16163	GENERIC_DAY	0	3	2010-03-04	1718	\N	8589	\N
16164	GENERIC_DAY	0	4	2010-02-27	1722	\N	8589	\N
16165	GENERIC_DAY	0	2	2010-03-28	1718	\N	8589	\N
16166	GENERIC_DAY	0	2	2010-02-28	1726	\N	8589	\N
16167	GENERIC_DAY	0	4	2010-02-23	1722	\N	8589	\N
16168	GENERIC_DAY	0	3	2010-03-09	1718	\N	8589	\N
16169	GENERIC_DAY	0	4	2010-02-07	1722	\N	8589	\N
16170	GENERIC_DAY	0	3	2010-03-12	1718	\N	8589	\N
16171	GENERIC_DAY	0	2	2010-03-16	1726	\N	8589	\N
16172	GENERIC_DAY	0	3	2010-03-26	1722	\N	8589	\N
16173	GENERIC_DAY	0	3	2010-03-22	1726	\N	8589	\N
16174	GENERIC_DAY	0	3	2010-02-16	1718	\N	8589	\N
16175	GENERIC_DAY	0	2	2010-02-27	1718	\N	8589	\N
16176	GENERIC_DAY	0	2	2010-02-12	1726	\N	8589	\N
16177	GENERIC_DAY	0	2	2010-03-20	1718	\N	8589	\N
16178	GENERIC_DAY	0	2	2010-02-28	1718	\N	8589	\N
16179	GENERIC_DAY	0	2	2010-02-08	1726	\N	8589	\N
16180	GENERIC_DAY	0	2	2010-02-24	1726	\N	8589	\N
16181	GENERIC_DAY	0	3	2010-02-17	1718	\N	8589	\N
16182	GENERIC_DAY	0	2	2010-03-07	1726	\N	8589	\N
16183	GENERIC_DAY	0	2	2010-03-02	1718	\N	8589	\N
16184	GENERIC_DAY	0	3	2010-03-19	1726	\N	8589	\N
16185	GENERIC_DAY	0	8	2010-04-22	1720	\N	8588	\N
16186	GENERIC_DAY	0	8	2010-04-12	1720	\N	8588	\N
16187	GENERIC_DAY	0	8	2010-04-19	1720	\N	8588	\N
16188	GENERIC_DAY	0	8	2010-04-15	1720	\N	8588	\N
16189	GENERIC_DAY	0	8	2010-04-21	1720	\N	8588	\N
16190	GENERIC_DAY	0	8	2010-04-11	1720	\N	8588	\N
16191	GENERIC_DAY	0	8	2010-04-14	1720	\N	8588	\N
16192	GENERIC_DAY	0	8	2010-04-16	1720	\N	8588	\N
16193	GENERIC_DAY	0	8	2010-04-18	1720	\N	8588	\N
16194	GENERIC_DAY	0	4	2010-04-23	1720	\N	8588	\N
16195	GENERIC_DAY	0	8	2010-04-17	1720	\N	8588	\N
27306	GENERIC_DAY	1	0	2009-12-25	1718	\N	19901	\N
27307	GENERIC_DAY	1	3	2010-02-04	1726	\N	19901	\N
27308	GENERIC_DAY	1	3	2010-02-16	1726	\N	19901	\N
27309	GENERIC_DAY	1	0	2009-12-26	1726	\N	19901	\N
27310	GENERIC_DAY	1	0	2009-12-25	1726	\N	19901	\N
27311	GENERIC_DAY	1	0	2010-01-02	1722	\N	19901	\N
27312	GENERIC_DAY	1	3	2009-12-29	1726	\N	19901	\N
27313	GENERIC_DAY	1	0	2010-01-16	1726	\N	19901	\N
27314	GENERIC_DAY	1	0	2010-01-30	1718	\N	19901	\N
27315	GENERIC_DAY	1	0	2010-01-01	1726	\N	19901	\N
27316	GENERIC_DAY	1	0	2010-01-30	1726	\N	19901	\N
20789	GENERIC_DAY	1	8	2010-03-02	1724	\N	6367	\N
20788	GENERIC_DAY	1	8	2010-03-08	1724	\N	6367	\N
20790	GENERIC_DAY	1	8	2010-03-05	1724	\N	6367	\N
27317	GENERIC_DAY	1	3	2009-12-29	1722	\N	19901	\N
27318	GENERIC_DAY	1	0	2010-02-13	1722	\N	19901	\N
27319	GENERIC_DAY	1	3	2009-12-31	1726	\N	19901	\N
27320	GENERIC_DAY	1	3	2010-01-29	1726	\N	19901	\N
27321	GENERIC_DAY	1	3	2010-01-20	1718	\N	19901	\N
27322	GENERIC_DAY	1	0	2010-02-06	1718	\N	19901	\N
27323	GENERIC_DAY	1	1	2010-02-09	1722	\N	19901	\N
27324	GENERIC_DAY	1	1	2010-02-17	1722	\N	19901	\N
27325	GENERIC_DAY	1	0	2010-02-06	1722	\N	19901	\N
27326	GENERIC_DAY	1	3	2010-01-28	1718	\N	19901	\N
27327	GENERIC_DAY	1	0	2010-01-09	1726	\N	19901	\N
27328	GENERIC_DAY	1	2	2009-12-31	1718	\N	19901	\N
27329	GENERIC_DAY	1	2	2009-12-30	1718	\N	19901	\N
27330	GENERIC_DAY	1	0	2010-01-01	1718	\N	19901	\N
27331	GENERIC_DAY	1	2	2010-02-03	1722	\N	19901	\N
27332	GENERIC_DAY	1	3	2010-02-05	1718	\N	19901	\N
27333	GENERIC_DAY	1	2	2010-01-29	1722	\N	19901	\N
27334	GENERIC_DAY	1	0	2010-01-09	1718	\N	19901	\N
27335	GENERIC_DAY	1	2	2010-01-13	1722	\N	19901	\N
27336	GENERIC_DAY	1	3	2010-02-01	1718	\N	19901	\N
27337	GENERIC_DAY	1	3	2010-02-03	1718	\N	19901	\N
27338	GENERIC_DAY	1	3	2010-01-06	1726	\N	19901	\N
27339	GENERIC_DAY	1	4	2010-01-12	1718	\N	19901	\N
27340	GENERIC_DAY	1	3	2010-01-06	1718	\N	19901	\N
27341	GENERIC_DAY	1	3	2010-01-20	1726	\N	19901	\N
27342	GENERIC_DAY	1	3	2010-01-15	1726	\N	19901	\N
27343	GENERIC_DAY	1	3	2010-02-04	1718	\N	19901	\N
27344	GENERIC_DAY	1	3	2010-01-27	1726	\N	19901	\N
27345	GENERIC_DAY	1	2	2010-02-04	1722	\N	19901	\N
27346	GENERIC_DAY	1	2	2010-01-20	1722	\N	19901	\N
27347	GENERIC_DAY	1	3	2009-12-24	1722	\N	19901	\N
27348	GENERIC_DAY	1	3	2009-12-30	1722	\N	19901	\N
27349	GENERIC_DAY	1	0	2010-02-14	1726	\N	19901	\N
27350	GENERIC_DAY	1	3	2010-02-02	1726	\N	19901	\N
27351	GENERIC_DAY	1	3	2010-02-02	1718	\N	19901	\N
27352	GENERIC_DAY	1	0	2010-02-13	1718	\N	19901	\N
27353	GENERIC_DAY	1	0	2010-01-01	1722	\N	19901	\N
27354	GENERIC_DAY	1	2	2010-01-04	1722	\N	19901	\N
27355	GENERIC_DAY	1	0	2010-02-13	1726	\N	19901	\N
27356	GENERIC_DAY	1	0	2010-01-31	1726	\N	19901	\N
27357	GENERIC_DAY	1	3	2010-01-18	1718	\N	19901	\N
27358	GENERIC_DAY	1	2	2010-01-07	1722	\N	19901	\N
27359	GENERIC_DAY	1	2	2010-02-01	1722	\N	19901	\N
27360	GENERIC_DAY	1	0	2010-01-24	1718	\N	19901	\N
27361	GENERIC_DAY	1	2	2010-02-15	1718	\N	19901	\N
27362	GENERIC_DAY	1	2	2010-01-06	1722	\N	19901	\N
27363	GENERIC_DAY	1	2	2010-01-19	1722	\N	19901	\N
27364	GENERIC_DAY	1	2	2010-01-13	1726	\N	19901	\N
27365	GENERIC_DAY	1	0	2010-01-09	1722	\N	19901	\N
27366	GENERIC_DAY	1	2	2010-01-12	1726	\N	19901	\N
27367	GENERIC_DAY	1	0	2010-01-10	1722	\N	19901	\N
27368	GENERIC_DAY	1	3	2010-01-25	1718	\N	19901	\N
27369	GENERIC_DAY	1	3	2010-02-15	1722	\N	19901	\N
27370	GENERIC_DAY	1	0	2010-01-23	1718	\N	19901	\N
27371	GENERIC_DAY	1	2	2009-12-24	1718	\N	19901	\N
27372	GENERIC_DAY	1	3	2010-01-05	1722	\N	19901	\N
27373	GENERIC_DAY	1	2	2010-01-12	1722	\N	19901	\N
27374	GENERIC_DAY	1	4	2010-01-14	1718	\N	19901	\N
27375	GENERIC_DAY	1	0	2010-01-02	1726	\N	19901	\N
27376	GENERIC_DAY	1	3	2009-12-28	1722	\N	19901	\N
27377	GENERIC_DAY	1	2	2010-01-27	1722	\N	19901	\N
27378	GENERIC_DAY	1	3	2010-02-05	1726	\N	19901	\N
27379	GENERIC_DAY	1	4	2010-02-09	1718	\N	19901	\N
27380	GENERIC_DAY	1	3	2010-01-19	1726	\N	19901	\N
27381	GENERIC_DAY	1	0	2010-01-17	1722	\N	19901	\N
27382	GENERIC_DAY	1	0	2010-01-24	1722	\N	19901	\N
27383	GENERIC_DAY	1	2	2010-01-08	1722	\N	19901	\N
27384	GENERIC_DAY	1	3	2010-01-05	1726	\N	19901	\N
27385	GENERIC_DAY	1	2	2010-01-14	1726	\N	19901	\N
27386	GENERIC_DAY	1	0	2010-01-17	1718	\N	19901	\N
27387	GENERIC_DAY	1	2	2010-01-11	1726	\N	19901	\N
27388	GENERIC_DAY	1	3	2010-01-18	1726	\N	19901	\N
27389	GENERIC_DAY	1	3	2009-12-30	1726	\N	19901	\N
27390	GENERIC_DAY	1	0	2009-12-27	1718	\N	19901	\N
27391	GENERIC_DAY	1	2	2010-02-12	1718	\N	19901	\N
27392	GENERIC_DAY	1	3	2010-02-12	1726	\N	19901	\N
27393	GENERIC_DAY	1	0	2010-01-30	1722	\N	19901	\N
27394	GENERIC_DAY	1	0	2010-01-24	1726	\N	19901	\N
27395	GENERIC_DAY	1	1	2010-02-11	1722	\N	19901	\N
27396	GENERIC_DAY	1	0	2009-12-26	1722	\N	19901	\N
27397	GENERIC_DAY	1	3	2010-01-26	1722	\N	19901	\N
27398	GENERIC_DAY	1	0	2010-01-23	1722	\N	19901	\N
27399	GENERIC_DAY	1	0	2010-01-23	1726	\N	19901	\N
27400	GENERIC_DAY	1	0	2010-02-07	1722	\N	19901	\N
27401	GENERIC_DAY	1	3	2010-01-28	1726	\N	19901	\N
27402	GENERIC_DAY	1	0	2010-01-03	1718	\N	19901	\N
27403	GENERIC_DAY	1	2	2010-02-02	1722	\N	19901	\N
27404	GENERIC_DAY	1	0	2010-02-14	1722	\N	19901	\N
27405	GENERIC_DAY	1	3	2010-02-10	1726	\N	19901	\N
27406	GENERIC_DAY	1	3	2010-01-08	1726	\N	19901	\N
27407	GENERIC_DAY	1	4	2010-02-08	1718	\N	19901	\N
27408	GENERIC_DAY	1	0	2010-01-10	1726	\N	19901	\N
20797	GENERIC_DAY	1	8	2010-02-26	1724	\N	6367	\N
20794	GENERIC_DAY	1	8	2010-03-01	1724	\N	6367	\N
20793	GENERIC_DAY	1	8	2010-02-28	1724	\N	6367	\N
20798	GENERIC_DAY	1	8	2010-03-09	1724	\N	6367	\N
20791	GENERIC_DAY	1	8	2010-03-07	1724	\N	6367	\N
20796	GENERIC_DAY	1	8	2010-03-06	1724	\N	6367	\N
20799	GENERIC_DAY	1	8	2010-02-27	1724	\N	6367	\N
20795	GENERIC_DAY	1	8	2010-03-03	1724	\N	6367	\N
20792	GENERIC_DAY	1	8	2010-03-04	1724	\N	6367	\N
20800	GENERIC_DAY	1	4	2010-03-10	1724	\N	6367	\N
27409	GENERIC_DAY	1	3	2009-12-24	1726	\N	19901	\N
27410	GENERIC_DAY	1	0	2010-01-10	1718	\N	19901	\N
27411	GENERIC_DAY	1	3	2010-01-21	1718	\N	19901	\N
27412	GENERIC_DAY	1	0	2010-01-16	1722	\N	19901	\N
27413	GENERIC_DAY	1	4	2010-02-10	1718	\N	19901	\N
27414	GENERIC_DAY	1	2	2010-01-25	1722	\N	19901	\N
27415	GENERIC_DAY	1	3	2010-01-08	1718	\N	19901	\N
27416	GENERIC_DAY	1	3	2010-01-04	1726	\N	19901	\N
27417	GENERIC_DAY	1	0	2009-12-27	1726	\N	19901	\N
27418	GENERIC_DAY	1	0	2009-12-27	1722	\N	19901	\N
27419	GENERIC_DAY	1	0	2010-01-16	1718	\N	19901	\N
27420	GENERIC_DAY	1	0	2009-12-25	1722	\N	19901	\N
27421	GENERIC_DAY	1	2	2010-01-22	1722	\N	19901	\N
27422	GENERIC_DAY	1	7	2010-01-10	1720	\N	3952	\N
27423	GENERIC_DAY	1	15	2010-01-11	1720	\N	3952	\N
27424	GENERIC_DAY	1	7	2010-01-09	1720	\N	3952	\N
27425	GENERIC_DAY	1	14	2010-01-12	1720	\N	3952	\N
27426	GENERIC_DAY	1	14	2010-01-13	1720	\N	3952	\N
27427	GENERIC_DAY	1	15	2010-01-08	1720	\N	3952	\N
27428	GENERIC_DAY	1	14	2010-01-14	1720	\N	3952	\N
27429	GENERIC_DAY	1	14	2010-01-15	1720	\N	3952	\N
27430	GENERIC_DAY	1	14	2010-01-13	1724	\N	3951	\N
27431	GENERIC_DAY	1	14	2010-01-12	1724	\N	3951	\N
27432	GENERIC_DAY	1	15	2010-01-08	1724	\N	3951	\N
27433	GENERIC_DAY	1	15	2010-01-11	1724	\N	3951	\N
27434	GENERIC_DAY	1	7	2010-01-10	1724	\N	3951	\N
27435	GENERIC_DAY	1	14	2010-01-15	1724	\N	3951	\N
27436	GENERIC_DAY	1	14	2010-01-14	1724	\N	3951	\N
27437	GENERIC_DAY	1	7	2010-01-09	1724	\N	3951	\N
27438	GENERIC_DAY	1	0	2010-03-21	1724	\N	3950	\N
27439	GENERIC_DAY	1	2	2010-02-19	1724	\N	3950	\N
27440	GENERIC_DAY	1	2	2010-03-11	1724	\N	3950	\N
27441	GENERIC_DAY	1	2	2010-03-15	1724	\N	3950	\N
27442	GENERIC_DAY	1	2	2010-03-04	1724	\N	3950	\N
27443	GENERIC_DAY	1	0	2010-02-28	1724	\N	3950	\N
27444	GENERIC_DAY	1	2	2010-03-17	1724	\N	3950	\N
27445	GENERIC_DAY	1	2	2010-03-16	1724	\N	3950	\N
27446	GENERIC_DAY	1	2	2010-02-22	1724	\N	3950	\N
27447	GENERIC_DAY	1	0	2010-03-20	1724	\N	3950	\N
27448	GENERIC_DAY	1	0	2010-02-20	1724	\N	3950	\N
27449	GENERIC_DAY	1	0	2010-03-14	1724	\N	3950	\N
27450	GENERIC_DAY	1	2	2010-03-23	1724	\N	3950	\N
27451	GENERIC_DAY	1	2	2010-03-08	1724	\N	3950	\N
27452	GENERIC_DAY	1	2	2010-02-24	1724	\N	3950	\N
27453	GENERIC_DAY	1	2	2010-03-03	1724	\N	3950	\N
27454	GENERIC_DAY	1	2	2010-03-10	1724	\N	3950	\N
27455	GENERIC_DAY	1	0	2010-03-06	1724	\N	3950	\N
27456	GENERIC_DAY	1	2	2010-03-19	1724	\N	3950	\N
27457	GENERIC_DAY	1	2	2010-03-05	1724	\N	3950	\N
27458	GENERIC_DAY	1	0	2010-03-13	1724	\N	3950	\N
27459	GENERIC_DAY	1	2	2010-02-23	1724	\N	3950	\N
27460	GENERIC_DAY	1	0	2010-03-07	1724	\N	3950	\N
27461	GENERIC_DAY	1	2	2010-03-24	1724	\N	3950	\N
27462	GENERIC_DAY	1	2	2010-03-09	1724	\N	3950	\N
27463	GENERIC_DAY	1	2	2010-02-26	1724	\N	3950	\N
27464	GENERIC_DAY	1	2	2010-03-18	1724	\N	3950	\N
27465	GENERIC_DAY	1	2	2010-02-18	1724	\N	3950	\N
27466	GENERIC_DAY	1	2	2010-03-12	1724	\N	3950	\N
27467	GENERIC_DAY	1	2	2010-03-02	1724	\N	3950	\N
27468	GENERIC_DAY	1	2	2010-02-25	1724	\N	3950	\N
27469	GENERIC_DAY	1	0	2010-02-27	1724	\N	3950	\N
27470	GENERIC_DAY	1	2	2010-03-22	1724	\N	3950	\N
27471	GENERIC_DAY	1	0	2010-02-21	1724	\N	3950	\N
27472	GENERIC_DAY	1	2	2010-03-01	1724	\N	3950	\N
27473	GENERIC_DAY	1	0	2010-01-03	1724	\N	3953	\N
27474	GENERIC_DAY	1	0	2009-12-27	1724	\N	3953	\N
27475	GENERIC_DAY	1	0	2009-12-26	1724	\N	3953	\N
27476	GENERIC_DAY	1	8	2009-12-16	1724	\N	3953	\N
27477	GENERIC_DAY	1	0	2010-01-01	1724	\N	3953	\N
27478	GENERIC_DAY	1	8	2009-12-15	1724	\N	3953	\N
27479	GENERIC_DAY	1	0	2009-12-25	1724	\N	3953	\N
27480	GENERIC_DAY	1	8	2010-01-05	1724	\N	3953	\N
27481	GENERIC_DAY	1	8	2009-12-22	1724	\N	3953	\N
27482	GENERIC_DAY	1	8	2009-12-24	1724	\N	3953	\N
27483	GENERIC_DAY	1	8	2009-12-23	1724	\N	3953	\N
27484	GENERIC_DAY	1	8	2009-12-28	1724	\N	3953	\N
27485	GENERIC_DAY	1	8	2009-12-18	1724	\N	3953	\N
27486	GENERIC_DAY	1	8	2010-01-06	1724	\N	3953	\N
27487	GENERIC_DAY	1	8	2009-12-21	1724	\N	3953	\N
27488	GENERIC_DAY	1	0	2010-01-02	1724	\N	3953	\N
27489	GENERIC_DAY	1	8	2010-01-07	1724	\N	3953	\N
27490	GENERIC_DAY	1	8	2009-12-17	1724	\N	3953	\N
27491	GENERIC_DAY	1	8	2010-01-04	1724	\N	3953	\N
27492	GENERIC_DAY	1	8	2009-12-29	1724	\N	3953	\N
27493	GENERIC_DAY	1	0	2009-12-20	1724	\N	3953	\N
27494	GENERIC_DAY	1	8	2009-12-30	1724	\N	3953	\N
27495	GENERIC_DAY	1	0	2009-12-19	1724	\N	3953	\N
31454	SPECIFIC_DAY	3	0	2010-01-09	1720	31014	\N	\N
31455	SPECIFIC_DAY	3	8	2009-12-15	1720	31014	\N	\N
31456	SPECIFIC_DAY	3	8	2009-12-16	1720	31014	\N	\N
31457	SPECIFIC_DAY	3	0	2009-12-12	1720	31014	\N	\N
31458	SPECIFIC_DAY	3	8	2009-12-28	1720	31014	\N	\N
31459	SPECIFIC_DAY	3	8	2009-12-30	1720	31014	\N	\N
31460	SPECIFIC_DAY	3	8	2010-01-15	1720	31014	\N	\N
31461	SPECIFIC_DAY	3	8	2009-12-22	1720	31014	\N	\N
31462	SPECIFIC_DAY	3	0	2010-01-03	1720	31014	\N	\N
31463	SPECIFIC_DAY	3	8	2009-12-17	1720	31014	\N	\N
31464	SPECIFIC_DAY	3	8	2010-01-12	1720	31014	\N	\N
31465	SPECIFIC_DAY	3	0	2009-12-26	1720	31014	\N	\N
31466	SPECIFIC_DAY	3	8	2010-01-13	1720	31014	\N	\N
31467	SPECIFIC_DAY	3	8	2010-01-04	1720	31014	\N	\N
31468	SPECIFIC_DAY	3	8	2009-12-11	1720	31014	\N	\N
31469	SPECIFIC_DAY	3	8	2009-12-18	1720	31014	\N	\N
31470	SPECIFIC_DAY	3	8	2009-12-23	1720	31014	\N	\N
31471	SPECIFIC_DAY	3	0	2009-12-20	1720	31014	\N	\N
31472	SPECIFIC_DAY	3	8	2009-12-31	1720	31014	\N	\N
31473	SPECIFIC_DAY	3	8	2009-12-14	1720	31014	\N	\N
31474	SPECIFIC_DAY	3	8	2010-01-06	1720	31014	\N	\N
31475	SPECIFIC_DAY	3	8	2009-12-10	1720	31014	\N	\N
31476	SPECIFIC_DAY	3	8	2009-12-24	1720	31014	\N	\N
31477	SPECIFIC_DAY	3	8	2010-01-11	1720	31014	\N	\N
31478	SPECIFIC_DAY	3	0	2010-01-02	1720	31014	\N	\N
31479	SPECIFIC_DAY	3	8	2009-12-29	1720	31014	\N	\N
31480	SPECIFIC_DAY	3	8	2010-01-14	1720	31014	\N	\N
31481	SPECIFIC_DAY	3	8	2009-12-21	1720	31014	\N	\N
31482	SPECIFIC_DAY	3	0	2009-12-25	1720	31014	\N	\N
31483	SPECIFIC_DAY	3	8	2010-01-08	1720	31014	\N	\N
31484	SPECIFIC_DAY	3	8	2010-01-05	1720	31014	\N	\N
31485	SPECIFIC_DAY	3	0	2009-12-27	1720	31014	\N	\N
31486	SPECIFIC_DAY	3	8	2010-01-07	1720	31014	\N	\N
31487	SPECIFIC_DAY	3	0	2010-01-01	1720	31014	\N	\N
31488	SPECIFIC_DAY	3	0	2010-01-10	1720	31014	\N	\N
31489	SPECIFIC_DAY	3	0	2009-12-19	1720	31014	\N	\N
31490	SPECIFIC_DAY	3	0	2009-12-13	1720	31014	\N	\N
48919	GENERIC_DAY	0	3	2010-02-08	40199	\N	41050	\N
48920	GENERIC_DAY	0	2	2010-02-08	37573	\N	41050	\N
48921	GENERIC_DAY	0	0	2010-02-06	36159	\N	41050	\N
48922	GENERIC_DAY	0	3	2010-02-05	37573	\N	41050	\N
48923	GENERIC_DAY	0	0	2010-02-06	37573	\N	41050	\N
48924	GENERIC_DAY	0	0	2010-02-07	36159	\N	41050	\N
48925	GENERIC_DAY	0	1	2010-02-08	36159	\N	41050	\N
48926	GENERIC_DAY	0	3	2010-02-05	40199	\N	41050	\N
48927	GENERIC_DAY	0	2	2010-02-05	36159	\N	41050	\N
48928	GENERIC_DAY	0	0	2010-02-07	40199	\N	41050	\N
48929	GENERIC_DAY	0	0	2010-02-07	37573	\N	41050	\N
48930	GENERIC_DAY	0	0	2010-02-06	40199	\N	41050	\N
39501	GENERIC_DAY	1	0	2010-02-05	36159	\N	38601	\N
39502	GENERIC_DAY	1	0	2010-03-22	36159	\N	38601	\N
39503	GENERIC_DAY	1	0	2010-02-01	37573	\N	38601	\N
39504	GENERIC_DAY	1	0	2010-02-26	37573	\N	38601	\N
39505	GENERIC_DAY	1	0	2010-02-10	36159	\N	38601	\N
39506	GENERIC_DAY	1	1	2010-01-28	36159	\N	38601	\N
16196	GENERIC_DAY	0	8	2010-04-20	1720	\N	8588	\N
16197	GENERIC_DAY	0	8	2010-04-13	1720	\N	8588	\N
16198	GENERIC_DAY	0	8	2010-03-24	1724	\N	3983	\N
16199	GENERIC_DAY	0	8	2010-03-13	1724	\N	3983	\N
16200	GENERIC_DAY	0	8	2010-03-20	1724	\N	3983	\N
16201	GENERIC_DAY	0	8	2010-03-16	1724	\N	3983	\N
16202	GENERIC_DAY	0	8	2010-03-04	1724	\N	3983	\N
16203	GENERIC_DAY	0	8	2010-03-26	1724	\N	3983	\N
16204	GENERIC_DAY	0	8	2010-04-02	1724	\N	3983	\N
16205	GENERIC_DAY	0	8	2010-03-19	1724	\N	3983	\N
16206	GENERIC_DAY	0	8	2010-03-18	1724	\N	3983	\N
16207	GENERIC_DAY	0	8	2010-03-29	1724	\N	3983	\N
16208	GENERIC_DAY	0	8	2010-04-03	1724	\N	3983	\N
16209	GENERIC_DAY	0	8	2010-03-06	1724	\N	3983	\N
16210	GENERIC_DAY	0	8	2010-04-01	1724	\N	3983	\N
16211	GENERIC_DAY	0	8	2010-03-30	1724	\N	3983	\N
16212	GENERIC_DAY	0	8	2010-03-11	1724	\N	3983	\N
16213	GENERIC_DAY	0	8	2010-03-12	1724	\N	3983	\N
16214	GENERIC_DAY	0	8	2010-03-09	1724	\N	3983	\N
16215	GENERIC_DAY	0	8	2010-03-02	1724	\N	3983	\N
16216	GENERIC_DAY	0	8	2010-03-25	1724	\N	3983	\N
16217	GENERIC_DAY	0	8	2010-03-22	1724	\N	3983	\N
16218	GENERIC_DAY	0	8	2010-03-27	1724	\N	3983	\N
16219	GENERIC_DAY	0	8	2010-03-23	1724	\N	3983	\N
16220	GENERIC_DAY	0	8	2010-03-31	1724	\N	3983	\N
16221	GENERIC_DAY	0	8	2010-03-14	1724	\N	3983	\N
16222	GENERIC_DAY	0	8	2010-03-28	1724	\N	3983	\N
16223	GENERIC_DAY	0	8	2010-03-08	1724	\N	3983	\N
16224	GENERIC_DAY	0	8	2010-03-01	1724	\N	3983	\N
16225	GENERIC_DAY	0	8	2010-03-21	1724	\N	3983	\N
16226	GENERIC_DAY	0	8	2010-03-15	1724	\N	3983	\N
16227	GENERIC_DAY	0	8	2010-03-17	1724	\N	3983	\N
16228	GENERIC_DAY	0	8	2010-03-05	1724	\N	3983	\N
16229	GENERIC_DAY	0	8	2010-03-10	1724	\N	3983	\N
16230	GENERIC_DAY	0	8	2010-03-07	1724	\N	3983	\N
16231	GENERIC_DAY	0	8	2010-03-03	1724	\N	3983	\N
16232	GENERIC_DAY	0	3	2010-04-04	1724	\N	3983	\N
16233	GENERIC_DAY	0	8	2010-03-24	1720	\N	3982	\N
16234	GENERIC_DAY	0	8	2010-03-31	1720	\N	3982	\N
16235	GENERIC_DAY	0	8	2010-03-18	1720	\N	3982	\N
16236	GENERIC_DAY	0	8	2010-03-25	1720	\N	3982	\N
16237	GENERIC_DAY	0	8	2010-03-14	1720	\N	3982	\N
16238	GENERIC_DAY	0	8	2010-03-11	1720	\N	3982	\N
16239	GENERIC_DAY	0	8	2010-03-04	1720	\N	3982	\N
16240	GENERIC_DAY	0	8	2010-03-13	1720	\N	3982	\N
16241	GENERIC_DAY	0	8	2010-03-03	1720	\N	3982	\N
16242	GENERIC_DAY	0	8	2010-03-29	1720	\N	3982	\N
16243	GENERIC_DAY	0	8	2010-04-02	1720	\N	3982	\N
16244	GENERIC_DAY	0	8	2010-03-23	1720	\N	3982	\N
16245	GENERIC_DAY	0	8	2010-03-12	1720	\N	3982	\N
16246	GENERIC_DAY	0	8	2010-03-22	1720	\N	3982	\N
16247	GENERIC_DAY	0	8	2010-03-17	1720	\N	3982	\N
16248	GENERIC_DAY	0	8	2010-03-16	1720	\N	3982	\N
16249	GENERIC_DAY	0	8	2010-03-30	1720	\N	3982	\N
16250	GENERIC_DAY	0	8	2010-03-15	1720	\N	3982	\N
16251	GENERIC_DAY	0	8	2010-03-06	1720	\N	3982	\N
16252	GENERIC_DAY	0	8	2010-03-28	1720	\N	3982	\N
16253	GENERIC_DAY	0	8	2010-03-08	1720	\N	3982	\N
16254	GENERIC_DAY	0	8	2010-03-26	1720	\N	3982	\N
16255	GENERIC_DAY	0	8	2010-03-05	1720	\N	3982	\N
16256	GENERIC_DAY	0	8	2010-04-01	1720	\N	3982	\N
16257	GENERIC_DAY	0	8	2010-04-03	1720	\N	3982	\N
16258	GENERIC_DAY	0	8	2010-03-01	1720	\N	3982	\N
16259	GENERIC_DAY	0	3	2010-04-04	1720	\N	3982	\N
16260	GENERIC_DAY	0	8	2010-03-21	1720	\N	3982	\N
16261	GENERIC_DAY	0	8	2010-03-09	1720	\N	3982	\N
16262	GENERIC_DAY	0	8	2010-03-10	1720	\N	3982	\N
16263	GENERIC_DAY	0	8	2010-03-02	1720	\N	3982	\N
16264	GENERIC_DAY	0	8	2010-03-07	1720	\N	3982	\N
16265	GENERIC_DAY	0	8	2010-03-27	1720	\N	3982	\N
16266	GENERIC_DAY	0	8	2010-03-20	1720	\N	3982	\N
16267	GENERIC_DAY	0	8	2010-03-19	1720	\N	3982	\N
120973	SPECIFIC_DAY	1	4	2010-02-03	49309	119897	\N	\N
120971	SPECIFIC_DAY	1	0	2010-02-06	49309	119897	\N	\N
120968	SPECIFIC_DAY	1	0	2010-02-14	49309	119897	\N	\N
120967	SPECIFIC_DAY	1	4	2010-02-16	49309	119897	\N	\N
120969	SPECIFIC_DAY	1	4	2010-02-02	49309	119897	\N	\N
120970	SPECIFIC_DAY	1	0	2010-02-07	49309	119897	\N	\N
120974	SPECIFIC_DAY	1	0	2010-02-13	49309	119897	\N	\N
120972	SPECIFIC_DAY	1	0	2010-02-21	49309	119897	\N	\N
15996	GENERIC_DAY	3	3	2010-03-31	1722	\N	3985	\N
15997	GENERIC_DAY	3	3	2010-04-05	1726	\N	3985	\N
15998	GENERIC_DAY	3	3	2010-04-01	1722	\N	3985	\N
15999	GENERIC_DAY	3	3	2010-03-30	1726	\N	3985	\N
16000	GENERIC_DAY	3	3	2010-04-02	1726	\N	3985	\N
16001	GENERIC_DAY	3	3	2010-04-08	1722	\N	3985	\N
39444	GENERIC_DAY	1	0	2010-01-23	36159	\N	38601	\N
39445	GENERIC_DAY	1	0	2010-03-01	37573	\N	38601	\N
39446	GENERIC_DAY	1	1	2010-01-26	37573	\N	38601	\N
39447	GENERIC_DAY	1	0	2010-03-23	37573	\N	38601	\N
39448	GENERIC_DAY	1	0	2010-03-05	37573	\N	38601	\N
39449	GENERIC_DAY	1	0	2010-03-02	36159	\N	38601	\N
39450	GENERIC_DAY	1	1	2010-02-03	37573	\N	38601	\N
39451	GENERIC_DAY	1	0	2010-03-01	36159	\N	38601	\N
39452	GENERIC_DAY	1	0	2010-03-06	36159	\N	38601	\N
39453	GENERIC_DAY	1	0	2010-01-26	36159	\N	38601	\N
39454	GENERIC_DAY	1	0	2010-02-09	36159	\N	38601	\N
39455	GENERIC_DAY	1	0	2010-02-23	36159	\N	38601	\N
39456	GENERIC_DAY	1	0	2010-01-31	36159	\N	38601	\N
39457	GENERIC_DAY	1	0	2010-03-16	37573	\N	38601	\N
39458	GENERIC_DAY	1	0	2010-02-21	36159	\N	38601	\N
39459	GENERIC_DAY	1	0	2010-02-12	36159	\N	38601	\N
39460	GENERIC_DAY	1	0	2010-02-14	37573	\N	38601	\N
39461	GENERIC_DAY	1	0	2010-03-10	37573	\N	38601	\N
39462	GENERIC_DAY	1	0	2010-02-24	36159	\N	38601	\N
39463	GENERIC_DAY	1	0	2010-02-21	37573	\N	38601	\N
39464	GENERIC_DAY	1	0	2010-03-13	36159	\N	38601	\N
39465	GENERIC_DAY	1	0	2010-02-13	37573	\N	38601	\N
39466	GENERIC_DAY	1	0	2010-02-18	36159	\N	38601	\N
39467	GENERIC_DAY	1	0	2010-03-06	37573	\N	38601	\N
39468	GENERIC_DAY	1	0	2010-02-11	36159	\N	38601	\N
39469	GENERIC_DAY	1	0	2010-02-20	37573	\N	38601	\N
39470	GENERIC_DAY	1	0	2010-02-17	37573	\N	38601	\N
39471	GENERIC_DAY	1	1	2010-02-05	37573	\N	38601	\N
39472	GENERIC_DAY	1	0	2010-03-04	37573	\N	38601	\N
39473	GENERIC_DAY	1	0	2010-02-22	37573	\N	38601	\N
39474	GENERIC_DAY	1	0	2010-02-27	36159	\N	38601	\N
39475	GENERIC_DAY	1	0	2010-03-21	36159	\N	38601	\N
39476	GENERIC_DAY	1	0	2010-03-20	37573	\N	38601	\N
39477	GENERIC_DAY	1	0	2010-02-15	36159	\N	38601	\N
39478	GENERIC_DAY	1	1	2010-02-04	37573	\N	38601	\N
39479	GENERIC_DAY	1	0	2010-03-04	36159	\N	38601	\N
39480	GENERIC_DAY	1	0	2010-02-08	36159	\N	38601	\N
39481	GENERIC_DAY	1	0	2010-02-23	37573	\N	38601	\N
39482	GENERIC_DAY	1	0	2010-03-02	37573	\N	38601	\N
39483	GENERIC_DAY	1	0	2010-02-28	36159	\N	38601	\N
39484	GENERIC_DAY	1	0	2010-03-09	36159	\N	38601	\N
39485	GENERIC_DAY	1	0	2010-03-22	37573	\N	38601	\N
39486	GENERIC_DAY	1	0	2010-01-22	36159	\N	38601	\N
39487	GENERIC_DAY	1	1	2010-01-22	37573	\N	38601	\N
39488	GENERIC_DAY	1	0	2010-02-04	36159	\N	38601	\N
39489	GENERIC_DAY	1	0	2010-03-14	36159	\N	38601	\N
39490	GENERIC_DAY	1	0	2010-03-08	37573	\N	38601	\N
39491	GENERIC_DAY	1	1	2010-02-01	36159	\N	38601	\N
39492	GENERIC_DAY	1	0	2010-02-20	36159	\N	38601	\N
39493	GENERIC_DAY	1	0	2010-02-24	37573	\N	38601	\N
39494	GENERIC_DAY	1	1	2010-02-10	37573	\N	38601	\N
39495	GENERIC_DAY	1	0	2010-03-21	37573	\N	38601	\N
39496	GENERIC_DAY	1	0	2010-03-14	37573	\N	38601	\N
39497	GENERIC_DAY	1	0	2010-03-07	37573	\N	38601	\N
39498	GENERIC_DAY	1	0	2010-03-17	37573	\N	38601	\N
39499	GENERIC_DAY	1	0	2010-03-12	36159	\N	38601	\N
39500	GENERIC_DAY	1	0	2010-02-16	36159	\N	38601	\N
39507	GENERIC_DAY	1	0	2010-03-24	36159	\N	38601	\N
39508	GENERIC_DAY	1	0	2010-03-15	37573	\N	38601	\N
39509	GENERIC_DAY	1	0	2010-03-11	37573	\N	38601	\N
39510	GENERIC_DAY	1	0	2010-03-20	36159	\N	38601	\N
39511	GENERIC_DAY	1	0	2010-01-24	36159	\N	38601	\N
39512	GENERIC_DAY	1	0	2010-02-25	36159	\N	38601	\N
39513	GENERIC_DAY	1	1	2010-01-25	37573	\N	38601	\N
39514	GENERIC_DAY	1	0	2010-01-30	37573	\N	38601	\N
39515	GENERIC_DAY	1	0	2010-02-18	37573	\N	38601	\N
39516	GENERIC_DAY	1	0	2010-03-11	36159	\N	38601	\N
39517	GENERIC_DAY	1	0	2010-03-09	37573	\N	38601	\N
39518	GENERIC_DAY	1	1	2010-02-09	37573	\N	38601	\N
39519	GENERIC_DAY	1	0	2010-03-19	37573	\N	38601	\N
39520	GENERIC_DAY	1	0	2010-03-03	36159	\N	38601	\N
39521	GENERIC_DAY	1	0	2010-03-15	36159	\N	38601	\N
39522	GENERIC_DAY	1	0	2010-01-25	36159	\N	38601	\N
39523	GENERIC_DAY	1	0	2010-03-18	37573	\N	38601	\N
39524	GENERIC_DAY	1	0	2010-02-17	36159	\N	38601	\N
39525	GENERIC_DAY	1	0	2010-02-16	37573	\N	38601	\N
39526	GENERIC_DAY	1	0	2010-02-07	37573	\N	38601	\N
39527	GENERIC_DAY	1	0	2010-02-19	37573	\N	38601	\N
39528	GENERIC_DAY	1	0	2010-02-07	36159	\N	38601	\N
39529	GENERIC_DAY	1	0	2010-02-26	36159	\N	38601	\N
39530	GENERIC_DAY	1	1	2010-01-29	36159	\N	38601	\N
39531	GENERIC_DAY	1	0	2010-01-31	37573	\N	38601	\N
39532	GENERIC_DAY	1	1	2010-02-08	37573	\N	38601	\N
39533	GENERIC_DAY	1	0	2010-03-10	36159	\N	38601	\N
39534	GENERIC_DAY	1	0	2010-03-16	36159	\N	38601	\N
39535	GENERIC_DAY	1	0	2010-02-06	37573	\N	38601	\N
39536	GENERIC_DAY	1	0	2010-02-06	36159	\N	38601	\N
39537	GENERIC_DAY	1	0	2010-01-28	37573	\N	38601	\N
39538	GENERIC_DAY	1	1	2010-02-02	37573	\N	38601	\N
39539	GENERIC_DAY	1	0	2010-02-15	37573	\N	38601	\N
39540	GENERIC_DAY	1	0	2010-01-29	37573	\N	38601	\N
39541	GENERIC_DAY	1	0	2010-03-05	36159	\N	38601	\N
39542	GENERIC_DAY	1	0	2010-02-28	37573	\N	38601	\N
39543	GENERIC_DAY	1	0	2010-03-17	36159	\N	38601	\N
39544	GENERIC_DAY	1	1	2010-01-27	36159	\N	38601	\N
39545	GENERIC_DAY	1	0	2010-01-27	37573	\N	38601	\N
39546	GENERIC_DAY	1	0	2010-02-03	36159	\N	38601	\N
39547	GENERIC_DAY	1	0	2010-01-24	37573	\N	38601	\N
39548	GENERIC_DAY	1	0	2010-03-12	37573	\N	38601	\N
39549	GENERIC_DAY	1	0	2010-02-27	37573	\N	38601	\N
39550	GENERIC_DAY	1	0	2010-03-08	36159	\N	38601	\N
39551	GENERIC_DAY	1	0	2010-02-12	37573	\N	38601	\N
39552	GENERIC_DAY	1	0	2010-02-19	36159	\N	38601	\N
39553	GENERIC_DAY	1	0	2010-02-14	36159	\N	38601	\N
39554	GENERIC_DAY	1	0	2010-02-13	36159	\N	38601	\N
39555	GENERIC_DAY	1	0	2010-01-30	36159	\N	38601	\N
39556	GENERIC_DAY	1	0	2010-03-13	37573	\N	38601	\N
39557	GENERIC_DAY	1	0	2010-03-24	37573	\N	38601	\N
39558	GENERIC_DAY	1	0	2010-02-02	36159	\N	38601	\N
39559	GENERIC_DAY	1	0	2010-01-23	37573	\N	38601	\N
39560	GENERIC_DAY	1	0	2010-02-25	37573	\N	38601	\N
39561	GENERIC_DAY	1	0	2010-03-03	37573	\N	38601	\N
39562	GENERIC_DAY	1	0	2010-03-23	36159	\N	38601	\N
39563	GENERIC_DAY	1	0	2010-03-18	36159	\N	38601	\N
48811	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077	\N
48812	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077	\N
48813	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077	\N
48814	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077	\N
48815	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077	\N
21933	SPECIFIC_DAY	4	8	2010-02-17	1724	19903	\N	\N
21968	SPECIFIC_DAY	4	8	2010-02-23	1724	19903	\N	\N
21958	SPECIFIC_DAY	4	8	2010-02-04	1724	19903	\N	\N
21964	SPECIFIC_DAY	4	8	2010-01-22	1724	19903	\N	\N
21961	SPECIFIC_DAY	4	8	2010-02-15	1724	19903	\N	\N
21932	SPECIFIC_DAY	4	8	2010-01-08	1724	19903	\N	\N
21942	SPECIFIC_DAY	4	8	2010-02-12	1724	19903	\N	\N
21960	SPECIFIC_DAY	4	0	2010-02-21	1724	19903	\N	\N
21941	SPECIFIC_DAY	4	8	2010-02-01	1724	19903	\N	\N
21930	SPECIFIC_DAY	4	8	2010-01-13	1724	19903	\N	\N
21959	SPECIFIC_DAY	4	8	2010-01-04	1724	19903	\N	\N
21928	SPECIFIC_DAY	4	8	2010-02-02	1724	19903	\N	\N
21935	SPECIFIC_DAY	4	8	2010-02-03	1724	19903	\N	\N
21966	SPECIFIC_DAY	4	0	2010-01-01	1724	19903	\N	\N
21944	SPECIFIC_DAY	4	8	2010-01-27	1724	19903	\N	\N
21975	SPECIFIC_DAY	4	8	2010-01-11	1724	19903	\N	\N
21934	SPECIFIC_DAY	4	8	2010-01-29	1724	19903	\N	\N
21925	SPECIFIC_DAY	4	8	2010-02-18	1724	19903	\N	\N
21953	SPECIFIC_DAY	4	8	2010-02-09	1724	19903	\N	\N
21974	SPECIFIC_DAY	4	8	2010-01-07	1724	19903	\N	\N
21973	SPECIFIC_DAY	4	8	2010-01-26	1724	19903	\N	\N
21962	SPECIFIC_DAY	4	0	2010-01-02	1724	19903	\N	\N
21938	SPECIFIC_DAY	4	8	2010-02-19	1724	19903	\N	\N
21957	SPECIFIC_DAY	4	0	2010-02-14	1724	19903	\N	\N
21967	SPECIFIC_DAY	4	0	2010-02-06	1724	19903	\N	\N
21936	SPECIFIC_DAY	4	0	2010-01-10	1724	19903	\N	\N
21923	SPECIFIC_DAY	4	0	2010-01-24	1724	19903	\N	\N
21952	SPECIFIC_DAY	4	8	2010-01-28	1724	19903	\N	\N
21945	SPECIFIC_DAY	4	4	2010-02-24	1724	19903	\N	\N
21963	SPECIFIC_DAY	4	8	2010-01-18	1724	19903	\N	\N
21924	SPECIFIC_DAY	4	0	2010-02-13	1724	19903	\N	\N
21927	SPECIFIC_DAY	4	8	2010-02-22	1724	19903	\N	\N
21949	SPECIFIC_DAY	4	8	2010-02-16	1724	19903	\N	\N
21921	SPECIFIC_DAY	4	8	2010-02-05	1724	19903	\N	\N
21940	SPECIFIC_DAY	4	8	2010-01-06	1724	19903	\N	\N
21947	SPECIFIC_DAY	4	8	2010-01-19	1724	19903	\N	\N
21931	SPECIFIC_DAY	4	0	2010-02-20	1724	19903	\N	\N
21970	SPECIFIC_DAY	4	8	2010-01-15	1724	19903	\N	\N
21969	SPECIFIC_DAY	4	8	2010-01-12	1724	19903	\N	\N
21946	SPECIFIC_DAY	4	0	2010-01-31	1724	19903	\N	\N
21951	SPECIFIC_DAY	4	8	2010-02-08	1724	19903	\N	\N
21972	SPECIFIC_DAY	4	8	2010-01-05	1724	19903	\N	\N
21950	SPECIFIC_DAY	4	8	2010-02-11	1724	19903	\N	\N
21922	SPECIFIC_DAY	4	0	2010-01-30	1724	19903	\N	\N
21943	SPECIFIC_DAY	4	8	2010-01-20	1724	19903	\N	\N
21965	SPECIFIC_DAY	4	8	2010-01-21	1724	19903	\N	\N
21971	SPECIFIC_DAY	4	0	2010-01-09	1724	19903	\N	\N
21956	SPECIFIC_DAY	4	0	2010-01-23	1724	19903	\N	\N
21939	SPECIFIC_DAY	4	0	2010-01-03	1724	19903	\N	\N
21926	SPECIFIC_DAY	4	8	2010-02-10	1724	19903	\N	\N
21955	SPECIFIC_DAY	4	0	2010-01-17	1724	19903	\N	\N
21929	SPECIFIC_DAY	4	0	2010-01-16	1724	19903	\N	\N
21937	SPECIFIC_DAY	4	8	2010-01-14	1724	19903	\N	\N
21954	SPECIFIC_DAY	4	8	2010-01-25	1724	19903	\N	\N
21948	SPECIFIC_DAY	4	0	2010-02-07	1724	19903	\N	\N
48816	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077	\N
48817	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077	\N
48818	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077	\N
48819	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077	\N
48820	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077	\N
48821	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077	\N
48822	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077	\N
48823	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077	\N
48824	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077	\N
48825	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077	\N
25621	GENERIC_DAY	0	7	2009-12-23	1724	\N	6369	\N
25622	GENERIC_DAY	0	6	2009-12-18	1724	\N	6369	\N
25623	GENERIC_DAY	0	0	2009-12-19	1724	\N	6369	\N
25624	GENERIC_DAY	0	6	2009-12-16	1724	\N	6369	\N
25625	GENERIC_DAY	0	6	2009-12-15	1724	\N	6369	\N
25626	GENERIC_DAY	0	2	2009-12-08	1724	\N	6369	\N
25627	GENERIC_DAY	0	5	2009-12-10	1724	\N	6369	\N
25628	GENERIC_DAY	0	0	2009-12-25	1724	\N	6369	\N
25629	GENERIC_DAY	0	0	2009-12-13	1724	\N	6369	\N
25630	GENERIC_DAY	0	0	2009-12-12	1724	\N	6369	\N
25631	GENERIC_DAY	0	0	2009-12-26	1724	\N	6369	\N
25632	GENERIC_DAY	0	1	2009-12-09	1724	\N	6369	\N
25633	GENERIC_DAY	0	5	2009-12-11	1724	\N	6369	\N
25634	GENERIC_DAY	0	7	2009-12-21	1724	\N	6369	\N
25635	GENERIC_DAY	0	7	2009-12-24	1724	\N	6369	\N
25636	GENERIC_DAY	0	6	2009-12-31	1724	\N	6369	\N
25637	GENERIC_DAY	0	7	2009-12-30	1724	\N	6369	\N
25638	GENERIC_DAY	0	0	2009-12-20	1724	\N	6369	\N
25639	GENERIC_DAY	0	7	2009-12-28	1724	\N	6369	\N
25640	GENERIC_DAY	0	0	2009-12-27	1724	\N	6369	\N
25641	GENERIC_DAY	0	7	2009-12-22	1724	\N	6369	\N
25642	GENERIC_DAY	0	2	2009-12-07	1724	\N	6369	\N
25643	GENERIC_DAY	0	7	2009-12-29	1724	\N	6369	\N
25644	GENERIC_DAY	0	6	2009-12-17	1724	\N	6369	\N
25645	GENERIC_DAY	0	6	2009-12-14	1724	\N	6369	\N
25646	GENERIC_DAY	0	4	2009-12-18	1727	\N	6368	\N
25647	GENERIC_DAY	0	4	2009-12-16	1727	\N	6368	\N
25648	GENERIC_DAY	0	4	2009-12-08	1727	\N	6368	\N
25649	GENERIC_DAY	0	4	2009-12-22	1727	\N	6368	\N
25650	GENERIC_DAY	0	4	2009-12-17	1727	\N	6368	\N
25651	GENERIC_DAY	0	4	2009-12-23	1727	\N	6368	\N
25652	GENERIC_DAY	0	4	2009-12-31	1727	\N	6368	\N
25653	GENERIC_DAY	0	4	2009-12-21	1727	\N	6368	\N
25654	GENERIC_DAY	0	4	2009-12-19	1727	\N	6368	\N
25655	GENERIC_DAY	0	4	2009-12-26	1727	\N	6368	\N
25656	GENERIC_DAY	0	4	2009-12-12	1727	\N	6368	\N
25657	GENERIC_DAY	0	4	2009-12-30	1727	\N	6368	\N
25658	GENERIC_DAY	0	4	2009-12-25	1727	\N	6368	\N
25659	GENERIC_DAY	0	4	2009-12-20	1727	\N	6368	\N
25660	GENERIC_DAY	0	4	2009-12-29	1727	\N	6368	\N
25661	GENERIC_DAY	0	4	2009-12-27	1727	\N	6368	\N
48826	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077	\N
48827	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077	\N
48828	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077	\N
48829	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077	\N
48830	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077	\N
48831	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077	\N
48832	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013	\N
48833	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013	\N
48834	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013	\N
48835	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013	\N
48836	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013	\N
48837	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013	\N
48838	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013	\N
48839	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013	\N
48840	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013	\N
48841	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013	\N
48842	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013	\N
48843	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013	\N
48844	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013	\N
48845	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013	\N
48846	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013	\N
48847	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013	\N
48848	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013	\N
48849	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013	\N
48850	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013	\N
48851	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013	\N
48852	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013	\N
48853	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013	\N
48854	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013	\N
48855	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013	\N
48856	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013	\N
48857	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013	\N
48858	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013	\N
48859	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013	\N
25662	GENERIC_DAY	0	4	2009-12-07	1727	\N	6368	\N
25663	GENERIC_DAY	0	4	2009-12-10	1727	\N	6368	\N
25664	GENERIC_DAY	0	4	2009-12-11	1727	\N	6368	\N
25665	GENERIC_DAY	0	4	2009-12-13	1727	\N	6368	\N
25666	GENERIC_DAY	0	4	2009-12-14	1727	\N	6368	\N
25667	GENERIC_DAY	0	4	2009-12-28	1727	\N	6368	\N
25668	GENERIC_DAY	0	4	2009-12-15	1727	\N	6368	\N
25669	GENERIC_DAY	0	4	2009-12-09	1727	\N	6368	\N
25670	GENERIC_DAY	0	4	2009-12-24	1727	\N	6368	\N
48860	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013	\N
48861	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013	\N
48862	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013	\N
48863	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013	\N
48864	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013	\N
48865	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013	\N
48866	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013	\N
48867	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013	\N
48868	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013	\N
48869	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013	\N
48870	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013	\N
48871	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013	\N
48872	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013	\N
48873	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013	\N
48874	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013	\N
48875	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013	\N
48876	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013	\N
48877	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013	\N
48878	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013	\N
48879	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013	\N
48880	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013	\N
48881	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013	\N
48882	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013	\N
48883	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013	\N
48884	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013	\N
48885	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013	\N
48886	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013	\N
48887	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013	\N
48888	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013	\N
48889	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013	\N
48890	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013	\N
48891	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013	\N
48892	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013	\N
48893	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013	\N
48894	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013	\N
48895	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013	\N
48896	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013	\N
48897	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013	\N
48898	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013	\N
48899	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013	\N
48900	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013	\N
48901	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013	\N
48902	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013	\N
48903	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013	\N
48904	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013	\N
48905	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013	\N
48906	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013	\N
48907	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013	\N
48908	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013	\N
48909	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013	\N
48910	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013	\N
48911	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013	\N
48912	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013	\N
48913	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013	\N
48914	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013	\N
48915	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013	\N
48916	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013	\N
48917	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013	\N
48918	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013	\N
48931	GENERIC_DAY	3	0	2010-01-19	37573	\N	41061	\N
48932	GENERIC_DAY	3	1	2010-01-20	36159	\N	41061	\N
48933	GENERIC_DAY	3	3	2010-01-19	40199	\N	41061	\N
48934	GENERIC_DAY	3	4	2010-01-20	40199	\N	41061	\N
48935	GENERIC_DAY	3	3	2010-01-19	36159	\N	41061	\N
48936	GENERIC_DAY	3	0	2010-01-20	37573	\N	41061	\N
48937	GENERIC_DAY	3	1	2010-01-21	36159	\N	41051	\N
48938	GENERIC_DAY	3	1	2010-01-21	37573	\N	41051	\N
48939	GENERIC_DAY	3	2	2010-01-21	40199	\N	41051	\N
48940	GENERIC_DAY	3	1	2010-01-22	36159	\N	41052	\N
48941	GENERIC_DAY	3	1	2010-01-22	40199	\N	41052	\N
48942	GENERIC_DAY	3	2	2010-01-22	37573	\N	41052	\N
48943	GENERIC_DAY	3	0	2010-01-23	37573	\N	41053	\N
48944	GENERIC_DAY	3	0	2010-01-24	40199	\N	41053	\N
48945	GENERIC_DAY	3	0	2010-01-23	36159	\N	41053	\N
48946	GENERIC_DAY	3	1	2010-01-25	40199	\N	41053	\N
48947	GENERIC_DAY	3	0	2010-01-23	40199	\N	41053	\N
48948	GENERIC_DAY	3	0	2010-01-24	36159	\N	41053	\N
48949	GENERIC_DAY	3	2	2010-01-25	37573	\N	41053	\N
48950	GENERIC_DAY	3	1	2010-01-25	36159	\N	41053	\N
48951	GENERIC_DAY	3	0	2010-01-24	37573	\N	41053	\N
24595	GENERIC_DAY	1	2	2010-02-05	1726	\N	19899	\N
24578	GENERIC_DAY	1	3	2010-01-19	1726	\N	19899	\N
24575	GENERIC_DAY	1	2	2010-01-13	1718	\N	19899	\N
24583	GENERIC_DAY	1	3	2010-01-06	1726	\N	19899	\N
24598	GENERIC_DAY	1	3	2010-01-07	1726	\N	19899	\N
24580	GENERIC_DAY	1	0	2010-01-30	1722	\N	19899	\N
24581	GENERIC_DAY	1	2	2010-02-02	1718	\N	19899	\N
24597	GENERIC_DAY	1	0	2010-01-17	1722	\N	19899	\N
24587	GENERIC_DAY	1	2	2010-02-02	1722	\N	19899	\N
24596	GENERIC_DAY	1	2	2010-02-02	1726	\N	19899	\N
24588	GENERIC_DAY	1	2	2010-01-29	1718	\N	19899	\N
24585	GENERIC_DAY	1	2	2010-01-22	1722	\N	19899	\N
24589	GENERIC_DAY	1	3	2010-01-12	1726	\N	19899	\N
24591	GENERIC_DAY	1	0	2009-12-27	1722	\N	19899	\N
24590	GENERIC_DAY	1	0	2010-01-01	1726	\N	19899	\N
24582	GENERIC_DAY	1	3	2009-12-22	1718	\N	19899	\N
24576	GENERIC_DAY	1	0	2009-12-20	1718	\N	19899	\N
24594	GENERIC_DAY	1	0	2010-01-31	1722	\N	19899	\N
24584	GENERIC_DAY	1	0	2010-01-16	1718	\N	19899	\N
24593	GENERIC_DAY	1	2	2009-12-30	1726	\N	19899	\N
24579	GENERIC_DAY	1	2	2010-01-15	1722	\N	19899	\N
24586	GENERIC_DAY	1	2	2010-01-11	1722	\N	19899	\N
24592	GENERIC_DAY	1	2	2010-01-05	1726	\N	19899	\N
24577	GENERIC_DAY	1	2	2010-01-06	1722	\N	19899	\N
37481	GENERIC_DAY	15	0	2010-01-27	36159	\N	36966	\N
37511	GENERIC_DAY	15	1	2010-03-22	36159	\N	36966	\N
37495	GENERIC_DAY	15	0	2010-02-27	36159	\N	36966	\N
37488	GENERIC_DAY	15	1	2010-03-18	36159	\N	36966	\N
37473	GENERIC_DAY	15	0	2010-02-14	36159	\N	36966	\N
37493	GENERIC_DAY	15	1	2010-01-25	36159	\N	36966	\N
37504	GENERIC_DAY	15	0	2010-01-29	36159	\N	36966	\N
37498	GENERIC_DAY	15	2	2010-02-17	36159	\N	36966	\N
37474	GENERIC_DAY	15	0	2010-02-02	36159	\N	36966	\N
37516	GENERIC_DAY	15	0	2010-02-09	36159	\N	36966	\N
37514	GENERIC_DAY	15	2	2010-02-16	36159	\N	36966	\N
37499	GENERIC_DAY	15	0	2010-02-20	36159	\N	36966	\N
37475	GENERIC_DAY	15	0	2010-02-12	36159	\N	36966	\N
37480	GENERIC_DAY	15	1	2010-03-04	36159	\N	36966	\N
37519	GENERIC_DAY	15	0	2010-01-24	36159	\N	36966	\N
37491	GENERIC_DAY	15	1	2010-03-02	36159	\N	36966	\N
37489	GENERIC_DAY	15	0	2010-01-23	36159	\N	36966	\N
37500	GENERIC_DAY	15	0	2010-02-08	36159	\N	36966	\N
37513	GENERIC_DAY	15	1	2010-03-25	36159	\N	36966	\N
37517	GENERIC_DAY	15	1	2010-02-26	36159	\N	36966	\N
45788	GENERIC_DAY	6	0	2010-01-25	36159	\N	41069	\N
37529	GENERIC_DAY	15	0	2010-02-28	36159	\N	36966	\N
37531	GENERIC_DAY	15	0	2010-01-28	36159	\N	36966	\N
37526	GENERIC_DAY	15	1	2010-02-18	36159	\N	36966	\N
37522	GENERIC_DAY	15	1	2010-01-22	36159	\N	36966	\N
37528	GENERIC_DAY	15	1	2010-03-11	36159	\N	36966	\N
37524	GENERIC_DAY	15	1	2010-02-24	36159	\N	36966	\N
37521	GENERIC_DAY	15	0	2010-01-31	36159	\N	36966	\N
37530	GENERIC_DAY	15	0	2010-02-03	36159	\N	36966	\N
37533	GENERIC_DAY	15	1	2010-03-12	36159	\N	36966	\N
37532	GENERIC_DAY	15	0	2010-02-21	36159	\N	36966	\N
37527	GENERIC_DAY	15	0	2010-02-04	36159	\N	36966	\N
37523	GENERIC_DAY	15	1	2010-03-23	36159	\N	36966	\N
37525	GENERIC_DAY	15	0	2010-03-06	36159	\N	36966	\N
43115	GENERIC_DAY	10	0	2010-01-22	36159	\N	41054	\N
43078	GENERIC_DAY	10	0	2010-02-02	37573	\N	41054	\N
43082	GENERIC_DAY	10	1	2010-01-28	40199	\N	41054	\N
43086	GENERIC_DAY	10	0	2010-01-30	37573	\N	41054	\N
43055	GENERIC_DAY	10	1	2010-01-19	40199	\N	41054	\N
43107	GENERIC_DAY	10	0	2010-02-02	36159	\N	41054	\N
43111	GENERIC_DAY	10	0	2010-01-18	37573	\N	41054	\N
43072	GENERIC_DAY	10	0	2010-01-19	37573	\N	41054	\N
43109	GENERIC_DAY	10	0	2010-02-07	36159	\N	41054	\N
43087	GENERIC_DAY	10	0	2010-02-10	40199	\N	41054	\N
43077	GENERIC_DAY	10	0	2010-01-31	37573	\N	41054	\N
43106	GENERIC_DAY	10	0	2010-02-07	40199	\N	41054	\N
43074	GENERIC_DAY	10	0	2010-01-31	36159	\N	41054	\N
43116	GENERIC_DAY	10	0	2010-01-25	37573	\N	41054	\N
43062	GENERIC_DAY	10	0	2010-01-11	40199	\N	41054	\N
43061	GENERIC_DAY	10	0	2010-01-29	37573	\N	41054	\N
43108	GENERIC_DAY	10	1	2010-01-11	36159	\N	41054	\N
43089	GENERIC_DAY	10	1	2010-01-20	40199	\N	41054	\N
43063	GENERIC_DAY	10	0	2010-01-17	40199	\N	41054	\N
43088	GENERIC_DAY	10	1	2010-01-27	40199	\N	41054	\N
43113	GENERIC_DAY	10	0	2010-01-15	36159	\N	41054	\N
43052	GENERIC_DAY	10	0	2010-01-22	40199	\N	41054	\N
43050	GENERIC_DAY	10	0	2010-02-06	40199	\N	41054	\N
43104	GENERIC_DAY	10	1	2010-01-21	37573	\N	41054	\N
37482	GENERIC_DAY	15	0	2010-02-15	36159	\N	36966	\N
37471	GENERIC_DAY	15	1	2010-03-09	36159	\N	36966	\N
37476	GENERIC_DAY	15	1	2010-03-08	36159	\N	36966	\N
37509	GENERIC_DAY	15	1	2010-03-15	36159	\N	36966	\N
37501	GENERIC_DAY	15	0	2010-03-20	36159	\N	36966	\N
37485	GENERIC_DAY	15	1	2010-03-10	36159	\N	36966	\N
37515	GENERIC_DAY	15	0	2010-03-07	36159	\N	36966	\N
37496	GENERIC_DAY	15	0	2010-03-14	36159	\N	36966	\N
37506	GENERIC_DAY	15	0	2010-02-10	36159	\N	36966	\N
37508	GENERIC_DAY	15	1	2010-03-16	36159	\N	36966	\N
37510	GENERIC_DAY	15	1	2010-03-17	36159	\N	36966	\N
37492	GENERIC_DAY	15	1	2010-02-23	36159	\N	36966	\N
37502	GENERIC_DAY	15	0	2010-02-07	36159	\N	36966	\N
37483	GENERIC_DAY	15	0	2010-02-13	36159	\N	36966	\N
37497	GENERIC_DAY	15	1	2010-01-26	36159	\N	36966	\N
37477	GENERIC_DAY	15	1	2010-02-22	36159	\N	36966	\N
37479	GENERIC_DAY	15	0	2010-02-05	36159	\N	36966	\N
37512	GENERIC_DAY	15	0	2010-02-01	36159	\N	36966	\N
37490	GENERIC_DAY	15	1	2010-03-24	36159	\N	36966	\N
37487	GENERIC_DAY	15	0	2010-02-11	36159	\N	36966	\N
37472	GENERIC_DAY	15	1	2010-03-05	36159	\N	36966	\N
37486	GENERIC_DAY	15	1	2010-03-03	36159	\N	36966	\N
37478	GENERIC_DAY	15	0	2010-02-06	36159	\N	36966	\N
37518	GENERIC_DAY	15	0	2010-03-21	36159	\N	36966	\N
37520	GENERIC_DAY	15	1	2010-02-25	36159	\N	36966	\N
37494	GENERIC_DAY	15	1	2010-03-19	36159	\N	36966	\N
37484	GENERIC_DAY	15	0	2010-03-13	36159	\N	36966	\N
37505	GENERIC_DAY	15	1	2010-02-19	36159	\N	36966	\N
37507	GENERIC_DAY	15	1	2010-03-01	36159	\N	36966	\N
37503	GENERIC_DAY	15	0	2010-01-30	36159	\N	36966	\N
37545	GENERIC_DAY	13	0	2010-01-31	37573	\N	38582	\N
37548	GENERIC_DAY	13	0	2010-01-23	37573	\N	38582	\N
37567	GENERIC_DAY	13	1	2010-02-19	36159	\N	38582	\N
37538	GENERIC_DAY	13	0	2010-01-30	37573	\N	38582	\N
37539	GENERIC_DAY	13	2	2010-01-27	37573	\N	38582	\N
37534	GENERIC_DAY	13	0	2010-02-07	36159	\N	38582	\N
37542	GENERIC_DAY	13	1	2010-02-10	37573	\N	38582	\N
37562	GENERIC_DAY	13	2	2010-01-29	37573	\N	38582	\N
37535	GENERIC_DAY	13	0	2010-02-21	37573	\N	38582	\N
37563	GENERIC_DAY	13	0	2010-02-06	37573	\N	38582	\N
37565	GENERIC_DAY	13	0	2010-01-24	36159	\N	38582	\N
37558	GENERIC_DAY	13	2	2010-02-02	36159	\N	38582	\N
37564	GENERIC_DAY	13	2	2010-02-12	36159	\N	38582	\N
37568	GENERIC_DAY	13	2	2010-01-28	37573	\N	38582	\N
37543	GENERIC_DAY	13	0	2010-02-14	36159	\N	38582	\N
37557	GENERIC_DAY	13	2	2010-01-26	37573	\N	38582	\N
37551	GENERIC_DAY	13	1	2010-02-15	37573	\N	38582	\N
37540	GENERIC_DAY	13	0	2010-02-13	36159	\N	38582	\N
37541	GENERIC_DAY	13	1	2010-02-03	37573	\N	38582	\N
37554	GENERIC_DAY	13	2	2010-02-16	37573	\N	38582	\N
37561	GENERIC_DAY	13	2	2010-01-25	36159	\N	38582	\N
37549	GENERIC_DAY	13	2	2010-02-15	36159	\N	38582	\N
37560	GENERIC_DAY	13	2	2010-02-17	37573	\N	38582	\N
37546	GENERIC_DAY	13	2	2010-01-28	36159	\N	38582	\N
37544	GENERIC_DAY	13	2	2010-02-10	36159	\N	38582	\N
37559	GENERIC_DAY	13	0	2010-01-23	36159	\N	38582	\N
37550	GENERIC_DAY	13	2	2010-02-19	37573	\N	38582	\N
37536	GENERIC_DAY	13	2	2010-02-18	37573	\N	38582	\N
37566	GENERIC_DAY	13	2	2010-02-05	36159	\N	38582	\N
37556	GENERIC_DAY	13	2	2010-01-25	37573	\N	38582	\N
37553	GENERIC_DAY	13	2	2010-01-29	36159	\N	38582	\N
37555	GENERIC_DAY	13	1	2010-02-05	37573	\N	38582	\N
37547	GENERIC_DAY	13	1	2010-02-04	37573	\N	38582	\N
37537	GENERIC_DAY	13	2	2010-02-11	36159	\N	38582	\N
37552	GENERIC_DAY	13	2	2010-02-01	37573	\N	38582	\N
24901	GENERIC_DAY	1	2	2010-03-10	1722	\N	19897	\N
24895	GENERIC_DAY	1	3	2010-02-24	1726	\N	19897	\N
24896	GENERIC_DAY	1	4	2010-02-19	1718	\N	19897	\N
24902	GENERIC_DAY	1	0	2010-02-21	1718	\N	19897	\N
24890	GENERIC_DAY	1	2	2010-03-09	1722	\N	19897	\N
24900	GENERIC_DAY	1	0	2010-03-21	1718	\N	19897	\N
24904	GENERIC_DAY	1	0	2010-03-21	1726	\N	19897	\N
24897	GENERIC_DAY	1	1	2010-02-26	1722	\N	19897	\N
24899	GENERIC_DAY	1	4	2010-03-24	1718	\N	19897	\N
24893	GENERIC_DAY	1	0	2010-02-14	1718	\N	19897	\N
24892	GENERIC_DAY	1	0	2010-03-13	1726	\N	19897	\N
24891	GENERIC_DAY	1	4	2010-03-25	1718	\N	19897	\N
24898	GENERIC_DAY	1	0	2010-03-21	1722	\N	19897	\N
24894	GENERIC_DAY	1	0	2010-03-20	1722	\N	19897	\N
24903	GENERIC_DAY	1	3	2010-03-16	1726	\N	19897	\N
38683	GENERIC_DAY	13	2	2010-01-22	37573	\N	38582	\N
38702	GENERIC_DAY	13	2	2010-02-08	36159	\N	38582	\N
38688	GENERIC_DAY	13	0	2010-02-20	36159	\N	38582	\N
38693	GENERIC_DAY	13	0	2010-02-14	37573	\N	38582	\N
38706	GENERIC_DAY	13	0	2010-02-06	36159	\N	38582	\N
38687	GENERIC_DAY	13	1	2010-02-17	36159	\N	38582	\N
38697	GENERIC_DAY	13	1	2010-02-08	37573	\N	38582	\N
38695	GENERIC_DAY	13	2	2010-01-22	36159	\N	38582	\N
38699	GENERIC_DAY	13	0	2010-02-07	37573	\N	38582	\N
38700	GENERIC_DAY	13	1	2010-02-18	36159	\N	38582	\N
47022	GENERIC_DAY	6	2	2010-01-27	36159	\N	41076	\N
47015	GENERIC_DAY	6	0	2010-01-28	37573	\N	41076	\N
47018	GENERIC_DAY	6	2	2010-01-27	37573	\N	41076	\N
38698	GENERIC_DAY	13	0	2010-01-24	37573	\N	38582	\N
37570	GENERIC_DAY	13	1	2010-02-16	36159	\N	38582	\N
38703	GENERIC_DAY	13	0	2010-01-31	36159	\N	38582	\N
38691	GENERIC_DAY	13	2	2010-02-09	36159	\N	38582	\N
37571	GENERIC_DAY	13	1	2010-02-11	37573	\N	38582	\N
38686	GENERIC_DAY	13	0	2010-02-20	37573	\N	38582	\N
38701	GENERIC_DAY	13	1	2010-02-02	37573	\N	38582	\N
38705	GENERIC_DAY	13	0	2010-01-30	36159	\N	38582	\N
38696	GENERIC_DAY	13	1	2010-02-09	37573	\N	38582	\N
38704	GENERIC_DAY	13	0	2010-02-13	37573	\N	38582	\N
38694	GENERIC_DAY	13	2	2010-02-01	36159	\N	38582	\N
38690	GENERIC_DAY	13	2	2010-02-03	36159	\N	38582	\N
38685	GENERIC_DAY	13	2	2010-01-26	36159	\N	38582	\N
38684	GENERIC_DAY	13	2	2010-02-04	36159	\N	38582	\N
37569	GENERIC_DAY	13	2	2010-01-27	36159	\N	38582	\N
38692	GENERIC_DAY	13	1	2010-02-12	37573	\N	38582	\N
38689	GENERIC_DAY	13	0	2010-02-21	36159	\N	38582	\N
45753	GENERIC_DAY	6	0	2010-02-01	36159	\N	41069	\N
45783	GENERIC_DAY	6	0	2010-01-14	36159	\N	41069	\N
45758	GENERIC_DAY	6	1	2010-01-22	40199	\N	41069	\N
45781	GENERIC_DAY	6	0	2010-01-30	36159	\N	41069	\N
45818	GENERIC_DAY	6	0	2010-01-23	37573	\N	41069	\N
45794	GENERIC_DAY	6	0	2010-01-17	40199	\N	41069	\N
45791	GENERIC_DAY	6	1	2010-01-21	36159	\N	41069	\N
45811	GENERIC_DAY	6	0	2010-02-05	36159	\N	41069	\N
45754	GENERIC_DAY	6	0	2010-01-31	37573	\N	41069	\N
45764	GENERIC_DAY	6	0	2010-01-22	36159	\N	41069	\N
45770	GENERIC_DAY	6	0	2010-01-31	36159	\N	41069	\N
45755	GENERIC_DAY	6	0	2010-02-07	40199	\N	41069	\N
45756	GENERIC_DAY	6	0	2010-02-06	40199	\N	41069	\N
45772	GENERIC_DAY	6	0	2010-02-05	40199	\N	41069	\N
45787	GENERIC_DAY	6	1	2010-01-14	40199	\N	41069	\N
30814	SPECIFIC_DAY	0	8	2010-01-08	1722	29807	\N	\N
30815	SPECIFIC_DAY	0	0	2010-01-10	1722	29807	\N	\N
30816	SPECIFIC_DAY	0	0	2010-01-09	1722	29807	\N	\N
30817	SPECIFIC_DAY	0	8	2010-01-18	1722	29807	\N	\N
30818	SPECIFIC_DAY	0	8	2010-01-11	1722	29807	\N	\N
30819	SPECIFIC_DAY	0	8	2010-01-07	1722	29807	\N	\N
30820	SPECIFIC_DAY	0	8	2010-01-12	1722	29807	\N	\N
30821	SPECIFIC_DAY	0	8	2010-01-15	1722	29807	\N	\N
30822	SPECIFIC_DAY	0	8	2010-01-14	1722	29807	\N	\N
30823	SPECIFIC_DAY	0	8	2010-01-13	1722	29807	\N	\N
30824	SPECIFIC_DAY	0	0	2010-01-17	1722	29807	\N	\N
30825	SPECIFIC_DAY	0	0	2010-01-16	1722	29807	\N	\N
121063	SPECIFIC_DAY	0	0	2010-02-28	36159	119895	\N	\N
121064	SPECIFIC_DAY	0	0	2010-02-20	36159	119895	\N	\N
121065	SPECIFIC_DAY	0	0	2010-03-06	36159	119895	\N	\N
121066	SPECIFIC_DAY	0	7	2010-03-04	36159	119895	\N	\N
121067	SPECIFIC_DAY	0	0	2010-03-07	36159	119895	\N	\N
121068	SPECIFIC_DAY	0	7	2010-02-22	36159	119895	\N	\N
121069	SPECIFIC_DAY	0	0	2010-02-27	36159	119895	\N	\N
121070	SPECIFIC_DAY	0	7	2010-02-25	36159	119895	\N	\N
121071	SPECIFIC_DAY	0	7	2010-03-12	36159	119895	\N	\N
121072	SPECIFIC_DAY	0	7	2010-02-23	36159	119895	\N	\N
121073	SPECIFIC_DAY	0	7	2010-03-01	36159	119895	\N	\N
121074	SPECIFIC_DAY	0	7	2010-02-18	36159	119895	\N	\N
121075	SPECIFIC_DAY	0	7	2010-02-24	36159	119895	\N	\N
121076	SPECIFIC_DAY	0	7	2010-03-10	36159	119895	\N	\N
121077	SPECIFIC_DAY	0	0	2010-03-14	36159	119895	\N	\N
121078	SPECIFIC_DAY	0	7	2010-03-15	36159	119895	\N	\N
121079	SPECIFIC_DAY	0	7	2010-02-26	36159	119895	\N	\N
121080	SPECIFIC_DAY	0	7	2010-02-19	36159	119895	\N	\N
121081	SPECIFIC_DAY	0	0	2010-02-21	36159	119895	\N	\N
121082	SPECIFIC_DAY	0	7	2010-03-09	36159	119895	\N	\N
121083	SPECIFIC_DAY	0	7	2010-03-03	36159	119895	\N	\N
121084	SPECIFIC_DAY	0	7	2010-02-16	36159	119895	\N	\N
121085	SPECIFIC_DAY	0	7	2010-03-11	36159	119895	\N	\N
121086	SPECIFIC_DAY	0	7	2010-02-17	36159	119895	\N	\N
121087	SPECIFIC_DAY	0	7	2010-03-05	36159	119895	\N	\N
121088	SPECIFIC_DAY	0	7	2010-03-02	36159	119895	\N	\N
121089	SPECIFIC_DAY	0	0	2010-03-13	36159	119895	\N	\N
121090	SPECIFIC_DAY	0	7	2010-03-08	36159	119895	\N	\N
121091	SPECIFIC_DAY	0	7	2010-04-01	37573	115380	\N	\N
121092	SPECIFIC_DAY	0	7	2010-03-31	37573	115380	\N	\N
121093	SPECIFIC_DAY	0	7	2010-03-26	37573	115380	\N	\N
121094	SPECIFIC_DAY	0	7	2010-03-29	37573	115380	\N	\N
121095	SPECIFIC_DAY	0	7	2010-04-02	37573	115380	\N	\N
121096	SPECIFIC_DAY	0	0	2010-03-28	37573	115380	\N	\N
121097	SPECIFIC_DAY	0	7	2010-03-30	37573	115380	\N	\N
121098	SPECIFIC_DAY	0	0	2010-03-27	37573	115380	\N	\N
121099	SPECIFIC_DAY	0	7	2010-04-05	37573	115381	\N	\N
121100	SPECIFIC_DAY	0	7	2010-04-12	37573	115381	\N	\N
121101	SPECIFIC_DAY	0	7	2010-04-06	37573	115381	\N	\N
121102	SPECIFIC_DAY	0	7	2010-04-08	37573	115381	\N	\N
121103	SPECIFIC_DAY	0	7	2010-04-07	37573	115381	\N	\N
121104	SPECIFIC_DAY	0	0	2010-04-04	37573	115381	\N	\N
121105	SPECIFIC_DAY	0	0	2010-04-11	37573	115381	\N	\N
121106	SPECIFIC_DAY	0	7	2010-04-09	37573	115381	\N	\N
121107	SPECIFIC_DAY	0	0	2010-04-10	37573	115381	\N	\N
121108	SPECIFIC_DAY	0	7	2010-04-14	37573	115381	\N	\N
121109	SPECIFIC_DAY	0	0	2010-04-03	37573	115381	\N	\N
121110	SPECIFIC_DAY	0	7	2010-04-13	37573	115381	\N	\N
121111	SPECIFIC_DAY	0	7	2010-03-25	49300	119894	\N	\N
38723	GENERIC_DAY	6	0	2010-02-27	36159	\N	38583	\N
38726	GENERIC_DAY	6	5	2010-03-08	37573	\N	38583	\N
38727	GENERIC_DAY	6	5	2010-03-10	37573	\N	38583	\N
38724	GENERIC_DAY	6	5	2010-03-04	37573	\N	38583	\N
38722	GENERIC_DAY	6	0	2010-02-27	37573	\N	38583	\N
38729	GENERIC_DAY	6	4	2010-03-15	37573	\N	38583	\N
38728	GENERIC_DAY	6	5	2010-03-02	37573	\N	38583	\N
38719	GENERIC_DAY	6	4	2010-02-23	37573	\N	38583	\N
38721	GENERIC_DAY	6	0	2010-03-06	37573	\N	38583	\N
38720	GENERIC_DAY	6	3	2010-03-04	36159	\N	38583	\N
38718	GENERIC_DAY	6	4	2010-02-25	37573	\N	38583	\N
38717	GENERIC_DAY	6	0	2010-03-13	37573	\N	38583	\N
38725	GENERIC_DAY	6	3	2010-03-10	36159	\N	38583	\N
45751	GENERIC_DAY	6	0	2010-02-01	37573	\N	41069	\N
121112	SPECIFIC_DAY	0	7	2010-05-21	49300	119894	\N	\N
121113	SPECIFIC_DAY	0	0	2010-03-07	49300	119894	\N	\N
121114	SPECIFIC_DAY	0	0	2010-04-25	49300	119894	\N	\N
121115	SPECIFIC_DAY	0	0	2010-04-04	49300	119894	\N	\N
121116	SPECIFIC_DAY	0	0	2010-05-01	49300	119894	\N	\N
121117	SPECIFIC_DAY	0	7	2010-04-19	49300	119894	\N	\N
121118	SPECIFIC_DAY	0	0	2010-03-20	49300	119894	\N	\N
121119	SPECIFIC_DAY	0	0	2010-04-11	49300	119894	\N	\N
121120	SPECIFIC_DAY	0	7	2010-03-15	49300	119894	\N	\N
121121	SPECIFIC_DAY	0	0	2010-04-17	49300	119894	\N	\N
121122	SPECIFIC_DAY	0	7	2010-05-07	49300	119894	\N	\N
121123	SPECIFIC_DAY	0	7	2010-04-27	49300	119894	\N	\N
121124	SPECIFIC_DAY	0	0	2010-05-16	49300	119894	\N	\N
121125	SPECIFIC_DAY	0	7	2010-05-19	49300	119894	\N	\N
121126	SPECIFIC_DAY	0	7	2010-04-20	49300	119894	\N	\N
121127	SPECIFIC_DAY	0	7	2010-03-18	49300	119894	\N	\N
121128	SPECIFIC_DAY	0	7	2010-03-22	49300	119894	\N	\N
121129	SPECIFIC_DAY	0	0	2010-05-15	49300	119894	\N	\N
121130	SPECIFIC_DAY	0	7	2010-03-05	49300	119894	\N	\N
121131	SPECIFIC_DAY	0	0	2010-03-27	49300	119894	\N	\N
121132	SPECIFIC_DAY	0	0	2010-03-21	49300	119894	\N	\N
121133	SPECIFIC_DAY	0	7	2010-04-28	49300	119894	\N	\N
121134	SPECIFIC_DAY	0	7	2010-05-03	49300	119894	\N	\N
121135	SPECIFIC_DAY	0	7	2010-05-11	49300	119894	\N	\N
121136	SPECIFIC_DAY	0	7	2010-05-14	49300	119894	\N	\N
121137	SPECIFIC_DAY	0	0	2010-03-13	49300	119894	\N	\N
121138	SPECIFIC_DAY	0	7	2010-05-12	49300	119894	\N	\N
121139	SPECIFIC_DAY	0	7	2010-04-22	49300	119894	\N	\N
121140	SPECIFIC_DAY	0	7	2010-04-14	49300	119894	\N	\N
121141	SPECIFIC_DAY	0	7	2010-03-04	49300	119894	\N	\N
121142	SPECIFIC_DAY	0	7	2010-05-20	49300	119894	\N	\N
121143	SPECIFIC_DAY	0	7	2010-04-26	49300	119894	\N	\N
121144	SPECIFIC_DAY	0	7	2010-03-24	49300	119894	\N	\N
121145	SPECIFIC_DAY	0	0	2010-04-10	49300	119894	\N	\N
121146	SPECIFIC_DAY	0	7	2010-04-08	49300	119894	\N	\N
121147	SPECIFIC_DAY	0	7	2010-05-10	49300	119894	\N	\N
121148	SPECIFIC_DAY	0	7	2010-05-05	49300	119894	\N	\N
45761	GENERIC_DAY	6	0	2010-01-30	40199	\N	41069	\N
45789	GENERIC_DAY	6	1	2010-01-15	40199	\N	41069	\N
45785	GENERIC_DAY	6	0	2010-02-09	37573	\N	41069	\N
45769	GENERIC_DAY	6	0	2010-01-24	40199	\N	41069	\N
45782	GENERIC_DAY	6	0	2010-02-10	37573	\N	41069	\N
45810	GENERIC_DAY	6	0	2010-02-07	37573	\N	41069	\N
45775	GENERIC_DAY	6	0	2010-01-13	37573	\N	41069	\N
45757	GENERIC_DAY	6	1	2010-01-27	40199	\N	41069	\N
45808	GENERIC_DAY	6	0	2010-01-29	40199	\N	41069	\N
45793	GENERIC_DAY	6	0	2010-01-16	40199	\N	41069	\N
45816	GENERIC_DAY	6	0	2010-02-02	37573	\N	41069	\N
45777	GENERIC_DAY	6	1	2010-01-19	36159	\N	41069	\N
45790	GENERIC_DAY	6	0	2010-02-11	37573	\N	41069	\N
45795	GENERIC_DAY	6	0	2010-01-16	37573	\N	41069	\N
45786	GENERIC_DAY	6	0	2010-01-25	37573	\N	41069	\N
45763	GENERIC_DAY	6	0	2010-01-11	36159	\N	41069	\N
45767	GENERIC_DAY	6	0	2010-01-26	37573	\N	41069	\N
45780	GENERIC_DAY	6	0	2010-01-17	37573	\N	41069	\N
45809	GENERIC_DAY	6	0	2010-01-11	40199	\N	41069	\N
45779	GENERIC_DAY	6	0	2010-01-20	36159	\N	41069	\N
45762	GENERIC_DAY	6	0	2010-01-30	37573	\N	41069	\N
45768	GENERIC_DAY	6	0	2010-01-27	37573	\N	41069	\N
45759	GENERIC_DAY	6	1	2010-01-13	36159	\N	41069	\N
45812	GENERIC_DAY	6	0	2010-01-17	36159	\N	41069	\N
45773	GENERIC_DAY	6	0	2010-01-24	37573	\N	41069	\N
45817	GENERIC_DAY	6	0	2010-02-08	40199	\N	41069	\N
45814	GENERIC_DAY	6	0	2010-02-05	37573	\N	41069	\N
45776	GENERIC_DAY	6	0	2010-02-09	40199	\N	41069	\N
45774	GENERIC_DAY	6	0	2010-02-02	36159	\N	41069	\N
45778	GENERIC_DAY	6	1	2010-01-20	37573	\N	41069	\N
45813	GENERIC_DAY	6	1	2010-01-11	37573	\N	41069	\N
45752	GENERIC_DAY	6	0	2010-01-28	36159	\N	41069	\N
45765	GENERIC_DAY	6	0	2010-01-15	37573	\N	41069	\N
45815	GENERIC_DAY	6	0	2010-02-11	36159	\N	41069	\N
45766	GENERIC_DAY	6	1	2010-01-28	37573	\N	41069	\N
45760	GENERIC_DAY	6	0	2010-01-23	40199	\N	41069	\N
45771	GENERIC_DAY	6	0	2010-02-08	37573	\N	41069	\N
45792	GENERIC_DAY	6	0	2010-01-29	36159	\N	41069	\N
45784	GENERIC_DAY	6	0	2010-01-23	36159	\N	41069	\N
38731	GENERIC_DAY	6	0	2010-02-28	36159	\N	38583	\N
38755	GENERIC_DAY	6	5	2010-03-11	37573	\N	38583	\N
38748	GENERIC_DAY	6	4	2010-02-23	36159	\N	38583	\N
38740	GENERIC_DAY	6	5	2010-03-05	37573	\N	38583	\N
38760	GENERIC_DAY	6	3	2010-03-09	36159	\N	38583	\N
38754	GENERIC_DAY	6	0	2010-03-07	36159	\N	38583	\N
38758	GENERIC_DAY	6	5	2010-02-22	37573	\N	38583	\N
38749	GENERIC_DAY	6	3	2010-03-12	36159	\N	38583	\N
38738	GENERIC_DAY	6	4	2010-02-26	37573	\N	38583	\N
38750	GENERIC_DAY	6	5	2010-03-01	37573	\N	38583	\N
38739	GENERIC_DAY	6	0	2010-03-07	37573	\N	38583	\N
38743	GENERIC_DAY	6	2	2010-03-15	36159	\N	38583	\N
38737	GENERIC_DAY	6	0	2010-02-28	37573	\N	38583	\N
38751	GENERIC_DAY	6	4	2010-02-24	36159	\N	38583	\N
121149	SPECIFIC_DAY	0	7	2010-03-08	49300	119894	\N	\N
121150	SPECIFIC_DAY	0	7	2010-04-12	49300	119894	\N	\N
121151	SPECIFIC_DAY	0	7	2010-03-10	49300	119894	\N	\N
121152	SPECIFIC_DAY	0	7	2010-03-26	49300	119894	\N	\N
121153	SPECIFIC_DAY	0	7	2010-04-02	49300	119894	\N	\N
121154	SPECIFIC_DAY	0	7	2010-03-16	49300	119894	\N	\N
121155	SPECIFIC_DAY	0	7	2010-04-16	49300	119894	\N	\N
121156	SPECIFIC_DAY	0	7	2010-04-15	49300	119894	\N	\N
121157	SPECIFIC_DAY	0	0	2010-03-06	49300	119894	\N	\N
121158	SPECIFIC_DAY	0	7	2010-05-04	49300	119894	\N	\N
121159	SPECIFIC_DAY	0	0	2010-03-14	49300	119894	\N	\N
121160	SPECIFIC_DAY	0	7	2010-03-29	49300	119894	\N	\N
121161	SPECIFIC_DAY	0	7	2010-04-07	49300	119894	\N	\N
121162	SPECIFIC_DAY	0	7	2010-04-23	49300	119894	\N	\N
121163	SPECIFIC_DAY	0	7	2010-04-21	49300	119894	\N	\N
121164	SPECIFIC_DAY	0	7	2010-03-31	49300	119894	\N	\N
121165	SPECIFIC_DAY	0	7	2010-04-01	49300	119894	\N	\N
30826	GENERIC_DAY	3	3	2010-03-29	1724	\N	29808	\N
30827	GENERIC_DAY	3	3	2010-04-02	1724	\N	29808	\N
30828	GENERIC_DAY	3	3	2010-02-26	1724	\N	29808	\N
30829	GENERIC_DAY	3	3	2010-02-11	1724	\N	29808	\N
30830	GENERIC_DAY	3	2	2010-04-14	1724	\N	29808	\N
30831	GENERIC_DAY	3	3	2010-03-16	1724	\N	29808	\N
30832	GENERIC_DAY	3	3	2010-02-15	1724	\N	29808	\N
30833	GENERIC_DAY	3	3	2010-03-22	1724	\N	29808	\N
30834	GENERIC_DAY	3	3	2010-01-27	1724	\N	29808	\N
30835	GENERIC_DAY	3	3	2010-01-13	1724	\N	29808	\N
30836	GENERIC_DAY	3	3	2010-02-09	1724	\N	29808	\N
30837	GENERIC_DAY	3	3	2010-02-23	1724	\N	29808	\N
30838	GENERIC_DAY	3	3	2010-02-22	1724	\N	29808	\N
30839	GENERIC_DAY	3	3	2010-03-18	1724	\N	29808	\N
30840	GENERIC_DAY	3	2	2010-04-06	1724	\N	29808	\N
30841	GENERIC_DAY	3	3	2010-03-08	1724	\N	29808	\N
30842	GENERIC_DAY	3	3	2010-03-04	1724	\N	29808	\N
30843	GENERIC_DAY	3	3	2010-03-19	1724	\N	29808	\N
30844	GENERIC_DAY	3	0	2010-02-28	1724	\N	29808	\N
30845	GENERIC_DAY	3	3	2010-03-15	1724	\N	29808	\N
30846	GENERIC_DAY	3	3	2010-03-01	1724	\N	29808	\N
30847	GENERIC_DAY	3	0	2010-01-16	1724	\N	29808	\N
24498	GENERIC_DAY	4	11	2009-11-03	1727	\N	3955	\N
24509	GENERIC_DAY	4	10	2010-01-19	1727	\N	3955	\N
24504	GENERIC_DAY	4	10	2010-01-11	1727	\N	3955	\N
24499	GENERIC_DAY	4	10	2009-12-15	1727	\N	3955	\N
24493	GENERIC_DAY	4	10	2010-01-18	1727	\N	3955	\N
24497	GENERIC_DAY	4	10	2010-01-14	1727	\N	3955	\N
24508	GENERIC_DAY	4	10	2009-11-19	1727	\N	3955	\N
24496	GENERIC_DAY	4	2	2009-11-21	1727	\N	3955	\N
24494	GENERIC_DAY	4	2	2009-11-07	1727	\N	3955	\N
24500	GENERIC_DAY	4	2	2010-01-01	1727	\N	3955	\N
24510	GENERIC_DAY	4	10	2009-12-10	1727	\N	3955	\N
24502	GENERIC_DAY	4	2	2009-12-12	1727	\N	3955	\N
24505	GENERIC_DAY	4	10	2010-01-25	1727	\N	3955	\N
24501	GENERIC_DAY	4	10	2009-12-17	1727	\N	3955	\N
24512	GENERIC_DAY	4	10	2010-02-11	1727	\N	3955	\N
30848	GENERIC_DAY	3	2	2010-04-16	1724	\N	29808	\N
30849	GENERIC_DAY	3	0	2010-02-14	1724	\N	29808	\N
30850	GENERIC_DAY	3	0	2010-01-31	1724	\N	29808	\N
30851	GENERIC_DAY	3	3	2010-01-26	1724	\N	29808	\N
30852	GENERIC_DAY	3	3	2010-01-14	1724	\N	29808	\N
30853	GENERIC_DAY	3	3	2010-02-18	1724	\N	29808	\N
30854	GENERIC_DAY	3	3	2010-03-26	1724	\N	29808	\N
30855	GENERIC_DAY	3	0	2010-02-20	1724	\N	29808	\N
30856	GENERIC_DAY	3	3	2010-02-03	1724	\N	29808	\N
30857	GENERIC_DAY	3	0	2010-02-13	1724	\N	29808	\N
30858	GENERIC_DAY	3	3	2010-03-03	1724	\N	29808	\N
30859	GENERIC_DAY	3	2	2010-04-09	1724	\N	29808	\N
30860	GENERIC_DAY	3	0	2010-03-28	1724	\N	29808	\N
30861	GENERIC_DAY	3	0	2010-04-17	1724	\N	29808	\N
121166	SPECIFIC_DAY	0	7	2010-03-19	49300	119894	\N	\N
121167	SPECIFIC_DAY	0	7	2010-04-05	49300	119894	\N	\N
121168	SPECIFIC_DAY	0	7	2010-03-12	49300	119894	\N	\N
121169	SPECIFIC_DAY	0	7	2010-04-29	49300	119894	\N	\N
121170	SPECIFIC_DAY	0	7	2010-05-13	49300	119894	\N	\N
121171	SPECIFIC_DAY	0	7	2010-04-30	49300	119894	\N	\N
121172	SPECIFIC_DAY	0	7	2010-04-09	49300	119894	\N	\N
121173	SPECIFIC_DAY	0	7	2010-05-18	49300	119894	\N	\N
121174	SPECIFIC_DAY	0	7	2010-04-06	49300	119894	\N	\N
121175	SPECIFIC_DAY	0	7	2010-03-09	49300	119894	\N	\N
121176	SPECIFIC_DAY	0	0	2010-05-09	49300	119894	\N	\N
121177	SPECIFIC_DAY	0	7	2010-03-23	49300	119894	\N	\N
121178	SPECIFIC_DAY	0	7	2010-04-13	49300	119894	\N	\N
121179	SPECIFIC_DAY	0	7	2010-03-17	49300	119894	\N	\N
121180	SPECIFIC_DAY	0	7	2010-03-30	49300	119894	\N	\N
121181	SPECIFIC_DAY	0	0	2010-05-08	49300	119894	\N	\N
121182	SPECIFIC_DAY	0	0	2010-04-03	49300	119894	\N	\N
121183	SPECIFIC_DAY	0	7	2010-03-03	49300	119894	\N	\N
121184	SPECIFIC_DAY	0	7	2010-03-11	49300	119894	\N	\N
121185	SPECIFIC_DAY	0	0	2010-03-28	49300	119894	\N	\N
121186	SPECIFIC_DAY	0	0	2010-04-18	49300	119894	\N	\N
121187	SPECIFIC_DAY	0	0	2010-05-02	49300	119894	\N	\N
121188	SPECIFIC_DAY	0	0	2010-04-24	49300	119894	\N	\N
121189	SPECIFIC_DAY	0	7	2010-05-17	49300	119894	\N	\N
121190	SPECIFIC_DAY	0	7	2010-05-06	49300	119894	\N	\N
121191	SPECIFIC_DAY	0	7	2010-02-17	49297	119904	\N	\N
121192	SPECIFIC_DAY	0	7	2010-02-11	49297	119904	\N	\N
121193	SPECIFIC_DAY	0	7	2010-02-10	49297	119904	\N	\N
121194	SPECIFIC_DAY	0	0	2010-02-13	49297	119904	\N	\N
121195	SPECIFIC_DAY	0	0	2010-02-14	49297	119904	\N	\N
121196	SPECIFIC_DAY	0	7	2010-02-16	49297	119904	\N	\N
121197	SPECIFIC_DAY	0	0	2010-02-06	49297	119904	\N	\N
121198	SPECIFIC_DAY	0	7	2010-02-18	49297	119904	\N	\N
121199	SPECIFIC_DAY	0	7	2010-02-08	49297	119904	\N	\N
121200	SPECIFIC_DAY	0	7	2010-02-15	49297	119904	\N	\N
121201	SPECIFIC_DAY	0	0	2010-02-07	49297	119904	\N	\N
121202	SPECIFIC_DAY	0	7	2010-02-12	49297	119904	\N	\N
121203	SPECIFIC_DAY	0	7	2010-02-09	49297	119904	\N	\N
121204	SPECIFIC_DAY	0	4	2010-03-10	49309	115437	\N	\N
121205	SPECIFIC_DAY	0	2	2010-03-11	49309	115437	\N	\N
121206	SPECIFIC_DAY	0	0	2010-03-06	49309	115437	\N	\N
121207	SPECIFIC_DAY	0	4	2010-03-02	49309	115437	\N	\N
121208	SPECIFIC_DAY	0	4	2010-03-01	49309	115437	\N	\N
121209	SPECIFIC_DAY	0	0	2010-02-27	49309	115437	\N	\N
121210	SPECIFIC_DAY	0	0	2010-03-07	49309	115437	\N	\N
121211	SPECIFIC_DAY	0	4	2010-03-03	49309	115437	\N	\N
121212	SPECIFIC_DAY	0	4	2010-02-25	49309	115437	\N	\N
121213	SPECIFIC_DAY	0	0	2010-02-28	49309	115437	\N	\N
121214	SPECIFIC_DAY	0	4	2010-03-04	49309	115437	\N	\N
121215	SPECIFIC_DAY	0	4	2010-03-08	49309	115437	\N	\N
121216	SPECIFIC_DAY	0	4	2010-03-05	49309	115437	\N	\N
121217	SPECIFIC_DAY	0	4	2010-03-09	49309	115437	\N	\N
121218	SPECIFIC_DAY	0	4	2010-02-26	49309	115437	\N	\N
121219	SPECIFIC_DAY	0	0	2010-03-06	37573	115364	\N	\N
121220	SPECIFIC_DAY	0	0	2010-02-13	37573	115364	\N	\N
121221	SPECIFIC_DAY	0	7	2010-03-12	37573	115364	\N	\N
121222	SPECIFIC_DAY	0	7	2010-02-12	37573	115364	\N	\N
121223	SPECIFIC_DAY	0	7	2010-02-18	37573	115364	\N	\N
121224	SPECIFIC_DAY	0	0	2010-02-27	37573	115364	\N	\N
121225	SPECIFIC_DAY	0	7	2010-02-17	37573	115364	\N	\N
121226	SPECIFIC_DAY	0	7	2010-02-16	37573	115364	\N	\N
121227	SPECIFIC_DAY	0	7	2010-03-04	37573	115364	\N	\N
121228	SPECIFIC_DAY	0	7	2010-02-25	37573	115364	\N	\N
121229	SPECIFIC_DAY	0	7	2010-03-09	37573	115364	\N	\N
121230	SPECIFIC_DAY	0	7	2010-02-15	37573	115364	\N	\N
121231	SPECIFIC_DAY	0	0	2010-03-07	37573	115364	\N	\N
121232	SPECIFIC_DAY	0	7	2010-03-11	37573	115364	\N	\N
121233	SPECIFIC_DAY	0	7	2010-03-03	37573	115364	\N	\N
121234	SPECIFIC_DAY	0	7	2010-03-15	37573	115364	\N	\N
121235	SPECIFIC_DAY	0	0	2010-02-20	37573	115364	\N	\N
121236	SPECIFIC_DAY	0	7	2010-02-22	37573	115364	\N	\N
121237	SPECIFIC_DAY	0	0	2010-03-14	37573	115364	\N	\N
121238	SPECIFIC_DAY	0	0	2010-03-13	37573	115364	\N	\N
121239	SPECIFIC_DAY	0	7	2010-03-05	37573	115364	\N	\N
121240	SPECIFIC_DAY	0	0	2010-02-21	37573	115364	\N	\N
121241	SPECIFIC_DAY	0	0	2010-02-14	37573	115364	\N	\N
121242	SPECIFIC_DAY	0	7	2010-03-02	37573	115364	\N	\N
121243	SPECIFIC_DAY	0	7	2010-02-19	37573	115364	\N	\N
121244	SPECIFIC_DAY	0	7	2010-02-24	37573	115364	\N	\N
121245	SPECIFIC_DAY	0	7	2010-03-10	37573	115364	\N	\N
121246	SPECIFIC_DAY	0	7	2010-02-23	37573	115364	\N	\N
121247	SPECIFIC_DAY	0	0	2010-02-28	37573	115364	\N	\N
121248	SPECIFIC_DAY	0	7	2010-03-08	37573	115364	\N	\N
121249	SPECIFIC_DAY	0	7	2010-03-01	37573	115364	\N	\N
121250	SPECIFIC_DAY	0	7	2010-02-26	37573	115364	\N	\N
121251	SPECIFIC_DAY	0	7	2010-04-16	37573	115442	\N	\N
121252	SPECIFIC_DAY	0	7	2010-04-23	37573	115442	\N	\N
121253	SPECIFIC_DAY	0	0	2010-04-18	37573	115442	\N	\N
121254	SPECIFIC_DAY	0	0	2010-04-25	37573	115442	\N	\N
121255	SPECIFIC_DAY	0	7	2010-04-15	37573	115442	\N	\N
121256	SPECIFIC_DAY	0	7	2010-04-26	37573	115442	\N	\N
121257	SPECIFIC_DAY	0	0	2010-04-24	37573	115442	\N	\N
121258	SPECIFIC_DAY	0	7	2010-04-19	37573	115442	\N	\N
121259	SPECIFIC_DAY	0	7	2010-04-22	37573	115442	\N	\N
121260	SPECIFIC_DAY	0	7	2010-04-20	37573	115442	\N	\N
121261	SPECIFIC_DAY	0	0	2010-04-17	37573	115442	\N	\N
121262	SPECIFIC_DAY	0	7	2010-04-21	37573	115442	\N	\N
45801	GENERIC_DAY	6	0	2010-01-24	36159	\N	41069	\N
45796	GENERIC_DAY	6	0	2010-02-08	36159	\N	41069	\N
45797	GENERIC_DAY	6	0	2010-02-10	36159	\N	41069	\N
45800	GENERIC_DAY	6	0	2010-01-20	40199	\N	41069	\N
45798	GENERIC_DAY	6	0	2010-02-11	40199	\N	41069	\N
45807	GENERIC_DAY	6	0	2010-02-02	40199	\N	41069	\N
45804	GENERIC_DAY	6	0	2010-02-06	37573	\N	41069	\N
45805	GENERIC_DAY	6	0	2010-01-12	40199	\N	41069	\N
45806	GENERIC_DAY	6	0	2010-01-21	37573	\N	41069	\N
45802	GENERIC_DAY	6	0	2010-01-18	40199	\N	41069	\N
45799	GENERIC_DAY	6	0	2010-02-03	37573	\N	41069	\N
45803	GENERIC_DAY	6	0	2010-01-14	37573	\N	41069	\N
121263	SPECIFIC_DAY	0	7	2010-04-27	37573	115442	\N	\N
121264	SPECIFIC_DAY	0	0	2010-05-02	37573	119887	\N	\N
121265	SPECIFIC_DAY	0	0	2010-05-01	37573	119887	\N	\N
121266	SPECIFIC_DAY	0	7	2010-04-30	37573	119887	\N	\N
121267	SPECIFIC_DAY	0	7	2010-05-03	37573	119887	\N	\N
121268	SPECIFIC_DAY	0	7	2010-05-05	37573	119887	\N	\N
121269	SPECIFIC_DAY	0	7	2010-04-28	37573	119887	\N	\N
121270	SPECIFIC_DAY	0	7	2010-05-04	37573	119887	\N	\N
121271	SPECIFIC_DAY	0	7	2010-04-29	37573	119887	\N	\N
121272	SPECIFIC_DAY	0	7	2010-03-16	37573	115365	\N	\N
121273	SPECIFIC_DAY	0	7	2010-03-19	37573	115365	\N	\N
121274	SPECIFIC_DAY	0	7	2010-03-18	37573	115365	\N	\N
121275	SPECIFIC_DAY	0	7	2010-03-17	37573	115365	\N	\N
121276	SPECIFIC_DAY	0	7	2010-03-23	37573	115366	\N	\N
121277	SPECIFIC_DAY	0	7	2010-03-24	37573	115366	\N	\N
121278	SPECIFIC_DAY	0	7	2010-03-25	37573	115366	\N	\N
121279	SPECIFIC_DAY	0	0	2010-03-21	37573	115366	\N	\N
121280	SPECIFIC_DAY	0	0	2010-03-20	37573	115366	\N	\N
121281	SPECIFIC_DAY	0	7	2010-03-22	37573	115366	\N	\N
121282	SPECIFIC_DAY	0	0	2010-02-13	36159	115441	\N	\N
121283	SPECIFIC_DAY	0	7	2010-02-15	36159	115441	\N	\N
121284	SPECIFIC_DAY	0	7	2010-02-09	36159	115441	\N	\N
121285	SPECIFIC_DAY	0	7	2010-02-10	36159	115441	\N	\N
121286	SPECIFIC_DAY	0	7	2010-02-11	36159	115441	\N	\N
121287	SPECIFIC_DAY	0	0	2010-02-14	36159	115441	\N	\N
121288	SPECIFIC_DAY	0	7	2010-02-12	36159	115441	\N	\N
121289	SPECIFIC_DAY	0	7	2010-02-04	49297	119905	\N	\N
121290	SPECIFIC_DAY	0	7	2010-02-02	49297	119905	\N	\N
121291	SPECIFIC_DAY	0	7	2010-02-03	49297	119905	\N	\N
121292	SPECIFIC_DAY	0	7	2010-02-05	49297	119905	\N	\N
121293	SPECIFIC_DAY	0	7	2010-02-01	49297	119905	\N	\N
47797	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077	\N
47798	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077	\N
47799	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077	\N
47800	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077	\N
47801	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077	\N
47802	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077	\N
47803	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077	\N
47804	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077	\N
47805	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077	\N
47806	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077	\N
47807	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077	\N
47808	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077	\N
47809	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077	\N
47810	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077	\N
47811	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077	\N
47812	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077	\N
47813	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077	\N
47814	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077	\N
47815	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077	\N
47816	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077	\N
47817	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077	\N
47818	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013	\N
47819	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013	\N
47820	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013	\N
47821	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013	\N
47822	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013	\N
47823	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013	\N
47824	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013	\N
47825	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013	\N
47826	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013	\N
47827	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013	\N
47828	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013	\N
47829	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013	\N
47830	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013	\N
47831	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013	\N
47832	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013	\N
47833	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013	\N
47834	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013	\N
47835	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013	\N
47836	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013	\N
47837	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013	\N
47838	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013	\N
47839	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013	\N
47840	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013	\N
47841	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013	\N
47842	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013	\N
47843	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013	\N
47844	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013	\N
47845	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013	\N
47846	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013	\N
47847	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013	\N
47848	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013	\N
47849	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013	\N
47850	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013	\N
47851	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013	\N
47852	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013	\N
47853	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013	\N
47854	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013	\N
47855	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013	\N
47856	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013	\N
47857	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013	\N
47858	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013	\N
47859	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013	\N
47860	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013	\N
47861	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013	\N
47862	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013	\N
47863	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013	\N
47864	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013	\N
47865	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013	\N
47866	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013	\N
47867	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013	\N
47868	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013	\N
47869	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013	\N
47870	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013	\N
47871	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013	\N
47872	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013	\N
47873	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013	\N
47874	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013	\N
47875	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013	\N
47876	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013	\N
47877	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013	\N
47878	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013	\N
47879	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013	\N
47880	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013	\N
47881	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013	\N
47882	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013	\N
47883	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013	\N
47884	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013	\N
47885	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013	\N
47886	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013	\N
47887	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013	\N
47888	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013	\N
47889	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013	\N
47890	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013	\N
47891	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013	\N
47892	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013	\N
47893	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013	\N
47894	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013	\N
47895	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013	\N
47896	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013	\N
47020	GENERIC_DAY	6	2	2010-01-26	37573	\N	41076	\N
47021	GENERIC_DAY	6	0	2010-01-26	36159	\N	41076	\N
47014	GENERIC_DAY	6	4	2010-01-26	40199	\N	41076	\N
47019	GENERIC_DAY	6	1	2010-01-28	40199	\N	41076	\N
47017	GENERIC_DAY	6	2	2010-01-27	40199	\N	41076	\N
47016	GENERIC_DAY	6	1	2010-01-28	36159	\N	41076	\N
47897	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013	\N
47898	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013	\N
47899	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013	\N
47900	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013	\N
47901	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013	\N
47902	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013	\N
47903	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013	\N
47904	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013	\N
66243	SPECIFIC_DAY	23	0	2010-01-03	49289	66055	\N	\N
66236	SPECIFIC_DAY	23	2	2010-01-27	49289	66055	\N	\N
66216	SPECIFIC_DAY	23	0	2010-01-17	49289	66055	\N	\N
66237	SPECIFIC_DAY	23	0	2010-01-16	49289	66055	\N	\N
66206	SPECIFIC_DAY	23	2	2009-12-31	49289	66055	\N	\N
66227	SPECIFIC_DAY	23	2	2009-12-16	49289	66055	\N	\N
66224	SPECIFIC_DAY	23	0	2010-01-10	49289	66055	\N	\N
66209	SPECIFIC_DAY	23	2	2009-12-14	49289	66055	\N	\N
101714	SPECIFIC_DAY	14	7	2009-12-14	40199	59189	\N	\N
66235	SPECIFIC_DAY	23	0	2010-01-01	49289	66055	\N	\N
66242	SPECIFIC_DAY	23	2	2009-12-30	49289	66055	\N	\N
66222	SPECIFIC_DAY	23	2	2009-12-29	49289	66055	\N	\N
66203	SPECIFIC_DAY	23	2	2009-12-22	49289	66055	\N	\N
66241	SPECIFIC_DAY	23	2	2010-01-11	49289	66055	\N	\N
66238	SPECIFIC_DAY	23	2	2010-01-28	49289	66055	\N	\N
66240	SPECIFIC_DAY	23	0	2009-12-20	49289	66055	\N	\N
66178	SPECIFIC_DAY	23	2	2009-12-17	49302	66054	\N	\N
66165	SPECIFIC_DAY	23	2	2009-12-21	49302	66054	\N	\N
66192	SPECIFIC_DAY	23	2	2010-01-15	49302	66054	\N	\N
66182	SPECIFIC_DAY	23	2	2010-01-26	49302	66054	\N	\N
66155	SPECIFIC_DAY	23	2	2010-01-28	49302	66054	\N	\N
66159	SPECIFIC_DAY	23	2	2010-01-25	49302	66054	\N	\N
66156	SPECIFIC_DAY	23	0	2010-01-06	49302	66054	\N	\N
66164	SPECIFIC_DAY	23	2	2009-12-22	49302	66054	\N	\N
66177	SPECIFIC_DAY	23	0	2010-01-23	49302	66054	\N	\N
66199	SPECIFIC_DAY	23	0	2010-01-17	49302	66054	\N	\N
66191	SPECIFIC_DAY	23	2	2010-01-12	49302	66054	\N	\N
66169	SPECIFIC_DAY	23	2	2010-01-07	49302	66054	\N	\N
66198	SPECIFIC_DAY	23	2	2010-01-19	49302	66054	\N	\N
66180	SPECIFIC_DAY	23	2	2010-01-14	49302	66054	\N	\N
66200	SPECIFIC_DAY	23	2	2009-12-24	49302	66054	\N	\N
66172	SPECIFIC_DAY	23	2	2010-01-18	49302	66054	\N	\N
66163	SPECIFIC_DAY	23	2	2010-01-22	49302	66054	\N	\N
66195	SPECIFIC_DAY	23	0	2010-01-24	49302	66054	\N	\N
66189	SPECIFIC_DAY	23	2	2009-12-15	49302	66054	\N	\N
66162	SPECIFIC_DAY	23	2	2009-12-18	49302	66054	\N	\N
66160	SPECIFIC_DAY	23	0	2009-12-19	49302	66054	\N	\N
66188	SPECIFIC_DAY	23	0	2010-01-16	49302	66054	\N	\N
66168	SPECIFIC_DAY	23	2	2010-01-13	49302	66054	\N	\N
66027	SPECIFIC_DAY	23	0	2010-01-02	49304	61508	\N	\N
66020	SPECIFIC_DAY	23	4	2009-12-21	49304	61508	\N	\N
66026	SPECIFIC_DAY	23	3	2009-12-29	49304	61508	\N	\N
66041	SPECIFIC_DAY	23	0	2010-01-24	49304	61508	\N	\N
66051	SPECIFIC_DAY	23	4	2009-12-16	49304	61508	\N	\N
66021	SPECIFIC_DAY	23	3	2009-12-23	49304	61508	\N	\N
66015	SPECIFIC_DAY	23	0	2009-12-20	49304	61508	\N	\N
66030	SPECIFIC_DAY	23	0	2009-12-25	49304	61508	\N	\N
69228	SPECIFIC_DAY	23	4	2009-12-22	49289	68695	\N	\N
69225	SPECIFIC_DAY	23	4	2009-12-17	49289	68695	\N	\N
69213	SPECIFIC_DAY	23	0	2010-01-02	49289	68695	\N	\N
69230	SPECIFIC_DAY	23	0	2009-12-27	49289	68695	\N	\N
69221	SPECIFIC_DAY	23	4	2009-12-14	49289	68695	\N	\N
69218	SPECIFIC_DAY	23	4	2009-12-18	49289	68695	\N	\N
69217	SPECIFIC_DAY	23	4	2009-12-15	49289	68695	\N	\N
69220	SPECIFIC_DAY	23	4	2009-12-23	49289	68695	\N	\N
69215	SPECIFIC_DAY	23	4	2009-12-21	49289	68695	\N	\N
69222	SPECIFIC_DAY	23	0	2009-12-26	49289	68695	\N	\N
69178	SPECIFIC_DAY	23	0	2009-12-27	49289	68692	\N	\N
69167	SPECIFIC_DAY	23	1	2010-01-27	49289	68692	\N	\N
69150	SPECIFIC_DAY	23	1	2010-01-14	49289	68692	\N	\N
69164	SPECIFIC_DAY	23	1	2010-01-05	49289	68692	\N	\N
69171	SPECIFIC_DAY	23	1	2009-12-30	49289	68692	\N	\N
69182	SPECIFIC_DAY	23	1	2010-01-25	49289	68692	\N	\N
69173	SPECIFIC_DAY	23	0	2010-01-06	49289	68692	\N	\N
69183	SPECIFIC_DAY	23	0	2010-01-03	49289	68692	\N	\N
69158	SPECIFIC_DAY	23	1	2009-12-31	49289	68692	\N	\N
69166	SPECIFIC_DAY	23	0	2010-01-09	49289	68692	\N	\N
69160	SPECIFIC_DAY	23	0	2010-01-23	49289	68692	\N	\N
69176	SPECIFIC_DAY	23	2	2009-12-16	49289	68692	\N	\N
69153	SPECIFIC_DAY	23	0	2009-12-19	49289	68692	\N	\N
69148	SPECIFIC_DAY	23	0	2010-01-10	49289	68692	\N	\N
69152	SPECIFIC_DAY	23	0	2010-01-17	49289	68692	\N	\N
69181	SPECIFIC_DAY	23	1	2010-01-12	49289	68692	\N	\N
69145	SPECIFIC_DAY	23	1	2010-01-19	49289	68692	\N	\N
69168	SPECIFIC_DAY	23	1	2010-01-07	49289	68692	\N	\N
69169	SPECIFIC_DAY	23	1	2010-01-26	49289	68692	\N	\N
69163	SPECIFIC_DAY	23	1	2009-12-18	49289	68692	\N	\N
102696	SPECIFIC_DAY	13	7	2009-12-16	36159	60445	\N	\N
102698	SPECIFIC_DAY	13	7	2009-12-14	36159	60445	\N	\N
102697	SPECIFIC_DAY	13	7	2009-12-17	36159	60445	\N	\N
103326	SPECIFIC_DAY	9	0	2009-12-20	37573	59218	\N	\N
103329	SPECIFIC_DAY	9	7	2009-12-22	37573	59218	\N	\N
103325	SPECIFIC_DAY	9	7	2009-12-15	37573	59218	\N	\N
103327	SPECIFIC_DAY	9	7	2009-12-16	37573	59218	\N	\N
103333	SPECIFIC_DAY	9	7	2009-12-21	37573	59218	\N	\N
103328	SPECIFIC_DAY	9	0	2009-12-19	37573	59218	\N	\N
103334	SPECIFIC_DAY	9	7	2009-12-14	37573	59218	\N	\N
103330	SPECIFIC_DAY	9	7	2009-12-17	37573	59218	\N	\N
103331	SPECIFIC_DAY	9	7	2009-12-18	37573	59218	\N	\N
103332	SPECIFIC_DAY	9	7	2009-12-23	37573	59218	\N	\N
102699	SPECIFIC_DAY	13	7	2009-12-18	36159	60445	\N	\N
102700	SPECIFIC_DAY	13	7	2009-12-21	36159	60445	\N	\N
102703	SPECIFIC_DAY	13	0	2009-12-20	36159	60445	\N	\N
102701	SPECIFIC_DAY	13	0	2009-12-19	36159	60445	\N	\N
102702	SPECIFIC_DAY	13	7	2009-12-15	36159	60445	\N	\N
66219	SPECIFIC_DAY	23	2	2010-01-12	49289	66055	\N	\N
66207	SPECIFIC_DAY	23	2	2010-01-26	49289	66055	\N	\N
66226	SPECIFIC_DAY	23	2	2010-01-15	49289	66055	\N	\N
66244	SPECIFIC_DAY	23	2	2009-12-24	49289	66055	\N	\N
66215	SPECIFIC_DAY	23	2	2009-12-18	49289	66055	\N	\N
66210	SPECIFIC_DAY	23	2	2010-01-07	49289	66055	\N	\N
66225	SPECIFIC_DAY	23	2	2009-12-21	49289	66055	\N	\N
66214	SPECIFIC_DAY	23	2	2010-01-14	49289	66055	\N	\N
66205	SPECIFIC_DAY	23	2	2010-01-04	49289	66055	\N	\N
66220	SPECIFIC_DAY	23	2	2009-12-23	49289	66055	\N	\N
66217	SPECIFIC_DAY	23	2	2009-12-17	49289	66055	\N	\N
66233	SPECIFIC_DAY	23	0	2010-01-24	49289	66055	\N	\N
66229	SPECIFIC_DAY	23	2	2010-01-08	49289	66055	\N	\N
66230	SPECIFIC_DAY	23	2	2009-12-15	49289	66055	\N	\N
66221	SPECIFIC_DAY	23	0	2010-01-09	49289	66055	\N	\N
66202	SPECIFIC_DAY	23	2	2010-01-20	49289	66055	\N	\N
66234	SPECIFIC_DAY	23	0	2009-12-19	49289	66055	\N	\N
66228	SPECIFIC_DAY	23	2	2010-01-13	49289	66055	\N	\N
66223	SPECIFIC_DAY	23	0	2010-01-06	49289	66055	\N	\N
66245	SPECIFIC_DAY	23	2	2010-01-25	49289	66055	\N	\N
66212	SPECIFIC_DAY	23	0	2009-12-25	49289	66055	\N	\N
66246	SPECIFIC_DAY	23	0	2010-01-23	49289	66055	\N	\N
66201	SPECIFIC_DAY	23	0	2009-12-26	49289	66055	\N	\N
66239	SPECIFIC_DAY	23	2	2010-01-22	49289	66055	\N	\N
66231	SPECIFIC_DAY	23	0	2010-01-02	49289	66055	\N	\N
66232	SPECIFIC_DAY	23	2	2010-01-19	49289	66055	\N	\N
66211	SPECIFIC_DAY	23	2	2010-01-18	49289	66055	\N	\N
66218	SPECIFIC_DAY	23	2	2009-12-28	49289	66055	\N	\N
66208	SPECIFIC_DAY	23	0	2009-12-27	49289	66055	\N	\N
66213	SPECIFIC_DAY	23	2	2010-01-21	49289	66055	\N	\N
66204	SPECIFIC_DAY	23	2	2010-01-05	49289	66055	\N	\N
66186	SPECIFIC_DAY	23	2	2009-12-30	49302	66054	\N	\N
66175	SPECIFIC_DAY	23	2	2009-12-23	49302	66054	\N	\N
66194	SPECIFIC_DAY	23	0	2010-01-02	49302	66054	\N	\N
66157	SPECIFIC_DAY	23	0	2009-12-20	49302	66054	\N	\N
66161	SPECIFIC_DAY	23	0	2009-12-26	49302	66054	\N	\N
66197	SPECIFIC_DAY	23	2	2010-01-04	49302	66054	\N	\N
66181	SPECIFIC_DAY	23	2	2010-01-20	49302	66054	\N	\N
66174	SPECIFIC_DAY	23	2	2009-12-31	49302	66054	\N	\N
66193	SPECIFIC_DAY	23	2	2009-12-16	49302	66054	\N	\N
66166	SPECIFIC_DAY	23	2	2009-12-29	49302	66054	\N	\N
66173	SPECIFIC_DAY	23	0	2010-01-09	49302	66054	\N	\N
66167	SPECIFIC_DAY	23	2	2009-12-14	49302	66054	\N	\N
66183	SPECIFIC_DAY	23	2	2010-01-05	49302	66054	\N	\N
66187	SPECIFIC_DAY	23	0	2010-01-03	49302	66054	\N	\N
66185	SPECIFIC_DAY	23	0	2010-01-10	49302	66054	\N	\N
66184	SPECIFIC_DAY	23	0	2009-12-25	49302	66054	\N	\N
66196	SPECIFIC_DAY	23	2	2009-12-28	49302	66054	\N	\N
66176	SPECIFIC_DAY	23	0	2009-12-27	49302	66054	\N	\N
66170	SPECIFIC_DAY	23	2	2010-01-11	49302	66054	\N	\N
69224	SPECIFIC_DAY	23	4	2009-12-31	49289	68695	\N	\N
69223	SPECIFIC_DAY	23	4	2009-12-29	49289	68695	\N	\N
69227	SPECIFIC_DAY	23	0	2010-01-04	49289	68695	\N	\N
69219	SPECIFIC_DAY	23	0	2010-01-01	49289	68695	\N	\N
69226	SPECIFIC_DAY	23	0	2009-12-19	49289	68695	\N	\N
69229	SPECIFIC_DAY	23	4	2009-12-16	49289	68695	\N	\N
69233	SPECIFIC_DAY	23	4	2009-12-28	49289	68695	\N	\N
69231	SPECIFIC_DAY	23	0	2009-12-25	49289	68695	\N	\N
69214	SPECIFIC_DAY	23	4	2009-12-30	49289	68695	\N	\N
69216	SPECIFIC_DAY	23	0	2010-01-03	49289	68695	\N	\N
69232	SPECIFIC_DAY	23	0	2009-12-20	49289	68695	\N	\N
69234	SPECIFIC_DAY	23	4	2009-12-24	49289	68695	\N	\N
69244	SPECIFIC_DAY	23	0	2009-12-26	49302	68696	\N	\N
69243	SPECIFIC_DAY	23	0	2009-12-20	49302	68696	\N	\N
69253	SPECIFIC_DAY	23	0	2010-01-03	49302	68696	\N	\N
69238	SPECIFIC_DAY	23	0	2009-12-19	49302	68696	\N	\N
69251	SPECIFIC_DAY	23	0	2009-12-27	49302	68696	\N	\N
69241	SPECIFIC_DAY	23	0	2010-01-02	49302	68696	\N	\N
69236	SPECIFIC_DAY	23	4	2009-12-28	49302	68696	\N	\N
69235	SPECIFIC_DAY	23	4	2009-12-22	49302	68696	\N	\N
69237	SPECIFIC_DAY	23	4	2009-12-18	49302	68696	\N	\N
69245	SPECIFIC_DAY	23	4	2009-12-29	49302	68696	\N	\N
69239	SPECIFIC_DAY	23	4	2009-12-23	49302	68696	\N	\N
69240	SPECIFIC_DAY	23	1	2010-01-04	49302	68696	\N	\N
69247	SPECIFIC_DAY	23	4	2009-12-24	49302	68696	\N	\N
69255	SPECIFIC_DAY	23	4	2009-12-15	49302	68696	\N	\N
69250	SPECIFIC_DAY	23	4	2009-12-30	49302	68696	\N	\N
69248	SPECIFIC_DAY	23	4	2009-12-14	49302	68696	\N	\N
69242	SPECIFIC_DAY	23	4	2009-12-17	49302	68696	\N	\N
69252	SPECIFIC_DAY	23	0	2009-12-25	49302	68696	\N	\N
69246	SPECIFIC_DAY	23	4	2009-12-21	49302	68696	\N	\N
69254	SPECIFIC_DAY	23	4	2009-12-31	49302	68696	\N	\N
69256	SPECIFIC_DAY	23	4	2009-12-16	49302	68696	\N	\N
69249	SPECIFIC_DAY	23	0	2010-01-01	49302	68696	\N	\N
61071	SPECIFIC_DAY	34	7	2009-12-16	49309	60448	\N	\N
61067	SPECIFIC_DAY	34	7	2009-12-21	49309	60448	\N	\N
61068	SPECIFIC_DAY	34	7	2009-12-17	49309	60448	\N	\N
61070	SPECIFIC_DAY	34	7	2009-12-14	49309	60448	\N	\N
61073	SPECIFIC_DAY	34	0	2009-12-19	49309	60448	\N	\N
61074	SPECIFIC_DAY	34	7	2009-12-18	49309	60448	\N	\N
61069	SPECIFIC_DAY	34	0	2009-12-20	49309	60448	\N	\N
61072	SPECIFIC_DAY	34	7	2009-12-15	49309	60448	\N	\N
69165	SPECIFIC_DAY	23	1	2010-01-21	49289	68692	\N	\N
69157	SPECIFIC_DAY	23	1	2010-01-13	49289	68692	\N	\N
69188	SPECIFIC_DAY	23	0	2009-12-25	49289	68692	\N	\N
69154	SPECIFIC_DAY	23	0	2010-01-02	49289	68692	\N	\N
69155	SPECIFIC_DAY	23	1	2010-01-28	49289	68692	\N	\N
69186	SPECIFIC_DAY	23	1	2009-12-24	49289	68692	\N	\N
69156	SPECIFIC_DAY	23	0	2009-12-20	49289	68692	\N	\N
69151	SPECIFIC_DAY	23	1	2010-01-08	49289	68692	\N	\N
69174	SPECIFIC_DAY	23	1	2009-12-23	49289	68692	\N	\N
69147	SPECIFIC_DAY	23	1	2009-12-22	49289	68692	\N	\N
68643	SPECIFIC_DAY	23	7	2009-12-15	49300	68680	\N	\N
68645	SPECIFIC_DAY	23	7	2009-12-17	49300	68680	\N	\N
68646	SPECIFIC_DAY	23	7	2009-12-18	49300	68680	\N	\N
68647	SPECIFIC_DAY	23	7	2009-12-14	49300	68680	\N	\N
68644	SPECIFIC_DAY	23	7	2009-12-16	49300	68680	\N	\N
66717	SPECIFIC_DAY	23	3	2010-01-28	49302	66061	\N	\N
66739	SPECIFIC_DAY	23	4	2009-12-30	49302	66061	\N	\N
66714	SPECIFIC_DAY	23	0	2009-12-25	49302	66061	\N	\N
66732	SPECIFIC_DAY	23	4	2009-12-14	49302	66061	\N	\N
66730	SPECIFIC_DAY	23	4	2010-01-11	49302	66061	\N	\N
66697	SPECIFIC_DAY	23	4	2010-01-12	49302	66061	\N	\N
66735	SPECIFIC_DAY	23	0	2009-12-27	49302	66061	\N	\N
66729	SPECIFIC_DAY	23	0	2010-01-03	49302	66061	\N	\N
66737	SPECIFIC_DAY	23	4	2009-12-24	49302	66061	\N	\N
66734	SPECIFIC_DAY	23	0	2009-12-26	49302	66061	\N	\N
66701	SPECIFIC_DAY	23	4	2009-12-17	49302	66061	\N	\N
66738	SPECIFIC_DAY	23	3	2010-01-13	49302	66061	\N	\N
66719	SPECIFIC_DAY	23	0	2010-01-17	49302	66061	\N	\N
66703	SPECIFIC_DAY	23	4	2009-12-29	49302	66061	\N	\N
66736	SPECIFIC_DAY	23	0	2010-01-06	49302	66061	\N	\N
66726	SPECIFIC_DAY	23	0	2010-01-24	49302	66061	\N	\N
66705	SPECIFIC_DAY	23	3	2010-01-15	49302	66061	\N	\N
66712	SPECIFIC_DAY	23	4	2009-12-28	49302	66061	\N	\N
66702	SPECIFIC_DAY	23	3	2010-01-18	49302	66061	\N	\N
66731	SPECIFIC_DAY	23	4	2009-12-21	49302	66061	\N	\N
66698	SPECIFIC_DAY	23	4	2009-12-18	49302	66061	\N	\N
66742	SPECIFIC_DAY	23	0	2010-01-01	49302	66061	\N	\N
66722	SPECIFIC_DAY	23	4	2010-01-07	49302	66061	\N	\N
66708	SPECIFIC_DAY	23	0	2010-01-23	49302	66061	\N	\N
66721	SPECIFIC_DAY	23	4	2010-01-05	49302	66061	\N	\N
66700	SPECIFIC_DAY	23	4	2009-12-31	49302	66061	\N	\N
66704	SPECIFIC_DAY	23	0	2010-01-16	49302	66061	\N	\N
66727	SPECIFIC_DAY	23	3	2010-01-21	49302	66061	\N	\N
66723	SPECIFIC_DAY	23	3	2010-01-25	49302	66061	\N	\N
66716	SPECIFIC_DAY	23	4	2009-12-16	49302	66061	\N	\N
66724	SPECIFIC_DAY	23	0	2010-01-09	49302	66061	\N	\N
66733	SPECIFIC_DAY	23	4	2009-12-15	49302	66061	\N	\N
66710	SPECIFIC_DAY	23	3	2010-01-19	49302	66061	\N	\N
66706	SPECIFIC_DAY	23	4	2010-01-08	49302	66061	\N	\N
66720	SPECIFIC_DAY	23	4	2009-12-23	49302	66061	\N	\N
66725	SPECIFIC_DAY	23	0	2009-12-20	49302	66061	\N	\N
66711	SPECIFIC_DAY	23	0	2009-12-19	49302	66061	\N	\N
66699	SPECIFIC_DAY	23	4	2009-12-22	49302	66061	\N	\N
66707	SPECIFIC_DAY	23	3	2010-01-27	49302	66061	\N	\N
105698	SPECIFIC_DAY	2	4	2009-12-16	49297	68683	\N	\N
105700	SPECIFIC_DAY	2	5	2009-12-14	49297	68683	\N	\N
105699	SPECIFIC_DAY	2	5	2009-12-15	49297	68683	\N	\N
107565	SPECIFIC_DAY	0	0	2009-12-26	37573	59217	\N	\N
107566	SPECIFIC_DAY	0	9	2009-12-30	37573	59217	\N	\N
107567	SPECIFIC_DAY	0	9	2009-12-24	37573	59217	\N	\N
107568	SPECIFIC_DAY	0	9	2009-12-29	37573	59217	\N	\N
107569	SPECIFIC_DAY	0	0	2009-12-27	37573	59217	\N	\N
107570	SPECIFIC_DAY	0	9	2009-12-28	37573	59217	\N	\N
107571	SPECIFIC_DAY	0	0	2009-12-25	37573	59217	\N	\N
107572	SPECIFIC_DAY	0	6	2009-12-31	37573	59217	\N	\N
107573	SPECIFIC_DAY	0	9	2010-01-25	49309	68681	\N	\N
107574	SPECIFIC_DAY	0	2	2010-01-23	49309	68681	\N	\N
107575	SPECIFIC_DAY	0	9	2010-01-21	49309	68681	\N	\N
107576	SPECIFIC_DAY	0	9	2010-01-20	49309	68681	\N	\N
107577	SPECIFIC_DAY	0	9	2010-01-22	49309	68681	\N	\N
107578	SPECIFIC_DAY	0	2	2010-01-24	49309	68681	\N	\N
107579	SPECIFIC_DAY	0	9	2010-01-26	49309	68681	\N	\N
107580	SPECIFIC_DAY	0	4	2010-01-29	49300	68682	\N	\N
107581	SPECIFIC_DAY	0	7	2010-01-03	37573	60439	\N	\N
107582	SPECIFIC_DAY	0	7	2010-01-02	37573	60439	\N	\N
107583	SPECIFIC_DAY	0	7	2010-01-01	37573	60439	\N	\N
107584	SPECIFIC_DAY	0	14	2010-01-04	37573	60439	\N	\N
107585	SPECIFIC_DAY	0	2	2010-01-15	49313	68707	\N	\N
107586	SPECIFIC_DAY	0	2	2009-12-31	49313	68707	\N	\N
107587	SPECIFIC_DAY	0	0	2010-01-02	49313	68707	\N	\N
107588	SPECIFIC_DAY	0	2	2009-12-30	49313	68707	\N	\N
107589	SPECIFIC_DAY	0	2	2010-01-07	49313	68707	\N	\N
107590	SPECIFIC_DAY	0	0	2010-01-03	49313	68707	\N	\N
107591	SPECIFIC_DAY	0	2	2010-01-08	49313	68707	\N	\N
107592	SPECIFIC_DAY	0	2	2010-01-13	49313	68707	\N	\N
107593	SPECIFIC_DAY	0	0	2010-01-10	49313	68707	\N	\N
107594	SPECIFIC_DAY	0	2	2010-01-05	49313	68707	\N	\N
107595	SPECIFIC_DAY	0	2	2010-01-19	49313	68707	\N	\N
107596	SPECIFIC_DAY	0	0	2010-01-09	49313	68707	\N	\N
107597	SPECIFIC_DAY	0	2	2010-01-04	49313	68707	\N	\N
107598	SPECIFIC_DAY	0	2	2010-01-20	49313	68707	\N	\N
107599	SPECIFIC_DAY	0	0	2010-01-01	49313	68707	\N	\N
107600	SPECIFIC_DAY	0	2	2010-01-18	49313	68707	\N	\N
107601	SPECIFIC_DAY	0	0	2010-01-06	49313	68707	\N	\N
107602	SPECIFIC_DAY	0	0	2010-01-17	49313	68707	\N	\N
107603	SPECIFIC_DAY	0	2	2010-01-14	49313	68707	\N	\N
107604	SPECIFIC_DAY	0	0	2010-01-16	49313	68707	\N	\N
107605	SPECIFIC_DAY	0	2	2010-01-11	49313	68707	\N	\N
107606	SPECIFIC_DAY	0	2	2010-01-12	49313	68707	\N	\N
107607	SPECIFIC_DAY	0	0	2010-01-17	49297	68684	\N	\N
107608	SPECIFIC_DAY	0	5	2010-01-21	49297	68684	\N	\N
107609	SPECIFIC_DAY	0	5	2010-01-20	49297	68684	\N	\N
107610	SPECIFIC_DAY	0	5	2010-01-18	49297	68684	\N	\N
107611	SPECIFIC_DAY	0	1	2010-01-22	49297	68684	\N	\N
107612	SPECIFIC_DAY	0	5	2010-01-19	49297	68684	\N	\N
107613	SPECIFIC_DAY	0	7	2010-01-27	49297	68685	\N	\N
107614	SPECIFIC_DAY	0	7	2010-01-26	49297	68685	\N	\N
107615	SPECIFIC_DAY	0	0	2010-01-24	49297	68685	\N	\N
107616	SPECIFIC_DAY	0	0	2010-01-23	49297	68685	\N	\N
107617	SPECIFIC_DAY	0	7	2010-01-25	49297	68685	\N	\N
107618	SPECIFIC_DAY	0	5	2009-12-21	49297	68686	\N	\N
107619	SPECIFIC_DAY	0	5	2009-12-18	49297	68686	\N	\N
107620	SPECIFIC_DAY	0	0	2009-12-20	49297	68686	\N	\N
107621	SPECIFIC_DAY	0	0	2009-12-19	49297	68686	\N	\N
107622	SPECIFIC_DAY	0	1	2009-12-23	49297	68686	\N	\N
107623	SPECIFIC_DAY	0	5	2009-12-22	49297	68686	\N	\N
107624	SPECIFIC_DAY	0	5	2009-12-17	49297	68686	\N	\N
107625	SPECIFIC_DAY	0	0	2010-01-10	49297	68687	\N	\N
107626	SPECIFIC_DAY	0	7	2010-01-08	49297	68687	\N	\N
107627	SPECIFIC_DAY	0	0	2010-01-09	49297	68687	\N	\N
107628	SPECIFIC_DAY	0	7	2010-01-11	49297	68687	\N	\N
107629	SPECIFIC_DAY	0	7	2010-01-12	49297	68687	\N	\N
107630	SPECIFIC_DAY	0	5	2009-12-24	49297	68688	\N	\N
107631	SPECIFIC_DAY	0	0	2009-12-25	49297	68688	\N	\N
107632	SPECIFIC_DAY	0	0	2009-12-27	49297	68688	\N	\N
107633	SPECIFIC_DAY	0	5	2009-12-30	49297	68688	\N	\N
107634	SPECIFIC_DAY	0	5	2009-12-28	49297	68688	\N	\N
107635	SPECIFIC_DAY	0	0	2009-12-26	49297	68688	\N	\N
107636	SPECIFIC_DAY	0	5	2009-12-29	49297	68688	\N	\N
107637	SPECIFIC_DAY	0	1	2009-12-31	49297	68688	\N	\N
107638	SPECIFIC_DAY	0	7	2010-01-04	49297	68689	\N	\N
107639	SPECIFIC_DAY	0	0	2010-01-03	49297	68689	\N	\N
107640	SPECIFIC_DAY	0	7	2010-01-07	49297	68689	\N	\N
107641	SPECIFIC_DAY	0	0	2010-01-06	49297	68689	\N	\N
107642	SPECIFIC_DAY	0	0	2010-01-02	49297	68689	\N	\N
107643	SPECIFIC_DAY	0	0	2010-01-01	49297	68689	\N	\N
107644	SPECIFIC_DAY	0	7	2010-01-05	49297	68689	\N	\N
107645	SPECIFIC_DAY	0	7	2010-01-15	49297	68690	\N	\N
107646	SPECIFIC_DAY	0	0	2010-01-16	49297	68690	\N	\N
107647	SPECIFIC_DAY	0	7	2010-01-14	49297	68690	\N	\N
107648	SPECIFIC_DAY	0	7	2010-01-13	49297	68690	\N	\N
107649	SPECIFIC_DAY	0	2	2010-01-26	36159	60446	\N	\N
107650	SPECIFIC_DAY	0	0	2010-01-16	36159	60446	\N	\N
107651	SPECIFIC_DAY	0	2	2010-01-21	36159	60446	\N	\N
107652	SPECIFIC_DAY	0	2	2010-01-19	36159	60446	\N	\N
107653	SPECIFIC_DAY	0	0	2010-01-14	36159	60446	\N	\N
107654	SPECIFIC_DAY	0	0	2010-01-23	36159	60446	\N	\N
107655	SPECIFIC_DAY	0	0	2010-01-17	36159	60446	\N	\N
107656	SPECIFIC_DAY	0	0	2010-01-24	36159	60446	\N	\N
107657	SPECIFIC_DAY	0	0	2010-01-11	36159	60446	\N	\N
107658	SPECIFIC_DAY	0	2	2010-01-20	36159	60446	\N	\N
107659	SPECIFIC_DAY	0	0	2010-01-13	36159	60446	\N	\N
107660	SPECIFIC_DAY	0	2	2010-01-27	36159	60446	\N	\N
107661	SPECIFIC_DAY	0	1	2010-01-28	36159	60446	\N	\N
107662	SPECIFIC_DAY	0	2	2010-01-25	36159	60446	\N	\N
107663	SPECIFIC_DAY	0	0	2010-01-10	36159	60446	\N	\N
107664	SPECIFIC_DAY	0	2	2010-01-07	36159	60446	\N	\N
107665	SPECIFIC_DAY	0	2	2010-01-18	36159	60446	\N	\N
107666	SPECIFIC_DAY	0	2	2010-01-22	36159	60446	\N	\N
107667	SPECIFIC_DAY	0	2	2010-01-08	36159	60446	\N	\N
107668	SPECIFIC_DAY	0	0	2010-01-09	36159	60446	\N	\N
107669	SPECIFIC_DAY	0	0	2010-01-15	36159	60446	\N	\N
107670	SPECIFIC_DAY	0	0	2010-01-12	36159	60446	\N	\N
107671	SPECIFIC_DAY	0	0	2010-01-01	36159	60447	\N	\N
107672	SPECIFIC_DAY	0	2	2010-01-04	36159	60447	\N	\N
107673	SPECIFIC_DAY	0	3	2009-12-24	36159	60447	\N	\N
107674	SPECIFIC_DAY	0	0	2009-12-25	36159	60447	\N	\N
107675	SPECIFIC_DAY	0	0	2009-12-26	36159	60447	\N	\N
107676	SPECIFIC_DAY	0	2	2009-12-31	36159	60447	\N	\N
107677	SPECIFIC_DAY	0	0	2010-01-03	36159	60447	\N	\N
107678	SPECIFIC_DAY	0	2	2010-01-05	36159	60447	\N	\N
107679	SPECIFIC_DAY	0	0	2009-12-27	36159	60447	\N	\N
107680	SPECIFIC_DAY	0	2	2009-12-30	36159	60447	\N	\N
107681	SPECIFIC_DAY	0	2	2009-12-28	36159	60447	\N	\N
107682	SPECIFIC_DAY	0	3	2009-12-22	36159	60447	\N	\N
107683	SPECIFIC_DAY	0	3	2009-12-23	36159	60447	\N	\N
107684	SPECIFIC_DAY	0	2	2009-12-29	36159	60447	\N	\N
107685	SPECIFIC_DAY	0	0	2010-01-02	36159	60447	\N	\N
107686	SPECIFIC_DAY	0	0	2010-01-06	36159	60447	\N	\N
107687	SPECIFIC_DAY	0	8	2010-01-05	40199	97675	\N	\N
107688	SPECIFIC_DAY	0	7	2010-01-12	40199	97675	\N	\N
107689	SPECIFIC_DAY	0	7	2010-01-13	40199	97675	\N	\N
107690	SPECIFIC_DAY	0	8	2010-01-08	40199	97675	\N	\N
107691	SPECIFIC_DAY	0	8	2010-01-11	40199	97675	\N	\N
107692	SPECIFIC_DAY	0	1	2010-01-09	40199	97675	\N	\N
107693	SPECIFIC_DAY	0	1	2010-01-10	40199	97675	\N	\N
107694	SPECIFIC_DAY	0	1	2010-01-06	40199	97675	\N	\N
107695	SPECIFIC_DAY	0	8	2010-01-07	40199	97675	\N	\N
107696	SPECIFIC_DAY	0	7	2010-01-14	40199	97675	\N	\N
107697	SPECIFIC_DAY	0	7	2010-01-07	37573	60440	\N	\N
107698	SPECIFIC_DAY	0	7	2010-01-05	37573	60440	\N	\N
107699	SPECIFIC_DAY	0	0	2010-01-06	37573	60440	\N	\N
107700	SPECIFIC_DAY	0	7	2010-01-08	37573	60441	\N	\N
107701	SPECIFIC_DAY	0	0	2010-01-10	37573	60441	\N	\N
107702	SPECIFIC_DAY	0	7	2010-01-12	37573	60441	\N	\N
107703	SPECIFIC_DAY	0	7	2010-01-13	37573	60441	\N	\N
107704	SPECIFIC_DAY	0	0	2010-01-09	37573	60441	\N	\N
107705	SPECIFIC_DAY	0	7	2010-01-11	37573	60441	\N	\N
107706	SPECIFIC_DAY	0	14	2010-01-15	37573	60442	\N	\N
107707	SPECIFIC_DAY	0	14	2010-01-14	37573	60442	\N	\N
107708	SPECIFIC_DAY	0	7	2010-01-16	37573	60442	\N	\N
107709	SPECIFIC_DAY	0	7	2010-01-19	37573	60443	\N	\N
107710	SPECIFIC_DAY	0	7	2010-01-18	37573	60443	\N	\N
107711	SPECIFIC_DAY	0	0	2010-01-17	37573	60443	\N	\N
107712	SPECIFIC_DAY	0	9	2010-01-21	37573	60444	\N	\N
107713	SPECIFIC_DAY	0	10	2010-01-20	37573	60444	\N	\N
107714	SPECIFIC_DAY	0	9	2010-01-22	37573	60444	\N	\N
107715	SPECIFIC_DAY	0	7	2010-01-21	49300	66154	\N	\N
107716	SPECIFIC_DAY	0	7	2010-01-22	49300	66154	\N	\N
107717	SPECIFIC_DAY	0	7	2010-01-20	49300	66154	\N	\N
107718	SPECIFIC_DAY	0	7	2009-12-23	49309	60449	\N	\N
107719	SPECIFIC_DAY	0	0	2009-12-25	49309	60449	\N	\N
107720	SPECIFIC_DAY	0	0	2009-12-27	49309	60449	\N	\N
107721	SPECIFIC_DAY	0	0	2009-12-26	49309	60449	\N	\N
107722	SPECIFIC_DAY	0	7	2009-12-22	49309	60449	\N	\N
107723	SPECIFIC_DAY	0	7	2009-12-28	49309	60449	\N	\N
107724	SPECIFIC_DAY	0	7	2009-12-24	49309	60449	\N	\N
107725	SPECIFIC_DAY	0	7	2010-01-08	49309	60450	\N	\N
107726	SPECIFIC_DAY	0	7	2010-01-07	49309	60450	\N	\N
107727	SPECIFIC_DAY	0	7	2010-01-12	49309	60450	\N	\N
107728	SPECIFIC_DAY	0	7	2010-01-11	49309	60450	\N	\N
107729	SPECIFIC_DAY	0	0	2010-01-09	49309	60450	\N	\N
107730	SPECIFIC_DAY	0	0	2010-01-10	49309	60450	\N	\N
107731	SPECIFIC_DAY	0	0	2010-01-06	49309	60450	\N	\N
107732	SPECIFIC_DAY	0	7	2009-12-16	40199	59220	\N	\N
107733	SPECIFIC_DAY	0	7	2009-12-15	40199	59220	\N	\N
107734	SPECIFIC_DAY	0	7	2009-12-18	40199	59221	\N	\N
107735	SPECIFIC_DAY	0	7	2009-12-17	40199	59221	\N	\N
107736	SPECIFIC_DAY	0	0	2010-01-03	40199	59222	\N	\N
107737	SPECIFIC_DAY	0	7	2009-12-24	40199	59222	\N	\N
107738	SPECIFIC_DAY	0	0	2009-12-27	40199	59222	\N	\N
107739	SPECIFIC_DAY	0	0	2010-01-01	40199	59222	\N	\N
107740	SPECIFIC_DAY	0	0	2009-12-26	40199	59222	\N	\N
107741	SPECIFIC_DAY	0	7	2010-01-04	40199	59222	\N	\N
107742	SPECIFIC_DAY	0	0	2009-12-31	40199	59222	\N	\N
107743	SPECIFIC_DAY	0	0	2010-01-02	40199	59222	\N	\N
107744	SPECIFIC_DAY	0	0	2009-12-29	40199	59222	\N	\N
107745	SPECIFIC_DAY	0	0	2009-12-20	40199	59222	\N	\N
107746	SPECIFIC_DAY	0	0	2009-12-30	40199	59222	\N	\N
107747	SPECIFIC_DAY	0	7	2009-12-23	40199	59222	\N	\N
107748	SPECIFIC_DAY	0	7	2009-12-21	40199	59222	\N	\N
107749	SPECIFIC_DAY	0	7	2009-12-22	40199	59222	\N	\N
107750	SPECIFIC_DAY	0	0	2009-12-28	40199	59222	\N	\N
107751	SPECIFIC_DAY	0	0	2009-12-25	40199	59222	\N	\N
107752	SPECIFIC_DAY	0	0	2009-12-19	40199	59222	\N	\N
107753	SPECIFIC_DAY	0	8	2010-01-26	36159	60451	\N	\N
107754	SPECIFIC_DAY	0	8	2010-01-19	36159	60451	\N	\N
107755	SPECIFIC_DAY	0	8	2010-01-20	36159	60451	\N	\N
107756	SPECIFIC_DAY	0	8	2010-01-22	36159	60451	\N	\N
107757	SPECIFIC_DAY	0	8	2010-01-27	36159	60451	\N	\N
107758	SPECIFIC_DAY	0	8	2010-01-21	36159	60451	\N	\N
107759	SPECIFIC_DAY	0	8	2010-01-25	36159	60451	\N	\N
107760	SPECIFIC_DAY	0	0	2010-01-24	36159	60451	\N	\N
107761	SPECIFIC_DAY	0	0	2010-01-23	36159	60451	\N	\N
107762	SPECIFIC_DAY	0	7	2010-01-18	36159	60452	\N	\N
107763	SPECIFIC_DAY	0	7	2009-12-28	36159	60452	\N	\N
107764	SPECIFIC_DAY	0	0	2009-12-27	36159	60452	\N	\N
107765	SPECIFIC_DAY	0	0	2010-01-14	36159	60452	\N	\N
107766	SPECIFIC_DAY	0	0	2010-01-03	36159	60452	\N	\N
107767	SPECIFIC_DAY	0	0	2010-01-17	36159	60452	\N	\N
107768	SPECIFIC_DAY	0	0	2010-01-15	36159	60452	\N	\N
107769	SPECIFIC_DAY	0	0	2010-01-12	36159	60452	\N	\N
107770	SPECIFIC_DAY	0	0	2010-01-02	36159	60452	\N	\N
107771	SPECIFIC_DAY	0	7	2010-01-05	36159	60452	\N	\N
107772	SPECIFIC_DAY	0	0	2010-01-11	36159	60452	\N	\N
107773	SPECIFIC_DAY	0	7	2009-12-24	36159	60452	\N	\N
107774	SPECIFIC_DAY	0	7	2009-12-30	36159	60452	\N	\N
107775	SPECIFIC_DAY	0	0	2009-12-26	36159	60452	\N	\N
107776	SPECIFIC_DAY	0	0	2010-01-09	36159	60452	\N	\N
107777	SPECIFIC_DAY	0	7	2009-12-31	36159	60452	\N	\N
107778	SPECIFIC_DAY	0	0	2010-01-13	36159	60452	\N	\N
107779	SPECIFIC_DAY	0	7	2009-12-29	36159	60452	\N	\N
107780	SPECIFIC_DAY	0	7	2010-01-04	36159	60452	\N	\N
107781	SPECIFIC_DAY	0	0	2010-01-10	36159	60452	\N	\N
107782	SPECIFIC_DAY	0	0	2010-01-06	36159	60452	\N	\N
107783	SPECIFIC_DAY	0	0	2009-12-25	36159	60452	\N	\N
107784	SPECIFIC_DAY	0	0	2010-01-16	36159	60452	\N	\N
107785	SPECIFIC_DAY	0	7	2009-12-22	36159	60452	\N	\N
107786	SPECIFIC_DAY	0	7	2010-01-07	36159	60452	\N	\N
107787	SPECIFIC_DAY	0	0	2010-01-01	36159	60452	\N	\N
107788	SPECIFIC_DAY	0	7	2010-01-08	36159	60452	\N	\N
107789	SPECIFIC_DAY	0	7	2009-12-23	36159	60452	\N	\N
107790	SPECIFIC_DAY	0	7	2010-01-15	49309	61409	\N	\N
107791	SPECIFIC_DAY	0	0	2010-01-17	49309	61409	\N	\N
107792	SPECIFIC_DAY	0	7	2010-01-19	49309	61409	\N	\N
107793	SPECIFIC_DAY	0	0	2010-01-16	49309	61409	\N	\N
107794	SPECIFIC_DAY	0	7	2010-01-14	49309	61409	\N	\N
107795	SPECIFIC_DAY	0	7	2010-01-13	49309	61409	\N	\N
107796	SPECIFIC_DAY	0	7	2010-01-18	49309	61409	\N	\N
107797	SPECIFIC_DAY	0	7	2010-01-08	49302	68693	\N	\N
107798	SPECIFIC_DAY	0	0	2010-01-09	49302	68693	\N	\N
107799	SPECIFIC_DAY	0	7	2010-01-05	49302	68693	\N	\N
107800	SPECIFIC_DAY	0	7	2010-01-11	49302	68693	\N	\N
107801	SPECIFIC_DAY	0	0	2010-01-06	49302	68693	\N	\N
107802	SPECIFIC_DAY	0	7	2010-01-07	49302	68693	\N	\N
107803	SPECIFIC_DAY	0	7	2010-01-12	49302	68693	\N	\N
107804	SPECIFIC_DAY	0	0	2010-01-10	49302	68693	\N	\N
107805	SPECIFIC_DAY	0	7	2010-01-15	49302	68694	\N	\N
107806	SPECIFIC_DAY	0	0	2010-01-16	49302	68694	\N	\N
107807	SPECIFIC_DAY	0	7	2010-01-18	49302	68694	\N	\N
107808	SPECIFIC_DAY	0	0	2010-01-17	49302	68694	\N	\N
107809	SPECIFIC_DAY	0	7	2010-01-13	49302	68694	\N	\N
107810	SPECIFIC_DAY	0	7	2010-01-14	49302	68694	\N	\N
107811	SPECIFIC_DAY	0	7	2010-01-04	49300	68697	\N	\N
107812	SPECIFIC_DAY	0	0	2010-01-03	49300	68697	\N	\N
107813	SPECIFIC_DAY	0	7	2009-12-31	49300	68697	\N	\N
107814	SPECIFIC_DAY	0	0	2010-01-01	49300	68697	\N	\N
107815	SPECIFIC_DAY	0	7	2009-12-30	49300	68697	\N	\N
107816	SPECIFIC_DAY	0	0	2010-01-02	49300	68697	\N	\N
107817	SPECIFIC_DAY	0	7	2010-01-12	49300	68698	\N	\N
107818	SPECIFIC_DAY	0	7	2010-01-07	49300	68698	\N	\N
107819	SPECIFIC_DAY	0	7	2010-01-13	49300	68698	\N	\N
107820	SPECIFIC_DAY	0	7	2010-01-11	49300	68698	\N	\N
107821	SPECIFIC_DAY	0	0	2010-01-06	49300	68698	\N	\N
107822	SPECIFIC_DAY	0	0	2010-01-09	49300	68698	\N	\N
107823	SPECIFIC_DAY	0	0	2010-01-10	49300	68698	\N	\N
107824	SPECIFIC_DAY	0	7	2010-01-05	49300	68698	\N	\N
107825	SPECIFIC_DAY	0	7	2010-01-08	49300	68698	\N	\N
107826	SPECIFIC_DAY	0	7	2010-01-27	49300	68699	\N	\N
107827	SPECIFIC_DAY	0	7	2010-01-25	49300	68699	\N	\N
107828	SPECIFIC_DAY	0	0	2010-01-23	49300	68699	\N	\N
107829	SPECIFIC_DAY	0	3	2010-01-28	49300	68699	\N	\N
107830	SPECIFIC_DAY	0	7	2010-01-26	49300	68699	\N	\N
107831	SPECIFIC_DAY	0	0	2010-01-24	49300	68699	\N	\N
107832	SPECIFIC_DAY	0	0	2009-12-20	49300	68700	\N	\N
107833	SPECIFIC_DAY	0	7	2009-12-21	49300	68700	\N	\N
107834	SPECIFIC_DAY	0	7	2009-12-22	49300	68700	\N	\N
107835	SPECIFIC_DAY	0	0	2009-12-26	49300	68700	\N	\N
107836	SPECIFIC_DAY	0	7	2009-12-23	49300	68700	\N	\N
107837	SPECIFIC_DAY	0	0	2009-12-19	49300	68700	\N	\N
107838	SPECIFIC_DAY	0	7	2009-12-29	49300	68700	\N	\N
107839	SPECIFIC_DAY	0	0	2009-12-25	49300	68700	\N	\N
107840	SPECIFIC_DAY	0	7	2009-12-28	49300	68700	\N	\N
107841	SPECIFIC_DAY	0	7	2009-12-24	49300	68700	\N	\N
107842	SPECIFIC_DAY	0	0	2009-12-27	49300	68700	\N	\N
107843	SPECIFIC_DAY	0	7	2010-01-05	49309	60438	\N	\N
107844	SPECIFIC_DAY	0	0	2010-01-03	49309	60438	\N	\N
107845	SPECIFIC_DAY	0	7	2010-01-04	49309	60438	\N	\N
107846	SPECIFIC_DAY	0	0	2010-01-01	49309	60438	\N	\N
107847	SPECIFIC_DAY	0	7	2009-12-30	49309	60438	\N	\N
107848	SPECIFIC_DAY	0	7	2009-12-31	49309	60438	\N	\N
107849	SPECIFIC_DAY	0	0	2010-01-02	49309	60438	\N	\N
107850	SPECIFIC_DAY	0	7	2009-12-29	49309	60438	\N	\N
107851	SPECIFIC_DAY	0	0	2010-01-16	49300	68691	\N	\N
107852	SPECIFIC_DAY	0	0	2010-01-17	49300	68691	\N	\N
107853	SPECIFIC_DAY	0	7	2010-01-19	49300	68691	\N	\N
107854	SPECIFIC_DAY	0	7	2010-01-14	49300	68691	\N	\N
107855	SPECIFIC_DAY	0	7	2010-01-15	49300	68691	\N	\N
107856	SPECIFIC_DAY	0	7	2010-01-18	49300	68691	\N	\N
75734	SPECIFIC_DAY	21	1	2009-12-29	49313	68706	\N	\N
75736	SPECIFIC_DAY	21	2	2009-12-15	49313	68706	\N	\N
75728	SPECIFIC_DAY	21	0	2009-12-19	49313	68706	\N	\N
75738	SPECIFIC_DAY	21	2	2009-12-28	49313	68706	\N	\N
75739	SPECIFIC_DAY	21	2	2009-12-23	49313	68706	\N	\N
75733	SPECIFIC_DAY	21	2	2009-12-17	49313	68706	\N	\N
75727	SPECIFIC_DAY	21	2	2009-12-21	49313	68706	\N	\N
75730	SPECIFIC_DAY	21	2	2009-12-14	49313	68706	\N	\N
75726	SPECIFIC_DAY	21	0	2009-12-26	49313	68706	\N	\N
75725	SPECIFIC_DAY	21	2	2009-12-18	49313	68706	\N	\N
75731	SPECIFIC_DAY	21	2	2009-12-16	49313	68706	\N	\N
75729	SPECIFIC_DAY	21	0	2009-12-27	49313	68706	\N	\N
75732	SPECIFIC_DAY	21	0	2009-12-20	49313	68706	\N	\N
75735	SPECIFIC_DAY	21	0	2009-12-25	49313	68706	\N	\N
75740	SPECIFIC_DAY	21	2	2009-12-24	49313	68706	\N	\N
75737	SPECIFIC_DAY	21	2	2009-12-22	49313	68706	\N	\N
69159	SPECIFIC_DAY	23	1	2009-12-29	49289	68692	\N	\N
69146	SPECIFIC_DAY	23	1	2010-01-20	49289	68692	\N	\N
69184	SPECIFIC_DAY	23	1	2010-01-11	49289	68692	\N	\N
69189	SPECIFIC_DAY	23	0	2009-12-26	49289	68692	\N	\N
69190	SPECIFIC_DAY	23	0	2010-01-01	49289	68692	\N	\N
69175	SPECIFIC_DAY	23	2	2009-12-17	49289	68692	\N	\N
69185	SPECIFIC_DAY	23	2	2009-12-15	49289	68692	\N	\N
69180	SPECIFIC_DAY	23	0	2010-01-16	49289	68692	\N	\N
69187	SPECIFIC_DAY	23	1	2010-01-15	49289	68692	\N	\N
69179	SPECIFIC_DAY	23	1	2010-01-22	49289	68692	\N	\N
69162	SPECIFIC_DAY	23	1	2009-12-21	49289	68692	\N	\N
66675	SPECIFIC_DAY	23	4	2009-12-16	49289	66060	\N	\N
66696	SPECIFIC_DAY	23	4	2010-01-11	49289	66060	\N	\N
66667	SPECIFIC_DAY	23	4	2009-12-31	49289	66060	\N	\N
66687	SPECIFIC_DAY	23	3	2010-01-19	49289	66060	\N	\N
66660	SPECIFIC_DAY	23	4	2009-12-29	49289	66060	\N	\N
66676	SPECIFIC_DAY	23	0	2009-12-19	49289	66060	\N	\N
66673	SPECIFIC_DAY	23	3	2010-01-14	49289	66060	\N	\N
66678	SPECIFIC_DAY	23	3	2010-01-26	49289	66060	\N	\N
66671	SPECIFIC_DAY	23	0	2009-12-25	49289	66060	\N	\N
66677	SPECIFIC_DAY	23	0	2009-12-27	49289	66060	\N	\N
66664	SPECIFIC_DAY	23	4	2010-01-04	49289	66060	\N	\N
66652	SPECIFIC_DAY	23	4	2010-01-05	49289	66060	\N	\N
66653	SPECIFIC_DAY	23	0	2010-01-01	49289	66060	\N	\N
66668	SPECIFIC_DAY	23	0	2010-01-23	49289	66060	\N	\N
66682	SPECIFIC_DAY	23	3	2010-01-28	49289	66060	\N	\N
66657	SPECIFIC_DAY	23	3	2010-01-27	49289	66060	\N	\N
66666	SPECIFIC_DAY	23	3	2010-01-13	49289	66060	\N	\N
66685	SPECIFIC_DAY	23	0	2010-01-06	49289	66060	\N	\N
66656	SPECIFIC_DAY	23	3	2010-01-22	49289	66060	\N	\N
66694	SPECIFIC_DAY	23	0	2009-12-26	49289	66060	\N	\N
66688	SPECIFIC_DAY	23	4	2009-12-17	49289	66060	\N	\N
66655	SPECIFIC_DAY	23	4	2009-12-15	49289	66060	\N	\N
66679	SPECIFIC_DAY	23	4	2009-12-18	49289	66060	\N	\N
66686	SPECIFIC_DAY	23	3	2010-01-20	49289	66060	\N	\N
66695	SPECIFIC_DAY	23	4	2010-01-12	49289	66060	\N	\N
66659	SPECIFIC_DAY	23	4	2009-12-14	49289	66060	\N	\N
66674	SPECIFIC_DAY	23	0	2010-01-16	49289	66060	\N	\N
66684	SPECIFIC_DAY	23	0	2009-12-20	49289	66060	\N	\N
66692	SPECIFIC_DAY	23	4	2009-12-22	49289	66060	\N	\N
66693	SPECIFIC_DAY	23	4	2009-12-24	49289	66060	\N	\N
66654	SPECIFIC_DAY	23	4	2009-12-28	49289	66060	\N	\N
66670	SPECIFIC_DAY	23	0	2010-01-10	49289	66060	\N	\N
66661	SPECIFIC_DAY	23	0	2010-01-02	49289	66060	\N	\N
66689	SPECIFIC_DAY	23	3	2010-01-25	49289	66060	\N	\N
69161	SPECIFIC_DAY	23	2	2009-12-14	49289	68692	\N	\N
69149	SPECIFIC_DAY	23	1	2010-01-04	49289	68692	\N	\N
69172	SPECIFIC_DAY	23	1	2010-01-18	49289	68692	\N	\N
69170	SPECIFIC_DAY	23	0	2010-01-24	49289	68692	\N	\N
69177	SPECIFIC_DAY	23	1	2009-12-28	49289	68692	\N	\N
66179	SPECIFIC_DAY	23	2	2010-01-27	49302	66054	\N	\N
66158	SPECIFIC_DAY	23	2	2010-01-21	49302	66054	\N	\N
66171	SPECIFIC_DAY	23	2	2010-01-08	49302	66054	\N	\N
66190	SPECIFIC_DAY	23	0	2010-01-01	49302	66054	\N	\N
66047	SPECIFIC_DAY	23	4	2009-12-22	49304	61508	\N	\N
66017	SPECIFIC_DAY	23	3	2010-01-04	49304	61508	\N	\N
66045	SPECIFIC_DAY	23	4	2009-12-14	49304	61508	\N	\N
66010	SPECIFIC_DAY	23	0	2009-12-26	49304	61508	\N	\N
66009	SPECIFIC_DAY	23	4	2009-12-18	49304	61508	\N	\N
66033	SPECIFIC_DAY	23	0	2009-12-19	49304	61508	\N	\N
66052	SPECIFIC_DAY	23	0	2010-01-23	49304	61508	\N	\N
66022	SPECIFIC_DAY	23	4	2009-12-15	49304	61508	\N	\N
66039	SPECIFIC_DAY	23	3	2010-01-07	49304	61508	\N	\N
66048	SPECIFIC_DAY	23	3	2010-01-28	49304	61508	\N	\N
66049	SPECIFIC_DAY	23	3	2010-01-15	49304	61508	\N	\N
66008	SPECIFIC_DAY	23	4	2009-12-17	49304	61508	\N	\N
66019	SPECIFIC_DAY	23	0	2010-01-03	49304	61508	\N	\N
66011	SPECIFIC_DAY	23	3	2009-12-30	49304	61508	\N	\N
66034	SPECIFIC_DAY	23	3	2009-12-24	49304	61508	\N	\N
66023	SPECIFIC_DAY	23	3	2010-01-25	49304	61508	\N	\N
66053	SPECIFIC_DAY	23	0	2010-01-17	49304	61508	\N	\N
66042	SPECIFIC_DAY	23	0	2010-01-16	49304	61508	\N	\N
66035	SPECIFIC_DAY	23	3	2010-01-20	49304	61508	\N	\N
66028	SPECIFIC_DAY	23	0	2010-01-06	49304	61508	\N	\N
66029	SPECIFIC_DAY	23	3	2010-01-11	49304	61508	\N	\N
66014	SPECIFIC_DAY	23	3	2010-01-12	49304	61508	\N	\N
66032	SPECIFIC_DAY	23	3	2010-01-05	49304	61508	\N	\N
66715	SPECIFIC_DAY	23	3	2010-01-14	49302	66061	\N	\N
66713	SPECIFIC_DAY	23	3	2010-01-22	49302	66061	\N	\N
66740	SPECIFIC_DAY	23	4	2010-01-04	49302	66061	\N	\N
66728	SPECIFIC_DAY	23	0	2010-01-02	49302	66061	\N	\N
66741	SPECIFIC_DAY	23	0	2010-01-10	49302	66061	\N	\N
66718	SPECIFIC_DAY	23	3	2010-01-26	49302	66061	\N	\N
66709	SPECIFIC_DAY	23	3	2010-01-20	49302	66061	\N	\N
66662	SPECIFIC_DAY	23	3	2010-01-15	49289	66060	\N	\N
66658	SPECIFIC_DAY	23	0	2010-01-24	49289	66060	\N	\N
66663	SPECIFIC_DAY	23	0	2010-01-09	49289	66060	\N	\N
66681	SPECIFIC_DAY	23	4	2009-12-23	49289	66060	\N	\N
66683	SPECIFIC_DAY	23	4	2010-01-08	49289	66060	\N	\N
66680	SPECIFIC_DAY	23	4	2010-01-07	49289	66060	\N	\N
66665	SPECIFIC_DAY	23	0	2010-01-17	49289	66060	\N	\N
66672	SPECIFIC_DAY	23	0	2010-01-03	49289	66060	\N	\N
66669	SPECIFIC_DAY	23	4	2009-12-30	49289	66060	\N	\N
66651	SPECIFIC_DAY	23	3	2010-01-18	49289	66060	\N	\N
66691	SPECIFIC_DAY	23	3	2010-01-21	49289	66060	\N	\N
66690	SPECIFIC_DAY	23	4	2009-12-21	49289	66060	\N	\N
66044	SPECIFIC_DAY	23	3	2010-01-27	49304	61508	\N	\N
66043	SPECIFIC_DAY	23	0	2009-12-27	49304	61508	\N	\N
66018	SPECIFIC_DAY	23	3	2010-01-26	49304	61508	\N	\N
66040	SPECIFIC_DAY	23	3	2010-01-22	49304	61508	\N	\N
66013	SPECIFIC_DAY	23	3	2010-01-14	49304	61508	\N	\N
66024	SPECIFIC_DAY	23	0	2010-01-10	49304	61508	\N	\N
66036	SPECIFIC_DAY	23	3	2010-01-19	49304	61508	\N	\N
66025	SPECIFIC_DAY	23	3	2009-12-31	49304	61508	\N	\N
66016	SPECIFIC_DAY	23	3	2010-01-21	49304	61508	\N	\N
66031	SPECIFIC_DAY	23	3	2009-12-28	49304	61508	\N	\N
66037	SPECIFIC_DAY	23	0	2010-01-09	49304	61508	\N	\N
66038	SPECIFIC_DAY	23	3	2010-01-13	49304	61508	\N	\N
66012	SPECIFIC_DAY	23	0	2010-01-01	49304	61508	\N	\N
66050	SPECIFIC_DAY	23	3	2010-01-08	49304	61508	\N	\N
66046	SPECIFIC_DAY	23	3	2010-01-18	49304	61508	\N	\N
117996	SPECIFIC_DAY	6	7	2010-02-03	49300	115346	\N	\N
117974	SPECIFIC_DAY	6	7	2010-02-15	49300	115346	\N	\N
117986	SPECIFIC_DAY	6	0	2010-02-20	49300	115346	\N	\N
117992	SPECIFIC_DAY	6	7	2010-02-04	49300	115346	\N	\N
117999	SPECIFIC_DAY	6	3	2010-03-02	49300	115346	\N	\N
117981	SPECIFIC_DAY	6	7	2010-02-02	49300	115346	\N	\N
117997	SPECIFIC_DAY	6	7	2010-02-18	49300	115346	\N	\N
117976	SPECIFIC_DAY	6	7	2010-02-22	49300	115346	\N	\N
117988	SPECIFIC_DAY	6	0	2010-02-06	49300	115346	\N	\N
118002	SPECIFIC_DAY	6	7	2010-03-01	49300	115346	\N	\N
117983	SPECIFIC_DAY	6	7	2010-02-26	49300	115346	\N	\N
117984	SPECIFIC_DAY	6	7	2010-02-08	49300	115346	\N	\N
117991	SPECIFIC_DAY	6	0	2010-02-28	49300	115346	\N	\N
118001	SPECIFIC_DAY	6	7	2010-02-19	49300	115346	\N	\N
118000	SPECIFIC_DAY	6	7	2010-02-25	49300	115346	\N	\N
117989	SPECIFIC_DAY	6	7	2010-02-23	49300	115346	\N	\N
117978	SPECIFIC_DAY	6	7	2010-02-24	49300	115346	\N	\N
117977	SPECIFIC_DAY	6	7	2010-02-09	49300	115346	\N	\N
117979	SPECIFIC_DAY	6	7	2010-02-12	49300	115346	\N	\N
117982	SPECIFIC_DAY	6	0	2010-02-27	49300	115346	\N	\N
117998	SPECIFIC_DAY	6	7	2010-02-01	49300	115346	\N	\N
117990	SPECIFIC_DAY	6	7	2010-02-16	49300	115346	\N	\N
117987	SPECIFIC_DAY	6	0	2010-02-14	49300	115346	\N	\N
117995	SPECIFIC_DAY	6	7	2010-02-05	49300	115346	\N	\N
117994	SPECIFIC_DAY	6	0	2010-02-13	49300	115346	\N	\N
117993	SPECIFIC_DAY	6	7	2010-02-10	49300	115346	\N	\N
117985	SPECIFIC_DAY	6	7	2010-02-17	49300	115346	\N	\N
117980	SPECIFIC_DAY	6	7	2010-02-11	49300	115346	\N	\N
117975	SPECIFIC_DAY	6	0	2010-02-07	49300	115346	\N	\N
118003	SPECIFIC_DAY	6	0	2010-02-21	49300	115346	\N	\N
119764	SPECIFIC_DAY	3	4	2010-02-17	49309	115438	\N	\N
119758	SPECIFIC_DAY	3	4	2010-02-10	49309	115438	\N	\N
119763	SPECIFIC_DAY	3	0	2010-02-13	49309	115438	\N	\N
119754	SPECIFIC_DAY	3	4	2010-02-15	49309	115438	\N	\N
119746	SPECIFIC_DAY	3	4	2010-02-22	49309	115438	\N	\N
119759	SPECIFIC_DAY	3	4	2010-02-12	49309	115438	\N	\N
119747	SPECIFIC_DAY	3	4	2010-02-02	49309	115438	\N	\N
119751	SPECIFIC_DAY	3	4	2010-02-18	49309	115438	\N	\N
119755	SPECIFIC_DAY	3	4	2010-02-03	49309	115438	\N	\N
119750	SPECIFIC_DAY	3	4	2010-02-01	49309	115438	\N	\N
119753	SPECIFIC_DAY	3	4	2010-02-11	49309	115438	\N	\N
119762	SPECIFIC_DAY	3	4	2010-02-23	49309	115438	\N	\N
119752	SPECIFIC_DAY	3	4	2010-02-09	49309	115438	\N	\N
119756	SPECIFIC_DAY	3	4	2010-02-19	49309	115438	\N	\N
119766	SPECIFIC_DAY	3	0	2010-02-07	49309	115438	\N	\N
119765	SPECIFIC_DAY	3	4	2010-02-08	49309	115438	\N	\N
119761	SPECIFIC_DAY	3	4	2010-02-16	49309	115438	\N	\N
119760	SPECIFIC_DAY	3	0	2010-02-21	49309	115438	\N	\N
119768	SPECIFIC_DAY	3	0	2010-02-06	49309	115438	\N	\N
119767	SPECIFIC_DAY	3	2	2010-02-24	49309	115438	\N	\N
119769	SPECIFIC_DAY	3	0	2010-02-20	49309	115438	\N	\N
119757	SPECIFIC_DAY	3	0	2010-02-14	49309	115438	\N	\N
119749	SPECIFIC_DAY	3	4	2010-02-05	49309	115438	\N	\N
119772	SPECIFIC_DAY	3	0	2010-02-06	37573	115439	\N	\N
119780	SPECIFIC_DAY	3	7	2010-02-01	37573	115439	\N	\N
119779	SPECIFIC_DAY	3	7	2010-02-09	37573	115439	\N	\N
119771	SPECIFIC_DAY	3	7	2010-02-11	37573	115439	\N	\N
119776	SPECIFIC_DAY	3	7	2010-02-03	37573	115439	\N	\N
119770	SPECIFIC_DAY	3	7	2010-02-10	37573	115439	\N	\N
119775	SPECIFIC_DAY	3	0	2010-02-07	37573	115439	\N	\N
119777	SPECIFIC_DAY	3	7	2010-02-02	37573	115439	\N	\N
119773	SPECIFIC_DAY	3	7	2010-02-05	37573	115439	\N	\N
119778	SPECIFIC_DAY	3	7	2010-02-08	37573	115439	\N	\N
119774	SPECIFIC_DAY	3	7	2010-02-04	37573	115439	\N	\N
119748	SPECIFIC_DAY	3	4	2010-02-04	49309	115438	\N	\N
119781	SPECIFIC_DAY	3	0	2010-02-07	36159	115440	\N	\N
119786	SPECIFIC_DAY	3	7	2010-02-01	36159	115440	\N	\N
119785	SPECIFIC_DAY	3	7	2010-02-03	36159	115440	\N	\N
119788	SPECIFIC_DAY	3	7	2010-02-05	36159	115440	\N	\N
119782	SPECIFIC_DAY	3	7	2010-02-08	36159	115440	\N	\N
119787	SPECIFIC_DAY	3	0	2010-02-06	36159	115440	\N	\N
119783	SPECIFIC_DAY	3	7	2010-02-04	36159	115440	\N	\N
119784	SPECIFIC_DAY	3	7	2010-02-02	36159	115440	\N	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
9273344	6	27876	27878	0
13271342	18	40109	40101	0
18940363	47	58181	58209	0
2523137	12	1222	1223	0
2523136	12	1221	1222	0
2752524	7	3137	3150	0
2752535	7	3137	3150	0
2752514	7	3137	3150	0
2752520	7	3137	3150	0
2129932	13	1218	1219	0
2752515	7	3131	3151	0
2752525	7	3131	3151	0
2752536	7	3131	3151	0
1245231	8	3132	3131	0
1245234	8	3132	3131	0
1245229	8	3133	3137	0
1245232	8	3133	3137	0
1245230	8	3136	3133	0
1245233	8	3136	3133	0
2752521	7	3131	3151	0
2129927	5	3141	3142	0
2129929	5	3139	3140	0
2129928	5	3139	3142	0
13271320	16	40109	40101	0
13271307	18	40099	40100	0
13271083	18	40099	40100	0
18940326	47	58181	58209	0
1245205	7	1212	1214	0
1245192	7	1212	1214	0
1245206	6	1214	1216	0
1245191	7	1215	1213	0
1245204	7	1215	1213	0
13271316	18	40099	40100	0
13271300	18	40102	40099	0
18940402	47	58181	58209	0
12582947	2	36769	36771	0
13271076	18	40102	40099	0
18940422	47	58189	58183	0
18940362	47	58207	58216	0
12582948	2	36769	36771	0
13271309	18	40102	40099	0
13271306	18	40100	40110	0
13271315	18	40100	40110	0
13271082	18	40100	40110	0
18940399	47	58207	58216	0
13271321	16	40109	40108	0
12582924	13	36771	38389	0
12582946	5	36766	36769	0
12582932	8	36768	36766	0
12582941	8	36768	36766	0
12582934	8	38380	38388	0
12582943	8	38380	38388	0
12582925	8	38380	38388	0
12582927	8	38380	38388	0
12582929	8	38380	38388	0
12582933	8	38388	36768	0
12582942	8	38388	36768	0
12582928	8	38388	36768	0
12582926	8	38388	36768	0
12582949	2	36769	36771	0
18940421	47	58207	58216	0
13271343	18	40109	40108	0
13271319	16	40109	40107	0
13271341	18	40109	40107	0
13271313	18	40106	40110	0
13271304	18	40106	40110	0
13271080	18	40106	40110	0
13271081	18	40110	40111	0
13271314	18	40110	40111	0
13271305	18	40110	40111	0
13271308	18	40102	40103	0
13271075	18	40102	40103	0
13271299	18	40102	40103	0
32440321	19	58225	99891	0
13271301	18	40103	40104	0
13271077	18	40103	40104	0
13271310	18	40103	40104	0
13271311	18	40104	40105	0
13271302	18	40104	40105	0
13271078	18	40104	40105	0
18940370	47	58228	58229	0
13271303	18	40105	40106	0
18940419	47	58185	58232	0
13271079	18	40105	40106	0
13271312	18	40105	40106	0
18940397	47	58185	58232	0
18940360	47	58185	58232	0
18940437	47	58185	58232	0
18940325	47	58185	58232	0
18940403	41	\N	\N	0
18940320	41	\N	\N	0
18940364	41	\N	\N	0
18940327	41	\N	\N	0
34111488	5	58208	58181	0
18940444	47	58194	58182	0
18940440	47	58189	58183	0
18940365	47	58223	58226	0
18940404	47	58223	58226	0
18940428	47	58223	58226	0
18940446	47	58223	58226	0
18940447	47	58224	58225	0
18940405	47	58224	58225	0
18940331	47	58185	58232	0
18940066	57	58185	58232	0
18940018	57	58185	58232	0
18940033	57	58185	58232	0
18939996	57	58179	58200	0
18940028	57	58179	58200	0
18940013	57	58179	58200	0
13271358	3	40111	40110	0
18940059	57	58179	58200	0
18939926	57	58179	58200	0
13271352	5	\N	\N	0
13271354	5	\N	\N	0
13271355	5	\N	\N	0
13271353	5	\N	\N	0
18940060	57	58201	58202	0
13271362	3	40110	40115	0
13271363	3	40111	40110	0
18940014	57	58201	58202	0
18939997	57	58201	58202	0
18939927	57	58201	58202	0
18940029	57	58201	58202	0
18939928	57	58202	58203	0
18940061	57	58202	58203	0
18940015	57	58202	58203	0
18939998	57	58202	58203	0
18940030	57	58202	58203	0
18939929	57	58203	58204	0
18940062	57	58203	58204	0
18939999	57	58203	58204	0
18940031	57	58203	58204	0
18940016	57	58203	58204	0
18940032	57	58204	58205	0
18940063	57	58204	58205	0
18940017	57	58204	58205	0
18940441	47	58236	58189	0
18940423	47	58236	58189	0
18940049	57	58197	58192	0
18940051	57	58192	58198	0
18940067	57	58185	58214	0
18940034	57	58185	58214	0
18940019	57	58185	58214	0
18940332	47	58216	58217	0
18940398	47	58216	58217	0
18940361	47	58216	58217	0
18940053	51	\N	\N	0
18940011	51	\N	\N	0
34111489	5	58208	58181	0
18940426	47	58194	58182	0
18940400	47	58189	58183	0
18940333	47	58207	58216	0
18940340	47	58207	58216	0
18940439	47	58207	58216	0
18940381	47	58207	58216	0
18940384	47	58223	58226	0
18940429	47	58224	58225	0
18940385	47	58224	58225	0
18940448	47	58230	58224	0
18940406	47	58230	58224	0
18940386	47	58230	58224	0
18940366	47	58230	58224	0
18940430	47	58230	58224	0
18940407	47	58226	58228	0
18940431	47	58226	58228	0
18940449	47	58226	58228	0
18940387	47	58226	58228	0
18940367	47	58226	58228	0
18940388	47	58227	58230	0
18940432	47	58227	58230	0
18940368	47	58227	58230	0
18940450	47	58227	58230	0
18940408	47	58227	58230	0
18940433	47	58229	58227	0
18940369	47	58229	58227	0
18940409	47	58229	58227	0
18940451	47	58229	58227	0
18940389	47	58229	58227	0
18940434	47	58228	58229	0
18940410	47	58228	58229	0
18940452	47	58228	58229	0
18940390	47	58228	58229	0
18940020	57	58232	58231	0
18940035	57	58232	58231	0
18940068	57	58232	58231	0
18940338	47	58185	58232	0
18940379	47	58185	58232	0
18940055	57	58221	58236	0
18940058	57	58237	58190	0
18940436	47	58196	58197	0
18940050	57	58190	58198	0
18940339	47	58216	58217	0
18940380	47	58216	58217	0
18940438	47	58216	58217	0
18940420	47	58216	58217	0
18940064	57	58187	58188	0
18940065	57	58190	58187	0
18940056	57	58188	58221	0
18940401	47	\N	58189	0
18939994	51	\N	\N	0
18940026	51	\N	\N	0
18940054	29	\N	\N	0
18940324	41	\N	\N	0
18939993	57	58181	58209	0
38240262	5	115243	115246	0
38240259	5	115243	115246	0
38240276	5	115243	115246	0
38240413	5	115244	115245	0
38240277	5	115244	115245	0
38240414	5	115252	115244	0
38240278	5	115252	115244	0
38240415	5	115245	115249	0
38240263	5	115248	115251	0
38240419	5	115248	115251	0
38240279	5	115248	115251	0
38240420	5	115249	115250	0
38240280	5	115251	115252	0
38240264	5	115251	115252	0
38240421	5	115251	115252	0
38240418	5	115254	115255	0
18940010	57	58181	58209	0
18940382	47	58181	58209	0
18940424	47	58181	58209	0
18940341	47	58181	58209	0
18940025	57	58181	58209	0
18940323	47	58181	58209	0
18940052	57	58181	58209	0
18940442	47	58181	58209	0
18940334	47	58181	58209	0
34111490	5	58208	58181	0
18939995	57	58209	58201	0
18940057	57	58209	58201	0
18940012	57	58209	58201	0
18940027	57	58209	58201	0
18940343	47	58210	58211	0
18940411	47	58210	58211	0
18940453	47	58210	58211	0
18940391	47	58210	58211	0
18940371	47	58210	58211	0
18940435	47	58210	58211	0
32440320	19	58225	99891	0
18939930	57	58204	58205	0
18940000	57	58204	58205	0
18940344	47	58196	58197	0
18940336	47	58196	58197	0
18940372	47	58196	58197	0
18940328	47	58196	58197	0
18940048	57	58196	58197	0
18940392	47	58196	58197	0
18940412	47	58196	58197	0
18940454	47	58196	58197	0
18940445	47	58198	58194	0
18940427	47	58198	58194	0
18940001	57	58176	58177	0
18940037	57	58176	58177	0
18940070	57	58176	58177	0
18940022	57	58176	58177	0
18939931	57	58176	58177	0
18940023	57	58177	58178	0
18940071	57	58177	58178	0
18939932	57	58177	58178	0
18940002	57	58177	58178	0
18940038	57	58177	58178	0
18940003	57	58178	58179	0
18940024	57	58178	58179	0
18940072	57	58178	58179	0
18939933	57	58178	58179	0
18940039	57	58178	58179	0
18940069	57	58214	58213	0
18940036	57	58214	58213	0
18940021	57	58214	58213	0
38240426	2	115241	115265	0
38240417	5	115261	115248	0
38240422	3	115255	115263	0
18940383	41	\N	\N	0
18940425	41	\N	\N	0
18940342	41	\N	\N	0
18940335	41	\N	\N	0
18940443	41	\N	\N	0
38240423	3	115255	115263	0
38240416	5	115257	115259	0
38240412	5	115243	115246	0
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
3636	Incidencias	Incidencia 
26664	incidencias	No indidencia...
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
3738	Incidencia	Ninguna destacada
3739	Incidencia	Nada...
3740	Incidencia	Nada...
7171	Incidencia	Retraso por causa de falta de material
7172	Incidencia	Nada que destacar
7173	Incidencia	Nada que destacar
8201	Incidencia	Non houbo
8202	Incidencia	Non houbo
8203	Incidencia	Non houbo
8204	Incidencia	Non houbo
8205	Incidencia	Perdemos 4 horas por tronada...
8206	Incidencia	Non houbo
8207	Incidencia	Non houbo
8208	Incidencia	Non houbo
17473	Incidencia	.
17474	Incidencia	.
17475	Incidencia	.
17476	Incidencia	.
17477	Incidencia	.
17478	Incidencia	.
17479	Incidencia	.
18887	Incidencia	No
108878	Incidencia	Incidencia
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
108985	50361	100.00
3056	1022	100.00
3099	1126	100.00
3115	1127	100.00
3130	1128	100.00
6178	1129	100.00
6179	1130	100.00
6894	1180	100.00
6895	1181	100.00
6902	1182	100.00
16659	1150	100.00
16660	1151	100.00
16662	1152	100.00
16663	1153	100.00
6186	1154	100.00
\.


--
-- Data for Name: external_company; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY external_company (id, version, name, nif, client, subcontractor, interactswithapplications, appuri, ourcompanylogin, ourcompanypassword, companyuser) FROM stdin;
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
3940
3950
3951
3952
3953
3955
3981
3982
3983
3984
3985
6367
6368
6369
8588
8589
19897
19898
19899
19901
24143
28093
29808
36966
38582
38583
38595
38596
38597
38598
38600
38601
41013
41014
41046
41047
41048
41050
41051
41052
41053
41054
41061
41065
41066
41067
41068
41069
41072
41073
41074
41075
41076
41077
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, index, positionnumber) FROM stdin;
2526	Incidencias	200	0	\N
21109	incidencias	300	0	\N
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
1202
1202
1202
1202
1202
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
1414	1	10.00	2009-12-07	2010-12-07	1217	1313
1415	1	15.00	2009-12-07	2010-12-07	1212	1313
20907	1	10.00	2010-01-02	\N	1217	1315
1419	3	15.00	2009-12-07	\N	1212	1315
1418	3	10.00	2009-12-07	2010-01-01	1217	1315
31815	2	30.00	2009-12-10	\N	31714	1314
1417	3	8.00	2009-12-07	2010-12-07	1217	1314
1416	3	15.00	2009-12-07	2010-12-07	1212	1314
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, name, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line, code) FROM stdin;
32933	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	32832	\N
27790	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	27604	\N
27791	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	430	1.00	f	27606	\N
27792	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	27607	\N
27793	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27608	\N
27794	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27609	\N
1435	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1356	\N
1436	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1358	\N
50567	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50659	PREFIX-00001-00060-00001
50515	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	105	1.00	f	50392	PREFIX-00001-00041-00001
35980	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	35791	\N
2863	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	1.00	f	1150	\N
2864	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	300	1.00	f	1151	\N
1437	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1359	\N
1438	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	110	1.00	f	1362	\N
2865	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1152	\N
2866	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1153	\N
2867	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	140	1.00	f	1154	\N
1439	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1363	\N
1440	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	1364	\N
1441	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1365	\N
1855	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129	\N
1856	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130	\N
35981	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	35792	\N
50516	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50393	PREFIX-00001-00042-00001
50566	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50658	PREFIX-00001-00059-00001
32932	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	32831	\N
109475	3	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	109539	web-00002-00032-00001
29507	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	29321	\N
29508	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29323	\N
29509	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29324	\N
29510	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29325	\N
29511	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29326	\N
2880	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1180	\N
1891	5	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	0.50	f	1180	\N
2881	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	350	1.00	f	1181	\N
2882	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1182	\N
2883	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1183	\N
2843	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1126	\N
1457	10	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127	\N
2844	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127	\N
32983	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	32884	\N
2845	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1128	\N
2846	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129	\N
2847	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130	\N
35982	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35793	\N
35986	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35797	\N
38282	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	38080	\N
50512	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50388	PREFIX-00001-00038-00001
35983	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35794	\N
35984	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	126	1.00	f	35795	\N
35985	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35796	\N
35987	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35798	\N
50513	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50389	PREFIX-00001-00039-00001
50511	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50387	PREFIX-00001-00037-00001
40045	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39885	\N
40046	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	39886	\N
40047	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39887	\N
40035	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39872	\N
40036	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39873	\N
40037	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39875	\N
50555	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50644	PREFIX-00001-00048-00001
50556	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50645	PREFIX-00001-00049-00001
50557	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50647	PREFIX-00001-00050-00001
50558	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50649	PREFIX-00001-00051-00001
50559	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50651	PREFIX-00001-00052-00001
50560	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50652	PREFIX-00001-00053-00001
50561	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50653	PREFIX-00001-00054-00001
50562	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50654	PREFIX-00001-00055-00001
50563	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50655	PREFIX-00001-00056-00001
50564	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50656	PREFIX-00001-00057-00001
40038	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	39876	\N
40039	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39878	\N
40040	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	11	1.00	f	39879	\N
40041	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39880	\N
40042	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39881	\N
40043	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39882	\N
40044	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39884	\N
50565	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50657	PREFIX-00001-00058-00001
50190	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50362	PREFIX-00001-00019-00001
50191	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50363	PREFIX-00001-00020-00001
50192	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50364	PREFIX-00001-00021-00001
50193	19	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50366	PREFIX-00001-00022-00001
50517	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50394	PREFIX-00001-00043-00001
50518	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50395	PREFIX-00001-00044-00001
50519	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50396	PREFIX-00001-00045-00001
50521	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50601	PREFIX-00001-00046-00001
50522	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	84	1.00	f	50602	PREFIX-00001-00047-00001
50568	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50660	PREFIX-00001-00061-00001
50569	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50661	PREFIX-00001-00015-00001
50570	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50662	PREFIX-00001-00016-00001
50575	16	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50670	PREFIX-00001-00062-00001
50576	16	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50671	PREFIX-00001-00063-00001
50189	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	50361	PREFIX-00001-00018-00001
50194	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	49	1.00	f	50367	PREFIX-00001-00023-00001
50195	19	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	50368	PREFIX-00001-00024-00001
50196	19	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50370	PREFIX-00001-00025-00001
50500	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50372	PREFIX-00001-00026-00001
50501	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50373	PREFIX-00001-00027-00001
50502	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	50374	PREFIX-00001-00028-00001
50503	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50375	PREFIX-00001-00029-00001
50504	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50377	PREFIX-00001-00030-00001
50505	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50379	PREFIX-00001-00031-00001
50506	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50381	PREFIX-00001-00032-00001
50507	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50382	PREFIX-00001-00033-00001
50508	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50383	PREFIX-00001-00034-00001
50509	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50385	PREFIX-00001-00035-00001
50510	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50386	PREFIX-00001-00036-00001
109401	13	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	109230	web-00002-00004-00001
109402	13	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	150	1.00	f	109232	web-00002-00005-00001
109403	13	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	109233	web-00002-00006-00001
109404	13	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	109234	web-00002-00007-00001
50514	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50390	PREFIX-00001-00040-00001
109405	13	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	406	1.00	f	109235	web-00002-00008-00001
109446	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	154	1.00	f	109503	web-00002-00017-00001
109447	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	63	1.00	f	109504	web-00002-00018-00001
109448	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	109505	web-00002-00019-00001
109449	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	109506	web-00002-00020-00001
109450	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	109507	web-00002-00021-00001
109451	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	109509	web-00002-00022-00001
109452	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	109510	web-00002-00023-00001
109453	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	109512	web-00002-00024-00001
109463	5	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	109527	web-00002-00030-00001
109464	5	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	109528	web-00002-00031-00001
109454	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	109514	web-00002-00025-00001
109455	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	63	1.00	f	109516	web-00002-00026-00001
109456	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	140	1.00	f	109518	web-00002-00027-00001
109457	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	63	1.00	f	109520	web-00002-00028-00001
109458	12	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	9	1.00	f	109522	web-00002-00029-00001
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
303	8	0
303	8	1
303	8	2
303	8	3
303	8	4
303	0	5
303	0	6
26361	8	0
31916	24	0
31916	24	1
31916	24	2
31916	24	3
31916	24	4
31916	0	5
31916	0	6
36362	7	0
36362	7	1
36362	7	2
36362	7	3
36362	7	4
49498	7	0
49498	7	1
49498	7	2
49498	7	3
49498	7	4
49500	7	0
49500	7	1
49500	7	2
49500	7	3
49500	7	4
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
16661	1149
2932	1149
6187	1035
27689	27605
27690	27603
2945	1179
6896	1179
29406	29322
29407	29320
35867	35766
3052	1357
3053	1361
3054	1360
3042	1325
2739	1022
3100	1022
39934	39874
39935	39877
39936	39883
39924	39823
109312	109229
109313	109231
109335	109508
109336	109511
109337	109513
109338	109515
109339	109517
109340	109519
109341	109521
49251	50360
108986	50360
49252	50371
49253	50376
49254	50378
49255	50380
49256	50384
49257	50391
49258	50398
49267	50643
49268	50646
49269	50648
49270	50650
49273	50669
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
912	18	Vulcano	809
910	1	Cubierta	808
911	1	Motores	808
916	1	2 (Medio)	810
114033	5	Xunta de Galicia	809
914	6	1 (Bajo)	810
913	17	Navantia	809
909	7	Bodega	808
915	9	3 (Alto)	810
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
808	1	Zonas
809	1	Cliente
810	1	Riesgo
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, index, positionnumber) FROM stdin;
2527	Incidencias2	201	0	\N
2525	Incidencia	200	0	\N
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
7272	pleg2	Plegadora A	Pleg. Desc.
1727	cod2	Torno A	Desc
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
1919	107
26462	107
21614	108
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
26563	4	2009-12-09 23:57:32.242	2009-12-25 00:00:00	26462	1726
32017	1	2009-12-10 17:14:26.615	2010-12-10 00:00:00	21614	1718
21513	4	2009-12-09 10:26:10.315	\N	1919	1724
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
26462	4	New configuration unit	0.50	7272
21614	4	New configuration unit	0.25	1727
1919	6	Seleccion de criterios	1.00	1727
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
1121	7	cod1.1	tubo 3/4 pulgadas	6.00	3	f	1023
1123	8	cod2.2	Tubos 20mm	7.00	3	f	1022
1122	8	cod2.1	Tubos 12mm	6.50	3	f	1022
31613	2	kjgkjhg	gfdhgfd	5.00	3	f	31512
1124	8	cod3.1	Tornillos hexagonales	0.45	3	f	1024
25856	3	cod3.1.1	Tornillos 304	55.00	3	f	1024
1125	9	cod3	Tornillo 304	0.50	\N	f	1021
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, estimated_availability, status, order_element_id, material_id, order_element_template_id) FROM stdin;
114140	4	2	5.00	2009-12-14 00:00:00	1	49125	31613	\N
114139	4	1	5.00	2009-12-14 00:00:00	1	49125	31613	\N
114138	4	4	7.00	2009-12-14 00:00:00	1	49125	1123	\N
114141	4	3	55.00	2009-12-14 00:00:00	1	49125	25856	\N
20829	3	2	0.45	2009-12-07 16:23:24.094	0	1325	1124	\N
20828	3	5	0.50	2009-12-07 16:23:24.094	1	1325	1125	\N
20825	3	0	6.00	2009-12-07 16:23:24.094	1	1325	1121	\N
20826	3	2	0.45	2009-12-07 16:23:24.094	1	1325	1124	\N
20827	3	0	6.50	2009-12-07 16:23:24.094	1	1325	1122	\N
20824	3	6	7.00	2009-12-07 16:23:24.094	1	1325	1123	\N
20881	2	0	6.50	\N	1	1356	1122	\N
20882	2	0	7.00	\N	1	1356	1123	\N
20883	2	0	6.00	\N	1	1356	1121	\N
3549	6	6	0.50	2009-12-07 13:59:19.527	1	1022	1125	\N
3548	6	8	6.50	2009-12-07 13:59:19.527	1	1022	1122	\N
3547	6	10	6.00	2009-12-07 13:59:19.527	1	1022	1121	\N
25964	4	0	3.00	2009-11-02 00:00:00	0	1035	1121	\N
25971	3	0	55.00	2009-11-02 00:00:00	1	1035	25856	\N
25972	3	0	6.50	2009-11-02 00:00:00	1	1035	1122	\N
25963	4	0	3.00	2009-11-02 00:00:00	2	1035	1121	\N
25983	2	0	7.00	\N	0	1152	1123	\N
\.


--
-- Data for Name: material_assigment_template; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment_template (id, version, units, unit_price, material_id, order_element_template_id) FROM stdin;
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
1020	9	Tubos	\N
1023	8	Cemento	1020
1022	8	Acero	1020
1021	9	Tornillos	\N
1024	8	Hexagonales	1021
31512	2	exemplo	1024
58479	2	Imported materials without category	\N
108474	1	Acero inoxidable	1022
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
114332	1	Usuarios da aplicación
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled) FROM stdin;
58681	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f
58682	3	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f
58683	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f
58684	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f
114433	2	usuario	ac33881dd89fa8fcbb8bfc11878eb912fe333b068b1efa22ef9031d57800525e97dc45c5a73683be63038a3103029177d63494618fb93e32dff50fb4e3bc28cf	usuario@usuario.com	f
114434	1	usuario2	baa149fe93fdb0a59b0625ea84df1d2e50ee6eaf512c6d0d0f467838a9d7bbcd465198fa4e4a537aca0bef82e702b7a7ed91696f706e871bf751d0014306dfb5	usuario2@usuario.com	f
\.


--
-- Data for Name: order_authorization; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_authorization (id, order_authorization_subclass, version, authorizationtype, order_id, user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
1022	913
1127	909
1127	915
1128	915
1035	912
1130	915
50361	914
49125	114033
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, base_calendar_id, codeautogenerated, lastorderelementsequencecode) FROM stdin;
1325	Xavi	...	t	202	f	0
1022	Xavi	...	t	202	f	0
1035	Xavi	\N	t	202	f	0
27603	Xavi.	\N	t	202	f	0
29320	Responsable	Cliente	t	202	f	0
32883	asdf	\N	t	202	f	0
35766	Xavier Castaño García	\N	t	202	f	0
39823	Xavier Castaño	\N	t	36260	f	0
1179	Xavi	\N	t	202	f	0
49125	Xavier	Xunta de Galicia	t	36260	t	63
109204	Xavier	\N	t	49399	t	32
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, initdate, deadline, mandatoryinit, mandatoryend, description, code, schedulingstatetype, parent, positionincontainer) FROM stdin;
27609	5	Exemplo6	\N	\N	f	f	\N	ped5.6	4	27603	3
1325	7	Contratación de muebles habitaciones	2009-12-07 16:23:24.094	2010-05-07 00:00:00	f	f	Desc.	ped4	4	\N	\N
1356	6	Tarefa1	\N	\N	f	f	\N	ped4.1	0	1325	0
1035	20	Contratación de pintado de casco	2009-11-02 00:00:00	2010-03-25 00:00:00	f	f	Desc.	ped2	3	\N	\N
1149	19	Coordinación	\N	\N	f	f	\N	ped2.1	3	1035	0
1150	19	Reuniones seguimiento 	\N	\N	f	f	\N	ped2.2	0	1149	0
1151	19	Seguimiento proyecto	\N	\N	f	f	\N	ped2.3	0	1149	1
1152	19	Montaje andamios	\N	\N	f	f	\N	ped2.4	0	1035	1
1153	19	Pintado cubierta	\N	\N	f	f	\N	ped2.5	0	1035	2
1154	19	Desmontaje andamios	\N	\N	f	f	\N	ped2.6	0	1035	3
1357	6	Tarefa2	\N	\N	f	f	\N	ped4.2	0	1325	1
1358	6	Subtarefa1.1	\N	\N	f	f	\N	ped4.3	1	1357	0
1359	6	Subtarefa1.2	\N	\N	f	f	\N	ped4.4	1	1357	1
1360	6	Tarefa3	\N	\N	f	f	\N	ped4.5	2	1325	2
1361	6	Subtarefa3.1	\N	\N	f	f	\N	ped4.6	2	1360	0
1362	6	Subsubtarefa3.1.1	\N	\N	f	f	\N	ped4.7	0	1361	0
1363	6	Subsubtarefa3.1.2	\N	\N	f	f	\N	ped4.8	4	1361	1
1364	6	Tarefa4	\N	\N	f	f	\N	ped4.9	0	1325	3
1365	6	Tarefa5	\N	\N	f	f	\N	ped4.10	0	1325	4
1022	22	Contratación de motores	2009-12-07 13:59:19.527	2009-12-25 00:00:00	f	f	Desc	ped1	4	\N	\N
1126	21	Adquisición de piezas	\N	\N	f	f	\N	ped1.1	0	1022	0
1179	7	Entrega de hélices	2009-12-07 16:12:52.395	2009-12-25 00:00:00	f	f	Desc.	ped3	4	\N	\N
1180	7	Tarea1	\N	\N	f	f	\N	ped3.1	0	1179	0
1127	21	Montaje piezas	\N	\N	f	f	\N	ped1.2	0	1022	1
1128	21	Prueba del motor	\N	\N	f	f	\N	ped1.3	0	1022	2
1129	21	Instalación de motor	\N	\N	f	f	\N	ped1.4	0	1022	3
1130	21	Validación funcionamiento	\N	\N	f	f	\N	ped1.5	0	1022	4
32832	3	Nuevo elemento de pedido	\N	\N	f	f	\N	hhhhh	4	29320	5
1181	7	Tarea2	\N	\N	f	f	\N	ped3.2	0	1179	1
1182	7	Tarea3	\N	\N	f	f	\N	ped3.3	0	1179	2
1183	7	Tarea4	\N	\N	f	f	\N	ped3.4	0	1179	3
109527	5	Melloras na pantalla de planificación	\N	\N	f	f	\N	web-00002-00030	0	109231	4
109528	5	Melloras na pantalla de carga de recursos	\N	\N	f	f	\N	web-00002-00031	0	109231	5
35766	11	Portal web para Hospital Modelo	2010-01-22 00:00:00	2010-03-26 00:00:00	f	f	Desarrollo de un portal web para el Hospital Modelo de A Coruña	eng-typo3-17128	4	\N	\N
35797	10	Entorno	\N	\N	f	f	\N	ent	0	35766	7
38080	6	Diseño gráfico	\N	\N	f	f	\N	dis	0	35766	8
29320	5	Pedido de exemplo 2	2009-12-10 01:15:12.433	2010-04-16 00:00:00	f	f	Desc.	ped6	2	\N	\N
29321	5	Exemplo11	\N	\N	f	f	\N	ped6.1	0	29320	0
29322	5	Exemplo12	\N	\N	f	f	\N	ped6.2	3	29320	1
27603	5	Pedido de exemplo 	2009-12-10 00:10:01.713	2010-04-15 00:00:00	f	f	...	ped5	2	\N	\N
27604	5	Exemplo1	\N	\N	f	f	\N	ped5.1	4	27603	0
27605	5	Exemplo2	\N	\N	f	f	\N	ped5.2	2	27603	1
32883	4	pedido bug	2009-12-11 10:20:44.566	2010-01-01 00:00:00	f	f	asdf	codbug	3	\N	\N
32884	4	Exemplo	\N	\N	f	f	\N	codbug1	0	32883	0
27606	5	Exemplo3	\N	\N	f	f	\N	ped5.3	4	27605	0
27607	5	Exemplo4	\N	\N	f	f	\N	ped5.4	0	27605	1
27608	5	Exemplo5	\N	\N	f	f	\N	ped5.5	0	27603	2
35791	10	Coordinación	\N	\N	f	f	\N	coor	0	35766	0
35792	10	Análisis	\N	\N	f	f	\N	ana	0	35766	1
29323	5	Exemplo13	\N	\N	f	f	\N	ped6.3	0	29322	0
29324	5	Exemplo14	\N	\N	f	f	\N	ped6.4	0	29322	1
29325	5	Exemplo15	\N	\N	f	f	\N	ped6.5	0	29320	2
29326	5	Exemplo16	\N	\N	f	f	\N	ped6.6	4	29320	3
32831	3	Nuevo elemento de pedido	\N	\N	f	f	\N	jjjjj	4	29320	4
35793	10	Migración contenidos	\N	\N	f	f	\N	con	0	35766	2
35794	10	Módulo de usuarios	\N	\N	f	f	\N	usu	0	35766	3
35795	10	Plantillas y gestión de contenidos	\N	\N	f	f	\N	plant	0	35766	4
109539	3	Resolución de bugs	\N	\N	f	f	\N	web-00002-00032	0	109517	1
50643	18	Módulo de arquitectura tecnolóxica	\N	\N	f	f	\N	PREFIX-00001-00011	3	49125	10
35796	10	Gestión de especialidades	\N	\N	f	f	\N	esp	0	35766	5
35798	10	Pruebas	\N	\N	f	f	\N	prue	0	35766	6
50644	18	Enlazar a axuda de usuario	\N	\N	f	f	\N	PREFIX-00001-00048	0	50643	0
50645	18	Desenvolvemento de paquetes  Ubuntu	\N	\N	f	f	\N	PREFIX-00001-00049	0	50643	1
50646	18	Módulo de documentación de API	\N	\N	f	f	\N	PREFIX-00001-00012	3	49125	11
50647	18	Documentación das API's públicas	\N	\N	f	f	\N	PREFIX-00001-00050	0	50646	0
50648	18	Módulo de arquivo histórico	\N	\N	f	f	\N	PREFIX-00001-00013	3	49125	12
50649	18	Pasar pedidos a histórico	\N	\N	f	f	\N	PREFIX-00001-00051	0	50648	0
50650	18	Módulo de extracción de informes	\N	\N	f	f	\N	PREFIX-00001-00014	3	49125	13
50651	18	Integración de Jasper Reports	\N	\N	f	f	\N	PREFIX-00001-00052	0	50650	0
50652	18	Informes sobre organizacións de traballo	\N	\N	f	f	\N	PREFIX-00001-00053	0	50650	1
50653	18	Informe sobre partes de traballo	\N	\N	f	f	\N	PREFIX-00001-00054	0	50650	2
39823	9	Desenvolvemento dunha aplicación middleware para impresión de tickets	2009-12-14 00:00:00	2010-01-29 00:00:00	f	f	Desc.	eng-LAMP-17134	4	\N	\N
39872	8	Coordinación	\N	\N	f	f	\N	coor1	0	39823	0
39873	8	Análisis	\N	\N	f	f	\N	ana1	0	39823	1
39874	8	Módulo de comunicación con SEDA	\N	\N	f	f	\N	comseda1	3	39823	2
39875	8	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	\N	f	f	\N	comseda1.1	0	39874	0
39876	8	Implementación de páxina de impresión e fluxo de impresión	\N	\N	f	f	\N	comseda1.2	0	39874	1
39877	8	Módulo de comunicación con JANTO	\N	\N	f	f	\N	comjanto1	3	39823	3
39878	8	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	\N	f	f	\N	comjanto1.1	0	39877	0
39879	8	Mecanismo de sesión e xestión de estado	\N	\N	f	f	\N	comjanto1.2	0	39877	1
39880	8	Obtención de listado de entrada pendentes	\N	\N	f	f	\N	comjanto1.3	0	39877	2
39881	8	Obtención de información para impresión de cada entrada	\N	\N	f	f	\N	comjanto1.4	0	39877	3
39882	8	Notificación de resultado de impresión de entrada	\N	\N	f	f	\N	comjanto1.5	0	39877	4
39883	8	Entorno	\N	\N	f	f	\N	ent1	3	39823	4
39884	8	Gestión de respositorios – Integración	\N	\N	f	f	\N	ent1.1	0	39883	0
39885	8	Montaje entorno de trabajo	\N	\N	f	f	\N	ent1.2	0	39883	1
39886	8	Implantación en producción	\N	\N	f	f	\N	ent1.3	0	39883	2
39887	8	Pruebas	\N	\N	f	f	\N	ent1.4	0	39823	5
49125	22	Proxecto para o desenvolvemento dun sistema de xestión da produción para o sector do auxiliar do naval	2009-12-14 00:00:00	2010-01-30 00:00:00	f	f	\N	PREFIX-00001	3	\N	\N
50654	18	Informes de horas traballadas por un traballador	\N	\N	f	f	\N	PREFIX-00001-00055	0	50650	3
50655	18	Lista de avances de planificación da empresa	\N	\N	f	f	\N	PREFIX-00001-00056	0	50650	4
50656	18	Lista de avances de traballo da empresa	\N	\N	f	f	\N	PREFIX-00001-00057	0	50650	5
50657	18	Informe de horas estimadas/horas realizadas	\N	\N	f	f	\N	PREFIX-00001-00058	0	50650	6
50658	18	Horas realizadas organizadas por tipo de traballo	\N	\N	f	f	\N	PREFIX-00001-00059	0	50650	7
50659	18	Horas estimadas/realizadas por tipo de traballo	\N	\N	f	f	\N	PREFIX-00001-00060	0	50650	8
50660	18	Informe de traballador indicando custos por hora	\N	\N	f	f	\N	PREFIX-00001-00061	0	50650	9
50661	18	Coordinación	\N	\N	f	f	\N	PREFIX-00001-00015	0	49125	14
50662	18	Análise	\N	\N	f	f	\N	PREFIX-00001-00016	0	49125	15
50360	19	Módulo de xestión de usuarios	\N	\N	f	f	\N	PREFIX-00001-00001	3	49125	0
50361	19	Xestión de usuarios	\N	\N	f	f	\N	PREFIX-00001-00018	0	50360	0
50362	19	Xestión de roles	\N	\N	f	f	\N	PREFIX-00001-00019	0	50360	1
50363	19	Xestión de perfiles	\N	\N	f	f	\N	PREFIX-00001-00020	0	50360	2
50364	19	Xestión de roles e pedidos	\N	\N	f	f	\N	PREFIX-00001-00021	0	50360	3
50365	19	Módulo de organización do traballo	\N	\N	f	f	\N	PREFIX-00001-00002	3	49125	1
50366	19	Xestión de código único	\N	\N	f	f	\N	PREFIX-00001-00022	0	50365	0
50367	19	Revisión formulario de pedidos	\N	\N	f	f	\N	PREFIX-00001-00023	0	50365	1
50368	19	Filtrado no listado de pedidos	\N	\N	f	f	\N	PREFIX-00001-00024	0	50365	2
50369	19	Módulo de recursos	\N	\N	f	f	\N	PREFIX-00001-00003	3	49125	2
50370	19	Recursos Virtuais	\N	\N	f	f	\N	PREFIX-00001-00025	0	50369	0
50371	19	Módulo de planificación	\N	\N	f	f	\N	PREFIX-00001-00004	3	49125	3
50372	19	Compartir estado entre pestanas planificación	\N	\N	f	f	\N	PREFIX-00001-00026	0	50371	0
50373	19	Técnica de recálculo de planificación	\N	\N	f	f	\N	PREFIX-00001-00027	0	50371	1
50374	19	Filtrado de pedidos e tarefas de un pedido	\N	\N	f	f	\N	PREFIX-00001-00028	0	50371	2
50669	16	Módulo de asignación de recursos	\N	\N	f	f	\N	PREFIX-00001-00017	3	49125	16
50670	16	Interpolación polinómica na asignación avanzada	\N	\N	f	f	\N	PREFIX-00001-00062	0	50669	0
50671	16	Asignación automática de configuración de máquina	\N	\N	f	f	\N	PREFIX-00001-00063	0	50669	1
50375	19	Modelos de pedidos e planificación	\N	\N	f	f	\N	PREFIX-00001-00029	0	50371	3
50376	19	Módulo de partes de traballo	\N	\N	f	f	\N	PREFIX-00001-00005	3	49125	4
50377	19	Procura de partes de traballo	\N	\N	f	f	\N	PREFIX-00001-00030	0	50376	0
50378	19	Módulo de materiais	\N	\N	f	f	\N	PREFIX-00001-00006	3	49125	5
50379	19	Informe de necesidades de materiais 	\N	\N	f	f	\N	PREFIX-00001-00031	0	50378	0
50380	19	Módulo de xestión da calidade	\N	\N	f	f	\N	PREFIX-00001-00007	3	49125	6
50381	19	Administración de checklists	\N	\N	f	f	\N	PREFIX-00001-00032	0	50380	0
50382	19	Cubrir formularios de calidade en planificación 	\N	\N	f	f	\N	PREFIX-00001-00033	0	50380	1
50383	19	Incorporar as listas de chequeo nos modelos de planificación	\N	\N	f	f	\N	PREFIX-00001-00034	0	50380	2
50384	19	Módulo de integración con subcontratas	\N	\N	f	f	\N	PREFIX-00001-00008	3	49125	7
50385	19	Administración de subcontratas	\N	\N	f	f	\N	PREFIX-00001-00035	0	50384	0
50386	19	Formato de intercambio	\N	\N	f	f	\N	PREFIX-00001-00036	0	50384	1
50387	19	Fluxo de importación/exportación	\N	\N	f	f	\N	PREFIX-00001-00037	0	50384	2
50388	19	Interfaz de xestión de subcontración nos pedidos	\N	\N	f	f	\N	PREFIX-00001-00038	0	50384	3
50389	19	Converter en fitos subcontratacións	\N	\N	f	f	\N	PREFIX-00001-00039	0	50384	4
50390	19	Avance e custo de subcontratas en Técnica de Valor Gañado	\N	\N	f	f	\N	PREFIX-00001-00040	0	50384	5
50391	19	Módulo de Exportación-Importación	\N	\N	f	f	\N	PREFIX-00001-00009	3	49125	8
50392	19	Definir workflows ERP pedidos	\N	\N	f	f	\N	PREFIX-00001-00041	0	50391	0
50393	19	Formato de intercambio de pedidos  e elementos de pedido	\N	\N	f	f	\N	PREFIX-00001-00042	0	50391	1
50394	19	Formato de intercambio de información de avances	\N	\N	f	f	\N	PREFIX-00001-00043	0	50391	2
50395	19	Formato de intercambio de recursos	\N	\N	f	f	\N	PREFIX-00001-00044	0	50391	3
109229	13	Xestion de usuarios	\N	\N	f	f	\N	web-00002-00001	3	109204	0
109230	13	Xestión de Roles e información sensible	\N	\N	f	f	\N	web-00002-00004	0	109229	0
109231	13	Módulo de planificación	\N	\N	f	f	\N	web-00002-00002	3	109204	1
109232	13	Técnica de consolidación de avances	\N	\N	f	f	\N	web-00002-00005	0	109231	0
50396	19	Formato de intercambio de materiais	\N	\N	f	f	\N	PREFIX-00001-00045	0	50391	4
50398	19	Módulo de presentación	\N	\N	f	f	\N	PREFIX-00001-00010	3	49125	9
50601	19	Imprimir o diagrama de Gantt en varias páxinas	\N	\N	f	f	\N	PREFIX-00001-00046	0	50398	0
50602	19	Imprimir información de pantalla  do planificador	\N	\N	f	f	\N	PREFIX-00001-00047	0	50398	1
109204	15	Proxecto para o desenvolvemento dun sistema de xestión da produción para o sector do auxiliar do naval - Release 5	2010-02-01 00:00:00	2010-06-01 00:00:00	f	f	Desc.	web-00002	3	\N	\N
109517	12	Módulo de arquitectura	\N	\N	f	f	\N	web-00002-00014	3	109204	7
109233	13	Reorganización vertical de tarefas Ganttt	\N	\N	f	f	\N	web-00002-00006	0	109231	1
109234	13	Vista aplanada reordenable de tarefas Gantt	\N	\N	f	f	\N	web-00002-00007	0	109231	2
109235	13	Escenarios de planificación	\N	\N	f	f	\N	web-00002-00008	0	109231	3
109502	12	Módulo de asignación de recursos	\N	\N	f	f	\N	web-00002-00009	3	109204	2
109503	12	Vista de asignación de recursos limitantes	\N	\N	f	f	\N	web-00002-00017	0	109502	0
109504	12	Melloras no sistema e pantalla de asignación avanzada	\N	\N	f	f	\N	web-00002-00018	0	109502	1
109505	12	Modificación da unidade mínima de tempo asignable	\N	\N	f	f	\N	web-00002-00019	0	109502	2
109506	12	Gráfica de carga de recursos diferenciada máquina-humano	\N	\N	f	f	\N	web-00002-00020	0	109502	3
109507	12	Gráfico de uso de recursos filtrada por criterio	\N	\N	f	f	\N	web-00002-00021	0	109502	4
109508	12	Módulo de control de avance	\N	\N	f	f	\N	web-00002-00010	3	109204	3
109509	12	Revisión de usabilidade da pantalla de asignación de avances	\N	\N	f	f	\N	web-00002-00022	0	109508	0
109510	12	Acceso directo dende planificación a xestión de avances	\N	\N	f	f	\N	web-00002-00023	0	109508	1
109511	12	Módulo de control de custos	\N	\N	f	f	\N	web-00002-00011	3	109204	4
109512	12	Técnica de valor gañado con información económica	\N	\N	f	f	\N	web-00002-00024	0	109511	0
109513	12	Módulo de xestión da calidade	\N	\N	f	f	\N	web-00002-00012	3	109204	5
109514	12	Asociar lista de chequeo a tipo de avance	\N	\N	f	f	\N	web-00002-00025	0	109513	0
109515	12	Módulo de integración con subcontratas	\N	\N	f	f	\N	web-00002-00013	3	109204	6
109516	12	Consulta da información subcontratada na aplicación	\N	\N	f	f	\N	web-00002-00026	0	109515	0
109518	12	Rendimento e melloras xerais en eficiencia	\N	\N	f	f	\N	web-00002-00027	0	109517	0
109519	12	Módulo de arquivo histórico	\N	\N	f	f	\N	web-00002-00015	3	109204	8
109520	12	Consulta información histórica dos modelos de planificación	\N	\N	f	f	\N	web-00002-00028	0	109519	0
109521	12	Módulo de informes	\N	\N	f	f	\N	web-00002-00016	3	109204	9
109522	12	3 informes definidos polas empresas	\N	\N	f	f	\N	web-00002-00029	0	109521	0
\.


--
-- Data for Name: orderelementtemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelementtemplate (id, version, name, description, code, startasdaysfrombeginning, deadlineasdaysfrombeginning, parent, positionincontainer) FROM stdin;
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid, lasthoursgroupsequencecode) FROM stdin;
1126	0
1127	0
1128	0
1129	0
1130	0
1150	0
1151	0
1152	0
1153	0
1154	0
1180	0
1181	0
1182	0
1183	0
1356	0
1358	0
1359	0
1362	0
1363	0
1364	0
1365	0
27604	0
27606	0
27607	0
27608	0
27609	0
29321	0
29323	0
29324	0
29325	0
29326	0
32831	0
32832	0
32884	0
35791	0
35792	0
35793	0
35794	0
35795	0
35796	0
35797	0
35798	0
38080	0
39872	0
39873	0
39875	0
39876	0
39878	0
39879	0
39880	0
39881	0
39882	0
39884	0
39885	0
39886	0
39887	0
109527	1
109528	1
50361	1
50362	1
50363	1
50364	1
50366	1
50367	1
50383	1
50385	1
50386	1
50387	1
50388	1
50389	1
50390	1
50392	1
50393	1
50394	1
50395	1
50396	1
50601	1
50602	1
50644	1
50645	1
50647	1
50649	1
50651	1
50652	1
50653	1
50654	1
50655	1
50656	1
50657	1
50658	1
50659	1
50368	1
50370	1
50372	1
50373	1
50374	1
50375	1
50377	1
50379	1
50381	1
50382	1
50660	1
50661	1
50662	1
50670	1
50671	1
109230	1
109232	1
109233	1
109234	1
109235	1
109503	1
109504	1
109505	1
109506	1
109507	1
109509	1
109510	1
109512	1
109514	1
109516	1
109518	1
109539	1
109520	1
109522	1
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1022
1035
1149
1179
1325
1357
1360
1361
27603
27605
29320
29322
32883
35766
39823
39874
39877
39883
49125
50360
50365
50369
50371
50376
50378
50380
50384
50391
50398
50643
50646
50648
50650
50669
109204
109229
109231
109502
109508
109511
109513
109515
109517
109519
109521
\.


--
-- Data for Name: orderlinegrouptemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegrouptemplate (group_template_id) FROM stdin;
\.


--
-- Data for Name: orderlinetemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinetemplate (order_line_template_id) FROM stdin;
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
58580	3	PREFIX	1	5	f
106454	4	web	2	5	t
\.


--
-- Data for Name: ordertemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordertemplate (order_template_id, base_calendar_id) FROM stdin;
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
114332	ROLE_BASIC_USER
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype) FROM stdin;
107262	1	Formulario de calidade I	Desc.	0
114534	1	Preguntas tipo cando se perfila peza X	Desc	0
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
107262	¿Defixéchedes esto?	15.00	0	0
107262	¿Creáchedes esto outro?	30.00	1	1
107262	¿Establecéchedes esto?	75.00	2	2
107262	¿Certificación de obra?	100.00	3	3
114534	¿Fixéches a tarefa A?	50.00	0	0
114534	¿Acordácheste de limpar X?	75.00	1	1
114534	¿REcolleches?	100.00	2	2
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, calendar, base_calendar_id) FROM stdin;
49313	2	49395	\N
36159	5	58786	\N
37573	4	58785	\N
49300	3	58784	\N
49304	6	58782	\N
40199	9	58789	\N
49309	7	58783	\N
49297	7	58790	\N
106556	1	106657	\N
114636	2	\N	114736
1720	2	206	\N
1718	2	205	\N
1724	5	208	\N
1722	3	207	\N
7272	6	7373	\N
1726	7	209	\N
1727	9	210	\N
37575	2	37674	\N
49315	2	49396	\N
49302	4	58787	\N
49289	5	58788	\N
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
6367	3	1.00	3141	\N
6369	4	0.69	3139	24953
6368	4	0.50	3139	\N
19903	3	1.00	3140	\N
3984	6	0.69	3131	\N
3981	8	1.00	3133	\N
3985	8	1.00	3133	\N
8589	3	1.00	3136	\N
8588	3	1.00	3137	\N
3983	6	1.00	3132	\N
3982	6	1.00	3132	\N
41065	6	0.75	40099	\N
41074	6	0.75	40099	\N
41076	6	0.75	40099	\N
41072	6	0.75	40099	\N
3940	6	1.00	1212	\N
19901	3	1.00	1214	\N
3952	5	2.08	1213	\N
3951	5	2.08	1213	\N
3950	5	0.25	1216	\N
3953	5	1.00	1215	\N
41067	6	0.75	40099	\N
41075	6	0.75	40100	\N
41077	6	0.75	40100	\N
41073	6	0.75	40100	\N
41066	6	0.75	40100	\N
41068	6	0.75	40100	\N
41013	18	0.48	40108	\N
29807	0	1.00	29595	\N
29808	3	0.36	29593	\N
19898	3	1.00	1223	\N
19899	3	0.82	1221	\N
19897	3	1.00	1222	\N
3955	16	1.36	1218	\N
24143	4	0.87	1219	\N
28093	2	1.02	27878	\N
31014	3	1.00	27876	\N
41014	18	0.75	40109	\N
41050	14	1.00	40111	\N
41069	6	0.07	40098	\N
38596	3	0.11	36765	\N
38601	1	0.04	36770	\N
38595	3	1.00	36766	\N
38582	13	0.42	38380	\N
38597	3	1.00	36767	\N
38583	7	1.00	36768	\N
38600	2	0.44	36771	\N
38598	3	1.00	36769	\N
36966	17	0.09	36764	37371
41061	12	0.75	40103	\N
41051	14	0.75	40104	\N
41046	14	1.00	40104	\N
41052	14	0.75	40105	\N
41047	14	1.00	40105	\N
41048	14	1.00	40106	\N
41053	14	0.75	40106	\N
41054	10	0.11	40097	\N
59217	43	1.25	58181	\N
61494	23	1.00	58182	\N
66056	23	1.00	58182	\N
66078	23	1.00	58182	\N
97675	19	1.14	58200	\N
61464	23	1.00	58236	\N
61478	23	1.00	58236	\N
66154	23	1.00	58236	\N
66133	23	1.00	58237	\N
61465	23	1.00	58237	\N
61452	23	1.00	58237	\N
61493	23	1.00	58237	\N
68680	23	1.00	58237	\N
61426	23	1.00	58237	\N
66077	23	1.00	58237	\N
61507	23	1.00	58237	\N
61479	23	1.00	58237	\N
66055	23	0.29	58234	\N
66054	23	0.29	58234	\N
61508	23	0.46	58234	\N
61474	23	1.00	58190	\N
61430	23	1.00	58190	\N
61505	23	1.00	58190	\N
61490	23	1.00	58190	\N
66069	23	1.00	58190	\N
61453	23	1.00	58182	\N
61411	23	1.00	58182	\N
61480	23	1.00	58182	\N
61427	23	1.00	58182	\N
61466	23	1.00	58182	\N
61481	23	1.00	58183	\N
66057	23	1.00	58183	\N
61454	23	1.00	58183	\N
61467	23	1.00	58183	\N
66079	23	1.00	58183	\N
61495	23	1.00	58183	\N
60410	34	0.30	58231	\N
60446	34	0.27	58231	\N
59276	34	0.30	58231	\N
60431	34	0.30	58231	\N
59285	34	0.30	58231	\N
60432	34	0.33	58232	\N
59277	34	0.33	58232	\N
60411	34	0.33	58232	\N
60447	34	0.33	58232	\N
59286	34	0.33	58232	\N
60425	34	1.00	58201	\N
59240	34	1.00	58201	\N
59270	34	1.00	58201	\N
60404	34	1.00	58201	\N
60440	34	1.00	58201	\N
59279	34	1.00	58201	\N
59260	34	1.00	58201	\N
59253	34	1.00	58201	\N
59261	34	1.00	58202	\N
59280	34	1.00	58202	\N
59271	34	1.00	58202	\N
60405	34	1.00	58202	\N
59241	34	1.00	58202	\N
60441	34	1.00	58202	\N
60426	34	1.00	58202	\N
59254	34	1.00	58202	\N
59281	34	1.67	58203	\N
60427	34	1.67	58203	\N
59272	34	1.67	58203	\N
59262	34	1.67	58203	\N
59242	34	1.67	58203	\N
60406	34	1.67	58203	\N
59255	34	1.67	58203	\N
60442	34	2.50	58203	\N
59282	34	1.00	58204	\N
59263	34	1.00	58204	\N
59256	34	1.00	58204	\N
60428	34	1.00	58204	\N
60436	34	1.20	58213	\N
60412	34	1.20	58213	\N
60451	34	1.20	58213	\N
60437	34	1.00	58214	\N
60452	34	1.00	58214	\N
60413	34	1.00	58214	\N
60430	34	1.00	58185	\N
59265	34	1.00	58185	\N
60445	34	1.00	58185	\N
59275	34	1.00	58185	\N
60409	34	1.00	58185	\N
61409	33	1.00	58194	\N
66080	23	1.00	58223	\N
66081	23	1.00	58226	\N
66082	23	1.50	58228	\N
59189	48	1.00	58176	\N
59194	43	1.00	58177	\N
59191	43	1.00	58177	\N
59199	43	1.00	58177	\N
59220	43	1.00	58177	\N
59195	43	1.00	58178	\N
59221	43	1.00	58178	\N
59200	43	1.00	58178	\N
59222	43	1.00	58179	\N
61483	23	1.00	58216	\N
66085	23	1.00	58216	\N
61498	23	1.00	58216	\N
66062	23	1.00	58216	\N
66086	23	1.00	58217	\N
66063	23	1.00	58217	\N
61484	23	1.00	58217	\N
61499	23	1.00	58217	\N
66066	23	1.00	58187	\N
61456	23	1.00	58187	\N
61502	23	1.00	58187	\N
61428	23	1.00	58187	\N
66089	23	1.00	58187	\N
61471	23	1.00	58187	\N
61487	23	1.00	58187	\N
61472	23	1.00	58188	\N
66134	23	1.00	58182	\N
68681	23	1.40	58182	\N
68682	23	1.00	58183	\N
66135	23	1.00	58183	\N
66061	23	0.52	58235	\N
66060	23	0.52	58235	\N
66149	23	0.50	58207	\N
68695	23	0.50	58207	\N
66148	23	0.50	58207	\N
68696	23	0.50	58207	\N
59269	34	1.67	58209	\N
68704	21	0.25	58210	\N
68705	21	0.25	58211	\N
66136	23	1.00	58223	\N
68683	23	0.75	58223	\N
66137	23	1.50	58224	\N
68684	23	0.75	58224	\N
66138	23	3.00	58225	\N
68685	23	1.00	58225	\N
66139	23	1.00	58226	\N
68686	23	0.75	58226	\N
66140	23	1.00	58227	\N
68687	23	1.00	58227	\N
68688	23	0.75	58228	\N
66141	23	1.50	58228	\N
68689	23	1.00	58229	\N
66142	23	1.00	58229	\N
68690	23	1.00	58230	\N
66143	23	3.00	58230	\N
68692	23	0.16	58219	\N
61497	23	0.16	58219	\N
66059	23	0.16	58219	\N
66084	23	0.16	58219	\N
66145	23	0.16	58219	\N
60433	34	1.00	58196	\N
60448	34	1.00	58196	\N
60449	34	1.00	58197	\N
60434	34	1.00	58197	\N
60450	34	1.00	58198	\N
60435	34	1.00	58198	\N
68693	23	1.00	58216	\N
66146	23	1.00	58216	\N
66147	23	1.00	58217	\N
68694	23	1.00	58217	\N
66150	23	1.00	58187	\N
68697	23	1.00	58187	\N
68698	23	1.00	58188	\N
66151	23	1.00	58188	\N
66152	23	1.00	58189	\N
68699	23	1.00	58189	\N
66092	23	1.00	58190	\N
68700	23	1.00	58190	\N
66153	23	1.00	58190	\N
66064	23	0.50	58207	\N
115380	4	1.00	115244	\N
115381	4	1.00	115245	\N
66088	23	0.50	58207	\N
61485	23	0.50	58207	\N
61470	23	0.50	58207	\N
61486	23	0.50	58207	\N
61501	23	0.50	58207	\N
61469	23	0.50	58207	\N
66087	23	0.50	58207	\N
61500	23	0.50	58207	\N
66065	23	0.50	58207	\N
59218	43	1.00	58208	\N
59239	34	1.67	58209	\N
60424	34	1.67	58209	\N
60403	34	1.67	58209	\N
60439	34	5.00	58209	\N
59232	34	1.67	58209	\N
59278	34	1.67	58209	\N
59252	34	1.67	58209	\N
59259	34	1.67	58209	\N
68706	21	0.25	58210	\N
68707	21	0.25	58211	\N
97674	19	1.14	58200	\N
59273	34	1.00	58204	\N
60443	34	1.00	58204	\N
60407	34	1.00	58204	\N
60429	34	1.33	58205	\N
60444	34	1.33	58205	\N
59264	34	1.33	58205	\N
59257	34	1.33	58205	\N
59283	34	1.33	58205	\N
60408	34	1.33	58205	\N
59274	34	1.33	58205	\N
66076	23	1.00	58236	\N
61492	23	1.00	58236	\N
61506	23	1.00	58236	\N
61451	23	1.00	58236	\N
66132	23	1.00	58236	\N
61429	23	1.00	58188	\N
66090	23	1.00	58188	\N
61488	23	1.00	58188	\N
61457	23	1.00	58188	\N
66067	23	1.00	58188	\N
61503	23	1.00	58188	\N
61458	23	1.00	58189	\N
66068	23	1.00	58189	\N
61504	23	1.00	58189	\N
61489	23	1.00	58189	\N
61473	23	1.00	58189	\N
66091	23	1.00	58189	\N
61459	23	1.00	58190	\N
60423	34	1.00	58192	\N
60438	34	1.00	58192	\N
61455	23	1.00	58221	\N
66083	23	1.00	58221	\N
61468	23	1.00	58221	\N
68691	23	1.00	58221	\N
61482	23	1.00	58221	\N
61496	23	1.00	58221	\N
66058	23	1.00	58221	\N
66144	23	1.00	58221	\N
119894	2	1.00	115246	\N
115437	3	0.50	115259	\N
115364	5	1.00	115248	\N
115442	3	1.00	115249	\N
119887	3	1.00	115250	\N
115365	5	1.00	115251	\N
115366	5	1.00	115252	\N
115440	3	1.00	115254	\N
115441	3	1.00	115255	\N
119897	1	0.50	115267	\N
119904	0	1.00	115265	\N
119905	0	1.00	115241	\N
115439	3	1.00	115261	\N
119895	2	1.00	115263	\N
115438	3	0.50	115257	\N
115346	6	1.00	115243	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
205	\N
206	\N
207	\N
208	\N
209	\N
210	\N
7373	\N
36259	\N
37673	\N
37674	\N
40299	\N
49389	\N
49390	\N
49391	\N
49392	\N
49393	\N
49394	\N
49396	\N
58787	1
58788	1
49395	\N
58786	1
58785	1
58784	1
58782	1
58789	1
58783	1
58790	1
106657	1
114736	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, initdate, enddate, cost_category_id, resource_id) FROM stdin;
26058	1	2009-12-09	\N	1315	1724
21009	3	2009-12-09	2009-12-25	1314	1726
3434	5	2009-12-26	\N	1313	1726
115140	1	2010-01-11	2010-01-30	1313	114636
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
66061	49302
66060	49289
19903	1724
68704	49313
68705	49313
66136	49297
68683	49297
66080	49297
29807	1722
31014	1720
66137	49297
68684	49297
66138	49297
68685	49297
66139	49297
68686	49297
66081	49297
66140	49297
68687	49297
68688	49297
66082	49297
66141	49297
68689	49297
66142	49297
68690	49297
66143	49297
60410	36159
60446	36159
59276	36159
60431	36159
59285	36159
60432	36159
59277	36159
60411	36159
60447	36159
59286	36159
66076	49300
61492	49300
61464	49300
61478	49300
61506	49300
66154	49300
61451	49300
66132	49300
66133	49300
61465	49300
61452	49300
61493	49300
68680	49300
61426	49300
66077	49300
61507	49300
61479	49300
68697	49300
60423	49309
60438	49309
66083	49300
61468	49300
68691	49300
61482	49300
61496	49300
59217	37573
61494	49309
61453	49309
61411	49309
66056	49309
66134	49309
61480	49309
61427	49309
61466	49309
68681	49309
66078	49309
61481	49300
68682	49300
66057	49300
61454	49300
66135	49300
61467	49300
66079	49300
61495	49300
97674	40199
60425	37573
59240	37573
59270	37573
60404	37573
60440	37573
59279	37573
59260	37573
59253	37573
59280	37573
59271	37573
60426	37573
59254	37573
66055	49289
66054	49302
61508	49304
60436	36159
60412	36159
60451	36159
60437	36159
60452	36159
60413	36159
60430	36159
59265	36159
60445	36159
59275	36159
60409	36159
61409	49309
66150	49300
66066	49300
61456	49300
61502	49300
61428	49300
66089	49300
61471	49300
61487	49300
61429	49300
66090	49300
61488	49300
61457	49300
68698	49300
66067	49300
66151	49300
61503	49300
61472	49300
61458	49300
66068	49300
61504	49300
66152	49300
61489	49300
68699	49300
61473	49300
66091	49300
61459	49300
61474	49300
66092	49300
61430	49300
61505	49300
68700	49300
61490	49300
66153	49300
66069	49300
115364	37573
115442	37573
119887	37573
115365	37573
115366	37573
115440	36159
115441	36159
119897	49309
66064	49289
66088	49302
61485	49289
61470	49302
66149	49302
61486	49302
61501	49302
61469	49289
66087	49289
68695	49289
66148	49289
61500	49289
66065	49302
68696	49302
59218	37573
59239	37573
60424	37573
60403	37573
60439	37573
59232	37573
59278	37573
59269	37573
59252	37573
59259	37573
68706	49313
68707	49313
68692	49289
61497	49289
66059	49289
66084	49289
66145	49289
97675	40199
59261	37573
60405	37573
59241	37573
60441	37573
59281	37573
60427	37573
59272	37573
59262	37573
59242	37573
60406	37573
59255	37573
60442	37573
59273	37573
60443	37573
60407	37573
59282	37573
59263	37573
59256	37573
60428	37573
60429	37573
60444	37573
59264	37573
59257	37573
59283	37573
60408	37573
59274	37573
60433	49309
60448	49309
60449	49309
60434	49309
60450	49309
60435	49309
59189	40199
59194	40199
59191	40199
59199	40199
59220	40199
59195	40199
59221	40199
119904	49297
119905	49297
115439	37573
119895	36159
115438	49309
115346	49300
115380	37573
115381	37573
119894	49300
115437	49309
59200	40199
59222	40199
61483	49302
66085	49302
61498	49302
68693	49302
66146	49302
66062	49302
66086	49302
66147	49302
66063	49302
61484	49302
61499	49302
68694	49302
61455	49300
66058	49300
66144	49300
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
4245	2009-12-08	0.10	0.20	0
4245	2009-12-12	0.40	0.55	1
4245	2009-12-15	0.60	0.80	2
4245	2009-12-20	1.00	1.00	3
24953	2009-12-10	0.10	0.05	0
24953	2009-12-12	0.20	0.15	1
24953	2009-12-20	0.50	0.45	2
24953	2010-01-01	1.00	1.00	3
37371	2010-02-16	0.40	0.10	0
37371	2010-03-26	1.00	1.00	1
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
4245
24953
37371
\.


--
-- Data for Name: subcontractedtaskdata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY subcontractedtaskdata (id, version, externalcompany, subcontratationdate, subcontractcommunicationdate, workdescription, subcontractprice, subcontractedcode, nodewithoutchildrenexported, labelsexported, materialassignmentsexported, hoursgroupsexported, criterionrequirementsexported) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate, subcontrated_task_data_id) FROM stdin;
1212	1	1	2009-11-28 16:06:06.476	\N
1214	1	0	\N	\N
1213	2	0	\N	\N
1216	1	0	\N	\N
1215	1	1	2009-12-15 02:35:46.838	\N
40097	2	0	\N	\N
40098	2	0	\N	\N
40099	1	1	2010-01-26 06:00:00	\N
40100	1	0	\N	\N
40102	1	0	\N	\N
40103	1	0	\N	\N
40104	1	0	\N	\N
40105	1	0	\N	\N
40106	1	0	\N	\N
40108	2	0	\N	\N
40109	1	0	\N	\N
40110	1	0	\N	\N
40111	1	1	2010-02-05 04:48:00	\N
3141	1	1	2010-02-26 03:54:19.558	\N
3139	1	0	\N	\N
3142	1	0	\N	\N
3140	1	0	\N	\N
27878	2	0	\N	\N
27876	1	0	\N	\N
33027	1	0	\N	\N
33028	1	0	\N	\N
29593	2	1	2010-01-11 12:05:14.108	\N
29595	0	1	2010-01-07 20:25:18.472	\N
33032	1	0	\N	\N
1218	2	0	\N	\N
1219	2	0	\N	\N
1221	2	1	2009-12-18 18:15:42.474	\N
1222	1	0	\N	\N
1223	1	0	\N	\N
3131	2	0	\N	\N
3132	1	1	2010-03-01 19:34:15.194	\N
3133	1	0	\N	\N
3136	1	1	2010-02-07 21:34:41.378	\N
3137	1	1	2010-04-09 05:03:29.372	\N
36765	2	1	2010-01-20 21:07:33.24	\N
36770	2	0	\N	\N
36766	1	0	\N	\N
38380	2	0	\N	\N
36767	1	1	2010-02-18 22:17:25.42	\N
36768	1	0	\N	\N
36771	2	1	2010-03-19 04:15:21.12	\N
36769	1	1	2010-03-16 03:11:51.036	\N
36764	2	0	\N	\N
115263	1	0	\N	\N
115276	1	0	\N	\N
115265	1	0	\N	\N
115267	1	0	\N	\N
58192	1	0	\N	\N
58194	1	0	\N	\N
58196	1	0	\N	\N
58197	1	0	\N	\N
58198	1	0	\N	\N
58200	2	0	\N	\N
58201	1	0	\N	\N
58202	1	0	\N	\N
58203	2	0	\N	\N
58204	2	0	\N	\N
58205	2	0	\N	\N
58207	1	0	\N	\N
58208	2	0	\N	\N
115241	1	1	2010-01-31 23:32:36.12	\N
115243	1	0	\N	\N
58209	2	0	\N	\N
58210	1	0	\N	\N
58211	1	0	\N	\N
58213	1	0	\N	\N
58214	1	0	\N	\N
58216	1	0	\N	\N
58217	1	0	\N	\N
58219	2	0	\N	\N
58221	1	0	\N	\N
58223	1	0	\N	\N
58224	1	0	\N	\N
58225	1	0	\N	\N
58226	1	0	\N	\N
58227	1	0	\N	\N
58228	1	0	\N	\N
58229	1	0	\N	\N
58230	2	0	\N	\N
58231	2	0	\N	\N
58232	2	0	\N	\N
58234	2	0	\N	\N
58235	2	0	\N	\N
58236	1	0	\N	\N
58237	1	0	\N	\N
115244	1	0	\N	\N
115245	1	0	\N	\N
115246	1	0	\N	\N
115270	1	0	\N	\N
115271	1	0	\N	\N
115248	1	0	\N	\N
115249	1	0	\N	\N
58176	1	0	\N	\N
58177	1	0	\N	\N
58178	1	0	\N	\N
58179	1	0	\N	\N
58181	1	1	2009-12-23 10:42:02.377	\N
58182	2	0	\N	\N
58183	1	0	\N	\N
58185	1	0	\N	\N
58187	1	0	\N	\N
58188	1	0	\N	\N
58189	1	0	\N	\N
58190	1	0	\N	\N
115250	1	0	\N	\N
115251	1	0	\N	\N
115252	1	0	\N	\N
115254	1	0	\N	\N
115255	1	0	\N	\N
115257	1	0	\N	\N
115259	1	0	\N	\N
115261	1	0	\N	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id) FROM stdin;
107367	5	107262	50361
114233	2	107262	49125
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
107367	¿Creáchedes esto outro?	30.00	1	f	\N	1
107367	¿Establecéchedes esto?	75.00	2	f	\N	2
107367	¿Certificación de obra?	100.00	3	f	\N	3
107367	¿Defixéchedes esto?	15.00	0	t	2009-12-30 00:00:00	0
114233	¿Defixéchedes esto?	15.00	0	f	\N	0
114233	¿Creáchedes esto outro?	30.00	1	f	\N	1
114233	¿Establecéchedes esto?	75.00	2	f	\N	2
114233	¿Certificación de obra?	100.00	3	f	\N	3
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
1217	2847
1217	2846
1217	2844
1217	2843
1217	2845
1220	2863
1220	2864
36772	35987
36772	35986
1224	2863
1224	2864
1224	2865
1224	2866
1224	2867
36772	35983
36772	35981
36772	35982
36772	35985
36772	35984
36772	35980
3134	1439
3134	1438
3135	1439
3135	1438
3131	1435
3132	1436
3138	1439
3138	1435
3138	1438
3138	1440
3138	1441
3138	1436
3138	1437
3132	1437
3133	1438
3136	1440
3137	1441
3143	2881
3143	2880
3143	2883
3143	2882
1212	2843
3139	2880
3139	1891
3140	2881
3141	2882
3142	2883
1213	1457
1213	2844
1214	2845
1215	2846
1215	1855
1216	1856
1216	2847
115241	109401
115243	109402
115244	109403
115245	109404
115246	109405
115270	109463
40097	40035
40098	40036
40099	40037
40100	40038
40102	40039
1218	2863
1219	2864
1221	2865
1222	2866
1223	2867
40103	40040
27877	27792
27877	27791
40104	40041
27879	27792
27879	27793
27879	27794
27879	27791
27879	27790
40105	40042
40106	40043
40108	40044
40109	40045
40110	40046
40111	40047
115271	109464
115248	109446
115249	109447
115250	109448
58180	50189
58180	50190
58180	50191
58180	50192
115251	109449
27876	27792
27878	27793
115252	109450
29594	29509
29594	29508
115254	109451
29596	29511
29596	29507
29596	29510
29596	29509
29596	29508
58184	50193
36764	35980
36765	35981
36766	35982
33027	29507
29593	29508
33028	29509
29595	29510
36767	35983
33033	32983
33032	32983
36768	35984
36769	35985
36771	35987
36770	35986
38380	38282
58184	50194
58184	50195
115255	109452
58186	50196
40101	40038
40101	40037
115257	109453
115259	109454
115261	109455
115263	109456
58191	50500
40107	40043
40107	40041
40107	40040
40107	40039
40107	40042
58191	50501
58191	50502
58191	50503
115276	109475
40112	40045
40112	40046
40112	40044
40112	40047
40113	40045
40113	40043
40113	40040
40113	40046
40113	40039
40113	40037
40113	40036
40113	40041
40113	40038
40113	40044
40113	40035
40113	40047
40113	40042
58193	50504
115265	109457
58195	50505
115267	109458
58199	50507
58199	50508
58199	50506
58206	50513
58206	50514
58206	50510
58206	50509
58206	50512
58206	50511
58212	50515
58212	50519
58212	50517
58212	50518
58212	50516
58215	50522
58215	50521
58218	50555
58218	50556
58220	50557
58222	50558
58233	50568
58233	50563
58233	50562
58233	50565
58233	50564
58233	50566
58233	50560
58233	50561
58233	50559
58233	50567
58238	50576
58238	50575
58239	50563
58239	50196
58239	50501
58239	50194
58239	50517
58239	50518
58239	50192
58239	50521
58239	50505
58239	50568
58239	50569
58239	50195
58239	50565
58239	50566
58239	50509
58239	50516
58239	50570
58239	50564
58239	50506
58239	50561
58239	50513
58239	50189
58239	50500
58239	50507
58239	50576
58239	50504
58239	50502
58239	50575
58239	50522
58239	50193
58239	50514
58239	50558
58239	50557
58239	50510
58239	50562
58239	50556
58239	50191
58239	50503
58239	50512
58239	50190
58239	50555
58239	50515
58239	50508
58239	50519
58239	50560
58239	50559
58239	50511
58239	50567
58176	50189
58177	50190
58178	50191
58179	50192
58181	50193
58182	50194
58183	50195
58185	50196
58187	50500
58188	50501
58189	50502
58190	50503
58192	50504
58194	50505
58196	50506
58197	50507
58198	50508
58200	50509
58201	50510
58202	50511
58203	50512
58204	50513
58205	50514
58207	50515
58208	50516
58209	50517
58210	50518
58211	50519
58213	50521
58214	50522
58216	50555
58217	50556
58219	50557
58221	50558
58223	50559
58224	50560
58225	50561
58226	50562
58227	50563
58228	50564
58229	50565
58230	50566
58231	50567
58232	50568
58234	50569
58235	50570
58236	50575
58237	50576
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
3141	10	Tarea3	\N	2010-02-26 03:54:19.558	2010-03-11 03:54:19.558	\N	3143	\N	2
3139	11	Tarea1	\N	2009-12-07 16:12:52.395	2010-01-01 16:12:52.395	\N	3143	\N	0
3142	10	Tarea4	\N	2010-03-11 03:54:19.558	2010-03-23 15:54:19.558	\N	3143	\N	3
3140	11	Tarea2	\N	2010-01-01 16:12:52.395	2010-02-25 16:12:52.395	\N	3143	\N	1
3143	10	\N	\N	2009-12-07 16:12:52.395	2010-03-23 15:54:19.558	2009-12-25	\N	\N	\N
1212	27	Adquisición de piezas	\N	2009-12-07 13:59:19.527	2009-12-24 13:59:19.527	\N	1217	\N	0
1214	27	Prueba del motor	\N	2009-12-24 13:59:19.527	2010-02-18 13:59:19.527	\N	1217	\N	2
1213	27	Montaje piezas	\N	2010-01-08 02:35:46.838	2010-01-16 02:35:46.838	\N	1217	\N	1
1216	27	Validación funcionamiento	\N	2010-02-18 13:59:19.527	2010-03-25 13:59:19.527	\N	1217	\N	4
1215	27	Instalación de motor	\N	2009-12-15 02:35:46.838	2010-01-08 02:35:46.838	\N	1217	\N	3
1217	27	\N	\N	2009-12-07 13:59:19.527	2010-03-25 13:59:19.527	2009-12-25	\N	\N	\N
36769	26	Gestión de especialidades	\N	2010-03-17 00:00:00	2010-03-19 00:00:00	\N	36772	\N	5
1218	33	Reuniones seguimiento 	\N	2009-11-02 00:00:00	2010-02-27 00:00:00	\N	1220	\N	0
1219	33	Seguimiento proyecto	\N	2010-02-27 00:00:00	2010-04-29 00:00:00	\N	1220	\N	1
1220	32	Coordinación	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	\N	1224	\N	0
1221	33	Montaje andamios	\N	2009-12-18 18:15:42.474	2010-02-12 18:15:42.474	\N	1224	\N	1
1222	33	Pintado cubierta	\N	2010-02-12 18:15:42.474	2010-03-30 18:15:42.474	\N	1224	\N	2
1223	33	Desmontaje andamios	\N	2010-03-30 18:15:42.474	2010-04-23 18:15:42.474	\N	1224	\N	3
1224	32	\N	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	2010-03-25	\N	\N	\N
33032	3	\N	\N	\N	\N	\N	33033	\N	0
33033	3	\N	\N	\N	\N	2010-01-01	\N	\N	\N
36764	26	Coordinación	\N	2010-01-22 00:00:00	2010-03-26 00:00:00	\N	36772	\N	0
36772	26	\N	\N	2010-01-22 00:00:00	2010-03-26 15:02:48.34	2010-03-26	\N	\N	\N
40115	5	Entrega	\N	2010-02-12 15:36:00	2010-02-12 15:36:00	\N	40113	\N	5
3150	11	validacion previa	\N	2010-04-24 21:34:41.378	2010-04-24 21:34:41.378	\N	1224	\N	4
3131	12	Tarefa1	\N	2010-04-05 19:34:15.194	2010-04-23 19:34:15.194	\N	3138	\N	0
3132	12	Tarefa2	\N	2010-03-01 19:34:15.194	2010-04-05 19:34:15.194	\N	3138	\N	1
3133	12	Subsubtarefa3.1.1	\N	2010-03-29 21:34:41.378	2010-04-11 21:34:41.378	\N	3134	\N	0
27878	12	Exemplo5	\N	2010-01-16 00:10:01.713	2010-04-13 00:10:01.713	\N	27879	\N	1
27877	12	Exemplo2	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27879	\N	0
3151	11	entrega	\N	2010-04-23 19:34:15.194	2010-04-23 19:34:15.194	\N	1224	\N	5
27876	12	Exemplo4	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27877	\N	0
27879	12	\N	\N	2009-12-10 00:10:01.713	2010-04-13 00:10:01.713	2010-04-15	\N	\N	\N
36765	26	Análisis	\N	2010-01-22 00:00:00	2010-02-18 20:21:57.46	\N	36772	\N	1
38389	11	Entrega	\N	2010-03-26 15:02:48.34	2010-03-26 15:02:48.34	\N	36772	\N	10
36770	26	Entorno	\N	2010-01-22 00:00:00	2010-03-25 20:19:23.46	\N	36772	\N	6
3134	12	Subtarefa3.1	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3135	\N	0
3135	12	Tarefa3	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3138	\N	2
3136	12	Tarefa4	\N	2010-02-07 21:34:41.378	2010-03-29 21:34:41.378	\N	3138	\N	3
3137	12	Tarefa5	\N	2010-04-11 21:34:41.378	2010-04-24 21:34:41.378	\N	3138	\N	4
3138	12	\N	\N	2009-12-07 16:23:24.094	2010-04-24 21:34:41.378	2010-05-07	\N	\N	\N
36766	26	Migración contenidos	\N	2010-03-16 00:00:00	2010-03-17 00:00:00	\N	36772	\N	2
29593	6	Exemplo13	\N	2010-01-11 12:05:14.108	2010-04-19 12:05:14.108	\N	29594	\N	0
29594	6	Exemplo12	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	\N	29596	\N	0
29595	6	Exemplo15	\N	2010-01-07 20:25:18.472	2010-01-19 20:25:18.472	\N	29596	\N	1
29596	6	\N	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	2010-04-16	\N	\N	\N
38380	19	Diseño gráfico	\N	2010-01-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	8
36767	26	Módulo de usuarios	\N	2010-02-18 22:17:25.42	2010-02-19 22:17:25.42	\N	36772	\N	3
38388	11	Entrega de diseño	\N	2010-02-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	9
36768	26	Plantillas y gestión de contenidos	\N	2010-02-22 00:00:00	2010-03-16 00:00:00	\N	36772	\N	4
58185	72	Recursos Virtuais	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58186	\N	0
58187	72	Compartir estado entre pestanas planificación	\N	2009-12-30 00:00:00	2010-01-05 00:00:00	\N	58191	\N	0
33027	2	\N	\N	\N	\N	\N	29596	\N	2
33028	2	\N	\N	\N	\N	\N	29594	\N	1
58188	72	Técnica de recálculo de planificación	\N	2010-01-05 00:00:00	2010-01-14 00:00:00	\N	58191	\N	1
58189	72	Filtrado de pedidos e tarefas de un pedido	\N	2010-01-23 00:00:00	2010-01-29 00:00:00	\N	58191	\N	2
58190	72	Modelos de pedidos e planificación	\N	2009-12-19 00:00:00	2009-12-30 00:00:00	\N	58191	\N	3
58194	72	Informe de necesidades de materiais 	\N	2010-01-13 00:00:00	2010-01-20 00:00:00	\N	58195	\N	0
36771	26	Pruebas	\N	2010-03-19 04:15:21.12	2010-03-25 23:26:51.20	\N	36772	\N	7
58213	72	Imprimir o diagrama de Gantt en varias páxinas	\N	2010-01-19 00:00:00	2010-01-28 00:00:00	\N	58215	\N	0
58180	81	Módulo de xestión de usuarios	\N	2009-12-14 00:00:00	2010-01-05 00:00:00	\N	58239	\N	0
58195	81	Módulo de materiais	\N	2009-12-14 00:00:00	2010-01-20 00:00:00	\N	58239	\N	5
115270	4	\N	\N	\N	\N	\N	115247	\N	4
115271	4	\N	\N	\N	\N	\N	115247	\N	5
40097	27	Coordinación	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	0
115276	2	\N	\N	\N	\N	\N	115264	\N	1
40098	27	Análisis	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	1
40099	27	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	2010-01-26 06:00:00	2010-01-29 06:00:00	\N	40101	\N	0
40100	27	Implementación de páxina de impresión e fluxo de impresión	\N	2010-01-29 06:00:00	2010-02-05 06:00:00	\N	40101	\N	1
40101	27	Módulo de comunicación con SEDA	\N	2010-01-14 00:00:00	2010-02-05 06:00:00	\N	40113	\N	2
40102	27	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	2010-01-14 00:00:00	2010-01-19 03:36:00	\N	40107	\N	0
40103	27	Mecanismo de sesión e xestión de estado	\N	2010-01-19 03:36:00	2010-01-21 03:36:00	\N	40107	\N	1
40104	27	Obtención de listado de entrada pendentes	\N	2010-01-21 03:36:00	2010-01-22 03:36:00	\N	40107	\N	2
40105	27	Obtención de información para impresión de cada entrada	\N	2010-01-22 03:36:00	2010-01-23 03:36:00	\N	40107	\N	3
40106	27	Notificación de resultado de impresión de entrada	\N	2010-01-23 03:36:00	2010-01-26 03:36:00	\N	40107	\N	4
40107	27	Módulo de comunicación con JANTO	\N	2010-01-14 00:00:00	2010-01-26 03:36:00	\N	40113	\N	3
40108	27	Gestión de respositorios – Integración	\N	2010-01-14 00:00:00	2010-02-12 00:00:00	\N	40112	\N	0
40109	27	Montaje entorno de trabajo	\N	2010-01-11 00:00:00	2010-01-14 00:00:00	\N	40112	\N	1
40110	27	Implantación en producción	\N	2010-02-10 19:12:00	2010-02-11 22:48:00	\N	40112	\N	2
40112	27	Entorno	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	4
40111	27	Prueba	\N	2010-02-05 04:48:00	2010-02-10 19:12:00	\N	40113	\N	6
40113	27	\N	\N	2010-01-11 00:00:00	2010-02-12 15:36:00	2010-02-12	\N	\N	\N
58176	72	Xestión de usuarios	\N	2009-12-14 00:00:00	2009-12-15 00:00:00	\N	58180	\N	0
58177	72	Xestión de roles	\N	2009-12-15 00:00:00	2009-12-17 00:00:00	\N	58180	\N	1
58178	72	Xestión de perfiles	\N	2009-12-17 00:00:00	2009-12-19 00:00:00	\N	58180	\N	2
58179	72	Xestión de roles e pedidos	\N	2009-12-19 00:00:00	2010-01-05 00:00:00	\N	58180	\N	3
58214	72	Imprimir información de pantalla  do planificador	\N	2009-12-22 00:00:00	2010-01-19 00:00:00	\N	58215	\N	1
58181	72	Xestión de código único	\N	2009-12-24 00:00:00	2010-01-01 00:00:00	\N	58184	\N	0
58182	72	Revisión formulario de pedidos	\N	2010-01-20 00:00:00	2010-01-27 00:00:00	\N	58184	\N	1
58183	72	Filtrado no listado de pedidos	\N	2010-01-29 00:00:00	2010-01-30 00:00:00	\N	58184	\N	2
58192	72	Procura de partes de traballo	\N	2009-12-29 00:00:00	2010-01-06 00:00:00	\N	58193	\N	0
58196	72	Administración de checklists	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58199	\N	0
58197	72	Cubrir formularios de calidade en planificación 	\N	2009-12-22 00:00:00	2009-12-29 00:00:00	\N	58199	\N	1
58198	72	Incorporar as listas de chequeo nos modelos de planificación	\N	2010-01-06 00:00:00	2010-01-13 00:00:00	\N	58199	\N	2
58200	72	Administración de subcontratas	\N	2010-01-05 00:00:00	2010-01-15 00:00:00	\N	58206	\N	0
58201	72	Formato de intercambio	\N	2010-01-05 00:00:00	2010-01-08 00:00:00	\N	58206	\N	1
58202	72	Fluxo de importación/exportación	\N	2010-01-08 00:00:00	2010-01-14 00:00:00	\N	58206	\N	2
58203	72	Interfaz de xestión de subcontración nos pedidos	\N	2010-01-14 00:00:00	2010-01-17 00:00:00	\N	58206	\N	3
58204	72	Converter en fitos subcontratacións	\N	2010-01-17 00:00:00	2010-01-20 00:00:00	\N	58206	\N	4
58205	72	Avance e custo de subcontratas en Técnica de Valor Gañado	\N	2010-01-20 00:00:00	2010-01-23 00:00:00	\N	58206	\N	5
58207	72	Definir workflows ERP pedidos	\N	2009-12-14 00:00:00	2010-01-05 00:00:00	\N	58212	\N	0
58208	72	Formato de intercambio de pedidos  e elementos de pedido	\N	2009-12-14 00:00:00	2009-12-24 00:00:00	\N	58212	\N	1
58209	72	Formato de intercambio de información de avances	\N	2010-01-01 00:00:00	2010-01-05 00:00:00	\N	58212	\N	2
58210	72	Formato de intercambio de recursos	\N	2009-12-14 00:00:00	2009-12-30 00:00:00	\N	58212	\N	3
58211	72	Formato de intercambio de materiais	\N	2009-12-30 00:00:00	2010-01-21 00:00:00	\N	58212	\N	4
58184	81	Módulo de organización do traballo	\N	2009-12-14 00:00:00	2010-01-30 00:00:00	\N	58239	\N	1
58186	81	Módulo de recursos	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58239	\N	2
58191	81	Módulo de planificación	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	3
58193	81	Módulo de partes de traballo	\N	2009-12-14 00:00:00	2010-01-06 00:00:00	\N	58239	\N	4
58199	81	Módulo de xestión da calidade	\N	2009-12-14 00:00:00	2010-01-13 00:00:00	\N	58239	\N	6
58206	81	Módulo de integración con subcontratas	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	58239	\N	7
58212	81	Módulo de Exportación-Importación	\N	2009-12-14 00:00:00	2010-01-21 00:00:00	\N	58239	\N	8
99891	16	Entrega 4º release	\N	2010-01-28 16:00:00	2010-01-28 16:00:00	\N	\N	\N	\N
58219	72	Documentación das API's públicas	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58220	\N	0
115243	12	Técnica de consolidación de avances	\N	2010-02-01 00:00:00	2010-03-03 00:00:00	\N	115247	\N	0
58221	72	Pasar pedidos a histórico	\N	2010-01-14 00:00:00	2010-01-20 00:00:00	\N	58222	\N	0
115244	12	Reorganización vertical de tarefas Ganttt	\N	2010-03-26 00:00:00	2010-04-03 00:00:00	\N	115247	\N	1
115245	12	Vista aplanada reordenable de tarefas Gantt	\N	2010-04-03 00:00:00	2010-04-15 00:00:00	\N	115247	\N	2
115246	12	Escenarios de planificación	\N	2010-03-03 00:00:00	2010-05-22 00:00:00	\N	115247	\N	3
58223	72	Integración de Jasper Reports	\N	2009-12-14 00:00:00	2009-12-17 00:00:00	\N	58233	\N	0
58224	72	Informes sobre organizacións de traballo	\N	2010-01-17 00:00:00	2010-01-23 00:00:00	\N	58233	\N	1
58225	72	Informe sobre partes de traballo	\N	2010-01-23 00:00:00	2010-01-28 00:00:00	\N	58233	\N	2
58226	72	Informes de horas traballadas por un traballador	\N	2009-12-17 00:00:00	2009-12-24 00:00:00	\N	58233	\N	3
58227	72	Lista de avances de planificación da empresa	\N	2010-01-08 00:00:00	2010-01-13 00:00:00	\N	58233	\N	4
58228	72	Lista de avances de traballo da empresa	\N	2009-12-24 00:00:00	2010-01-01 00:00:00	\N	58233	\N	5
58229	72	Informe de horas estimadas/horas realizadas	\N	2010-01-01 00:00:00	2010-01-08 00:00:00	\N	58233	\N	6
58230	72	Horas realizadas organizadas por tipo de traballo	\N	2010-01-13 00:00:00	2010-01-17 00:00:00	\N	58233	\N	7
58231	72	Horas estimadas/realizadas por tipo de traballo	\N	2010-01-07 00:00:00	2010-01-29 00:00:00	\N	58233	\N	8
58232	72	Informe de traballador indicando custos por hora	\N	2009-12-22 00:00:00	2010-01-07 00:00:00	\N	58233	\N	9
58234	72	Coordinación	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	14
58235	72	Análise	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	15
58236	72	Interpolación polinómica na asignación avanzada	\N	2010-01-20 00:00:00	2010-01-23 00:00:00	\N	58238	\N	0
58237	72	Asignación automática de configuración de máquina	\N	2009-12-14 00:00:00	2009-12-19 00:00:00	\N	58238	\N	1
115257	12	Técnica de valor gañado con información económica	\N	2010-02-01 00:00:00	2010-02-25 00:00:00	\N	115258	\N	0
58215	81	Módulo de presentación	\N	2009-12-14 00:00:00	2010-01-28 00:00:00	\N	58239	\N	9
58218	81	Módulo de arquitectura tecnolóxica	\N	2009-12-14 00:00:00	2010-01-19 00:00:00	\N	58239	\N	10
58220	81	Módulo de documentación de API	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	11
58222	81	Módulo de arquivo histórico	\N	2009-12-14 00:00:00	2010-01-20 00:00:00	\N	58239	\N	12
58233	81	Módulo de extracción de informes	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	13
115259	12	Asociar lista de chequeo a tipo de avance	\N	2010-02-25 00:00:00	2010-03-12 00:00:00	\N	115260	\N	0
58238	81	Módulo de asignación de recursos	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	58239	\N	16
58239	81	\N	\N	2009-12-14 00:00:00	2010-01-30 00:00:00	2010-01-30	\N	\N	\N
115263	12	Rendimento e melloras xerais en eficiencia	\N	2010-02-16 00:00:00	2010-03-16 00:00:00	\N	115264	\N	0
115265	12	Consulta información histórica dos modelos de planificación	\N	2010-02-06 00:00:00	2010-02-19 00:00:00	\N	115266	\N	0
115267	12	3 informes definidos polas empresas	\N	2010-02-01 00:00:00	2010-02-23 00:00:00	\N	115268	\N	0
115242	16	Xestion de usuarios	\N	2010-02-01 00:00:00	2010-02-06 00:00:00	\N	115269	\N	0
58216	72	Enlazar a axuda de usuario	\N	2010-01-05 00:00:00	2010-01-13 00:00:00	\N	58218	\N	0
58217	72	Desenvolvemento de paquetes  Ubuntu	\N	2010-01-13 00:00:00	2010-01-19 00:00:00	\N	58218	\N	1
115247	16	Módulo de planificación	\N	2010-02-01 00:00:00	2010-05-22 00:00:00	\N	115269	\N	1
115256	16	Módulo de control de avance	\N	2010-02-01 00:00:00	2010-02-16 00:00:00	\N	115269	\N	3
115258	16	Módulo de control de custos	\N	2010-02-01 00:00:00	2010-02-25 00:00:00	\N	115269	\N	4
115260	16	Módulo de xestión da calidade	\N	2010-02-01 00:00:00	2010-03-12 00:00:00	\N	115269	\N	5
115249	12	Melloras no sistema de asignación avanzada	\N	2010-04-15 00:00:00	2010-04-28 00:00:00	\N	115253	\N	1
115250	12	Modificación da unidade mínima de tempo asignable	\N	2010-04-28 00:00:00	2010-05-06 00:00:00	\N	115253	\N	2
115251	12	Gráfica de carga de recursos diferenciada máquina-humano	\N	2010-03-16 00:00:00	2010-03-20 00:00:00	\N	115253	\N	3
115252	12	Gráfico de uso de recursos filtrada por criterio	\N	2010-03-20 00:00:00	2010-03-26 00:00:00	\N	115253	\N	4
115254	12	Revisión de usabilidade da pantalla de asignación de avances	\N	2010-02-01 00:00:00	2010-02-09 00:00:00	\N	115256	\N	0
115255	12	Acceso directo dende planificación a xestión de avances	\N	2010-02-09 00:00:00	2010-02-16 00:00:00	\N	115256	\N	1
115261	12	Consulta da información subcontratada na aplicación	\N	2010-02-01 00:00:00	2010-02-12 00:00:00	\N	115262	\N	0
115253	16	Módulo de asignación de recursos	\N	2010-02-01 00:00:00	2010-05-06 00:00:00	\N	115269	\N	2
115262	16	Módulo de integración con subcontratas	\N	2010-02-01 00:00:00	2010-02-12 00:00:00	\N	115269	\N	6
115264	16	Módulo de arquitectura	\N	2010-02-01 00:00:00	2010-03-16 00:00:00	\N	115269	\N	7
115266	16	Módulo de arquivo histórico	\N	2010-02-01 00:00:00	2010-02-19 00:00:00	\N	115269	\N	8
115268	16	Módulo de informes	\N	2010-02-01 00:00:00	2010-02-23 00:00:00	\N	115269	\N	9
115269	16	\N	\N	2010-02-01 00:00:00	2010-05-22 00:00:00	2010-06-01	\N	\N	\N
115241	12	Xestión de Roles e información sensible	\N	2010-02-01 00:00:00	2010-02-06 00:00:00	\N	115242	\N	0
115248	12	Vista de asignación de recursos limitantes	\N	2010-02-12 00:00:00	2010-03-16 00:00:00	\N	115253	\N	0
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
1217
1220
1224
3134
3135
3138
3143
27877
27879
29594
29596
33033
36772
40101
40107
40112
40113
58180
58184
58186
58191
58193
58195
58199
58206
58212
58215
58218
58220
58222
58233
58238
58239
115242
115247
115253
115256
115258
115260
115262
115264
115266
115268
115269
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
3150
3151
38388
38389
40115
99891
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
33032	3	32884
1218	19	1150
1219	19	1151
1220	19	1149
1221	19	1152
1222	19	1153
1223	19	1154
1224	19	1035
33033	3	32883
58176	20	50361
3139	6	1180
3140	6	1181
58177	20	50362
3141	6	1182
3142	6	1183
3143	6	1179
27876	5	27607
3131	5	1356
3132	5	1357
3133	5	1362
3134	5	1361
3135	5	1360
3136	5	1364
3137	5	1365
3138	5	1325
1212	20	1126
1213	20	1127
1214	20	1128
1215	20	1129
1216	20	1130
1217	20	1022
27877	5	27605
27878	5	27608
27879	5	27603
36764	8	35791
36765	8	35792
36766	8	35793
36767	8	35794
36768	8	35795
36769	8	35796
36771	8	35798
36770	8	35797
38380	5	38080
36772	8	35766
29593	5	29323
29594	5	29322
29595	5	29325
29596	5	29320
33027	2	29321
33028	2	29324
58178	20	50363
58179	20	50364
58181	20	50366
58180	11	50360
58184	11	50365
58186	11	50369
58191	11	50371
58193	11	50376
58182	20	50367
58183	20	50368
58185	20	50370
58187	20	50372
58188	20	50373
58189	20	50374
58190	20	50375
58192	20	50377
58194	20	50379
40097	7	39872
40098	7	39873
40099	7	39875
40100	7	39876
40101	7	39874
40102	7	39878
40103	7	39879
40104	7	39880
40105	7	39881
40106	7	39882
40107	7	39877
40108	7	39884
40109	7	39885
40110	7	39886
40112	7	39883
40111	7	39887
40113	7	39823
58212	11	50391
58215	11	50398
58218	11	50643
58220	11	50646
58222	11	50648
58233	11	50650
58238	11	50669
58239	11	49125
115247	5	109231
115253	5	109502
58196	20	50381
115256	5	109508
58197	20	50382
58198	20	50383
115258	5	109511
115260	5	109513
115262	5	109515
115264	5	109517
115266	5	109519
115268	5	109521
115269	5	109204
115241	9	109230
115243	9	109232
115244	9	109233
115245	9	109234
115246	9	109235
115270	7	109527
115271	7	109528
58195	11	50378
115248	9	109503
115249	9	109504
115250	9	109505
58199	11	50380
115251	9	109506
115252	9	109507
115254	9	109509
115255	9	109510
115257	9	109512
58206	11	50384
115259	9	109514
58200	20	50385
58201	20	50386
58202	20	50387
58203	20	50388
58204	20	50389
58205	20	50390
58207	20	50392
58208	20	50393
58209	20	50394
58210	20	50395
58211	20	50396
58213	20	50601
58214	20	50602
58216	20	50644
58217	20	50645
58219	20	50647
58221	20	50649
58223	20	50651
58224	20	50652
58225	20	50653
58226	20	50654
58227	20	50655
58228	20	50656
58229	20	50657
58230	20	50658
58231	20	50659
58232	20	50660
58234	20	50661
58235	20	50662
58236	20	50670
58237	20	50671
115261	9	109516
115263	9	109518
115276	3	109539
115265	9	109520
115267	9	109522
115242	5	109229
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled) FROM stdin;
1212	1	EXTRAORDINARIA	Cod1	15.00	t
31714	1	FESTIVOS	FESTIVOS	30.00	t
1217	2	NORMAL	Cod2	10.00	t
108575	1	Diurna	MaqDiurna	13.00	t
108576	1	Nocturna	MaqNocturna	12.00	t
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
114433	114332
114434	114332
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
58681	ROLE_BASIC_USER
58682	ROLE_ADMINISTRATION
58682	ROLE_BASIC_USER
58683	ROLE_WS_READER
58684	ROLE_WS_WRITER
58684	ROLE_WS_READER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
114636	Obs.
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, work_report_type_id, resource_id, order_element_id) FROM stdin;
3636	1	2009-12-04 00:00:00	2526	1718	1126
3637	2	\N	2525	1722	\N
3638	1	\N	2525	1722	\N
7070	1	\N	2525	1724	\N
8100	1	\N	2525	1718	\N
17372	1	\N	2525	1722	\N
18786	1	\N	2525	1722	\N
26664	1	\N	21109	1718	1152
108777	1	\N	2525	36159	\N
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, index, label_type_id, label_id, work_report_type_id, positionnumber) FROM stdin;
910	0	f	0	810	914	2526	\N
911	0	t	0	808	909	2527	\N
909	1	t	0	809	913	2525	\N
21210	1	t	1	808	910	21109	\N
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
3737	1	6	2009-12-04 00:00:00	1970-01-01 08:10:00	1970-01-01 14:11:00	3636	1718	1126	1212
3738	2	20	2009-12-07 00:00:00	\N	\N	3637	1722	1126	1217
3739	1	8	2009-12-07 00:00:00	\N	\N	3638	1722	1128	1217
3740	1	8	2009-12-04 00:00:00	\N	\N	3638	1722	1128	1217
7171	1	50	2009-12-07 00:00:00	\N	\N	7070	1724	1182	1217
7172	1	40	2009-12-08 00:00:00	\N	\N	7070	1724	1180	1217
7173	1	30	2009-12-09 00:00:00	\N	\N	7070	1724	1181	1217
8201	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8202	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8203	1	8	2009-12-11 00:00:00	\N	\N	8100	1718	1181	1217
8204	1	8	2009-12-08 00:00:00	\N	\N	8100	1718	1180	1217
8205	1	8	2009-12-14 00:00:00	\N	\N	8100	1718	1181	1217
8206	1	8	2009-12-10 00:00:00	\N	\N	8100	1718	1180	1217
8207	1	8	2009-12-07 00:00:00	\N	\N	8100	1718	1180	1217
8208	1	8	2009-12-09 00:00:00	\N	\N	8100	1718	1180	1217
17473	1	30	2009-12-09 00:00:00	\N	\N	17372	1722	1152	1217
17474	1	10	2009-12-10 00:00:00	\N	\N	17372	1722	1149	1217
17475	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1152	1217
17476	1	10	2009-12-07 00:00:00	\N	\N	17372	1722	1149	1217
17477	1	10	2009-12-09 00:00:00	\N	\N	17372	1722	1149	1217
17478	1	30	2009-12-10 00:00:00	\N	\N	17372	1722	1152	1217
17479	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1149	1217
18887	1	20	2009-12-07 00:00:00	\N	\N	18786	1722	1152	1217
26765	1	20	2009-12-09 00:00:00	\N	\N	26664	1718	1152	1217
108878	1	7	2010-01-05 00:00:00	\N	\N	108777	36159	50361	1217
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
2526	1	Tipo2	cod2	t	t	t	1
2527	1	Tipo3	cod3	t	f	t	2
2525	4	Tipo1	cod1	f	t	f	0
21109	4	tipo4	codparte5	f	t	t	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
114636	Traballadores para proxecto desenvolvemento web	---	[Virtual]
1720	Samuel	Lopez	22222222B
1718	Marcos	Cancela	11111111A
1724	Isabel	Dopacio	44444444D
1722	Andres	Lafuente	33333333C
1726	Silvia	Martinez	55555555E
37575	Pedro	Figueras	88888888H
49315	Proba1	Proba2	34343434C
49302	José María 	Casanova Crespo	44444444E
49289	Javier	Morán Rúa	11111111B
49313	Fernando	Bellas	10000000C
36159	Lorenzo	Tilve Álvaro	66666666E
37573	Manuel	Rego Casasnovas	77777777G
49300	Oscar	González Fernández	33333333D
49304	Xavier	Castaño García	55555555F
40199	Jacobo	Aragunde	99999999H
49309	Susana	Montes	77777777P
49297	Diego	Pino García	22222222C
106556	Nome	Apelidos	12312312E
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
3637	913
3638	913
7070	913
8100	913
17372	913
18786	913
26664	911
108777	913
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
3737	914
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: external_company_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_name_key UNIQUE (name);


--
-- Name: external_company_nif_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_nif_key UNIQUE (nif);


--
-- Name: external_company_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_template_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT material_assigment_template_pkey PRIMARY KEY (id);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT order_authorization_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderelementtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT orderelementtemplate_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegrouptemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT orderlinegrouptemplate_pkey PRIMARY KEY (group_template_id);


--
-- Name: orderlinetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT orderlinetemplate_pkey PRIMARY KEY (order_line_template_id);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: ordertemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT ordertemplate_pkey PRIMARY KEY (order_template_id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_base_calendar_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_base_calendar_id_key UNIQUE (base_calendar_id);


--
-- Name: resource_calendar_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_calendar_key UNIQUE (calendar);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: subcontractedtaskdata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT subcontractedtaskdata_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: task_subcontrated_task_data_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_subcontrated_task_data_id_key UNIQUE (subcontrated_task_data_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk1ccb0f7419b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f7419b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk1ccb0f74b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f74b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk27a9a55b595a0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a55b595a0 FOREIGN KEY (subcontrated_task_data_id) REFERENCES subcontractedtaskdata(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk4a1d42dc9fb7fc18; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT fk4a1d42dc9fb7fc18 FOREIGN KEY (order_line_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk4d68b9c89a4a7d90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c89a4a7d90 FOREIGN KEY (order_template_id) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fk4d68b9c8a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c8a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fk9bb0b28841638aab; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT fk9bb0b28841638aab FOREIGN KEY (parent) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fka87c31085567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c31085567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fka87c310887287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c310887287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fka87c3108edc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c3108edc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f501b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f501b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkd3056ef7ddc82952; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT fkd3056ef7ddc82952 FOREIGN KEY (group_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke562c7e93fee60cc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT fke562c7e93fee60cc FOREIGN KEY (companyuser) REFERENCES naval_user(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkecc6114019960f43; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT fkecc6114019960f43 FOREIGN KEY (externalcompany) REFERENCES external_company(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282edc874c20; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282edc874c20 FOREIGN KEY (base_calendar_id) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkef86282ee893ce10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282ee893ce10 FOREIGN KEY (calendar) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd50940519b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd50940519b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

