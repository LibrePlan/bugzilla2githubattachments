--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
2945	4	t	606
3056	15	f	509
3099	12	t	607
3115	11	t	607
3130	9	t	607
2739	19	t	606
3100	12	f	607
2250	3	t	606
2251	3	t	606
2234	4	t	606
3052	3	t	606
3053	3	t	606
3054	3	t	606
3042	4	t	606
2932	6	t	606
2752	7	t	606
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
1519	15	2009-12-25	100.00	3056
1520	15	2009-12-10	15.00	3056
1521	15	2009-12-07	5.00	3056
1522	15	2009-12-04	1.00	3056
1544	12	2009-12-04	10.00	3099
1573	11	2009-12-07	30.00	3115
1574	11	2009-12-04	10.00	3115
3233	9	2009-12-07	30.00	3130
3234	9	2009-12-04	10.00	3130
3235	9	2009-12-03	2.00	3130
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
606	3	children	100.0000	f	0.0100	t	t
607	2	percentage	100.0000	f	0.0100	t	t
608	1	units	2147483647.0000	f	1.0000	t	f
508	1	Pactado	1000000.0000	t	1000.0000	t	f
510	1	Toneladas	4000.0000	t	1.0000	t	f
509	2	Porcentage pactado	100.0000	t	1.0000	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
3940	105
3950	106
3951	106
3952	107
3953	106
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
204	2	Ferrol
205	1	\N
206	1	\N
207	1	\N
208	1	\N
210	2	\N
202	2	España
203	3	Galicia
209	3	\N
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
306	2	203	\N	204	0
307	1	202	\N	205	0
308	1	202	\N	206	0
309	1	202	\N	207	0
310	1	202	\N	208	0
312	2	202	\N	210	0
303	2	\N	\N	202	0
304	2	\N	\N	202	1
305	3	202	\N	203	0
311	3	202	\N	209	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
808	1	2009-12-25	0	505	202
809	1	2010-01-01	0	505	202
810	1	2010-05-17	0	505	203
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, name, color, notassignable) FROM stdin;
505	6	HOLIDAY	red	t
506	5	SICK_LEAVE	red	t
507	4	LEAVE	red	t
508	3	STRIKE	red	t
509	2	BANK_HOLIDAY	red	t
510	1	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id) FROM stdin;
404	1	202
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, name, enabled) FROM stdin;
1313	1	Oficial 1º	t
1314	1	Oficial 2º	t
1315	2	Peón	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
105	2	Pintor	t	4	\N
106	2	Soldador	t	4	\N
107	2	Andamiero	t	4	\N
108	2	Calderero	t	4	\N
109	2	Curso de riesgos laborales	t	3	\N
110	1	Torno	t	7	\N
111	1	Plegadora	t	7	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
2388	DIRECT	2	1891	\N	110	\N	\N
2389	DIRECT	2	2880	\N	106	\N	\N
2390	DIRECT	2	\N	1182	108	\N	\N
2391	DIRECT	2	\N	1182	106	\N	\N
2392	INDIRECT	2	2882	\N	108	2390	t
2393	INDIRECT	2	2882	\N	106	2391	t
2394	DIRECT	2	\N	1183	108	\N	\N
2395	INDIRECT	2	2883	\N	108	2394	t
1646	DIRECT	8	\N	1126	105	\N	\N
1647	INDIRECT	8	2843	\N	105	1646	t
1678	DIRECT	7	2844	\N	106	\N	\N
1679	DIRECT	7	1457	\N	107	\N	\N
1816	DIRECT	6	\N	1128	105	\N	\N
2204	DIRECT	2	\N	1150	110	\N	\N
2205	DIRECT	2	\N	1151	111	\N	\N
2206	DIRECT	2	\N	1152	105	\N	\N
2207	INDIRECT	2	2865	\N	105	2206	t
2208	DIRECT	2	\N	1153	105	\N	\N
2209	INDIRECT	2	2866	\N	105	2208	t
2210	DIRECT	2	\N	1154	107	\N	\N
2211	INDIRECT	2	2867	\N	107	2210	t
1817	INDIRECT	6	2845	\N	105	1816	t
1919	DIRECT	6	2846	\N	108	\N	\N
1935	DIRECT	5	1855	\N	106	\N	\N
1966	DIRECT	4	1856	\N	106	\N	\N
1967	DIRECT	4	2847	\N	108	\N	\N
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
1818	1	2009-12-07 12:13:55.69	\N	f	105	1718
1819	1	2009-12-07 12:14:12.984	\N	f	107	1720
1820	1	2009-12-07 12:14:39.805	\N	f	105	1722
1821	1	2009-12-07 12:15:40.633	\N	f	106	1724
1823	2	2009-12-07 12:22:26.956	\N	f	110	1727
1822	3	2009-12-07 12:16:13.031	\N	f	105	1726
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
1	15	LEAVE	Leave	f	f	t	1
2	11	CATEGORY	Professional category	t	t	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
4	7	JOB	Job	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
7	1	Tipo de máquina	\N	t	f	t	2
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id) FROM stdin;
4079	GENERIC_DAY	1	3	2009-12-15	1718	\N	3940
4080	GENERIC_DAY	1	3	2009-12-12	1718	\N	3940
4081	GENERIC_DAY	1	3	2009-12-17	1718	\N	3940
4082	GENERIC_DAY	1	3	2009-12-18	1718	\N	3940
4083	GENERIC_DAY	1	3	2009-12-11	1722	\N	3940
4084	GENERIC_DAY	1	3	2009-12-13	1718	\N	3940
4085	GENERIC_DAY	1	3	2009-12-14	1722	\N	3940
4086	GENERIC_DAY	1	3	2009-12-16	1718	\N	3940
4087	GENERIC_DAY	1	1	2009-12-19	1722	\N	3940
4088	GENERIC_DAY	1	3	2009-12-10	1718	\N	3940
4089	GENERIC_DAY	1	2	2009-12-09	1726	\N	3940
4090	GENERIC_DAY	1	2	2009-12-08	1726	\N	3940
4091	GENERIC_DAY	1	2	2009-12-19	1718	\N	3940
4092	GENERIC_DAY	1	2	2009-12-17	1726	\N	3940
4093	GENERIC_DAY	1	3	2009-12-09	1722	\N	3940
4094	GENERIC_DAY	1	3	2009-12-11	1718	\N	3940
4095	GENERIC_DAY	1	3	2009-12-08	1722	\N	3940
4096	GENERIC_DAY	1	1	2009-12-19	1726	\N	3940
4097	GENERIC_DAY	1	3	2009-12-08	1718	\N	3940
4098	GENERIC_DAY	1	3	2009-12-10	1722	\N	3940
4099	GENERIC_DAY	1	3	2009-12-17	1722	\N	3940
4100	GENERIC_DAY	1	2	2009-12-12	1726	\N	3940
4101	GENERIC_DAY	1	2	2009-12-16	1726	\N	3940
4102	GENERIC_DAY	1	3	2009-12-16	1722	\N	3940
4103	GENERIC_DAY	1	3	2009-12-18	1722	\N	3940
4104	GENERIC_DAY	1	3	2009-12-07	1722	\N	3940
4105	GENERIC_DAY	1	3	2009-12-15	1722	\N	3940
4106	GENERIC_DAY	1	2	2009-12-10	1726	\N	3940
4107	GENERIC_DAY	1	2	2009-12-18	1726	\N	3940
4108	GENERIC_DAY	1	2	2009-12-11	1726	\N	3940
4109	GENERIC_DAY	1	3	2009-12-14	1718	\N	3940
4110	GENERIC_DAY	1	2	2009-12-14	1726	\N	3940
4111	GENERIC_DAY	1	2	2009-12-15	1726	\N	3940
4112	GENERIC_DAY	1	3	2009-12-07	1718	\N	3940
4113	GENERIC_DAY	1	3	2009-12-12	1722	\N	3940
4114	GENERIC_DAY	1	3	2009-12-13	1722	\N	3940
4115	GENERIC_DAY	1	2	2009-12-07	1726	\N	3940
4116	GENERIC_DAY	1	2	2009-12-13	1726	\N	3940
4117	GENERIC_DAY	1	3	2009-12-09	1718	\N	3940
4186	GENERIC_DAY	0	12	2009-12-10	1724	\N	3950
4187	GENERIC_DAY	0	13	2009-12-08	1724	\N	3950
4188	GENERIC_DAY	0	12	2009-12-09	1724	\N	3950
4189	GENERIC_DAY	0	13	2009-12-07	1724	\N	3950
4190	GENERIC_DAY	0	12	2009-12-22	1724	\N	3951
4191	GENERIC_DAY	0	13	2009-12-15	1724	\N	3951
4192	GENERIC_DAY	0	13	2009-12-17	1724	\N	3951
4193	GENERIC_DAY	0	12	2009-12-20	1724	\N	3951
4194	GENERIC_DAY	0	13	2009-12-18	1724	\N	3951
4195	GENERIC_DAY	0	12	2009-12-19	1724	\N	3951
4196	GENERIC_DAY	0	12	2009-12-21	1724	\N	3951
4197	GENERIC_DAY	0	13	2009-12-16	1724	\N	3951
4198	GENERIC_DAY	0	12	2009-12-19	1720	\N	3952
4199	GENERIC_DAY	0	13	2009-12-15	1720	\N	3952
4200	GENERIC_DAY	0	13	2009-12-18	1720	\N	3952
4201	GENERIC_DAY	0	13	2009-12-16	1720	\N	3952
4202	GENERIC_DAY	0	12	2009-12-20	1720	\N	3952
4203	GENERIC_DAY	0	12	2009-12-21	1720	\N	3952
4204	GENERIC_DAY	0	12	2009-12-22	1720	\N	3952
4205	GENERIC_DAY	0	13	2009-12-17	1720	\N	3952
4206	GENERIC_DAY	0	16	2009-12-08	1724	\N	3953
4207	GENERIC_DAY	0	16	2009-12-07	1724	\N	3953
4208	GENERIC_DAY	0	16	2009-12-14	1724	\N	3953
4209	GENERIC_DAY	0	16	2009-12-10	1724	\N	3953
4210	GENERIC_DAY	0	16	2009-12-09	1724	\N	3953
4211	GENERIC_DAY	0	16	2009-12-12	1724	\N	3953
4212	GENERIC_DAY	0	16	2009-12-13	1724	\N	3953
4213	GENERIC_DAY	0	16	2009-12-11	1724	\N	3953
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
1245191	2	1215	1213	0
1245192	2	1212	1214	0
1245204	2	1215	1213	0
1245205	2	1212	1214	0
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
3636	Incidencias	Incidencia 
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
3738	Incidencia	Ninguna destacada
3739	Incidencia	Nada...
3740	Incidencia	Nada...
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
3056	1022	100.00
3099	1126	100.00
3115	1127	100.00
3130	1128	100.00
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
3940
3950
3951
3952
3953
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, index) FROM stdin;
2526	Incidencias	200	0
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
42
42
42
42
42
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
1414	1	10.00	2009-12-07	2010-12-07	1217	1313
1415	1	15.00	2009-12-07	2010-12-07	1212	1313
1416	1	15.00	2009-12-07	2010-12-07	1212	1314
1417	1	8.00	2009-12-07	2010-12-07	1217	1314
1418	2	6.00	2009-12-07	\N	1217	1315
1419	2	10.00	2009-12-07	\N	1212	1315
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, name, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line) FROM stdin;
2867	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	140	1.00	f	1154
1435	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1356
1436	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1358
1437	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1359
1438	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	110	1.00	f	1362
1439	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1363
1855	6	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
1856	6	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
1440	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	1364
1441	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1365
2863	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1150
2864	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1151
2865	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1152
2866	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1153
2843	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1126
2844	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
1457	7	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
2845	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1128
2846	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
2847	18	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
2880	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1180
2881	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	350	1.00	f	1181
2882	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1182
2883	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1183
1891	2	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	0.50	f	1180
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
303	8	0
303	8	1
303	8	2
303	8	3
303	8	4
303	0	5
303	0	6
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
2739	1022
3100	1022
3052	1357
3053	1361
3054	1360
3042	1325
2932	1149
2752	1035
2945	1179
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
910	1	Cubierta	808
911	1	Motores	808
914	1	1 (Bajo)	810
916	1	2 (Medio)	810
909	6	Bodega	808
915	7	3 (Alto)	810
912	5	Vulcano	809
913	14	Navantia	809
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
808	1	Zonas
809	1	Cliente
810	1	Riesgo
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, index) FROM stdin;
2527	Incidencias2	201	0
2525	Incidencia	200	0
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
1727	cod2	Torno A	Desc
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
1919	1	Seleccion de criterios	1.00	1727
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
1121	4	cod1.1	tubo 3/4 pulgadas	6.00	3	f	1023
1123	5	cod2.2	Tubos 20mm	7.00	3	f	1022
1122	5	cod2.1	Tubos 12mm	6.50	3	f	1022
1124	5	cod3.1	Tornillos hexagonales	0.45	3	f	1024
1125	6	cod3	Tornillo 304	0.50	\N	f	1021
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, estimated_availability, status, order_element_id, material_id) FROM stdin;
3549	3	6	0.50	2009-12-07 13:59:19.527	1	1022	1125
3548	3	8	6.50	2009-12-07 13:59:19.527	1	1022	1122
3547	3	10	6.00	2009-12-07 13:59:19.527	1	1022	1121
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
1020	6	Tubos	\N
1023	5	Cemento	1020
1022	5	Acero	1020
1021	6	Tornillos	\N
1024	5	Hexagonales	1021
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password) FROM stdin;
707	2	user	user
708	1	admin	admin
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
1022	913
1127	909
1127	915
1128	915
1035	912
1130	915
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, base_calendar_id) FROM stdin;
1325	Xavi	...	t	202
1035	Xavi	\N	t	202
1179	Xavi	\N	t	202
1022	Xavi	...	t	202
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, initdate, deadline, mandatoryinit, mandatoryend, description, code, schedulingstatetype, parent, positionincontainer) FROM stdin;
1130	18	Validación funcionamiento	\N	\N	f	f	\N	ped1.5	0	1022	4
1035	7	Contratación de pintado de cubierta	2009-12-07 13:59:43.333	2010-03-25 00:00:00	f	f	Desc.	ped2	3	\N	\N
1149	6	Coordinación	\N	\N	f	f	\N	ped2.1	3	1035	0
1150	6	Reuniones seguimiento 	\N	\N	f	f	\N	ped2.2	0	1149	0
1151	6	Seguimiento proyecto	\N	\N	f	f	\N	ped2.3	0	1149	1
1152	6	Montaje andamios	\N	\N	f	f	\N	ped2.4	0	1035	1
1153	6	Pintado cubierta	\N	\N	f	f	\N	ped2.5	0	1035	2
1154	6	Desmontaje andamios	\N	\N	f	f	\N	ped2.6	0	1035	3
1179	4	Entrega de hélices	2009-12-07 16:12:52.395	2009-12-25 00:00:00	f	f	Desc.	ped3	4	\N	\N
1180	4	Tarea1	\N	\N	f	f	\N	ped3.1	0	1179	0
1181	4	Tarea2	\N	\N	f	f	\N	ped3.2	0	1179	1
1182	4	Tarea3	\N	\N	f	f	\N	ped3.3	0	1179	2
1183	4	Tarea4	\N	\N	f	f	\N	ped3.4	0	1179	3
1325	4	Contratación de muebles habitaciones	2009-12-07 16:23:24.094	2010-05-07 00:00:00	f	f	Desc.	ped4	4	\N	\N
1356	3	Tarefa1	\N	\N	f	f	\N	ped4.1	0	1325	0
1357	3	Tarefa2	\N	\N	f	f	\N	ped4.2	0	1325	1
1358	3	Subtarefa1.1	\N	\N	f	f	\N	ped4.3	1	1357	0
1359	3	Subtarefa1.2	\N	\N	f	f	\N	ped4.4	1	1357	1
1360	3	Tarefa3	\N	\N	f	f	\N	ped4.5	2	1325	2
1361	3	Subtarefa3.1	\N	\N	f	f	\N	ped4.6	2	1360	0
1362	3	Subsubtarefa3.1.1	\N	\N	f	f	\N	ped4.7	0	1361	0
1363	3	Subsubtarefa3.1.2	\N	\N	f	f	\N	ped4.8	4	1361	1
1364	3	Tarefa4	\N	\N	f	f	\N	ped4.9	0	1325	3
1365	3	Tarefa5	\N	\N	f	f	\N	ped4.10	0	1325	4
1022	19	Contratación de motores	2009-12-07 13:59:19.527	2009-12-25 00:00:00	f	f	Desc	ped1	4	\N	\N
1126	18	Adquisición de piezas	\N	\N	f	f	\N	ped1.1	0	1022	0
1127	18	Montaje piezas	\N	\N	f	f	\N	ped1.2	0	1022	1
1128	18	Prueba del motor	\N	\N	f	f	\N	ped1.3	0	1022	2
1129	18	Instalación de motor	\N	\N	f	f	\N	ped1.4	0	1022	3
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid) FROM stdin;
1126
1127
1128
1129
1130
1150
1151
1152
1153
1154
1180
1181
1182
1183
1356
1358
1359
1362
1363
1364
1365
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1022
1035
1149
1179
1325
1357
1360
1361
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, calendar) FROM stdin;
1718	1	205
1720	1	206
1722	1	207
1724	1	208
1727	2	210
1726	3	209
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
3940	1	1.00	1212	\N
3950	0	1.56	1216	\N
3951	0	1.56	1213	\N
3952	0	1.56	1213	\N
3953	0	2.00	1215	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id) FROM stdin;
205
206
207
208
209
210
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, initdate, enddate, cost_category_id, resource_id) FROM stdin;
3434	1	2009-12-07	\N	1313	1726
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate) FROM stdin;
1218	1	0	\N
1219	1	0	\N
1221	1	0	\N
1222	1	0	\N
1223	1	0	\N
3139	1	0	\N
3140	1	0	\N
3141	1	0	\N
3142	1	0	\N
1216	2	0	\N
1213	2	0	\N
1212	1	0	\N
1214	1	0	\N
1215	0	0	\N
3131	1	0	\N
3132	1	0	\N
3133	1	0	\N
3136	1	0	\N
3137	1	0	\N
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
1217	2847
1217	2846
1217	2844
1217	2843
1217	2845
1220	2863
1220	2864
1224	2863
1224	2864
1224	2865
1224	2866
1224	2867
3131	1435
3132	1436
3132	1437
3133	1438
3134	1439
3134	1438
3135	1439
3135	1438
3136	1440
3137	1441
3138	1439
3138	1435
3138	1438
3138	1440
3138	1441
3138	1436
3138	1437
3143	2881
3143	2880
3143	2883
3143	2882
1218	2863
1219	2864
1221	2865
1222	2866
1223	2867
3139	1891
3139	2880
3140	2881
3141	2882
3142	2883
1212	2843
1213	2844
1213	1457
1214	2845
1215	2846
1215	1855
1216	1856
1216	2847
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
1216	19	Validación funcionamiento	\N	2009-12-07 13:59:19.527	2009-12-11 13:59:19.527	\N	1217	\N	4
1213	19	Montaje piezas	\N	2009-12-15 13:59:19.527	2009-12-23 13:59:19.527	\N	1217	\N	1
1212	19	Adquisición de piezas	\N	2009-12-07 13:59:19.527	2009-12-20 13:59:19.527	\N	1217	\N	0
1214	19	Prueba del motor	\N	2009-12-20 13:59:19.527	2010-01-02 01:59:19.527	\N	1217	\N	2
1215	19	Instalación de motor	\N	2009-12-07 13:59:19.527	2009-12-15 13:59:19.527	\N	1217	\N	3
1217	19	\N	\N	2009-12-07 13:59:19.527	2010-01-02 01:59:19.527	2009-12-25	\N	\N	\N
3131	2	\N	\N	\N	\N	\N	3138	\N	0
3132	2	\N	\N	\N	\N	\N	3138	\N	1
3133	2	\N	\N	\N	\N	\N	3134	\N	0
3134	2	\N	\N	\N	\N	\N	3135	\N	0
3135	2	\N	\N	\N	\N	\N	3138	\N	2
3136	2	\N	\N	\N	\N	\N	3138	\N	3
3137	2	\N	\N	\N	\N	\N	3138	\N	4
3138	2	\N	\N	\N	\N	2010-05-07	\N	\N	\N
1218	6	\N	\N	\N	\N	\N	1220	\N	0
1219	6	\N	\N	\N	\N	\N	1220	\N	1
1220	6	\N	\N	\N	\N	\N	1224	\N	0
1221	6	\N	\N	\N	\N	\N	1224	\N	1
1222	6	\N	\N	\N	\N	\N	1224	\N	2
1223	6	\N	\N	\N	\N	\N	1224	\N	3
1224	6	\N	\N	\N	\N	2010-03-25	\N	\N	\N
3139	3	\N	\N	\N	\N	\N	3143	\N	0
3140	3	\N	\N	\N	\N	\N	3143	\N	1
3141	3	\N	\N	\N	\N	\N	3143	\N	2
3142	3	\N	\N	\N	\N	\N	3143	\N	3
3143	3	\N	\N	\N	\N	2009-12-25	\N	\N	\N
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
1217
1220
1224
3134
3135
3138
3143
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
1218	6	1150
1219	6	1151
1220	6	1149
1221	6	1152
1222	6	1153
1223	6	1154
1224	6	1035
3139	3	1180
3140	3	1181
3141	3	1182
3142	3	1183
3143	3	1179
3131	2	1356
3132	2	1357
3133	2	1362
3134	2	1361
3135	2	1360
3136	2	1364
3137	2	1365
3138	2	1325
1212	17	1126
1213	17	1127
1214	17	1128
1215	17	1129
1216	17	1130
1217	17	1022
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled) FROM stdin;
1212	1	EXTRAORDINARIA	Cod1	15.00	t
1217	1	NORMAL	Cod2	10.00	t
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
707	ROLE_BASIC_USER
708	ROLE_ADMINISTRATION
708	ROLE_BASIC_USER
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, work_report_type_id, resource_id, order_element_id) FROM stdin;
3636	1	2009-12-04 00:00:00	2526	1718	1126
3637	2	\N	2525	1722	\N
3638	1	\N	2525	1722	\N
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, index, label_type_id, label_id, work_report_type_id) FROM stdin;
910	0	f	0	810	914	2526
911	0	t	0	808	909	2527
909	1	t	0	809	913	2525
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
3737	1	6	2009-12-04 00:00:00	1970-01-01 08:10:00	1970-01-01 14:11:00	3636	1718	1126	1212
3738	2	20	2009-12-07 00:00:00	\N	\N	3637	1722	1126	1217
3739	1	8	2009-12-07 00:00:00	\N	\N	3638	1722	1128	1217
3740	1	8	2009-12-04 00:00:00	\N	\N	3638	1722	1128	1217
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
2526	1	Tipo2	cod2	t	t	t	1
2527	1	Tipo3	cod3	t	f	t	2
2525	4	Tipo1	cod1	f	t	f	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1718	Marcos	Cancela	11111111A
1720	Samuel	Lopez	22222222B
1722	Andres	Lafuente	33333333C
1724	Isabel	Dopacio	44444444D
1726	Silvia	Martinez	55555555E
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
3637	913
3638	913
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
3737	914
\.


--
-- PostgreSQL database dump complete
--

