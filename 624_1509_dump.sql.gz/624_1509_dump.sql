--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advanceassignmenttemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignmenttemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    advance_type_id bigint,
    order_element_template_id bigint,
    reportglobaladvance boolean,
    maxvalue numeric(19,2)
);


ALTER TABLE public.advanceassignmenttemplate OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint,
    communicationdate timestamp without time zone
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean,
    qualityform boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date date,
    duration integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255),
    generatecodeforcriterion boolean NOT NULL,
    generatecodeforlabel boolean NOT NULL,
    generatecodeforworkreport boolean NOT NULL,
    generatecodeforresources boolean NOT NULL,
    generatecodefortypesofworkhours boolean NOT NULL,
    generatecodeformaterialcategories boolean NOT NULL,
    generatecodeforunittypes boolean NOT NULL,
    expandcompanyplanningviewcharts boolean NOT NULL,
    expandorderplanningviewcharts boolean NOT NULL,
    expandresourceloadviewcharts boolean NOT NULL
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: consolidatedvalue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidatedvalue (
    id bigint NOT NULL,
    consolidated_value_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    taskenddate date,
    consolidation_id bigint,
    advance_measurement_id bigint
);


ALTER TABLE public.consolidatedvalue OWNER TO naval;

--
-- Name: consolidation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidation (
    id bigint NOT NULL,
    consolidation_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    dir_advance_assignment_id bigint,
    ind_advance_assignment_id bigint
);


ALTER TABLE public.consolidation OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint,
    predefinedcriterioninternalname character varying(255)
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    order_element_template_id bigint,
    criterion_id bigint,
    parent bigint,
    valid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    generatecode boolean NOT NULL,
    resource integer,
    predefinedtypeinternalname character varying(255)
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    duration integer NOT NULL,
    consolidated boolean,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_container_id bigint,
    generic_container_id bigint,
    derived_container_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    queue_dependency bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: deriveddayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE deriveddayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    derived_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.deriveddayassignmentscontainer OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: effortperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE effortperday (
    base_calendar_id bigint NOT NULL,
    effort integer,
    day_id integer NOT NULL
);


ALTER TABLE public.effortperday OWNER TO naval;

--
-- Name: external_company; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE external_company (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    nif character varying(255),
    client boolean,
    subcontractor boolean,
    interactswithapplications boolean,
    appuri character varying(255),
    ourcompanylogin character varying(255),
    ourcompanypassword character varying(255),
    companyuser bigint
);


ALTER TABLE public.external_company OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: genericdayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE genericdayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.genericdayassignmentscontainer OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: naval
--

CREATE SEQUENCE hibernate_sequence
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO naval;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: naval
--

SELECT pg_catalog.setval('hibernate_sequence', 1264, true);


--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    resourcetype character varying(255),
    workinghours integer NOT NULL,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint,
    order_line_template bigint
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: limiting_resource_queue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_id bigint
);


ALTER TABLE public.limiting_resource_queue OWNER TO naval;

--
-- Name: limiting_resource_queue_dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_dependency (
    id bigint NOT NULL,
    type integer,
    origin_queue_element_id bigint,
    destiny_queue_element_id bigint
);


ALTER TABLE public.limiting_resource_queue_dependency OWNER TO naval;

--
-- Name: limiting_resource_queue_element; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_element (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    limiting_resource_queue_id bigint,
    earlier_start_date_because_of_gantt timestamp without time zone,
    earliest_end_date_because_of_gantt timestamp without time zone,
    creation_timestamp bigint,
    start_date date,
    start_hour integer,
    end_date date,
    end_hour integer
);


ALTER TABLE public.limiting_resource_queue_element OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type bigint,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_assigment_template; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment_template (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment_template OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL,
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean,
    lastconnectedscenario bigint
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_authorization; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_authorization (
    id bigint NOT NULL,
    order_authorization_subclass character varying(255) NOT NULL,
    version bigint NOT NULL,
    authorizationtype character varying(255) NOT NULL,
    order_id bigint,
    user_id bigint,
    profile_id bigint
);


ALTER TABLE public.order_authorization OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_element_template_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_label (
    order_element_template_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_label OWNER TO naval;

--
-- Name: order_element_template_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_quality_form (
    order_element_template_id bigint NOT NULL,
    quality_form_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_quality_form OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    dependenciesconstraintshavepriority boolean,
    codeautogenerated boolean,
    lastorderelementsequencecode integer,
    workbudget numeric(19,2),
    materialsbudget numeric(19,2),
    totalhours integer,
    customerreference character varying(255),
    externalcode character varying(255),
    state integer,
    customer bigint,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    lastadvancemeausurementforspreading numeric(19,2),
    dirtylastadvancemeasurementforspreading boolean,
    parent bigint,
    template bigint,
    externalcode character varying(255),
    positionincontainer integer,
    sum_charged_hours_id bigint
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderelementtemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelementtemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    startasdaysfrombeginning integer,
    deadlineasdaysfrombeginning integer,
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelementtemplate OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: orderlinegrouptemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegrouptemplate (
    group_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinegrouptemplate OWNER TO naval;

--
-- Name: orderlinetemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinetemplate (
    order_line_template_id bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderlinetemplate OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: ordertemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordertemplate (
    order_template_id bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.ordertemplate OWNER TO naval;

--
-- Name: orderversion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderversion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    modificationbyownertimestamp timestamp without time zone,
    ownerscenario bigint
);


ALTER TABLE public.orderversion OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer,
    reportadvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    generatecode boolean NOT NULL,
    limited_resource boolean NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    intended_total_hours integer,
    originaltotalassignment integer,
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: scenario; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scenario (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    lastnotownedreassignationstimestamp timestamp without time zone,
    predecessor bigint
);


ALTER TABLE public.scenario OWNER TO naval;

--
-- Name: scenario_orders; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scenario_orders (
    order_id bigint NOT NULL,
    order_version_id bigint NOT NULL,
    scenario_id bigint NOT NULL
);


ALTER TABLE public.scenario_orders OWNER TO naval;

--
-- Name: scheduling_states_by_order_version; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scheduling_states_by_order_version (
    order_element_id bigint NOT NULL,
    scheduling_state_for_version_id bigint NOT NULL,
    order_version_id bigint NOT NULL
);


ALTER TABLE public.scheduling_states_by_order_version OWNER TO naval;

--
-- Name: schedulingdataforversion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE schedulingdataforversion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    schedulingstatetype integer,
    order_element_id bigint
);


ALTER TABLE public.schedulingdataforversion OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: specificdayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specificdayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.specificdayassignmentscontainer OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL,
    type integer
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: subcontractedtaskdata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE subcontractedtaskdata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    externalcompany bigint,
    subcontratationdate timestamp without time zone,
    subcontractcommunicationdate timestamp without time zone,
    workdescription character varying(255),
    subcontractprice numeric(19,2),
    subcontractedcode character varying(255),
    nodewithoutchildrenexported boolean,
    labelsexported boolean,
    materialassignmentsexported boolean,
    hoursgroupsexported boolean,
    state integer
);


ALTER TABLE public.subcontractedtaskdata OWNER TO naval;

--
-- Name: sumchargedhours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE sumchargedhours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    directchargedhours integer,
    indirectchargedhours integer
);


ALTER TABLE public.sumchargedhours OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone,
    subcontrated_task_data_id bigint,
    priority integer
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint,
    reportadvance boolean
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone NOT NULL,
    enddate timestamp without time zone NOT NULL,
    deadline date,
    advance_percentage numeric(19,2),
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer,
    startdayduration integer,
    enddayduration integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL,
    startconstrainttype integer,
    constraintdate date
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    schedulingdata bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean,
    generatecode boolean NOT NULL
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: unit_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE unit_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    measure character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.unit_type OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date timestamp without time zone,
    generatecode boolean NOT NULL,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    positionnumber integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart integer,
    clockfinish integer,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
2020	17	t	809
2021	17	t	809
2023	9	t	808
2022	9	f	809
2030	16	t	809
2029	9	f	809
2028	9	t	808
2024	17	t	809
2025	17	t	809
2027	9	f	809
2026	9	t	808
31540	4	f	809
31539	4	t	808
71888	7	f	809
5353	28	t	809
5354	28	t	809
5355	28	t	809
5356	28	t	809
82921	6	t	809
82922	6	t	809
9191	12	t	811
9192	12	t	811
9193	12	t	809
43227	13	t	809
43632	13	t	809
43633	13	t	809
9195	9	f	809
9194	9	t	808
31579	9	f	809
82970	1	f	811
5358	20	t	808
5357	20	f	809
82971	2	f	811
82972	2	t	811
5364	20	t	808
5363	20	f	809
22732	18	t	809
22725	18	t	809
22726	18	t	809
22727	18	t	809
22728	18	t	809
22729	18	t	809
5367	20	t	808
5368	20	f	809
5370	20	t	808
5369	20	f	809
31578	9	t	808
82929	3	t	809
5359	28	t	809
9197	9	t	808
9196	9	f	809
26114	10	t	808
26113	10	f	809
5360	28	t	809
31576	13	t	809
71887	7	t	808
31580	13	t	809
31581	13	t	809
31577	13	t	809
26117	10	f	809
26116	10	t	808
82930	2	t	808
31525	5	t	809
31526	5	t	809
31527	5	t	809
31528	5	t	809
31530	4	f	809
31529	4	t	808
31531	5	t	809
31532	5	t	809
31533	5	t	809
31534	5	t	809
31535	4	f	809
31536	4	t	808
31542	4	f	809
31541	4	t	808
31537	5	t	809
31538	5	t	809
82931	2	f	809
71883	9	t	809
76066	4	f	811
43634	13	t	809
43637	13	t	809
43638	13	t	809
43639	13	t	809
26109	14	t	809
26108	14	t	809
26110	14	t	809
31583	9	t	808
5361	28	t	809
71884	9	t	809
26111	14	t	809
43635	8	t	808
43636	8	f	809
26112	14	t	809
26115	14	t	809
31582	9	f	809
82925	6	t	809
31584	13	t	809
22731	15	f	809
22730	15	t	808
31585	9	t	808
22733	15	f	809
22734	15	t	808
31586	9	f	809
71885	8	f	809
71886	8	f	808
82923	3	t	808
82924	3	f	809
5362	28	t	809
82926	3	f	809
82927	3	t	808
5365	28	t	809
5366	28	t	809
43686	3	t	809
43679	3	t	809
43680	3	t	809
43681	3	t	809
43682	3	t	809
43683	3	t	809
71880	10	t	808
71882	10	t	808
71881	10	f	809
76069	2	f	811
71865	14	t	809
71866	14	t	809
71867	14	t	809
76067	3	t	811
82973	1	f	811
82974	1	f	811
82975	1	f	811
82932	7	t	809
82933	7	t	809
43689	7	t	809
82928	4	t	809
82935	6	f	808
76065	5	f	811
76063	7	f	811
76064	6	t	811
82934	6	f	809
43684	2	f	809
43685	2	t	808
43687	2	t	808
43688	2	f	809
43641	8	f	809
43642	8	t	808
43644	12	t	809
43645	8	f	809
43646	8	t	808
43647	8	t	808
43648	8	f	809
43643	13	t	809
43640	13	t	809
71870	10	t	808
76068	2	f	811
71869	10	f	809
71871	11	t	809
71872	11	t	809
71873	11	t	809
71874	11	t	809
71876	10	t	808
71875	10	f	809
71877	11	t	809
71878	11	t	809
71879	10	f	809
82936	5	t	808
82937	5	f	809
106055	4	f	809
106054	4	t	808
106056	4	f	809
106057	4	t	808
106050	7	t	809
106051	7	t	809
106052	7	t	809
106053	7	t	809
103830	8	t	809
103828	8	t	809
103829	8	t	809
103831	8	t	809
103833	7	f	809
103832	7	t	808
109590	15	f	809
109591	15	t	808
109585	19	t	809
109586	19	t	809
109587	19	t	809
109588	19	t	809
109589	19	t	809
109592	19	t	809
109593	19	t	809
109594	19	t	809
109595	19	t	809
109596	19	t	809
109597	19	t	809
109598	19	t	809
109623	6	t	809
109603	15	f	809
109604	15	t	808
159182	22	t	809
159183	22	t	809
159184	22	t	809
159186	18	f	808
159185	18	f	809
159188	18	f	809
159187	18	t	808
159263	8	f	810
165798	2	t	809
153435	6	t	809
153419	6	t	809
109608	15	t	808
109607	15	f	809
153420	6	t	809
153421	6	t	809
153422	6	t	809
153423	5	f	809
109613	15	f	809
109614	15	t	808
153424	5	t	808
153425	6	t	809
153426	6	t	809
153427	6	t	809
153428	6	t	809
153429	6	t	809
109621	15	t	808
109622	15	f	809
153430	6	t	809
109618	19	t	809
109599	19	t	809
109600	19	t	809
109601	19	t	809
109602	19	t	809
150591	3	t	809
109605	19	t	809
109606	19	t	809
109609	19	t	809
109610	19	t	809
109611	19	t	809
109612	19	t	809
109615	19	t	809
109616	19	t	809
109617	19	t	809
109619	19	t	809
109620	19	t	809
153431	6	t	809
153433	5	t	808
153432	5	f	809
153434	6	t	809
153436	6	t	809
159176	22	t	809
159177	22	t	809
159178	22	t	810
159179	22	t	810
159264	8	f	810
153437	6	t	809
153438	5	t	808
153439	5	f	809
159180	18	f	809
159181	18	t	808
159265	7	t	810
\.


--
-- Data for Name: advanceassignmenttemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignmenttemplate (id, version, advance_type_id, order_element_template_id, reportglobaladvance, maxvalue) FROM stdin;
26677	1	809	26614	t	100.00
26678	1	809	26615	t	100.00
26679	1	809	26616	t	100.00
26680	1	809	26617	t	100.00
26681	1	809	26619	t	100.00
26682	1	809	26620	t	100.00
26683	1	809	26621	t	100.00
26684	1	809	26622	t	100.00
26685	1	809	26624	t	100.00
26686	1	809	26625	t	100.00
25619	2	809	25436	t	100.00
25620	2	809	25437	t	100.00
25621	2	809	25438	t	100.00
25622	2	809	25440	t	100.00
25623	2	809	25441	t	100.00
25624	2	809	25442	t	100.00
26702	1	809	26652	t	100.00
26703	1	809	26653	t	100.00
26704	1	809	26655	t	100.00
26705	1	809	26656	t	100.00
26706	1	809	26657	t	100.00
105355	1	809	105258	t	100.00
105356	1	809	105259	t	100.00
105357	1	809	105260	t	100.00
105358	1	809	105261	t	100.00
166977	1	809	166889	t	100.00
166978	1	809	166893	t	100.00
166979	1	810	166894	t	5.00
166980	1	810	166895	t	10.00
166981	1	810	166896	t	10.00
166982	1	809	166897	t	100.00
166983	1	809	166898	t	100.00
166984	1	809	166899	t	100.00
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id, communicationdate) FROM stdin;
48496	4	2010-09-15	10.00	43640	\N
27799	9	2010-07-08	20.00	26108	\N
27851	2	2010-06-24	25.00	26110	\N
8932	6	2010-06-18	30.00	9191	\N
8956	1	2010-06-19	35.00	9192	\N
73590	3	2010-06-16	29.99	76067	\N
73548	7	2010-06-16	10.00	22725	\N
84170	1	2010-07-01	50.00	22729	\N
84144	3	2010-06-16	20.00	22729	\N
27830	0	2010-06-15	50.00	2020	\N
27831	0	2010-06-15	40.00	2030	\N
73579	5	2010-06-16	40.00	71883	\N
73586	6	2010-06-16	40.00	76063	2010-06-16 10:58:05.004
73589	3	2010-06-16	25.00	76066	2010-06-16 10:58:05.004
73580	5	2010-06-16	25.00	71884	\N
6383	23	2010-06-25	20.00	5353	\N
8915	17	2010-07-29	25.00	5355	\N
84204	1	2010-06-24	10.00	82932	\N
84205	1	2010-06-24	15.00	82973	\N
84203	2	2010-06-24	15.00	82971	2010-06-16 18:29:38.892
107989	1	2010-07-08	25.00	106050	\N
161919	11	2010-09-30	25.00	159176	\N
161983	10	2010-09-23	2.00	159178	\N
161984	10	2010-09-09	1.00	159178	\N
162109	9	2010-10-07	3.00	159179	\N
162108	7	2010-12-21	5.00	159265	\N
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage, qualityform) FROM stdin;
808	4	children	100.0000	f	0.0100	t	t	f
809	3	percentage	100.0000	f	0.0100	t	t	f
810	2	units	2147483647.0000	f	1.0000	t	f	f
811	1	subcontractor	100.0000	f	0.0100	t	t	f
165438	1	QF: Formulario de calidade	100.0000	f	0.0100	t	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
5861	4751
5863	4747
7908	4751
16672	4747
16673	4747
16699	4747
16701	4751
26970	4751
26972	4751
26973	4747
26974	4751
26989	4747
27040	4747
27041	4747
27042	4751
27043	4747
27044	4747
27045	4751
27046	4751
27047	4751
27048	4751
27049	4751
43936	4751
43941	4747
43943	4747
43944	4751
43945	4747
43946	510
45989	4751
45990	4747
72925	4748
72929	4748
72930	4748
72931	510
83125	4748
83126	4748
83128	4748
83130	4751
83131	510
83152	4747
83153	4751
104135	4747
104137	4748
104138	4747
106354	4747
111908	109787
111909	109789
111910	109788
111911	109788
111912	109788
116134	109788
116135	109788
116136	109788
116137	109788
116138	109788
116139	109788
116140	109788
116141	109788
116142	109788
116143	109788
116144	109788
116145	109788
128483	109788
128484	109788
128485	109788
128486	109788
128487	109788
128488	109788
128489	109788
128490	109788
128491	109788
128492	109788
128493	109788
128496	109788
151205	109788
159517	152410
159518	152410
159519	152410
159520	152413
159521	152413
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
164025	3
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, code, name) FROM stdin;
2	1	b239c933-2a54-493d-81ac-87e587db0bdb	\N
5	2	8f5ff702-2dbd-4209-928a-54c702dd7673	\N
4444	2	039aaa19-e957-4735-bcdd-258070156265	\N
4445	1	68bb41ad-9f63-4531-b3f3-3fba90b881f0	\N
4446	1	088f35bf-c773-4322-adb4-f0155c2ba870	\N
4447	1	62a7802c-77d6-4499-b79b-09de20279d26	\N
4448	2	52881e47-3ed1-47cd-9345-922398ea874d	\N
4449	1	697d2524-9acc-41f3-b55b-941b34d08eb8	\N
4450	1	9a6a699d-23b6-406c-8172-8c8e80832814	\N
21917	1	570a0ec3-32d5-4291-84f9-a6c8152b99a0	\N
72417	1	53ac9e8b-5305-4821-b928-c97a2dd73605	\N
72418	1	a89cfeb6-a3ee-4762-9dca-b97da28a76d5	\N
72419	2	05c3d56c-68e3-403c-9c20-ca7a9468d099	\N
83732	2	9e4b0ee4-781e-49ae-bd13-183742501f61	\N
3	4	56404054-9105-4bcd-9775-174952902c25	\N
107464	2	66b3f3e2-edc7-4ab9-9aed-d87875a9d8c7	\N
111504	1	e580622b-9001-4fe2-8814-98de591717a0	\N
152005	1	512a5c72-ca31-482c-9e57-d36a39572977	\N
152006	2	4b472f8b-1d86-4246-814d-92ad4ff54978	\N
111505	2	621833ca-8664-41da-a246-50b825205ba7	\N
1	2	5d393609-e203-42eb-ac95-0a352e90aa98	España
152007	1	75cc153d-0c60-4a18-9af0-c2fd623e5b49	Galicia
152008	1	ecaa1d11-2f78-4864-a0fd-9e14dba0fc6a	Galicia Media Xornada
152011	9	bebfeefb-c04e-4914-bf96-e525c4e71474	\N
152009	11	fc111f75-18e8-4cba-9aaa-c7d0fb0e4178	\N
154833	11	fb35453d-0d70-45d6-a0a0-b7818651d05a	\N
168266	1	48df5375-969c-4419-8a6d-d6357176553c	\N
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
1313	1	2010-06-13	\N	2	0
1316	2	2010-06-13	\N	5	0
4646	2	2010-06-14	\N	4444	0
4647	1	2010-06-14	\N	4445	0
4648	1	2010-06-14	\N	4446	0
4649	1	2010-06-14	\N	4447	0
4650	2	2010-06-14	\N	4448	0
4651	1	2010-06-14	\N	4449	0
4652	1	2010-06-14	\N	4450	0
22119	1	2010-06-14	\N	21917	0
72619	1	2010-06-16	\N	72417	0
72620	1	2010-06-16	\N	72418	0
72621	2	2010-06-16	2010-08-13	72419	0
83934	2	2011-01-16	\N	83732	0
1314	4	2010-06-13	\N	3	0
107666	2	2010-07-06	2010-09-07	107464	0
111706	1	2010-07-08	\N	111504	0
152207	1	2010-08-30	\N	152005	0
152208	2	2010-08-30	\N	152006	0
111707	2	2010-07-08	\N	111505	0
152212	8	2010-09-01	\N	152011	0
152209	11	2010-09-02	\N	152009	0
155035	11	2010-09-09	\N	154833	0
168468	1	2010-09-06	\N	168266	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, code, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
102	1	5dcd06a8-5bf7-4f0a-b22f-e96c1dd97124	1	\N	2	0
105	2	92bf9dec-53b9-4d28-88fc-52241fd90430	1	\N	5	0
4545	2	c6e69c26-8bba-4918-b49d-a8c0b9b1c442	1	\N	4444	0
4546	1	64d2247c-2066-4833-8941-1b5c0bd304e1	1	\N	4445	0
4547	1	29e5cb45-3cb3-4e1d-973c-f9f9110c0b7f	1	\N	4446	0
4548	1	4be9c076-9dec-49aa-8b8c-c49ea0cfa7e4	1	\N	4447	0
4549	2	7a0e6b57-50ac-49a3-a701-7ec79f2bc522	1	\N	4448	0
4550	1	3cce9429-94d2-4a84-b866-5ff33e2f64f5	1	\N	4449	0
4551	1	5e2f282b-8318-4c6f-b1aa-52df873e8f82	1	\N	4450	0
22018	1	12480924-24ef-4d7a-bff5-863f3e3321e0	1	\N	21917	0
72518	1	198afe7a-c2f3-47e6-922b-d996e1e29386	1	\N	72417	0
72519	1	e7587da8-63b4-40a9-b37d-717c52e162c0	1	\N	72418	0
72520	2	145821f9-44eb-46e7-b058-662418140f68	1	\N	72419	0
83833	2	67329860-144e-4c31-b075-afc238d0b002	1	\N	83732	0
103	4	a6600c81-6dd8-4603-a436-ae3ab3a85b65	1	\N	3	0
107565	2	1dc6c5d4-0ffe-49c5-966f-42f19b9e88ab	1	\N	107464	0
152112	9	4a6d3dbc-67bb-46cc-b78d-0524ae5dbf3d	152008	\N	152011	0
111605	1	505056e3-942a-4171-8f35-fa2895d0f526	1	\N	111504	0
152110	11	be879237-73c9-444f-b067-6f92da728eea	152007	\N	152009	0
154934	11	f9d823c4-cb8f-411d-92e4-49e00fe41520	152008	\N	154833	0
152106	1	78d84990-d086-41f6-b8b0-6af9c81fe9c8	1	\N	152005	0
152107	2	c66e8193-fdc6-43bf-b8e9-b71075a8b689	1	\N	152006	0
111606	2	04e91d86-941d-4e16-96fb-643a4fad5087	1	\N	111505	0
101	2	d0f2f4ae-8926-4ef0-a24c-7f7f1feee225	\N	\N	1	0
168367	1	389c16f7-e724-4672-9af0-4071c36cacfa	1	\N	168266	0
152108	1	a96bdb13-395e-4af6-99c9-fefd64a86c3a	1	\N	152007	0
152109	1	a0e44272-0263-4347-8d5b-6267610d32b0	152007	\N	152008	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, code, date, duration, calendar_exception_id, base_calendar_id) FROM stdin;
154439	6	67b43a56-f885-4ee3-a523-7d0f0d3e0fee	2010-11-12	0	606	152011
154435	6	a554aac7-b9cf-4f81-bdc9-1d9dc68ec34a	2010-11-09	0	606	152011
154432	6	70202ba7-1b89-41b2-bcd7-7c955534c198	2010-11-10	0	606	152011
154429	1	73c7cfcc-a72d-4cec-a726-871cae8bcd28	2010-12-24	0	610	152007
154430	1	597cb905-d72b-492f-8bea-6bd89cdc23fd	2010-05-17	0	610	152007
154431	1	922484fa-0698-4ac2-9ef8-447acb88f2a1	2010-12-31	0	610	152007
154437	6	0eed5871-9532-4965-8865-80c91de866a6	2010-11-11	0	606	152011
154436	6	49f9530f-e573-43dd-a0e6-918c8949ba0b	2010-11-05	0	606	152011
154433	6	873a9144-6db3-4914-8cf4-ff36acd692fc	2010-11-08	0	606	152011
154434	6	74a8be04-d25e-4238-b783-0d06cc5ef154	2010-11-06	0	606	152011
154438	6	17e0d115-df40-4a41-96e3-f4b64516c951	2010-11-07	0	606	152011
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, code, name, color, notassignable) FROM stdin;
606	6	HOLIDAY	HOLIDAY	red	t
607	5	SICK_LEAVE	SICK_LEAVE	red	t
608	4	LEAVE	LEAVE	red	t
609	3	STRIKE	STRIKE	red	t
610	2	BANK_HOLIDAY	BANK_HOLIDAY	red	t
611	1	WORKABLE_BANK_HOLIDAY	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode, generatecodeforcriterion, generatecodeforlabel, generatecodeforworkreport, generatecodeforresources, generatecodefortypesofworkhours, generatecodeformaterialcategories, generatecodeforunittypes, expandcompanyplanningviewcharts, expandorderplanningviewcharts, expandresourceloadviewcharts) FROM stdin;
202	3	1	B15804842	t	t	t	t	t	t	t	t	t	t
\.


--
-- Data for Name: consolidatedvalue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidatedvalue (id, consolidated_value_type, version, date, value, taskenddate, consolidation_id, advance_measurement_id) FROM stdin;
48614	NonCalculated	0	2010-09-15	10.00	2010-11-06	26522	48496
48615	NonCalculated	1	2010-09-15	10.00	2010-11-06	64749	48496
84441	NonCalculated	2	2010-06-16	20.00	2010-07-17	22830	84144
73745	NonCalculated	8	2010-06-16	10.00	2010-07-01	22826	73548
6565	NonCalculated	16	2010-06-25	20.00	2010-07-21	5454	6383
\.


--
-- Data for Name: consolidation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidation (id, consolidation_type, version, dir_advance_assignment_id, ind_advance_assignment_id) FROM stdin;
26522	NonCalculated	0	43640	\N
64749	NonCalculated	1	43640	\N
22830	NonCalculated	2	22729	\N
22826	NonCalculated	7	22725	\N
5454	NonCalculated	22	5353	\N
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, code, name, enabled) FROM stdin;
164833	2	1c770b01-512e-434b-ae29-3a22e7b5b375	Operarios con máis de 5 anos de experiencia	t
164832	2	b6d02a81-4f3f-4819-a4ca-47848b821beb	Operarios con menos de 5 anos de experiencia.	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, code, name, active, id_criterion_type, parent, predefinedcriterioninternalname) FROM stdin;
505	14	88922432-9273-4424-8a2b-8f12feb2a52c	medicalLeave	t	131072	\N	\N
506	13	0950fe65-93d7-4be8-a409-be71a15b6a6d	paternityLeave	t	131072	\N	\N
507	4	8a7d32d6-05b5-4564-86af-b9c83129f31c	hiredResourceWorkingRelationship	t	131076	\N	\N
508	3	8b24931b-c856-44b4-8e9b-cee668109b8f	firedResourceWorkingRelationship	t	131076	\N	\N
509	1	60a0aa3a-7d89-4da7-b969-cea4d3debdcb	Serras	t	131078	\N	\N
510	1	8dba1e21-572d-4c51-835b-3d5a9af7011d	Tornos	t	131078	\N	\N
4760	1	3a270823-a27f-4e91-a897-6fe052be59de	Oficial 2º	t	131073	\N	\N
4761	1	0e7e9b0b-491b-4f96-a161-3150e2e9a48f	Peón	t	131073	\N	\N
4762	1	5ab495e9-714e-4818-a91f-01e4286b373c	Oficial 1º	t	131073	\N	\N
4758	2	c061322d-e3c2-46f0-880d-8aaac91364a8	Fontanero	t	131075	\N	\N
4750	3	19674a9d-7408-43e6-bffa-36b9d263f766	Revestidor	t	131075	\N	\N
109787	1	f853ee0d-5de9-418d-96ac-572ecd061138	Analista	t	131075	\N	\N
4747	3	2385e1b8-fe90-4a7e-a36e-a40bc7337320	Soldador	t	131075	\N	\N
4757	2	c19886b3-9644-42ca-9625-de225877507a	Electricista	t	131075	\N	\N
109788	1	1c9f3eff-cd28-47c4-abc9-9fcaa274067e	Analista / Desarrollador	t	131075	\N	\N
4749	3	478bbf49-f2d6-4bd4-a1be-1b34e6073b64	Pulidor	t	131075	\N	\N
4752	3	7dfba9b4-6e73-4ad2-a0bd-45f9e7401b37	Tornero	t	131075	\N	\N
4748	3	dd23eea0-15ab-40e0-8ecf-68bb25672d85	Andamiero	t	131075	\N	\N
4759	2	6ab1550f-2fa6-40c9-ac13-d79d3df718dc	Carpintero	t	131075	\N	\N
109789	1	39d51d88-b351-40d5-9ce6-d733909411a2	Coordinador	t	131075	\N	\N
4751	3	d4c3a0f2-1de4-4162-9475-d8b621a46dcb	Pintor	t	131075	\N	\N
4753	2	b750558d-8406-431b-9627-8a5613136f62	Ciclo medio electricista	t	131074	\N	\N
4756	2	8c1a2c3a-bb12-47cb-aa69-fc98f0df2bcc	Ciclo superior soldadura	t	131074	\N	\N
4754	2	dc894670-7e51-4aab-83a7-9f4a83665499	Ciclo medio soldadura	t	131074	\N	\N
152409	1	d5a00d97-8364-4ef7-9154-d8f51209c900	Experto en Typo3	t	131074	\N	\N
4755	2	86f7c98c-9cf2-4966-9e5d-b81081f6b006	Ciclo medio tecnologías de la información	t	131074	\N	\N
152410	1	36e7b321-2224-44c0-b396-a0e95b6303e5	Soldador	t	50069504	\N	\N
152411	1	3e20f3d0-5ee5-4375-ab54-24d9272d32c1	Califugador	t	50069504	\N	\N
152412	1	6917674c-1922-425e-ad45-9400b063a001	Soldador marino	t	50069504	\N	\N
152413	1	7ce45679-1116-4fb0-8448-8b707dcad04d	Carpinteiro	t	50069504	\N	\N
152414	1	0654f8b5-cbd0-4353-9455-1822845c665b	Electricista	t	50069504	\N	\N
152415	1	0761bbb3-ed09-4cb9-be26-c11af71293b1	Pintor	t	50069504	\N	\N
155237	1	f610e1bc-a935-4443-b955-6706cd25bb86	Oficial 2º	t	50331648	\N	\N
155238	1	629f8be5-e9ca-4b12-b78d-77b1a98061b3	Oficial 1º	t	50331648	\N	\N
155239	1	6d2c4b6e-b416-4816-a562-b86e2f5190ec	Peon	t	50331648	\N	\N
168165	1	a4803b82-f294-4bc8-9660-ce58ef59d444	Torno	t	54525952	\N	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, order_element_template_id, criterion_id, parent, valid) FROM stdin;
26267	INDIRECT	9	26364	\N	\N	510	26266	t
26268	DIRECT	10	\N	25901	\N	4747	\N	\N
82856	DIRECT	4	\N	82474	\N	4748	\N	\N
23095	DIRECT	12	\N	22343	\N	4747	\N	\N
23097	DIRECT	12	\N	22344	\N	4751	\N	\N
26262	DIRECT	10	\N	25897	\N	4747	\N	\N
26263	INDIRECT	10	26362	\N	\N	4747	26262	t
26264	DIRECT	10	\N	25898	\N	4751	\N	\N
26265	INDIRECT	9	26363	\N	\N	4751	26264	t
26266	DIRECT	10	\N	25899	\N	510	\N	\N
26269	INDIRECT	7	26365	\N	\N	4747	26268	t
5799	INDIRECT	14	5272	\N	\N	4751	5798	t
5800	DIRECT	20	\N	4981	\N	4747	\N	\N
23099	DIRECT	12	\N	22345	\N	4751	\N	\N
23092	INDIRECT	6	22637	\N	\N	4751	23091	t
23090	INDIRECT	12	22636	\N	\N	4747	23089	t
26270	DIRECT	10	\N	25902	\N	4751	\N	\N
26271	INDIRECT	7	26366	\N	\N	4751	26270	t
23098	INDIRECT	9	22640	\N	\N	4751	23097	t
26272	DIRECT	10	\N	25903	\N	4751	\N	\N
23096	INDIRECT	5	22639	\N	\N	4747	23095	t
82858	DIRECT	4	\N	82475	\N	4748	\N	\N
23114	INDIRECT	4	22638	\N	\N	510	23107	t
26273	INDIRECT	7	26367	\N	\N	4751	26272	t
14960	INDIRECT	10	9106	\N	\N	4747	5800	t
5801	INDIRECT	15	5273	\N	\N	4747	5800	t
82857	INDIRECT	5	82752	\N	\N	4748	82856	t
5815	DIRECT	20	\N	4989	\N	4747	\N	\N
23100	INDIRECT	5	22641	\N	\N	4751	23099	t
82859	INDIRECT	5	82753	\N	\N	4748	82858	t
5798	DIRECT	20	\N	4980	\N	4751	\N	\N
5802	DIRECT	20	\N	4982	\N	4747	\N	\N
5803	INDIRECT	15	5274	\N	\N	4747	5802	t
5804	DIRECT	20	\N	4983	\N	4751	\N	\N
5805	INDIRECT	12	5275	\N	\N	4751	5804	t
23091	DIRECT	12	\N	22340	\N	4751	\N	\N
23089	DIRECT	12	\N	22339	\N	4747	\N	\N
23107	DIRECT	9	\N	22341	\N	510	\N	\N
5806	DIRECT	20	\N	4984	\N	4751	\N	\N
5807	INDIRECT	20	\N	4985	\N	4751	5806	t
5808	INDIRECT	13	5276	\N	\N	4751	5806	t
5809	INDIRECT	20	\N	4986	\N	4751	5806	t
5810	INDIRECT	12	5277	\N	\N	4751	5806	t
5811	INDIRECT	20	\N	4987	\N	4751	5806	t
5812	INDIRECT	11	5278	\N	\N	4751	5806	t
26774	DIRECT	1	\N	\N	26614	4751	\N	\N
26775	INDIRECT	1	26414	\N	\N	4751	26774	t
26776	DIRECT	1	\N	\N	26615	4747	\N	\N
26777	INDIRECT	1	26415	\N	\N	4747	26776	t
26779	DIRECT	1	\N	\N	26616	4747	\N	\N
25786	DIRECT	2	\N	\N	25436	4747	\N	\N
25787	INDIRECT	2	25720	\N	\N	4747	25786	t
25788	DIRECT	2	\N	\N	25437	4751	\N	\N
25789	INDIRECT	2	25721	\N	\N	4751	25788	t
25790	DIRECT	2	\N	\N	25438	510	\N	\N
25791	INDIRECT	2	25722	\N	\N	510	25790	t
25792	DIRECT	2	\N	\N	25440	4747	\N	\N
25793	INDIRECT	2	25723	\N	\N	4747	25792	t
25794	DIRECT	2	\N	\N	25441	4751	\N	\N
25795	INDIRECT	2	25724	\N	\N	4751	25794	t
25796	DIRECT	2	\N	\N	25442	4751	\N	\N
25797	INDIRECT	2	25725	\N	\N	4751	25796	t
43311	DIRECT	10	\N	43464	\N	4751	\N	\N
43313	DIRECT	10	\N	43465	\N	4747	\N	\N
26778	INDIRECT	1	26416	\N	\N	4747	26776	t
26780	INDIRECT	1	26417	\N	\N	4747	26779	t
26781	DIRECT	1	\N	\N	26617	4751	\N	\N
26782	INDIRECT	1	26418	\N	\N	4751	26781	t
26783	DIRECT	1	\N	\N	26618	4751	\N	\N
26784	INDIRECT	1	\N	\N	26619	4751	26783	t
26785	INDIRECT	1	26419	\N	\N	4751	26783	t
26786	INDIRECT	1	\N	\N	26620	4751	26783	t
26787	INDIRECT	1	26420	\N	\N	4751	26783	t
26788	INDIRECT	1	\N	\N	26621	4751	26783	t
26789	INDIRECT	1	26421	\N	\N	4751	26783	t
26790	INDIRECT	1	\N	\N	26622	4751	26783	t
26791	INDIRECT	1	26422	\N	\N	4751	26783	t
26792	DIRECT	1	\N	\N	26623	4747	\N	\N
26793	INDIRECT	1	\N	\N	26624	4747	26792	t
26794	INDIRECT	1	26423	\N	\N	4747	26792	t
26795	INDIRECT	1	\N	\N	26625	4747	26792	t
26796	INDIRECT	1	26424	\N	\N	4747	26792	t
43316	DIRECT	10	\N	43466	\N	4747	\N	\N
43318	DIRECT	10	\N	43467	\N	4751	\N	\N
43320	DIRECT	10	\N	43468	\N	4751	\N	\N
43312	INDIRECT	9	43367	\N	\N	4751	43311	t
43315	INDIRECT	8	43369	\N	\N	4747	43313	t
43314	INDIRECT	8	43368	\N	\N	4747	43313	t
43317	INDIRECT	6	43370	\N	\N	4747	43316	t
43319	INDIRECT	6	43371	\N	\N	4751	43318	t
82860	DIRECT	4	\N	82476	\N	4748	\N	\N
43321	INDIRECT	10	\N	43469	\N	4751	43320	t
43323	INDIRECT	10	\N	43470	\N	4751	43320	t
31631	DIRECT	4	\N	31815	\N	4747	\N	\N
31613	DIRECT	4	\N	25948	\N	4751	\N	\N
31614	INDIRECT	4	26458	\N	\N	4751	31613	t
31615	DIRECT	4	\N	25949	\N	4747	\N	\N
31616	INDIRECT	4	26459	\N	\N	4747	31615	t
31617	INDIRECT	4	26460	\N	\N	4747	31615	t
31618	DIRECT	4	\N	25950	\N	4747	\N	\N
31619	INDIRECT	5	26461	\N	\N	4747	31618	t
31620	DIRECT	4	\N	25951	\N	4751	\N	\N
31621	INDIRECT	4	31714	\N	\N	4751	31620	t
31622	DIRECT	4	\N	25952	\N	4751	\N	\N
31623	INDIRECT	4	\N	25953	\N	4751	31622	t
31624	INDIRECT	4	31715	\N	\N	4751	31622	t
31625	INDIRECT	4	\N	25954	\N	4751	31622	t
31626	INDIRECT	4	31716	\N	\N	4751	31622	t
31627	INDIRECT	4	\N	25955	\N	4751	31622	t
31628	INDIRECT	4	31717	\N	\N	4751	31622	t
31629	INDIRECT	4	\N	25956	\N	4751	31622	t
31630	INDIRECT	4	31718	\N	\N	4751	31622	t
31632	INDIRECT	4	\N	31816	\N	4747	31631	t
31633	INDIRECT	4	31719	\N	\N	4747	31631	t
31634	INDIRECT	4	\N	31817	\N	4747	31631	t
82861	INDIRECT	5	82754	\N	\N	4748	82860	t
43322	INDIRECT	6	43372	\N	\N	4751	43320	t
43325	INDIRECT	10	\N	43471	\N	4751	43320	t
5813	INDIRECT	20	\N	4988	\N	4751	5806	t
43327	INDIRECT	10	\N	43472	\N	4751	43320	t
43324	INDIRECT	6	43373	\N	\N	4751	43320	t
43733	DIRECT	10	\N	43473	\N	4747	\N	\N
43734	INDIRECT	10	\N	43474	\N	4747	43733	t
5814	INDIRECT	11	5279	\N	\N	4751	5806	t
43736	INDIRECT	10	\N	43475	\N	4747	43733	t
5816	INDIRECT	20	\N	4990	\N	4747	5815	t
5817	INDIRECT	16	5280	\N	\N	4747	5815	t
5818	INDIRECT	20	\N	4991	\N	4747	5815	t
5819	INDIRECT	16	5281	\N	\N	4747	5815	t
43326	INDIRECT	6	43374	\N	\N	4751	43320	t
43328	INDIRECT	9	43375	\N	\N	4751	43320	t
43735	INDIRECT	6	43376	\N	\N	4747	43733	t
31635	INDIRECT	4	31720	\N	\N	4747	31631	t
71998	INDIRECT	8	72054	\N	\N	4751	71990	t
71999	DIRECT	9	\N	71662	\N	4747	\N	\N
43774	DIRECT	2	\N	43501	\N	4747	\N	\N
43776	DIRECT	2	\N	43502	\N	4751	\N	\N
43777	INDIRECT	2	43397	\N	\N	4751	43776	t
43778	DIRECT	2	\N	43503	\N	510	\N	\N
43779	INDIRECT	2	43398	\N	\N	510	43778	t
43780	DIRECT	2	\N	43505	\N	4747	\N	\N
43781	INDIRECT	2	43399	\N	\N	4747	43780	t
43782	DIRECT	2	\N	43506	\N	4751	\N	\N
43783	INDIRECT	2	43400	\N	\N	4751	43782	t
43784	DIRECT	2	\N	43507	\N	4751	\N	\N
43785	INDIRECT	2	43401	\N	\N	4751	43784	t
43775	INDIRECT	3	43396	\N	\N	4747	43774	t
43737	INDIRECT	6	43377	\N	\N	4747	43733	t
72000	INDIRECT	9	\N	71663	\N	4747	71999	t
72001	INDIRECT	8	72055	\N	\N	4747	71999	t
72002	INDIRECT	9	\N	71664	\N	4747	71999	t
72003	INDIRECT	8	72056	\N	\N	4747	71999	t
82868	DIRECT	4	\N	82482	\N	510	\N	\N
82869	INDIRECT	5	82760	\N	\N	510	82868	t
82900	DIRECT	4	\N	82491	\N	4747	\N	\N
82901	INDIRECT	5	82764	\N	\N	4747	82900	t
82902	DIRECT	4	\N	82497	\N	4751	\N	\N
82903	INDIRECT	5	82767	\N	\N	4751	82902	t
72854	DIRECT	8	\N	71653	\N	4748	\N	\N
72855	INDIRECT	8	72046	\N	\N	4748	72854	t
72856	DIRECT	8	\N	71654	\N	4748	\N	\N
72857	INDIRECT	7	72048	\N	\N	4748	72856	t
72858	INDIRECT	7	72047	\N	\N	4748	72856	t
72859	DIRECT	8	\N	71655	\N	4748	\N	\N
72860	INDIRECT	7	72049	\N	\N	4748	72859	t
71988	DIRECT	10	\N	71656	\N	4751	\N	\N
71989	INDIRECT	9	72050	\N	\N	4751	71988	t
71990	DIRECT	9	\N	71657	\N	4751	\N	\N
71991	INDIRECT	9	\N	71658	\N	4751	71990	t
71992	INDIRECT	8	72051	\N	\N	4751	71990	t
71993	INDIRECT	9	\N	71659	\N	4751	71990	t
71994	INDIRECT	8	72052	\N	\N	4751	71990	t
71995	INDIRECT	9	\N	71660	\N	4751	71990	t
71996	INDIRECT	8	72053	\N	\N	4751	71990	t
71997	INDIRECT	9	\N	71661	\N	4751	71990	t
149581	DIRECT	3	\N	109315	\N	109788	\N	\N
149582	INDIRECT	4	109498	\N	\N	109788	149581	t
104096	DIRECT	5	\N	103438	\N	4747	\N	\N
104062	DIRECT	6	\N	103436	\N	4747	\N	\N
104063	INDIRECT	7	103735	\N	\N	4747	104062	t
104064	DIRECT	6	\N	103437	\N	4748	\N	\N
104065	INDIRECT	7	103736	\N	\N	4748	104064	t
104098	DIRECT	5	\N	103439	\N	4752	\N	\N
104099	INDIRECT	6	103738	\N	\N	4752	104098	t
104097	INDIRECT	6	103737	\N	\N	4747	104096	t
104124	DIRECT	1	\N	\N	105258	4747	\N	\N
104125	INDIRECT	1	103751	\N	\N	4747	104124	t
104126	DIRECT	1	\N	\N	105259	4748	\N	\N
104127	INDIRECT	1	103752	\N	\N	4748	104126	t
104128	DIRECT	1	\N	\N	105260	4747	\N	\N
104129	INDIRECT	1	103753	\N	\N	4747	104128	t
104130	DIRECT	1	\N	\N	105261	4752	\N	\N
105444	INDIRECT	1	103754	\N	\N	4752	104130	t
105959	DIRECT	5	\N	105559	\N	4747	\N	\N
105960	INDIRECT	6	105856	\N	\N	4747	105959	t
111337	INDIRECT	10	109225	\N	\N	109788	111335	t
111338	INDIRECT	12	\N	108931	\N	109788	111335	t
111339	INDIRECT	10	109226	\N	\N	109788	111335	t
111340	INDIRECT	12	\N	108932	\N	109788	111335	t
111341	INDIRECT	10	109227	\N	\N	109788	111335	t
111342	DIRECT	12	\N	108933	\N	109788	\N	\N
111343	INDIRECT	10	109228	\N	\N	109788	111342	t
111344	DIRECT	12	\N	108972	\N	109788	\N	\N
111345	INDIRECT	12	\N	108934	\N	109788	111344	t
111346	INDIRECT	9	109229	\N	\N	109788	111344	t
111347	INDIRECT	12	\N	108973	\N	109788	111344	t
111348	INDIRECT	9	109264	\N	\N	109788	111344	t
111349	INDIRECT	12	\N	108974	\N	109788	111344	t
111350	INDIRECT	9	109265	\N	\N	109788	111344	t
111351	INDIRECT	12	\N	108975	\N	109788	111344	t
111352	INDIRECT	9	109266	\N	\N	109788	111344	t
111353	INDIRECT	12	\N	108976	\N	109788	111344	t
111354	INDIRECT	9	109267	\N	\N	109788	111344	t
111355	INDIRECT	12	\N	108977	\N	109788	111344	t
111356	INDIRECT	9	109268	\N	\N	109788	111344	t
111357	INDIRECT	12	\N	108978	\N	109788	111344	t
111358	INDIRECT	9	109269	\N	\N	109788	111344	t
111359	INDIRECT	12	\N	109282	\N	109788	111344	t
111360	INDIRECT	9	109270	\N	\N	109788	111344	t
111361	INDIRECT	12	\N	109283	\N	109788	111344	t
111362	INDIRECT	9	109271	\N	\N	109788	111344	t
111363	INDIRECT	12	\N	109284	\N	109788	111344	t
111364	INDIRECT	9	109272	\N	\N	109788	111344	t
150292	INDIRECT	2	\N	150189	\N	109788	111344	t
150293	INDIRECT	3	150492	\N	\N	109788	111344	t
111331	DIRECT	12	\N	108927	\N	109789	\N	\N
111332	INDIRECT	14	109223	\N	\N	109789	111331	t
111333	DIRECT	12	\N	108928	\N	109787	\N	\N
111334	INDIRECT	13	109224	\N	\N	109787	111333	t
111335	DIRECT	12	\N	108929	\N	109788	\N	\N
111336	INDIRECT	12	\N	108930	\N	109788	111335	t
111365	DIRECT	12	\N	109293	\N	109788	\N	\N
111366	INDIRECT	12	\N	109306	\N	109788	111365	t
111367	INDIRECT	10	109490	\N	\N	109788	111365	t
111368	INDIRECT	12	\N	109307	\N	109788	111365	t
111369	INDIRECT	10	109491	\N	\N	109788	111365	t
111370	DIRECT	12	\N	109308	\N	109788	\N	\N
111371	INDIRECT	12	\N	108935	\N	109788	111370	t
111372	INDIRECT	10	109230	\N	\N	109788	111370	t
111373	INDIRECT	12	\N	109295	\N	109788	111370	t
111374	INDIRECT	10	109280	\N	\N	109788	111370	t
111375	INDIRECT	12	\N	109294	\N	109788	111370	t
111376	INDIRECT	10	109279	\N	\N	109788	111370	t
111377	INDIRECT	12	\N	109296	\N	109788	111370	t
111378	INDIRECT	10	109281	\N	\N	109788	111370	t
111379	DIRECT	12	\N	108937	\N	109788	\N	\N
111380	INDIRECT	11	109232	\N	\N	109788	111379	t
111381	DIRECT	12	\N	108938	\N	109788	\N	\N
111382	INDIRECT	11	109233	\N	\N	109788	111381	t
111383	DIRECT	12	\N	108939	\N	109788	\N	\N
111384	INDIRECT	11	109234	\N	\N	109788	111383	t
111385	DIRECT	12	\N	108940	\N	109788	\N	\N
111386	INDIRECT	10	109235	\N	\N	109788	111385	t
111387	DIRECT	12	\N	108941	\N	109788	\N	\N
111388	INDIRECT	12	109236	\N	\N	109788	111387	t
111389	DIRECT	12	\N	109312	\N	109788	\N	\N
111390	INDIRECT	9	109495	\N	\N	109788	111389	t
167194	DIRECT	1	\N	\N	166892	152410	\N	\N
167195	INDIRECT	1	\N	\N	166893	152410	167194	t
167196	INDIRECT	1	167080	\N	\N	152410	167194	t
167197	INDIRECT	1	\N	\N	166894	152410	167194	t
160634	DIRECT	13	\N	158712	\N	152410	\N	\N
167198	INDIRECT	1	167081	\N	\N	152410	167194	t
160635	INDIRECT	13	\N	158713	\N	152410	160634	t
160636	INDIRECT	13	159101	\N	\N	152410	160634	t
160637	INDIRECT	13	\N	158714	\N	152410	160634	t
160638	INDIRECT	13	159102	\N	\N	152410	160634	t
160639	INDIRECT	13	\N	158715	\N	152410	160634	t
160640	INDIRECT	13	159103	\N	\N	152410	160634	t
160641	DIRECT	13	\N	158717	\N	152413	\N	\N
160642	INDIRECT	13	159104	\N	\N	152413	160641	t
167199	INDIRECT	1	\N	\N	166895	152410	167194	t
167200	INDIRECT	1	167082	\N	\N	152410	167194	t
167201	DIRECT	1	\N	\N	166897	152413	\N	\N
167202	INDIRECT	1	167083	\N	\N	152413	167201	t
167203	DIRECT	1	\N	\N	166898	152413	\N	\N
167204	INDIRECT	1	167084	\N	\N	152413	167203	t
167205	DIRECT	1	\N	\N	166899	152413	\N	\N
167206	INDIRECT	1	167085	\N	\N	152413	167205	t
160643	DIRECT	13	\N	158718	\N	152413	\N	\N
160644	INDIRECT	13	159105	\N	\N	152413	160643	t
160645	DIRECT	13	\N	158719	\N	152413	\N	\N
160646	INDIRECT	15	159106	\N	\N	152413	160645	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, code, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
2627	1	df020c7d-8a9b-407d-8cd0-e2dd81da7463	2010-06-13 12:42:41.932	\N	f	510	1220
4848	1	79097724-5c5c-449c-9402-65968bd4213f	2010-06-14 12:56:07.532	\N	f	4747	4344
4849	1	c64b2471-fe3a-4948-ae4e-4b007ba35c0b	2010-06-14 12:57:11.852	\N	f	4747	4348
4850	1	9f966399-4383-4e12-96f5-5fbaf1570188	2010-06-14 00:00:00	\N	f	4747	4350
4851	1	a387e54a-5903-4821-b768-03bb230cdb70	2010-06-14 12:57:53.247	\N	f	4751	4352
4852	2	3ce6d0f5-c10f-4c6f-8ae0-8544173599a5	2010-06-14 00:00:00	\N	f	4751	4354
4853	1	71712208-998e-42c0-8f9a-b08849f3ef9c	2010-06-14 00:00:00	\N	f	4747	4358
22220	1	2caf2d13-f23c-4f60-beaa-ee2e494d6044	2010-06-14 18:08:20.558	2010-07-14 00:00:00	f	4747	21817
72720	1	0ee8a190-e2d2-4290-a77c-690e885b3348	2010-06-16 09:53:13.847	\N	f	4748	72317
72721	1	b250df17-4b16-48d9-b8bb-3f3ee0dd6292	2010-06-16 09:53:51.588	\N	f	4748	72319
72722	2	b213c33a-5cf4-49aa-b320-f9f0c0c6b475	2010-06-16 10:00:26.272	\N	f	4748	72321
84037	2	aae1cd60-c087-48cf-a7a5-58e3b97ab49f	2011-01-16 00:00:00	\N	f	4748	83633
2626	3	c0c879d6-1d67-4262-bccd-698d8a6cc04c	2010-06-13 00:00:00	\N	f	510	1216
107767	2	53272e6a-4124-4bde-9998-3524a0c3cd00	2010-07-06 12:03:30.939	\N	f	4747	107364
111807	1	348495c4-a107-4872-813e-da0cbfb1b0b6	2010-07-08 11:43:43.328	\N	f	109788	111404
152308	1	08ed92a7-4e84-43df-b27d-23ab8abaeb8b	2010-08-30 14:06:04.123	\N	f	109788	151905
152309	2	8cc32bab-d609-4884-b3eb-cc65d2206d95	2010-08-30 14:06:41.656	\N	f	109788	151907
152310	1	62339858-1be6-4b8e-b83a-f62ff4bbb3f2	2010-08-30 00:00:00	\N	f	152409	151907
111809	2	13f20099-841d-4dcd-9668-1a9ef6d46e1b	2010-07-08 11:43:57.546	\N	f	109789	111406
152311	1	fbf5c786-8019-4434-b162-e7404400b4b0	2010-08-30 14:10:23.237	\N	f	152409	111406
111808	2	0b2c9417-5f47-4fe0-baa5-26aa521f4daf	2010-07-08 11:44:10.856	\N	f	109787	111406
111810	2	e9919603-20a6-413a-9c34-724d79be5539	2010-07-08 11:44:05.117	\N	f	109788	111406
155338	5	f875d47e-0446-4e22-ad82-3cefe1ffd810	2010-09-02 13:19:42.399	\N	f	4747	151915
155339	5	17b40dc1-0209-4dd9-be41-7a4abe7508de	2010-09-02 13:19:48.42	\N	f	155238	151915
155342	9	11d4b3e1-6bd4-435d-8383-73644c8f0e6b	2010-09-02 13:21:01.633	\N	f	155237	151909
155343	9	5697cc44-d4cf-4bb0-8294-36a91a026dd5	2010-09-02 13:20:43.995	\N	f	152410	151909
155340	9	07642177-aeee-4166-af43-f7aa1a5aac5f	2010-09-02 13:20:08.399	\N	f	155238	154733
155341	9	08e736e9-3d58-4f38-81d0-c0f2547a09d7	2010-09-02 00:00:00	\N	f	152413	154733
168569	1	f0cb8826-f750-4517-bd68-260d9e1a4b28	2010-09-06 17:42:28.178	\N	f	168165	167965
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, code, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, generatecode, resource, predefinedtypeinternalname) FROM stdin;
131072	15	3d1358b7-eb8e-40bc-8c3b-f6cca7f89b68	LEAVE	Leave	f	f	t	f	1	\N
131076	5	2bb2ac50-d133-4a65-94b6-781aaea01195	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	f	1	\N
131077	1	a25159a6-5ec3-43b8-a423-f7aa6723e237	LOCATION_GROUP	Location where the resource work	t	f	t	f	0	\N
131078	1	9c3603cb-62fb-469c-a2c9-8c856e923a9a	Tipo de maquina	Este criterio faise para clasificar os distintos tipos de maquinas	t	f	t	t	2	\N
131073	12	ce41a9f3-76fd-4b87-a042-77615da665a5	Categoría profesional	Professional category	t	t	t	f	1	\N
2424832	13	5632c9cf-046f-4141-8d7e-47ffb792cc24	CATEGORY	Professional category	t	t	t	f	1	\N
2424833	11	414260c8-691a-4a87-927c-4ccc85569626	TRAINING	Training courses and labor training	t	t	t	f	1	\N
2424834	9	0282320c-65cd-467d-abec-be8a4c1ce3a8	JOB	Job	t	t	t	f	1	\N
131075	10	0a2fd812-e7d8-4774-9030-224bf0462ee5	Tipo de trabajo	Job	t	t	t	f	1	\N
131074	11	2b1d47d1-5b13-4e5b-8ccf-874309111813	Formación	Training courses and labor training	t	t	t	f	1	\N
50069504	1	b8fa22a3-9057-4f06-a321-e4b42011bfe9	Tipo de traballo	\N	t	f	t	t	0	\N
50331648	1	1a441183-7b94-4825-a28a-050e85beef55	Capacitación	\N	t	f	t	t	0	\N
54525952	1	a7e75e58-045d-4ddc-8614-6bf0f7554e63	Máquinas	\N	t	t	t	t	2	\N
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, duration, consolidated, day, resource_id, specific_container_id, generic_container_id, derived_container_id) FROM stdin;
153845	SPECIFIC_DAY	2	3600	f	2010-10-28	111406	153722	\N	\N
153846	SPECIFIC_DAY	2	3600	f	2010-11-03	111406	153722	\N	\N
153847	SPECIFIC_DAY	2	3600	f	2010-11-01	111406	153722	\N	\N
153823	SPECIFIC_DAY	2	3600	f	2010-11-08	111406	153722	\N	\N
153824	SPECIFIC_DAY	2	7200	f	2010-09-20	111406	153722	\N	\N
153825	SPECIFIC_DAY	2	7200	f	2010-09-24	111406	153722	\N	\N
153826	SPECIFIC_DAY	2	3600	f	2010-11-05	111406	153722	\N	\N
153827	SPECIFIC_DAY	2	3600	f	2010-10-05	111406	153722	\N	\N
153828	SPECIFIC_DAY	2	7200	f	2010-09-27	111406	153722	\N	\N
153829	SPECIFIC_DAY	2	3600	f	2010-10-11	111406	153722	\N	\N
153830	SPECIFIC_DAY	2	3600	f	2010-10-04	111406	153722	\N	\N
153831	SPECIFIC_DAY	2	3600	f	2010-10-22	111406	153722	\N	\N
153832	SPECIFIC_DAY	2	3600	f	2010-10-19	111406	153722	\N	\N
153833	SPECIFIC_DAY	2	7200	f	2010-09-21	111406	153722	\N	\N
153834	SPECIFIC_DAY	2	3600	f	2010-10-18	111406	153722	\N	\N
153835	SPECIFIC_DAY	2	3600	f	2010-10-14	111406	153722	\N	\N
153836	SPECIFIC_DAY	2	3600	f	2010-10-08	111406	153722	\N	\N
153837	SPECIFIC_DAY	2	3600	f	2010-11-04	111406	153722	\N	\N
153838	SPECIFIC_DAY	2	7200	f	2010-09-22	111406	153722	\N	\N
153839	SPECIFIC_DAY	2	3600	f	2010-10-15	111406	153722	\N	\N
153840	SPECIFIC_DAY	2	3600	f	2010-11-09	111406	153722	\N	\N
153841	SPECIFIC_DAY	2	3600	f	2010-10-12	111406	153722	\N	\N
153842	SPECIFIC_DAY	2	3600	f	2010-10-29	111406	153722	\N	\N
153843	SPECIFIC_DAY	2	3600	f	2010-10-01	111406	153722	\N	\N
153844	SPECIFIC_DAY	2	3600	f	2010-10-21	111406	153722	\N	\N
153848	SPECIFIC_DAY	2	3600	f	2010-10-07	111406	153722	\N	\N
153849	SPECIFIC_DAY	2	7200	f	2010-09-23	111406	153722	\N	\N
153850	SPECIFIC_DAY	2	3600	f	2010-10-13	111406	153722	\N	\N
153851	SPECIFIC_DAY	2	3600	f	2010-10-26	111406	153722	\N	\N
153852	SPECIFIC_DAY	2	3600	f	2010-10-20	111406	153722	\N	\N
153853	SPECIFIC_DAY	2	7200	f	2010-09-28	111406	153722	\N	\N
153854	SPECIFIC_DAY	2	3600	f	2010-10-27	111406	153722	\N	\N
153855	SPECIFIC_DAY	2	7200	f	2010-09-29	111406	153722	\N	\N
153856	SPECIFIC_DAY	2	3600	f	2010-11-11	111406	153722	\N	\N
153857	SPECIFIC_DAY	2	3600	f	2010-11-12	111406	153722	\N	\N
153858	SPECIFIC_DAY	2	3600	f	2010-10-06	111406	153722	\N	\N
153859	SPECIFIC_DAY	2	3600	f	2010-10-25	111406	153722	\N	\N
153860	SPECIFIC_DAY	2	7200	f	2010-09-30	111406	153722	\N	\N
153861	SPECIFIC_DAY	2	3600	f	2010-11-02	111406	153722	\N	\N
153862	SPECIFIC_DAY	2	3600	f	2010-11-10	111406	153722	\N	\N
153863	SPECIFIC_DAY	2	3600	f	2010-09-21	111406	153723	\N	\N
153864	SPECIFIC_DAY	2	3600	f	2010-10-06	111406	153723	\N	\N
153865	SPECIFIC_DAY	2	3600	f	2010-09-22	111406	153723	\N	\N
153866	SPECIFIC_DAY	2	3600	f	2010-09-28	111406	153723	\N	\N
153867	SPECIFIC_DAY	2	3600	f	2010-10-08	111406	153723	\N	\N
153868	SPECIFIC_DAY	2	3600	f	2010-09-24	111406	153723	\N	\N
153869	SPECIFIC_DAY	2	3600	f	2010-09-29	111406	153723	\N	\N
153870	SPECIFIC_DAY	2	3600	f	2010-09-23	111406	153723	\N	\N
153871	SPECIFIC_DAY	2	3600	f	2010-10-05	111406	153723	\N	\N
153872	SPECIFIC_DAY	2	3600	f	2010-09-20	111406	153723	\N	\N
153873	SPECIFIC_DAY	2	3600	f	2010-09-30	111406	153723	\N	\N
153874	SPECIFIC_DAY	2	3600	f	2010-10-01	111406	153723	\N	\N
153875	SPECIFIC_DAY	2	3600	f	2010-09-27	111406	153723	\N	\N
153876	SPECIFIC_DAY	2	3600	f	2010-10-04	111406	153723	\N	\N
153877	SPECIFIC_DAY	2	3600	f	2010-10-07	111406	153723	\N	\N
153878	SPECIFIC_DAY	2	3600	f	2010-10-11	111406	153723	\N	\N
154175	SPECIFIC_DAY	1	25200	f	2010-09-21	151907	153768	\N	\N
154176	SPECIFIC_DAY	1	0	f	2010-09-19	151907	153769	\N	\N
154177	SPECIFIC_DAY	1	25200	f	2010-09-20	151907	153769	\N	\N
154178	SPECIFIC_DAY	1	25200	f	2010-09-22	151907	153770	\N	\N
154179	SPECIFIC_DAY	1	28800	f	2010-09-24	151907	153771	\N	\N
154180	SPECIFIC_DAY	1	28800	f	2010-09-28	151907	153771	\N	\N
154181	SPECIFIC_DAY	1	0	f	2010-09-26	151907	153771	\N	\N
154182	SPECIFIC_DAY	1	28800	f	2010-09-30	151907	153771	\N	\N
154183	SPECIFIC_DAY	1	18000	f	2010-10-01	151907	153771	\N	\N
154184	SPECIFIC_DAY	1	28800	f	2010-09-29	151907	153771	\N	\N
154185	SPECIFIC_DAY	1	28800	f	2010-09-27	151907	153771	\N	\N
154186	SPECIFIC_DAY	1	28800	f	2010-09-23	151907	153771	\N	\N
154187	SPECIFIC_DAY	1	0	f	2010-09-25	151907	153771	\N	\N
154188	SPECIFIC_DAY	1	0	f	2010-10-03	151907	153772	\N	\N
154189	SPECIFIC_DAY	1	25200	f	2010-10-04	151907	153772	\N	\N
154190	SPECIFIC_DAY	1	25200	f	2010-10-05	151907	153772	\N	\N
154191	SPECIFIC_DAY	1	0	f	2010-10-02	151907	153772	\N	\N
154192	SPECIFIC_DAY	1	21600	f	2010-10-07	151907	153773	\N	\N
154193	SPECIFIC_DAY	1	28800	f	2010-10-06	151907	153773	\N	\N
154194	SPECIFIC_DAY	1	0	f	2010-10-09	151907	153774	\N	\N
154195	SPECIFIC_DAY	1	25200	f	2010-10-11	151907	153774	\N	\N
154196	SPECIFIC_DAY	1	0	f	2010-10-10	151907	153774	\N	\N
154197	SPECIFIC_DAY	1	25200	f	2010-10-08	151907	153774	\N	\N
154198	SPECIFIC_DAY	1	25200	f	2010-10-14	151907	153775	\N	\N
154199	SPECIFIC_DAY	1	25200	f	2010-10-15	151907	153775	\N	\N
154200	SPECIFIC_DAY	1	0	f	2010-10-17	151907	153775	\N	\N
154201	SPECIFIC_DAY	1	25200	f	2010-10-12	151907	153775	\N	\N
154202	SPECIFIC_DAY	1	25200	f	2010-10-13	151907	153775	\N	\N
154203	SPECIFIC_DAY	1	25200	f	2010-10-18	151907	153775	\N	\N
154204	SPECIFIC_DAY	1	0	f	2010-10-16	151907	153775	\N	\N
154209	SPECIFIC_DAY	1	3600	f	2010-09-24	111406	153777	\N	\N
154210	SPECIFIC_DAY	1	3600	f	2010-09-27	111406	153777	\N	\N
154211	SPECIFIC_DAY	1	3600	f	2010-09-28	111406	153777	\N	\N
154212	SPECIFIC_DAY	1	3600	f	2010-09-22	111406	153777	\N	\N
154213	SPECIFIC_DAY	1	3600	f	2010-09-30	111406	153777	\N	\N
154214	SPECIFIC_DAY	1	3600	f	2010-09-23	111406	153777	\N	\N
154215	SPECIFIC_DAY	1	7200	f	2010-09-21	111406	153777	\N	\N
154216	SPECIFIC_DAY	1	3600	f	2010-09-29	111406	153777	\N	\N
154217	SPECIFIC_DAY	1	3600	f	2010-10-01	111406	153777	\N	\N
154247	SPECIFIC_DAY	0	25200	f	2010-10-19	151907	153776	\N	\N
154248	SPECIFIC_DAY	0	25200	f	2010-10-20	151907	153776	\N	\N
154249	SPECIFIC_DAY	0	25200	f	2010-10-22	151907	153776	\N	\N
154250	SPECIFIC_DAY	0	25200	f	2010-10-21	151907	153776	\N	\N
154244	SPECIFIC_DAY	0	0	f	2010-10-24	151907	153782	\N	\N
154245	SPECIFIC_DAY	0	0	f	2010-10-23	151907	153782	\N	\N
154246	SPECIFIC_DAY	0	25200	f	2010-10-25	151907	153782	\N	\N
154251	SPECIFIC_DAY	0	25200	f	2010-10-27	151907	153783	\N	\N
154252	SPECIFIC_DAY	0	25200	f	2010-10-25	151907	153784	\N	\N
154253	SPECIFIC_DAY	0	25200	f	2010-10-26	151907	153784	\N	\N
154254	SPECIFIC_DAY	0	0	f	2010-10-23	151907	153784	\N	\N
154255	SPECIFIC_DAY	0	0	f	2010-10-24	151907	153784	\N	\N
164004	SPECIFIC_DAY	3	14400	f	2010-10-26	151915	159582	\N	\N
163967	SPECIFIC_DAY	3	3600	f	2010-09-17	151915	159582	\N	\N
163992	SPECIFIC_DAY	3	18000	f	2010-10-31	151915	159582	\N	\N
164001	SPECIFIC_DAY	3	3600	f	2010-09-23	151915	159582	\N	\N
164005	SPECIFIC_DAY	3	21600	f	2010-11-04	151915	159582	\N	\N
164007	SPECIFIC_DAY	3	3600	f	2010-10-06	151915	159582	\N	\N
163969	SPECIFIC_DAY	3	3600	f	2010-09-14	151915	159582	\N	\N
164018	SPECIFIC_DAY	3	18000	f	2010-10-27	151915	159582	\N	\N
163987	SPECIFIC_DAY	3	21600	f	2010-10-29	151915	159582	\N	\N
163983	SPECIFIC_DAY	3	14400	f	2010-10-15	151915	159582	\N	\N
163996	SPECIFIC_DAY	3	14400	f	2010-10-18	151915	159582	\N	\N
163986	SPECIFIC_DAY	3	25200	f	2010-11-13	151915	159582	\N	\N
163975	SPECIFIC_DAY	3	18000	f	2010-10-24	151915	159582	\N	\N
163995	SPECIFIC_DAY	3	18000	f	2010-11-02	151915	159582	\N	\N
163968	SPECIFIC_DAY	3	14400	f	2010-10-13	151915	159582	\N	\N
164006	SPECIFIC_DAY	3	21600	f	2010-11-17	151915	159582	\N	\N
163974	SPECIFIC_DAY	3	10800	f	2010-10-05	151915	159582	\N	\N
163970	SPECIFIC_DAY	3	3600	f	2010-09-04	151915	159582	\N	\N
163977	SPECIFIC_DAY	3	14400	f	2010-10-17	151915	159582	\N	\N
163971	SPECIFIC_DAY	3	3600	f	2010-09-29	151915	159582	\N	\N
164009	SPECIFIC_DAY	3	18000	f	2010-10-21	151915	159582	\N	\N
163984	SPECIFIC_DAY	3	14400	f	2010-10-22	151915	159582	\N	\N
163993	SPECIFIC_DAY	3	3600	f	2010-09-21	151915	159582	\N	\N
164012	SPECIFIC_DAY	3	3600	f	2010-10-03	151915	159582	\N	\N
163989	SPECIFIC_DAY	3	10800	f	2010-10-16	151915	159582	\N	\N
163997	SPECIFIC_DAY	3	3600	f	2010-09-10	151915	159582	\N	\N
164022	SPECIFIC_DAY	3	3600	f	2010-09-28	151915	159582	\N	\N
164020	SPECIFIC_DAY	3	3600	f	2010-09-22	151915	159582	\N	\N
164125	SPECIFIC_DAY	3	14400	f	2010-10-10	151915	159582	\N	\N
164023	SPECIFIC_DAY	3	25200	f	2010-11-18	151915	159582	\N	\N
164126	SPECIFIC_DAY	3	25200	f	2010-11-16	151915	159582	\N	\N
164021	SPECIFIC_DAY	3	21600	f	2010-11-03	151915	159582	\N	\N
164147	GENERIC_DAY	3	28800	f	2010-10-05	151909	\N	160727	\N
164146	GENERIC_DAY	3	28800	f	2010-09-07	151909	\N	160727	\N
164175	GENERIC_DAY	3	28800	f	2010-09-16	151909	\N	160727	\N
164183	GENERIC_DAY	3	28800	f	2010-09-14	151909	\N	160727	\N
164148	GENERIC_DAY	3	28800	f	2010-09-09	151909	\N	160727	\N
164165	GENERIC_DAY	3	28800	f	2010-09-23	151909	\N	160727	\N
164166	GENERIC_DAY	3	28800	f	2010-09-15	151909	\N	160727	\N
164173	GENERIC_DAY	3	14400	f	2010-10-11	151909	\N	160727	\N
164167	GENERIC_DAY	3	28800	f	2010-10-04	151909	\N	160727	\N
164150	GENERIC_DAY	3	28800	f	2010-10-07	151909	\N	160727	\N
164152	GENERIC_DAY	3	28800	f	2010-09-21	151909	\N	160727	\N
164178	GENERIC_DAY	3	14400	f	2010-10-12	151909	\N	160727	\N
164149	GENERIC_DAY	3	28800	f	2010-09-22	151909	\N	160727	\N
164163	GENERIC_DAY	3	14400	f	2010-09-28	151909	\N	160727	\N
164164	GENERIC_DAY	3	0	f	2010-09-12	151909	\N	160727	\N
164160	GENERIC_DAY	3	0	f	2010-09-04	151909	\N	160727	\N
164180	GENERIC_DAY	3	28800	f	2010-09-13	151909	\N	160727	\N
164170	GENERIC_DAY	3	14400	f	2010-10-13	151909	\N	160727	\N
164161	GENERIC_DAY	3	0	f	2010-09-05	151909	\N	160727	\N
164179	GENERIC_DAY	3	14400	f	2010-10-15	151909	\N	160727	\N
164156	GENERIC_DAY	3	0	f	2010-09-25	151909	\N	160727	\N
164159	GENERIC_DAY	3	14400	f	2010-09-30	151909	\N	160727	\N
164162	GENERIC_DAY	3	0	f	2010-09-19	151909	\N	160727	\N
164151	GENERIC_DAY	3	28800	f	2010-09-17	151909	\N	160727	\N
164171	GENERIC_DAY	3	28800	f	2010-09-24	151909	\N	160727	\N
164155	GENERIC_DAY	3	14400	f	2010-09-27	151909	\N	160727	\N
164158	GENERIC_DAY	3	0	f	2010-09-18	151909	\N	160727	\N
164172	GENERIC_DAY	3	28800	f	2010-09-10	151909	\N	160727	\N
164177	GENERIC_DAY	3	14400	f	2010-09-29	151909	\N	160727	\N
164153	GENERIC_DAY	3	28800	f	2010-09-20	151909	\N	160727	\N
164181	GENERIC_DAY	3	28800	f	2010-09-06	151909	\N	160727	\N
164176	GENERIC_DAY	3	14400	f	2010-10-01	151909	\N	160727	\N
164168	GENERIC_DAY	3	0	f	2010-09-11	151909	\N	160727	\N
164154	GENERIC_DAY	3	0	f	2010-09-26	151909	\N	160727	\N
164182	GENERIC_DAY	3	28800	f	2010-09-08	151909	\N	160727	\N
164169	GENERIC_DAY	3	28800	f	2010-10-06	151909	\N	160727	\N
164174	GENERIC_DAY	3	14400	f	2010-10-14	151909	\N	160727	\N
164157	GENERIC_DAY	3	28800	f	2010-09-03	151909	\N	160727	\N
85908	GENERIC_DAY	0	0	f	2010-09-04	1216	\N	42597	\N
85909	GENERIC_DAY	0	28800	f	2010-10-13	1216	\N	42597	\N
85910	GENERIC_DAY	0	28800	f	2010-09-15	1216	\N	42597	\N
112486	GENERIC_DAY	7	18000	f	2010-09-08	111404	\N	112012	\N
112481	GENERIC_DAY	7	18000	f	2010-09-06	111404	\N	112012	\N
112483	GENERIC_DAY	7	18000	f	2010-09-01	111404	\N	112012	\N
112484	GENERIC_DAY	7	10800	f	2010-09-06	111406	\N	112012	\N
112487	GENERIC_DAY	7	10800	f	2010-09-07	111406	\N	112012	\N
112482	GENERIC_DAY	7	18000	f	2010-09-03	111404	\N	112012	\N
112479	GENERIC_DAY	7	18000	f	2010-09-02	111404	\N	112012	\N
112480	GENERIC_DAY	7	18000	f	2010-09-09	111404	\N	112012	\N
112490	GENERIC_DAY	7	10800	f	2010-09-08	111406	\N	112012	\N
112489	GENERIC_DAY	7	10800	f	2010-09-02	111406	\N	112012	\N
112478	GENERIC_DAY	7	0	f	2010-09-04	111406	\N	112012	\N
112477	GENERIC_DAY	7	10800	f	2010-09-03	111406	\N	112012	\N
112485	GENERIC_DAY	7	18000	f	2010-09-07	111404	\N	112012	\N
112488	GENERIC_DAY	7	10800	f	2010-09-09	111406	\N	112012	\N
112197	GENERIC_DAY	9	3600	f	2010-10-27	111406	\N	112009	\N
112198	GENERIC_DAY	9	3600	f	2010-12-28	111406	\N	112009	\N
112195	GENERIC_DAY	9	3600	f	2011-01-03	111406	\N	112009	\N
112200	GENERIC_DAY	9	3600	f	2010-10-07	111406	\N	112009	\N
112199	GENERIC_DAY	9	3600	f	2010-11-29	111406	\N	112009	\N
112196	GENERIC_DAY	9	3600	f	2010-10-26	111406	\N	112009	\N
112202	GENERIC_DAY	9	3600	f	2010-09-30	111406	\N	112010	\N
112211	GENERIC_DAY	9	3600	f	2010-09-27	111406	\N	112010	\N
112203	GENERIC_DAY	9	3600	f	2010-12-10	111406	\N	112010	\N
112201	GENERIC_DAY	9	3600	f	2010-11-30	111406	\N	112010	\N
112205	GENERIC_DAY	9	3600	f	2010-11-24	111406	\N	112010	\N
112208	GENERIC_DAY	9	3600	f	2010-10-04	111406	\N	112010	\N
112207	GENERIC_DAY	9	3600	f	2010-09-09	111406	\N	112010	\N
112210	GENERIC_DAY	9	3600	f	2010-09-22	111406	\N	112010	\N
112204	GENERIC_DAY	9	3600	f	2010-09-10	111406	\N	112010	\N
112212	GENERIC_DAY	9	3600	f	2010-12-24	111406	\N	112010	\N
112209	GENERIC_DAY	9	3600	f	2010-10-15	111406	\N	112010	\N
112206	GENERIC_DAY	9	3600	f	2011-01-10	111406	\N	112010	\N
149370	GENERIC_DAY	4	3600	f	2010-12-10	111406	\N	116240	\N
149358	GENERIC_DAY	4	10800	f	2010-12-16	111404	\N	116240	\N
149364	GENERIC_DAY	4	3600	f	2010-12-13	111406	\N	116240	\N
149363	GENERIC_DAY	4	10800	f	2010-12-15	111404	\N	116240	\N
149360	GENERIC_DAY	4	0	f	2010-12-12	111406	\N	116240	\N
149368	GENERIC_DAY	4	14400	f	2010-12-13	111404	\N	116240	\N
149362	GENERIC_DAY	4	3600	f	2010-12-14	111406	\N	116240	\N
149366	GENERIC_DAY	4	0	f	2010-12-12	111404	\N	116240	\N
149365	GENERIC_DAY	4	7200	f	2010-12-16	111406	\N	116240	\N
149361	GENERIC_DAY	4	14400	f	2010-12-10	111404	\N	116240	\N
149359	GENERIC_DAY	4	14400	f	2010-12-14	111404	\N	116240	\N
149357	GENERIC_DAY	4	7200	f	2010-12-15	111406	\N	116240	\N
149369	GENERIC_DAY	4	0	f	2010-12-11	111406	\N	116240	\N
149367	GENERIC_DAY	4	0	f	2010-12-11	111404	\N	116240	\N
149380	GENERIC_DAY	4	0	f	2010-12-18	111406	\N	116241	\N
149375	GENERIC_DAY	4	18000	f	2010-12-17	111404	\N	116241	\N
149377	GENERIC_DAY	4	18000	f	2010-12-20	111404	\N	116241	\N
149371	GENERIC_DAY	4	14400	f	2010-12-23	111406	\N	116241	\N
149372	GENERIC_DAY	4	10800	f	2010-12-20	111406	\N	116241	\N
149374	GENERIC_DAY	4	0	f	2010-12-19	111406	\N	116241	\N
149378	GENERIC_DAY	4	10800	f	2010-12-17	111406	\N	116241	\N
149376	GENERIC_DAY	4	10800	f	2010-12-21	111406	\N	116241	\N
149373	GENERIC_DAY	4	18000	f	2010-12-21	111404	\N	116241	\N
149379	GENERIC_DAY	4	14400	f	2010-12-23	111404	\N	116241	\N
149396	GENERIC_DAY	4	14400	f	2010-12-28	111406	\N	116242	\N
149395	GENERIC_DAY	4	14400	f	2010-12-29	111406	\N	116242	\N
104871	GENERIC_DAY	2	7200	f	2010-07-29	4350	\N	104235	\N
104872	GENERIC_DAY	2	7200	f	2010-07-26	4350	\N	104235	\N
104873	GENERIC_DAY	2	7200	f	2010-07-22	4358	\N	104235	\N
104874	GENERIC_DAY	2	7200	f	2010-07-30	4358	\N	104235	\N
104875	GENERIC_DAY	2	7200	f	2010-07-30	4348	\N	104235	\N
104876	GENERIC_DAY	2	0	f	2010-08-07	4348	\N	104235	\N
104877	GENERIC_DAY	2	0	f	2010-07-24	4348	\N	104235	\N
104878	GENERIC_DAY	2	7200	f	2010-08-09	4344	\N	104235	\N
104879	GENERIC_DAY	2	7200	f	2010-08-04	4348	\N	104235	\N
112473	GENERIC_DAY	8	3600	f	2010-09-20	111404	\N	112011	\N
112476	GENERIC_DAY	8	3600	f	2010-11-24	111404	\N	112011	\N
112474	GENERIC_DAY	8	3600	f	2010-10-18	111404	\N	112011	\N
112475	GENERIC_DAY	8	3600	f	2010-10-20	111404	\N	112011	\N
104880	GENERIC_DAY	2	7200	f	2010-07-19	4348	\N	104235	\N
104881	GENERIC_DAY	2	7200	f	2010-07-19	4358	\N	104235	\N
104882	GENERIC_DAY	2	0	f	2010-07-17	4344	\N	104235	\N
104883	GENERIC_DAY	2	0	f	2010-07-31	4350	\N	104235	\N
104884	GENERIC_DAY	2	0	f	2010-07-31	4358	\N	104235	\N
104885	GENERIC_DAY	2	7200	f	2010-08-06	4358	\N	104235	\N
104886	GENERIC_DAY	2	7200	f	2010-08-06	4344	\N	104235	\N
104887	GENERIC_DAY	2	0	f	2010-07-18	4348	\N	104235	\N
104888	GENERIC_DAY	2	7200	f	2010-07-26	4348	\N	104235	\N
104889	GENERIC_DAY	2	7200	f	2010-07-16	4348	\N	104235	\N
104890	GENERIC_DAY	2	0	f	2010-08-08	4350	\N	104235	\N
104891	GENERIC_DAY	2	0	f	2010-07-15	4344	\N	104235	\N
104892	GENERIC_DAY	2	0	f	2010-07-16	4344	\N	104235	\N
104893	GENERIC_DAY	2	0	f	2010-07-24	4350	\N	104235	\N
104894	GENERIC_DAY	2	7200	f	2010-07-23	4350	\N	104235	\N
104895	GENERIC_DAY	2	7200	f	2010-07-26	4344	\N	104235	\N
104896	GENERIC_DAY	2	7200	f	2010-07-30	4344	\N	104235	\N
104897	GENERIC_DAY	2	0	f	2010-08-01	4350	\N	104235	\N
104898	GENERIC_DAY	2	10800	f	2010-07-15	4350	\N	104235	\N
104899	GENERIC_DAY	2	7200	f	2010-08-02	4344	\N	104235	\N
149505	GENERIC_DAY	4	14400	f	2010-11-11	111404	\N	116245	\N
149496	GENERIC_DAY	4	3600	f	2010-11-11	111406	\N	116245	\N
149498	GENERIC_DAY	4	14400	f	2010-11-12	111404	\N	116245	\N
149493	GENERIC_DAY	4	14400	f	2010-11-18	111404	\N	116245	\N
149508	GENERIC_DAY	4	10800	f	2010-11-17	111404	\N	116245	\N
149502	GENERIC_DAY	4	0	f	2010-11-13	111406	\N	116245	\N
149503	GENERIC_DAY	4	7200	f	2010-11-17	111406	\N	116245	\N
104900	GENERIC_DAY	2	7200	f	2010-07-29	4344	\N	104235	\N
104901	GENERIC_DAY	2	7200	f	2010-08-03	4348	\N	104235	\N
104902	GENERIC_DAY	2	7200	f	2010-08-02	4348	\N	104235	\N
104903	GENERIC_DAY	2	7200	f	2010-07-21	4344	\N	104235	\N
104904	GENERIC_DAY	2	7200	f	2010-08-05	4350	\N	104235	\N
104905	GENERIC_DAY	2	0	f	2010-08-08	4358	\N	104235	\N
104906	GENERIC_DAY	2	7200	f	2010-08-06	4350	\N	104235	\N
104907	GENERIC_DAY	2	0	f	2010-08-08	4344	\N	104235	\N
104908	GENERIC_DAY	2	7200	f	2010-07-21	4348	\N	104235	\N
104909	GENERIC_DAY	2	7200	f	2010-07-19	4350	\N	104235	\N
104910	GENERIC_DAY	2	7200	f	2010-08-04	4350	\N	104235	\N
104911	GENERIC_DAY	2	7200	f	2010-08-09	4348	\N	104235	\N
104912	GENERIC_DAY	2	0	f	2010-08-01	4358	\N	104235	\N
104913	GENERIC_DAY	2	0	f	2010-07-25	4344	\N	104235	\N
104914	GENERIC_DAY	2	0	f	2010-08-07	4358	\N	104235	\N
104915	GENERIC_DAY	2	7200	f	2010-07-27	4344	\N	104235	\N
104916	GENERIC_DAY	2	7200	f	2010-07-23	4344	\N	104235	\N
104917	GENERIC_DAY	2	7200	f	2010-07-23	4348	\N	104235	\N
104918	GENERIC_DAY	2	7200	f	2010-07-28	4350	\N	104235	\N
104919	GENERIC_DAY	2	7200	f	2010-07-23	4358	\N	104235	\N
104920	GENERIC_DAY	2	7200	f	2010-07-21	4350	\N	104235	\N
104921	GENERIC_DAY	2	7200	f	2010-08-03	4344	\N	104235	\N
104922	GENERIC_DAY	2	7200	f	2010-07-30	4350	\N	104235	\N
104923	GENERIC_DAY	2	7200	f	2010-08-02	4358	\N	104235	\N
105200	GENERIC_DAY	2	0	f	2010-07-11	4348	\N	104237	\N
105201	GENERIC_DAY	2	7200	f	2010-07-22	4348	\N	104237	\N
105202	GENERIC_DAY	2	7200	f	2010-07-12	4344	\N	104237	\N
105203	GENERIC_DAY	2	7200	f	2010-07-22	4344	\N	104237	\N
105204	GENERIC_DAY	2	0	f	2010-07-17	4350	\N	104237	\N
105205	GENERIC_DAY	2	10800	f	2010-07-28	4348	\N	104237	\N
105206	GENERIC_DAY	2	7200	f	2010-07-21	4348	\N	104237	\N
107930	GENERIC_DAY	2	21600	f	2010-07-08	4350	\N	106455	\N
107944	GENERIC_DAY	2	0	f	2010-07-11	4350	\N	106455	\N
107909	GENERIC_DAY	2	0	f	2010-07-10	4358	\N	106455	\N
107919	GENERIC_DAY	2	28800	f	2010-07-06	4350	\N	106455	\N
107929	GENERIC_DAY	2	25200	f	2010-07-08	4358	\N	106455	\N
107917	GENERIC_DAY	2	21600	f	2010-07-07	4344	\N	106455	\N
107924	GENERIC_DAY	2	21600	f	2010-07-08	4348	\N	106455	\N
107936	GENERIC_DAY	2	0	f	2010-07-10	4344	\N	106455	\N
107939	GENERIC_DAY	2	25200	f	2010-07-07	4358	\N	106455	\N
107933	GENERIC_DAY	2	21600	f	2010-07-09	21817	\N	106455	\N
107912	GENERIC_DAY	2	32400	f	2010-07-12	107364	\N	106455	\N
107908	GENERIC_DAY	2	21600	f	2010-07-07	4348	\N	106455	\N
107922	GENERIC_DAY	2	28800	f	2010-07-06	4344	\N	106455	\N
107935	GENERIC_DAY	2	21600	f	2010-07-12	4350	\N	106455	\N
107911	GENERIC_DAY	2	21600	f	2010-07-12	4344	\N	106455	\N
107920	GENERIC_DAY	2	0	f	2010-07-11	4358	\N	106455	\N
107934	GENERIC_DAY	2	21600	f	2010-07-12	21817	\N	106455	\N
107945	GENERIC_DAY	2	28800	f	2010-07-06	4358	\N	106455	\N
107914	GENERIC_DAY	2	0	f	2010-07-11	21817	\N	106455	\N
107923	GENERIC_DAY	2	0	f	2010-07-10	107364	\N	106455	\N
107946	GENERIC_DAY	2	21600	f	2010-07-07	21817	\N	106455	\N
107918	GENERIC_DAY	2	25200	f	2010-07-08	21817	\N	106455	\N
107913	GENERIC_DAY	2	21600	f	2010-07-09	4350	\N	106455	\N
107921	GENERIC_DAY	2	28800	f	2010-07-06	4348	\N	106455	\N
107926	GENERIC_DAY	2	18000	f	2010-07-08	4344	\N	106455	\N
107910	GENERIC_DAY	2	0	f	2010-07-11	107364	\N	106455	\N
107927	GENERIC_DAY	2	0	f	2010-07-11	4348	\N	106455	\N
107928	GENERIC_DAY	2	21600	f	2010-07-12	4348	\N	106455	\N
107938	GENERIC_DAY	2	21600	f	2010-07-09	4344	\N	106455	\N
107915	GENERIC_DAY	2	32400	f	2010-07-07	107364	\N	106455	\N
107925	GENERIC_DAY	2	21600	f	2010-07-07	4350	\N	106455	\N
107937	GENERIC_DAY	2	25200	f	2010-07-09	4358	\N	106455	\N
107916	GENERIC_DAY	2	32400	f	2010-07-08	107364	\N	106455	\N
107932	GENERIC_DAY	2	0	f	2010-07-10	4350	\N	106455	\N
107943	GENERIC_DAY	2	32400	f	2010-07-09	107364	\N	106455	\N
107941	GENERIC_DAY	2	25200	f	2010-07-12	4358	\N	106455	\N
107942	GENERIC_DAY	2	0	f	2010-07-10	21817	\N	106455	\N
107931	GENERIC_DAY	2	0	f	2010-07-11	4344	\N	106455	\N
107940	GENERIC_DAY	2	21600	f	2010-07-09	4348	\N	106455	\N
107948	GENERIC_DAY	2	28800	f	2010-07-06	21817	\N	106455	\N
107947	GENERIC_DAY	2	0	f	2010-07-10	4348	\N	106455	\N
112110	GENERIC_DAY	9	3600	f	2010-09-13	111406	\N	112009	\N
112111	GENERIC_DAY	9	3600	f	2010-11-22	111406	\N	112009	\N
149913	GENERIC_DAY	1	3600	f	2011-01-05	111406	\N	116243	\N
149909	GENERIC_DAY	1	7200	f	2011-01-05	111404	\N	116243	\N
149916	GENERIC_DAY	1	3600	f	2011-01-18	111406	\N	116243	\N
149922	GENERIC_DAY	1	3600	f	2011-01-12	111406	\N	116243	\N
149903	GENERIC_DAY	1	7200	f	2011-01-03	111404	\N	116243	\N
149902	GENERIC_DAY	1	3600	f	2011-01-07	111404	\N	116243	\N
149915	GENERIC_DAY	1	3600	f	2010-12-31	111406	\N	116243	\N
149921	GENERIC_DAY	1	7200	f	2010-12-30	111404	\N	116243	\N
149900	GENERIC_DAY	1	7200	f	2011-01-04	111404	\N	116243	\N
149919	GENERIC_DAY	1	3600	f	2011-01-14	111404	\N	116243	\N
149907	GENERIC_DAY	1	3600	f	2011-01-13	111406	\N	116243	\N
149917	GENERIC_DAY	1	3600	f	2011-01-18	111404	\N	116243	\N
149923	GENERIC_DAY	1	3600	f	2011-01-03	111406	\N	116243	\N
149912	GENERIC_DAY	1	7200	f	2011-01-11	111404	\N	116243	\N
149901	GENERIC_DAY	1	3600	f	2011-01-13	111404	\N	116243	\N
149906	GENERIC_DAY	1	7200	f	2011-01-07	111406	\N	116243	\N
149914	GENERIC_DAY	1	3600	f	2011-01-10	111406	\N	116243	\N
149904	GENERIC_DAY	1	3600	f	2010-12-30	111406	\N	116243	\N
149908	GENERIC_DAY	1	7200	f	2010-12-31	111404	\N	116243	\N
149911	GENERIC_DAY	1	7200	f	2011-01-06	111406	\N	116243	\N
149910	GENERIC_DAY	1	3600	f	2011-01-04	111406	\N	116243	\N
149920	GENERIC_DAY	1	3600	f	2011-01-10	111404	\N	116243	\N
149924	GENERIC_DAY	1	3600	f	2011-01-06	111404	\N	116243	\N
149918	GENERIC_DAY	1	3600	f	2011-01-17	111404	\N	116243	\N
149926	GENERIC_DAY	1	3600	f	2011-01-12	111404	\N	116243	\N
149905	GENERIC_DAY	1	3600	f	2011-01-14	111406	\N	116243	\N
149925	GENERIC_DAY	1	3600	f	2011-01-17	111406	\N	116243	\N
149945	GENERIC_DAY	1	0	f	2011-01-22	111404	\N	128597	\N
128788	GENERIC_DAY	5	10800	f	2010-10-13	111404	\N	128587	\N
128784	GENERIC_DAY	5	14400	f	2010-10-14	111406	\N	128587	\N
128783	GENERIC_DAY	5	14400	f	2010-10-12	111406	\N	128587	\N
128787	GENERIC_DAY	5	10800	f	2010-10-14	111404	\N	128587	\N
128786	GENERIC_DAY	5	10800	f	2010-10-12	111404	\N	128587	\N
128785	GENERIC_DAY	5	14400	f	2010-10-13	111406	\N	128587	\N
128797	GENERIC_DAY	5	14400	f	2010-10-19	111406	\N	128588	\N
128793	GENERIC_DAY	5	0	f	2010-10-17	111404	\N	128588	\N
128792	GENERIC_DAY	5	10800	f	2010-10-15	111404	\N	128588	\N
128798	GENERIC_DAY	5	14400	f	2010-10-18	111406	\N	128588	\N
128791	GENERIC_DAY	5	0	f	2010-10-16	111406	\N	128588	\N
128795	GENERIC_DAY	5	10800	f	2010-10-18	111404	\N	128588	\N
128790	GENERIC_DAY	5	14400	f	2010-10-15	111406	\N	128588	\N
128794	GENERIC_DAY	5	0	f	2010-10-16	111404	\N	128588	\N
128796	GENERIC_DAY	5	10800	f	2010-10-19	111404	\N	128588	\N
128789	GENERIC_DAY	5	0	f	2010-10-17	111406	\N	128588	\N
128801	GENERIC_DAY	5	10800	f	2010-10-21	111406	\N	128589	\N
128800	GENERIC_DAY	5	10800	f	2010-10-20	111404	\N	128589	\N
128799	GENERIC_DAY	5	14400	f	2010-10-21	111404	\N	128589	\N
128802	GENERIC_DAY	5	14400	f	2010-10-22	111404	\N	128589	\N
128803	GENERIC_DAY	5	14400	f	2010-10-20	111406	\N	128589	\N
128804	GENERIC_DAY	5	10800	f	2010-10-22	111406	\N	128589	\N
128806	GENERIC_DAY	5	10800	f	2010-10-26	111406	\N	128590	\N
128810	GENERIC_DAY	5	10800	f	2010-10-27	111406	\N	128590	\N
128807	GENERIC_DAY	5	0	f	2010-10-23	111404	\N	128590	\N
128809	GENERIC_DAY	5	0	f	2010-10-23	111406	\N	128590	\N
128808	GENERIC_DAY	5	0	f	2010-10-24	111404	\N	128590	\N
128805	GENERIC_DAY	5	14400	f	2010-10-27	111404	\N	128590	\N
112146	GENERIC_DAY	9	3600	f	2010-11-19	111406	\N	112009	\N
112138	GENERIC_DAY	9	3600	f	2010-12-09	111406	\N	112009	\N
112113	GENERIC_DAY	9	3600	f	2010-10-19	111406	\N	112009	\N
112147	GENERIC_DAY	9	3600	f	2010-11-16	111406	\N	112009	\N
112115	GENERIC_DAY	9	3600	f	2011-01-04	111406	\N	112009	\N
112121	GENERIC_DAY	9	3600	f	2010-12-21	111406	\N	112009	\N
112131	GENERIC_DAY	9	3600	f	2010-11-18	111406	\N	112009	\N
112118	GENERIC_DAY	9	3600	f	2010-12-15	111406	\N	112009	\N
112145	GENERIC_DAY	9	3600	f	2010-10-25	111406	\N	112009	\N
112133	GENERIC_DAY	9	3600	f	2010-11-08	111406	\N	112009	\N
112123	GENERIC_DAY	9	3600	f	2010-09-24	111406	\N	112009	\N
112144	GENERIC_DAY	9	3600	f	2011-01-05	111406	\N	112009	\N
112129	GENERIC_DAY	9	3600	f	2010-09-02	111406	\N	112009	\N
112140	GENERIC_DAY	9	3600	f	2010-12-02	111406	\N	112009	\N
112112	GENERIC_DAY	9	3600	f	2010-12-17	111406	\N	112009	\N
112128	GENERIC_DAY	9	3600	f	2010-11-04	111406	\N	112009	\N
112124	GENERIC_DAY	9	3600	f	2010-09-28	111406	\N	112009	\N
112143	GENERIC_DAY	9	3600	f	2010-09-23	111406	\N	112009	\N
112130	GENERIC_DAY	9	3600	f	2010-11-02	111406	\N	112009	\N
112136	GENERIC_DAY	9	3600	f	2010-12-16	111406	\N	112009	\N
112125	GENERIC_DAY	9	3600	f	2010-11-10	111406	\N	112009	\N
112126	GENERIC_DAY	9	3600	f	2010-09-10	111406	\N	112009	\N
112127	GENERIC_DAY	9	3600	f	2010-10-08	111406	\N	112009	\N
112117	GENERIC_DAY	9	3600	f	2010-12-31	111406	\N	112009	\N
112135	GENERIC_DAY	9	3600	f	2010-12-27	111406	\N	112009	\N
112132	GENERIC_DAY	9	3600	f	2010-11-30	111406	\N	112009	\N
112141	GENERIC_DAY	9	3600	f	2010-09-08	111406	\N	112009	\N
112122	GENERIC_DAY	9	3600	f	2010-12-24	111406	\N	112009	\N
112137	GENERIC_DAY	9	3600	f	2010-09-06	111406	\N	112009	\N
112114	GENERIC_DAY	9	3600	f	2010-11-12	111406	\N	112009	\N
112142	GENERIC_DAY	9	3600	f	2010-11-03	111406	\N	112009	\N
112148	GENERIC_DAY	9	3600	f	2010-10-15	111406	\N	112009	\N
112139	GENERIC_DAY	9	3600	f	2010-09-21	111406	\N	112009	\N
112134	GENERIC_DAY	9	3600	f	2010-12-06	111406	\N	112009	\N
112116	GENERIC_DAY	9	3600	f	2010-10-29	111406	\N	112009	\N
112119	GENERIC_DAY	9	3600	f	2010-12-30	111406	\N	112009	\N
112120	GENERIC_DAY	9	3600	f	2010-11-15	111406	\N	112009	\N
149946	GENERIC_DAY	1	7200	f	2011-01-28	111406	\N	128597	\N
149454	GENERIC_DAY	4	0	f	2011-01-01	111404	\N	116244	\N
149485	GENERIC_DAY	4	3600	f	2011-01-17	111406	\N	116244	\N
149469	GENERIC_DAY	4	0	f	2011-01-15	111406	\N	116244	\N
149464	GENERIC_DAY	4	3600	f	2011-01-12	111406	\N	116244	\N
149492	GENERIC_DAY	4	3600	f	2011-01-05	111406	\N	116244	\N
149490	GENERIC_DAY	4	3600	f	2010-12-31	111406	\N	116244	\N
149467	GENERIC_DAY	4	10800	f	2011-01-03	111404	\N	116244	\N
149474	GENERIC_DAY	4	0	f	2011-01-16	111404	\N	116244	\N
149452	GENERIC_DAY	4	0	f	2011-01-02	111404	\N	116244	\N
149450	GENERIC_DAY	4	10800	f	2011-01-10	111404	\N	116244	\N
149458	GENERIC_DAY	4	10800	f	2010-12-30	111404	\N	116244	\N
149455	GENERIC_DAY	4	3600	f	2011-01-06	111406	\N	116244	\N
149491	GENERIC_DAY	4	0	f	2011-01-16	111406	\N	116244	\N
112169	GENERIC_DAY	9	3600	f	2010-12-14	111406	\N	112009	\N
112155	GENERIC_DAY	9	3600	f	2010-12-10	111406	\N	112009	\N
112152	GENERIC_DAY	9	3600	f	2010-10-04	111406	\N	112009	\N
112158	GENERIC_DAY	9	3600	f	2010-09-27	111406	\N	112009	\N
112161	GENERIC_DAY	9	3600	f	2010-09-20	111406	\N	112009	\N
112154	GENERIC_DAY	9	3600	f	2010-12-07	111406	\N	112009	\N
112165	GENERIC_DAY	9	3600	f	2010-09-07	111406	\N	112009	\N
112149	GENERIC_DAY	9	3600	f	2010-12-29	111406	\N	112009	\N
112150	GENERIC_DAY	9	3600	f	2010-09-17	111406	\N	112009	\N
112164	GENERIC_DAY	9	3600	f	2010-09-01	111406	\N	112009	\N
112168	GENERIC_DAY	9	3600	f	2010-11-05	111406	\N	112009	\N
112153	GENERIC_DAY	9	3600	f	2010-11-17	111406	\N	112009	\N
112156	GENERIC_DAY	9	3600	f	2010-09-22	111406	\N	112009	\N
112163	GENERIC_DAY	9	3600	f	2010-10-20	111406	\N	112009	\N
112167	GENERIC_DAY	9	3600	f	2010-12-13	111406	\N	112009	\N
112151	GENERIC_DAY	9	3600	f	2010-10-12	111406	\N	112009	\N
112166	GENERIC_DAY	9	3600	f	2010-09-03	111406	\N	112009	\N
112170	GENERIC_DAY	9	3600	f	2010-09-14	111406	\N	112009	\N
112160	GENERIC_DAY	9	3600	f	2010-12-22	111406	\N	112009	\N
112162	GENERIC_DAY	9	3600	f	2010-09-29	111406	\N	112009	\N
112157	GENERIC_DAY	9	3600	f	2010-12-03	111406	\N	112009	\N
112159	GENERIC_DAY	9	3600	f	2010-10-21	111406	\N	112009	\N
149382	GENERIC_DAY	4	0	f	2010-12-18	111404	\N	116241	\N
149384	GENERIC_DAY	4	0	f	2010-12-19	111404	\N	116241	\N
149381	GENERIC_DAY	4	14400	f	2010-12-22	111406	\N	116241	\N
149383	GENERIC_DAY	4	14400	f	2010-12-22	111404	\N	116241	\N
149386	GENERIC_DAY	4	7200	f	2010-12-24	111406	\N	116242	\N
149389	GENERIC_DAY	4	0	f	2010-12-25	111404	\N	116242	\N
149387	GENERIC_DAY	4	18000	f	2010-12-27	111404	\N	116242	\N
149393	GENERIC_DAY	4	0	f	2010-12-26	111404	\N	116242	\N
149390	GENERIC_DAY	4	0	f	2010-12-25	111406	\N	116242	\N
149388	GENERIC_DAY	4	10800	f	2010-12-28	111404	\N	116242	\N
149394	GENERIC_DAY	4	10800	f	2010-12-29	111404	\N	116242	\N
149392	GENERIC_DAY	4	0	f	2010-12-26	111406	\N	116242	\N
149385	GENERIC_DAY	4	18000	f	2010-12-24	111404	\N	116242	\N
149391	GENERIC_DAY	4	7200	f	2010-12-27	111406	\N	116242	\N
112213	GENERIC_DAY	9	3600	f	2010-11-23	111406	\N	112010	\N
112215	GENERIC_DAY	9	3600	f	2010-12-21	111406	\N	112010	\N
112214	GENERIC_DAY	9	3600	f	2010-09-15	111406	\N	112010	\N
112216	GENERIC_DAY	9	3600	f	2011-01-20	111406	\N	112010	\N
149289	GENERIC_DAY	4	10800	f	2010-09-27	111404	\N	116236	\N
149294	GENERIC_DAY	4	7200	f	2010-09-27	111406	\N	116236	\N
149288	GENERIC_DAY	4	7200	f	2010-09-16	111404	\N	116236	\N
149302	GENERIC_DAY	4	7200	f	2010-10-04	111406	\N	116237	\N
149299	GENERIC_DAY	4	7200	f	2010-09-29	111404	\N	116237	\N
149306	GENERIC_DAY	4	10800	f	2010-10-04	111404	\N	116237	\N
149304	GENERIC_DAY	4	0	f	2010-10-03	111406	\N	116237	\N
149305	GENERIC_DAY	4	0	f	2010-10-03	111404	\N	116237	\N
149300	GENERIC_DAY	4	0	f	2010-10-02	111406	\N	116237	\N
149301	GENERIC_DAY	4	10800	f	2010-10-07	111406	\N	116237	\N
149303	GENERIC_DAY	4	10800	f	2010-09-30	111406	\N	116237	\N
149338	GENERIC_DAY	4	14400	f	2010-10-14	111404	\N	116238	\N
149337	GENERIC_DAY	4	0	f	2010-10-09	111406	\N	116238	\N
149244	GENERIC_DAY	4	14400	f	2010-10-20	111404	\N	116235	\N
149235	GENERIC_DAY	4	10800	f	2010-10-29	111404	\N	116235	\N
149240	GENERIC_DAY	4	3600	f	2010-11-09	111406	\N	116235	\N
149234	GENERIC_DAY	4	0	f	2010-10-30	111406	\N	116235	\N
149246	GENERIC_DAY	4	7200	f	2010-11-10	111404	\N	116235	\N
149250	GENERIC_DAY	4	10800	f	2010-10-21	111404	\N	116235	\N
149241	GENERIC_DAY	4	0	f	2010-10-24	111406	\N	116235	\N
112183	GENERIC_DAY	9	3600	f	2010-11-23	111406	\N	112009	\N
112192	GENERIC_DAY	9	3600	f	2010-12-08	111406	\N	112009	\N
112189	GENERIC_DAY	9	3600	f	2010-10-01	111406	\N	112009	\N
112172	GENERIC_DAY	9	3600	f	2010-10-11	111406	\N	112009	\N
112177	GENERIC_DAY	9	3600	f	2010-11-11	111406	\N	112009	\N
112178	GENERIC_DAY	9	3600	f	2010-09-09	111406	\N	112009	\N
112181	GENERIC_DAY	9	3600	f	2010-11-26	111406	\N	112009	\N
112193	GENERIC_DAY	9	3600	f	2010-09-15	111406	\N	112009	\N
112194	GENERIC_DAY	9	3600	f	2010-09-16	111406	\N	112009	\N
112191	GENERIC_DAY	9	3600	f	2010-10-13	111406	\N	112009	\N
112184	GENERIC_DAY	9	3600	f	2010-11-09	111406	\N	112009	\N
112186	GENERIC_DAY	9	3600	f	2010-11-01	111406	\N	112009	\N
112187	GENERIC_DAY	9	3600	f	2010-09-30	111406	\N	112009	\N
112179	GENERIC_DAY	9	3600	f	2010-10-28	111406	\N	112009	\N
112175	GENERIC_DAY	9	3600	f	2010-12-23	111406	\N	112009	\N
112190	GENERIC_DAY	9	3600	f	2010-10-06	111406	\N	112009	\N
112174	GENERIC_DAY	9	3600	f	2010-12-01	111406	\N	112009	\N
112173	GENERIC_DAY	9	3600	f	2010-12-20	111406	\N	112009	\N
112188	GENERIC_DAY	9	3600	f	2010-10-05	111406	\N	112009	\N
112176	GENERIC_DAY	9	3600	f	2010-10-22	111406	\N	112009	\N
112171	GENERIC_DAY	9	3600	f	2010-11-24	111406	\N	112009	\N
112185	GENERIC_DAY	9	3600	f	2010-10-18	111406	\N	112009	\N
112180	GENERIC_DAY	9	3600	f	2010-11-25	111406	\N	112009	\N
112182	GENERIC_DAY	9	3600	f	2010-10-14	111406	\N	112009	\N
112298	GENERIC_DAY	9	3600	f	2010-10-01	111406	\N	112010	\N
112299	GENERIC_DAY	9	3600	f	2011-01-03	111406	\N	112010	\N
112304	GENERIC_DAY	9	3600	f	2010-10-21	111406	\N	112010	\N
112301	GENERIC_DAY	9	3600	f	2010-09-07	111406	\N	112010	\N
112303	GENERIC_DAY	9	3600	f	2010-10-28	111406	\N	112010	\N
112300	GENERIC_DAY	9	3600	f	2011-01-14	111406	\N	112010	\N
112302	GENERIC_DAY	9	3600	f	2011-01-25	111406	\N	112010	\N
128832	GENERIC_DAY	5	0	f	2010-11-06	111406	\N	128593	\N
128843	GENERIC_DAY	5	14400	f	2010-11-11	111406	\N	128594	\N
128841	GENERIC_DAY	5	14400	f	2010-11-12	111406	\N	128594	\N
128846	GENERIC_DAY	5	10800	f	2010-11-11	111404	\N	128594	\N
128845	GENERIC_DAY	5	10800	f	2010-11-10	111404	\N	128594	\N
128844	GENERIC_DAY	5	14400	f	2010-11-10	111406	\N	128594	\N
128842	GENERIC_DAY	5	10800	f	2010-11-12	111404	\N	128594	\N
151787	GENERIC_DAY	0	0	f	2010-12-05	111406	\N	128584	\N
151788	GENERIC_DAY	0	14400	f	2010-12-03	111404	\N	128584	\N
151789	GENERIC_DAY	0	0	f	2010-11-28	111404	\N	128584	\N
151790	GENERIC_DAY	0	10800	f	2010-11-30	111406	\N	128584	\N
151791	GENERIC_DAY	0	0	f	2010-12-04	111406	\N	128584	\N
151792	GENERIC_DAY	0	14400	f	2010-12-02	111406	\N	128584	\N
151793	GENERIC_DAY	0	0	f	2010-12-04	111404	\N	128584	\N
151794	GENERIC_DAY	0	14400	f	2010-12-03	111406	\N	128584	\N
151795	GENERIC_DAY	0	0	f	2010-11-28	111406	\N	128584	\N
151796	GENERIC_DAY	0	14400	f	2010-12-06	111406	\N	128584	\N
151797	GENERIC_DAY	0	14400	f	2010-12-01	111406	\N	128584	\N
151798	GENERIC_DAY	0	14400	f	2010-12-02	111404	\N	128584	\N
151799	GENERIC_DAY	0	18000	f	2010-11-29	111404	\N	128584	\N
151800	GENERIC_DAY	0	14400	f	2010-11-26	111404	\N	128584	\N
151801	GENERIC_DAY	0	14400	f	2010-11-26	111406	\N	128584	\N
151802	GENERIC_DAY	0	10800	f	2010-11-29	111406	\N	128584	\N
151803	GENERIC_DAY	0	14400	f	2010-12-06	111404	\N	128584	\N
151837	GENERIC_DAY	0	0	f	2010-11-21	111404	\N	151306	\N
151838	GENERIC_DAY	0	0	f	2010-11-14	111404	\N	151306	\N
151839	GENERIC_DAY	0	0	f	2010-11-13	111404	\N	151306	\N
151840	GENERIC_DAY	0	14400	f	2010-11-16	111406	\N	151306	\N
151841	GENERIC_DAY	0	0	f	2010-11-21	111406	\N	151306	\N
151842	GENERIC_DAY	0	14400	f	2010-11-24	111406	\N	151306	\N
151843	GENERIC_DAY	0	18000	f	2010-11-18	111406	\N	151306	\N
151844	GENERIC_DAY	0	14400	f	2010-11-17	111404	\N	151306	\N
151845	GENERIC_DAY	0	14400	f	2010-11-22	111404	\N	151306	\N
151846	GENERIC_DAY	0	0	f	2010-11-20	111404	\N	151306	\N
151847	GENERIC_DAY	0	14400	f	2010-11-23	111404	\N	151306	\N
151848	GENERIC_DAY	0	18000	f	2010-11-19	111406	\N	151306	\N
151849	GENERIC_DAY	0	0	f	2010-11-14	111406	\N	151306	\N
151850	GENERIC_DAY	0	0	f	2010-11-13	111406	\N	151306	\N
151851	GENERIC_DAY	0	10800	f	2010-11-18	111404	\N	151306	\N
151852	GENERIC_DAY	0	10800	f	2010-11-25	111406	\N	151306	\N
151853	GENERIC_DAY	0	14400	f	2010-11-24	111404	\N	151306	\N
151854	GENERIC_DAY	0	10800	f	2010-11-19	111404	\N	151306	\N
112493	GENERIC_DAY	7	0	f	2010-09-05	111404	\N	112012	\N
112494	GENERIC_DAY	7	0	f	2010-09-05	111406	\N	112012	\N
112492	GENERIC_DAY	7	10800	f	2010-09-01	111406	\N	112012	\N
112491	GENERIC_DAY	7	0	f	2010-09-04	111404	\N	112012	\N
112305	GENERIC_DAY	9	3600	f	2010-11-29	111406	\N	112010	\N
112495	GENERIC_DAY	7	0	f	2010-09-11	111404	\N	112013	\N
112511	GENERIC_DAY	7	18000	f	2010-09-10	111404	\N	112013	\N
112516	GENERIC_DAY	7	10800	f	2010-09-29	111406	\N	112013	\N
112514	GENERIC_DAY	7	18000	f	2010-09-24	111404	\N	112013	\N
112497	GENERIC_DAY	7	10800	f	2010-09-17	111406	\N	112013	\N
112496	GENERIC_DAY	7	0	f	2010-09-19	111406	\N	112013	\N
112504	GENERIC_DAY	7	10800	f	2010-09-14	111406	\N	112013	\N
112508	GENERIC_DAY	7	10800	f	2010-09-30	111406	\N	112013	\N
112513	GENERIC_DAY	7	18000	f	2010-09-17	111404	\N	112013	\N
112505	GENERIC_DAY	7	10800	f	2010-09-10	111406	\N	112013	\N
112515	GENERIC_DAY	7	18000	f	2010-09-22	111404	\N	112013	\N
112512	GENERIC_DAY	7	10800	f	2010-09-22	111406	\N	112013	\N
112507	GENERIC_DAY	7	10800	f	2010-09-13	111406	\N	112013	\N
112509	GENERIC_DAY	7	0	f	2010-09-12	111406	\N	112013	\N
112518	GENERIC_DAY	7	0	f	2010-09-19	111404	\N	112013	\N
112498	GENERIC_DAY	7	10800	f	2010-09-23	111406	\N	112013	\N
112503	GENERIC_DAY	7	14400	f	2010-10-01	111404	\N	112013	\N
112517	GENERIC_DAY	7	18000	f	2010-09-27	111404	\N	112013	\N
112499	GENERIC_DAY	7	0	f	2010-09-25	111406	\N	112013	\N
112510	GENERIC_DAY	7	18000	f	2010-09-30	111404	\N	112013	\N
112506	GENERIC_DAY	7	18000	f	2010-09-28	111404	\N	112013	\N
112501	GENERIC_DAY	7	7200	f	2010-10-01	111406	\N	112013	\N
112500	GENERIC_DAY	7	18000	f	2010-09-23	111404	\N	112013	\N
112502	GENERIC_DAY	7	0	f	2010-09-26	111406	\N	112013	\N
149274	GENERIC_DAY	4	3600	f	2010-09-28	111406	\N	116236	\N
149268	GENERIC_DAY	4	0	f	2010-09-12	111406	\N	116236	\N
149265	GENERIC_DAY	4	0	f	2010-09-26	111406	\N	116236	\N
149282	GENERIC_DAY	4	0	f	2010-09-11	111404	\N	116236	\N
149263	GENERIC_DAY	4	7200	f	2010-09-28	111404	\N	116236	\N
149261	GENERIC_DAY	4	0	f	2010-09-25	111404	\N	116236	\N
149273	GENERIC_DAY	4	10800	f	2010-09-23	111406	\N	116236	\N
149266	GENERIC_DAY	4	0	f	2010-09-12	111404	\N	116236	\N
149264	GENERIC_DAY	4	0	f	2010-09-18	111404	\N	116236	\N
149267	GENERIC_DAY	4	0	f	2010-09-26	111404	\N	116236	\N
149278	GENERIC_DAY	4	7200	f	2010-09-23	111404	\N	116236	\N
149270	GENERIC_DAY	4	0	f	2010-09-25	111406	\N	116236	\N
149281	GENERIC_DAY	4	10800	f	2010-09-14	111406	\N	116236	\N
149283	GENERIC_DAY	4	7200	f	2010-09-17	111404	\N	116236	\N
149269	GENERIC_DAY	4	10800	f	2010-09-15	111406	\N	116236	\N
149271	GENERIC_DAY	4	0	f	2010-09-19	111406	\N	116236	\N
149280	GENERIC_DAY	4	10800	f	2010-09-10	111406	\N	116236	\N
149262	GENERIC_DAY	4	10800	f	2010-09-16	111406	\N	116236	\N
149272	GENERIC_DAY	4	0	f	2010-09-11	111406	\N	116236	\N
149277	GENERIC_DAY	4	7200	f	2010-09-21	111404	\N	116236	\N
149275	GENERIC_DAY	4	7200	f	2010-09-14	111404	\N	116236	\N
149284	GENERIC_DAY	4	7200	f	2010-09-22	111404	\N	116236	\N
149276	GENERIC_DAY	4	0	f	2010-09-18	111406	\N	116236	\N
149279	GENERIC_DAY	4	7200	f	2010-09-15	111404	\N	116236	\N
149259	GENERIC_DAY	4	7200	f	2010-10-27	111406	\N	116235	\N
149256	GENERIC_DAY	4	7200	f	2010-11-03	111404	\N	116235	\N
149260	GENERIC_DAY	4	7200	f	2010-11-01	111406	\N	116235	\N
149258	GENERIC_DAY	4	3600	f	2010-10-20	111406	\N	116235	\N
149257	GENERIC_DAY	4	0	f	2010-10-31	111404	\N	116235	\N
149310	GENERIC_DAY	4	10800	f	2010-10-01	111406	\N	116237	\N
149312	GENERIC_DAY	4	7200	f	2010-10-01	111404	\N	116237	\N
149313	GENERIC_DAY	4	10800	f	2010-10-05	111404	\N	116237	\N
149314	GENERIC_DAY	4	7200	f	2010-10-06	111404	\N	116237	\N
149311	GENERIC_DAY	4	10800	f	2010-09-29	111406	\N	116237	\N
149309	GENERIC_DAY	4	7200	f	2010-09-30	111404	\N	116237	\N
149316	GENERIC_DAY	4	0	f	2010-10-02	111404	\N	116237	\N
149307	GENERIC_DAY	4	7200	f	2010-10-05	111406	\N	116237	\N
149315	GENERIC_DAY	4	7200	f	2010-10-07	111404	\N	116237	\N
149308	GENERIC_DAY	4	10800	f	2010-10-06	111406	\N	116237	\N
149326	GENERIC_DAY	4	0	f	2010-10-09	111404	\N	116238	\N
149317	GENERIC_DAY	4	0	f	2010-10-17	111404	\N	116238	\N
149331	GENERIC_DAY	4	0	f	2010-10-17	111406	\N	116238	\N
149330	GENERIC_DAY	4	14400	f	2010-10-08	111404	\N	116238	\N
149336	GENERIC_DAY	4	14400	f	2010-10-11	111404	\N	116238	\N
149327	GENERIC_DAY	4	3600	f	2010-10-11	111406	\N	116238	\N
149321	GENERIC_DAY	4	3600	f	2010-10-08	111406	\N	116238	\N
149328	GENERIC_DAY	4	7200	f	2010-10-18	111406	\N	116238	\N
149325	GENERIC_DAY	4	0	f	2010-10-10	111406	\N	116238	\N
149319	GENERIC_DAY	4	3600	f	2010-10-14	111406	\N	116238	\N
149323	GENERIC_DAY	4	0	f	2010-10-16	111406	\N	116238	\N
149320	GENERIC_DAY	4	0	f	2010-10-10	111404	\N	116238	\N
149332	GENERIC_DAY	4	0	f	2010-10-16	111404	\N	116238	\N
149335	GENERIC_DAY	4	10800	f	2010-10-15	111404	\N	116238	\N
149334	GENERIC_DAY	4	10800	f	2010-10-18	111404	\N	116238	\N
149318	GENERIC_DAY	4	3600	f	2010-10-12	111406	\N	116238	\N
149322	GENERIC_DAY	4	7200	f	2010-10-15	111406	\N	116238	\N
149324	GENERIC_DAY	4	14400	f	2010-10-12	111404	\N	116238	\N
149333	GENERIC_DAY	4	3600	f	2010-10-13	111406	\N	116238	\N
149329	GENERIC_DAY	4	14400	f	2010-10-13	111404	\N	116238	\N
149478	GENERIC_DAY	4	10800	f	2011-01-07	111404	\N	116244	\N
149480	GENERIC_DAY	4	3600	f	2011-01-13	111406	\N	116244	\N
149483	GENERIC_DAY	4	0	f	2011-01-09	111406	\N	116244	\N
149479	GENERIC_DAY	4	3600	f	2011-01-03	111406	\N	116244	\N
149481	GENERIC_DAY	4	3600	f	2011-01-07	111406	\N	116244	\N
149477	GENERIC_DAY	4	10800	f	2010-12-31	111404	\N	116244	\N
149482	GENERIC_DAY	4	10800	f	2011-01-14	111404	\N	116244	\N
149476	GENERIC_DAY	4	3600	f	2011-01-04	111406	\N	116244	\N
149484	GENERIC_DAY	4	10800	f	2011-01-04	111404	\N	116244	\N
149475	GENERIC_DAY	4	3600	f	2011-01-18	111406	\N	116244	\N
149222	GENERIC_DAY	4	0	f	2010-11-06	111406	\N	116235	\N
149221	GENERIC_DAY	4	7200	f	2010-10-26	111406	\N	116235	\N
149218	GENERIC_DAY	4	10800	f	2010-11-02	111404	\N	116235	\N
149224	GENERIC_DAY	4	0	f	2010-11-07	111404	\N	116235	\N
149216	GENERIC_DAY	4	10800	f	2010-11-03	111406	\N	116235	\N
149225	GENERIC_DAY	4	14400	f	2010-11-09	111404	\N	116235	\N
149226	GENERIC_DAY	4	0	f	2010-10-23	111406	\N	116235	\N
149219	GENERIC_DAY	4	10800	f	2010-10-22	111404	\N	116235	\N
149215	GENERIC_DAY	4	14400	f	2010-10-19	111404	\N	116235	\N
149217	GENERIC_DAY	4	7200	f	2010-11-04	111404	\N	116235	\N
149227	GENERIC_DAY	4	3600	f	2010-10-19	111406	\N	116235	\N
149223	GENERIC_DAY	4	7200	f	2010-11-10	111406	\N	116235	\N
149220	GENERIC_DAY	4	7200	f	2010-10-25	111406	\N	116235	\N
149232	GENERIC_DAY	4	7200	f	2010-11-05	111404	\N	116235	\N
149231	GENERIC_DAY	4	10800	f	2010-11-05	111406	\N	116235	\N
149229	GENERIC_DAY	4	7200	f	2010-10-28	111406	\N	116235	\N
149230	GENERIC_DAY	4	14400	f	2010-11-08	111404	\N	116235	\N
149228	GENERIC_DAY	4	7200	f	2010-10-29	111406	\N	116235	\N
2897	SPECIFIC_DAY	7	28800	f	2010-06-21	1216	2729	\N	\N
2895	SPECIFIC_DAY	7	0	f	2010-06-27	1216	2729	\N	\N
2882	SPECIFIC_DAY	7	28800	f	2010-06-15	1216	2729	\N	\N
2892	SPECIFIC_DAY	7	0	f	2010-06-13	1216	2729	\N	\N
2888	SPECIFIC_DAY	7	0	f	2010-06-20	1216	2729	\N	\N
2883	SPECIFIC_DAY	7	28800	f	2010-06-18	1216	2729	\N	\N
2884	SPECIFIC_DAY	7	0	f	2010-06-19	1216	2729	\N	\N
2890	SPECIFIC_DAY	7	14400	f	2010-06-30	1216	2729	\N	\N
2896	SPECIFIC_DAY	7	28800	f	2010-06-14	1216	2729	\N	\N
31447	SPECIFIC_DAY	0	28800	f	2010-08-03	4352	31212	\N	\N
31448	SPECIFIC_DAY	0	28800	f	2010-07-28	4352	31212	\N	\N
31449	SPECIFIC_DAY	0	0	f	2010-06-19	4352	31212	\N	\N
31450	SPECIFIC_DAY	0	28800	f	2010-07-19	4352	31212	\N	\N
31451	SPECIFIC_DAY	0	28800	f	2010-06-22	4352	31212	\N	\N
31452	SPECIFIC_DAY	0	28800	f	2010-07-07	4352	31212	\N	\N
31453	SPECIFIC_DAY	0	0	f	2010-07-11	4352	31212	\N	\N
31454	SPECIFIC_DAY	0	28800	f	2010-07-21	4352	31212	\N	\N
31455	SPECIFIC_DAY	0	28800	f	2010-07-12	4352	31212	\N	\N
31456	SPECIFIC_DAY	0	28800	f	2010-07-27	4352	31212	\N	\N
31457	SPECIFIC_DAY	0	28800	f	2010-06-29	4352	31212	\N	\N
31458	SPECIFIC_DAY	0	0	f	2010-07-03	4352	31212	\N	\N
31459	SPECIFIC_DAY	0	28800	f	2010-06-30	4352	31212	\N	\N
31460	SPECIFIC_DAY	0	28800	f	2010-07-26	4352	31212	\N	\N
31461	SPECIFIC_DAY	0	28800	f	2010-07-06	4352	31212	\N	\N
31462	SPECIFIC_DAY	0	28800	f	2010-06-25	4352	31212	\N	\N
31463	SPECIFIC_DAY	0	28800	f	2010-07-01	4352	31212	\N	\N
31464	SPECIFIC_DAY	0	28800	f	2010-07-09	4352	31212	\N	\N
31465	SPECIFIC_DAY	0	0	f	2010-06-13	4352	31212	\N	\N
31466	SPECIFIC_DAY	0	28800	f	2010-06-28	4352	31212	\N	\N
31467	SPECIFIC_DAY	0	0	f	2010-07-17	4352	31212	\N	\N
31468	SPECIFIC_DAY	0	28800	f	2010-06-18	4352	31212	\N	\N
31469	SPECIFIC_DAY	0	0	f	2010-07-18	4352	31212	\N	\N
31470	SPECIFIC_DAY	0	0	f	2010-06-27	4352	31212	\N	\N
31471	SPECIFIC_DAY	0	0	f	2010-08-01	4352	31212	\N	\N
31472	SPECIFIC_DAY	0	0	f	2010-07-25	4352	31212	\N	\N
31473	SPECIFIC_DAY	0	28800	f	2010-07-08	4352	31212	\N	\N
31474	SPECIFIC_DAY	0	28800	f	2010-07-15	4352	31212	\N	\N
31475	SPECIFIC_DAY	0	28800	f	2010-08-02	4352	31212	\N	\N
31476	SPECIFIC_DAY	0	28800	f	2010-06-16	4352	31212	\N	\N
31477	SPECIFIC_DAY	0	14400	f	2010-08-04	4352	31212	\N	\N
31478	SPECIFIC_DAY	0	0	f	2010-07-04	4352	31212	\N	\N
31479	SPECIFIC_DAY	0	0	f	2010-07-10	4352	31212	\N	\N
31480	SPECIFIC_DAY	0	28800	f	2010-07-13	4352	31212	\N	\N
31481	SPECIFIC_DAY	0	28800	f	2010-06-17	4352	31212	\N	\N
31482	SPECIFIC_DAY	0	28800	f	2010-07-02	4352	31212	\N	\N
31483	SPECIFIC_DAY	0	28800	f	2010-06-15	4352	31212	\N	\N
31484	SPECIFIC_DAY	0	0	f	2010-06-20	4352	31212	\N	\N
31485	SPECIFIC_DAY	0	28800	f	2010-06-14	4352	31212	\N	\N
31486	SPECIFIC_DAY	0	0	f	2010-07-31	4352	31212	\N	\N
31487	SPECIFIC_DAY	0	28800	f	2010-06-24	4352	31212	\N	\N
31488	SPECIFIC_DAY	0	28800	f	2010-07-05	4352	31212	\N	\N
31489	SPECIFIC_DAY	0	28800	f	2010-06-21	4352	31212	\N	\N
31490	SPECIFIC_DAY	0	28800	f	2010-06-23	4352	31212	\N	\N
31491	SPECIFIC_DAY	0	28800	f	2010-07-16	4352	31212	\N	\N
31492	SPECIFIC_DAY	0	0	f	2010-06-26	4352	31212	\N	\N
31493	SPECIFIC_DAY	0	28800	f	2010-07-20	4352	31212	\N	\N
31494	SPECIFIC_DAY	0	28800	f	2010-07-30	4352	31212	\N	\N
31495	SPECIFIC_DAY	0	28800	f	2010-07-22	4352	31212	\N	\N
31496	SPECIFIC_DAY	0	28800	f	2010-07-14	4352	31212	\N	\N
31497	SPECIFIC_DAY	0	28800	f	2010-07-23	4352	31212	\N	\N
31498	SPECIFIC_DAY	0	0	f	2010-07-24	4352	31212	\N	\N
31499	SPECIFIC_DAY	0	28800	f	2010-07-29	4352	31212	\N	\N
102369	GENERIC_DAY	1	0	f	2010-07-27	1216	\N	83243	\N
102370	GENERIC_DAY	1	3600	f	2010-07-29	21817	\N	83243	\N
102371	GENERIC_DAY	1	0	f	2010-07-25	4344	\N	83243	\N
102372	GENERIC_DAY	1	0	f	2010-07-22	4354	\N	83243	\N
102373	GENERIC_DAY	1	0	f	2010-07-29	4350	\N	83243	\N
102374	GENERIC_DAY	1	0	f	2010-07-24	72319	\N	83243	\N
102375	GENERIC_DAY	1	7200	f	2010-07-22	21817	\N	83243	\N
102376	GENERIC_DAY	1	7200	f	2010-07-23	4356	\N	83243	\N
102377	GENERIC_DAY	1	3600	f	2010-07-21	72319	\N	83243	\N
102378	GENERIC_DAY	1	0	f	2010-07-28	4352	\N	83243	\N
102379	GENERIC_DAY	1	0	f	2010-07-22	1216	\N	83243	\N
102380	GENERIC_DAY	1	7200	f	2010-07-28	21817	\N	83243	\N
102381	GENERIC_DAY	1	3600	f	2010-07-23	72319	\N	83243	\N
102382	GENERIC_DAY	1	3600	f	2010-07-28	72319	\N	83243	\N
102383	GENERIC_DAY	1	7200	f	2010-07-21	4356	\N	83243	\N
102384	GENERIC_DAY	1	0	f	2010-07-22	4344	\N	83243	\N
102385	GENERIC_DAY	1	7200	f	2010-07-22	4356	\N	83243	\N
102386	GENERIC_DAY	1	0	f	2010-07-29	4358	\N	83243	\N
102387	GENERIC_DAY	1	0	f	2010-07-24	72317	\N	83243	\N
102388	GENERIC_DAY	1	0	f	2010-07-25	72319	\N	83243	\N
102389	GENERIC_DAY	1	3600	f	2010-07-23	1214	\N	83243	\N
102390	GENERIC_DAY	1	3600	f	2010-07-22	72319	\N	83243	\N
102391	GENERIC_DAY	1	0	f	2010-07-24	4352	\N	83243	\N
102392	GENERIC_DAY	1	0	f	2010-07-21	4352	\N	83243	\N
102393	GENERIC_DAY	1	0	f	2010-07-25	4350	\N	83243	\N
102394	GENERIC_DAY	1	0	f	2010-07-21	4348	\N	83243	\N
102395	GENERIC_DAY	1	3600	f	2010-07-27	72321	\N	83243	\N
102396	GENERIC_DAY	1	0	f	2010-07-27	4352	\N	83243	\N
102397	GENERIC_DAY	1	0	f	2010-07-21	1216	\N	83243	\N
102398	GENERIC_DAY	1	0	f	2010-07-25	4354	\N	83243	\N
102399	GENERIC_DAY	1	0	f	2010-07-21	1220	\N	83243	\N
102400	GENERIC_DAY	1	0	f	2010-07-21	4354	\N	83243	\N
102401	GENERIC_DAY	1	0	f	2010-07-27	1220	\N	83243	\N
102402	GENERIC_DAY	1	0	f	2010-07-26	4352	\N	83243	\N
102403	GENERIC_DAY	1	0	f	2010-07-26	4350	\N	83243	\N
102404	GENERIC_DAY	1	0	f	2010-07-22	4348	\N	83243	\N
102405	GENERIC_DAY	1	7200	f	2010-07-26	4356	\N	83243	\N
102406	GENERIC_DAY	1	0	f	2010-07-24	21817	\N	83243	\N
27707	GENERIC_DAY	9	14400	f	2010-08-27	4354	\N	27075	\N
27688	GENERIC_DAY	9	0	f	2010-08-28	4352	\N	27075	\N
27697	GENERIC_DAY	9	14400	f	2010-08-04	4354	\N	27075	\N
27710	GENERIC_DAY	9	0	f	2010-09-04	4354	\N	27075	\N
27694	GENERIC_DAY	9	14400	f	2010-09-06	4352	\N	27075	\N
27687	GENERIC_DAY	9	14400	f	2010-08-20	4354	\N	27075	\N
27689	GENERIC_DAY	9	14400	f	2010-08-06	4354	\N	27075	\N
27700	GENERIC_DAY	9	14400	f	2010-08-31	4354	\N	27075	\N
27706	GENERIC_DAY	9	14400	f	2010-08-31	4352	\N	27075	\N
27685	GENERIC_DAY	9	14400	f	2010-08-11	4352	\N	27075	\N
27696	GENERIC_DAY	9	14400	f	2010-08-17	4352	\N	27075	\N
27712	GENERIC_DAY	9	14400	f	2010-08-27	4352	\N	27075	\N
27695	GENERIC_DAY	9	14400	f	2010-08-04	4352	\N	27075	\N
27703	GENERIC_DAY	9	14400	f	2010-08-03	4352	\N	27075	\N
27708	GENERIC_DAY	9	14400	f	2010-08-09	4354	\N	27075	\N
27709	GENERIC_DAY	9	14400	f	2010-09-01	4354	\N	27075	\N
27701	GENERIC_DAY	9	0	f	2010-08-08	4354	\N	27075	\N
27690	GENERIC_DAY	9	14400	f	2010-08-23	4354	\N	27075	\N
27702	GENERIC_DAY	9	14400	f	2010-08-10	4352	\N	27075	\N
27705	GENERIC_DAY	9	14400	f	2010-09-06	4354	\N	27075	\N
27686	GENERIC_DAY	9	14400	f	2010-08-25	4354	\N	27075	\N
27699	GENERIC_DAY	9	14400	f	2010-08-17	4354	\N	27075	\N
27692	GENERIC_DAY	9	14400	f	2010-08-13	4352	\N	27075	\N
27711	GENERIC_DAY	9	0	f	2010-09-04	4352	\N	27075	\N
27693	GENERIC_DAY	9	0	f	2010-08-29	4352	\N	27075	\N
27713	GENERIC_DAY	9	14400	f	2010-08-19	4354	\N	27075	\N
27714	GENERIC_DAY	9	14400	f	2010-08-16	4354	\N	27075	\N
27691	GENERIC_DAY	9	14400	f	2010-08-12	4354	\N	27075	\N
27704	GENERIC_DAY	9	14400	f	2010-08-18	4354	\N	27075	\N
27698	GENERIC_DAY	9	0	f	2010-09-05	4354	\N	27075	\N
4291	SPECIFIC_DAY	3	28800	f	2010-07-20	1220	2731	\N	\N
4287	SPECIFIC_DAY	3	28800	f	2010-07-30	1220	2731	\N	\N
4278	SPECIFIC_DAY	3	28800	f	2010-08-02	1220	2731	\N	\N
4277	SPECIFIC_DAY	3	0	f	2010-07-24	1220	2731	\N	\N
4290	SPECIFIC_DAY	3	28800	f	2010-07-26	1220	2731	\N	\N
4280	SPECIFIC_DAY	3	28800	f	2010-07-21	1220	2731	\N	\N
4281	SPECIFIC_DAY	3	0	f	2010-07-25	1220	2731	\N	\N
4292	SPECIFIC_DAY	3	0	f	2010-07-16	1220	2731	\N	\N
4285	SPECIFIC_DAY	3	28800	f	2010-08-03	1220	2731	\N	\N
4289	SPECIFIC_DAY	3	0	f	2010-07-17	1220	2731	\N	\N
4295	SPECIFIC_DAY	3	28800	f	2010-07-29	1220	2731	\N	\N
4286	SPECIFIC_DAY	3	28800	f	2010-07-19	1220	2731	\N	\N
4282	SPECIFIC_DAY	3	28800	f	2010-07-28	1220	2731	\N	\N
4276	SPECIFIC_DAY	3	28800	f	2010-07-27	1220	2731	\N	\N
2880	SPECIFIC_DAY	7	28800	f	2010-06-25	1216	2729	\N	\N
2894	SPECIFIC_DAY	7	28800	f	2010-06-29	1216	2729	\N	\N
2889	SPECIFIC_DAY	7	28800	f	2010-06-28	1216	2729	\N	\N
2886	SPECIFIC_DAY	7	28800	f	2010-06-22	1216	2729	\N	\N
2885	SPECIFIC_DAY	7	28800	f	2010-06-16	1216	2729	\N	\N
2887	SPECIFIC_DAY	7	28800	f	2010-06-17	1216	2729	\N	\N
2893	SPECIFIC_DAY	7	28800	f	2010-06-24	1216	2729	\N	\N
2891	SPECIFIC_DAY	7	28800	f	2010-06-23	1216	2729	\N	\N
2881	SPECIFIC_DAY	7	0	f	2010-06-26	1216	2729	\N	\N
4257	SPECIFIC_DAY	3	28800	f	2010-07-02	1220	2730	\N	\N
4244	SPECIFIC_DAY	3	0	f	2010-07-11	1220	2730	\N	\N
4253	SPECIFIC_DAY	3	28800	f	2010-07-14	1220	2730	\N	\N
4243	SPECIFIC_DAY	3	28800	f	2010-07-15	1220	2730	\N	\N
4254	SPECIFIC_DAY	3	28800	f	2010-07-07	1220	2730	\N	\N
4258	SPECIFIC_DAY	3	28800	f	2010-07-08	1220	2730	\N	\N
4256	SPECIFIC_DAY	3	28800	f	2010-07-06	1220	2730	\N	\N
4255	SPECIFIC_DAY	3	14400	f	2010-06-30	1220	2730	\N	\N
4242	SPECIFIC_DAY	3	0	f	2010-07-10	1220	2730	\N	\N
4252	SPECIFIC_DAY	3	28800	f	2010-07-13	1220	2730	\N	\N
4246	SPECIFIC_DAY	3	28800	f	2010-07-12	1220	2730	\N	\N
4248	SPECIFIC_DAY	3	0	f	2010-07-04	1220	2730	\N	\N
4251	SPECIFIC_DAY	3	28800	f	2010-07-01	1220	2730	\N	\N
4247	SPECIFIC_DAY	3	28800	f	2010-07-05	1220	2730	\N	\N
4250	SPECIFIC_DAY	3	0	f	2010-07-03	1220	2730	\N	\N
4249	SPECIFIC_DAY	3	28800	f	2010-07-09	1220	2730	\N	\N
4245	SPECIFIC_DAY	3	28800	f	2010-07-16	1220	2730	\N	\N
102407	GENERIC_DAY	1	0	f	2010-07-28	4344	\N	83243	\N
102408	GENERIC_DAY	1	0	f	2010-07-21	4350	\N	83243	\N
102409	GENERIC_DAY	1	0	f	2010-07-29	4352	\N	83243	\N
102410	GENERIC_DAY	1	3600	f	2010-07-22	72321	\N	83243	\N
102411	GENERIC_DAY	1	7200	f	2010-07-27	4356	\N	83243	\N
102412	GENERIC_DAY	1	0	f	2010-07-29	1214	\N	83243	\N
102413	GENERIC_DAY	1	3600	f	2010-07-21	72321	\N	83243	\N
102414	GENERIC_DAY	1	7200	f	2010-07-27	21817	\N	83243	\N
102415	GENERIC_DAY	1	0	f	2010-07-28	1220	\N	83243	\N
102416	GENERIC_DAY	1	0	f	2010-07-25	72317	\N	83243	\N
102417	GENERIC_DAY	1	0	f	2010-07-24	4344	\N	83243	\N
102418	GENERIC_DAY	1	0	f	2010-07-25	1214	\N	83243	\N
102419	GENERIC_DAY	1	0	f	2010-07-24	72321	\N	83243	\N
102420	GENERIC_DAY	1	3600	f	2010-07-26	72317	\N	83243	\N
102421	GENERIC_DAY	1	0	f	2010-07-25	21817	\N	83243	\N
102422	GENERIC_DAY	1	0	f	2010-07-28	4358	\N	83243	\N
102423	GENERIC_DAY	1	0	f	2010-07-25	4356	\N	83243	\N
102424	GENERIC_DAY	1	3600	f	2010-07-26	72321	\N	83243	\N
102425	GENERIC_DAY	1	0	f	2010-07-29	72317	\N	83243	\N
102426	GENERIC_DAY	1	0	f	2010-07-28	4350	\N	83243	\N
102427	GENERIC_DAY	1	0	f	2010-07-26	1216	\N	83243	\N
102428	GENERIC_DAY	1	3600	f	2010-07-29	4356	\N	83243	\N
102429	GENERIC_DAY	1	0	f	2010-07-25	4352	\N	83243	\N
102430	GENERIC_DAY	1	3600	f	2010-07-28	1214	\N	83243	\N
102431	GENERIC_DAY	1	3600	f	2010-07-26	72319	\N	83243	\N
102432	GENERIC_DAY	1	0	f	2010-07-25	4358	\N	83243	\N
102433	GENERIC_DAY	1	0	f	2010-07-23	4354	\N	83243	\N
102434	GENERIC_DAY	1	0	f	2010-07-27	4350	\N	83243	\N
102435	GENERIC_DAY	1	0	f	2010-07-26	4348	\N	83243	\N
102436	GENERIC_DAY	1	0	f	2010-07-26	1220	\N	83243	\N
102437	GENERIC_DAY	1	0	f	2010-07-29	4354	\N	83243	\N
102438	GENERIC_DAY	1	3600	f	2010-07-23	72317	\N	83243	\N
102439	GENERIC_DAY	1	0	f	2010-07-26	4354	\N	83243	\N
102440	GENERIC_DAY	1	3600	f	2010-07-21	1214	\N	83243	\N
102441	GENERIC_DAY	1	0	f	2010-07-23	1220	\N	83243	\N
102442	GENERIC_DAY	1	0	f	2010-07-27	4358	\N	83243	\N
27476	GENERIC_DAY	9	0	f	2010-08-01	4352	\N	27071	\N
27486	GENERIC_DAY	9	14400	f	2010-07-23	4354	\N	27071	\N
27494	GENERIC_DAY	9	14400	f	2010-07-29	4352	\N	27071	\N
4288	SPECIFIC_DAY	3	28800	f	2010-07-23	1220	2731	\N	\N
4294	SPECIFIC_DAY	3	0	f	2010-08-01	1220	2731	\N	\N
4279	SPECIFIC_DAY	3	14400	f	2010-08-04	1220	2731	\N	\N
4284	SPECIFIC_DAY	3	0	f	2010-07-18	1220	2731	\N	\N
4283	SPECIFIC_DAY	3	28800	f	2010-07-22	1220	2731	\N	\N
4293	SPECIFIC_DAY	3	0	f	2010-07-31	1220	2731	\N	\N
102443	GENERIC_DAY	1	0	f	2010-07-24	4348	\N	83243	\N
102444	GENERIC_DAY	1	0	f	2010-07-23	1216	\N	83243	\N
102445	GENERIC_DAY	1	3600	f	2010-07-22	72317	\N	83243	\N
102446	GENERIC_DAY	1	0	f	2010-07-23	4350	\N	83243	\N
102447	GENERIC_DAY	1	0	f	2010-07-23	4344	\N	83243	\N
102448	GENERIC_DAY	1	3600	f	2010-07-27	72317	\N	83243	\N
102449	GENERIC_DAY	1	0	f	2010-07-29	4344	\N	83243	\N
102450	GENERIC_DAY	1	0	f	2010-07-24	1214	\N	83243	\N
102451	GENERIC_DAY	1	0	f	2010-07-29	1216	\N	83243	\N
102452	GENERIC_DAY	1	0	f	2010-07-27	4348	\N	83243	\N
102453	GENERIC_DAY	1	3600	f	2010-07-28	72321	\N	83243	\N
102454	GENERIC_DAY	1	0	f	2010-07-26	4358	\N	83243	\N
27598	GENERIC_DAY	9	7200	f	2010-08-13	4350	\N	27074	\N
27592	GENERIC_DAY	9	7200	f	2010-08-03	4348	\N	27074	\N
27586	GENERIC_DAY	9	0	f	2010-08-14	4350	\N	27074	\N
27627	GENERIC_DAY	9	0	f	2010-08-15	4350	\N	27074	\N
27624	GENERIC_DAY	9	7200	f	2010-08-18	4344	\N	27074	\N
27648	GENERIC_DAY	9	7200	f	2010-08-12	4358	\N	27074	\N
27622	GENERIC_DAY	9	7200	f	2010-08-19	4344	\N	27074	\N
27606	GENERIC_DAY	9	7200	f	2010-08-24	4350	\N	27074	\N
27663	GENERIC_DAY	9	7200	f	2010-08-19	4350	\N	27074	\N
27589	GENERIC_DAY	9	0	f	2010-08-07	4358	\N	27074	\N
102455	GENERIC_DAY	1	0	f	2010-07-22	4350	\N	83243	\N
102456	GENERIC_DAY	1	0	f	2010-07-25	1220	\N	83243	\N
102457	GENERIC_DAY	1	0	f	2010-07-24	4350	\N	83243	\N
102458	GENERIC_DAY	1	3600	f	2010-07-23	72321	\N	83243	\N
102459	GENERIC_DAY	1	0	f	2010-07-25	1216	\N	83243	\N
102460	GENERIC_DAY	1	0	f	2010-07-23	4352	\N	83243	\N
102461	GENERIC_DAY	1	7200	f	2010-07-21	21817	\N	83243	\N
102462	GENERIC_DAY	1	0	f	2010-07-21	4358	\N	83243	\N
102463	GENERIC_DAY	1	3600	f	2010-07-26	1214	\N	83243	\N
102464	GENERIC_DAY	1	0	f	2010-07-22	4352	\N	83243	\N
102465	GENERIC_DAY	1	3600	f	2010-07-28	72317	\N	83243	\N
102466	GENERIC_DAY	1	0	f	2010-07-24	4358	\N	83243	\N
102467	GENERIC_DAY	1	0	f	2010-07-29	1220	\N	83243	\N
102468	GENERIC_DAY	1	7200	f	2010-07-23	21817	\N	83243	\N
102469	GENERIC_DAY	1	0	f	2010-07-23	4348	\N	83243	\N
102470	GENERIC_DAY	1	7200	f	2010-07-28	4356	\N	83243	\N
102471	GENERIC_DAY	1	0	f	2010-07-22	1220	\N	83243	\N
102472	GENERIC_DAY	1	3600	f	2010-07-27	1214	\N	83243	\N
102473	GENERIC_DAY	1	0	f	2010-07-29	4348	\N	83243	\N
102474	GENERIC_DAY	1	0	f	2010-07-24	1220	\N	83243	\N
102475	GENERIC_DAY	1	0	f	2010-07-24	4356	\N	83243	\N
102476	GENERIC_DAY	1	3600	f	2010-07-22	1214	\N	83243	\N
37239	GENERIC_DAY	0	7200	f	2010-11-19	4348	\N	27138	\N
37240	GENERIC_DAY	0	7200	f	2010-12-03	4348	\N	27138	\N
37241	GENERIC_DAY	0	0	f	2010-11-20	4350	\N	27138	\N
37242	GENERIC_DAY	0	7200	f	2010-11-10	4350	\N	27138	\N
37243	GENERIC_DAY	0	0	f	2010-12-04	4344	\N	27138	\N
37244	GENERIC_DAY	0	7200	f	2010-11-26	4350	\N	27138	\N
37245	GENERIC_DAY	0	0	f	2010-12-12	4350	\N	27138	\N
37246	GENERIC_DAY	0	7200	f	2010-11-23	4350	\N	27138	\N
37247	GENERIC_DAY	0	7200	f	2010-11-12	4344	\N	27138	\N
37248	GENERIC_DAY	0	7200	f	2010-11-30	4358	\N	27138	\N
37249	GENERIC_DAY	0	7200	f	2010-11-23	4344	\N	27138	\N
37250	GENERIC_DAY	0	7200	f	2010-12-13	4344	\N	27138	\N
37251	GENERIC_DAY	0	0	f	2010-12-11	4344	\N	27138	\N
37252	GENERIC_DAY	0	7200	f	2010-12-02	4358	\N	27138	\N
37253	GENERIC_DAY	0	7200	f	2010-11-22	4350	\N	27138	\N
37254	GENERIC_DAY	0	7200	f	2010-11-10	4348	\N	27138	\N
37255	GENERIC_DAY	0	7200	f	2010-11-18	4348	\N	27138	\N
102477	GENERIC_DAY	1	0	f	2010-07-28	4348	\N	83243	\N
102478	GENERIC_DAY	1	0	f	2010-07-23	4358	\N	83243	\N
102479	GENERIC_DAY	1	0	f	2010-07-25	4348	\N	83243	\N
102480	GENERIC_DAY	1	0	f	2010-07-24	1216	\N	83243	\N
102481	GENERIC_DAY	1	0	f	2010-07-28	4354	\N	83243	\N
102482	GENERIC_DAY	1	0	f	2010-07-29	72321	\N	83243	\N
102483	GENERIC_DAY	1	0	f	2010-07-27	4354	\N	83243	\N
102484	GENERIC_DAY	1	3600	f	2010-07-27	72319	\N	83243	\N
102485	GENERIC_DAY	1	7200	f	2010-07-26	21817	\N	83243	\N
102486	GENERIC_DAY	1	0	f	2010-07-22	4358	\N	83243	\N
102487	GENERIC_DAY	1	0	f	2010-07-27	4344	\N	83243	\N
102488	GENERIC_DAY	1	0	f	2010-07-21	4344	\N	83243	\N
27632	GENERIC_DAY	9	7200	f	2010-08-09	4348	\N	27074	\N
102489	GENERIC_DAY	1	0	f	2010-07-29	72319	\N	83243	\N
102490	GENERIC_DAY	1	0	f	2010-07-25	72321	\N	83243	\N
102491	GENERIC_DAY	1	0	f	2010-07-26	4344	\N	83243	\N
102492	GENERIC_DAY	1	0	f	2010-07-28	1216	\N	83243	\N
102493	GENERIC_DAY	1	3600	f	2010-07-21	72317	\N	83243	\N
102494	GENERIC_DAY	1	0	f	2010-07-24	4354	\N	83243	\N
6300	GENERIC_DAY	18	14400	t	2010-06-22	4352	\N	5962	\N
6499	GENERIC_DAY	16	18000	f	2010-07-08	4354	\N	5962	\N
6328	GENERIC_DAY	18	0	t	2010-06-19	4354	\N	5962	\N
6303	GENERIC_DAY	18	14400	t	2010-06-21	4352	\N	5962	\N
6502	GENERIC_DAY	16	18000	f	2010-06-30	4354	\N	5962	\N
6506	GENERIC_DAY	16	14400	f	2010-07-06	4352	\N	5962	\N
6306	GENERIC_DAY	18	14400	t	2010-06-21	4354	\N	5962	\N
6339	GENERIC_DAY	18	14400	t	2010-06-18	4352	\N	5962	\N
6291	GENERIC_DAY	18	14400	t	2010-06-15	4354	\N	5962	\N
6527	GENERIC_DAY	16	3600	f	2010-07-11	4354	\N	5962	\N
6512	GENERIC_DAY	16	3600	f	2010-07-10	4354	\N	5962	\N
6501	GENERIC_DAY	16	18000	f	2010-07-09	4354	\N	5962	\N
6346	GENERIC_DAY	18	14400	t	2010-06-25	4354	\N	5962	\N
6508	GENERIC_DAY	16	18000	f	2010-07-02	4352	\N	5962	\N
6309	GENERIC_DAY	18	14400	t	2010-06-17	4354	\N	5962	\N
6324	GENERIC_DAY	18	14400	t	2010-06-22	4354	\N	5962	\N
6510	GENERIC_DAY	16	3600	f	2010-07-03	4354	\N	5962	\N
6532	GENERIC_DAY	16	18000	f	2010-07-07	4354	\N	5962	\N
6299	GENERIC_DAY	18	14400	t	2010-06-25	4352	\N	5962	\N
6509	GENERIC_DAY	16	18000	f	2010-07-05	4354	\N	5962	\N
6533	GENERIC_DAY	16	18000	f	2010-06-28	4352	\N	5962	\N
6525	GENERIC_DAY	16	18000	f	2010-07-16	4354	\N	5962	\N
6530	GENERIC_DAY	16	14400	f	2010-07-08	4352	\N	5962	\N
6281	GENERIC_DAY	18	0	t	2010-06-20	4354	\N	5962	\N
6514	GENERIC_DAY	16	18000	f	2010-07-01	4354	\N	5962	\N
6288	GENERIC_DAY	18	14400	t	2010-06-23	4352	\N	5962	\N
27645	GENERIC_DAY	9	7200	f	2010-08-19	4348	\N	27074	\N
27653	GENERIC_DAY	9	7200	f	2010-08-16	4348	\N	27074	\N
27581	GENERIC_DAY	9	7200	f	2010-08-23	4358	\N	27074	\N
27631	GENERIC_DAY	9	7200	f	2010-08-04	4344	\N	27074	\N
27587	GENERIC_DAY	9	7200	f	2010-08-17	4348	\N	27074	\N
37285	GENERIC_DAY	0	14400	f	2010-09-20	4352	\N	27139	\N
37286	GENERIC_DAY	0	14400	f	2010-10-11	4352	\N	27139	\N
37287	GENERIC_DAY	0	14400	f	2010-09-27	4354	\N	27139	\N
37288	GENERIC_DAY	0	0	f	2010-09-26	4352	\N	27139	\N
37289	GENERIC_DAY	0	14400	f	2010-09-16	4354	\N	27139	\N
37290	GENERIC_DAY	0	14400	f	2010-09-22	4354	\N	27139	\N
6535	GENERIC_DAY	16	3600	f	2010-07-17	4354	\N	5962	\N
6325	GENERIC_DAY	18	28800	t	2010-06-14	4354	\N	5962	\N
6503	GENERIC_DAY	16	18000	f	2010-07-01	4352	\N	5962	\N
27585	GENERIC_DAY	9	7200	f	2010-08-06	4358	\N	27074	\N
13235	SPECIFIC_DAY	2	0	f	2010-06-19	4350	8082	\N	\N
13252	SPECIFIC_DAY	2	28800	f	2010-06-15	4350	8082	\N	\N
13232	SPECIFIC_DAY	2	28800	f	2010-06-28	4350	8082	\N	\N
13244	SPECIFIC_DAY	2	0	f	2010-06-27	4350	8082	\N	\N
13251	SPECIFIC_DAY	2	0	f	2010-06-20	4350	8082	\N	\N
13248	SPECIFIC_DAY	2	28800	f	2010-06-29	4350	8082	\N	\N
13240	SPECIFIC_DAY	2	28800	f	2010-07-01	4350	8082	\N	\N
13249	SPECIFIC_DAY	2	28800	f	2010-06-17	4350	8082	\N	\N
13243	SPECIFIC_DAY	2	28800	f	2010-07-05	4350	8082	\N	\N
13247	SPECIFIC_DAY	2	0	f	2010-07-03	4350	8082	\N	\N
13246	SPECIFIC_DAY	2	21600	f	2010-07-08	4350	8082	\N	\N
13237	SPECIFIC_DAY	2	28800	f	2010-06-25	4350	8082	\N	\N
13250	SPECIFIC_DAY	2	28800	f	2010-06-21	4350	8082	\N	\N
13233	SPECIFIC_DAY	2	28800	f	2010-07-07	4350	8082	\N	\N
13245	SPECIFIC_DAY	2	28800	f	2010-06-23	4350	8082	\N	\N
13236	SPECIFIC_DAY	2	28800	f	2010-06-24	4350	8082	\N	\N
13238	SPECIFIC_DAY	2	28800	f	2010-06-22	4350	8082	\N	\N
13239	SPECIFIC_DAY	2	28800	f	2010-07-02	4350	8082	\N	\N
13231	SPECIFIC_DAY	2	28800	f	2010-06-14	4350	8082	\N	\N
13242	SPECIFIC_DAY	2	28800	f	2010-07-06	4350	8082	\N	\N
13241	SPECIFIC_DAY	2	0	f	2010-06-26	4350	8082	\N	\N
13230	SPECIFIC_DAY	2	0	f	2010-07-04	4350	8082	\N	\N
13234	SPECIFIC_DAY	2	28800	f	2010-06-18	4350	8082	\N	\N
13229	SPECIFIC_DAY	2	28800	f	2010-06-16	4350	8082	\N	\N
8200	SPECIFIC_DAY	14	0	f	2010-07-04	1216	8080	\N	\N
8193	SPECIFIC_DAY	14	28800	f	2010-07-06	1216	8080	\N	\N
8191	SPECIFIC_DAY	14	0	f	2010-07-17	1216	8080	\N	\N
8188	SPECIFIC_DAY	14	0	f	2010-07-03	1216	8080	\N	\N
8199	SPECIFIC_DAY	14	28800	f	2010-07-08	1216	8080	\N	\N
8183	SPECIFIC_DAY	14	0	f	2010-07-18	1216	8080	\N	\N
8190	SPECIFIC_DAY	14	28800	f	2010-07-15	1216	8080	\N	\N
8186	SPECIFIC_DAY	14	0	f	2010-07-11	1216	8080	\N	\N
8196	SPECIFIC_DAY	14	14400	f	2010-06-30	1216	8080	\N	\N
8195	SPECIFIC_DAY	14	0	f	2010-07-10	1216	8080	\N	\N
8198	SPECIFIC_DAY	14	28800	f	2010-07-16	1216	8080	\N	\N
8181	SPECIFIC_DAY	14	28800	f	2010-07-13	1216	8080	\N	\N
8184	SPECIFIC_DAY	14	28800	f	2010-07-09	1216	8080	\N	\N
8185	SPECIFIC_DAY	14	28800	f	2010-07-05	1216	8080	\N	\N
8192	SPECIFIC_DAY	14	3600	f	2010-07-19	1216	8080	\N	\N
8182	SPECIFIC_DAY	14	28800	f	2010-07-02	1216	8080	\N	\N
21697	GENERIC_DAY	4	7200	f	2010-07-29	4350	\N	16774	\N
21690	GENERIC_DAY	4	7200	f	2010-08-05	4344	\N	16774	\N
21686	GENERIC_DAY	4	7200	f	2010-08-17	4350	\N	16774	\N
21693	GENERIC_DAY	4	7200	f	2010-08-27	4344	\N	16774	\N
21684	GENERIC_DAY	4	0	f	2010-08-21	4348	\N	16774	\N
21685	GENERIC_DAY	4	7200	f	2010-08-12	4350	\N	16774	\N
21699	GENERIC_DAY	4	7200	f	2010-08-09	4344	\N	16774	\N
27484	GENERIC_DAY	9	14400	f	2010-07-23	4352	\N	27071	\N
27470	GENERIC_DAY	9	0	f	2010-07-18	4354	\N	27071	\N
27464	GENERIC_DAY	9	14400	f	2010-08-17	4352	\N	27071	\N
27454	GENERIC_DAY	9	14400	f	2010-08-06	4352	\N	27071	\N
27466	GENERIC_DAY	9	14400	f	2010-07-15	4352	\N	27071	\N
27492	GENERIC_DAY	9	0	f	2010-08-14	4354	\N	27071	\N
27473	GENERIC_DAY	9	0	f	2010-08-07	4352	\N	27071	\N
27471	GENERIC_DAY	9	14400	f	2010-07-28	4354	\N	27071	\N
27459	GENERIC_DAY	9	14400	f	2010-08-04	4354	\N	27071	\N
27448	GENERIC_DAY	9	14400	f	2010-08-11	4354	\N	27071	\N
27455	GENERIC_DAY	9	0	f	2010-07-25	4352	\N	27071	\N
27458	GENERIC_DAY	9	14400	f	2010-08-10	4354	\N	27071	\N
27465	GENERIC_DAY	9	0	f	2010-07-25	4354	\N	27071	\N
27463	GENERIC_DAY	9	0	f	2010-08-01	4354	\N	27071	\N
27461	GENERIC_DAY	9	14400	f	2010-08-13	4354	\N	27071	\N
27457	GENERIC_DAY	9	14400	f	2010-08-16	4352	\N	27071	\N
27715	GENERIC_DAY	9	0	f	2010-08-21	4354	\N	27075	\N
27684	GENERIC_DAY	9	14400	f	2010-08-23	4352	\N	27075	\N
27682	GENERIC_DAY	9	0	f	2010-08-08	4352	\N	27075	\N
27683	GENERIC_DAY	9	14400	f	2010-08-26	4352	\N	27075	\N
21700	GENERIC_DAY	4	0	f	2010-08-21	4350	\N	16774	\N
21704	GENERIC_DAY	4	7200	f	2010-08-27	4350	\N	16774	\N
21692	GENERIC_DAY	4	7200	f	2010-08-31	4358	\N	16774	\N
21698	GENERIC_DAY	4	0	f	2010-08-07	4348	\N	16774	\N
21695	GENERIC_DAY	4	7200	f	2010-08-20	4350	\N	16774	\N
21703	GENERIC_DAY	4	7200	f	2010-08-10	4358	\N	16774	\N
21691	GENERIC_DAY	4	7200	f	2010-08-13	4350	\N	16774	\N
21701	GENERIC_DAY	4	7200	f	2010-09-01	4358	\N	16774	\N
21689	GENERIC_DAY	4	0	f	2010-07-31	4350	\N	16774	\N
21702	GENERIC_DAY	4	0	f	2010-08-22	4358	\N	16774	\N
21688	GENERIC_DAY	4	0	f	2010-08-28	4344	\N	16774	\N
21696	GENERIC_DAY	4	7200	f	2010-08-26	4350	\N	16774	\N
21694	GENERIC_DAY	4	0	f	2010-08-08	4358	\N	16774	\N
21687	GENERIC_DAY	4	7200	f	2010-08-31	4348	\N	16774	\N
27436	GENERIC_DAY	9	14400	f	2010-07-27	4352	\N	27071	\N
27443	GENERIC_DAY	9	14400	f	2010-07-22	4354	\N	27071	\N
27439	GENERIC_DAY	9	14400	f	2010-08-16	4354	\N	27071	\N
27431	GENERIC_DAY	9	14400	f	2010-07-26	4354	\N	27071	\N
27432	GENERIC_DAY	9	14400	f	2010-07-22	4352	\N	27071	\N
27434	GENERIC_DAY	9	14400	f	2010-07-30	4354	\N	27071	\N
27438	GENERIC_DAY	9	14400	f	2010-07-20	4352	\N	27071	\N
27441	GENERIC_DAY	9	14400	f	2010-08-10	4352	\N	27071	\N
27429	GENERIC_DAY	9	0	f	2010-08-07	4354	\N	27071	\N
27430	GENERIC_DAY	9	0	f	2010-08-08	4354	\N	27071	\N
27444	GENERIC_DAY	9	14400	f	2010-07-28	4352	\N	27071	\N
27445	GENERIC_DAY	9	14400	f	2010-08-03	4354	\N	27071	\N
27435	GENERIC_DAY	9	14400	f	2010-07-16	4352	\N	27071	\N
27440	GENERIC_DAY	9	0	f	2010-08-15	4352	\N	27071	\N
27442	GENERIC_DAY	9	14400	f	2010-08-02	4352	\N	27071	\N
27433	GENERIC_DAY	9	14400	f	2010-07-26	4352	\N	27071	\N
27428	GENERIC_DAY	9	0	f	2010-07-31	4352	\N	27071	\N
27437	GENERIC_DAY	9	14400	f	2010-07-19	4354	\N	27071	\N
102495	GENERIC_DAY	1	0	f	2010-07-24	4348	\N	83244	\N
102496	GENERIC_DAY	1	0	f	2010-07-29	4354	\N	83244	\N
102497	GENERIC_DAY	1	0	f	2010-07-24	4358	\N	83244	\N
102498	GENERIC_DAY	1	3600	f	2010-07-29	21817	\N	83244	\N
102499	GENERIC_DAY	1	0	f	2010-07-21	1220	\N	83244	\N
102500	GENERIC_DAY	1	3600	f	2010-07-28	72321	\N	83244	\N
102501	GENERIC_DAY	1	0	f	2010-07-28	4352	\N	83244	\N
102502	GENERIC_DAY	1	0	f	2010-07-24	4344	\N	83244	\N
102503	GENERIC_DAY	1	0	f	2010-07-27	1216	\N	83244	\N
102504	GENERIC_DAY	1	3600	f	2010-07-23	72317	\N	83244	\N
102505	GENERIC_DAY	1	0	f	2010-07-24	1220	\N	83244	\N
102506	GENERIC_DAY	1	3600	f	2010-07-22	1214	\N	83244	\N
102507	GENERIC_DAY	1	0	f	2010-07-26	4352	\N	83244	\N
102508	GENERIC_DAY	1	0	f	2010-07-29	1216	\N	83244	\N
102509	GENERIC_DAY	1	0	f	2010-07-28	4348	\N	83244	\N
102510	GENERIC_DAY	1	3600	f	2010-07-27	72317	\N	83244	\N
102511	GENERIC_DAY	1	7200	f	2010-07-22	21817	\N	83244	\N
102512	GENERIC_DAY	1	0	f	2010-07-22	4350	\N	83244	\N
102513	GENERIC_DAY	1	0	f	2010-07-21	4354	\N	83244	\N
102514	GENERIC_DAY	1	3600	f	2010-07-29	4356	\N	83244	\N
102515	GENERIC_DAY	1	0	f	2010-07-22	4344	\N	83244	\N
102516	GENERIC_DAY	1	0	f	2010-07-24	1216	\N	83244	\N
102517	GENERIC_DAY	1	0	f	2010-07-21	1216	\N	83244	\N
102518	GENERIC_DAY	1	7200	f	2010-07-21	21817	\N	83244	\N
102519	GENERIC_DAY	1	0	f	2010-07-26	4348	\N	83244	\N
102520	GENERIC_DAY	1	0	f	2010-07-29	1220	\N	83244	\N
102521	GENERIC_DAY	1	7200	f	2010-07-26	4356	\N	83244	\N
102522	GENERIC_DAY	1	0	f	2010-07-29	4352	\N	83244	\N
102523	GENERIC_DAY	1	3600	f	2010-07-21	72319	\N	83244	\N
102524	GENERIC_DAY	1	0	f	2010-07-23	4348	\N	83244	\N
102525	GENERIC_DAY	1	0	f	2010-07-29	72317	\N	83244	\N
102526	GENERIC_DAY	1	0	f	2010-07-27	4344	\N	83244	\N
102527	GENERIC_DAY	1	0	f	2010-07-25	4354	\N	83244	\N
102528	GENERIC_DAY	1	0	f	2010-07-25	72321	\N	83244	\N
102529	GENERIC_DAY	1	7200	f	2010-07-23	21817	\N	83244	\N
102530	GENERIC_DAY	1	0	f	2010-07-25	1216	\N	83244	\N
102531	GENERIC_DAY	1	0	f	2010-07-24	72319	\N	83244	\N
102532	GENERIC_DAY	1	0	f	2010-07-24	1214	\N	83244	\N
102533	GENERIC_DAY	1	0	f	2010-07-28	4344	\N	83244	\N
102534	GENERIC_DAY	1	3600	f	2010-07-23	1214	\N	83244	\N
102535	GENERIC_DAY	1	7200	f	2010-07-28	4356	\N	83244	\N
102536	GENERIC_DAY	1	0	f	2010-07-23	4344	\N	83244	\N
102537	GENERIC_DAY	1	0	f	2010-07-21	4344	\N	83244	\N
102538	GENERIC_DAY	1	0	f	2010-07-27	4354	\N	83244	\N
102539	GENERIC_DAY	1	0	f	2010-07-22	1216	\N	83244	\N
102540	GENERIC_DAY	1	0	f	2010-07-27	4352	\N	83244	\N
102541	GENERIC_DAY	1	7200	f	2010-07-23	4356	\N	83244	\N
102542	GENERIC_DAY	1	0	f	2010-07-23	4354	\N	83244	\N
102543	GENERIC_DAY	1	0	f	2010-07-26	1220	\N	83244	\N
102544	GENERIC_DAY	1	0	f	2010-07-28	4354	\N	83244	\N
102545	GENERIC_DAY	1	0	f	2010-07-27	4350	\N	83244	\N
102546	GENERIC_DAY	1	0	f	2010-07-23	4352	\N	83244	\N
102547	GENERIC_DAY	1	0	f	2010-07-28	4358	\N	83244	\N
102548	GENERIC_DAY	1	3600	f	2010-07-28	72319	\N	83244	\N
102549	GENERIC_DAY	1	0	f	2010-07-22	4354	\N	83244	\N
102550	GENERIC_DAY	1	3600	f	2010-07-21	1214	\N	83244	\N
102551	GENERIC_DAY	1	3600	f	2010-07-28	72317	\N	83244	\N
102552	GENERIC_DAY	1	0	f	2010-07-25	4358	\N	83244	\N
102553	GENERIC_DAY	1	0	f	2010-07-22	4358	\N	83244	\N
102554	GENERIC_DAY	1	0	f	2010-07-27	1220	\N	83244	\N
102555	GENERIC_DAY	1	0	f	2010-07-27	4358	\N	83244	\N
102556	GENERIC_DAY	1	0	f	2010-07-29	72321	\N	83244	\N
102557	GENERIC_DAY	1	3600	f	2010-07-23	72319	\N	83244	\N
102558	GENERIC_DAY	1	0	f	2010-07-21	4352	\N	83244	\N
102559	GENERIC_DAY	1	0	f	2010-07-24	4352	\N	83244	\N
102560	GENERIC_DAY	1	0	f	2010-07-25	72317	\N	83244	\N
102561	GENERIC_DAY	1	3600	f	2010-07-23	72321	\N	83244	\N
102562	GENERIC_DAY	1	3600	f	2010-07-21	72317	\N	83244	\N
102563	GENERIC_DAY	1	0	f	2010-07-28	1216	\N	83244	\N
102564	GENERIC_DAY	1	3600	f	2010-07-26	72317	\N	83244	\N
102565	GENERIC_DAY	1	0	f	2010-07-25	4344	\N	83244	\N
102566	GENERIC_DAY	1	0	f	2010-07-25	1214	\N	83244	\N
102567	GENERIC_DAY	1	0	f	2010-07-26	4354	\N	83244	\N
102568	GENERIC_DAY	1	0	f	2010-07-21	4350	\N	83244	\N
102569	GENERIC_DAY	1	0	f	2010-07-28	4350	\N	83244	\N
102570	GENERIC_DAY	1	3600	f	2010-07-26	72319	\N	83244	\N
102571	GENERIC_DAY	1	0	f	2010-07-25	1220	\N	83244	\N
102572	GENERIC_DAY	1	0	f	2010-07-29	4348	\N	83244	\N
102573	GENERIC_DAY	1	7200	f	2010-07-21	4356	\N	83244	\N
102574	GENERIC_DAY	1	0	f	2010-07-24	21817	\N	83244	\N
102575	GENERIC_DAY	1	3600	f	2010-07-27	72319	\N	83244	\N
102576	GENERIC_DAY	1	0	f	2010-07-21	4348	\N	83244	\N
102577	GENERIC_DAY	1	7200	f	2010-07-22	4356	\N	83244	\N
102578	GENERIC_DAY	1	0	f	2010-07-25	21817	\N	83244	\N
102579	GENERIC_DAY	1	0	f	2010-07-29	4344	\N	83244	\N
102580	GENERIC_DAY	1	3600	f	2010-07-21	72321	\N	83244	\N
102581	GENERIC_DAY	1	0	f	2010-07-25	4348	\N	83244	\N
102582	GENERIC_DAY	1	7200	f	2010-07-27	4356	\N	83244	\N
102583	GENERIC_DAY	1	0	f	2010-07-25	72319	\N	83244	\N
102584	GENERIC_DAY	1	0	f	2010-07-25	4352	\N	83244	\N
102585	GENERIC_DAY	1	0	f	2010-07-26	4358	\N	83244	\N
102586	GENERIC_DAY	1	0	f	2010-07-29	4358	\N	83244	\N
102587	GENERIC_DAY	1	0	f	2010-07-21	4358	\N	83244	\N
102588	GENERIC_DAY	1	0	f	2010-07-28	1220	\N	83244	\N
102589	GENERIC_DAY	1	3600	f	2010-07-22	72319	\N	83244	\N
102590	GENERIC_DAY	1	0	f	2010-07-24	4356	\N	83244	\N
102591	GENERIC_DAY	1	0	f	2010-07-26	4344	\N	83244	\N
102592	GENERIC_DAY	1	7200	f	2010-07-27	21817	\N	83244	\N
102593	GENERIC_DAY	1	3600	f	2010-07-26	72321	\N	83244	\N
102594	GENERIC_DAY	1	0	f	2010-07-23	4358	\N	83244	\N
102595	GENERIC_DAY	1	0	f	2010-07-26	1216	\N	83244	\N
102596	GENERIC_DAY	1	0	f	2010-07-25	4356	\N	83244	\N
102597	GENERIC_DAY	1	0	f	2010-07-22	1220	\N	83244	\N
102598	GENERIC_DAY	1	7200	f	2010-07-26	21817	\N	83244	\N
102599	GENERIC_DAY	1	0	f	2010-07-22	4348	\N	83244	\N
102600	GENERIC_DAY	1	3600	f	2010-07-27	1214	\N	83244	\N
102601	GENERIC_DAY	1	0	f	2010-07-25	4350	\N	83244	\N
102602	GENERIC_DAY	1	3600	f	2010-07-22	72321	\N	83244	\N
102603	GENERIC_DAY	1	3600	f	2010-07-22	72317	\N	83244	\N
102604	GENERIC_DAY	1	0	f	2010-07-29	72319	\N	83244	\N
102605	GENERIC_DAY	1	0	f	2010-07-24	72321	\N	83244	\N
102606	GENERIC_DAY	1	7200	f	2010-07-28	21817	\N	83244	\N
102607	GENERIC_DAY	1	0	f	2010-07-23	1220	\N	83244	\N
102608	GENERIC_DAY	1	0	f	2010-07-24	4350	\N	83244	\N
102609	GENERIC_DAY	1	3600	f	2010-07-27	72321	\N	83244	\N
102610	GENERIC_DAY	1	0	f	2010-07-29	1214	\N	83244	\N
102611	GENERIC_DAY	1	0	f	2010-07-23	4350	\N	83244	\N
102612	GENERIC_DAY	1	0	f	2010-07-24	4354	\N	83244	\N
102613	GENERIC_DAY	1	0	f	2010-07-23	1216	\N	83244	\N
102614	GENERIC_DAY	1	0	f	2010-07-24	72317	\N	83244	\N
102615	GENERIC_DAY	1	0	f	2010-07-27	4348	\N	83244	\N
102616	GENERIC_DAY	1	3600	f	2010-07-26	1214	\N	83244	\N
102617	GENERIC_DAY	1	0	f	2010-07-22	4352	\N	83244	\N
102618	GENERIC_DAY	1	3600	f	2010-07-28	1214	\N	83244	\N
102619	GENERIC_DAY	1	0	f	2010-07-26	4350	\N	83244	\N
102620	GENERIC_DAY	1	0	f	2010-07-29	4350	\N	83244	\N
13228	SPECIFIC_DAY	2	28800	f	2010-06-30	4350	8082	\N	\N
27644	GENERIC_DAY	9	0	f	2010-08-21	4344	\N	27074	\N
27668	GENERIC_DAY	9	7200	f	2010-08-05	4358	\N	27074	\N
27664	GENERIC_DAY	9	7200	f	2010-08-24	4358	\N	27074	\N
27667	GENERIC_DAY	9	7200	f	2010-08-27	4344	\N	27074	\N
27641	GENERIC_DAY	9	7200	f	2010-08-18	4348	\N	27074	\N
27635	GENERIC_DAY	9	0	f	2010-08-08	4350	\N	27074	\N
27643	GENERIC_DAY	9	7200	f	2010-08-18	4350	\N	27074	\N
27646	GENERIC_DAY	9	7200	f	2010-08-12	4348	\N	27074	\N
27650	GENERIC_DAY	9	7200	f	2010-08-03	4350	\N	27074	\N
27640	GENERIC_DAY	9	7200	f	2010-08-04	4358	\N	27074	\N
37911	SPECIFIC_DAY	2	28800	f	2010-08-17	1220	31213	\N	\N
37898	SPECIFIC_DAY	2	28800	f	2010-08-20	1220	31213	\N	\N
37906	SPECIFIC_DAY	2	0	f	2010-08-15	1220	31213	\N	\N
37901	SPECIFIC_DAY	2	28800	f	2010-08-13	1220	31213	\N	\N
37909	SPECIFIC_DAY	2	28800	f	2010-08-11	1220	31213	\N	\N
37910	SPECIFIC_DAY	2	28800	f	2010-08-05	1220	31213	\N	\N
37905	SPECIFIC_DAY	2	28800	f	2010-08-19	1220	31213	\N	\N
37895	SPECIFIC_DAY	2	28800	f	2010-08-16	1220	31213	\N	\N
37896	SPECIFIC_DAY	2	0	f	2010-08-14	1220	31213	\N	\N
37900	SPECIFIC_DAY	2	28800	f	2010-08-09	1220	31213	\N	\N
37897	SPECIFIC_DAY	2	28800	f	2010-08-06	1220	31213	\N	\N
37899	SPECIFIC_DAY	2	14400	f	2010-08-04	1220	31213	\N	\N
37904	SPECIFIC_DAY	2	28800	f	2010-08-10	1220	31213	\N	\N
37907	SPECIFIC_DAY	2	28800	f	2010-08-12	1220	31213	\N	\N
37908	SPECIFIC_DAY	2	0	f	2010-08-07	1220	31213	\N	\N
37902	SPECIFIC_DAY	2	28800	f	2010-08-18	1220	31213	\N	\N
37903	SPECIFIC_DAY	2	0	f	2010-08-08	1220	31213	\N	\N
21509	GENERIC_DAY	4	0	f	2010-07-17	4344	\N	16773	\N
21541	GENERIC_DAY	4	10800	f	2010-07-14	4348	\N	16773	\N
21566	GENERIC_DAY	4	7200	f	2010-07-16	4358	\N	16773	\N
21528	GENERIC_DAY	4	0	f	2010-07-24	4358	\N	16773	\N
21484	GENERIC_DAY	4	0	f	2010-07-07	4350	\N	16773	\N
21539	GENERIC_DAY	4	0	f	2010-07-17	4350	\N	16773	\N
21524	GENERIC_DAY	4	14400	f	2010-07-07	4358	\N	16773	\N
21525	GENERIC_DAY	4	0	f	2010-07-24	4348	\N	16773	\N
21492	GENERIC_DAY	4	7200	f	2010-07-21	4358	\N	16773	\N
21577	GENERIC_DAY	4	7200	f	2010-07-15	4358	\N	16773	\N
21522	GENERIC_DAY	4	10800	f	2010-07-09	4350	\N	16773	\N
21515	GENERIC_DAY	4	7200	f	2010-07-14	4358	\N	16773	\N
21505	GENERIC_DAY	4	7200	f	2010-07-28	4350	\N	16773	\N
21550	GENERIC_DAY	4	0	f	2010-07-24	4344	\N	16773	\N
21562	GENERIC_DAY	4	0	f	2010-07-11	4350	\N	16773	\N
21565	GENERIC_DAY	4	0	f	2010-07-18	4348	\N	16773	\N
21560	GENERIC_DAY	4	0	f	2010-07-04	4358	\N	16773	\N
21544	GENERIC_DAY	4	14400	f	2010-07-08	4348	\N	16773	\N
21564	GENERIC_DAY	4	0	f	2010-07-24	4350	\N	16773	\N
21506	GENERIC_DAY	4	0	f	2010-07-08	4350	\N	16773	\N
21532	GENERIC_DAY	4	0	f	2010-07-04	4348	\N	16773	\N
21536	GENERIC_DAY	4	7200	f	2010-07-20	4358	\N	16773	\N
21570	GENERIC_DAY	4	7200	f	2010-07-28	4344	\N	16773	\N
21546	GENERIC_DAY	4	0	f	2010-07-15	4344	\N	16773	\N
21545	GENERIC_DAY	4	14400	f	2010-07-05	4358	\N	16773	\N
21511	GENERIC_DAY	4	7200	f	2010-07-20	4348	\N	16773	\N
21477	GENERIC_DAY	4	0	f	2010-07-04	4344	\N	16773	\N
21502	GENERIC_DAY	4	10800	f	2010-07-12	4350	\N	16773	\N
21559	GENERIC_DAY	4	0	f	2010-07-06	4350	\N	16773	\N
21555	GENERIC_DAY	4	7200	f	2010-07-21	4348	\N	16773	\N
21551	GENERIC_DAY	4	0	f	2010-07-10	4358	\N	16773	\N
21569	GENERIC_DAY	4	7200	f	2010-07-19	4350	\N	16773	\N
44628	GENERIC_DAY	0	7200	f	2010-06-17	4350	\N	42531	\N
44629	GENERIC_DAY	0	0	f	2010-06-26	4348	\N	42531	\N
44630	GENERIC_DAY	0	3600	f	2010-06-17	21817	\N	42531	\N
44631	GENERIC_DAY	0	0	f	2010-06-26	4358	\N	42531	\N
44632	GENERIC_DAY	0	0	f	2010-06-20	4350	\N	42531	\N
44633	GENERIC_DAY	0	0	f	2010-06-27	4358	\N	42531	\N
44634	GENERIC_DAY	0	0	f	2010-06-27	21817	\N	42531	\N
44635	GENERIC_DAY	0	0	f	2010-06-27	4348	\N	42531	\N
44636	GENERIC_DAY	0	0	f	2010-06-19	4348	\N	42531	\N
44637	GENERIC_DAY	0	3600	f	2010-06-15	4358	\N	42531	\N
44638	GENERIC_DAY	0	0	f	2010-06-26	4344	\N	42531	\N
21499	GENERIC_DAY	4	10800	f	2010-07-15	4348	\N	16773	\N
21523	GENERIC_DAY	4	10800	f	2010-07-14	4350	\N	16773	\N
21518	GENERIC_DAY	4	7200	f	2010-07-26	4348	\N	16773	\N
21531	GENERIC_DAY	4	7200	f	2010-07-20	4344	\N	16773	\N
21538	GENERIC_DAY	4	0	f	2010-07-05	4344	\N	16773	\N
21514	GENERIC_DAY	4	7200	f	2010-07-27	4350	\N	16773	\N
21521	GENERIC_DAY	4	14400	f	2010-07-06	4358	\N	16773	\N
21510	GENERIC_DAY	4	0	f	2010-07-10	4344	\N	16773	\N
21488	GENERIC_DAY	4	0	f	2010-07-10	4350	\N	16773	\N
21498	GENERIC_DAY	4	0	f	2010-07-18	4344	\N	16773	\N
21543	GENERIC_DAY	4	14400	f	2010-07-02	4358	\N	16773	\N
21561	GENERIC_DAY	4	10800	f	2010-07-09	4348	\N	16773	\N
21495	GENERIC_DAY	4	0	f	2010-07-11	4358	\N	16773	\N
21552	GENERIC_DAY	4	7200	f	2010-07-27	4358	\N	16773	\N
21512	GENERIC_DAY	4	7200	f	2010-07-23	4358	\N	16773	\N
21556	GENERIC_DAY	4	0	f	2010-07-09	4344	\N	16773	\N
21519	GENERIC_DAY	4	0	f	2010-07-12	4344	\N	16773	\N
21571	GENERIC_DAY	4	0	f	2010-07-06	4344	\N	16773	\N
21579	GENERIC_DAY	4	10800	f	2010-07-13	4350	\N	16773	\N
21575	GENERIC_DAY	4	0	f	2010-07-13	4344	\N	16773	\N
21507	GENERIC_DAY	4	0	f	2010-07-07	4344	\N	16773	\N
44639	GENERIC_DAY	0	7200	f	2010-06-25	4348	\N	42531	\N
44640	GENERIC_DAY	0	0	f	2010-06-24	4344	\N	42531	\N
44641	GENERIC_DAY	0	0	f	2010-06-25	4350	\N	42531	\N
44642	GENERIC_DAY	0	0	f	2010-06-20	4348	\N	42531	\N
44643	GENERIC_DAY	0	0	f	2010-06-26	21817	\N	42531	\N
44644	GENERIC_DAY	0	3600	f	2010-06-30	4350	\N	42531	\N
44645	GENERIC_DAY	0	3600	f	2010-06-16	21817	\N	42531	\N
44646	GENERIC_DAY	0	14400	f	2010-06-24	21817	\N	42531	\N
44647	GENERIC_DAY	0	7200	f	2010-06-16	4348	\N	42531	\N
44648	GENERIC_DAY	0	14400	f	2010-06-30	4348	\N	42531	\N
44649	GENERIC_DAY	0	7200	f	2010-06-29	4350	\N	42531	\N
44650	GENERIC_DAY	0	10800	f	2010-06-29	4358	\N	42531	\N
44651	GENERIC_DAY	0	7200	f	2010-06-17	4344	\N	42531	\N
44652	GENERIC_DAY	0	7200	f	2010-06-21	4344	\N	42531	\N
44653	GENERIC_DAY	0	3600	f	2010-06-16	4358	\N	42531	\N
44654	GENERIC_DAY	0	7200	f	2010-06-16	4344	\N	42531	\N
44655	GENERIC_DAY	0	0	f	2010-06-27	4344	\N	42531	\N
44656	GENERIC_DAY	0	0	f	2010-06-19	4358	\N	42531	\N
44657	GENERIC_DAY	0	7200	f	2010-06-24	4358	\N	42531	\N
44658	GENERIC_DAY	0	7200	f	2010-06-15	4348	\N	42531	\N
44659	GENERIC_DAY	0	7200	f	2010-06-18	4350	\N	42531	\N
44660	GENERIC_DAY	0	3600	f	2010-07-01	4358	\N	42531	\N
44661	GENERIC_DAY	0	14400	f	2010-06-25	21817	\N	42531	\N
44662	GENERIC_DAY	0	0	f	2010-07-01	4350	\N	42531	\N
44663	GENERIC_DAY	0	3600	f	2010-06-30	4358	\N	42531	\N
44664	GENERIC_DAY	0	7200	f	2010-06-18	4344	\N	42531	\N
44665	GENERIC_DAY	0	3600	f	2010-06-30	21817	\N	42531	\N
44666	GENERIC_DAY	0	0	f	2010-06-23	4350	\N	42531	\N
44667	GENERIC_DAY	0	0	f	2010-06-27	4350	\N	42531	\N
44668	GENERIC_DAY	0	3600	f	2010-07-01	4348	\N	42531	\N
44669	GENERIC_DAY	0	10800	f	2010-06-28	4358	\N	42531	\N
44670	GENERIC_DAY	0	7200	f	2010-07-01	21817	\N	42531	\N
44671	GENERIC_DAY	0	3600	f	2010-06-29	4348	\N	42531	\N
44672	GENERIC_DAY	0	0	f	2010-06-20	21817	\N	42531	\N
44673	GENERIC_DAY	0	7200	f	2010-06-15	4344	\N	42531	\N
44674	GENERIC_DAY	0	7200	f	2010-06-18	4348	\N	42531	\N
44675	GENERIC_DAY	0	0	f	2010-06-23	4344	\N	42531	\N
44676	GENERIC_DAY	0	3600	f	2010-06-22	4350	\N	42531	\N
44677	GENERIC_DAY	0	0	f	2010-06-19	21817	\N	42531	\N
37009	GENERIC_DAY	0	0	f	2010-10-17	4350	\N	27137	\N
37010	GENERIC_DAY	0	0	f	2010-10-24	4358	\N	27137	\N
37011	GENERIC_DAY	0	7200	f	2010-11-02	4348	\N	27137	\N
37012	GENERIC_DAY	0	0	f	2010-11-06	4350	\N	27137	\N
13745	GENERIC_DAY	1	0	f	2010-06-18	4358	\N	9406	\N
13740	GENERIC_DAY	1	10800	f	2010-06-18	1220	\N	9406	\N
37013	GENERIC_DAY	0	0	f	2010-10-23	4344	\N	27137	\N
37014	GENERIC_DAY	0	7200	f	2010-10-20	4348	\N	27137	\N
13743	GENERIC_DAY	1	0	f	2010-06-19	4356	\N	9406	\N
37015	GENERIC_DAY	0	7200	f	2010-10-22	4358	\N	27137	\N
37016	GENERIC_DAY	0	7200	f	2010-10-21	4344	\N	27137	\N
13755	GENERIC_DAY	1	0	f	2010-06-17	4358	\N	9406	\N
37017	GENERIC_DAY	0	7200	f	2010-10-29	4350	\N	27137	\N
13756	GENERIC_DAY	1	0	f	2010-06-21	4344	\N	9406	\N
37018	GENERIC_DAY	0	7200	f	2010-11-03	4348	\N	27137	\N
13750	GENERIC_DAY	1	0	f	2010-06-22	4344	\N	9406	\N
13741	GENERIC_DAY	1	0	f	2010-06-15	4344	\N	9406	\N
37019	GENERIC_DAY	0	0	f	2010-10-31	4350	\N	27137	\N
37020	GENERIC_DAY	0	7200	f	2010-10-15	4350	\N	27137	\N
13752	GENERIC_DAY	1	7200	f	2010-06-14	1220	\N	9406	\N
37021	GENERIC_DAY	0	7200	f	2010-11-04	4344	\N	27137	\N
37022	GENERIC_DAY	0	7200	f	2010-10-18	4344	\N	27137	\N
37023	GENERIC_DAY	0	7200	f	2010-11-01	4350	\N	27137	\N
37024	GENERIC_DAY	0	3600	f	2010-11-08	4358	\N	27137	\N
37025	GENERIC_DAY	0	7200	f	2010-11-05	4348	\N	27137	\N
13744	GENERIC_DAY	1	0	f	2010-06-18	1216	\N	9406	\N
13747	GENERIC_DAY	1	0	f	2010-06-16	4348	\N	9406	\N
13753	GENERIC_DAY	1	7200	f	2010-06-18	4356	\N	9406	\N
37026	GENERIC_DAY	0	7200	f	2010-10-25	4348	\N	27137	\N
13742	GENERIC_DAY	1	0	f	2010-06-20	4344	\N	9406	\N
37027	GENERIC_DAY	0	7200	f	2010-10-22	4350	\N	27137	\N
37028	GENERIC_DAY	0	0	f	2010-10-23	4350	\N	27137	\N
37029	GENERIC_DAY	0	7200	f	2010-11-05	4344	\N	27137	\N
13749	GENERIC_DAY	1	0	f	2010-06-19	1216	\N	9406	\N
13754	GENERIC_DAY	1	0	f	2010-06-17	4348	\N	9406	\N
13739	GENERIC_DAY	1	10800	f	2010-06-21	1214	\N	9406	\N
37030	GENERIC_DAY	0	7200	f	2010-10-13	4344	\N	27137	\N
37031	GENERIC_DAY	0	7200	f	2010-11-04	4358	\N	27137	\N
13748	GENERIC_DAY	1	0	f	2010-06-16	4352	\N	9406	\N
37032	GENERIC_DAY	0	7200	f	2010-10-14	4344	\N	27137	\N
13751	GENERIC_DAY	1	0	f	2010-06-14	4358	\N	9406	\N
37033	GENERIC_DAY	0	7200	f	2010-11-08	4348	\N	27137	\N
13746	GENERIC_DAY	1	0	f	2010-06-21	4350	\N	9406	\N
37034	GENERIC_DAY	0	7200	f	2010-10-18	4350	\N	27137	\N
37035	GENERIC_DAY	0	7200	f	2010-10-25	4344	\N	27137	\N
37036	GENERIC_DAY	0	0	f	2010-10-31	4344	\N	27137	\N
21574	GENERIC_DAY	4	0	f	2010-07-02	4344	\N	16773	\N
21476	GENERIC_DAY	4	0	f	2010-07-18	4350	\N	16773	\N
21500	GENERIC_DAY	4	10800	f	2010-07-12	4348	\N	16773	\N
21497	GENERIC_DAY	4	0	f	2010-07-17	4358	\N	16773	\N
21479	GENERIC_DAY	4	0	f	2010-07-10	4348	\N	16773	\N
21576	GENERIC_DAY	4	7200	f	2010-07-20	4350	\N	16773	\N
21487	GENERIC_DAY	4	7200	f	2010-07-19	4358	\N	16773	\N
21578	GENERIC_DAY	4	0	f	2010-07-25	4344	\N	16773	\N
21473	GENERIC_DAY	4	3600	f	2010-07-28	4348	\N	16773	\N
21534	GENERIC_DAY	4	7200	f	2010-07-26	4350	\N	16773	\N
21513	GENERIC_DAY	4	0	f	2010-07-17	4348	\N	16773	\N
21508	GENERIC_DAY	4	7200	f	2010-07-27	4348	\N	16773	\N
21474	GENERIC_DAY	4	14400	f	2010-07-07	4348	\N	16773	\N
21516	GENERIC_DAY	4	7200	f	2010-07-22	4358	\N	16773	\N
21472	GENERIC_DAY	4	0	f	2010-07-04	4350	\N	16773	\N
21557	GENERIC_DAY	4	7200	f	2010-07-13	4358	\N	16773	\N
21504	GENERIC_DAY	4	0	f	2010-07-03	4350	\N	16773	\N
21478	GENERIC_DAY	4	7200	f	2010-07-23	4350	\N	16773	\N
21490	GENERIC_DAY	4	7200	f	2010-07-22	4344	\N	16773	\N
37037	GENERIC_DAY	0	0	f	2010-10-30	4350	\N	27137	\N
37038	GENERIC_DAY	0	0	f	2010-10-24	4348	\N	27137	\N
37039	GENERIC_DAY	0	7200	f	2010-10-19	4344	\N	27137	\N
37040	GENERIC_DAY	0	7200	f	2010-11-03	4344	\N	27137	\N
37041	GENERIC_DAY	0	0	f	2010-10-24	4344	\N	27137	\N
37042	GENERIC_DAY	0	7200	f	2010-10-15	4344	\N	27137	\N
37043	GENERIC_DAY	0	7200	f	2010-11-03	4350	\N	27137	\N
37044	GENERIC_DAY	0	7200	f	2010-10-19	4350	\N	27137	\N
37045	GENERIC_DAY	0	0	f	2010-10-30	4348	\N	27137	\N
37046	GENERIC_DAY	0	7200	f	2010-11-08	4344	\N	27137	\N
37047	GENERIC_DAY	0	7200	f	2010-10-20	4350	\N	27137	\N
37048	GENERIC_DAY	0	0	f	2010-11-07	4358	\N	27137	\N
37049	GENERIC_DAY	0	0	f	2010-10-16	4344	\N	27137	\N
37050	GENERIC_DAY	0	7200	f	2010-10-20	4344	\N	27137	\N
37051	GENERIC_DAY	0	7200	f	2010-11-05	4358	\N	27137	\N
37052	GENERIC_DAY	0	7200	f	2010-11-01	4358	\N	27137	\N
37053	GENERIC_DAY	0	0	f	2010-10-23	4348	\N	27137	\N
37054	GENERIC_DAY	0	7200	f	2010-11-05	4350	\N	27137	\N
37055	GENERIC_DAY	0	7200	f	2010-10-25	4358	\N	27137	\N
21548	GENERIC_DAY	4	7200	f	2010-07-23	4348	\N	16773	\N
21485	GENERIC_DAY	4	0	f	2010-07-25	4350	\N	16773	\N
21494	GENERIC_DAY	4	7200	f	2010-07-26	4358	\N	16773	\N
21573	GENERIC_DAY	4	0	f	2010-07-03	4348	\N	16773	\N
21537	GENERIC_DAY	4	0	f	2010-07-03	4344	\N	16773	\N
21475	GENERIC_DAY	4	7200	f	2010-07-22	4348	\N	16773	\N
21489	GENERIC_DAY	4	14400	f	2010-07-08	4358	\N	16773	\N
21517	GENERIC_DAY	4	7200	f	2010-07-21	4350	\N	16773	\N
21503	GENERIC_DAY	4	10800	f	2010-07-15	4350	\N	16773	\N
21493	GENERIC_DAY	4	3600	f	2010-07-28	4358	\N	16773	\N
21526	GENERIC_DAY	4	0	f	2010-07-11	4348	\N	16773	\N
21542	GENERIC_DAY	4	0	f	2010-07-08	4344	\N	16773	\N
21567	GENERIC_DAY	4	14400	f	2010-07-05	4348	\N	16773	\N
21553	GENERIC_DAY	4	10800	f	2010-07-13	4348	\N	16773	\N
21520	GENERIC_DAY	4	10800	f	2010-07-16	4350	\N	16773	\N
21480	GENERIC_DAY	4	0	f	2010-07-25	4348	\N	16773	\N
21483	GENERIC_DAY	4	7200	f	2010-07-26	4344	\N	16773	\N
21529	GENERIC_DAY	4	7200	f	2010-07-19	4344	\N	16773	\N
21572	GENERIC_DAY	4	7200	f	2010-07-19	4348	\N	16773	\N
21563	GENERIC_DAY	4	0	f	2010-07-02	4350	\N	16773	\N
21491	GENERIC_DAY	4	0	f	2010-07-16	4344	\N	16773	\N
21530	GENERIC_DAY	4	7200	f	2010-07-21	4344	\N	16773	\N
21482	GENERIC_DAY	4	7200	f	2010-07-09	4358	\N	16773	\N
21527	GENERIC_DAY	4	14400	f	2010-07-02	4348	\N	16773	\N
21549	GENERIC_DAY	4	0	f	2010-07-25	4358	\N	16773	\N
21486	GENERIC_DAY	4	7200	f	2010-07-12	4358	\N	16773	\N
21558	GENERIC_DAY	4	14400	f	2010-07-06	4348	\N	16773	\N
21547	GENERIC_DAY	4	0	f	2010-07-03	4358	\N	16773	\N
21540	GENERIC_DAY	4	7200	f	2010-07-22	4350	\N	16773	\N
21535	GENERIC_DAY	4	7200	f	2010-07-27	4344	\N	16773	\N
21501	GENERIC_DAY	4	0	f	2010-07-05	4350	\N	16773	\N
21481	GENERIC_DAY	4	0	f	2010-07-11	4344	\N	16773	\N
21533	GENERIC_DAY	4	0	f	2010-07-14	4344	\N	16773	\N
21496	GENERIC_DAY	4	7200	f	2010-07-23	4344	\N	16773	\N
21568	GENERIC_DAY	4	10800	f	2010-07-16	4348	\N	16773	\N
21554	GENERIC_DAY	4	0	f	2010-07-18	4358	\N	16773	\N
21613	GENERIC_DAY	4	7200	f	2010-08-03	4348	\N	16774	\N
21666	GENERIC_DAY	4	7200	f	2010-08-11	4348	\N	16774	\N
21673	GENERIC_DAY	4	0	f	2010-07-31	4358	\N	16774	\N
21646	GENERIC_DAY	4	7200	f	2010-07-30	4344	\N	16774	\N
21627	GENERIC_DAY	4	7200	f	2010-08-17	4348	\N	16774	\N
21580	GENERIC_DAY	4	7200	f	2010-08-16	4348	\N	16774	\N
21628	GENERIC_DAY	4	7200	f	2010-08-24	4358	\N	16774	\N
21582	GENERIC_DAY	4	7200	f	2010-09-01	4350	\N	16774	\N
21665	GENERIC_DAY	4	7200	f	2010-08-23	4350	\N	16774	\N
21657	GENERIC_DAY	4	7200	f	2010-08-18	4350	\N	16774	\N
21601	GENERIC_DAY	4	0	f	2010-08-14	4358	\N	16774	\N
21605	GENERIC_DAY	4	7200	f	2010-08-24	4348	\N	16774	\N
21587	GENERIC_DAY	4	7200	f	2010-08-25	4348	\N	16774	\N
21650	GENERIC_DAY	4	0	f	2010-08-15	4350	\N	16774	\N
21667	GENERIC_DAY	4	7200	f	2010-08-25	4344	\N	16774	\N
21584	GENERIC_DAY	4	7200	f	2010-08-30	4350	\N	16774	\N
21668	GENERIC_DAY	4	7200	f	2010-08-27	4348	\N	16774	\N
21586	GENERIC_DAY	4	7200	f	2010-08-18	4344	\N	16774	\N
21677	GENERIC_DAY	4	7200	f	2010-08-13	4348	\N	16774	\N
21658	GENERIC_DAY	4	7200	f	2010-08-27	4358	\N	16774	\N
21611	GENERIC_DAY	4	7200	f	2010-08-04	4358	\N	16774	\N
21683	GENERIC_DAY	4	7200	f	2010-07-29	4358	\N	16774	\N
21669	GENERIC_DAY	4	0	f	2010-08-14	4350	\N	16774	\N
21633	GENERIC_DAY	4	7200	f	2010-08-24	4350	\N	16774	\N
21637	GENERIC_DAY	4	0	f	2010-08-08	4344	\N	16774	\N
21652	GENERIC_DAY	4	7200	f	2010-08-09	4350	\N	16774	\N
21599	GENERIC_DAY	4	7200	f	2010-07-29	4344	\N	16774	\N
21598	GENERIC_DAY	4	7200	f	2010-08-09	4348	\N	16774	\N
21678	GENERIC_DAY	4	7200	f	2010-08-20	4344	\N	16774	\N
21590	GENERIC_DAY	4	0	f	2010-08-22	4350	\N	16774	\N
21589	GENERIC_DAY	4	0	f	2010-08-29	4348	\N	16774	\N
21597	GENERIC_DAY	4	7200	f	2010-08-05	4350	\N	16774	\N
21594	GENERIC_DAY	4	7200	f	2010-08-11	4350	\N	16774	\N
21682	GENERIC_DAY	4	7200	f	2010-08-23	4358	\N	16774	\N
21596	GENERIC_DAY	4	0	f	2010-08-01	4358	\N	16774	\N
21622	GENERIC_DAY	4	7200	f	2010-08-30	4348	\N	16774	\N
21614	GENERIC_DAY	4	7200	f	2010-08-20	4348	\N	16774	\N
21681	GENERIC_DAY	4	7200	f	2010-08-23	4348	\N	16774	\N
21621	GENERIC_DAY	4	7200	f	2010-08-12	4348	\N	16774	\N
21639	GENERIC_DAY	4	7200	f	2010-09-01	4348	\N	16774	\N
21631	GENERIC_DAY	4	7200	f	2010-08-16	4358	\N	16774	\N
21642	GENERIC_DAY	4	0	f	2010-08-28	4350	\N	16774	\N
21618	GENERIC_DAY	4	0	f	2010-08-08	4348	\N	16774	\N
21645	GENERIC_DAY	4	7200	f	2010-09-01	4344	\N	16774	\N
21625	GENERIC_DAY	4	7200	f	2010-08-06	4348	\N	16774	\N
37056	GENERIC_DAY	0	7200	f	2010-10-18	4348	\N	27137	\N
37057	GENERIC_DAY	0	7200	f	2010-10-21	4350	\N	27137	\N
37058	GENERIC_DAY	0	7200	f	2010-10-26	4348	\N	27137	\N
37059	GENERIC_DAY	0	7200	f	2010-10-13	4348	\N	27137	\N
37060	GENERIC_DAY	0	7200	f	2010-10-25	4350	\N	27137	\N
37061	GENERIC_DAY	0	7200	f	2010-10-22	4348	\N	27137	\N
37062	GENERIC_DAY	0	7200	f	2010-10-14	4350	\N	27137	\N
37063	GENERIC_DAY	0	7200	f	2010-10-14	4348	\N	27137	\N
37064	GENERIC_DAY	0	7200	f	2010-11-02	4350	\N	27137	\N
37065	GENERIC_DAY	0	0	f	2010-10-16	4358	\N	27137	\N
37066	GENERIC_DAY	0	7200	f	2010-10-27	4358	\N	27137	\N
37067	GENERIC_DAY	0	7200	f	2010-10-19	4358	\N	27137	\N
37068	GENERIC_DAY	0	7200	f	2010-10-20	4358	\N	27137	\N
37069	GENERIC_DAY	0	7200	f	2010-10-28	4358	\N	27137	\N
37070	GENERIC_DAY	0	7200	f	2010-11-02	4358	\N	27137	\N
37071	GENERIC_DAY	0	7200	f	2010-10-29	4358	\N	27137	\N
37072	GENERIC_DAY	0	7200	f	2010-10-28	4348	\N	27137	\N
37073	GENERIC_DAY	0	7200	f	2010-11-02	4344	\N	27137	\N
37074	GENERIC_DAY	0	7200	f	2010-10-27	4344	\N	27137	\N
37075	GENERIC_DAY	0	7200	f	2010-10-27	4348	\N	27137	\N
37076	GENERIC_DAY	0	0	f	2010-10-16	4350	\N	27137	\N
37077	GENERIC_DAY	0	7200	f	2010-10-26	4344	\N	27137	\N
37078	GENERIC_DAY	0	7200	f	2010-10-19	4348	\N	27137	\N
37079	GENERIC_DAY	0	7200	f	2010-11-01	4348	\N	27137	\N
37080	GENERIC_DAY	0	7200	f	2010-10-21	4348	\N	27137	\N
37081	GENERIC_DAY	0	7200	f	2010-10-28	4344	\N	27137	\N
37082	GENERIC_DAY	0	0	f	2010-10-31	4348	\N	27137	\N
37083	GENERIC_DAY	0	7200	f	2010-11-03	4358	\N	27137	\N
37084	GENERIC_DAY	0	7200	f	2010-10-28	4350	\N	27137	\N
37085	GENERIC_DAY	0	7200	f	2010-10-29	4348	\N	27137	\N
37086	GENERIC_DAY	0	7200	f	2010-11-04	4348	\N	27137	\N
37087	GENERIC_DAY	0	0	f	2010-10-23	4358	\N	27137	\N
37088	GENERIC_DAY	0	7200	f	2010-11-04	4350	\N	27137	\N
37089	GENERIC_DAY	0	7200	f	2010-10-15	4358	\N	27137	\N
37090	GENERIC_DAY	0	0	f	2010-11-06	4348	\N	27137	\N
37091	GENERIC_DAY	0	0	f	2010-11-07	4350	\N	27137	\N
37092	GENERIC_DAY	0	0	f	2010-11-07	4348	\N	27137	\N
37093	GENERIC_DAY	0	0	f	2010-10-17	4344	\N	27137	\N
37094	GENERIC_DAY	0	7200	f	2010-10-21	4358	\N	27137	\N
21617	GENERIC_DAY	4	0	f	2010-08-15	4344	\N	16774	\N
21680	GENERIC_DAY	4	7200	f	2010-08-04	4348	\N	16774	\N
21676	GENERIC_DAY	4	0	f	2010-08-22	4348	\N	16774	\N
21651	GENERIC_DAY	4	7200	f	2010-08-06	4358	\N	16774	\N
21649	GENERIC_DAY	4	7200	f	2010-08-19	4348	\N	16774	\N
21674	GENERIC_DAY	4	7200	f	2010-08-30	4358	\N	16774	\N
21615	GENERIC_DAY	4	7200	f	2010-08-11	4358	\N	16774	\N
21608	GENERIC_DAY	4	0	f	2010-08-29	4344	\N	16774	\N
21623	GENERIC_DAY	4	7200	f	2010-08-04	4344	\N	16774	\N
21634	GENERIC_DAY	4	7200	f	2010-08-04	4350	\N	16774	\N
21679	GENERIC_DAY	4	7200	f	2010-08-25	4358	\N	16774	\N
21640	GENERIC_DAY	4	7200	f	2010-08-11	4344	\N	16774	\N
21616	GENERIC_DAY	4	7200	f	2010-08-19	4344	\N	16774	\N
21630	GENERIC_DAY	4	0	f	2010-08-29	4350	\N	16774	\N
21664	GENERIC_DAY	4	7200	f	2010-08-13	4358	\N	16774	\N
21648	GENERIC_DAY	4	7200	f	2010-08-16	4350	\N	16774	\N
21675	GENERIC_DAY	4	7200	f	2010-08-03	4344	\N	16774	\N
21581	GENERIC_DAY	4	7200	f	2010-08-18	4348	\N	16774	\N
21670	GENERIC_DAY	4	7200	f	2010-08-12	4344	\N	16774	\N
21655	GENERIC_DAY	4	7200	f	2010-08-10	4350	\N	16774	\N
21592	GENERIC_DAY	4	0	f	2010-08-14	4348	\N	16774	\N
21672	GENERIC_DAY	4	7200	f	2010-07-30	4358	\N	16774	\N
21644	GENERIC_DAY	4	7200	f	2010-08-02	4350	\N	16774	\N
21653	GENERIC_DAY	4	7200	f	2010-08-23	4344	\N	16774	\N
21609	GENERIC_DAY	4	7200	f	2010-08-05	4348	\N	16774	\N
21626	GENERIC_DAY	4	0	f	2010-07-31	4348	\N	16774	\N
21624	GENERIC_DAY	4	0	f	2010-08-14	4344	\N	16774	\N
21610	GENERIC_DAY	4	7200	f	2010-07-30	4350	\N	16774	\N
21635	GENERIC_DAY	4	0	f	2010-08-07	4350	\N	16774	\N
21607	GENERIC_DAY	4	7200	f	2010-08-26	4344	\N	16774	\N
21620	GENERIC_DAY	4	7200	f	2010-08-17	4344	\N	16774	\N
21591	GENERIC_DAY	4	7200	f	2010-08-06	4344	\N	16774	\N
37095	GENERIC_DAY	0	3600	f	2010-11-08	4350	\N	27137	\N
37096	GENERIC_DAY	0	7200	f	2010-10-27	4350	\N	27137	\N
37097	GENERIC_DAY	0	7200	f	2010-10-22	4344	\N	27137	\N
37098	GENERIC_DAY	0	7200	f	2010-10-14	4358	\N	27137	\N
37099	GENERIC_DAY	0	0	f	2010-10-31	4358	\N	27137	\N
37100	GENERIC_DAY	0	7200	f	2010-11-01	4344	\N	27137	\N
37101	GENERIC_DAY	0	0	f	2010-10-17	4348	\N	27137	\N
37102	GENERIC_DAY	0	7200	f	2010-10-29	4344	\N	27137	\N
37103	GENERIC_DAY	0	7200	f	2010-10-13	4358	\N	27137	\N
37104	GENERIC_DAY	0	7200	f	2010-10-13	4350	\N	27137	\N
37105	GENERIC_DAY	0	0	f	2010-11-06	4344	\N	27137	\N
37106	GENERIC_DAY	0	0	f	2010-10-30	4344	\N	27137	\N
37107	GENERIC_DAY	0	7200	f	2010-10-15	4348	\N	27137	\N
37108	GENERIC_DAY	0	0	f	2010-10-30	4358	\N	27137	\N
37109	GENERIC_DAY	0	0	f	2010-11-06	4358	\N	27137	\N
37110	GENERIC_DAY	0	7200	f	2010-10-26	4350	\N	27137	\N
37111	GENERIC_DAY	0	0	f	2010-10-16	4348	\N	27137	\N
37112	GENERIC_DAY	0	0	f	2010-11-07	4344	\N	27137	\N
37113	GENERIC_DAY	0	0	f	2010-10-24	4350	\N	27137	\N
37114	GENERIC_DAY	0	7200	f	2010-10-26	4358	\N	27137	\N
37115	GENERIC_DAY	0	0	f	2010-10-17	4358	\N	27137	\N
37116	GENERIC_DAY	0	7200	f	2010-10-18	4358	\N	27137	\N
37117	GENERIC_DAY	0	7200	f	2010-11-16	4358	\N	27138	\N
37118	GENERIC_DAY	0	7200	f	2010-12-06	4350	\N	27138	\N
37119	GENERIC_DAY	0	7200	f	2010-11-10	4358	\N	27138	\N
37120	GENERIC_DAY	0	7200	f	2010-11-23	4358	\N	27138	\N
37121	GENERIC_DAY	0	7200	f	2010-11-11	4358	\N	27138	\N
37122	GENERIC_DAY	0	7200	f	2010-11-18	4350	\N	27138	\N
37123	GENERIC_DAY	0	7200	f	2010-12-09	4348	\N	27138	\N
37124	GENERIC_DAY	0	0	f	2010-11-13	4350	\N	27138	\N
37125	GENERIC_DAY	0	0	f	2010-11-21	4344	\N	27138	\N
13738	SPECIFIC_DAY	1	28800	f	2010-06-16	4348	8090	\N	\N
21604	GENERIC_DAY	4	7200	f	2010-08-03	4358	\N	16774	\N
21654	GENERIC_DAY	4	7200	f	2010-08-05	4358	\N	16774	\N
21585	GENERIC_DAY	4	7200	f	2010-08-25	4350	\N	16774	\N
21600	GENERIC_DAY	4	7200	f	2010-08-10	4344	\N	16774	\N
21661	GENERIC_DAY	4	0	f	2010-07-31	4344	\N	16774	\N
21641	GENERIC_DAY	4	0	f	2010-08-28	4358	\N	16774	\N
21660	GENERIC_DAY	4	7200	f	2010-08-17	4358	\N	16774	\N
21662	GENERIC_DAY	4	7200	f	2010-07-29	4348	\N	16774	\N
21588	GENERIC_DAY	4	7200	f	2010-08-02	4344	\N	16774	\N
21612	GENERIC_DAY	4	0	f	2010-08-15	4358	\N	16774	\N
21671	GENERIC_DAY	4	7200	f	2010-08-31	4344	\N	16774	\N
21643	GENERIC_DAY	4	7200	f	2010-08-12	4358	\N	16774	\N
21629	GENERIC_DAY	4	7200	f	2010-08-19	4358	\N	16774	\N
21632	GENERIC_DAY	4	0	f	2010-08-21	4344	\N	16774	\N
21606	GENERIC_DAY	4	0	f	2010-08-28	4348	\N	16774	\N
21619	GENERIC_DAY	4	0	f	2010-08-21	4358	\N	16774	\N
21636	GENERIC_DAY	4	7200	f	2010-08-09	4358	\N	16774	\N
21603	GENERIC_DAY	4	7200	f	2010-08-20	4358	\N	16774	\N
21663	GENERIC_DAY	4	7200	f	2010-08-02	4348	\N	16774	\N
21659	GENERIC_DAY	4	0	f	2010-08-07	4358	\N	16774	\N
21602	GENERIC_DAY	4	0	f	2010-08-15	4348	\N	16774	\N
21647	GENERIC_DAY	4	0	f	2010-08-07	4344	\N	16774	\N
21719	GENERIC_DAY	4	7200	f	2010-08-26	4348	\N	16774	\N
21595	GENERIC_DAY	4	0	f	2010-08-08	4350	\N	16774	\N
21583	GENERIC_DAY	4	7200	f	2010-08-16	4344	\N	16774	\N
21638	GENERIC_DAY	4	7200	f	2010-08-10	4348	\N	16774	\N
21593	GENERIC_DAY	4	7200	f	2010-08-30	4344	\N	16774	\N
21656	GENERIC_DAY	4	0	f	2010-08-01	4348	\N	16774	\N
21710	GENERIC_DAY	4	7200	f	2010-08-24	4344	\N	16774	\N
6319	GENERIC_DAY	18	14400	t	2010-06-18	4354	\N	5962	\N
6536	GENERIC_DAY	16	3600	f	2010-06-26	4354	\N	5962	\N
6534	GENERIC_DAY	16	18000	f	2010-07-02	4354	\N	5962	\N
6511	GENERIC_DAY	16	18000	f	2010-06-29	4354	\N	5962	\N
6515	GENERIC_DAY	16	18000	f	2010-07-14	4354	\N	5962	\N
6498	GENERIC_DAY	16	18000	f	2010-07-13	4354	\N	5962	\N
6528	GENERIC_DAY	16	14400	f	2010-07-15	4352	\N	5962	\N
6517	GENERIC_DAY	16	14400	f	2010-07-16	4352	\N	5962	\N
6540	GENERIC_DAY	16	14400	f	2010-07-20	4352	\N	5962	\N
6507	GENERIC_DAY	16	14400	f	2010-07-14	4352	\N	5962	\N
6310	GENERIC_DAY	18	14400	t	2010-06-23	4354	\N	5962	\N
6504	GENERIC_DAY	16	14400	f	2010-07-05	4352	\N	5962	\N
6523	GENERIC_DAY	16	14400	f	2010-07-12	4352	\N	5962	\N
6520	GENERIC_DAY	16	18000	f	2010-06-28	4354	\N	5962	\N
6539	GENERIC_DAY	16	14400	f	2010-07-19	4352	\N	5962	\N
6531	GENERIC_DAY	16	18000	f	2010-07-20	4354	\N	5962	\N
6285	GENERIC_DAY	18	14400	t	2010-06-16	4352	\N	5962	\N
6327	GENERIC_DAY	18	0	t	2010-06-19	4352	\N	5962	\N
6526	GENERIC_DAY	16	3600	f	2010-06-27	4352	\N	5962	\N
6513	GENERIC_DAY	16	14400	f	2010-07-07	4352	\N	5962	\N
6519	GENERIC_DAY	16	3600	f	2010-06-27	4354	\N	5962	\N
6295	GENERIC_DAY	18	14400	t	2010-06-24	4354	\N	5962	\N
6344	GENERIC_DAY	18	0	t	2010-06-20	4352	\N	5962	\N
6522	GENERIC_DAY	16	3600	f	2010-07-18	4354	\N	5962	\N
6500	GENERIC_DAY	16	18000	f	2010-07-19	4354	\N	5962	\N
6340	GENERIC_DAY	18	14400	t	2010-06-17	4352	\N	5962	\N
6505	GENERIC_DAY	16	18000	f	2010-07-12	4354	\N	5962	\N
6516	GENERIC_DAY	16	14400	f	2010-07-09	4352	\N	5962	\N
6529	GENERIC_DAY	16	3600	f	2010-06-26	4352	\N	5962	\N
6538	GENERIC_DAY	16	14400	f	2010-07-13	4352	\N	5962	\N
6343	GENERIC_DAY	18	14400	t	2010-06-15	4352	\N	5962	\N
6518	GENERIC_DAY	16	18000	f	2010-06-29	4352	\N	5962	\N
6497	GENERIC_DAY	16	18000	f	2010-07-06	4354	\N	5962	\N
6336	GENERIC_DAY	18	14400	t	2010-06-24	4352	\N	5962	\N
6524	GENERIC_DAY	16	18000	f	2010-07-15	4354	\N	5962	\N
6521	GENERIC_DAY	16	18000	f	2010-06-30	4352	\N	5962	\N
6537	GENERIC_DAY	16	3600	f	2010-07-04	4354	\N	5962	\N
6298	GENERIC_DAY	18	14400	t	2010-06-16	4354	\N	5962	\N
8812	GENERIC_DAY	12	7200	f	2010-06-24	4350	\N	5964	\N
8881	GENERIC_DAY	12	7200	f	2010-06-22	4350	\N	5964	\N
8828	GENERIC_DAY	12	7200	f	2010-07-01	4350	\N	5964	\N
8839	GENERIC_DAY	12	7200	f	2010-07-07	4348	\N	5964	\N
8854	GENERIC_DAY	12	0	f	2010-07-04	4344	\N	5964	\N
8843	GENERIC_DAY	12	0	f	2010-06-26	4344	\N	5964	\N
8856	GENERIC_DAY	12	7200	f	2010-07-07	4358	\N	5964	\N
8864	GENERIC_DAY	12	7200	f	2010-07-06	4350	\N	5964	\N
8876	GENERIC_DAY	12	7200	f	2010-06-21	4350	\N	5964	\N
8857	GENERIC_DAY	12	7200	f	2010-07-07	4350	\N	5964	\N
8875	GENERIC_DAY	12	7200	f	2010-06-21	4348	\N	5964	\N
8885	GENERIC_DAY	12	0	f	2010-07-03	4344	\N	5964	\N
8867	GENERIC_DAY	12	0	f	2010-07-03	4350	\N	5964	\N
8807	GENERIC_DAY	12	7200	f	2010-06-18	4350	\N	5964	\N
8795	GENERIC_DAY	12	7200	f	2010-06-28	4350	\N	5964	\N
8841	GENERIC_DAY	12	0	f	2010-07-04	4350	\N	5964	\N
8855	GENERIC_DAY	12	7200	f	2010-06-17	4358	\N	5964	\N
8850	GENERIC_DAY	12	0	f	2010-07-04	4348	\N	5964	\N
8874	GENERIC_DAY	12	7200	f	2010-06-24	4348	\N	5964	\N
8802	GENERIC_DAY	12	7200	f	2010-06-23	4358	\N	5964	\N
8861	GENERIC_DAY	12	7200	f	2010-06-17	4350	\N	5964	\N
8883	GENERIC_DAY	12	7200	f	2010-06-30	4348	\N	5964	\N
8789	GENERIC_DAY	12	0	f	2010-07-03	4358	\N	5964	\N
8814	GENERIC_DAY	12	0	f	2010-06-27	4358	\N	5964	\N
8860	GENERIC_DAY	12	7200	f	2010-06-18	4344	\N	5964	\N
8829	GENERIC_DAY	12	0	f	2010-06-19	4350	\N	5964	\N
8803	GENERIC_DAY	12	7200	f	2010-07-01	4358	\N	5964	\N
37126	GENERIC_DAY	0	7200	f	2010-12-01	4358	\N	27138	\N
37127	GENERIC_DAY	0	0	f	2010-12-04	4350	\N	27138	\N
37128	GENERIC_DAY	0	0	f	2010-11-27	4344	\N	27138	\N
37129	GENERIC_DAY	0	7200	f	2010-12-13	4350	\N	27138	\N
37130	GENERIC_DAY	0	0	f	2010-11-14	4348	\N	27138	\N
37131	GENERIC_DAY	0	7200	f	2010-11-09	4350	\N	27138	\N
37132	GENERIC_DAY	0	7200	f	2010-11-25	4344	\N	27138	\N
37133	GENERIC_DAY	0	7200	f	2010-12-10	4344	\N	27138	\N
37134	GENERIC_DAY	0	7200	f	2010-11-12	4358	\N	27138	\N
37135	GENERIC_DAY	0	0	f	2010-11-13	4358	\N	27138	\N
37136	GENERIC_DAY	0	0	f	2010-11-27	4358	\N	27138	\N
37137	GENERIC_DAY	0	7200	f	2010-11-11	4344	\N	27138	\N
37138	GENERIC_DAY	0	0	f	2010-11-27	4348	\N	27138	\N
37139	GENERIC_DAY	0	0	f	2010-12-11	4348	\N	27138	\N
37140	GENERIC_DAY	0	7200	f	2010-11-22	4348	\N	27138	\N
37141	GENERIC_DAY	0	0	f	2010-11-13	4344	\N	27138	\N
37142	GENERIC_DAY	0	7200	f	2010-12-03	4350	\N	27138	\N
37143	GENERIC_DAY	0	7200	f	2010-12-03	4358	\N	27138	\N
37144	GENERIC_DAY	0	7200	f	2010-11-25	4358	\N	27138	\N
37145	GENERIC_DAY	0	7200	f	2010-12-09	4358	\N	27138	\N
37146	GENERIC_DAY	0	7200	f	2010-12-09	4350	\N	27138	\N
37147	GENERIC_DAY	0	0	f	2010-11-28	4358	\N	27138	\N
37148	GENERIC_DAY	0	0	f	2010-12-12	4358	\N	27138	\N
37149	GENERIC_DAY	0	0	f	2010-12-12	4348	\N	27138	\N
37150	GENERIC_DAY	0	7200	f	2010-11-17	4344	\N	27138	\N
37151	GENERIC_DAY	0	7200	f	2010-12-06	4358	\N	27138	\N
37152	GENERIC_DAY	0	0	f	2010-11-14	4350	\N	27138	\N
37153	GENERIC_DAY	0	7200	f	2010-12-02	4348	\N	27138	\N
37154	GENERIC_DAY	0	7200	f	2010-11-24	4344	\N	27138	\N
37155	GENERIC_DAY	0	0	f	2010-11-20	4358	\N	27138	\N
37156	GENERIC_DAY	0	7200	f	2010-11-12	4348	\N	27138	\N
37157	GENERIC_DAY	0	7200	f	2010-12-10	4350	\N	27138	\N
37158	GENERIC_DAY	0	0	f	2010-11-21	4358	\N	27138	\N
37159	GENERIC_DAY	0	0	f	2010-12-05	4358	\N	27138	\N
37160	GENERIC_DAY	0	7200	f	2010-12-13	4358	\N	27138	\N
37161	GENERIC_DAY	0	7200	f	2010-12-07	4358	\N	27138	\N
37162	GENERIC_DAY	0	7200	f	2010-11-22	4344	\N	27138	\N
37163	GENERIC_DAY	0	7200	f	2010-12-02	4344	\N	27138	\N
37164	GENERIC_DAY	0	0	f	2010-12-11	4358	\N	27138	\N
37165	GENERIC_DAY	0	7200	f	2010-11-11	4348	\N	27138	\N
37166	GENERIC_DAY	0	7200	f	2010-11-15	4348	\N	27138	\N
37167	GENERIC_DAY	0	7200	f	2010-11-19	4344	\N	27138	\N
37168	GENERIC_DAY	0	7200	f	2010-12-10	4358	\N	27138	\N
37169	GENERIC_DAY	0	0	f	2010-12-05	4348	\N	27138	\N
37170	GENERIC_DAY	0	7200	f	2010-11-10	4344	\N	27138	\N
37171	GENERIC_DAY	0	0	f	2010-12-04	4348	\N	27138	\N
37172	GENERIC_DAY	0	7200	f	2010-11-15	4344	\N	27138	\N
37173	GENERIC_DAY	0	7200	f	2010-12-06	4344	\N	27138	\N
37174	GENERIC_DAY	0	0	f	2010-11-28	4348	\N	27138	\N
37175	GENERIC_DAY	0	0	f	2010-11-14	4344	\N	27138	\N
37176	GENERIC_DAY	0	7200	f	2010-11-30	4350	\N	27138	\N
37177	GENERIC_DAY	0	0	f	2010-12-11	4350	\N	27138	\N
37178	GENERIC_DAY	0	7200	f	2010-12-06	4348	\N	27138	\N
37179	GENERIC_DAY	0	7200	f	2010-11-24	4358	\N	27138	\N
37180	GENERIC_DAY	0	7200	f	2010-12-09	4344	\N	27138	\N
37181	GENERIC_DAY	0	7200	f	2010-11-29	4344	\N	27138	\N
37182	GENERIC_DAY	0	0	f	2010-11-28	4344	\N	27138	\N
37183	GENERIC_DAY	0	7200	f	2010-12-02	4350	\N	27138	\N
37184	GENERIC_DAY	0	7200	f	2010-11-09	4358	\N	27138	\N
37185	GENERIC_DAY	0	7200	f	2010-12-08	4348	\N	27138	\N
37186	GENERIC_DAY	0	7200	f	2010-11-15	4358	\N	27138	\N
37187	GENERIC_DAY	0	7200	f	2010-12-01	4344	\N	27138	\N
37188	GENERIC_DAY	0	7200	f	2010-11-09	4344	\N	27138	\N
37189	GENERIC_DAY	0	7200	f	2010-11-12	4350	\N	27138	\N
44678	GENERIC_DAY	0	0	f	2010-06-25	4344	\N	42531	\N
44679	GENERIC_DAY	0	0	f	2010-06-24	4350	\N	42531	\N
44680	GENERIC_DAY	0	0	f	2010-06-19	4350	\N	42531	\N
44681	GENERIC_DAY	0	0	f	2010-06-19	4344	\N	42531	\N
44682	GENERIC_DAY	0	7200	f	2010-06-15	4350	\N	42531	\N
44683	GENERIC_DAY	0	7200	f	2010-06-29	4344	\N	42531	\N
44684	GENERIC_DAY	0	7200	f	2010-06-28	4350	\N	42531	\N
44685	GENERIC_DAY	0	3600	f	2010-06-28	4348	\N	42531	\N
44686	GENERIC_DAY	0	7200	f	2010-06-17	4348	\N	42531	\N
44687	GENERIC_DAY	0	3600	f	2010-06-21	4358	\N	42531	\N
44688	GENERIC_DAY	0	14400	f	2010-06-23	21817	\N	42531	\N
44689	GENERIC_DAY	0	7200	f	2010-06-28	4344	\N	42531	\N
44690	GENERIC_DAY	0	7200	f	2010-06-21	4348	\N	42531	\N
44691	GENERIC_DAY	0	0	f	2010-06-20	4344	\N	42531	\N
44692	GENERIC_DAY	0	7200	f	2010-06-21	4350	\N	42531	\N
44693	GENERIC_DAY	0	7200	f	2010-06-16	4350	\N	42531	\N
44694	GENERIC_DAY	0	0	f	2010-06-29	21817	\N	42531	\N
8806	GENERIC_DAY	12	7200	f	2010-07-05	4344	\N	5964	\N
8853	GENERIC_DAY	12	7200	f	2010-07-08	4348	\N	5964	\N
8842	GENERIC_DAY	12	7200	f	2010-07-05	4350	\N	5964	\N
73412	GENERIC_DAY	3	28800	f	2010-07-21	72317	\N	73026	\N
73411	GENERIC_DAY	3	28800	f	2010-07-19	72321	\N	73026	\N
73413	GENERIC_DAY	3	28800	f	2010-07-21	72319	\N	73026	\N
8872	GENERIC_DAY	12	7200	f	2010-06-16	4348	\N	5964	\N
8804	GENERIC_DAY	12	7200	f	2010-07-02	4348	\N	5964	\N
8847	GENERIC_DAY	12	0	f	2010-06-27	4348	\N	5964	\N
8845	GENERIC_DAY	12	7200	f	2010-06-30	4344	\N	5964	\N
8799	GENERIC_DAY	12	7200	f	2010-06-21	4358	\N	5964	\N
37190	GENERIC_DAY	0	7200	f	2010-12-01	4350	\N	27138	\N
37191	GENERIC_DAY	0	7200	f	2010-11-09	4348	\N	27138	\N
37192	GENERIC_DAY	0	7200	f	2010-11-19	4350	\N	27138	\N
37193	GENERIC_DAY	0	7200	f	2010-12-07	4350	\N	27138	\N
37194	GENERIC_DAY	0	0	f	2010-11-27	4350	\N	27138	\N
37195	GENERIC_DAY	0	7200	f	2010-11-24	4350	\N	27138	\N
37196	GENERIC_DAY	0	0	f	2010-11-13	4348	\N	27138	\N
37197	GENERIC_DAY	0	7200	f	2010-11-29	4350	\N	27138	\N
37198	GENERIC_DAY	0	0	f	2010-12-04	4358	\N	27138	\N
37199	GENERIC_DAY	0	7200	f	2010-11-30	4344	\N	27138	\N
37200	GENERIC_DAY	0	7200	f	2010-12-03	4344	\N	27138	\N
37201	GENERIC_DAY	0	7200	f	2010-12-07	4348	\N	27138	\N
37202	GENERIC_DAY	0	7200	f	2010-11-26	4348	\N	27138	\N
37203	GENERIC_DAY	0	7200	f	2010-11-19	4358	\N	27138	\N
37204	GENERIC_DAY	0	7200	f	2010-11-26	4358	\N	27138	\N
37205	GENERIC_DAY	0	7200	f	2010-11-11	4350	\N	27138	\N
37206	GENERIC_DAY	0	7200	f	2010-12-10	4348	\N	27138	\N
37207	GENERIC_DAY	0	0	f	2010-11-28	4350	\N	27138	\N
37208	GENERIC_DAY	0	7200	f	2010-11-29	4348	\N	27138	\N
37209	GENERIC_DAY	0	7200	f	2010-12-08	4350	\N	27138	\N
37210	GENERIC_DAY	0	7200	f	2010-11-25	4348	\N	27138	\N
37211	GENERIC_DAY	0	7200	f	2010-11-16	4350	\N	27138	\N
37212	GENERIC_DAY	0	7200	f	2010-11-17	4348	\N	27138	\N
37213	GENERIC_DAY	0	7200	f	2010-12-13	4348	\N	27138	\N
37214	GENERIC_DAY	0	7200	f	2010-11-18	4344	\N	27138	\N
37215	GENERIC_DAY	0	0	f	2010-11-20	4348	\N	27138	\N
37216	GENERIC_DAY	0	7200	f	2010-11-22	4358	\N	27138	\N
37217	GENERIC_DAY	0	0	f	2010-12-05	4344	\N	27138	\N
37218	GENERIC_DAY	0	0	f	2010-12-05	4350	\N	27138	\N
37219	GENERIC_DAY	0	7200	f	2010-11-16	4348	\N	27138	\N
37220	GENERIC_DAY	0	7200	f	2010-11-29	4358	\N	27138	\N
37221	GENERIC_DAY	0	0	f	2010-11-21	4348	\N	27138	\N
37222	GENERIC_DAY	0	7200	f	2010-12-08	4344	\N	27138	\N
37223	GENERIC_DAY	0	7200	f	2010-11-15	4350	\N	27138	\N
37224	GENERIC_DAY	0	0	f	2010-11-21	4350	\N	27138	\N
37225	GENERIC_DAY	0	7200	f	2010-11-26	4344	\N	27138	\N
37226	GENERIC_DAY	0	7200	f	2010-11-18	4358	\N	27138	\N
37227	GENERIC_DAY	0	7200	f	2010-11-17	4358	\N	27138	\N
37228	GENERIC_DAY	0	7200	f	2010-11-30	4348	\N	27138	\N
37229	GENERIC_DAY	0	0	f	2010-11-20	4344	\N	27138	\N
37230	GENERIC_DAY	0	7200	f	2010-12-08	4358	\N	27138	\N
37231	GENERIC_DAY	0	7200	f	2010-11-17	4350	\N	27138	\N
37232	GENERIC_DAY	0	7200	f	2010-11-25	4350	\N	27138	\N
37233	GENERIC_DAY	0	7200	f	2010-11-24	4348	\N	27138	\N
37234	GENERIC_DAY	0	0	f	2010-11-14	4358	\N	27138	\N
37235	GENERIC_DAY	0	7200	f	2010-11-16	4344	\N	27138	\N
37236	GENERIC_DAY	0	7200	f	2010-12-01	4348	\N	27138	\N
37237	GENERIC_DAY	0	0	f	2010-12-12	4344	\N	27138	\N
37238	GENERIC_DAY	0	7200	f	2010-12-07	4344	\N	27138	\N
37256	GENERIC_DAY	0	7200	f	2010-11-23	4348	\N	27138	\N
37257	GENERIC_DAY	0	14400	f	2010-10-07	4354	\N	27139	\N
37258	GENERIC_DAY	0	14400	f	2010-09-16	4352	\N	27139	\N
37259	GENERIC_DAY	0	14400	f	2010-09-30	4354	\N	27139	\N
37260	GENERIC_DAY	0	14400	f	2010-09-21	4354	\N	27139	\N
37261	GENERIC_DAY	0	0	f	2010-09-12	4352	\N	27139	\N
37262	GENERIC_DAY	0	14400	f	2010-09-14	4354	\N	27139	\N
37263	GENERIC_DAY	0	14400	f	2010-10-11	4354	\N	27139	\N
37264	GENERIC_DAY	0	14400	f	2010-10-01	4354	\N	27139	\N
37265	GENERIC_DAY	0	14400	f	2010-09-23	4352	\N	27139	\N
37266	GENERIC_DAY	0	14400	f	2010-10-08	4354	\N	27139	\N
37267	GENERIC_DAY	0	14400	f	2010-10-01	4352	\N	27139	\N
37268	GENERIC_DAY	0	14400	f	2010-10-12	4354	\N	27139	\N
37269	GENERIC_DAY	0	14400	f	2010-09-17	4352	\N	27139	\N
37270	GENERIC_DAY	0	14400	f	2010-10-05	4354	\N	27139	\N
37271	GENERIC_DAY	0	0	f	2010-09-11	4354	\N	27139	\N
37272	GENERIC_DAY	0	14400	f	2010-09-21	4352	\N	27139	\N
37273	GENERIC_DAY	0	14400	f	2010-09-22	4352	\N	27139	\N
37274	GENERIC_DAY	0	14400	f	2010-09-15	4352	\N	27139	\N
37275	GENERIC_DAY	0	14400	f	2010-09-09	4354	\N	27139	\N
37276	GENERIC_DAY	0	0	f	2010-10-03	4354	\N	27139	\N
37277	GENERIC_DAY	0	0	f	2010-10-09	4354	\N	27139	\N
37278	GENERIC_DAY	0	14400	f	2010-09-28	4352	\N	27139	\N
37279	GENERIC_DAY	0	0	f	2010-09-12	4354	\N	27139	\N
37280	GENERIC_DAY	0	14400	f	2010-10-07	4352	\N	27139	\N
37281	GENERIC_DAY	0	0	f	2010-10-03	4352	\N	27139	\N
37282	GENERIC_DAY	0	0	f	2010-10-02	4354	\N	27139	\N
37283	GENERIC_DAY	0	0	f	2010-10-10	4352	\N	27139	\N
37284	GENERIC_DAY	0	14400	f	2010-09-13	4354	\N	27139	\N
37291	GENERIC_DAY	0	14400	f	2010-09-08	4352	\N	27139	\N
37292	GENERIC_DAY	0	14400	f	2010-09-09	4352	\N	27139	\N
37293	GENERIC_DAY	0	14400	f	2010-10-13	4352	\N	27139	\N
37294	GENERIC_DAY	0	0	f	2010-09-18	4352	\N	27139	\N
37295	GENERIC_DAY	0	14400	f	2010-09-24	4352	\N	27139	\N
37296	GENERIC_DAY	0	14400	f	2010-09-27	4352	\N	27139	\N
37297	GENERIC_DAY	0	14400	f	2010-09-13	4352	\N	27139	\N
37298	GENERIC_DAY	0	0	f	2010-09-19	4354	\N	27139	\N
37299	GENERIC_DAY	0	3600	f	2010-10-14	4352	\N	27139	\N
37300	GENERIC_DAY	0	14400	f	2010-09-10	4352	\N	27139	\N
37301	GENERIC_DAY	0	14400	f	2010-09-29	4354	\N	27139	\N
37302	GENERIC_DAY	0	14400	f	2010-09-20	4354	\N	27139	\N
37303	GENERIC_DAY	0	14400	f	2010-10-12	4352	\N	27139	\N
37304	GENERIC_DAY	0	0	f	2010-09-11	4352	\N	27139	\N
37305	GENERIC_DAY	0	14400	f	2010-09-24	4354	\N	27139	\N
37306	GENERIC_DAY	0	14400	f	2010-10-05	4352	\N	27139	\N
37307	GENERIC_DAY	0	0	f	2010-10-10	4354	\N	27139	\N
37308	GENERIC_DAY	0	14400	f	2010-09-15	4354	\N	27139	\N
37309	GENERIC_DAY	0	14400	f	2010-09-08	4354	\N	27139	\N
37310	GENERIC_DAY	0	0	f	2010-10-02	4352	\N	27139	\N
37311	GENERIC_DAY	0	0	f	2010-09-19	4352	\N	27139	\N
37312	GENERIC_DAY	0	0	f	2010-10-09	4352	\N	27139	\N
37313	GENERIC_DAY	0	14400	f	2010-09-23	4354	\N	27139	\N
37314	GENERIC_DAY	0	3600	f	2010-10-14	4354	\N	27139	\N
37315	GENERIC_DAY	0	0	f	2010-09-25	4354	\N	27139	\N
37316	GENERIC_DAY	0	14400	f	2010-09-28	4354	\N	27139	\N
37317	GENERIC_DAY	0	14400	f	2010-10-06	4352	\N	27139	\N
37318	GENERIC_DAY	0	14400	f	2010-09-29	4352	\N	27139	\N
37319	GENERIC_DAY	0	14400	f	2010-09-17	4354	\N	27139	\N
37320	GENERIC_DAY	0	14400	f	2010-09-30	4352	\N	27139	\N
37321	GENERIC_DAY	0	14400	f	2010-09-10	4354	\N	27139	\N
37322	GENERIC_DAY	0	0	f	2010-09-18	4354	\N	27139	\N
37323	GENERIC_DAY	0	0	f	2010-09-25	4352	\N	27139	\N
37324	GENERIC_DAY	0	14400	f	2010-10-04	4354	\N	27139	\N
37325	GENERIC_DAY	0	14400	f	2010-09-14	4352	\N	27139	\N
37326	GENERIC_DAY	0	14400	f	2010-10-13	4354	\N	27139	\N
37327	GENERIC_DAY	0	0	f	2010-09-26	4354	\N	27139	\N
37328	GENERIC_DAY	0	14400	f	2010-10-08	4352	\N	27139	\N
37329	GENERIC_DAY	0	14400	f	2010-10-04	4352	\N	27139	\N
37330	GENERIC_DAY	0	14400	f	2010-10-06	4354	\N	27139	\N
37331	GENERIC_DAY	0	7200	f	2010-09-22	4350	\N	27140	\N
37332	GENERIC_DAY	0	7200	f	2010-09-15	4344	\N	27140	\N
37333	GENERIC_DAY	0	0	f	2010-09-19	4344	\N	27140	\N
37334	GENERIC_DAY	0	7200	f	2010-09-13	4350	\N	27140	\N
37335	GENERIC_DAY	0	7200	f	2010-09-08	4358	\N	27140	\N
37336	GENERIC_DAY	0	0	f	2010-09-25	4344	\N	27140	\N
37337	GENERIC_DAY	0	7200	f	2010-09-24	4344	\N	27140	\N
37338	GENERIC_DAY	0	7200	f	2010-09-24	4350	\N	27140	\N
37339	GENERIC_DAY	0	7200	f	2010-09-17	4348	\N	27140	\N
37340	GENERIC_DAY	0	7200	f	2010-09-16	4348	\N	27140	\N
37341	GENERIC_DAY	0	7200	f	2010-09-27	4348	\N	27140	\N
37342	GENERIC_DAY	0	7200	f	2010-09-20	4348	\N	27140	\N
37343	GENERIC_DAY	0	7200	f	2010-09-15	4350	\N	27140	\N
37344	GENERIC_DAY	0	7200	f	2010-09-30	4350	\N	27140	\N
37345	GENERIC_DAY	0	7200	f	2010-09-17	4358	\N	27140	\N
37346	GENERIC_DAY	0	7200	f	2010-09-16	4358	\N	27140	\N
37347	GENERIC_DAY	0	7200	f	2010-09-30	4358	\N	27140	\N
37348	GENERIC_DAY	0	7200	f	2010-09-13	4348	\N	27140	\N
37349	GENERIC_DAY	0	7200	f	2010-09-09	4344	\N	27140	\N
37350	GENERIC_DAY	0	7200	f	2010-09-17	4350	\N	27140	\N
37351	GENERIC_DAY	0	0	f	2010-09-19	4358	\N	27140	\N
37352	GENERIC_DAY	0	7200	f	2010-09-27	4350	\N	27140	\N
37353	GENERIC_DAY	0	7200	f	2010-09-10	4344	\N	27140	\N
37354	GENERIC_DAY	0	0	f	2010-09-26	4350	\N	27140	\N
37355	GENERIC_DAY	0	7200	f	2010-09-28	4358	\N	27140	\N
37356	GENERIC_DAY	0	7200	f	2010-09-14	4348	\N	27140	\N
37357	GENERIC_DAY	0	7200	f	2010-09-13	4358	\N	27140	\N
37358	GENERIC_DAY	0	7200	f	2010-09-14	4358	\N	27140	\N
37359	GENERIC_DAY	0	0	f	2010-09-18	4348	\N	27140	\N
37360	GENERIC_DAY	0	7200	f	2010-09-22	4348	\N	27140	\N
37361	GENERIC_DAY	0	0	f	2010-09-18	4344	\N	27140	\N
37362	GENERIC_DAY	0	0	f	2010-09-25	4348	\N	27140	\N
37363	GENERIC_DAY	0	7200	f	2010-09-20	4344	\N	27140	\N
37364	GENERIC_DAY	0	7200	f	2010-09-29	4344	\N	27140	\N
37365	GENERIC_DAY	0	7200	f	2010-09-10	4348	\N	27140	\N
37366	GENERIC_DAY	0	7200	f	2010-09-21	4350	\N	27140	\N
37367	GENERIC_DAY	0	0	f	2010-09-25	4358	\N	27140	\N
37368	GENERIC_DAY	0	7200	f	2010-09-24	4358	\N	27140	\N
37369	GENERIC_DAY	0	0	f	2010-09-12	4350	\N	27140	\N
37370	GENERIC_DAY	0	7200	f	2010-09-17	4344	\N	27140	\N
37371	GENERIC_DAY	0	7200	f	2010-10-04	4344	\N	27140	\N
37372	GENERIC_DAY	0	7200	f	2010-09-23	4348	\N	27140	\N
37373	GENERIC_DAY	0	0	f	2010-10-02	4348	\N	27140	\N
37374	GENERIC_DAY	0	0	f	2010-09-18	4358	\N	27140	\N
37375	GENERIC_DAY	0	0	f	2010-09-11	4348	\N	27140	\N
37376	GENERIC_DAY	0	7200	f	2010-09-29	4348	\N	27140	\N
37377	GENERIC_DAY	0	0	f	2010-09-11	4358	\N	27140	\N
37378	GENERIC_DAY	0	7200	f	2010-09-27	4358	\N	27140	\N
37379	GENERIC_DAY	0	7200	f	2010-09-21	4344	\N	27140	\N
37380	GENERIC_DAY	0	7200	f	2010-09-23	4344	\N	27140	\N
37381	GENERIC_DAY	0	7200	f	2010-09-08	4344	\N	27140	\N
37382	GENERIC_DAY	0	7200	f	2010-09-20	4358	\N	27140	\N
37383	GENERIC_DAY	0	0	f	2010-09-19	4350	\N	27140	\N
37384	GENERIC_DAY	0	7200	f	2010-09-16	4344	\N	27140	\N
37385	GENERIC_DAY	0	7200	f	2010-09-28	4348	\N	27140	\N
37386	GENERIC_DAY	0	7200	f	2010-10-01	4344	\N	27140	\N
37387	GENERIC_DAY	0	7200	f	2010-09-27	4344	\N	27140	\N
37388	GENERIC_DAY	0	0	f	2010-10-02	4344	\N	27140	\N
37389	GENERIC_DAY	0	7200	f	2010-09-22	4358	\N	27140	\N
37390	GENERIC_DAY	0	7200	f	2010-09-09	4350	\N	27140	\N
37391	GENERIC_DAY	0	7200	f	2010-09-08	4348	\N	27140	\N
37392	GENERIC_DAY	0	0	f	2010-10-03	4344	\N	27140	\N
37393	GENERIC_DAY	0	7200	f	2010-09-09	4358	\N	27140	\N
37394	GENERIC_DAY	0	0	f	2010-10-02	4350	\N	27140	\N
37395	GENERIC_DAY	0	7200	f	2010-09-10	4358	\N	27140	\N
37396	GENERIC_DAY	0	0	f	2010-09-26	4358	\N	27140	\N
37397	GENERIC_DAY	0	7200	f	2010-09-22	4344	\N	27140	\N
37398	GENERIC_DAY	0	0	f	2010-09-12	4344	\N	27140	\N
44695	GENERIC_DAY	0	7200	f	2010-06-25	4358	\N	42531	\N
44696	GENERIC_DAY	0	3600	f	2010-06-21	21817	\N	42531	\N
44697	GENERIC_DAY	0	3600	f	2010-06-17	4358	\N	42531	\N
44698	GENERIC_DAY	0	7200	f	2010-06-22	4358	\N	42531	\N
44699	GENERIC_DAY	0	0	f	2010-07-01	4344	\N	42531	\N
44700	GENERIC_DAY	0	3600	f	2010-06-15	21817	\N	42531	\N
44701	GENERIC_DAY	0	3600	f	2010-06-18	4358	\N	42531	\N
44702	GENERIC_DAY	0	3600	f	2010-06-18	21817	\N	42531	\N
44703	GENERIC_DAY	0	0	f	2010-06-22	4348	\N	42531	\N
44704	GENERIC_DAY	0	0	f	2010-06-26	4350	\N	42531	\N
44705	GENERIC_DAY	0	3600	f	2010-06-30	4344	\N	42531	\N
44706	GENERIC_DAY	0	7200	f	2010-06-23	4348	\N	42531	\N
44707	GENERIC_DAY	0	3600	f	2010-06-22	4344	\N	42531	\N
44708	GENERIC_DAY	0	7200	f	2010-06-24	4348	\N	42531	\N
44709	GENERIC_DAY	0	0	f	2010-06-28	21817	\N	42531	\N
44710	GENERIC_DAY	0	7200	f	2010-06-23	4358	\N	42531	\N
44711	GENERIC_DAY	0	0	f	2010-06-20	4358	\N	42531	\N
44712	GENERIC_DAY	0	14400	f	2010-06-22	21817	\N	42531	\N
8798	GENERIC_DAY	12	7200	f	2010-07-06	4348	\N	5964	\N
8871	GENERIC_DAY	12	0	f	2010-06-20	4358	\N	5964	\N
8800	GENERIC_DAY	12	0	f	2010-06-19	4358	\N	5964	\N
8796	GENERIC_DAY	12	0	f	2010-07-04	4358	\N	5964	\N
8811	GENERIC_DAY	12	7200	f	2010-07-05	4358	\N	5964	\N
8859	GENERIC_DAY	12	3600	f	2010-07-08	4350	\N	5964	\N
8809	GENERIC_DAY	12	7200	f	2010-06-30	4358	\N	5964	\N
8858	GENERIC_DAY	12	7200	f	2010-06-17	4348	\N	5964	\N
8863	GENERIC_DAY	12	7200	f	2010-07-02	4358	\N	5964	\N
8801	GENERIC_DAY	12	7200	f	2010-06-29	4350	\N	5964	\N
8878	GENERIC_DAY	12	0	f	2010-06-27	4344	\N	5964	\N
8791	GENERIC_DAY	12	0	f	2010-06-19	4348	\N	5964	\N
8810	GENERIC_DAY	12	7200	f	2010-06-24	4344	\N	5964	\N
8820	GENERIC_DAY	12	7200	f	2010-07-06	4344	\N	5964	\N
8865	GENERIC_DAY	12	0	f	2010-06-27	4350	\N	5964	\N
37399	GENERIC_DAY	0	0	f	2010-09-18	4350	\N	27140	\N
37400	GENERIC_DAY	0	7200	f	2010-09-10	4350	\N	27140	\N
37401	GENERIC_DAY	0	0	f	2010-10-03	4358	\N	27140	\N
37402	GENERIC_DAY	0	7200	f	2010-09-24	4348	\N	27140	\N
37403	GENERIC_DAY	0	0	f	2010-09-11	4344	\N	27140	\N
37404	GENERIC_DAY	0	7200	f	2010-09-15	4358	\N	27140	\N
37405	GENERIC_DAY	0	0	f	2010-09-25	4350	\N	27140	\N
37406	GENERIC_DAY	0	0	f	2010-09-19	4348	\N	27140	\N
37407	GENERIC_DAY	0	7200	f	2010-09-20	4350	\N	27140	\N
37408	GENERIC_DAY	0	7200	f	2010-09-21	4348	\N	27140	\N
37409	GENERIC_DAY	0	7200	f	2010-10-01	4348	\N	27140	\N
37410	GENERIC_DAY	0	0	f	2010-09-26	4348	\N	27140	\N
37411	GENERIC_DAY	0	0	f	2010-10-03	4350	\N	27140	\N
37412	GENERIC_DAY	0	0	f	2010-09-26	4344	\N	27140	\N
37413	GENERIC_DAY	0	7200	f	2010-09-23	4358	\N	27140	\N
37414	GENERIC_DAY	0	7200	f	2010-09-13	4344	\N	27140	\N
37415	GENERIC_DAY	0	7200	f	2010-10-01	4350	\N	27140	\N
37416	GENERIC_DAY	0	7200	f	2010-09-15	4348	\N	27140	\N
37417	GENERIC_DAY	0	7200	f	2010-09-14	4350	\N	27140	\N
37418	GENERIC_DAY	0	0	f	2010-09-11	4350	\N	27140	\N
37419	GENERIC_DAY	0	0	f	2010-10-03	4348	\N	27140	\N
37420	GENERIC_DAY	0	7200	f	2010-09-09	4348	\N	27140	\N
37421	GENERIC_DAY	0	7200	f	2010-09-28	4350	\N	27140	\N
37422	GENERIC_DAY	0	7200	f	2010-09-21	4358	\N	27140	\N
37423	GENERIC_DAY	0	7200	f	2010-10-01	4358	\N	27140	\N
37424	GENERIC_DAY	0	7200	f	2010-10-04	4348	\N	27140	\N
37425	GENERIC_DAY	0	7200	f	2010-09-28	4344	\N	27140	\N
37426	GENERIC_DAY	0	7200	f	2010-09-23	4350	\N	27140	\N
37427	GENERIC_DAY	0	3600	f	2010-10-04	4358	\N	27140	\N
37428	GENERIC_DAY	0	7200	f	2010-09-14	4344	\N	27140	\N
37429	GENERIC_DAY	0	7200	f	2010-09-29	4358	\N	27140	\N
37430	GENERIC_DAY	0	0	f	2010-09-12	4348	\N	27140	\N
37431	GENERIC_DAY	0	7200	f	2010-09-30	4344	\N	27140	\N
37432	GENERIC_DAY	0	0	f	2010-10-02	4358	\N	27140	\N
37433	GENERIC_DAY	0	3600	f	2010-10-04	4350	\N	27140	\N
37434	GENERIC_DAY	0	7200	f	2010-09-16	4350	\N	27140	\N
37435	GENERIC_DAY	0	7200	f	2010-09-29	4350	\N	27140	\N
37436	GENERIC_DAY	0	7200	f	2010-09-30	4348	\N	27140	\N
37437	GENERIC_DAY	0	0	f	2010-09-12	4358	\N	27140	\N
37438	GENERIC_DAY	0	7200	f	2010-09-08	4350	\N	27140	\N
37439	GENERIC_DAY	0	7200	f	2010-09-16	4348	\N	27141	\N
37440	GENERIC_DAY	0	7200	f	2010-09-14	4358	\N	27141	\N
37441	GENERIC_DAY	0	0	f	2010-09-12	4348	\N	27141	\N
37442	GENERIC_DAY	0	0	f	2010-09-19	4350	\N	27141	\N
37443	GENERIC_DAY	0	7200	f	2010-09-20	4358	\N	27141	\N
37444	GENERIC_DAY	0	7200	f	2010-09-21	4344	\N	27141	\N
37445	GENERIC_DAY	0	7200	f	2010-09-14	4350	\N	27141	\N
37446	GENERIC_DAY	0	7200	f	2010-09-16	4358	\N	27141	\N
37447	GENERIC_DAY	0	7200	f	2010-09-23	4348	\N	27141	\N
37448	GENERIC_DAY	0	0	f	2010-09-11	4348	\N	27141	\N
37449	GENERIC_DAY	0	7200	f	2010-09-10	4344	\N	27141	\N
37450	GENERIC_DAY	0	7200	f	2010-09-14	4348	\N	27141	\N
37451	GENERIC_DAY	0	7200	f	2010-09-08	4344	\N	27141	\N
37452	GENERIC_DAY	0	3600	f	2010-09-24	4350	\N	27141	\N
37453	GENERIC_DAY	0	7200	f	2010-09-24	4344	\N	27141	\N
37454	GENERIC_DAY	0	7200	f	2010-09-09	4350	\N	27141	\N
37455	GENERIC_DAY	0	7200	f	2010-09-16	4344	\N	27141	\N
37456	GENERIC_DAY	0	3600	f	2010-09-24	4348	\N	27141	\N
37457	GENERIC_DAY	0	0	f	2010-09-18	4348	\N	27141	\N
37458	GENERIC_DAY	0	0	f	2010-09-12	4350	\N	27141	\N
37459	GENERIC_DAY	0	7200	f	2010-09-09	4358	\N	27141	\N
37460	GENERIC_DAY	0	7200	f	2010-09-17	4350	\N	27141	\N
37461	GENERIC_DAY	0	7200	f	2010-09-09	4344	\N	27141	\N
37462	GENERIC_DAY	0	7200	f	2010-09-20	4348	\N	27141	\N
37463	GENERIC_DAY	0	0	f	2010-09-11	4358	\N	27141	\N
37464	GENERIC_DAY	0	7200	f	2010-09-08	4358	\N	27141	\N
37465	GENERIC_DAY	0	7200	f	2010-09-14	4344	\N	27141	\N
37466	GENERIC_DAY	0	7200	f	2010-09-21	4358	\N	27141	\N
37467	GENERIC_DAY	0	7200	f	2010-09-13	4348	\N	27141	\N
37468	GENERIC_DAY	0	7200	f	2010-09-16	4350	\N	27141	\N
37469	GENERIC_DAY	0	7200	f	2010-09-17	4348	\N	27141	\N
37470	GENERIC_DAY	0	0	f	2010-09-18	4358	\N	27141	\N
37471	GENERIC_DAY	0	0	f	2010-09-12	4358	\N	27141	\N
37472	GENERIC_DAY	0	7200	f	2010-09-15	4348	\N	27141	\N
37473	GENERIC_DAY	0	7200	f	2010-09-17	4358	\N	27141	\N
37474	GENERIC_DAY	0	7200	f	2010-09-23	4350	\N	27141	\N
37475	GENERIC_DAY	0	7200	f	2010-09-22	4358	\N	27141	\N
37476	GENERIC_DAY	0	7200	f	2010-09-22	4344	\N	27141	\N
37477	GENERIC_DAY	0	7200	f	2010-09-20	4344	\N	27141	\N
37478	GENERIC_DAY	0	7200	f	2010-09-23	4344	\N	27141	\N
37479	GENERIC_DAY	0	7200	f	2010-09-15	4344	\N	27141	\N
37480	GENERIC_DAY	0	7200	f	2010-09-09	4348	\N	27141	\N
37481	GENERIC_DAY	0	0	f	2010-09-12	4344	\N	27141	\N
37482	GENERIC_DAY	0	0	f	2010-09-19	4344	\N	27141	\N
37483	GENERIC_DAY	0	7200	f	2010-09-15	4358	\N	27141	\N
37484	GENERIC_DAY	0	7200	f	2010-09-13	4344	\N	27141	\N
37485	GENERIC_DAY	0	7200	f	2010-09-13	4358	\N	27141	\N
37486	GENERIC_DAY	0	0	f	2010-09-19	4358	\N	27141	\N
37487	GENERIC_DAY	0	0	f	2010-09-11	4344	\N	27141	\N
37488	GENERIC_DAY	0	7200	f	2010-09-21	4348	\N	27141	\N
37489	GENERIC_DAY	0	7200	f	2010-09-22	4350	\N	27141	\N
37490	GENERIC_DAY	0	7200	f	2010-09-13	4350	\N	27141	\N
37491	GENERIC_DAY	0	7200	f	2010-09-17	4344	\N	27141	\N
37492	GENERIC_DAY	0	7200	f	2010-09-23	4358	\N	27141	\N
37493	GENERIC_DAY	0	0	f	2010-09-11	4350	\N	27141	\N
37494	GENERIC_DAY	0	7200	f	2010-09-20	4350	\N	27141	\N
37495	GENERIC_DAY	0	7200	f	2010-09-08	4348	\N	27141	\N
37496	GENERIC_DAY	0	7200	f	2010-09-08	4350	\N	27141	\N
37497	GENERIC_DAY	0	0	f	2010-09-19	4348	\N	27141	\N
37498	GENERIC_DAY	0	7200	f	2010-09-21	4350	\N	27141	\N
37499	GENERIC_DAY	0	0	f	2010-09-18	4344	\N	27141	\N
37500	GENERIC_DAY	0	0	f	2010-09-18	4350	\N	27141	\N
37501	GENERIC_DAY	0	3600	f	2010-09-24	4358	\N	27141	\N
37502	GENERIC_DAY	0	7200	f	2010-09-22	4348	\N	27141	\N
37503	GENERIC_DAY	0	7200	f	2010-09-10	4358	\N	27141	\N
37504	GENERIC_DAY	0	7200	f	2010-09-10	4350	\N	27141	\N
37505	GENERIC_DAY	0	7200	f	2010-09-10	4348	\N	27141	\N
37506	GENERIC_DAY	0	7200	f	2010-09-15	4350	\N	27141	\N
37507	GENERIC_DAY	0	14400	f	2010-11-03	4352	\N	27142	\N
37508	GENERIC_DAY	0	14400	f	2010-10-08	4354	\N	27142	\N
37509	GENERIC_DAY	0	14400	f	2010-10-21	4354	\N	27142	\N
37510	GENERIC_DAY	0	14400	f	2010-10-18	4354	\N	27142	\N
37511	GENERIC_DAY	0	14400	f	2010-11-05	4354	\N	27142	\N
37512	GENERIC_DAY	0	14400	f	2010-10-07	4352	\N	27142	\N
37513	GENERIC_DAY	0	0	f	2010-10-30	4354	\N	27142	\N
37514	GENERIC_DAY	0	14400	f	2010-11-03	4354	\N	27142	\N
37515	GENERIC_DAY	0	14400	f	2010-10-14	4354	\N	27142	\N
37516	GENERIC_DAY	0	0	f	2010-10-10	4352	\N	27142	\N
37517	GENERIC_DAY	0	14400	f	2010-11-01	4354	\N	27142	\N
37518	GENERIC_DAY	0	14400	f	2010-10-08	4352	\N	27142	\N
37519	GENERIC_DAY	0	14400	f	2010-10-19	4354	\N	27142	\N
37520	GENERIC_DAY	0	14400	f	2010-10-11	4354	\N	27142	\N
37521	GENERIC_DAY	0	0	f	2010-10-17	4354	\N	27142	\N
37522	GENERIC_DAY	0	0	f	2010-10-09	4354	\N	27142	\N
37523	GENERIC_DAY	0	14400	f	2010-10-26	4354	\N	27142	\N
37524	GENERIC_DAY	0	14400	f	2010-10-06	4354	\N	27142	\N
37525	GENERIC_DAY	0	14400	f	2010-10-11	4352	\N	27142	\N
37526	GENERIC_DAY	0	14400	f	2010-10-05	4352	\N	27142	\N
37527	GENERIC_DAY	0	14400	f	2010-11-02	4352	\N	27142	\N
37528	GENERIC_DAY	0	14400	f	2010-10-12	4352	\N	27142	\N
37529	GENERIC_DAY	0	14400	f	2010-11-08	4352	\N	27142	\N
37530	GENERIC_DAY	0	0	f	2010-10-31	4352	\N	27142	\N
37531	GENERIC_DAY	0	14400	f	2010-10-19	4352	\N	27142	\N
37532	GENERIC_DAY	0	14400	f	2010-10-07	4354	\N	27142	\N
37533	GENERIC_DAY	0	14400	f	2010-10-29	4354	\N	27142	\N
37534	GENERIC_DAY	0	14400	f	2010-10-26	4352	\N	27142	\N
37535	GENERIC_DAY	0	0	f	2010-11-07	4354	\N	27142	\N
37536	GENERIC_DAY	0	0	f	2010-10-09	4352	\N	27142	\N
37537	GENERIC_DAY	0	14400	f	2010-11-01	4352	\N	27142	\N
37538	GENERIC_DAY	0	14400	f	2010-10-13	4354	\N	27142	\N
37539	GENERIC_DAY	0	14400	f	2010-10-25	4354	\N	27142	\N
37540	GENERIC_DAY	0	14400	f	2010-10-28	4352	\N	27142	\N
37541	GENERIC_DAY	0	0	f	2010-11-07	4352	\N	27142	\N
37542	GENERIC_DAY	0	14400	f	2010-10-27	4352	\N	27142	\N
37543	GENERIC_DAY	0	14400	f	2010-10-13	4352	\N	27142	\N
37544	GENERIC_DAY	0	0	f	2010-10-23	4352	\N	27142	\N
37545	GENERIC_DAY	0	14400	f	2010-10-21	4352	\N	27142	\N
37546	GENERIC_DAY	0	14400	f	2010-10-14	4352	\N	27142	\N
37547	GENERIC_DAY	0	0	f	2010-10-23	4354	\N	27142	\N
37548	GENERIC_DAY	0	0	f	2010-11-06	4354	\N	27142	\N
37549	GENERIC_DAY	0	14400	f	2010-10-28	4354	\N	27142	\N
37550	GENERIC_DAY	0	0	f	2010-10-17	4352	\N	27142	\N
37551	GENERIC_DAY	0	0	f	2010-11-06	4352	\N	27142	\N
37552	GENERIC_DAY	0	14400	f	2010-10-25	4352	\N	27142	\N
37553	GENERIC_DAY	0	14400	f	2010-10-20	4354	\N	27142	\N
37554	GENERIC_DAY	0	14400	f	2010-10-15	4354	\N	27142	\N
37555	GENERIC_DAY	0	0	f	2010-10-16	4354	\N	27142	\N
37556	GENERIC_DAY	0	14400	f	2010-10-20	4352	\N	27142	\N
37557	GENERIC_DAY	0	14400	f	2010-10-29	4352	\N	27142	\N
37558	GENERIC_DAY	0	14400	f	2010-10-22	4352	\N	27142	\N
37559	GENERIC_DAY	0	0	f	2010-10-24	4354	\N	27142	\N
37560	GENERIC_DAY	0	14400	f	2010-11-02	4354	\N	27142	\N
37561	GENERIC_DAY	0	14400	f	2010-11-04	4352	\N	27142	\N
37562	GENERIC_DAY	0	14400	f	2010-11-04	4354	\N	27142	\N
37563	GENERIC_DAY	0	0	f	2010-10-24	4352	\N	27142	\N
37564	GENERIC_DAY	0	14400	f	2010-10-05	4354	\N	27142	\N
37565	GENERIC_DAY	0	14400	f	2010-11-05	4352	\N	27142	\N
37566	GENERIC_DAY	0	14400	f	2010-11-08	4354	\N	27142	\N
37567	GENERIC_DAY	0	14400	f	2010-10-15	4352	\N	27142	\N
8793	GENERIC_DAY	12	7200	f	2010-06-22	4358	\N	5964	\N
8818	GENERIC_DAY	12	3600	f	2010-07-08	4358	\N	5964	\N
8794	GENERIC_DAY	12	7200	f	2010-06-15	4350	\N	5964	\N
8813	GENERIC_DAY	12	7200	f	2010-06-29	4344	\N	5964	\N
8848	GENERIC_DAY	12	7200	f	2010-06-16	4358	\N	5964	\N
8837	GENERIC_DAY	12	7200	f	2010-06-28	4358	\N	5964	\N
8831	GENERIC_DAY	12	0	f	2010-06-26	4358	\N	5964	\N
8882	GENERIC_DAY	12	7200	f	2010-06-25	4350	\N	5964	\N
8868	GENERIC_DAY	12	7200	f	2010-06-18	4348	\N	5964	\N
8825	GENERIC_DAY	12	7200	f	2010-06-23	4350	\N	5964	\N
8790	GENERIC_DAY	12	7200	f	2010-07-01	4348	\N	5964	\N
8805	GENERIC_DAY	12	7200	f	2010-06-28	4344	\N	5964	\N
8834	GENERIC_DAY	12	0	f	2010-06-19	4344	\N	5964	\N
8852	GENERIC_DAY	12	7200	f	2010-07-02	4344	\N	5964	\N
8880	GENERIC_DAY	12	7200	f	2010-06-15	4348	\N	5964	\N
8816	GENERIC_DAY	12	7200	f	2010-06-21	4344	\N	5964	\N
8840	GENERIC_DAY	12	7200	f	2010-06-30	4350	\N	5964	\N
8844	GENERIC_DAY	12	7200	f	2010-06-23	4344	\N	5964	\N
8832	GENERIC_DAY	12	7200	f	2010-06-15	4344	\N	5964	\N
8808	GENERIC_DAY	12	7200	f	2010-06-22	4344	\N	5964	\N
8838	GENERIC_DAY	12	7200	f	2010-06-25	4358	\N	5964	\N
64461	GENERIC_DAY	1	3600	f	2010-06-18	4352	\N	53632	\N
37568	GENERIC_DAY	0	14400	f	2010-10-22	4354	\N	27142	\N
37569	GENERIC_DAY	0	14400	f	2010-10-12	4354	\N	27142	\N
37570	GENERIC_DAY	0	14400	f	2010-10-06	4352	\N	27142	\N
37571	GENERIC_DAY	0	14400	f	2010-10-27	4354	\N	27142	\N
37572	GENERIC_DAY	0	0	f	2010-10-30	4352	\N	27142	\N
37573	GENERIC_DAY	0	0	f	2010-10-31	4354	\N	27142	\N
37574	GENERIC_DAY	0	14400	f	2010-10-18	4352	\N	27142	\N
37575	GENERIC_DAY	0	0	f	2010-10-16	4352	\N	27142	\N
37576	GENERIC_DAY	0	0	f	2010-10-10	4354	\N	27142	\N
37577	GENERIC_DAY	0	0	f	2010-10-30	4352	\N	27143	\N
37578	GENERIC_DAY	0	0	f	2010-10-24	4352	\N	27143	\N
37579	GENERIC_DAY	0	7200	f	2010-11-02	4352	\N	27143	\N
37580	GENERIC_DAY	0	14400	f	2010-10-22	4354	\N	27143	\N
37581	GENERIC_DAY	0	0	f	2010-10-31	4352	\N	27143	\N
37582	GENERIC_DAY	0	14400	f	2010-10-29	4352	\N	27143	\N
37583	GENERIC_DAY	0	14400	f	2010-10-26	4354	\N	27143	\N
37584	GENERIC_DAY	0	14400	f	2010-10-28	4354	\N	27143	\N
37585	GENERIC_DAY	0	14400	f	2010-10-22	4352	\N	27143	\N
64462	GENERIC_DAY	1	0	f	2010-07-05	4354	\N	53632	\N
37586	GENERIC_DAY	0	0	f	2010-10-24	4354	\N	27143	\N
37587	GENERIC_DAY	0	14400	f	2010-10-28	4352	\N	27143	\N
37588	GENERIC_DAY	0	0	f	2010-10-17	4354	\N	27143	\N
37589	GENERIC_DAY	0	14400	f	2010-10-25	4354	\N	27143	\N
37590	GENERIC_DAY	0	0	f	2010-10-17	4352	\N	27143	\N
37591	GENERIC_DAY	0	14400	f	2010-10-26	4352	\N	27143	\N
37592	GENERIC_DAY	0	14400	f	2010-11-01	4354	\N	27143	\N
37593	GENERIC_DAY	0	14400	f	2010-10-21	4354	\N	27143	\N
37594	GENERIC_DAY	0	14400	f	2010-10-19	4354	\N	27143	\N
37595	GENERIC_DAY	0	14400	f	2010-10-29	4354	\N	27143	\N
37596	GENERIC_DAY	0	0	f	2010-10-23	4352	\N	27143	\N
37597	GENERIC_DAY	0	14400	f	2010-10-19	4352	\N	27143	\N
37598	GENERIC_DAY	0	0	f	2010-10-16	4352	\N	27143	\N
37599	GENERIC_DAY	0	14400	f	2010-10-18	4352	\N	27143	\N
37600	GENERIC_DAY	0	0	f	2010-10-23	4354	\N	27143	\N
37601	GENERIC_DAY	0	14400	f	2010-10-21	4352	\N	27143	\N
37602	GENERIC_DAY	0	0	f	2010-10-16	4354	\N	27143	\N
37603	GENERIC_DAY	0	14400	f	2010-10-20	4352	\N	27143	\N
37604	GENERIC_DAY	0	14400	f	2010-10-18	4354	\N	27143	\N
37605	GENERIC_DAY	0	7200	f	2010-11-02	4354	\N	27143	\N
37606	GENERIC_DAY	0	0	f	2010-10-30	4354	\N	27143	\N
37607	GENERIC_DAY	0	14400	f	2010-10-15	4354	\N	27143	\N
37608	GENERIC_DAY	0	14400	f	2010-10-15	4352	\N	27143	\N
37609	GENERIC_DAY	0	14400	f	2010-10-27	4354	\N	27143	\N
37610	GENERIC_DAY	0	0	f	2010-10-31	4354	\N	27143	\N
37611	GENERIC_DAY	0	14400	f	2010-10-27	4352	\N	27143	\N
37612	GENERIC_DAY	0	14400	f	2010-10-25	4352	\N	27143	\N
37613	GENERIC_DAY	0	14400	f	2010-10-20	4354	\N	27143	\N
37614	GENERIC_DAY	0	14400	f	2010-11-01	4352	\N	27143	\N
37615	GENERIC_DAY	0	14400	f	2010-10-26	4354	\N	27144	\N
37616	GENERIC_DAY	0	0	f	2010-10-03	4354	\N	27144	\N
37617	GENERIC_DAY	0	14400	f	2010-10-18	4354	\N	27144	\N
37618	GENERIC_DAY	0	14400	f	2010-10-25	4352	\N	27144	\N
37619	GENERIC_DAY	0	14400	f	2010-10-19	4354	\N	27144	\N
37620	GENERIC_DAY	0	14400	f	2010-09-28	4352	\N	27144	\N
37621	GENERIC_DAY	0	0	f	2010-09-25	4354	\N	27144	\N
37622	GENERIC_DAY	0	14400	f	2010-10-20	4354	\N	27144	\N
37623	GENERIC_DAY	0	0	f	2010-10-02	4354	\N	27144	\N
37624	GENERIC_DAY	0	0	f	2010-10-16	4352	\N	27144	\N
37625	GENERIC_DAY	0	14400	f	2010-10-27	4352	\N	27144	\N
37626	GENERIC_DAY	0	0	f	2010-10-23	4352	\N	27144	\N
37627	GENERIC_DAY	0	0	f	2010-10-16	4354	\N	27144	\N
37628	GENERIC_DAY	0	14400	f	2010-10-06	4354	\N	27144	\N
37629	GENERIC_DAY	0	14400	f	2010-10-21	4354	\N	27144	\N
37630	GENERIC_DAY	0	0	f	2010-10-03	4352	\N	27144	\N
37631	GENERIC_DAY	0	0	f	2010-10-24	4352	\N	27144	\N
37632	GENERIC_DAY	0	14400	f	2010-10-05	4352	\N	27144	\N
37633	GENERIC_DAY	0	14400	f	2010-09-30	4354	\N	27144	\N
37634	GENERIC_DAY	0	14400	f	2010-09-30	4352	\N	27144	\N
37635	GENERIC_DAY	0	14400	f	2010-10-15	4352	\N	27144	\N
37636	GENERIC_DAY	0	0	f	2010-10-10	4354	\N	27144	\N
37637	GENERIC_DAY	0	0	f	2010-10-23	4354	\N	27144	\N
37638	GENERIC_DAY	0	14400	f	2010-10-13	4352	\N	27144	\N
37639	GENERIC_DAY	0	0	f	2010-10-10	4352	\N	27144	\N
37640	GENERIC_DAY	0	14400	f	2010-10-15	4354	\N	27144	\N
37641	GENERIC_DAY	0	14400	f	2010-10-11	4354	\N	27144	\N
37642	GENERIC_DAY	0	14400	f	2010-10-11	4352	\N	27144	\N
37643	GENERIC_DAY	0	14400	f	2010-09-27	4352	\N	27144	\N
37644	GENERIC_DAY	0	0	f	2010-09-26	4354	\N	27144	\N
37645	GENERIC_DAY	0	0	f	2010-10-24	4354	\N	27144	\N
37646	GENERIC_DAY	0	14400	f	2010-10-18	4352	\N	27144	\N
37647	GENERIC_DAY	0	14400	f	2010-10-22	4354	\N	27144	\N
37648	GENERIC_DAY	0	14400	f	2010-10-19	4352	\N	27144	\N
37649	GENERIC_DAY	0	14400	f	2010-10-05	4354	\N	27144	\N
37650	GENERIC_DAY	0	14400	f	2010-10-25	4354	\N	27144	\N
37651	GENERIC_DAY	0	14400	f	2010-10-04	4354	\N	27144	\N
37652	GENERIC_DAY	0	14400	f	2010-10-12	4352	\N	27144	\N
37653	GENERIC_DAY	0	14400	f	2010-10-27	4354	\N	27144	\N
37654	GENERIC_DAY	0	14400	f	2010-09-28	4354	\N	27144	\N
37655	GENERIC_DAY	0	14400	f	2010-10-29	4352	\N	27144	\N
37656	GENERIC_DAY	0	14400	f	2010-10-08	4354	\N	27144	\N
37657	GENERIC_DAY	0	0	f	2010-10-09	4352	\N	27144	\N
37658	GENERIC_DAY	0	14400	f	2010-10-28	4354	\N	27144	\N
37659	GENERIC_DAY	0	14400	f	2010-10-29	4354	\N	27144	\N
37660	GENERIC_DAY	0	14400	f	2010-10-22	4352	\N	27144	\N
37661	GENERIC_DAY	0	0	f	2010-09-26	4352	\N	27144	\N
37662	GENERIC_DAY	0	14400	f	2010-10-26	4352	\N	27144	\N
37663	GENERIC_DAY	0	14400	f	2010-09-29	4354	\N	27144	\N
37664	GENERIC_DAY	0	14400	f	2010-10-06	4352	\N	27144	\N
37665	GENERIC_DAY	0	14400	f	2010-10-28	4352	\N	27144	\N
37666	GENERIC_DAY	0	0	f	2010-09-25	4352	\N	27144	\N
37667	GENERIC_DAY	0	14400	f	2010-10-12	4354	\N	27144	\N
37668	GENERIC_DAY	0	14400	f	2010-10-07	4352	\N	27144	\N
37669	GENERIC_DAY	0	14400	f	2010-10-21	4352	\N	27144	\N
37670	GENERIC_DAY	0	14400	f	2010-09-29	4352	\N	27144	\N
37671	GENERIC_DAY	0	14400	f	2010-10-07	4354	\N	27144	\N
37672	GENERIC_DAY	0	14400	f	2010-10-14	4352	\N	27144	\N
37673	GENERIC_DAY	0	0	f	2010-10-17	4352	\N	27144	\N
37674	GENERIC_DAY	0	14400	f	2010-10-04	4352	\N	27144	\N
37675	GENERIC_DAY	0	0	f	2010-10-17	4354	\N	27144	\N
37676	GENERIC_DAY	0	14400	f	2010-10-01	4352	\N	27144	\N
37677	GENERIC_DAY	0	14400	f	2010-10-14	4354	\N	27144	\N
37678	GENERIC_DAY	0	14400	f	2010-09-27	4354	\N	27144	\N
37679	GENERIC_DAY	0	14400	f	2010-10-01	4354	\N	27144	\N
37680	GENERIC_DAY	0	0	f	2010-10-02	4352	\N	27144	\N
37681	GENERIC_DAY	0	14400	f	2010-10-13	4354	\N	27144	\N
37682	GENERIC_DAY	0	0	f	2010-10-09	4354	\N	27144	\N
37683	GENERIC_DAY	0	14400	f	2010-10-08	4352	\N	27144	\N
37684	GENERIC_DAY	0	14400	f	2010-10-20	4352	\N	27144	\N
37685	GENERIC_DAY	0	14400	f	2010-09-10	4352	\N	27145	\N
37686	GENERIC_DAY	0	14400	f	2010-09-13	4354	\N	27145	\N
37687	GENERIC_DAY	0	14400	f	2010-09-30	4352	\N	27145	\N
37688	GENERIC_DAY	0	14400	f	2010-10-06	4352	\N	27145	\N
37689	GENERIC_DAY	0	0	f	2010-10-02	4354	\N	27145	\N
37690	GENERIC_DAY	0	14400	f	2010-10-12	4352	\N	27145	\N
37691	GENERIC_DAY	0	14400	f	2010-10-11	4354	\N	27145	\N
37692	GENERIC_DAY	0	14400	f	2010-09-23	4354	\N	27145	\N
37693	GENERIC_DAY	0	14400	f	2010-09-29	4354	\N	27145	\N
37694	GENERIC_DAY	0	14400	f	2010-09-10	4354	\N	27145	\N
37695	GENERIC_DAY	0	0	f	2010-10-10	4352	\N	27145	\N
37696	GENERIC_DAY	0	0	f	2010-09-11	4352	\N	27145	\N
37697	GENERIC_DAY	0	0	f	2010-10-09	4354	\N	27145	\N
37698	GENERIC_DAY	0	14400	f	2010-09-24	4354	\N	27145	\N
37699	GENERIC_DAY	0	14400	f	2010-10-04	4352	\N	27145	\N
37700	GENERIC_DAY	0	14400	f	2010-09-28	4354	\N	27145	\N
37701	GENERIC_DAY	0	14400	f	2010-10-07	4352	\N	27145	\N
37702	GENERIC_DAY	0	0	f	2010-10-03	4354	\N	27145	\N
37703	GENERIC_DAY	0	14400	f	2010-09-20	4354	\N	27145	\N
37704	GENERIC_DAY	0	14400	f	2010-10-12	4354	\N	27145	\N
37705	GENERIC_DAY	0	14400	f	2010-10-06	4354	\N	27145	\N
37706	GENERIC_DAY	0	14400	f	2010-10-01	4354	\N	27145	\N
37707	GENERIC_DAY	0	14400	f	2010-09-17	4354	\N	27145	\N
37708	GENERIC_DAY	0	14400	f	2010-09-08	4352	\N	27145	\N
37709	GENERIC_DAY	0	14400	f	2010-09-15	4352	\N	27145	\N
37710	GENERIC_DAY	0	14400	f	2010-10-01	4352	\N	27145	\N
37711	GENERIC_DAY	0	0	f	2010-09-12	4354	\N	27145	\N
37712	GENERIC_DAY	0	0	f	2010-09-18	4352	\N	27145	\N
37713	GENERIC_DAY	0	0	f	2010-10-09	4352	\N	27145	\N
37714	GENERIC_DAY	0	14400	f	2010-09-14	4354	\N	27145	\N
37715	GENERIC_DAY	0	14400	f	2010-09-09	4352	\N	27145	\N
37716	GENERIC_DAY	0	0	f	2010-10-03	4352	\N	27145	\N
37717	GENERIC_DAY	0	0	f	2010-09-12	4352	\N	27145	\N
37718	GENERIC_DAY	0	14400	f	2010-09-21	4352	\N	27145	\N
37719	GENERIC_DAY	0	14400	f	2010-09-23	4352	\N	27145	\N
37720	GENERIC_DAY	0	14400	f	2010-09-17	4352	\N	27145	\N
37721	GENERIC_DAY	0	14400	f	2010-09-16	4354	\N	27145	\N
37722	GENERIC_DAY	0	14400	f	2010-09-15	4354	\N	27145	\N
37723	GENERIC_DAY	0	14400	f	2010-09-22	4354	\N	27145	\N
37724	GENERIC_DAY	0	14400	f	2010-10-11	4352	\N	27145	\N
37725	GENERIC_DAY	0	14400	f	2010-09-08	4354	\N	27145	\N
37726	GENERIC_DAY	0	14400	f	2010-10-05	4354	\N	27145	\N
37727	GENERIC_DAY	0	14400	f	2010-09-24	4352	\N	27145	\N
37728	GENERIC_DAY	0	14400	f	2010-09-20	4352	\N	27145	\N
37729	GENERIC_DAY	0	0	f	2010-10-02	4352	\N	27145	\N
37730	GENERIC_DAY	0	14400	f	2010-09-27	4352	\N	27145	\N
37731	GENERIC_DAY	0	0	f	2010-09-19	4354	\N	27145	\N
37732	GENERIC_DAY	0	0	f	2010-09-25	4352	\N	27145	\N
37733	GENERIC_DAY	0	14400	f	2010-09-14	4352	\N	27145	\N
37734	GENERIC_DAY	0	14400	f	2010-09-21	4354	\N	27145	\N
37735	GENERIC_DAY	0	0	f	2010-09-19	4352	\N	27145	\N
37736	GENERIC_DAY	0	0	f	2010-09-18	4354	\N	27145	\N
64463	GENERIC_DAY	1	0	f	2010-07-06	4354	\N	53632	\N
64464	GENERIC_DAY	1	25200	f	2010-06-15	4354	\N	53632	\N
64465	GENERIC_DAY	1	0	f	2010-07-11	4352	\N	53632	\N
64466	GENERIC_DAY	1	0	f	2010-07-03	4354	\N	53632	\N
64467	GENERIC_DAY	1	0	f	2010-07-20	4354	\N	53632	\N
64468	GENERIC_DAY	1	28800	f	2010-07-02	4352	\N	53632	\N
64469	GENERIC_DAY	1	0	f	2010-06-19	4352	\N	53632	\N
64470	GENERIC_DAY	1	28800	f	2010-07-08	4352	\N	53632	\N
64471	GENERIC_DAY	1	28800	f	2010-07-01	4352	\N	53632	\N
64472	GENERIC_DAY	1	0	f	2010-06-20	4352	\N	53632	\N
64473	GENERIC_DAY	1	0	f	2010-07-18	4354	\N	53632	\N
37737	GENERIC_DAY	0	14400	f	2010-10-08	4352	\N	27145	\N
37738	GENERIC_DAY	0	14400	f	2010-09-09	4354	\N	27145	\N
37739	GENERIC_DAY	0	14400	f	2010-10-07	4354	\N	27145	\N
37740	GENERIC_DAY	0	14400	f	2010-10-05	4352	\N	27145	\N
37741	GENERIC_DAY	0	14400	f	2010-09-27	4354	\N	27145	\N
37742	GENERIC_DAY	0	14400	f	2010-09-29	4352	\N	27145	\N
37743	GENERIC_DAY	0	14400	f	2010-10-08	4354	\N	27145	\N
37744	GENERIC_DAY	0	14400	f	2010-09-28	4352	\N	27145	\N
37745	GENERIC_DAY	0	14400	f	2010-09-16	4352	\N	27145	\N
37746	GENERIC_DAY	0	0	f	2010-09-25	4354	\N	27145	\N
37747	GENERIC_DAY	0	0	f	2010-09-26	4352	\N	27145	\N
37748	GENERIC_DAY	0	14400	f	2010-09-30	4354	\N	27145	\N
37749	GENERIC_DAY	0	14400	f	2010-09-22	4352	\N	27145	\N
37750	GENERIC_DAY	0	0	f	2010-10-10	4354	\N	27145	\N
37751	GENERIC_DAY	0	0	f	2010-09-11	4354	\N	27145	\N
37752	GENERIC_DAY	0	14400	f	2010-10-04	4354	\N	27145	\N
37753	GENERIC_DAY	0	14400	f	2010-09-13	4352	\N	27145	\N
37754	GENERIC_DAY	0	0	f	2010-09-26	4354	\N	27145	\N
37755	GENERIC_DAY	0	0	f	2011-01-16	4354	\N	27146	\N
37756	GENERIC_DAY	0	14400	f	2010-11-30	4352	\N	27146	\N
37757	GENERIC_DAY	0	0	f	2010-11-20	4354	\N	27146	\N
37758	GENERIC_DAY	0	14400	f	2010-12-28	4352	\N	27146	\N
37759	GENERIC_DAY	0	14400	f	2011-01-14	4352	\N	27146	\N
37760	GENERIC_DAY	0	14400	f	2010-11-29	4354	\N	27146	\N
37761	GENERIC_DAY	0	14400	f	2011-01-04	4354	\N	27146	\N
37762	GENERIC_DAY	0	14400	f	2010-11-22	4352	\N	27146	\N
37763	GENERIC_DAY	0	14400	f	2010-11-17	4352	\N	27146	\N
37764	GENERIC_DAY	0	14400	f	2010-12-15	4352	\N	27146	\N
37765	GENERIC_DAY	0	14400	f	2010-11-10	4354	\N	27146	\N
37766	GENERIC_DAY	0	14400	f	2010-12-16	4352	\N	27146	\N
37767	GENERIC_DAY	0	0	f	2010-11-13	4352	\N	27146	\N
37768	GENERIC_DAY	0	14400	f	2011-01-07	4352	\N	27146	\N
37769	GENERIC_DAY	0	14400	f	2010-12-16	4354	\N	27146	\N
37770	GENERIC_DAY	0	14400	f	2010-11-26	4352	\N	27146	\N
37771	GENERIC_DAY	0	14400	f	2011-01-03	4352	\N	27146	\N
37772	GENERIC_DAY	0	14400	f	2010-12-06	4352	\N	27146	\N
37773	GENERIC_DAY	0	14400	f	2011-01-13	4354	\N	27146	\N
37774	GENERIC_DAY	0	14400	f	2011-01-17	4354	\N	27146	\N
37775	GENERIC_DAY	0	0	f	2011-01-09	4352	\N	27146	\N
37776	GENERIC_DAY	0	14400	f	2010-12-14	4354	\N	27146	\N
37777	GENERIC_DAY	0	14400	f	2010-12-22	4354	\N	27146	\N
37778	GENERIC_DAY	0	14400	f	2011-01-14	4354	\N	27146	\N
37779	GENERIC_DAY	0	0	f	2011-01-02	4354	\N	27146	\N
37780	GENERIC_DAY	0	14400	f	2010-12-01	4354	\N	27146	\N
37781	GENERIC_DAY	0	14400	f	2010-11-25	4352	\N	27146	\N
37782	GENERIC_DAY	0	14400	f	2011-01-06	4354	\N	27146	\N
37783	GENERIC_DAY	0	0	f	2010-11-20	4352	\N	27146	\N
37784	GENERIC_DAY	0	14400	f	2010-12-22	4352	\N	27146	\N
37785	GENERIC_DAY	0	14400	f	2010-12-30	4354	\N	27146	\N
37786	GENERIC_DAY	0	14400	f	2011-01-12	4354	\N	27146	\N
37787	GENERIC_DAY	0	14400	f	2010-12-23	4354	\N	27146	\N
37788	GENERIC_DAY	0	0	f	2010-12-05	4352	\N	27146	\N
37789	GENERIC_DAY	0	0	f	2010-12-11	4354	\N	27146	\N
37790	GENERIC_DAY	0	14400	f	2010-12-30	4352	\N	27146	\N
37791	GENERIC_DAY	0	14400	f	2010-12-21	4352	\N	27146	\N
37792	GENERIC_DAY	0	14400	f	2011-01-12	4352	\N	27146	\N
37793	GENERIC_DAY	0	14400	f	2010-11-10	4352	\N	27146	\N
37794	GENERIC_DAY	0	14400	f	2010-12-24	4352	\N	27146	\N
37795	GENERIC_DAY	0	0	f	2010-11-21	4354	\N	27146	\N
37796	GENERIC_DAY	0	14400	f	2010-11-15	4352	\N	27146	\N
37797	GENERIC_DAY	0	14400	f	2010-11-29	4352	\N	27146	\N
37798	GENERIC_DAY	0	14400	f	2010-12-27	4352	\N	27146	\N
37799	GENERIC_DAY	0	0	f	2011-01-01	4354	\N	27146	\N
37800	GENERIC_DAY	0	0	f	2010-12-11	4352	\N	27146	\N
37801	GENERIC_DAY	0	14400	f	2010-11-18	4352	\N	27146	\N
37802	GENERIC_DAY	0	0	f	2011-01-01	4352	\N	27146	\N
37803	GENERIC_DAY	0	0	f	2010-12-12	4354	\N	27146	\N
37804	GENERIC_DAY	0	0	f	2010-12-05	4354	\N	27146	\N
37805	GENERIC_DAY	0	0	f	2011-01-02	4352	\N	27146	\N
64474	GENERIC_DAY	1	0	f	2010-06-26	4352	\N	53632	\N
64475	GENERIC_DAY	1	28800	f	2010-06-24	4354	\N	53632	\N
64476	GENERIC_DAY	1	3600	f	2010-06-17	4352	\N	53632	\N
64477	GENERIC_DAY	1	0	f	2010-07-12	4354	\N	53632	\N
64478	GENERIC_DAY	1	28800	f	2010-07-16	4352	\N	53632	\N
64479	GENERIC_DAY	1	14400	f	2010-06-28	4354	\N	53632	\N
64480	GENERIC_DAY	1	0	f	2010-06-26	4354	\N	53632	\N
64481	GENERIC_DAY	1	0	f	2010-07-16	4354	\N	53632	\N
64482	GENERIC_DAY	1	14400	f	2010-06-30	4352	\N	53632	\N
64483	GENERIC_DAY	1	0	f	2010-07-19	4354	\N	53632	\N
64484	GENERIC_DAY	1	0	f	2010-07-21	4354	\N	53632	\N
64485	GENERIC_DAY	1	0	f	2010-06-20	4354	\N	53632	\N
64486	GENERIC_DAY	1	28800	f	2010-07-05	4352	\N	53632	\N
37806	GENERIC_DAY	0	0	f	2010-12-19	4352	\N	27146	\N
37807	GENERIC_DAY	0	14400	f	2011-01-06	4352	\N	27146	\N
37808	GENERIC_DAY	0	14400	f	2010-11-16	4352	\N	27146	\N
37809	GENERIC_DAY	0	14400	f	2010-12-13	4352	\N	27146	\N
37810	GENERIC_DAY	0	14400	f	2011-01-11	4354	\N	27146	\N
37811	GENERIC_DAY	0	0	f	2011-01-08	4354	\N	27146	\N
37812	GENERIC_DAY	0	0	f	2010-11-21	4352	\N	27146	\N
37813	GENERIC_DAY	0	0	f	2011-01-08	4352	\N	27146	\N
37814	GENERIC_DAY	0	14400	f	2010-12-21	4354	\N	27146	\N
37815	GENERIC_DAY	0	14400	f	2010-11-18	4354	\N	27146	\N
37816	GENERIC_DAY	0	14400	f	2010-12-20	4352	\N	27146	\N
37817	GENERIC_DAY	0	0	f	2010-11-14	4354	\N	27146	\N
37818	GENERIC_DAY	0	14400	f	2010-12-09	4354	\N	27146	\N
37819	GENERIC_DAY	0	0	f	2010-11-28	4354	\N	27146	\N
37820	GENERIC_DAY	0	0	f	2010-12-26	4352	\N	27146	\N
37821	GENERIC_DAY	0	14400	f	2010-12-27	4354	\N	27146	\N
37822	GENERIC_DAY	0	14400	f	2010-12-02	4354	\N	27146	\N
37823	GENERIC_DAY	0	0	f	2010-11-27	4354	\N	27146	\N
37824	GENERIC_DAY	0	14400	f	2010-11-12	4354	\N	27146	\N
37825	GENERIC_DAY	0	0	f	2010-11-14	4352	\N	27146	\N
37826	GENERIC_DAY	0	14400	f	2010-12-24	4354	\N	27146	\N
37827	GENERIC_DAY	0	0	f	2010-12-19	4354	\N	27146	\N
37828	GENERIC_DAY	0	14400	f	2010-12-31	4354	\N	27146	\N
37829	GENERIC_DAY	0	14400	f	2010-12-03	4352	\N	27146	\N
37830	GENERIC_DAY	0	14400	f	2011-01-04	4352	\N	27146	\N
37831	GENERIC_DAY	0	14400	f	2010-12-29	4352	\N	27146	\N
37832	GENERIC_DAY	0	0	f	2010-12-26	4354	\N	27146	\N
37833	GENERIC_DAY	0	0	f	2010-12-04	4352	\N	27146	\N
37834	GENERIC_DAY	0	14400	f	2010-11-24	4352	\N	27146	\N
37835	GENERIC_DAY	0	14400	f	2010-12-10	4354	\N	27146	\N
37836	GENERIC_DAY	0	14400	f	2010-11-15	4354	\N	27146	\N
37837	GENERIC_DAY	0	14400	f	2010-11-22	4354	\N	27146	\N
37838	GENERIC_DAY	0	14400	f	2010-12-15	4354	\N	27146	\N
37839	GENERIC_DAY	0	14400	f	2010-11-19	4352	\N	27146	\N
37840	GENERIC_DAY	0	0	f	2010-12-18	4352	\N	27146	\N
37841	GENERIC_DAY	0	0	f	2010-12-25	4354	\N	27146	\N
37842	GENERIC_DAY	0	14400	f	2010-11-17	4354	\N	27146	\N
37843	GENERIC_DAY	0	0	f	2010-12-18	4354	\N	27146	\N
37844	GENERIC_DAY	0	14400	f	2010-12-01	4352	\N	27146	\N
37845	GENERIC_DAY	0	14400	f	2010-12-14	4352	\N	27146	\N
37846	GENERIC_DAY	0	14400	f	2010-11-23	4354	\N	27146	\N
37847	GENERIC_DAY	0	14400	f	2011-01-10	4352	\N	27146	\N
37848	GENERIC_DAY	0	14400	f	2010-12-08	4352	\N	27146	\N
37849	GENERIC_DAY	0	14400	f	2011-01-17	4352	\N	27146	\N
37850	GENERIC_DAY	0	14400	f	2010-11-09	4354	\N	27146	\N
37851	GENERIC_DAY	0	14400	f	2010-11-11	4352	\N	27146	\N
8870	GENERIC_DAY	12	7200	f	2010-06-22	4348	\N	5964	\N
8819	GENERIC_DAY	12	7200	f	2010-06-15	4358	\N	5964	\N
8815	GENERIC_DAY	12	7200	f	2010-06-29	4348	\N	5964	\N
8835	GENERIC_DAY	12	7200	f	2010-06-16	4344	\N	5964	\N
64487	GENERIC_DAY	1	0	f	2010-07-09	4354	\N	53632	\N
8851	GENERIC_DAY	12	7200	f	2010-07-01	4344	\N	5964	\N
8873	GENERIC_DAY	12	7200	f	2010-07-05	4348	\N	5964	\N
64488	GENERIC_DAY	1	14400	f	2010-06-28	4352	\N	53632	\N
64489	GENERIC_DAY	1	0	f	2010-06-23	4352	\N	53632	\N
64490	GENERIC_DAY	1	28800	f	2010-06-25	4354	\N	53632	\N
8826	GENERIC_DAY	12	7200	f	2010-06-17	4344	\N	5964	\N
8792	GENERIC_DAY	12	7200	f	2010-06-24	4358	\N	5964	\N
64491	GENERIC_DAY	1	0	f	2010-06-19	4354	\N	53632	\N
64492	GENERIC_DAY	1	28800	f	2010-07-12	4352	\N	53632	\N
8823	GENERIC_DAY	12	7200	f	2010-07-02	4350	\N	5964	\N
8836	GENERIC_DAY	12	7200	f	2010-06-18	4358	\N	5964	\N
8797	GENERIC_DAY	12	7200	f	2010-06-23	4348	\N	5964	\N
8877	GENERIC_DAY	12	0	f	2010-06-26	4350	\N	5964	\N
64493	GENERIC_DAY	1	28800	f	2010-07-06	4352	\N	53632	\N
8849	GENERIC_DAY	12	0	f	2010-06-20	4344	\N	5964	\N
8830	GENERIC_DAY	12	0	f	2010-06-20	4350	\N	5964	\N
8886	GENERIC_DAY	12	14400	f	2010-06-14	4358	\N	5964	\N
64494	GENERIC_DAY	1	25200	f	2010-06-16	4354	\N	53632	\N
8869	GENERIC_DAY	12	0	f	2010-06-26	4348	\N	5964	\N
37852	GENERIC_DAY	0	0	f	2010-11-13	4354	\N	27146	\N
37853	GENERIC_DAY	0	14400	f	2010-11-23	4352	\N	27146	\N
37854	GENERIC_DAY	0	14400	f	2011-01-11	4352	\N	27146	\N
37855	GENERIC_DAY	0	14400	f	2010-12-20	4354	\N	27146	\N
37856	GENERIC_DAY	0	14400	f	2010-12-29	4354	\N	27146	\N
37857	GENERIC_DAY	0	14400	f	2010-12-08	4354	\N	27146	\N
37858	GENERIC_DAY	0	14400	f	2010-11-25	4354	\N	27146	\N
37859	GENERIC_DAY	0	14400	f	2010-12-23	4352	\N	27146	\N
37860	GENERIC_DAY	0	14400	f	2010-12-31	4352	\N	27146	\N
37861	GENERIC_DAY	0	14400	f	2010-12-06	4354	\N	27146	\N
37862	GENERIC_DAY	0	14400	f	2010-11-12	4352	\N	27146	\N
37863	GENERIC_DAY	0	14400	f	2010-12-17	4354	\N	27146	\N
37864	GENERIC_DAY	0	14400	f	2011-01-13	4352	\N	27146	\N
37865	GENERIC_DAY	0	14400	f	2010-11-16	4354	\N	27146	\N
37866	GENERIC_DAY	0	14400	f	2010-12-17	4352	\N	27146	\N
37867	GENERIC_DAY	0	14400	f	2010-12-03	4354	\N	27146	\N
37868	GENERIC_DAY	0	14400	f	2011-01-10	4354	\N	27146	\N
37869	GENERIC_DAY	0	0	f	2010-11-27	4352	\N	27146	\N
37870	GENERIC_DAY	0	0	f	2011-01-15	4354	\N	27146	\N
37871	GENERIC_DAY	0	14400	f	2010-12-10	4352	\N	27146	\N
37872	GENERIC_DAY	0	0	f	2010-12-04	4354	\N	27146	\N
37873	GENERIC_DAY	0	14400	f	2010-12-13	4354	\N	27146	\N
64495	GENERIC_DAY	1	0	f	2010-07-10	4352	\N	53632	\N
64496	GENERIC_DAY	1	25200	f	2010-06-17	4354	\N	53632	\N
64497	GENERIC_DAY	1	0	f	2010-07-17	4352	\N	53632	\N
64498	GENERIC_DAY	1	28800	f	2010-06-23	4354	\N	53632	\N
64499	GENERIC_DAY	1	3600	f	2010-06-21	4352	\N	53632	\N
64500	GENERIC_DAY	1	0	f	2010-06-25	4352	\N	53632	\N
64501	GENERIC_DAY	1	0	f	2010-07-07	4354	\N	53632	\N
64502	GENERIC_DAY	1	28800	f	2010-06-22	4354	\N	53632	\N
64503	GENERIC_DAY	1	28800	f	2010-07-14	4352	\N	53632	\N
64504	GENERIC_DAY	1	0	f	2010-07-14	4354	\N	53632	\N
64505	GENERIC_DAY	1	25200	f	2010-06-21	4354	\N	53632	\N
37874	GENERIC_DAY	0	14400	f	2010-11-19	4354	\N	27146	\N
37875	GENERIC_DAY	0	0	f	2010-11-28	4352	\N	27146	\N
37876	GENERIC_DAY	0	14400	f	2010-11-09	4352	\N	27146	\N
37877	GENERIC_DAY	0	14400	f	2011-01-05	4352	\N	27146	\N
37878	GENERIC_DAY	0	14400	f	2010-12-07	4352	\N	27146	\N
37879	GENERIC_DAY	0	14400	f	2011-01-05	4354	\N	27146	\N
37880	GENERIC_DAY	0	14400	f	2010-12-09	4352	\N	27146	\N
37881	GENERIC_DAY	0	14400	f	2010-11-26	4354	\N	27146	\N
37882	GENERIC_DAY	0	14400	f	2010-11-24	4354	\N	27146	\N
37883	GENERIC_DAY	0	0	f	2011-01-09	4354	\N	27146	\N
37884	GENERIC_DAY	0	14400	f	2010-12-02	4352	\N	27146	\N
37885	GENERIC_DAY	0	14400	f	2010-11-30	4354	\N	27146	\N
37886	GENERIC_DAY	0	14400	f	2010-12-07	4354	\N	27146	\N
37887	GENERIC_DAY	0	0	f	2011-01-16	4352	\N	27146	\N
37888	GENERIC_DAY	0	0	f	2010-12-25	4352	\N	27146	\N
37889	GENERIC_DAY	0	14400	f	2011-01-07	4354	\N	27146	\N
37890	GENERIC_DAY	0	0	f	2010-12-12	4352	\N	27146	\N
37891	GENERIC_DAY	0	14400	f	2011-01-03	4354	\N	27146	\N
37892	GENERIC_DAY	0	14400	f	2010-12-28	4354	\N	27146	\N
37893	GENERIC_DAY	0	0	f	2011-01-15	4352	\N	27146	\N
37894	GENERIC_DAY	0	14400	f	2010-11-11	4354	\N	27146	\N
64506	GENERIC_DAY	1	0	f	2010-07-11	4354	\N	53632	\N
64507	GENERIC_DAY	1	0	f	2010-07-17	4354	\N	53632	\N
64508	GENERIC_DAY	1	0	f	2010-07-04	4354	\N	53632	\N
64509	GENERIC_DAY	1	0	f	2010-07-15	4354	\N	53632	\N
64510	GENERIC_DAY	1	14400	f	2010-06-30	4354	\N	53632	\N
64511	GENERIC_DAY	1	25200	f	2010-06-18	4354	\N	53632	\N
64512	GENERIC_DAY	1	0	f	2010-07-03	4352	\N	53632	\N
64513	GENERIC_DAY	1	0	f	2010-07-13	4354	\N	53632	\N
64514	GENERIC_DAY	1	0	f	2010-07-04	4352	\N	53632	\N
64515	GENERIC_DAY	1	0	f	2010-06-27	4352	\N	53632	\N
64516	GENERIC_DAY	1	28800	f	2010-07-15	4352	\N	53632	\N
64517	GENERIC_DAY	1	14400	f	2010-06-29	4354	\N	53632	\N
64518	GENERIC_DAY	1	28800	f	2010-07-19	4352	\N	53632	\N
64519	GENERIC_DAY	1	28800	f	2010-07-20	4352	\N	53632	\N
64520	GENERIC_DAY	1	14400	f	2010-06-29	4352	\N	53632	\N
64521	GENERIC_DAY	1	28800	f	2010-07-13	4352	\N	53632	\N
8846	GENERIC_DAY	12	7200	f	2010-07-07	4344	\N	5964	\N
8827	GENERIC_DAY	12	7200	f	2010-06-25	4348	\N	5964	\N
64522	GENERIC_DAY	1	0	f	2010-06-27	4354	\N	53632	\N
64523	GENERIC_DAY	1	7200	f	2010-07-21	4352	\N	53632	\N
64524	GENERIC_DAY	1	28800	f	2010-07-07	4352	\N	53632	\N
8824	GENERIC_DAY	12	7200	f	2010-06-28	4348	\N	5964	\N
64525	GENERIC_DAY	1	28800	f	2010-07-09	4352	\N	53632	\N
64526	GENERIC_DAY	1	0	f	2010-06-22	4352	\N	53632	\N
8862	GENERIC_DAY	12	7200	f	2010-07-06	4358	\N	5964	\N
64527	GENERIC_DAY	1	0	f	2010-07-02	4354	\N	53632	\N
8822	GENERIC_DAY	12	0	f	2010-07-03	4348	\N	5964	\N
8821	GENERIC_DAY	12	7200	f	2010-07-08	4344	\N	5964	\N
8884	GENERIC_DAY	12	7200	f	2010-06-29	4358	\N	5964	\N
64528	GENERIC_DAY	1	3600	f	2010-06-15	4352	\N	53632	\N
64529	GENERIC_DAY	1	0	f	2010-07-01	4354	\N	53632	\N
64530	GENERIC_DAY	1	0	f	2010-07-18	4352	\N	53632	\N
8879	GENERIC_DAY	12	7200	f	2010-06-16	4350	\N	5964	\N
64531	GENERIC_DAY	1	0	f	2010-07-08	4354	\N	53632	\N
64532	GENERIC_DAY	1	3600	f	2010-06-16	4352	\N	53632	\N
64533	GENERIC_DAY	1	0	f	2010-06-24	4352	\N	53632	\N
64534	GENERIC_DAY	1	0	f	2010-07-10	4354	\N	53632	\N
64535	GENERIC_DAY	1	7200	f	2010-08-13	4348	\N	53633	\N
64536	GENERIC_DAY	1	7200	f	2010-07-29	4350	\N	53633	\N
64537	GENERIC_DAY	1	0	f	2010-08-07	4350	\N	53633	\N
64538	GENERIC_DAY	1	0	f	2010-08-15	4344	\N	53633	\N
64943	GENERIC_DAY	1	0	f	2010-07-24	4348	\N	53633	\N
8833	GENERIC_DAY	12	7200	f	2010-06-25	4344	\N	5964	\N
8817	GENERIC_DAY	12	0	f	2010-06-20	4348	\N	5964	\N
64944	GENERIC_DAY	1	7200	f	2010-07-22	4358	\N	53633	\N
8866	GENERIC_DAY	12	14400	f	2010-06-14	4350	\N	5964	\N
64945	GENERIC_DAY	1	0	f	2010-08-08	4350	\N	53633	\N
64946	GENERIC_DAY	1	0	f	2010-08-01	4358	\N	53633	\N
64947	GENERIC_DAY	1	0	f	2010-07-25	4348	\N	53633	\N
64948	GENERIC_DAY	1	3600	f	2010-08-17	4358	\N	53633	\N
64949	GENERIC_DAY	1	7200	f	2010-07-27	4358	\N	53633	\N
64950	GENERIC_DAY	1	7200	f	2010-08-10	4350	\N	53633	\N
64951	GENERIC_DAY	1	7200	f	2010-07-26	4348	\N	53633	\N
64952	GENERIC_DAY	1	7200	f	2010-08-16	4350	\N	53633	\N
64953	GENERIC_DAY	1	7200	f	2010-08-16	4344	\N	53633	\N
64954	GENERIC_DAY	1	7200	f	2010-07-29	4358	\N	53633	\N
64955	GENERIC_DAY	1	0	f	2010-07-25	4344	\N	53633	\N
64956	GENERIC_DAY	1	7200	f	2010-08-05	4350	\N	53633	\N
64957	GENERIC_DAY	1	0	f	2010-08-15	4350	\N	53633	\N
64958	GENERIC_DAY	1	7200	f	2010-08-17	4344	\N	53633	\N
64959	GENERIC_DAY	1	7200	f	2010-08-11	4358	\N	53633	\N
64960	GENERIC_DAY	1	0	f	2010-07-25	4358	\N	53633	\N
64961	GENERIC_DAY	1	7200	f	2010-07-22	4348	\N	53633	\N
64962	GENERIC_DAY	1	0	f	2010-07-24	4358	\N	53633	\N
64963	GENERIC_DAY	1	7200	f	2010-07-23	4358	\N	53633	\N
64964	GENERIC_DAY	1	0	f	2010-08-01	4350	\N	53633	\N
64965	GENERIC_DAY	1	7200	f	2010-07-26	4358	\N	53633	\N
64966	GENERIC_DAY	1	7200	f	2010-08-03	4348	\N	53633	\N
64967	GENERIC_DAY	1	7200	f	2010-08-04	4348	\N	53633	\N
64968	GENERIC_DAY	1	0	f	2010-08-01	4348	\N	53633	\N
64969	GENERIC_DAY	1	0	f	2010-07-24	4344	\N	53633	\N
64970	GENERIC_DAY	1	3600	f	2010-07-28	4358	\N	53633	\N
64971	GENERIC_DAY	1	0	f	2010-07-24	4350	\N	53633	\N
64972	GENERIC_DAY	1	7200	f	2010-07-26	4344	\N	53633	\N
64973	GENERIC_DAY	1	7200	f	2010-08-05	4348	\N	53633	\N
64974	GENERIC_DAY	1	0	f	2010-08-08	4348	\N	53633	\N
64975	GENERIC_DAY	1	3600	f	2010-08-17	4350	\N	53633	\N
64976	GENERIC_DAY	1	7200	f	2010-08-06	4344	\N	53633	\N
64977	GENERIC_DAY	1	0	f	2010-07-31	4344	\N	53633	\N
64978	GENERIC_DAY	1	7200	f	2010-08-06	4348	\N	53633	\N
64979	GENERIC_DAY	1	7200	f	2010-08-12	4348	\N	53633	\N
64980	GENERIC_DAY	1	7200	f	2010-08-02	4348	\N	53633	\N
64981	GENERIC_DAY	1	0	f	2010-08-08	4344	\N	53633	\N
64982	GENERIC_DAY	1	7200	f	2010-08-05	4358	\N	53633	\N
64983	GENERIC_DAY	1	7200	f	2010-08-03	4358	\N	53633	\N
64984	GENERIC_DAY	1	7200	f	2010-08-02	4350	\N	53633	\N
64985	GENERIC_DAY	1	0	f	2010-08-14	4344	\N	53633	\N
64986	GENERIC_DAY	1	7200	f	2010-07-30	4344	\N	53633	\N
64987	GENERIC_DAY	1	7200	f	2010-07-27	4350	\N	53633	\N
64988	GENERIC_DAY	1	7200	f	2010-08-09	4358	\N	53633	\N
64989	GENERIC_DAY	1	0	f	2010-07-31	4358	\N	53633	\N
64990	GENERIC_DAY	1	7200	f	2010-07-27	4348	\N	53633	\N
8189	SPECIFIC_DAY	14	28800	f	2010-07-01	1216	8080	\N	\N
8194	SPECIFIC_DAY	14	28800	f	2010-07-12	1216	8080	\N	\N
8187	SPECIFIC_DAY	14	28800	f	2010-07-07	1216	8080	\N	\N
8197	SPECIFIC_DAY	14	28800	f	2010-07-14	1216	8080	\N	\N
64991	GENERIC_DAY	1	7200	f	2010-08-02	4358	\N	53633	\N
64992	GENERIC_DAY	1	0	f	2010-08-07	4348	\N	53633	\N
64993	GENERIC_DAY	1	7200	f	2010-08-06	4350	\N	53633	\N
64994	GENERIC_DAY	1	7200	f	2010-08-09	4348	\N	53633	\N
64995	GENERIC_DAY	1	7200	f	2010-08-13	4344	\N	53633	\N
64996	GENERIC_DAY	1	7200	f	2010-08-12	4358	\N	53633	\N
64997	GENERIC_DAY	1	7200	f	2010-07-30	4358	\N	53633	\N
64998	GENERIC_DAY	1	0	f	2010-07-31	4350	\N	53633	\N
64999	GENERIC_DAY	1	7200	f	2010-07-29	4344	\N	53633	\N
65000	GENERIC_DAY	1	10800	f	2010-07-28	4344	\N	53633	\N
65001	GENERIC_DAY	1	7200	f	2010-08-10	4348	\N	53633	\N
65002	GENERIC_DAY	1	7200	f	2010-07-28	4348	\N	53633	\N
65003	GENERIC_DAY	1	7200	f	2010-08-10	4344	\N	53633	\N
65004	GENERIC_DAY	1	7200	f	2010-08-04	4358	\N	53633	\N
65005	GENERIC_DAY	1	7200	f	2010-08-03	4344	\N	53633	\N
65006	GENERIC_DAY	1	7200	f	2010-08-02	4344	\N	53633	\N
65007	GENERIC_DAY	1	0	f	2010-08-14	4350	\N	53633	\N
65008	GENERIC_DAY	1	0	f	2010-08-07	4358	\N	53633	\N
65009	GENERIC_DAY	1	0	f	2010-08-01	4344	\N	53633	\N
65010	GENERIC_DAY	1	7200	f	2010-08-06	4358	\N	53633	\N
65011	GENERIC_DAY	1	7200	f	2010-08-12	4344	\N	53633	\N
65012	GENERIC_DAY	1	7200	f	2010-08-03	4350	\N	53633	\N
65013	GENERIC_DAY	1	0	f	2010-07-31	4348	\N	53633	\N
65014	GENERIC_DAY	1	0	f	2010-08-08	4358	\N	53633	\N
65015	GENERIC_DAY	1	7200	f	2010-08-13	4358	\N	53633	\N
65016	GENERIC_DAY	1	7200	f	2010-07-23	4348	\N	53633	\N
65017	GENERIC_DAY	1	7200	f	2010-07-30	4348	\N	53633	\N
65018	GENERIC_DAY	1	7200	f	2010-08-11	4350	\N	53633	\N
65019	GENERIC_DAY	1	7200	f	2010-08-13	4350	\N	53633	\N
65020	GENERIC_DAY	1	0	f	2010-08-15	4348	\N	53633	\N
65021	GENERIC_DAY	1	7200	f	2010-07-23	4350	\N	53633	\N
65022	GENERIC_DAY	1	7200	f	2010-08-16	4358	\N	53633	\N
65023	GENERIC_DAY	1	7200	f	2010-07-22	4350	\N	53633	\N
65024	GENERIC_DAY	1	0	f	2010-08-14	4358	\N	53633	\N
65025	GENERIC_DAY	1	0	f	2010-08-15	4358	\N	53633	\N
65026	GENERIC_DAY	1	7200	f	2010-07-28	4350	\N	53633	\N
65027	GENERIC_DAY	1	7200	f	2010-07-23	4344	\N	53633	\N
65028	GENERIC_DAY	1	0	f	2010-07-25	4350	\N	53633	\N
65029	GENERIC_DAY	1	7200	f	2010-08-09	4350	\N	53633	\N
65030	GENERIC_DAY	1	7200	f	2010-08-09	4344	\N	53633	\N
65031	GENERIC_DAY	1	7200	f	2010-08-10	4358	\N	53633	\N
65032	GENERIC_DAY	1	7200	f	2010-07-22	4344	\N	53633	\N
65033	GENERIC_DAY	1	7200	f	2010-07-29	4348	\N	53633	\N
65034	GENERIC_DAY	1	7200	f	2010-08-05	4344	\N	53633	\N
65035	GENERIC_DAY	1	0	f	2010-08-07	4344	\N	53633	\N
65036	GENERIC_DAY	1	0	f	2010-08-14	4348	\N	53633	\N
65037	GENERIC_DAY	1	7200	f	2010-08-12	4350	\N	53633	\N
65038	GENERIC_DAY	1	7200	f	2010-08-04	4344	\N	53633	\N
65039	GENERIC_DAY	1	7200	f	2010-08-17	4348	\N	53633	\N
65040	GENERIC_DAY	1	7200	f	2010-08-16	4348	\N	53633	\N
65041	GENERIC_DAY	1	7200	f	2010-07-26	4350	\N	53633	\N
65042	GENERIC_DAY	1	7200	f	2010-08-11	4348	\N	53633	\N
65043	GENERIC_DAY	1	7200	f	2010-07-27	4344	\N	53633	\N
65044	GENERIC_DAY	1	7200	f	2010-07-30	4350	\N	53633	\N
65045	GENERIC_DAY	1	7200	f	2010-08-04	4350	\N	53633	\N
65046	GENERIC_DAY	1	7200	f	2010-08-11	4344	\N	53633	\N
27485	GENERIC_DAY	9	14400	f	2010-08-18	4354	\N	27071	\N
21715	GENERIC_DAY	4	0	f	2010-08-01	4344	\N	16774	\N
27480	GENERIC_DAY	9	14400	f	2010-08-03	4352	\N	27071	\N
21714	GENERIC_DAY	4	7200	f	2010-08-18	4358	\N	16774	\N
21717	GENERIC_DAY	4	7200	f	2010-08-13	4344	\N	16774	\N
27456	GENERIC_DAY	9	0	f	2010-08-14	4352	\N	27071	\N
27460	GENERIC_DAY	9	14400	f	2010-07-27	4354	\N	27071	\N
27491	GENERIC_DAY	9	14400	f	2010-08-05	4354	\N	27071	\N
27452	GENERIC_DAY	9	14400	f	2010-07-30	4352	\N	27071	\N
21706	GENERIC_DAY	4	7200	f	2010-08-19	4350	\N	16774	\N
27479	GENERIC_DAY	9	14400	f	2010-08-12	4354	\N	27071	\N
27451	GENERIC_DAY	9	14400	f	2010-07-21	4354	\N	27071	\N
27446	GENERIC_DAY	9	14400	f	2010-07-20	4354	\N	27071	\N
27462	GENERIC_DAY	9	0	f	2010-07-31	4354	\N	27071	\N
27477	GENERIC_DAY	9	0	f	2010-07-24	4354	\N	27071	\N
21716	GENERIC_DAY	4	7200	f	2010-07-30	4348	\N	16774	\N
21707	GENERIC_DAY	4	7200	f	2010-08-02	4358	\N	16774	\N
27493	GENERIC_DAY	9	0	f	2010-07-24	4352	\N	27071	\N
21712	GENERIC_DAY	4	0	f	2010-08-22	4344	\N	16774	\N
27467	GENERIC_DAY	9	14400	f	2010-08-18	4352	\N	27071	\N
27489	GENERIC_DAY	9	14400	f	2010-08-04	4352	\N	27071	\N
27488	GENERIC_DAY	9	14400	f	2010-07-21	4352	\N	27071	\N
27453	GENERIC_DAY	9	14400	f	2010-08-09	4354	\N	27071	\N
27474	GENERIC_DAY	9	14400	f	2010-07-16	4354	\N	27071	\N
27475	GENERIC_DAY	9	14400	f	2010-08-09	4352	\N	27071	\N
27497	GENERIC_DAY	9	14400	f	2010-08-11	4352	\N	27071	\N
27447	GENERIC_DAY	9	0	f	2010-07-17	4352	\N	27071	\N
27495	GENERIC_DAY	9	14400	f	2010-08-06	4354	\N	27071	\N
27478	GENERIC_DAY	9	0	f	2010-08-08	4352	\N	27071	\N
27469	GENERIC_DAY	9	14400	f	2010-07-15	4354	\N	27071	\N
27449	GENERIC_DAY	9	0	f	2010-08-15	4354	\N	27071	\N
27468	GENERIC_DAY	9	14400	f	2010-08-13	4352	\N	27071	\N
27472	GENERIC_DAY	9	14400	f	2010-07-19	4352	\N	27071	\N
21709	GENERIC_DAY	4	7200	f	2010-08-03	4350	\N	16774	\N
21705	GENERIC_DAY	4	0	f	2010-08-01	4350	\N	16774	\N
21708	GENERIC_DAY	4	7200	f	2010-08-26	4358	\N	16774	\N
27483	GENERIC_DAY	9	14400	f	2010-07-29	4354	\N	27071	\N
21718	GENERIC_DAY	4	7200	f	2010-08-31	4350	\N	16774	\N
27482	GENERIC_DAY	9	0	f	2010-07-18	4352	\N	27071	\N
27450	GENERIC_DAY	9	14400	f	2010-08-02	4354	\N	27071	\N
21711	GENERIC_DAY	4	7200	f	2010-08-06	4350	\N	16774	\N
21713	GENERIC_DAY	4	0	f	2010-08-29	4358	\N	16774	\N
27481	GENERIC_DAY	9	14400	f	2010-08-05	4352	\N	27071	\N
27490	GENERIC_DAY	9	0	f	2010-07-17	4354	\N	27071	\N
27496	GENERIC_DAY	9	14400	f	2010-08-17	4354	\N	27071	\N
27487	GENERIC_DAY	9	14400	f	2010-08-12	4352	\N	27071	\N
27620	GENERIC_DAY	9	0	f	2010-08-21	4350	\N	27074	\N
27615	GENERIC_DAY	9	7200	f	2010-08-25	4344	\N	27074	\N
27572	GENERIC_DAY	9	0	f	2010-08-07	4344	\N	27074	\N
27662	GENERIC_DAY	9	7200	f	2010-08-11	4344	\N	27074	\N
27616	GENERIC_DAY	9	3600	f	2010-08-27	4350	\N	27074	\N
27605	GENERIC_DAY	9	0	f	2010-08-08	4358	\N	27074	\N
27617	GENERIC_DAY	9	7200	f	2010-08-05	4344	\N	27074	\N
27584	GENERIC_DAY	9	7200	f	2010-08-10	4350	\N	27074	\N
27590	GENERIC_DAY	9	7200	f	2010-08-13	4358	\N	27074	\N
27612	GENERIC_DAY	9	7200	f	2010-08-03	4358	\N	27074	\N
27633	GENERIC_DAY	9	7200	f	2010-08-16	4350	\N	27074	\N
27600	GENERIC_DAY	9	0	f	2010-08-08	4344	\N	27074	\N
27602	GENERIC_DAY	9	7200	f	2010-08-20	4348	\N	27074	\N
27614	GENERIC_DAY	9	7200	f	2010-08-06	4348	\N	27074	\N
27625	GENERIC_DAY	9	7200	f	2010-08-06	4350	\N	27074	\N
27636	GENERIC_DAY	9	7200	f	2010-08-09	4350	\N	27074	\N
27603	GENERIC_DAY	9	7200	f	2010-08-12	4344	\N	27074	\N
27582	GENERIC_DAY	9	7200	f	2010-08-25	4348	\N	27074	\N
27628	GENERIC_DAY	9	7200	f	2010-08-19	4358	\N	27074	\N
27607	GENERIC_DAY	9	7200	f	2010-08-12	4350	\N	27074	\N
27597	GENERIC_DAY	9	7200	f	2010-08-05	4350	\N	27074	\N
27571	GENERIC_DAY	9	7200	f	2010-08-17	4350	\N	27074	\N
27573	GENERIC_DAY	9	7200	f	2010-08-20	4350	\N	27074	\N
27638	GENERIC_DAY	9	7200	f	2010-08-10	4344	\N	27074	\N
27639	GENERIC_DAY	9	7200	f	2010-08-25	4350	\N	27074	\N
27652	GENERIC_DAY	9	7200	f	2010-08-25	4358	\N	27074	\N
27608	GENERIC_DAY	9	7200	f	2010-08-11	4350	\N	27074	\N
27649	GENERIC_DAY	9	7200	f	2010-08-04	4350	\N	27074	\N
27629	GENERIC_DAY	9	7200	f	2010-08-06	4344	\N	27074	\N
27611	GENERIC_DAY	9	7200	f	2010-08-10	4348	\N	27074	\N
27594	GENERIC_DAY	9	7200	f	2010-08-03	4344	\N	27074	\N
27654	GENERIC_DAY	9	7200	f	2010-08-26	4358	\N	27074	\N
27634	GENERIC_DAY	9	7200	f	2010-08-26	4344	\N	27074	\N
27618	GENERIC_DAY	9	0	f	2010-08-14	4348	\N	27074	\N
27580	GENERIC_DAY	9	7200	f	2010-08-05	4348	\N	27074	\N
27637	GENERIC_DAY	9	0	f	2010-08-14	4344	\N	27074	\N
27666	GENERIC_DAY	9	0	f	2010-08-22	4350	\N	27074	\N
27658	GENERIC_DAY	9	7200	f	2010-08-17	4358	\N	27074	\N
27599	GENERIC_DAY	9	7200	f	2010-08-10	4358	\N	27074	\N
27657	GENERIC_DAY	9	0	f	2010-08-08	4348	\N	27074	\N
27621	GENERIC_DAY	9	0	f	2010-08-07	4350	\N	27074	\N
27595	GENERIC_DAY	9	7200	f	2010-08-16	4344	\N	27074	\N
27604	GENERIC_DAY	9	7200	f	2010-08-23	4348	\N	27074	\N
27613	GENERIC_DAY	9	0	f	2010-08-21	4348	\N	27074	\N
27669	GENERIC_DAY	9	7200	f	2010-08-24	4344	\N	27074	\N
27591	GENERIC_DAY	9	7200	f	2010-08-17	4344	\N	27074	\N
27570	GENERIC_DAY	9	0	f	2010-08-21	4358	\N	27074	\N
27576	GENERIC_DAY	9	7200	f	2010-08-20	4358	\N	27074	\N
27642	GENERIC_DAY	9	7200	f	2010-08-11	4348	\N	27074	\N
27623	GENERIC_DAY	9	7200	f	2010-08-27	4348	\N	27074	\N
27610	GENERIC_DAY	9	7200	f	2010-08-04	4348	\N	27074	\N
27593	GENERIC_DAY	9	7200	f	2010-08-26	4350	\N	27074	\N
27665	GENERIC_DAY	9	7200	f	2010-08-11	4358	\N	27074	\N
27661	GENERIC_DAY	9	0	f	2010-08-14	4358	\N	27074	\N
27579	GENERIC_DAY	9	0	f	2010-08-07	4348	\N	27074	\N
27655	GENERIC_DAY	9	3600	f	2010-08-27	4358	\N	27074	\N
27659	GENERIC_DAY	9	7200	f	2010-08-13	4344	\N	27074	\N
27656	GENERIC_DAY	9	7200	f	2010-08-09	4358	\N	27074	\N
27619	GENERIC_DAY	9	7200	f	2010-08-23	4344	\N	27074	\N
27647	GENERIC_DAY	9	0	f	2010-08-15	4344	\N	27074	\N
27596	GENERIC_DAY	9	0	f	2010-08-22	4358	\N	27074	\N
27578	GENERIC_DAY	9	7200	f	2010-08-23	4350	\N	27074	\N
27574	GENERIC_DAY	9	0	f	2010-08-22	4348	\N	27074	\N
27660	GENERIC_DAY	9	7200	f	2010-08-20	4344	\N	27074	\N
27630	GENERIC_DAY	9	7200	f	2010-08-09	4344	\N	27074	\N
27583	GENERIC_DAY	9	7200	f	2010-08-24	4348	\N	27074	\N
27575	GENERIC_DAY	9	7200	f	2010-08-18	4358	\N	27074	\N
27601	GENERIC_DAY	9	0	f	2010-08-15	4348	\N	27074	\N
27626	GENERIC_DAY	9	7200	f	2010-08-13	4348	\N	27074	\N
27588	GENERIC_DAY	9	7200	f	2010-08-16	4358	\N	27074	\N
27577	GENERIC_DAY	9	0	f	2010-08-15	4358	\N	27074	\N
27609	GENERIC_DAY	9	7200	f	2010-08-26	4348	\N	27074	\N
27651	GENERIC_DAY	9	0	f	2010-08-22	4344	\N	27074	\N
27676	GENERIC_DAY	9	14400	f	2010-08-20	4352	\N	27075	\N
27734	GENERIC_DAY	9	14400	f	2010-08-05	4352	\N	27075	\N
27718	GENERIC_DAY	9	14400	f	2010-08-12	4352	\N	27075	\N
27725	GENERIC_DAY	9	0	f	2010-08-22	4352	\N	27075	\N
27719	GENERIC_DAY	9	14400	f	2010-08-24	4352	\N	27075	\N
27670	GENERIC_DAY	9	14400	f	2010-08-30	4352	\N	27075	\N
27671	GENERIC_DAY	9	14400	f	2010-08-05	4354	\N	27075	\N
27735	GENERIC_DAY	9	14400	f	2010-08-11	4354	\N	27075	\N
27677	GENERIC_DAY	9	14400	f	2010-08-24	4354	\N	27075	\N
27716	GENERIC_DAY	9	14400	f	2010-08-16	4352	\N	27075	\N
27672	GENERIC_DAY	9	14400	f	2010-09-03	4354	\N	27075	\N
27724	GENERIC_DAY	9	0	f	2010-08-15	4352	\N	27075	\N
27733	GENERIC_DAY	9	14400	f	2010-09-02	4352	\N	27075	\N
27723	GENERIC_DAY	9	0	f	2010-08-07	4352	\N	27075	\N
27678	GENERIC_DAY	9	0	f	2010-08-14	4352	\N	27075	\N
27738	GENERIC_DAY	9	0	f	2010-09-05	4352	\N	27075	\N
27739	GENERIC_DAY	9	14400	f	2010-08-26	4354	\N	27075	\N
27720	GENERIC_DAY	9	0	f	2010-08-14	4354	\N	27075	\N
27717	GENERIC_DAY	9	0	f	2010-08-07	4354	\N	27075	\N
27675	GENERIC_DAY	9	14400	f	2010-09-02	4354	\N	27075	\N
27681	GENERIC_DAY	9	14400	f	2010-09-01	4352	\N	27075	\N
27729	GENERIC_DAY	9	0	f	2010-08-15	4354	\N	27075	\N
27732	GENERIC_DAY	9	0	f	2010-08-29	4354	\N	27075	\N
27673	GENERIC_DAY	9	0	f	2010-08-21	4352	\N	27075	\N
27730	GENERIC_DAY	9	14400	f	2010-08-06	4352	\N	27075	\N
27731	GENERIC_DAY	9	14400	f	2010-08-13	4354	\N	27075	\N
27726	GENERIC_DAY	9	14400	f	2010-08-19	4352	\N	27075	\N
27737	GENERIC_DAY	9	14400	f	2010-08-03	4354	\N	27075	\N
27674	GENERIC_DAY	9	14400	f	2010-08-25	4352	\N	27075	\N
27680	GENERIC_DAY	9	14400	f	2010-08-10	4354	\N	27075	\N
27736	GENERIC_DAY	9	0	f	2010-08-22	4354	\N	27075	\N
27722	GENERIC_DAY	9	14400	f	2010-08-18	4352	\N	27075	\N
27679	GENERIC_DAY	9	14400	f	2010-08-09	4352	\N	27075	\N
27721	GENERIC_DAY	9	14400	f	2010-08-30	4354	\N	27075	\N
27727	GENERIC_DAY	9	14400	f	2010-09-03	4352	\N	27075	\N
27728	GENERIC_DAY	9	0	f	2010-08-28	4354	\N	27075	\N
31134	GENERIC_DAY	4	7200	f	2010-07-14	4358	\N	27090	\N
31146	GENERIC_DAY	4	3600	f	2010-07-09	4350	\N	27090	\N
31151	GENERIC_DAY	4	14400	f	2010-07-09	21817	\N	27090	\N
31177	GENERIC_DAY	4	0	f	2010-07-04	4358	\N	27090	\N
31164	GENERIC_DAY	4	0	f	2010-07-03	4358	\N	27090	\N
31168	GENERIC_DAY	4	0	f	2010-07-10	4358	\N	27090	\N
31131	GENERIC_DAY	4	7200	f	2010-06-29	21817	\N	27090	\N
31122	GENERIC_DAY	4	0	f	2010-07-01	4350	\N	27090	\N
31141	GENERIC_DAY	4	0	f	2010-07-08	4344	\N	27090	\N
31147	GENERIC_DAY	4	3600	f	2010-07-13	4350	\N	27090	\N
31133	GENERIC_DAY	4	7200	f	2010-06-28	21817	\N	27090	\N
31135	GENERIC_DAY	4	0	f	2010-07-11	21817	\N	27090	\N
31178	GENERIC_DAY	4	0	f	2010-06-28	4350	\N	27090	\N
31179	GENERIC_DAY	4	0	f	2010-06-27	4350	\N	27090	\N
31098	GENERIC_DAY	4	3600	f	2010-07-02	4358	\N	27090	\N
31185	GENERIC_DAY	4	0	f	2010-07-10	21817	\N	27090	\N
31137	GENERIC_DAY	4	7200	f	2010-07-01	4358	\N	27090	\N
31162	GENERIC_DAY	4	0	f	2010-07-08	4350	\N	27090	\N
31145	GENERIC_DAY	4	0	f	2010-07-07	4350	\N	27090	\N
31143	GENERIC_DAY	4	0	f	2010-07-05	4350	\N	27090	\N
31175	GENERIC_DAY	4	0	f	2010-07-02	4350	\N	27090	\N
31152	GENERIC_DAY	4	0	f	2010-07-03	21817	\N	27090	\N
31166	GENERIC_DAY	4	3600	f	2010-07-14	4348	\N	27090	\N
31182	GENERIC_DAY	4	7200	f	2010-06-30	4358	\N	27090	\N
31130	GENERIC_DAY	4	3600	f	2010-07-08	4358	\N	27090	\N
31105	GENERIC_DAY	4	10800	f	2010-06-30	21817	\N	27090	\N
31111	GENERIC_DAY	4	0	f	2010-06-29	4350	\N	27090	\N
31116	GENERIC_DAY	4	0	f	2010-07-13	4344	\N	27090	\N
31110	GENERIC_DAY	4	10800	f	2010-06-28	4348	\N	27090	\N
31115	GENERIC_DAY	4	0	f	2010-06-30	4350	\N	27090	\N
31156	GENERIC_DAY	4	3600	f	2010-07-05	4358	\N	27090	\N
31139	GENERIC_DAY	4	3600	f	2010-07-06	4348	\N	27090	\N
31103	GENERIC_DAY	4	0	f	2010-06-30	4344	\N	27090	\N
31154	GENERIC_DAY	4	21600	f	2010-07-06	21817	\N	27090	\N
31157	GENERIC_DAY	4	3600	f	2010-07-05	4348	\N	27090	\N
31132	GENERIC_DAY	4	14400	f	2010-07-12	21817	\N	27090	\N
31184	GENERIC_DAY	4	0	f	2010-07-06	4350	\N	27090	\N
31108	GENERIC_DAY	4	7200	f	2010-07-12	4358	\N	27090	\N
31138	GENERIC_DAY	4	0	f	2010-07-04	4344	\N	27090	\N
31113	GENERIC_DAY	4	0	f	2010-06-27	4358	\N	27090	\N
31173	GENERIC_DAY	4	7200	f	2010-07-09	4358	\N	27090	\N
31099	GENERIC_DAY	4	0	f	2010-07-11	4348	\N	27090	\N
31114	GENERIC_DAY	4	3600	f	2010-07-08	4348	\N	27090	\N
31181	GENERIC_DAY	4	21600	f	2010-07-05	21817	\N	27090	\N
31121	GENERIC_DAY	4	0	f	2010-07-03	4348	\N	27090	\N
31174	GENERIC_DAY	4	0	f	2010-07-10	4350	\N	27090	\N
31169	GENERIC_DAY	4	3600	f	2010-07-13	4348	\N	27090	\N
31104	GENERIC_DAY	4	3600	f	2010-07-07	4348	\N	27090	\N
31144	GENERIC_DAY	4	10800	f	2010-06-30	4348	\N	27090	\N
31150	GENERIC_DAY	4	3600	f	2010-07-07	4358	\N	27090	\N
31172	GENERIC_DAY	4	10800	f	2010-06-29	4358	\N	27090	\N
31101	GENERIC_DAY	4	0	f	2010-07-09	4344	\N	27090	\N
31176	GENERIC_DAY	4	0	f	2010-07-10	4344	\N	27090	\N
31126	GENERIC_DAY	4	0	f	2010-07-10	4348	\N	27090	\N
31100	GENERIC_DAY	4	14400	f	2010-07-13	21817	\N	27090	\N
31102	GENERIC_DAY	4	0	f	2010-06-29	4344	\N	27090	\N
31118	GENERIC_DAY	4	0	f	2010-07-02	4344	\N	27090	\N
31119	GENERIC_DAY	4	0	f	2010-06-27	4348	\N	27090	\N
31171	GENERIC_DAY	4	0	f	2010-07-01	4344	\N	27090	\N
31149	GENERIC_DAY	4	3600	f	2010-07-09	4348	\N	27090	\N
73496	GENERIC_DAY	3	28800	f	2010-08-10	72321	\N	73031	\N
73493	GENERIC_DAY	3	28800	f	2010-08-11	72319	\N	73031	\N
73494	GENERIC_DAY	3	0	f	2010-08-07	72321	\N	73031	\N
73495	GENERIC_DAY	3	28800	f	2010-08-11	72321	\N	73031	\N
73492	GENERIC_DAY	3	7200	f	2010-08-13	72317	\N	73031	\N
31153	GENERIC_DAY	4	0	f	2010-07-11	4358	\N	27090	\N
73423	GENERIC_DAY	3	0	f	2010-07-24	72319	\N	73026	\N
73443	GENERIC_DAY	3	28800	f	2010-07-20	72321	\N	73026	\N
102691	GENERIC_DAY	0	14400	f	2010-08-11	4354	\N	9412	\N
102692	GENERIC_DAY	0	0	f	2010-08-14	4354	\N	9412	\N
102693	GENERIC_DAY	0	14400	f	2010-08-20	4352	\N	9412	\N
102694	GENERIC_DAY	0	14400	f	2010-08-05	4354	\N	9412	\N
102695	GENERIC_DAY	0	14400	f	2010-08-16	4354	\N	9412	\N
102696	GENERIC_DAY	0	14400	f	2010-08-02	4354	\N	9412	\N
102697	GENERIC_DAY	0	0	f	2010-07-31	4354	\N	9412	\N
102698	GENERIC_DAY	0	0	f	2010-08-21	4354	\N	9412	\N
102699	GENERIC_DAY	0	14400	f	2010-08-18	4352	\N	9412	\N
102700	GENERIC_DAY	0	0	f	2010-08-22	4352	\N	9412	\N
102701	GENERIC_DAY	0	14400	f	2010-08-16	4352	\N	9412	\N
102702	GENERIC_DAY	0	0	f	2010-08-01	4352	\N	9412	\N
102703	GENERIC_DAY	0	0	f	2010-08-07	4354	\N	9412	\N
102704	GENERIC_DAY	0	14400	f	2010-08-20	4354	\N	9412	\N
102705	GENERIC_DAY	0	14400	f	2010-08-06	4352	\N	9412	\N
102706	GENERIC_DAY	0	0	f	2010-08-28	4352	\N	9412	\N
102707	GENERIC_DAY	0	0	f	2010-08-08	4354	\N	9412	\N
102708	GENERIC_DAY	0	14400	f	2010-08-09	4354	\N	9412	\N
102709	GENERIC_DAY	0	14400	f	2010-08-04	4352	\N	9412	\N
102710	GENERIC_DAY	0	14400	f	2010-08-06	4354	\N	9412	\N
102711	GENERIC_DAY	0	14400	f	2010-08-26	4352	\N	9412	\N
102712	GENERIC_DAY	0	14400	f	2010-08-03	4354	\N	9412	\N
102713	GENERIC_DAY	0	14400	f	2010-07-28	4352	\N	9412	\N
102714	GENERIC_DAY	0	14400	f	2010-08-09	4352	\N	9412	\N
102715	GENERIC_DAY	0	14400	f	2010-08-23	4354	\N	9412	\N
102716	GENERIC_DAY	0	14400	f	2010-08-12	4354	\N	9412	\N
102818	GENERIC_DAY	0	14400	f	2010-08-03	4352	\N	9412	\N
102819	GENERIC_DAY	0	14400	f	2010-08-17	4354	\N	9412	\N
102820	GENERIC_DAY	0	28800	f	2010-08-31	4352	\N	9412	\N
102821	GENERIC_DAY	0	0	f	2010-08-01	4354	\N	9412	\N
102822	GENERIC_DAY	0	14400	f	2010-08-04	4354	\N	9412	\N
102823	GENERIC_DAY	0	14400	f	2010-08-19	4352	\N	9412	\N
102824	GENERIC_DAY	0	0	f	2010-08-21	4352	\N	9412	\N
102825	GENERIC_DAY	0	14400	f	2010-08-13	4354	\N	9412	\N
102826	GENERIC_DAY	0	0	f	2010-08-07	4352	\N	9412	\N
102827	GENERIC_DAY	0	0	f	2010-08-15	4352	\N	9412	\N
102828	GENERIC_DAY	0	14400	f	2010-08-24	4352	\N	9412	\N
102829	GENERIC_DAY	0	14400	f	2010-08-27	4352	\N	9412	\N
102830	GENERIC_DAY	0	14400	f	2010-08-05	4352	\N	9412	\N
102831	GENERIC_DAY	0	14400	f	2010-08-10	4352	\N	9412	\N
102832	GENERIC_DAY	0	0	f	2010-08-29	4352	\N	9412	\N
102833	GENERIC_DAY	0	0	f	2010-08-22	4354	\N	9412	\N
102834	GENERIC_DAY	0	14400	f	2010-08-27	4354	\N	9412	\N
102835	GENERIC_DAY	0	0	f	2010-07-31	4352	\N	9412	\N
102836	GENERIC_DAY	0	14400	f	2010-08-11	4352	\N	9412	\N
102837	GENERIC_DAY	0	0	f	2010-08-31	4354	\N	9412	\N
102838	GENERIC_DAY	0	14400	f	2010-08-18	4354	\N	9412	\N
102839	GENERIC_DAY	0	28800	f	2010-08-30	4352	\N	9412	\N
102840	GENERIC_DAY	0	14400	f	2010-08-25	4352	\N	9412	\N
102841	GENERIC_DAY	0	14400	f	2010-08-17	4352	\N	9412	\N
102842	GENERIC_DAY	0	14400	f	2010-08-10	4354	\N	9412	\N
102843	GENERIC_DAY	0	14400	f	2010-08-26	4354	\N	9412	\N
102844	GENERIC_DAY	0	0	f	2010-08-15	4354	\N	9412	\N
102845	GENERIC_DAY	0	14400	f	2010-08-12	4352	\N	9412	\N
102846	GENERIC_DAY	0	14400	f	2010-07-30	4352	\N	9412	\N
102847	GENERIC_DAY	0	0	f	2010-08-28	4354	\N	9412	\N
102848	GENERIC_DAY	0	0	f	2010-08-14	4352	\N	9412	\N
102849	GENERIC_DAY	0	0	f	2010-08-30	4354	\N	9412	\N
102850	GENERIC_DAY	0	14400	f	2010-07-28	4354	\N	9412	\N
102851	GENERIC_DAY	0	14400	f	2010-08-24	4354	\N	9412	\N
102852	GENERIC_DAY	0	14400	f	2010-07-30	4354	\N	9412	\N
102853	GENERIC_DAY	0	14400	f	2010-08-25	4354	\N	9412	\N
102854	GENERIC_DAY	0	14400	f	2010-08-13	4352	\N	9412	\N
102855	GENERIC_DAY	0	14400	f	2010-08-02	4352	\N	9412	\N
102856	GENERIC_DAY	0	14400	f	2010-08-19	4354	\N	9412	\N
102857	GENERIC_DAY	0	14400	f	2010-08-23	4352	\N	9412	\N
102858	GENERIC_DAY	0	14400	f	2010-07-29	4352	\N	9412	\N
102859	GENERIC_DAY	0	14400	f	2010-07-29	4354	\N	9412	\N
102860	GENERIC_DAY	0	0	f	2010-08-29	4354	\N	9412	\N
102861	GENERIC_DAY	0	0	f	2010-08-08	4352	\N	9412	\N
31140	GENERIC_DAY	4	0	f	2010-06-27	21817	\N	27090	\N
31167	GENERIC_DAY	4	3600	f	2010-07-02	4348	\N	27090	\N
31158	GENERIC_DAY	4	10800	f	2010-06-29	4348	\N	27090	\N
31148	GENERIC_DAY	4	0	f	2010-07-11	4344	\N	27090	\N
31107	GENERIC_DAY	4	0	f	2010-07-04	4348	\N	27090	\N
31170	GENERIC_DAY	4	0	f	2010-07-14	4344	\N	27090	\N
31117	GENERIC_DAY	4	21600	f	2010-07-02	21817	\N	27090	\N
31128	GENERIC_DAY	4	7200	f	2010-07-13	4358	\N	27090	\N
31161	GENERIC_DAY	4	0	f	2010-06-27	4344	\N	27090	\N
31127	GENERIC_DAY	4	3600	f	2010-07-12	4350	\N	27090	\N
31106	GENERIC_DAY	4	0	f	2010-07-03	4344	\N	27090	\N
31125	GENERIC_DAY	4	21600	f	2010-07-08	21817	\N	27090	\N
31124	GENERIC_DAY	4	14400	f	2010-07-01	21817	\N	27090	\N
31136	GENERIC_DAY	4	0	f	2010-07-11	4350	\N	27090	\N
31142	GENERIC_DAY	4	0	f	2010-07-07	4344	\N	27090	\N
31180	GENERIC_DAY	4	0	f	2010-07-04	21817	\N	27090	\N
31159	GENERIC_DAY	4	0	f	2010-06-28	4344	\N	27090	\N
31155	GENERIC_DAY	4	10800	f	2010-06-28	4358	\N	27090	\N
31160	GENERIC_DAY	4	0	f	2010-07-04	4350	\N	27090	\N
31123	GENERIC_DAY	4	21600	f	2010-07-07	21817	\N	27090	\N
31163	GENERIC_DAY	4	0	f	2010-07-06	4344	\N	27090	\N
31183	GENERIC_DAY	4	3600	f	2010-07-12	4348	\N	27090	\N
31109	GENERIC_DAY	4	3600	f	2010-07-14	4350	\N	27090	\N
31165	GENERIC_DAY	4	0	f	2010-07-12	4344	\N	27090	\N
31186	GENERIC_DAY	4	3600	f	2010-07-06	4358	\N	27090	\N
31120	GENERIC_DAY	4	0	f	2010-07-05	4344	\N	27090	\N
31112	GENERIC_DAY	4	7200	f	2010-07-01	4348	\N	27090	\N
31129	GENERIC_DAY	4	0	f	2010-07-03	4350	\N	27090	\N
27541	GENERIC_DAY	9	14400	f	2010-09-14	4352	\N	27073	\N
27561	GENERIC_DAY	9	14400	f	2010-09-10	4352	\N	27073	\N
27553	GENERIC_DAY	9	14400	f	2010-09-16	4352	\N	27073	\N
27551	GENERIC_DAY	9	14400	f	2010-09-17	4354	\N	27073	\N
27538	GENERIC_DAY	9	0	f	2010-09-19	4352	\N	27073	\N
27555	GENERIC_DAY	9	0	f	2010-09-12	4352	\N	27073	\N
27566	GENERIC_DAY	9	0	f	2010-09-11	4352	\N	27073	\N
27560	GENERIC_DAY	9	14400	f	2010-09-16	4354	\N	27073	\N
27554	GENERIC_DAY	9	14400	f	2010-09-15	4352	\N	27073	\N
27558	GENERIC_DAY	9	14400	f	2010-09-08	4354	\N	27073	\N
27544	GENERIC_DAY	9	14400	f	2010-09-13	4354	\N	27073	\N
27546	GENERIC_DAY	9	14400	f	2010-09-07	4354	\N	27073	\N
27565	GENERIC_DAY	9	14400	f	2010-09-22	4354	\N	27073	\N
27567	GENERIC_DAY	9	0	f	2010-09-11	4354	\N	27073	\N
27545	GENERIC_DAY	9	0	f	2010-09-12	4354	\N	27073	\N
27552	GENERIC_DAY	9	7200	f	2010-09-23	4354	\N	27073	\N
27548	GENERIC_DAY	9	14400	f	2010-09-14	4354	\N	27073	\N
27559	GENERIC_DAY	9	14400	f	2010-09-20	4354	\N	27073	\N
27568	GENERIC_DAY	9	14400	f	2010-09-08	4352	\N	27073	\N
27557	GENERIC_DAY	9	0	f	2010-09-19	4354	\N	27073	\N
27543	GENERIC_DAY	9	14400	f	2010-09-21	4354	\N	27073	\N
27562	GENERIC_DAY	9	14400	f	2010-09-21	4352	\N	27073	\N
27550	GENERIC_DAY	9	14400	f	2010-09-09	4354	\N	27073	\N
27537	GENERIC_DAY	9	14400	f	2010-09-07	4352	\N	27073	\N
27540	GENERIC_DAY	9	14400	f	2010-09-10	4354	\N	27073	\N
27569	GENERIC_DAY	9	14400	f	2010-09-13	4352	\N	27073	\N
27564	GENERIC_DAY	9	7200	f	2010-09-23	4352	\N	27073	\N
27563	GENERIC_DAY	9	0	f	2010-09-18	4354	\N	27073	\N
27536	GENERIC_DAY	9	14400	f	2010-09-20	4352	\N	27073	\N
27549	GENERIC_DAY	9	14400	f	2010-09-09	4352	\N	27073	\N
27542	GENERIC_DAY	9	14400	f	2010-09-17	4352	\N	27073	\N
27539	GENERIC_DAY	9	14400	f	2010-09-15	4354	\N	27073	\N
27556	GENERIC_DAY	9	14400	f	2010-09-22	4352	\N	27073	\N
27547	GENERIC_DAY	9	0	f	2010-09-18	4352	\N	27073	\N
45562	GENERIC_DAY	3	14400	f	2010-09-13	4352	\N	42595	\N
45566	GENERIC_DAY	3	0	f	2010-09-25	4354	\N	42595	\N
45565	GENERIC_DAY	3	14400	f	2010-09-29	4354	\N	42595	\N
45567	GENERIC_DAY	3	0	f	2010-09-04	4352	\N	42595	\N
45561	GENERIC_DAY	3	0	f	2010-08-28	4352	\N	42595	\N
45563	GENERIC_DAY	3	14400	f	2010-09-29	4352	\N	42595	\N
45564	GENERIC_DAY	3	14400	f	2010-08-26	4352	\N	42595	\N
45611	GENERIC_DAY	3	14400	f	2010-08-31	4352	\N	42595	\N
45580	GENERIC_DAY	3	14400	f	2010-09-23	4354	\N	42595	\N
45597	GENERIC_DAY	3	3600	f	2010-09-30	4352	\N	42595	\N
45604	GENERIC_DAY	3	14400	f	2010-08-30	4352	\N	42595	\N
45586	GENERIC_DAY	3	14400	f	2010-09-23	4352	\N	42595	\N
45618	GENERIC_DAY	3	0	f	2010-09-18	4352	\N	42595	\N
45599	GENERIC_DAY	3	14400	f	2010-09-28	4354	\N	42595	\N
45589	GENERIC_DAY	3	14400	f	2010-09-27	4354	\N	42595	\N
45624	GENERIC_DAY	3	14400	f	2010-08-27	4352	\N	42595	\N
45585	GENERIC_DAY	3	14400	f	2010-09-09	4354	\N	42595	\N
45570	GENERIC_DAY	3	14400	f	2010-09-24	4354	\N	42595	\N
45578	GENERIC_DAY	3	0	f	2010-09-18	4354	\N	42595	\N
45620	GENERIC_DAY	3	0	f	2010-09-11	4352	\N	42595	\N
45596	GENERIC_DAY	3	0	f	2010-08-29	4352	\N	42595	\N
103052	GENERIC_DAY	2	14400	f	2010-07-12	21817	\N	83254	\N
103053	GENERIC_DAY	2	3600	f	2010-07-14	4348	\N	83254	\N
103054	GENERIC_DAY	2	14400	f	2010-07-13	4350	\N	83254	\N
103055	GENERIC_DAY	2	0	f	2010-07-14	4358	\N	83254	\N
103056	GENERIC_DAY	2	0	f	2010-07-11	4344	\N	83254	\N
103057	GENERIC_DAY	2	14400	f	2010-07-13	4358	\N	83254	\N
103058	GENERIC_DAY	2	14400	f	2010-07-09	21817	\N	83254	\N
103059	GENERIC_DAY	2	14400	f	2010-07-13	21817	\N	83254	\N
103060	GENERIC_DAY	2	14400	f	2010-07-12	4348	\N	83254	\N
103061	GENERIC_DAY	2	0	f	2010-07-11	21817	\N	83254	\N
103062	GENERIC_DAY	2	0	f	2010-07-11	4350	\N	83254	\N
103063	GENERIC_DAY	2	0	f	2010-07-11	4348	\N	83254	\N
103064	GENERIC_DAY	2	14400	f	2010-07-09	4348	\N	83254	\N
103065	GENERIC_DAY	2	0	f	2010-07-10	21817	\N	83254	\N
103066	GENERIC_DAY	2	0	f	2010-07-14	4344	\N	83254	\N
103067	GENERIC_DAY	2	0	f	2010-07-10	4348	\N	83254	\N
103068	GENERIC_DAY	2	0	f	2010-07-10	4350	\N	83254	\N
103069	GENERIC_DAY	2	14400	f	2010-07-12	4350	\N	83254	\N
103070	GENERIC_DAY	2	0	f	2010-07-11	4358	\N	83254	\N
103071	GENERIC_DAY	2	36000	f	2010-07-15	4352	\N	83255	\N
103072	GENERIC_DAY	2	36000	f	2010-07-15	4354	\N	83255	\N
103042	GENERIC_DAY	2	0	f	2010-07-10	4358	\N	83254	\N
103043	GENERIC_DAY	2	3600	f	2010-07-14	4350	\N	83254	\N
103044	GENERIC_DAY	2	14400	f	2010-07-09	4350	\N	83254	\N
103045	GENERIC_DAY	2	0	f	2010-07-13	4344	\N	83254	\N
103046	GENERIC_DAY	2	0	f	2010-07-09	4344	\N	83254	\N
103047	GENERIC_DAY	2	14400	f	2010-07-13	4348	\N	83254	\N
103048	GENERIC_DAY	2	0	f	2010-07-10	4344	\N	83254	\N
103049	GENERIC_DAY	2	0	f	2010-07-12	4344	\N	83254	\N
103050	GENERIC_DAY	2	14400	f	2010-07-12	4358	\N	83254	\N
103051	GENERIC_DAY	2	14400	f	2010-07-09	4358	\N	83254	\N
45608	GENERIC_DAY	3	14400	f	2010-08-25	4352	\N	42595	\N
45633	GENERIC_DAY	3	14400	f	2010-09-02	4352	\N	42595	\N
45629	GENERIC_DAY	3	0	f	2010-08-28	4354	\N	42595	\N
45625	GENERIC_DAY	3	14400	f	2010-09-22	4354	\N	42595	\N
45602	GENERIC_DAY	3	14400	f	2010-08-30	4354	\N	42595	\N
45621	GENERIC_DAY	3	0	f	2010-09-19	4354	\N	42595	\N
45623	GENERIC_DAY	3	14400	f	2010-09-16	4354	\N	42595	\N
45601	GENERIC_DAY	3	0	f	2010-09-12	4354	\N	42595	\N
45595	GENERIC_DAY	3	14400	f	2010-09-20	4354	\N	42595	\N
45606	GENERIC_DAY	3	0	f	2010-09-11	4354	\N	42595	\N
45610	GENERIC_DAY	3	0	f	2010-09-04	4354	\N	42595	\N
45626	GENERIC_DAY	3	14400	f	2010-08-26	4354	\N	42595	\N
75637	GENERIC_DAY	7	10800	f	2010-06-30	4358	\N	16800	\N
75640	GENERIC_DAY	7	0	f	2010-07-02	4350	\N	16800	\N
75595	GENERIC_DAY	7	10800	f	2010-07-01	4358	\N	16800	\N
75590	GENERIC_DAY	7	0	f	2010-06-20	4350	\N	16800	\N
75593	GENERIC_DAY	7	7200	f	2010-06-30	4348	\N	16800	\N
75643	GENERIC_DAY	7	0	f	2010-07-04	21817	\N	16800	\N
75591	GENERIC_DAY	7	0	t	2010-06-15	4348	\N	16800	\N
75638	GENERIC_DAY	7	0	f	2010-06-21	4350	\N	16800	\N
75596	GENERIC_DAY	7	7200	f	2010-06-23	4348	\N	16800	\N
75599	GENERIC_DAY	7	10800	f	2010-07-02	21817	\N	16800	\N
75644	GENERIC_DAY	7	10800	f	2010-06-21	4358	\N	16800	\N
75592	GENERIC_DAY	7	10800	f	2010-06-17	4358	\N	16800	\N
75639	GENERIC_DAY	7	0	f	2010-06-18	4348	\N	16800	\N
75598	GENERIC_DAY	7	18000	t	2010-06-16	21817	\N	16800	\N
75594	GENERIC_DAY	7	0	f	2010-06-21	4344	\N	16800	\N
75588	GENERIC_DAY	7	0	f	2010-06-27	4348	\N	16800	\N
75587	GENERIC_DAY	7	0	f	2010-06-27	21817	\N	16800	\N
75600	GENERIC_DAY	7	0	f	2010-06-29	4350	\N	16800	\N
75641	GENERIC_DAY	7	7200	f	2010-06-28	4358	\N	16800	\N
75589	GENERIC_DAY	7	0	f	2010-07-03	4344	\N	16800	\N
75597	GENERIC_DAY	7	0	t	2010-06-15	4344	\N	16800	\N
75645	GENERIC_DAY	7	18000	f	2010-06-17	21817	\N	16800	\N
75642	GENERIC_DAY	7	0	f	2010-06-19	4350	\N	16800	\N
48434	SPECIFIC_DAY	2	0	t	2010-09-12	4354	46089	\N	\N
48439	SPECIFIC_DAY	2	28800	t	2010-09-10	4354	46089	\N	\N
48431	SPECIFIC_DAY	2	28800	t	2010-08-31	4354	46089	\N	\N
48441	SPECIFIC_DAY	2	28800	t	2010-09-08	4354	46089	\N	\N
48426	SPECIFIC_DAY	2	28800	t	2010-09-03	4354	46089	\N	\N
48440	SPECIFIC_DAY	2	28800	t	2010-09-15	4354	46089	\N	\N
48428	SPECIFIC_DAY	2	0	t	2010-09-11	4354	46089	\N	\N
48400	SPECIFIC_DAY	2	28800	t	2010-08-30	4354	46089	\N	\N
48417	SPECIFIC_DAY	2	0	t	2010-08-29	4354	46089	\N	\N
48403	SPECIFIC_DAY	2	0	t	2010-09-05	4354	46089	\N	\N
48379	SPECIFIC_DAY	2	28800	t	2010-09-13	4354	46089	\N	\N
48418	SPECIFIC_DAY	2	28800	t	2010-09-06	4354	46089	\N	\N
48390	SPECIFIC_DAY	2	28800	t	2010-09-02	4354	46089	\N	\N
48399	SPECIFIC_DAY	2	28800	t	2010-09-07	4354	46089	\N	\N
48384	SPECIFIC_DAY	2	28800	t	2010-09-01	4354	46089	\N	\N
48404	SPECIFIC_DAY	2	0	t	2010-09-04	4354	46089	\N	\N
48393	SPECIFIC_DAY	2	28800	t	2010-09-09	4354	46089	\N	\N
48407	SPECIFIC_DAY	2	28800	t	2010-09-14	4354	46089	\N	\N
45616	GENERIC_DAY	3	14400	f	2010-09-01	4352	\N	42595	\N
45568	GENERIC_DAY	3	14400	f	2010-09-17	4352	\N	42595	\N
45575	GENERIC_DAY	3	14400	f	2010-09-06	4354	\N	42595	\N
45582	GENERIC_DAY	3	14400	f	2010-08-25	4354	\N	42595	\N
45569	GENERIC_DAY	3	14400	f	2010-09-16	4352	\N	42595	\N
45594	GENERIC_DAY	3	0	f	2010-09-19	4352	\N	42595	\N
45590	GENERIC_DAY	3	14400	f	2010-09-24	4352	\N	42595	\N
45572	GENERIC_DAY	3	14400	f	2010-09-15	4352	\N	42595	\N
45571	GENERIC_DAY	3	14400	f	2010-09-10	4352	\N	42595	\N
45574	GENERIC_DAY	3	0	f	2010-09-26	4354	\N	42595	\N
45584	GENERIC_DAY	3	14400	f	2010-09-21	4354	\N	42595	\N
45609	GENERIC_DAY	3	14400	f	2010-09-03	4354	\N	42595	\N
45576	GENERIC_DAY	3	14400	f	2010-09-01	4354	\N	42595	\N
45612	GENERIC_DAY	3	0	f	2010-09-05	4354	\N	42595	\N
45631	GENERIC_DAY	3	14400	f	2010-09-02	4354	\N	42595	\N
45622	GENERIC_DAY	3	14400	f	2010-09-14	4354	\N	42595	\N
45581	GENERIC_DAY	3	0	f	2010-09-12	4352	\N	42595	\N
45587	GENERIC_DAY	3	14400	f	2010-09-08	4354	\N	42595	\N
45579	GENERIC_DAY	3	3600	f	2010-09-30	4354	\N	42595	\N
45605	GENERIC_DAY	3	14400	f	2010-09-20	4352	\N	42595	\N
45630	GENERIC_DAY	3	14400	f	2010-09-22	4352	\N	42595	\N
45583	GENERIC_DAY	3	14400	f	2010-08-31	4354	\N	42595	\N
45634	GENERIC_DAY	3	14400	f	2010-09-21	4352	\N	42595	\N
45617	GENERIC_DAY	3	14400	f	2010-09-08	4352	\N	42595	\N
45591	GENERIC_DAY	3	0	f	2010-08-29	4354	\N	42595	\N
45588	GENERIC_DAY	3	14400	f	2010-09-15	4354	\N	42595	\N
45607	GENERIC_DAY	3	14400	f	2010-09-28	4352	\N	42595	\N
45628	GENERIC_DAY	3	0	f	2010-09-05	4352	\N	42595	\N
45592	GENERIC_DAY	3	14400	f	2010-08-27	4354	\N	42595	\N
45619	GENERIC_DAY	3	14400	f	2010-09-17	4354	\N	42595	\N
45577	GENERIC_DAY	3	14400	f	2010-09-27	4352	\N	42595	\N
45603	GENERIC_DAY	3	14400	f	2010-09-07	4352	\N	42595	\N
45614	GENERIC_DAY	3	14400	f	2010-09-14	4352	\N	42595	\N
45613	GENERIC_DAY	3	14400	f	2010-09-06	4352	\N	42595	\N
45627	GENERIC_DAY	3	14400	f	2010-09-07	4354	\N	42595	\N
45615	GENERIC_DAY	3	0	f	2010-09-26	4352	\N	42595	\N
45600	GENERIC_DAY	3	14400	f	2010-09-09	4352	\N	42595	\N
45573	GENERIC_DAY	3	14400	f	2010-09-13	4354	\N	42595	\N
45632	GENERIC_DAY	3	14400	f	2010-09-03	4352	\N	42595	\N
45593	GENERIC_DAY	3	0	f	2010-09-25	4352	\N	42595	\N
45598	GENERIC_DAY	3	14400	f	2010-09-10	4354	\N	42595	\N
75703	SPECIFIC_DAY	2	0	f	2010-09-19	1220	31222	\N	\N
75708	SPECIFIC_DAY	2	28800	f	2010-09-22	1220	31222	\N	\N
75705	SPECIFIC_DAY	2	28800	f	2010-09-27	1220	31222	\N	\N
50817	SPECIFIC_DAY	0	36000	f	2010-09-20	4354	46089	\N	\N
50818	SPECIFIC_DAY	0	36000	f	2010-10-01	4354	46089	\N	\N
50819	SPECIFIC_DAY	0	0	f	2010-09-25	4354	46089	\N	\N
50820	SPECIFIC_DAY	0	36000	f	2010-10-20	4354	46089	\N	\N
50821	SPECIFIC_DAY	0	0	f	2010-10-10	4354	46089	\N	\N
50822	SPECIFIC_DAY	0	0	f	2010-10-02	4354	46089	\N	\N
50823	SPECIFIC_DAY	0	36000	f	2010-09-30	4354	46089	\N	\N
50824	SPECIFIC_DAY	0	36000	f	2010-10-18	4354	46089	\N	\N
50825	SPECIFIC_DAY	0	36000	f	2010-10-05	4354	46089	\N	\N
50826	SPECIFIC_DAY	0	0	f	2010-10-23	4354	46089	\N	\N
50827	SPECIFIC_DAY	0	32400	f	2010-10-25	4354	46089	\N	\N
50828	SPECIFIC_DAY	0	36000	f	2010-10-21	4354	46089	\N	\N
50829	SPECIFIC_DAY	0	36000	f	2010-10-12	4354	46089	\N	\N
50830	SPECIFIC_DAY	0	36000	f	2010-09-23	4354	46089	\N	\N
50831	SPECIFIC_DAY	0	32400	f	2010-11-03	4354	46089	\N	\N
50832	SPECIFIC_DAY	0	0	f	2010-10-16	4354	46089	\N	\N
50833	SPECIFIC_DAY	0	36000	f	2010-09-16	4354	46089	\N	\N
50834	SPECIFIC_DAY	0	32400	f	2010-11-04	4354	46089	\N	\N
50835	SPECIFIC_DAY	0	0	f	2010-10-24	4354	46089	\N	\N
50836	SPECIFIC_DAY	0	36000	f	2010-10-07	4354	46089	\N	\N
50837	SPECIFIC_DAY	0	36000	f	2010-10-15	4354	46089	\N	\N
50838	SPECIFIC_DAY	0	36000	f	2010-09-29	4354	46089	\N	\N
50839	SPECIFIC_DAY	0	32400	f	2010-11-02	4354	46089	\N	\N
50840	SPECIFIC_DAY	0	32400	f	2010-10-27	4354	46089	\N	\N
50841	SPECIFIC_DAY	0	36000	f	2010-10-22	4354	46089	\N	\N
50842	SPECIFIC_DAY	0	0	f	2010-09-26	4354	46089	\N	\N
50843	SPECIFIC_DAY	0	36000	f	2010-09-22	4354	46089	\N	\N
50844	SPECIFIC_DAY	0	36000	f	2010-10-19	4354	46089	\N	\N
50845	SPECIFIC_DAY	0	0	f	2010-10-09	4354	46089	\N	\N
50846	SPECIFIC_DAY	0	32400	f	2010-10-26	4354	46089	\N	\N
50847	SPECIFIC_DAY	0	32400	f	2010-11-01	4354	46089	\N	\N
50848	SPECIFIC_DAY	0	36000	f	2010-09-27	4354	46089	\N	\N
50849	SPECIFIC_DAY	0	0	f	2010-09-19	4354	46089	\N	\N
75721	SPECIFIC_DAY	2	28800	f	2010-09-24	1220	31222	\N	\N
75710	SPECIFIC_DAY	2	0	f	2010-09-11	1220	31222	\N	\N
75707	SPECIFIC_DAY	2	28800	f	2010-09-16	1220	31222	\N	\N
75713	SPECIFIC_DAY	2	28800	f	2010-09-20	1220	31222	\N	\N
50850	SPECIFIC_DAY	0	32400	f	2010-11-05	4354	46089	\N	\N
50851	SPECIFIC_DAY	0	36000	f	2010-10-14	4354	46089	\N	\N
50852	SPECIFIC_DAY	0	36000	f	2010-09-28	4354	46089	\N	\N
50853	SPECIFIC_DAY	0	0	f	2010-09-18	4354	46089	\N	\N
50854	SPECIFIC_DAY	0	36000	f	2010-09-21	4354	46089	\N	\N
50855	SPECIFIC_DAY	0	36000	f	2010-10-11	4354	46089	\N	\N
50856	SPECIFIC_DAY	0	32400	f	2010-10-28	4354	46089	\N	\N
50857	SPECIFIC_DAY	0	36000	f	2010-09-24	4354	46089	\N	\N
50858	SPECIFIC_DAY	0	32400	f	2010-10-29	4354	46089	\N	\N
50859	SPECIFIC_DAY	0	36000	f	2010-10-08	4354	46089	\N	\N
50860	SPECIFIC_DAY	0	36000	f	2010-09-17	4354	46089	\N	\N
50861	SPECIFIC_DAY	0	36000	f	2010-10-13	4354	46089	\N	\N
50862	SPECIFIC_DAY	0	0	f	2010-10-31	4354	46089	\N	\N
50863	SPECIFIC_DAY	0	36000	f	2010-10-06	4354	46089	\N	\N
50864	SPECIFIC_DAY	0	0	f	2010-10-30	4354	46089	\N	\N
50865	SPECIFIC_DAY	0	0	f	2010-10-17	4354	46089	\N	\N
50866	SPECIFIC_DAY	0	36000	f	2010-10-04	4354	46089	\N	\N
50867	SPECIFIC_DAY	0	0	f	2010-10-03	4354	46089	\N	\N
75722	SPECIFIC_DAY	0	28800	f	2011-02-11	1216	2732	\N	\N
75723	SPECIFIC_DAY	0	28800	f	2011-02-03	1216	2732	\N	\N
75724	SPECIFIC_DAY	0	28800	f	2011-02-10	1216	2732	\N	\N
75725	SPECIFIC_DAY	0	14400	f	2011-01-26	1216	2732	\N	\N
75726	SPECIFIC_DAY	0	28800	f	2011-02-07	1216	2732	\N	\N
75727	SPECIFIC_DAY	0	28800	f	2011-02-09	1216	2732	\N	\N
75728	SPECIFIC_DAY	0	28800	f	2011-02-04	1216	2732	\N	\N
75729	SPECIFIC_DAY	0	28800	f	2011-02-02	1216	2732	\N	\N
75730	SPECIFIC_DAY	0	28800	f	2011-01-31	1216	2732	\N	\N
75731	SPECIFIC_DAY	0	28800	f	2011-02-01	1216	2732	\N	\N
75732	SPECIFIC_DAY	0	28800	f	2011-01-27	1216	2732	\N	\N
75733	SPECIFIC_DAY	0	28800	f	2011-02-08	1216	2732	\N	\N
75734	SPECIFIC_DAY	0	28800	f	2011-01-28	1216	2732	\N	\N
75735	SPECIFIC_DAY	2	28800	f	2010-08-04	1216	31223	\N	\N
75738	SPECIFIC_DAY	2	28800	f	2010-08-03	1216	31223	\N	\N
75737	SPECIFIC_DAY	2	28800	f	2010-07-20	1216	31223	\N	\N
75742	SPECIFIC_DAY	2	28800	f	2010-07-27	1216	31223	\N	\N
75736	SPECIFIC_DAY	2	28800	f	2010-07-23	1216	31223	\N	\N
75746	SPECIFIC_DAY	2	28800	f	2010-07-30	1216	31223	\N	\N
75739	SPECIFIC_DAY	2	28800	f	2010-07-22	1216	31223	\N	\N
75747	SPECIFIC_DAY	2	28800	f	2010-08-02	1216	31223	\N	\N
75743	SPECIFIC_DAY	2	28800	f	2010-07-26	1216	31223	\N	\N
75745	SPECIFIC_DAY	2	28800	f	2010-07-29	1216	31223	\N	\N
75740	SPECIFIC_DAY	2	28800	f	2010-07-21	1216	31223	\N	\N
75741	SPECIFIC_DAY	2	28800	f	2010-07-28	1216	31223	\N	\N
75744	SPECIFIC_DAY	2	14400	f	2010-07-19	1216	31223	\N	\N
75855	SPECIFIC_DAY	2	28800	f	2010-08-18	1216	31221	\N	\N
75860	SPECIFIC_DAY	2	14400	f	2010-08-05	1216	31221	\N	\N
75749	SPECIFIC_DAY	2	28800	f	2010-08-17	1216	31221	\N	\N
75856	SPECIFIC_DAY	2	28800	f	2010-08-23	1216	31221	\N	\N
75857	SPECIFIC_DAY	2	28800	f	2010-08-12	1216	31221	\N	\N
75748	SPECIFIC_DAY	2	28800	f	2010-08-10	1216	31221	\N	\N
75851	SPECIFIC_DAY	2	28800	f	2010-08-09	1216	31221	\N	\N
75854	SPECIFIC_DAY	2	28800	f	2010-08-06	1216	31221	\N	\N
75853	SPECIFIC_DAY	2	28800	f	2010-08-19	1216	31221	\N	\N
75858	SPECIFIC_DAY	2	28800	f	2010-08-20	1216	31221	\N	\N
75859	SPECIFIC_DAY	2	28800	f	2010-08-11	1216	31221	\N	\N
75904	SPECIFIC_DAY	2	28800	f	2010-12-24	1216	31224	\N	\N
75883	SPECIFIC_DAY	2	28800	f	2010-11-10	1216	31224	\N	\N
75910	SPECIFIC_DAY	2	28800	f	2010-12-09	1216	31224	\N	\N
75868	SPECIFIC_DAY	2	28800	f	2010-12-27	1216	31224	\N	\N
75871	SPECIFIC_DAY	2	0	f	2010-11-14	1216	31224	\N	\N
75862	SPECIFIC_DAY	2	28800	f	2010-12-16	1216	31224	\N	\N
75873	SPECIFIC_DAY	2	0	f	2010-11-21	1216	31224	\N	\N
75887	SPECIFIC_DAY	2	28800	f	2010-12-20	1216	31224	\N	\N
75900	SPECIFIC_DAY	2	28800	f	2010-12-22	1216	31224	\N	\N
75884	SPECIFIC_DAY	2	28800	f	2010-11-24	1216	31224	\N	\N
75909	SPECIFIC_DAY	2	0	f	2010-11-05	1216	31224	\N	\N
75888	SPECIFIC_DAY	2	0	f	2010-12-11	1216	31224	\N	\N
75893	SPECIFIC_DAY	2	28800	f	2010-12-10	1216	31224	\N	\N
75906	SPECIFIC_DAY	2	28800	f	2010-12-07	1216	31224	\N	\N
75901	SPECIFIC_DAY	2	28800	f	2010-12-01	1216	31224	\N	\N
13707	SPECIFIC_DAY	1	0	f	2010-06-20	4344	8089	\N	\N
13704	SPECIFIC_DAY	1	28800	f	2010-06-23	4344	8089	\N	\N
13728	SPECIFIC_DAY	1	28800	f	2010-06-25	4344	8089	\N	\N
13708	SPECIFIC_DAY	1	0	f	2010-07-11	4344	8089	\N	\N
13702	SPECIFIC_DAY	1	28800	f	2010-06-24	4344	8089	\N	\N
13725	SPECIFIC_DAY	1	28800	f	2010-07-13	4344	8089	\N	\N
13721	SPECIFIC_DAY	1	0	f	2010-07-10	4344	8089	\N	\N
13723	SPECIFIC_DAY	1	0	f	2010-06-26	4344	8089	\N	\N
13709	SPECIFIC_DAY	1	28800	f	2010-06-16	4344	8089	\N	\N
13701	SPECIFIC_DAY	1	28800	f	2010-07-09	4344	8089	\N	\N
13697	SPECIFIC_DAY	1	0	f	2010-07-03	4344	8089	\N	\N
13726	SPECIFIC_DAY	1	0	f	2010-06-27	4344	8089	\N	\N
13724	SPECIFIC_DAY	1	28800	f	2010-07-14	4344	8089	\N	\N
13710	SPECIFIC_DAY	1	28800	f	2010-07-06	4344	8089	\N	\N
13706	SPECIFIC_DAY	1	28800	f	2010-07-07	4344	8089	\N	\N
13703	SPECIFIC_DAY	1	28800	f	2010-06-30	4344	8089	\N	\N
13717	SPECIFIC_DAY	1	28800	f	2010-06-28	4344	8089	\N	\N
13720	SPECIFIC_DAY	1	28800	f	2010-07-08	4344	8089	\N	\N
13712	SPECIFIC_DAY	1	28800	f	2010-07-15	4344	8089	\N	\N
13715	SPECIFIC_DAY	1	0	f	2010-06-19	4344	8089	\N	\N
13718	SPECIFIC_DAY	1	28800	f	2010-06-15	4344	8089	\N	\N
13699	SPECIFIC_DAY	1	28800	f	2010-07-05	4344	8089	\N	\N
13698	SPECIFIC_DAY	1	28800	f	2010-06-18	4344	8089	\N	\N
13705	SPECIFIC_DAY	1	28800	f	2010-07-01	4344	8089	\N	\N
13711	SPECIFIC_DAY	1	28800	f	2010-06-17	4344	8089	\N	\N
13722	SPECIFIC_DAY	1	28800	f	2010-06-29	4344	8089	\N	\N
13729	SPECIFIC_DAY	1	28800	f	2010-06-22	4344	8089	\N	\N
13719	SPECIFIC_DAY	1	28800	f	2010-06-14	4344	8089	\N	\N
13700	SPECIFIC_DAY	1	0	f	2010-07-04	4344	8089	\N	\N
13727	SPECIFIC_DAY	1	28800	f	2010-07-16	4344	8089	\N	\N
13713	SPECIFIC_DAY	1	28800	f	2010-07-12	4344	8089	\N	\N
13716	SPECIFIC_DAY	1	28800	f	2010-07-02	4344	8089	\N	\N
13714	SPECIFIC_DAY	1	28800	f	2010-06-21	4344	8089	\N	\N
13732	SPECIFIC_DAY	1	10800	f	2010-06-22	4348	8090	\N	\N
13730	SPECIFIC_DAY	1	28800	f	2010-06-21	4348	8090	\N	\N
13735	SPECIFIC_DAY	1	28800	f	2010-06-14	4348	8090	\N	\N
13731	SPECIFIC_DAY	1	28800	f	2010-06-17	4348	8090	\N	\N
13736	SPECIFIC_DAY	1	0	f	2010-06-19	4348	8090	\N	\N
13737	SPECIFIC_DAY	1	28800	f	2010-06-18	4348	8090	\N	\N
13734	SPECIFIC_DAY	1	28800	f	2010-06-15	4348	8090	\N	\N
13733	SPECIFIC_DAY	1	0	f	2010-06-20	4348	8090	\N	\N
13826	GENERIC_DAY	1	0	f	2010-06-19	1220	\N	9406	\N
13821	GENERIC_DAY	1	0	f	2010-06-16	4354	\N	9406	\N
13808	GENERIC_DAY	1	7200	f	2010-06-16	4356	\N	9406	\N
13797	GENERIC_DAY	1	0	f	2010-06-22	4358	\N	9406	\N
13786	GENERIC_DAY	1	0	f	2010-06-18	4344	\N	9406	\N
13827	GENERIC_DAY	1	0	f	2010-06-19	4354	\N	9406	\N
13812	GENERIC_DAY	1	3600	f	2010-06-14	4352	\N	9406	\N
13807	GENERIC_DAY	1	0	f	2010-06-22	4356	\N	9406	\N
13764	GENERIC_DAY	1	0	f	2010-06-18	4350	\N	9406	\N
13780	GENERIC_DAY	1	10800	f	2010-06-17	1214	\N	9406	\N
13793	GENERIC_DAY	1	7200	f	2010-06-14	1214	\N	9406	\N
13809	GENERIC_DAY	1	0	f	2010-06-16	4344	\N	9406	\N
13771	GENERIC_DAY	1	0	f	2010-06-22	4354	\N	9406	\N
13766	GENERIC_DAY	1	0	f	2010-06-20	1214	\N	9406	\N
13796	GENERIC_DAY	1	0	f	2010-06-15	4354	\N	9406	\N
13822	GENERIC_DAY	1	0	f	2010-06-14	1216	\N	9406	\N
13803	GENERIC_DAY	1	0	f	2010-06-15	4358	\N	9406	\N
13820	GENERIC_DAY	1	0	f	2010-06-21	4358	\N	9406	\N
13798	GENERIC_DAY	1	7200	f	2010-06-21	4356	\N	9406	\N
13813	GENERIC_DAY	1	0	f	2010-06-22	4352	\N	9406	\N
13773	GENERIC_DAY	1	0	f	2010-06-15	4352	\N	9406	\N
13785	GENERIC_DAY	1	0	f	2010-06-19	4350	\N	9406	\N
13770	GENERIC_DAY	1	0	f	2010-06-16	4358	\N	9406	\N
13768	GENERIC_DAY	1	10800	f	2010-06-15	1214	\N	9406	\N
13782	GENERIC_DAY	1	0	f	2010-06-17	1216	\N	9406	\N
13788	GENERIC_DAY	1	0	f	2010-06-19	4348	\N	9406	\N
13777	GENERIC_DAY	1	0	f	2010-06-15	4348	\N	9406	\N
13811	GENERIC_DAY	1	0	f	2010-06-17	4344	\N	9406	\N
13765	GENERIC_DAY	1	0	f	2010-06-15	1216	\N	9406	\N
13784	GENERIC_DAY	1	0	f	2010-06-20	1220	\N	9406	\N
13800	GENERIC_DAY	1	0	f	2010-06-21	4348	\N	9406	\N
13815	GENERIC_DAY	1	0	f	2010-06-21	4354	\N	9406	\N
13817	GENERIC_DAY	1	10800	f	2010-06-16	1220	\N	9406	\N
13804	GENERIC_DAY	1	0	f	2010-06-14	4350	\N	9406	\N
13757	GENERIC_DAY	1	10800	f	2010-06-15	1220	\N	9406	\N
13781	GENERIC_DAY	1	10800	f	2010-06-16	1214	\N	9406	\N
13799	GENERIC_DAY	1	10800	f	2010-06-17	1220	\N	9406	\N
13792	GENERIC_DAY	1	0	f	2010-06-22	4348	\N	9406	\N
13787	GENERIC_DAY	1	0	f	2010-06-19	4352	\N	9406	\N
13816	GENERIC_DAY	1	7200	f	2010-06-15	4356	\N	9406	\N
13794	GENERIC_DAY	1	0	f	2010-06-16	4350	\N	9406	\N
13759	GENERIC_DAY	1	0	f	2010-06-20	4350	\N	9406	\N
13763	GENERIC_DAY	1	0	f	2010-06-16	1216	\N	9406	\N
13760	GENERIC_DAY	1	0	f	2010-06-20	4352	\N	9406	\N
13775	GENERIC_DAY	1	0	f	2010-06-22	4350	\N	9406	\N
13825	GENERIC_DAY	1	0	f	2010-06-17	4350	\N	9406	\N
13789	GENERIC_DAY	1	0	f	2010-06-21	1216	\N	9406	\N
13805	GENERIC_DAY	1	0	f	2010-06-17	4352	\N	9406	\N
13823	GENERIC_DAY	1	0	f	2010-06-20	4354	\N	9406	\N
13791	GENERIC_DAY	1	0	f	2010-06-22	1216	\N	9406	\N
13814	GENERIC_DAY	1	0	f	2010-06-20	4348	\N	9406	\N
13801	GENERIC_DAY	1	0	f	2010-06-17	4354	\N	9406	\N
13762	GENERIC_DAY	1	0	f	2010-06-19	4344	\N	9406	\N
13802	GENERIC_DAY	1	0	f	2010-06-18	4352	\N	9406	\N
13783	GENERIC_DAY	1	10800	f	2010-06-21	1220	\N	9406	\N
13778	GENERIC_DAY	1	0	f	2010-06-20	4358	\N	9406	\N
13779	GENERIC_DAY	1	3600	f	2010-06-22	1214	\N	9406	\N
13824	GENERIC_DAY	1	0	f	2010-06-20	4356	\N	9406	\N
13767	GENERIC_DAY	1	0	f	2010-06-14	4344	\N	9406	\N
13761	GENERIC_DAY	1	0	f	2010-06-18	4354	\N	9406	\N
13772	GENERIC_DAY	1	0	f	2010-06-18	4348	\N	9406	\N
13795	GENERIC_DAY	1	0	f	2010-06-22	1220	\N	9406	\N
13810	GENERIC_DAY	1	7200	f	2010-06-14	4348	\N	9406	\N
13819	GENERIC_DAY	1	10800	f	2010-06-18	1214	\N	9406	\N
13828	GENERIC_DAY	1	0	f	2010-06-21	4352	\N	9406	\N
13818	GENERIC_DAY	1	0	f	2010-06-20	1216	\N	9406	\N
13774	GENERIC_DAY	1	0	f	2010-06-15	4350	\N	9406	\N
13806	GENERIC_DAY	1	0	f	2010-06-14	4354	\N	9406	\N
13776	GENERIC_DAY	1	7200	f	2010-06-17	4356	\N	9406	\N
13769	GENERIC_DAY	1	3600	f	2010-06-14	4356	\N	9406	\N
13758	GENERIC_DAY	1	0	f	2010-06-19	4358	\N	9406	\N
13790	GENERIC_DAY	1	0	f	2010-06-19	1214	\N	9406	\N
73444	GENERIC_DAY	3	0	f	2010-07-24	72321	\N	73026	\N
73436	GENERIC_DAY	3	28800	f	2010-07-26	72319	\N	73026	\N
73415	GENERIC_DAY	3	28800	f	2010-07-22	72321	\N	73026	\N
73430	GENERIC_DAY	3	21600	f	2010-07-28	72317	\N	73026	\N
73449	GENERIC_DAY	3	28800	f	2010-07-16	72317	\N	73026	\N
73435	GENERIC_DAY	3	28800	f	2010-07-26	72317	\N	73026	\N
73442	GENERIC_DAY	3	28800	f	2010-07-19	72317	\N	73026	\N
73437	GENERIC_DAY	3	0	f	2010-07-17	72321	\N	73026	\N
73448	GENERIC_DAY	3	28800	f	2010-07-16	72321	\N	73026	\N
73418	GENERIC_DAY	3	28800	f	2010-07-26	72321	\N	73026	\N
73447	GENERIC_DAY	3	28800	f	2010-07-22	72317	\N	73026	\N
73424	GENERIC_DAY	3	28800	f	2010-07-20	72317	\N	73026	\N
73416	GENERIC_DAY	3	28800	f	2010-07-21	72321	\N	73026	\N
73419	GENERIC_DAY	3	28800	f	2010-07-27	72321	\N	73026	\N
73445	GENERIC_DAY	3	28800	f	2010-07-27	72317	\N	73026	\N
73417	GENERIC_DAY	3	0	f	2010-07-18	72321	\N	73026	\N
73427	GENERIC_DAY	3	28800	f	2010-07-16	72319	\N	73026	\N
73429	GENERIC_DAY	3	28800	f	2010-07-22	72319	\N	73026	\N
73426	GENERIC_DAY	3	28800	f	2010-07-27	72319	\N	73026	\N
73441	GENERIC_DAY	3	21600	f	2010-07-28	72319	\N	73026	\N
73414	GENERIC_DAY	3	0	f	2010-07-18	72319	\N	73026	\N
73431	GENERIC_DAY	3	28800	f	2010-07-23	72321	\N	73026	\N
73420	GENERIC_DAY	3	0	f	2010-07-17	72317	\N	73026	\N
73433	GENERIC_DAY	3	0	f	2010-07-25	72321	\N	73026	\N
73439	GENERIC_DAY	3	28800	f	2010-07-23	72317	\N	73026	\N
73428	GENERIC_DAY	3	28800	f	2010-07-23	72319	\N	73026	\N
73421	GENERIC_DAY	3	0	f	2010-07-24	72317	\N	73026	\N
73425	GENERIC_DAY	3	0	f	2010-07-25	72317	\N	73026	\N
73422	GENERIC_DAY	3	0	f	2010-07-25	72319	\N	73026	\N
73432	GENERIC_DAY	3	0	f	2010-07-17	72319	\N	73026	\N
73446	GENERIC_DAY	3	28800	f	2010-07-19	72319	\N	73026	\N
73438	GENERIC_DAY	3	21600	f	2010-07-28	72321	\N	73026	\N
73440	GENERIC_DAY	3	28800	f	2010-07-20	72319	\N	73026	\N
73434	GENERIC_DAY	3	0	f	2010-07-18	72317	\N	73026	\N
73457	GENERIC_DAY	3	28800	f	2010-08-05	72321	\N	73030	\N
73459	GENERIC_DAY	3	28800	f	2010-08-05	72317	\N	73030	\N
73453	GENERIC_DAY	3	0	f	2010-07-31	72319	\N	73030	\N
73461	GENERIC_DAY	3	0	f	2010-07-31	72317	\N	73030	\N
73467	GENERIC_DAY	3	28800	f	2010-08-04	72317	\N	73030	\N
73471	GENERIC_DAY	3	0	f	2010-07-31	72321	\N	73030	\N
73450	GENERIC_DAY	3	28800	f	2010-07-29	72319	\N	73030	\N
73458	GENERIC_DAY	3	28800	f	2010-08-05	72319	\N	73030	\N
73472	GENERIC_DAY	3	28800	f	2010-08-04	72319	\N	73030	\N
73466	GENERIC_DAY	3	28800	f	2010-07-30	72319	\N	73030	\N
73463	GENERIC_DAY	3	28800	f	2010-07-29	72321	\N	73030	\N
73470	GENERIC_DAY	3	28800	f	2010-08-02	72319	\N	73030	\N
73452	GENERIC_DAY	3	0	f	2010-08-01	72321	\N	73030	\N
73469	GENERIC_DAY	3	28800	f	2010-08-02	72321	\N	73030	\N
73475	GENERIC_DAY	3	28800	f	2010-07-30	72317	\N	73030	\N
73455	GENERIC_DAY	3	28800	f	2010-08-02	72317	\N	73030	\N
73465	GENERIC_DAY	3	0	f	2010-08-01	72317	\N	73030	\N
73476	GENERIC_DAY	3	7200	f	2010-08-06	72321	\N	73030	\N
73451	GENERIC_DAY	3	28800	f	2010-07-30	72321	\N	73030	\N
73462	GENERIC_DAY	3	28800	f	2010-08-03	72319	\N	73030	\N
73456	GENERIC_DAY	3	28800	f	2010-08-03	72321	\N	73030	\N
73473	GENERIC_DAY	3	0	f	2010-08-01	72319	\N	73030	\N
73454	GENERIC_DAY	3	28800	f	2010-08-04	72321	\N	73030	\N
73464	GENERIC_DAY	3	28800	f	2010-07-29	72317	\N	73030	\N
73474	GENERIC_DAY	3	28800	f	2010-08-03	72317	\N	73030	\N
73460	GENERIC_DAY	3	7200	f	2010-08-06	72317	\N	73030	\N
73468	GENERIC_DAY	3	7200	f	2010-08-06	72319	\N	73030	\N
73487	GENERIC_DAY	3	28800	f	2010-08-09	72321	\N	73031	\N
73477	GENERIC_DAY	3	28800	f	2010-08-10	72319	\N	73031	\N
73479	GENERIC_DAY	3	0	f	2010-08-07	72317	\N	73031	\N
73490	GENERIC_DAY	3	0	f	2010-08-08	72317	\N	73031	\N
73485	GENERIC_DAY	3	3600	f	2010-08-13	72321	\N	73031	\N
73497	GENERIC_DAY	3	28800	f	2010-08-12	72317	\N	73031	\N
73486	GENERIC_DAY	3	28800	f	2010-08-11	72317	\N	73031	\N
73481	GENERIC_DAY	3	28800	f	2010-08-12	72321	\N	73031	\N
73484	GENERIC_DAY	3	28800	f	2010-08-12	72319	\N	73031	\N
73488	GENERIC_DAY	3	28800	f	2010-08-09	72319	\N	73031	\N
73483	GENERIC_DAY	3	28800	f	2010-08-10	72317	\N	73031	\N
73489	GENERIC_DAY	3	28800	f	2010-08-09	72317	\N	73031	\N
73480	GENERIC_DAY	3	7200	f	2010-08-13	72319	\N	73031	\N
73482	GENERIC_DAY	3	0	f	2010-08-08	72319	\N	73031	\N
73478	GENERIC_DAY	3	0	f	2010-08-07	72319	\N	73031	\N
73491	GENERIC_DAY	3	0	f	2010-08-08	72321	\N	73031	\N
95991	GENERIC_DAY	28	0	f	2011-02-19	83633	\N	83233	\N
95992	GENERIC_DAY	28	28800	f	2011-02-17	72317	\N	83233	\N
95993	GENERIC_DAY	28	28800	f	2011-02-21	72319	\N	83233	\N
95994	GENERIC_DAY	28	0	f	2011-02-20	83633	\N	83233	\N
95995	GENERIC_DAY	28	3600	f	2011-02-22	83633	\N	83233	\N
95996	GENERIC_DAY	28	3600	f	2011-02-22	72319	\N	83233	\N
95997	GENERIC_DAY	28	28800	f	2011-02-16	72319	\N	83233	\N
95998	GENERIC_DAY	28	28800	f	2011-02-16	72317	\N	83233	\N
95999	GENERIC_DAY	28	0	f	2011-02-20	72319	\N	83233	\N
96000	GENERIC_DAY	28	0	f	2011-02-19	72317	\N	83233	\N
96001	GENERIC_DAY	28	0	f	2011-02-20	72317	\N	83233	\N
96002	GENERIC_DAY	28	28800	f	2011-02-21	72317	\N	83233	\N
96003	GENERIC_DAY	28	28800	f	2011-02-16	83633	\N	83233	\N
96004	GENERIC_DAY	28	0	f	2011-02-19	72319	\N	83233	\N
96005	GENERIC_DAY	28	28800	f	2011-02-21	83633	\N	83233	\N
96006	GENERIC_DAY	28	28800	f	2011-02-17	72319	\N	83233	\N
96007	GENERIC_DAY	28	7200	f	2011-02-22	72317	\N	83233	\N
96008	GENERIC_DAY	28	28800	f	2011-02-18	72319	\N	83233	\N
96009	GENERIC_DAY	28	28800	f	2011-02-17	83633	\N	83233	\N
96010	GENERIC_DAY	28	28800	f	2011-02-18	83633	\N	83233	\N
96011	GENERIC_DAY	28	28800	f	2011-02-18	72317	\N	83233	\N
96012	GENERIC_DAY	27	28800	f	2011-02-28	72319	\N	83234	\N
96013	GENERIC_DAY	27	0	f	2011-02-27	83633	\N	83234	\N
96014	GENERIC_DAY	27	28800	f	2011-02-24	72317	\N	83234	\N
96015	GENERIC_DAY	27	7200	f	2011-03-01	72317	\N	83234	\N
96016	GENERIC_DAY	27	28800	f	2011-02-28	83633	\N	83234	\N
96017	GENERIC_DAY	27	0	f	2011-02-26	72317	\N	83234	\N
96018	GENERIC_DAY	27	0	f	2011-02-26	72319	\N	83234	\N
96019	GENERIC_DAY	27	28800	f	2011-02-28	72317	\N	83234	\N
96020	GENERIC_DAY	27	28800	f	2011-02-24	83633	\N	83234	\N
96021	GENERIC_DAY	27	3600	f	2011-03-01	83633	\N	83234	\N
96022	GENERIC_DAY	27	28800	f	2011-02-25	72317	\N	83234	\N
96023	GENERIC_DAY	27	28800	f	2011-02-24	72319	\N	83234	\N
96024	GENERIC_DAY	27	0	f	2011-02-26	83633	\N	83234	\N
96025	GENERIC_DAY	27	28800	f	2011-02-23	83633	\N	83234	\N
96026	GENERIC_DAY	27	0	f	2011-02-27	72317	\N	83234	\N
96027	GENERIC_DAY	27	28800	f	2011-02-23	72319	\N	83234	\N
96028	GENERIC_DAY	27	0	f	2011-02-27	72319	\N	83234	\N
96029	GENERIC_DAY	27	28800	f	2011-02-25	83633	\N	83234	\N
96030	GENERIC_DAY	27	3600	f	2011-03-01	72319	\N	83234	\N
96031	GENERIC_DAY	27	28800	f	2011-02-25	72319	\N	83234	\N
96032	GENERIC_DAY	27	28800	f	2011-02-23	72317	\N	83234	\N
96033	GENERIC_DAY	26	28800	f	2011-03-02	83633	\N	83235	\N
96034	GENERIC_DAY	26	28800	f	2011-03-07	72317	\N	83235	\N
96035	GENERIC_DAY	26	28800	f	2011-03-07	72319	\N	83235	\N
96036	GENERIC_DAY	26	3600	f	2011-03-08	72319	\N	83235	\N
96037	GENERIC_DAY	26	28800	f	2011-03-03	72317	\N	83235	\N
96038	GENERIC_DAY	26	0	f	2011-03-05	83633	\N	83235	\N
96039	GENERIC_DAY	26	28800	f	2011-03-03	83633	\N	83235	\N
96040	GENERIC_DAY	26	0	f	2011-03-05	72317	\N	83235	\N
96041	GENERIC_DAY	26	28800	f	2011-03-04	72317	\N	83235	\N
96042	GENERIC_DAY	26	7200	f	2011-03-08	72317	\N	83235	\N
96043	GENERIC_DAY	26	28800	f	2011-03-04	72319	\N	83235	\N
96044	GENERIC_DAY	26	28800	f	2011-03-03	72319	\N	83235	\N
96045	GENERIC_DAY	26	28800	f	2011-03-07	83633	\N	83235	\N
96046	GENERIC_DAY	26	28800	f	2011-03-02	72317	\N	83235	\N
96047	GENERIC_DAY	26	0	f	2011-03-06	83633	\N	83235	\N
96048	GENERIC_DAY	26	28800	f	2011-03-04	83633	\N	83235	\N
96049	GENERIC_DAY	26	28800	f	2011-03-02	72319	\N	83235	\N
96050	GENERIC_DAY	26	0	f	2011-03-06	72319	\N	83235	\N
96051	GENERIC_DAY	26	0	f	2011-03-06	72317	\N	83235	\N
96052	GENERIC_DAY	26	0	f	2011-03-05	72319	\N	83235	\N
96053	GENERIC_DAY	26	3600	f	2011-03-08	83633	\N	83235	\N
96940	GENERIC_DAY	25	28800	f	2010-10-11	4352	\N	27147	\N
96941	GENERIC_DAY	25	28800	f	2010-09-14	4352	\N	27147	\N
96942	GENERIC_DAY	25	0	f	2010-09-19	4352	\N	27147	\N
96943	GENERIC_DAY	25	0	f	2010-09-20	4354	\N	27147	\N
96944	GENERIC_DAY	25	28800	f	2010-09-15	4352	\N	27147	\N
96945	GENERIC_DAY	25	0	f	2010-10-02	4354	\N	27147	\N
96946	GENERIC_DAY	25	0	f	2010-09-10	4354	\N	27147	\N
96947	GENERIC_DAY	25	7200	f	2010-10-14	4352	\N	27147	\N
96948	GENERIC_DAY	25	0	f	2010-10-02	4352	\N	27147	\N
96949	GENERIC_DAY	25	28800	f	2010-10-01	4352	\N	27147	\N
96950	GENERIC_DAY	25	28800	f	2010-09-29	4352	\N	27147	\N
96951	GENERIC_DAY	25	0	f	2010-09-28	4354	\N	27147	\N
96952	GENERIC_DAY	25	0	f	2010-10-06	4354	\N	27147	\N
96953	GENERIC_DAY	25	0	f	2010-09-24	4354	\N	27147	\N
96954	GENERIC_DAY	25	0	f	2010-10-12	4354	\N	27147	\N
96955	GENERIC_DAY	25	0	f	2010-09-21	4354	\N	27147	\N
96956	GENERIC_DAY	25	28800	f	2010-09-09	4352	\N	27147	\N
96957	GENERIC_DAY	25	0	f	2010-09-08	4354	\N	27147	\N
96958	GENERIC_DAY	25	28800	f	2010-09-24	4352	\N	27147	\N
96959	GENERIC_DAY	25	0	f	2010-09-19	4354	\N	27147	\N
96960	GENERIC_DAY	25	0	f	2010-09-09	4354	\N	27147	\N
96961	GENERIC_DAY	25	28800	f	2010-09-16	4352	\N	27147	\N
96962	GENERIC_DAY	25	0	f	2010-10-05	4354	\N	27147	\N
96963	GENERIC_DAY	25	28800	f	2010-09-17	4352	\N	27147	\N
96964	GENERIC_DAY	25	0	f	2010-09-29	4354	\N	27147	\N
96965	GENERIC_DAY	25	0	f	2010-09-26	4354	\N	27147	\N
96966	GENERIC_DAY	25	0	f	2010-10-11	4354	\N	27147	\N
96967	GENERIC_DAY	25	28800	f	2010-09-13	4352	\N	27147	\N
96968	GENERIC_DAY	25	0	f	2010-09-11	4354	\N	27147	\N
96969	GENERIC_DAY	25	0	f	2010-09-16	4354	\N	27147	\N
96970	GENERIC_DAY	25	0	f	2010-09-22	4354	\N	27147	\N
96971	GENERIC_DAY	25	0	f	2010-09-12	4352	\N	27147	\N
96972	GENERIC_DAY	25	0	f	2010-09-18	4352	\N	27147	\N
96973	GENERIC_DAY	25	28800	f	2010-09-30	4352	\N	27147	\N
96974	GENERIC_DAY	25	0	f	2010-09-18	4354	\N	27147	\N
96975	GENERIC_DAY	25	28800	f	2010-10-06	4352	\N	27147	\N
96976	GENERIC_DAY	25	28800	f	2010-09-10	4352	\N	27147	\N
96977	GENERIC_DAY	25	0	f	2010-09-14	4354	\N	27147	\N
96978	GENERIC_DAY	25	28800	f	2010-09-08	4352	\N	27147	\N
96979	GENERIC_DAY	25	28800	f	2010-09-27	4352	\N	27147	\N
96980	GENERIC_DAY	25	0	f	2010-09-15	4354	\N	27147	\N
96981	GENERIC_DAY	25	0	f	2010-09-23	4354	\N	27147	\N
96982	GENERIC_DAY	25	28800	f	2010-09-21	4352	\N	27147	\N
96983	GENERIC_DAY	25	28800	f	2010-10-05	4352	\N	27147	\N
96984	GENERIC_DAY	25	0	f	2010-10-09	4352	\N	27147	\N
96985	GENERIC_DAY	25	0	f	2010-10-10	4352	\N	27147	\N
96986	GENERIC_DAY	25	28800	f	2010-10-08	4352	\N	27147	\N
96987	GENERIC_DAY	25	0	f	2010-09-25	4352	\N	27147	\N
96988	GENERIC_DAY	25	0	f	2010-09-26	4352	\N	27147	\N
96989	GENERIC_DAY	25	0	f	2010-10-14	4354	\N	27147	\N
96990	GENERIC_DAY	25	28800	f	2010-10-07	4352	\N	27147	\N
96991	GENERIC_DAY	25	0	f	2010-10-09	4354	\N	27147	\N
96992	GENERIC_DAY	25	0	f	2010-10-03	4354	\N	27147	\N
96993	GENERIC_DAY	25	0	f	2010-10-08	4354	\N	27147	\N
96994	GENERIC_DAY	25	0	f	2010-09-11	4352	\N	27147	\N
96995	GENERIC_DAY	25	28800	f	2010-10-13	4352	\N	27147	\N
96996	GENERIC_DAY	25	28800	f	2010-10-12	4352	\N	27147	\N
96997	GENERIC_DAY	25	0	f	2010-10-03	4352	\N	27147	\N
96998	GENERIC_DAY	25	0	f	2010-10-04	4354	\N	27147	\N
96999	GENERIC_DAY	25	0	f	2010-09-30	4354	\N	27147	\N
97000	GENERIC_DAY	25	0	f	2010-10-10	4354	\N	27147	\N
97001	GENERIC_DAY	25	28800	f	2010-09-20	4352	\N	27147	\N
97002	GENERIC_DAY	25	0	f	2010-09-12	4354	\N	27147	\N
97003	GENERIC_DAY	25	28800	f	2010-09-28	4352	\N	27147	\N
97004	GENERIC_DAY	25	0	f	2010-09-13	4354	\N	27147	\N
97005	GENERIC_DAY	25	0	f	2010-09-27	4354	\N	27147	\N
97006	GENERIC_DAY	25	0	f	2010-10-07	4354	\N	27147	\N
97007	GENERIC_DAY	25	0	f	2010-10-13	4354	\N	27147	\N
97008	GENERIC_DAY	25	0	f	2010-10-01	4354	\N	27147	\N
97009	GENERIC_DAY	25	0	f	2010-09-17	4354	\N	27147	\N
97010	GENERIC_DAY	25	28800	f	2010-10-04	4352	\N	27147	\N
97011	GENERIC_DAY	25	0	f	2010-09-25	4354	\N	27147	\N
97012	GENERIC_DAY	25	28800	f	2010-09-23	4352	\N	27147	\N
97013	GENERIC_DAY	25	28800	f	2010-09-22	4352	\N	27147	\N
97014	GENERIC_DAY	24	7200	f	2010-10-01	4350	\N	27148	\N
97015	GENERIC_DAY	24	7200	f	2010-10-01	4358	\N	27148	\N
97016	GENERIC_DAY	24	0	f	2010-09-12	4350	\N	27148	\N
97017	GENERIC_DAY	24	7200	f	2010-09-20	4358	\N	27148	\N
97018	GENERIC_DAY	24	0	f	2010-09-19	4348	\N	27148	\N
97019	GENERIC_DAY	24	7200	f	2010-09-09	4350	\N	27148	\N
97020	GENERIC_DAY	24	3600	f	2010-10-04	4350	\N	27148	\N
97021	GENERIC_DAY	24	7200	f	2010-09-21	4348	\N	27148	\N
97022	GENERIC_DAY	24	0	f	2010-09-18	4344	\N	27148	\N
97023	GENERIC_DAY	24	7200	f	2010-09-17	4344	\N	27148	\N
97024	GENERIC_DAY	24	0	f	2010-10-02	4350	\N	27148	\N
97025	GENERIC_DAY	24	7200	f	2010-09-27	4358	\N	27148	\N
97026	GENERIC_DAY	24	7200	f	2010-09-17	4348	\N	27148	\N
97027	GENERIC_DAY	24	0	f	2010-10-02	4344	\N	27148	\N
97028	GENERIC_DAY	24	0	f	2010-09-18	4358	\N	27148	\N
97029	GENERIC_DAY	24	0	f	2010-10-03	4348	\N	27148	\N
97030	GENERIC_DAY	24	7200	f	2010-09-29	4348	\N	27148	\N
97031	GENERIC_DAY	24	7200	f	2010-09-13	4358	\N	27148	\N
97032	GENERIC_DAY	24	0	f	2010-09-26	4358	\N	27148	\N
97033	GENERIC_DAY	24	7200	f	2010-09-16	4358	\N	27148	\N
97034	GENERIC_DAY	24	7200	f	2010-09-30	4358	\N	27148	\N
97035	GENERIC_DAY	24	7200	f	2010-09-21	4350	\N	27148	\N
97036	GENERIC_DAY	24	7200	f	2010-09-21	4358	\N	27148	\N
97037	GENERIC_DAY	24	0	f	2010-10-03	4344	\N	27148	\N
97038	GENERIC_DAY	24	0	f	2010-10-02	4358	\N	27148	\N
97039	GENERIC_DAY	24	0	f	2010-09-25	4344	\N	27148	\N
97040	GENERIC_DAY	24	7200	f	2010-09-20	4344	\N	27148	\N
97041	GENERIC_DAY	24	7200	f	2010-09-23	4350	\N	27148	\N
97042	GENERIC_DAY	24	7200	f	2010-09-10	4344	\N	27148	\N
97043	GENERIC_DAY	24	7200	f	2010-09-16	4348	\N	27148	\N
97044	GENERIC_DAY	24	7200	f	2010-09-21	4344	\N	27148	\N
97045	GENERIC_DAY	24	7200	f	2010-09-10	4348	\N	27148	\N
97046	GENERIC_DAY	24	7200	f	2010-09-22	4350	\N	27148	\N
97047	GENERIC_DAY	24	7200	f	2010-09-09	4358	\N	27148	\N
97048	GENERIC_DAY	24	0	f	2010-10-03	4358	\N	27148	\N
97049	GENERIC_DAY	24	7200	f	2010-09-27	4344	\N	27148	\N
97050	GENERIC_DAY	24	7200	f	2010-09-08	4348	\N	27148	\N
97051	GENERIC_DAY	24	7200	f	2010-09-09	4348	\N	27148	\N
97052	GENERIC_DAY	24	0	f	2010-09-19	4358	\N	27148	\N
97053	GENERIC_DAY	24	0	f	2010-09-18	4348	\N	27148	\N
97054	GENERIC_DAY	24	7200	f	2010-09-28	4344	\N	27148	\N
97055	GENERIC_DAY	24	0	f	2010-10-02	4348	\N	27148	\N
97056	GENERIC_DAY	24	7200	f	2010-09-14	4358	\N	27148	\N
97057	GENERIC_DAY	24	7200	f	2010-09-14	4344	\N	27148	\N
97058	GENERIC_DAY	24	7200	f	2010-09-20	4348	\N	27148	\N
97059	GENERIC_DAY	24	7200	f	2010-09-30	4344	\N	27148	\N
97060	GENERIC_DAY	24	7200	f	2010-09-08	4358	\N	27148	\N
97061	GENERIC_DAY	24	7200	f	2010-09-24	4344	\N	27148	\N
97062	GENERIC_DAY	24	7200	f	2010-09-23	4344	\N	27148	\N
97063	GENERIC_DAY	24	7200	f	2010-09-24	4350	\N	27148	\N
97064	GENERIC_DAY	24	7200	f	2010-09-08	4344	\N	27148	\N
97065	GENERIC_DAY	24	7200	f	2010-09-09	4344	\N	27148	\N
97066	GENERIC_DAY	24	7200	f	2010-10-04	4348	\N	27148	\N
97067	GENERIC_DAY	24	7200	f	2010-09-30	4350	\N	27148	\N
97068	GENERIC_DAY	24	0	f	2010-09-12	4348	\N	27148	\N
97069	GENERIC_DAY	24	0	f	2010-09-26	4344	\N	27148	\N
97070	GENERIC_DAY	24	7200	f	2010-09-23	4358	\N	27148	\N
97071	GENERIC_DAY	24	0	f	2010-09-25	4350	\N	27148	\N
97072	GENERIC_DAY	24	7200	f	2010-09-13	4348	\N	27148	\N
97073	GENERIC_DAY	24	0	f	2010-09-11	4358	\N	27148	\N
97074	GENERIC_DAY	24	7200	f	2010-09-15	4358	\N	27148	\N
97075	GENERIC_DAY	24	7200	f	2010-09-22	4348	\N	27148	\N
97076	GENERIC_DAY	24	7200	f	2010-09-29	4350	\N	27148	\N
97077	GENERIC_DAY	24	7200	f	2010-09-24	4348	\N	27148	\N
97078	GENERIC_DAY	24	7200	f	2010-09-13	4344	\N	27148	\N
97079	GENERIC_DAY	24	7200	f	2010-09-29	4344	\N	27148	\N
97080	GENERIC_DAY	24	7200	f	2010-09-27	4348	\N	27148	\N
97081	GENERIC_DAY	24	7200	f	2010-09-15	4348	\N	27148	\N
97082	GENERIC_DAY	24	7200	f	2010-09-20	4350	\N	27148	\N
97083	GENERIC_DAY	24	0	f	2010-09-19	4350	\N	27148	\N
97084	GENERIC_DAY	24	7200	f	2010-09-13	4350	\N	27148	\N
97085	GENERIC_DAY	24	7200	f	2010-09-10	4350	\N	27148	\N
97086	GENERIC_DAY	24	7200	f	2010-09-17	4350	\N	27148	\N
97087	GENERIC_DAY	24	0	f	2010-09-26	4350	\N	27148	\N
97088	GENERIC_DAY	24	7200	f	2010-09-22	4358	\N	27148	\N
97089	GENERIC_DAY	24	0	f	2010-09-26	4348	\N	27148	\N
97090	GENERIC_DAY	24	0	f	2010-09-18	4350	\N	27148	\N
97091	GENERIC_DAY	24	7200	f	2010-09-15	4344	\N	27148	\N
97092	GENERIC_DAY	24	0	f	2010-09-25	4358	\N	27148	\N
97093	GENERIC_DAY	24	7200	f	2010-10-01	4344	\N	27148	\N
97094	GENERIC_DAY	24	7200	f	2010-09-17	4358	\N	27148	\N
97095	GENERIC_DAY	24	7200	f	2010-09-30	4348	\N	27148	\N
97096	GENERIC_DAY	24	7200	f	2010-09-22	4344	\N	27148	\N
97097	GENERIC_DAY	24	0	f	2010-09-25	4348	\N	27148	\N
97098	GENERIC_DAY	24	0	f	2010-09-11	4350	\N	27148	\N
97099	GENERIC_DAY	24	7200	f	2010-09-14	4350	\N	27148	\N
97100	GENERIC_DAY	24	7200	f	2010-09-29	4358	\N	27148	\N
97101	GENERIC_DAY	24	7200	f	2010-09-28	4350	\N	27148	\N
97102	GENERIC_DAY	24	7200	f	2010-10-04	4344	\N	27148	\N
97103	GENERIC_DAY	24	3600	f	2010-10-04	4358	\N	27148	\N
97104	GENERIC_DAY	24	7200	f	2010-09-23	4348	\N	27148	\N
97105	GENERIC_DAY	24	0	f	2010-10-03	4350	\N	27148	\N
97106	GENERIC_DAY	24	0	f	2010-09-12	4344	\N	27148	\N
97107	GENERIC_DAY	24	7200	f	2010-09-16	4344	\N	27148	\N
97108	GENERIC_DAY	24	7200	f	2010-09-08	4350	\N	27148	\N
97109	GENERIC_DAY	24	7200	f	2010-09-24	4358	\N	27148	\N
97110	GENERIC_DAY	24	7200	f	2010-10-01	4348	\N	27148	\N
97111	GENERIC_DAY	24	0	f	2010-09-11	4344	\N	27148	\N
97112	GENERIC_DAY	24	0	f	2010-09-19	4344	\N	27148	\N
97113	GENERIC_DAY	24	7200	f	2010-09-28	4358	\N	27148	\N
97114	GENERIC_DAY	24	7200	f	2010-09-14	4348	\N	27148	\N
97115	GENERIC_DAY	24	7200	f	2010-09-28	4348	\N	27148	\N
97116	GENERIC_DAY	24	7200	f	2010-09-10	4358	\N	27148	\N
97117	GENERIC_DAY	24	7200	f	2010-09-27	4350	\N	27148	\N
97118	GENERIC_DAY	24	7200	f	2010-09-15	4350	\N	27148	\N
97119	GENERIC_DAY	24	0	f	2010-09-12	4358	\N	27148	\N
97120	GENERIC_DAY	24	0	f	2010-09-11	4348	\N	27148	\N
97121	GENERIC_DAY	24	7200	f	2010-09-16	4350	\N	27148	\N
97122	GENERIC_DAY	23	7200	f	2010-09-21	4348	\N	27149	\N
97123	GENERIC_DAY	23	7200	f	2010-09-20	4348	\N	27149	\N
97124	GENERIC_DAY	23	7200	f	2010-09-10	4358	\N	27149	\N
97125	GENERIC_DAY	23	7200	f	2010-09-20	4358	\N	27149	\N
97126	GENERIC_DAY	23	7200	f	2010-09-16	4358	\N	27149	\N
97127	GENERIC_DAY	23	7200	f	2010-09-14	4350	\N	27149	\N
97128	GENERIC_DAY	23	7200	f	2010-09-10	4348	\N	27149	\N
97129	GENERIC_DAY	23	7200	f	2010-09-13	4348	\N	27149	\N
97130	GENERIC_DAY	23	7200	f	2010-09-14	4344	\N	27149	\N
97131	GENERIC_DAY	23	7200	f	2010-09-16	4350	\N	27149	\N
97132	GENERIC_DAY	23	7200	f	2010-09-08	4344	\N	27149	\N
97133	GENERIC_DAY	23	7200	f	2010-09-22	4348	\N	27149	\N
97134	GENERIC_DAY	23	0	f	2010-09-19	4344	\N	27149	\N
97135	GENERIC_DAY	23	0	f	2010-09-12	4348	\N	27149	\N
97136	GENERIC_DAY	23	0	f	2010-09-18	4350	\N	27149	\N
97137	GENERIC_DAY	23	7200	f	2010-09-23	4350	\N	27149	\N
97138	GENERIC_DAY	23	3600	f	2010-09-24	4350	\N	27149	\N
97139	GENERIC_DAY	23	7200	f	2010-09-10	4344	\N	27149	\N
97140	GENERIC_DAY	23	7200	f	2010-09-08	4348	\N	27149	\N
97141	GENERIC_DAY	23	0	f	2010-09-19	4350	\N	27149	\N
97142	GENERIC_DAY	23	7200	f	2010-09-24	4344	\N	27149	\N
97143	GENERIC_DAY	23	7200	f	2010-09-15	4358	\N	27149	\N
97144	GENERIC_DAY	23	7200	f	2010-09-08	4350	\N	27149	\N
97145	GENERIC_DAY	23	0	f	2010-09-12	4350	\N	27149	\N
97146	GENERIC_DAY	23	7200	f	2010-09-22	4344	\N	27149	\N
97147	GENERIC_DAY	23	7200	f	2010-09-16	4344	\N	27149	\N
97148	GENERIC_DAY	23	7200	f	2010-09-20	4344	\N	27149	\N
97149	GENERIC_DAY	23	7200	f	2010-09-22	4358	\N	27149	\N
97150	GENERIC_DAY	23	3600	f	2010-09-24	4348	\N	27149	\N
97151	GENERIC_DAY	23	7200	f	2010-09-17	4350	\N	27149	\N
97152	GENERIC_DAY	23	7200	f	2010-09-21	4344	\N	27149	\N
97153	GENERIC_DAY	23	0	f	2010-09-11	4348	\N	27149	\N
97154	GENERIC_DAY	23	7200	f	2010-09-21	4358	\N	27149	\N
97155	GENERIC_DAY	23	0	f	2010-09-11	4358	\N	27149	\N
97156	GENERIC_DAY	23	7200	f	2010-09-13	4358	\N	27149	\N
97157	GENERIC_DAY	23	0	f	2010-09-18	4348	\N	27149	\N
97158	GENERIC_DAY	23	7200	f	2010-09-20	4350	\N	27149	\N
97159	GENERIC_DAY	23	7200	f	2010-09-15	4344	\N	27149	\N
97160	GENERIC_DAY	23	7200	f	2010-09-09	4358	\N	27149	\N
97161	GENERIC_DAY	23	7200	f	2010-09-22	4350	\N	27149	\N
97162	GENERIC_DAY	23	0	f	2010-09-19	4358	\N	27149	\N
97163	GENERIC_DAY	23	7200	f	2010-09-17	4358	\N	27149	\N
97164	GENERIC_DAY	23	7200	f	2010-09-14	4348	\N	27149	\N
97165	GENERIC_DAY	23	7200	f	2010-09-23	4348	\N	27149	\N
97166	GENERIC_DAY	23	7200	f	2010-09-08	4358	\N	27149	\N
97167	GENERIC_DAY	23	7200	f	2010-09-23	4344	\N	27149	\N
97168	GENERIC_DAY	23	0	f	2010-09-11	4350	\N	27149	\N
97169	GENERIC_DAY	23	7200	f	2010-09-17	4344	\N	27149	\N
97170	GENERIC_DAY	23	0	f	2010-09-18	4344	\N	27149	\N
97171	GENERIC_DAY	23	3600	f	2010-09-24	4358	\N	27149	\N
97172	GENERIC_DAY	23	0	f	2010-09-19	4348	\N	27149	\N
97173	GENERIC_DAY	23	7200	f	2010-09-16	4348	\N	27149	\N
97174	GENERIC_DAY	23	7200	f	2010-09-09	4344	\N	27149	\N
97175	GENERIC_DAY	23	0	f	2010-09-12	4344	\N	27149	\N
97176	GENERIC_DAY	23	7200	f	2010-09-21	4350	\N	27149	\N
97177	GENERIC_DAY	23	7200	f	2010-09-15	4348	\N	27149	\N
97178	GENERIC_DAY	23	0	f	2010-09-18	4358	\N	27149	\N
97179	GENERIC_DAY	23	0	f	2010-09-11	4344	\N	27149	\N
97180	GENERIC_DAY	23	0	f	2010-09-12	4358	\N	27149	\N
97181	GENERIC_DAY	23	7200	f	2010-09-17	4348	\N	27149	\N
97182	GENERIC_DAY	23	7200	f	2010-09-15	4350	\N	27149	\N
97183	GENERIC_DAY	23	7200	f	2010-09-13	4350	\N	27149	\N
97184	GENERIC_DAY	23	7200	f	2010-09-14	4358	\N	27149	\N
97185	GENERIC_DAY	23	7200	f	2010-09-09	4350	\N	27149	\N
97186	GENERIC_DAY	23	7200	f	2010-09-23	4358	\N	27149	\N
97187	GENERIC_DAY	23	7200	f	2010-09-09	4348	\N	27149	\N
97188	GENERIC_DAY	23	7200	f	2010-09-13	4344	\N	27149	\N
97189	GENERIC_DAY	23	7200	f	2010-09-10	4350	\N	27149	\N
97190	GENERIC_DAY	22	0	f	2010-11-06	4354	\N	27150	\N
97191	GENERIC_DAY	22	28800	f	2010-10-14	4352	\N	27150	\N
97192	GENERIC_DAY	22	28800	f	2010-10-20	4352	\N	27150	\N
97193	GENERIC_DAY	22	14400	f	2010-11-08	4354	\N	27150	\N
97194	GENERIC_DAY	22	0	f	2010-10-16	4354	\N	27150	\N
97195	GENERIC_DAY	22	0	f	2010-11-02	4354	\N	27150	\N
97196	GENERIC_DAY	22	0	f	2010-10-18	4354	\N	27150	\N
97197	GENERIC_DAY	22	28800	f	2010-11-01	4352	\N	27150	\N
97198	GENERIC_DAY	22	0	f	2010-11-01	4354	\N	27150	\N
97199	GENERIC_DAY	22	28800	f	2010-10-26	4352	\N	27150	\N
97200	GENERIC_DAY	22	0	f	2010-10-29	4354	\N	27150	\N
97201	GENERIC_DAY	22	0	f	2010-10-06	4354	\N	27150	\N
97202	GENERIC_DAY	22	28800	f	2010-10-28	4352	\N	27150	\N
97203	GENERIC_DAY	22	0	f	2010-10-10	4352	\N	27150	\N
97204	GENERIC_DAY	22	28800	f	2010-10-19	4352	\N	27150	\N
97205	GENERIC_DAY	22	0	f	2010-10-09	4354	\N	27150	\N
97206	GENERIC_DAY	22	28800	f	2010-10-13	4352	\N	27150	\N
97207	GENERIC_DAY	22	0	f	2010-10-07	4354	\N	27150	\N
97208	GENERIC_DAY	22	0	f	2010-10-30	4352	\N	27150	\N
97209	GENERIC_DAY	22	0	f	2010-10-08	4354	\N	27150	\N
97210	GENERIC_DAY	22	0	f	2010-10-14	4354	\N	27150	\N
97211	GENERIC_DAY	22	0	f	2010-10-17	4352	\N	27150	\N
97212	GENERIC_DAY	22	28800	f	2010-11-04	4352	\N	27150	\N
97213	GENERIC_DAY	22	28800	f	2010-10-22	4352	\N	27150	\N
97214	GENERIC_DAY	22	0	f	2010-10-23	4354	\N	27150	\N
97215	GENERIC_DAY	22	0	f	2010-10-15	4354	\N	27150	\N
97216	GENERIC_DAY	22	0	f	2010-11-04	4354	\N	27150	\N
97217	GENERIC_DAY	22	0	f	2010-10-28	4354	\N	27150	\N
97218	GENERIC_DAY	22	0	f	2010-11-06	4352	\N	27150	\N
97219	GENERIC_DAY	22	0	f	2010-10-25	4354	\N	27150	\N
97220	GENERIC_DAY	22	28800	f	2010-10-25	4352	\N	27150	\N
97221	GENERIC_DAY	22	28800	f	2010-10-08	4352	\N	27150	\N
97222	GENERIC_DAY	22	28800	f	2010-11-03	4352	\N	27150	\N
97223	GENERIC_DAY	22	0	f	2010-10-13	4354	\N	27150	\N
97224	GENERIC_DAY	22	28800	f	2010-10-15	4352	\N	27150	\N
97225	GENERIC_DAY	22	0	f	2010-10-27	4354	\N	27150	\N
97226	GENERIC_DAY	22	0	f	2010-10-31	4354	\N	27150	\N
97227	GENERIC_DAY	22	28800	f	2010-10-05	4352	\N	27150	\N
97228	GENERIC_DAY	22	0	f	2010-10-22	4354	\N	27150	\N
97229	GENERIC_DAY	22	0	f	2010-10-31	4352	\N	27150	\N
97230	GENERIC_DAY	22	0	f	2010-11-07	4352	\N	27150	\N
97231	GENERIC_DAY	22	0	f	2010-10-09	4352	\N	27150	\N
97232	GENERIC_DAY	22	0	f	2010-10-11	4354	\N	27150	\N
97233	GENERIC_DAY	22	28800	f	2010-10-21	4352	\N	27150	\N
97234	GENERIC_DAY	22	0	f	2010-10-17	4354	\N	27150	\N
97235	GENERIC_DAY	22	0	f	2010-11-05	4354	\N	27150	\N
97236	GENERIC_DAY	22	14400	f	2010-11-08	4352	\N	27150	\N
97237	GENERIC_DAY	22	0	f	2010-10-26	4354	\N	27150	\N
97238	GENERIC_DAY	22	0	f	2010-11-07	4354	\N	27150	\N
97239	GENERIC_DAY	22	0	f	2010-10-05	4354	\N	27150	\N
97240	GENERIC_DAY	22	28800	f	2010-11-02	4352	\N	27150	\N
97241	GENERIC_DAY	22	0	f	2010-10-23	4352	\N	27150	\N
97242	GENERIC_DAY	22	28800	f	2010-10-27	4352	\N	27150	\N
97243	GENERIC_DAY	22	28800	f	2010-10-12	4352	\N	27150	\N
97244	GENERIC_DAY	22	28800	f	2010-10-07	4352	\N	27150	\N
97245	GENERIC_DAY	22	0	f	2010-10-20	4354	\N	27150	\N
97246	GENERIC_DAY	22	0	f	2010-10-12	4354	\N	27150	\N
97247	GENERIC_DAY	22	0	f	2010-10-16	4352	\N	27150	\N
97248	GENERIC_DAY	22	0	f	2010-10-10	4354	\N	27150	\N
97249	GENERIC_DAY	22	0	f	2010-11-03	4354	\N	27150	\N
97250	GENERIC_DAY	22	0	f	2010-10-24	4352	\N	27150	\N
97251	GENERIC_DAY	22	0	f	2010-10-24	4354	\N	27150	\N
97252	GENERIC_DAY	22	28800	f	2010-10-11	4352	\N	27150	\N
97253	GENERIC_DAY	22	28800	f	2010-10-29	4352	\N	27150	\N
97254	GENERIC_DAY	22	0	f	2010-10-30	4354	\N	27150	\N
97255	GENERIC_DAY	22	28800	f	2010-10-06	4352	\N	27150	\N
97256	GENERIC_DAY	22	0	f	2010-10-21	4354	\N	27150	\N
97257	GENERIC_DAY	22	28800	f	2010-10-18	4352	\N	27150	\N
97258	GENERIC_DAY	22	0	f	2010-10-19	4354	\N	27150	\N
97259	GENERIC_DAY	22	28800	f	2010-11-05	4352	\N	27150	\N
97260	GENERIC_DAY	21	0	f	2010-10-24	4352	\N	27151	\N
97261	GENERIC_DAY	21	28800	f	2010-11-01	4352	\N	27151	\N
97262	GENERIC_DAY	21	14400	f	2010-11-02	4352	\N	27151	\N
97263	GENERIC_DAY	21	0	f	2010-10-15	4354	\N	27151	\N
97264	GENERIC_DAY	21	0	f	2010-10-22	4354	\N	27151	\N
97265	GENERIC_DAY	21	0	f	2010-10-18	4354	\N	27151	\N
97266	GENERIC_DAY	21	0	f	2010-10-19	4354	\N	27151	\N
97267	GENERIC_DAY	21	0	f	2010-10-27	4354	\N	27151	\N
97268	GENERIC_DAY	21	0	f	2010-11-02	4354	\N	27151	\N
97269	GENERIC_DAY	21	0	f	2010-10-17	4354	\N	27151	\N
97270	GENERIC_DAY	21	0	f	2010-10-31	4354	\N	27151	\N
97271	GENERIC_DAY	21	28800	f	2010-10-15	4352	\N	27151	\N
97272	GENERIC_DAY	21	0	f	2010-10-16	4352	\N	27151	\N
97273	GENERIC_DAY	21	0	f	2010-11-01	4354	\N	27151	\N
97274	GENERIC_DAY	21	28800	f	2010-10-27	4352	\N	27151	\N
97275	GENERIC_DAY	21	0	f	2010-10-25	4354	\N	27151	\N
97276	GENERIC_DAY	21	0	f	2010-10-20	4354	\N	27151	\N
97277	GENERIC_DAY	21	0	f	2010-10-30	4352	\N	27151	\N
97278	GENERIC_DAY	21	0	f	2010-10-24	4354	\N	27151	\N
97279	GENERIC_DAY	21	0	f	2010-10-30	4354	\N	27151	\N
97280	GENERIC_DAY	21	0	f	2010-10-28	4354	\N	27151	\N
97281	GENERIC_DAY	21	28800	f	2010-10-18	4352	\N	27151	\N
97282	GENERIC_DAY	21	0	f	2010-10-21	4354	\N	27151	\N
97283	GENERIC_DAY	21	28800	f	2010-10-21	4352	\N	27151	\N
97284	GENERIC_DAY	21	0	f	2010-10-23	4352	\N	27151	\N
97285	GENERIC_DAY	21	28800	f	2010-10-19	4352	\N	27151	\N
97286	GENERIC_DAY	21	28800	f	2010-10-25	4352	\N	27151	\N
97287	GENERIC_DAY	21	28800	f	2010-10-20	4352	\N	27151	\N
97288	GENERIC_DAY	21	28800	f	2010-10-28	4352	\N	27151	\N
97289	GENERIC_DAY	21	28800	f	2010-10-22	4352	\N	27151	\N
97290	GENERIC_DAY	21	0	f	2010-10-17	4352	\N	27151	\N
97291	GENERIC_DAY	21	28800	f	2010-10-29	4352	\N	27151	\N
97292	GENERIC_DAY	21	0	f	2010-10-16	4354	\N	27151	\N
97293	GENERIC_DAY	21	0	f	2010-10-26	4354	\N	27151	\N
97294	GENERIC_DAY	21	28800	f	2010-10-26	4352	\N	27151	\N
97295	GENERIC_DAY	21	0	f	2010-10-23	4354	\N	27151	\N
97296	GENERIC_DAY	21	0	f	2010-10-29	4354	\N	27151	\N
97297	GENERIC_DAY	21	0	f	2010-10-31	4352	\N	27151	\N
97298	GENERIC_DAY	20	28800	f	2010-10-04	4352	\N	27152	\N
97299	GENERIC_DAY	20	28800	f	2010-10-13	4352	\N	27152	\N
97300	GENERIC_DAY	20	0	f	2010-10-21	4354	\N	27152	\N
97301	GENERIC_DAY	20	0	f	2010-10-29	4354	\N	27152	\N
97302	GENERIC_DAY	20	0	f	2010-10-28	4354	\N	27152	\N
97303	GENERIC_DAY	20	28800	f	2010-10-08	4352	\N	27152	\N
97304	GENERIC_DAY	20	28800	f	2010-10-18	4352	\N	27152	\N
97305	GENERIC_DAY	20	28800	f	2010-10-05	4352	\N	27152	\N
97306	GENERIC_DAY	20	0	f	2010-10-11	4354	\N	27152	\N
97307	GENERIC_DAY	20	28800	f	2010-10-21	4352	\N	27152	\N
97308	GENERIC_DAY	20	0	f	2010-10-18	4354	\N	27152	\N
97309	GENERIC_DAY	20	0	f	2010-09-26	4352	\N	27152	\N
97310	GENERIC_DAY	20	0	f	2010-10-25	4354	\N	27152	\N
97311	GENERIC_DAY	20	28800	f	2010-10-26	4352	\N	27152	\N
97312	GENERIC_DAY	20	0	f	2010-10-03	4354	\N	27152	\N
97313	GENERIC_DAY	20	0	f	2010-10-20	4354	\N	27152	\N
97314	GENERIC_DAY	20	0	f	2010-10-27	4354	\N	27152	\N
97315	GENERIC_DAY	20	28800	f	2010-10-15	4352	\N	27152	\N
97316	GENERIC_DAY	20	28800	f	2010-10-06	4352	\N	27152	\N
97317	GENERIC_DAY	20	0	f	2010-10-09	4354	\N	27152	\N
97318	GENERIC_DAY	20	0	f	2010-10-05	4354	\N	27152	\N
97319	GENERIC_DAY	20	0	f	2010-10-08	4354	\N	27152	\N
97320	GENERIC_DAY	20	0	f	2010-09-27	4354	\N	27152	\N
97321	GENERIC_DAY	20	0	f	2010-10-01	4354	\N	27152	\N
97322	GENERIC_DAY	20	28800	f	2010-10-12	4352	\N	27152	\N
97323	GENERIC_DAY	20	0	f	2010-10-06	4354	\N	27152	\N
97324	GENERIC_DAY	20	0	f	2010-10-24	4352	\N	27152	\N
97325	GENERIC_DAY	20	28800	f	2010-09-27	4352	\N	27152	\N
97326	GENERIC_DAY	20	28800	f	2010-10-28	4352	\N	27152	\N
97327	GENERIC_DAY	20	0	f	2010-10-15	4354	\N	27152	\N
97328	GENERIC_DAY	20	28800	f	2010-09-29	4352	\N	27152	\N
97329	GENERIC_DAY	20	28800	f	2010-10-19	4352	\N	27152	\N
97330	GENERIC_DAY	20	0	f	2010-09-25	4354	\N	27152	\N
97331	GENERIC_DAY	20	0	f	2010-10-26	4354	\N	27152	\N
97332	GENERIC_DAY	20	28800	f	2010-10-14	4352	\N	27152	\N
97333	GENERIC_DAY	20	0	f	2010-10-02	4352	\N	27152	\N
97334	GENERIC_DAY	20	0	f	2010-10-09	4352	\N	27152	\N
97335	GENERIC_DAY	20	0	f	2010-10-04	4354	\N	27152	\N
97336	GENERIC_DAY	20	28800	f	2010-10-29	4352	\N	27152	\N
97337	GENERIC_DAY	20	0	f	2010-09-30	4354	\N	27152	\N
97338	GENERIC_DAY	20	0	f	2010-10-12	4354	\N	27152	\N
97339	GENERIC_DAY	20	0	f	2010-09-25	4352	\N	27152	\N
97340	GENERIC_DAY	20	0	f	2010-10-19	4354	\N	27152	\N
97341	GENERIC_DAY	20	28800	f	2010-10-11	4352	\N	27152	\N
97342	GENERIC_DAY	20	28800	f	2010-10-01	4352	\N	27152	\N
97343	GENERIC_DAY	20	0	f	2010-09-29	4354	\N	27152	\N
97344	GENERIC_DAY	20	0	f	2010-10-24	4354	\N	27152	\N
97345	GENERIC_DAY	20	0	f	2010-10-23	4354	\N	27152	\N
97346	GENERIC_DAY	20	0	f	2010-10-10	4352	\N	27152	\N
97347	GENERIC_DAY	20	0	f	2010-09-28	4354	\N	27152	\N
97348	GENERIC_DAY	20	0	f	2010-10-14	4354	\N	27152	\N
97349	GENERIC_DAY	20	28800	f	2010-10-07	4352	\N	27152	\N
97350	GENERIC_DAY	20	28800	f	2010-10-20	4352	\N	27152	\N
97351	GENERIC_DAY	20	0	f	2010-10-13	4354	\N	27152	\N
97352	GENERIC_DAY	20	28800	f	2010-09-30	4352	\N	27152	\N
97353	GENERIC_DAY	20	0	f	2010-09-26	4354	\N	27152	\N
97354	GENERIC_DAY	20	0	f	2010-10-17	4352	\N	27152	\N
97355	GENERIC_DAY	20	28800	f	2010-10-22	4352	\N	27152	\N
97356	GENERIC_DAY	20	28800	f	2010-10-27	4352	\N	27152	\N
97357	GENERIC_DAY	20	0	f	2010-10-03	4352	\N	27152	\N
97358	GENERIC_DAY	20	28800	f	2010-10-25	4352	\N	27152	\N
97359	GENERIC_DAY	20	0	f	2010-10-10	4354	\N	27152	\N
97360	GENERIC_DAY	20	28800	f	2010-09-28	4352	\N	27152	\N
97361	GENERIC_DAY	20	0	f	2010-10-22	4354	\N	27152	\N
97362	GENERIC_DAY	20	0	f	2010-10-23	4352	\N	27152	\N
97363	GENERIC_DAY	20	0	f	2010-10-17	4354	\N	27152	\N
97364	GENERIC_DAY	20	0	f	2010-10-16	4354	\N	27152	\N
97365	GENERIC_DAY	20	0	f	2010-10-02	4354	\N	27152	\N
97366	GENERIC_DAY	20	0	f	2010-10-07	4354	\N	27152	\N
97367	GENERIC_DAY	20	0	f	2010-10-16	4352	\N	27152	\N
97368	GENERIC_DAY	19	0	f	2010-09-24	4354	\N	27153	\N
97369	GENERIC_DAY	19	0	f	2010-09-27	4354	\N	27153	\N
97370	GENERIC_DAY	19	0	f	2010-09-12	4354	\N	27153	\N
97371	GENERIC_DAY	19	28800	f	2010-09-14	4352	\N	27153	\N
97372	GENERIC_DAY	19	28800	f	2010-10-06	4352	\N	27153	\N
97373	GENERIC_DAY	19	0	f	2010-10-12	4354	\N	27153	\N
97374	GENERIC_DAY	19	28800	f	2010-10-04	4352	\N	27153	\N
97375	GENERIC_DAY	19	28800	f	2010-09-15	4352	\N	27153	\N
97376	GENERIC_DAY	19	0	f	2010-09-13	4354	\N	27153	\N
97377	GENERIC_DAY	19	0	f	2010-09-15	4354	\N	27153	\N
97378	GENERIC_DAY	19	28800	f	2010-10-01	4352	\N	27153	\N
97379	GENERIC_DAY	19	0	f	2010-09-20	4354	\N	27153	\N
97380	GENERIC_DAY	19	28800	f	2010-10-08	4352	\N	27153	\N
97381	GENERIC_DAY	19	0	f	2010-10-03	4354	\N	27153	\N
97382	GENERIC_DAY	19	0	f	2010-09-23	4354	\N	27153	\N
97383	GENERIC_DAY	19	0	f	2010-09-18	4352	\N	27153	\N
97384	GENERIC_DAY	19	0	f	2010-10-06	4354	\N	27153	\N
97385	GENERIC_DAY	19	0	f	2010-10-02	4354	\N	27153	\N
97386	GENERIC_DAY	19	0	f	2010-10-09	4352	\N	27153	\N
97387	GENERIC_DAY	19	28800	f	2010-09-17	4352	\N	27153	\N
97388	GENERIC_DAY	19	0	f	2010-10-09	4354	\N	27153	\N
97389	GENERIC_DAY	19	0	f	2010-10-10	4352	\N	27153	\N
97390	GENERIC_DAY	19	28800	f	2010-09-30	4352	\N	27153	\N
97391	GENERIC_DAY	19	0	f	2010-09-26	4352	\N	27153	\N
97392	GENERIC_DAY	19	0	f	2010-09-18	4354	\N	27153	\N
97393	GENERIC_DAY	19	0	f	2010-10-04	4354	\N	27153	\N
97394	GENERIC_DAY	19	28800	f	2010-09-16	4352	\N	27153	\N
97395	GENERIC_DAY	19	0	f	2010-09-25	4352	\N	27153	\N
97396	GENERIC_DAY	19	0	f	2010-10-08	4354	\N	27153	\N
97397	GENERIC_DAY	19	0	f	2010-09-19	4354	\N	27153	\N
97398	GENERIC_DAY	19	0	f	2010-09-14	4354	\N	27153	\N
97399	GENERIC_DAY	19	0	f	2010-09-30	4354	\N	27153	\N
97400	GENERIC_DAY	19	0	f	2010-09-22	4354	\N	27153	\N
97401	GENERIC_DAY	19	28800	f	2010-09-23	4352	\N	27153	\N
97402	GENERIC_DAY	19	28800	f	2010-09-09	4352	\N	27153	\N
97403	GENERIC_DAY	19	0	f	2010-10-10	4354	\N	27153	\N
97404	GENERIC_DAY	19	0	f	2010-09-09	4354	\N	27153	\N
97405	GENERIC_DAY	19	0	f	2010-10-11	4354	\N	27153	\N
97406	GENERIC_DAY	19	0	f	2010-09-11	4352	\N	27153	\N
97407	GENERIC_DAY	19	28800	f	2010-09-24	4352	\N	27153	\N
97408	GENERIC_DAY	19	28800	f	2010-09-27	4352	\N	27153	\N
97409	GENERIC_DAY	19	28800	f	2010-10-11	4352	\N	27153	\N
97410	GENERIC_DAY	19	28800	f	2010-09-28	4352	\N	27153	\N
97411	GENERIC_DAY	19	0	f	2010-10-02	4352	\N	27153	\N
97412	GENERIC_DAY	19	0	f	2010-09-17	4354	\N	27153	\N
97413	GENERIC_DAY	19	0	f	2010-09-28	4354	\N	27153	\N
97414	GENERIC_DAY	19	0	f	2010-10-07	4354	\N	27153	\N
97415	GENERIC_DAY	19	0	f	2010-09-26	4354	\N	27153	\N
97416	GENERIC_DAY	19	0	f	2010-09-11	4354	\N	27153	\N
97417	GENERIC_DAY	19	0	f	2010-10-01	4354	\N	27153	\N
97418	GENERIC_DAY	19	28800	f	2010-09-20	4352	\N	27153	\N
97419	GENERIC_DAY	19	28800	f	2010-10-12	4352	\N	27153	\N
97420	GENERIC_DAY	19	0	f	2010-10-05	4354	\N	27153	\N
97421	GENERIC_DAY	19	0	f	2010-09-25	4354	\N	27153	\N
97422	GENERIC_DAY	19	28800	f	2010-10-07	4352	\N	27153	\N
97423	GENERIC_DAY	19	0	f	2010-09-21	4354	\N	27153	\N
97424	GENERIC_DAY	19	0	f	2010-10-03	4352	\N	27153	\N
97425	GENERIC_DAY	19	28800	f	2010-09-13	4352	\N	27153	\N
97426	GENERIC_DAY	19	0	f	2010-09-10	4354	\N	27153	\N
97427	GENERIC_DAY	19	28800	f	2010-09-29	4352	\N	27153	\N
97428	GENERIC_DAY	19	28800	f	2010-09-22	4352	\N	27153	\N
97429	GENERIC_DAY	19	28800	f	2010-09-10	4352	\N	27153	\N
97430	GENERIC_DAY	19	28800	f	2010-09-08	4352	\N	27153	\N
97431	GENERIC_DAY	19	0	f	2010-09-08	4354	\N	27153	\N
97432	GENERIC_DAY	19	0	f	2010-09-16	4354	\N	27153	\N
97433	GENERIC_DAY	19	28800	f	2010-09-21	4352	\N	27153	\N
97434	GENERIC_DAY	19	0	f	2010-09-29	4354	\N	27153	\N
97435	GENERIC_DAY	19	28800	f	2010-10-05	4352	\N	27153	\N
97436	GENERIC_DAY	19	0	f	2010-09-12	4352	\N	27153	\N
97437	GENERIC_DAY	19	0	f	2010-09-19	4352	\N	27153	\N
97438	GENERIC_DAY	18	14400	f	2010-12-22	4354	\N	27154	\N
97439	GENERIC_DAY	18	14400	f	2010-11-12	4354	\N	27154	\N
97440	GENERIC_DAY	18	14400	f	2010-12-27	4354	\N	27154	\N
97441	GENERIC_DAY	18	14400	f	2010-12-14	4354	\N	27154	\N
97442	GENERIC_DAY	18	0	f	2010-11-20	4354	\N	27154	\N
97443	GENERIC_DAY	18	14400	f	2011-01-05	4354	\N	27154	\N
97444	GENERIC_DAY	18	14400	f	2010-12-20	4354	\N	27154	\N
97445	GENERIC_DAY	18	14400	f	2010-12-13	4354	\N	27154	\N
97446	GENERIC_DAY	18	0	f	2010-11-13	4352	\N	27154	\N
97447	GENERIC_DAY	18	0	f	2011-01-09	4352	\N	27154	\N
97448	GENERIC_DAY	18	0	f	2011-01-15	4354	\N	27154	\N
97449	GENERIC_DAY	18	14400	f	2011-01-10	4354	\N	27154	\N
97450	GENERIC_DAY	18	0	f	2011-01-08	4352	\N	27154	\N
97451	GENERIC_DAY	18	14400	f	2010-11-23	4354	\N	27154	\N
97452	GENERIC_DAY	18	14400	f	2010-12-29	4354	\N	27154	\N
97453	GENERIC_DAY	18	0	f	2010-11-13	4354	\N	27154	\N
97454	GENERIC_DAY	18	14400	f	2010-12-28	4352	\N	27154	\N
97455	GENERIC_DAY	18	0	f	2010-12-18	4354	\N	27154	\N
97456	GENERIC_DAY	18	0	f	2011-01-02	4354	\N	27154	\N
97457	GENERIC_DAY	18	14400	f	2010-11-11	4352	\N	27154	\N
97458	GENERIC_DAY	18	14400	f	2010-12-14	4352	\N	27154	\N
97459	GENERIC_DAY	18	14400	f	2010-12-01	4354	\N	27154	\N
97460	GENERIC_DAY	18	14400	f	2010-11-17	4354	\N	27154	\N
97461	GENERIC_DAY	18	14400	f	2010-12-02	4352	\N	27154	\N
97462	GENERIC_DAY	18	14400	f	2010-11-09	4354	\N	27154	\N
97463	GENERIC_DAY	18	0	f	2010-12-26	4352	\N	27154	\N
97464	GENERIC_DAY	18	0	f	2010-12-18	4352	\N	27154	\N
97465	GENERIC_DAY	18	0	f	2010-12-11	4352	\N	27154	\N
97466	GENERIC_DAY	18	14400	f	2011-01-04	4354	\N	27154	\N
97467	GENERIC_DAY	18	14400	f	2010-11-23	4352	\N	27154	\N
97468	GENERIC_DAY	18	14400	f	2011-01-03	4352	\N	27154	\N
97469	GENERIC_DAY	18	14400	f	2010-12-07	4352	\N	27154	\N
97470	GENERIC_DAY	18	14400	f	2011-01-14	4354	\N	27154	\N
97471	GENERIC_DAY	18	14400	f	2010-11-18	4352	\N	27154	\N
97472	GENERIC_DAY	18	14400	f	2010-11-26	4352	\N	27154	\N
97473	GENERIC_DAY	18	0	f	2010-12-05	4354	\N	27154	\N
97474	GENERIC_DAY	18	14400	f	2010-12-06	4352	\N	27154	\N
97475	GENERIC_DAY	18	14400	f	2011-01-11	4354	\N	27154	\N
97476	GENERIC_DAY	18	14400	f	2011-01-12	4354	\N	27154	\N
97477	GENERIC_DAY	18	14400	f	2011-01-13	4352	\N	27154	\N
97478	GENERIC_DAY	18	0	f	2010-11-21	4352	\N	27154	\N
97479	GENERIC_DAY	18	0	f	2010-11-14	4352	\N	27154	\N
97480	GENERIC_DAY	18	0	f	2011-01-15	4352	\N	27154	\N
97481	GENERIC_DAY	18	14400	f	2010-12-13	4352	\N	27154	\N
97482	GENERIC_DAY	18	14400	f	2010-12-30	4352	\N	27154	\N
97483	GENERIC_DAY	18	0	f	2011-01-16	4352	\N	27154	\N
97484	GENERIC_DAY	18	14400	f	2010-11-30	4352	\N	27154	\N
97485	GENERIC_DAY	18	14400	f	2010-11-17	4352	\N	27154	\N
97486	GENERIC_DAY	18	14400	f	2010-12-23	4352	\N	27154	\N
97487	GENERIC_DAY	18	0	f	2010-11-20	4352	\N	27154	\N
97488	GENERIC_DAY	18	14400	f	2010-12-03	4352	\N	27154	\N
97489	GENERIC_DAY	18	14400	f	2011-01-05	4352	\N	27154	\N
97490	GENERIC_DAY	18	14400	f	2010-11-11	4354	\N	27154	\N
97491	GENERIC_DAY	18	14400	f	2010-12-16	4354	\N	27154	\N
97492	GENERIC_DAY	18	14400	f	2010-12-08	4354	\N	27154	\N
97493	GENERIC_DAY	18	14400	f	2010-11-18	4354	\N	27154	\N
97494	GENERIC_DAY	18	14400	f	2010-12-24	4354	\N	27154	\N
97495	GENERIC_DAY	18	0	f	2010-12-04	4354	\N	27154	\N
97496	GENERIC_DAY	18	0	f	2011-01-09	4354	\N	27154	\N
97497	GENERIC_DAY	18	14400	f	2010-11-25	4352	\N	27154	\N
97498	GENERIC_DAY	18	14400	f	2010-12-31	4352	\N	27154	\N
97499	GENERIC_DAY	18	14400	f	2011-01-03	4354	\N	27154	\N
97500	GENERIC_DAY	18	14400	f	2011-01-06	4354	\N	27154	\N
97501	GENERIC_DAY	18	14400	f	2010-12-17	4354	\N	27154	\N
97502	GENERIC_DAY	18	14400	f	2011-01-12	4352	\N	27154	\N
97503	GENERIC_DAY	18	14400	f	2010-12-29	4352	\N	27154	\N
97504	GENERIC_DAY	18	14400	f	2010-12-31	4354	\N	27154	\N
97505	GENERIC_DAY	18	14400	f	2010-11-26	4354	\N	27154	\N
97506	GENERIC_DAY	18	14400	f	2010-11-24	4352	\N	27154	\N
97507	GENERIC_DAY	18	14400	f	2010-11-29	4354	\N	27154	\N
97508	GENERIC_DAY	18	14400	f	2010-11-22	4354	\N	27154	\N
97509	GENERIC_DAY	18	14400	f	2010-11-15	4352	\N	27154	\N
97510	GENERIC_DAY	18	0	f	2010-12-04	4352	\N	27154	\N
97511	GENERIC_DAY	18	14400	f	2010-11-12	4352	\N	27154	\N
97512	GENERIC_DAY	18	14400	f	2010-11-25	4354	\N	27154	\N
97513	GENERIC_DAY	18	14400	f	2010-11-16	4352	\N	27154	\N
97514	GENERIC_DAY	18	14400	f	2010-12-02	4354	\N	27154	\N
97515	GENERIC_DAY	18	14400	f	2010-12-17	4352	\N	27154	\N
97516	GENERIC_DAY	18	14400	f	2010-12-16	4352	\N	27154	\N
97517	GENERIC_DAY	18	14400	f	2010-12-08	4352	\N	27154	\N
97518	GENERIC_DAY	18	14400	f	2011-01-10	4352	\N	27154	\N
97519	GENERIC_DAY	18	14400	f	2010-12-21	4352	\N	27154	\N
97520	GENERIC_DAY	18	14400	f	2010-12-20	4352	\N	27154	\N
97521	GENERIC_DAY	18	14400	f	2010-12-01	4352	\N	27154	\N
97522	GENERIC_DAY	18	14400	f	2010-11-19	4352	\N	27154	\N
97523	GENERIC_DAY	18	0	f	2010-11-21	4354	\N	27154	\N
97524	GENERIC_DAY	18	0	f	2010-12-12	4352	\N	27154	\N
97525	GENERIC_DAY	18	0	f	2011-01-01	4354	\N	27154	\N
97526	GENERIC_DAY	18	0	f	2010-12-25	4352	\N	27154	\N
97527	GENERIC_DAY	18	0	f	2010-11-28	4354	\N	27154	\N
97528	GENERIC_DAY	18	14400	f	2011-01-07	4354	\N	27154	\N
97529	GENERIC_DAY	18	0	f	2010-11-14	4354	\N	27154	\N
97530	GENERIC_DAY	18	14400	f	2011-01-04	4352	\N	27154	\N
97531	GENERIC_DAY	18	14400	f	2010-12-10	4354	\N	27154	\N
97532	GENERIC_DAY	18	0	f	2010-12-19	4352	\N	27154	\N
97533	GENERIC_DAY	18	14400	f	2010-12-03	4354	\N	27154	\N
97534	GENERIC_DAY	18	14400	f	2011-01-06	4352	\N	27154	\N
97535	GENERIC_DAY	18	0	f	2010-11-27	4354	\N	27154	\N
97536	GENERIC_DAY	18	14400	f	2010-11-30	4354	\N	27154	\N
97537	GENERIC_DAY	18	14400	f	2010-11-24	4354	\N	27154	\N
97538	GENERIC_DAY	18	14400	f	2010-12-22	4352	\N	27154	\N
97539	GENERIC_DAY	18	14400	f	2010-12-27	4352	\N	27154	\N
97540	GENERIC_DAY	18	14400	f	2010-12-10	4352	\N	27154	\N
97541	GENERIC_DAY	18	0	f	2010-11-28	4352	\N	27154	\N
97542	GENERIC_DAY	18	14400	f	2011-01-13	4354	\N	27154	\N
97543	GENERIC_DAY	18	14400	f	2010-12-24	4352	\N	27154	\N
97544	GENERIC_DAY	18	0	f	2010-12-19	4354	\N	27154	\N
97545	GENERIC_DAY	18	0	f	2011-01-08	4354	\N	27154	\N
97546	GENERIC_DAY	18	14400	f	2010-11-10	4352	\N	27154	\N
97547	GENERIC_DAY	18	0	f	2011-01-02	4352	\N	27154	\N
97548	GENERIC_DAY	18	14400	f	2010-12-09	4352	\N	27154	\N
97549	GENERIC_DAY	18	0	f	2011-01-01	4352	\N	27154	\N
97550	GENERIC_DAY	18	14400	f	2010-12-23	4354	\N	27154	\N
97551	GENERIC_DAY	18	14400	f	2010-12-28	4354	\N	27154	\N
97552	GENERIC_DAY	18	14400	f	2010-11-09	4352	\N	27154	\N
97553	GENERIC_DAY	18	14400	f	2010-11-19	4354	\N	27154	\N
97554	GENERIC_DAY	18	14400	f	2010-12-09	4354	\N	27154	\N
97555	GENERIC_DAY	18	14400	f	2011-01-17	4352	\N	27154	\N
97556	GENERIC_DAY	18	14400	f	2010-12-15	4354	\N	27154	\N
97557	GENERIC_DAY	18	0	f	2010-12-12	4354	\N	27154	\N
97558	GENERIC_DAY	18	14400	f	2010-12-15	4352	\N	27154	\N
97559	GENERIC_DAY	18	14400	f	2010-12-06	4354	\N	27154	\N
97560	GENERIC_DAY	18	14400	f	2010-11-29	4352	\N	27154	\N
97561	GENERIC_DAY	18	14400	f	2010-12-07	4354	\N	27154	\N
97562	GENERIC_DAY	18	0	f	2010-11-27	4352	\N	27154	\N
97563	GENERIC_DAY	18	0	f	2010-12-26	4354	\N	27154	\N
97564	GENERIC_DAY	18	14400	f	2010-12-30	4354	\N	27154	\N
97565	GENERIC_DAY	18	14400	f	2011-01-07	4352	\N	27154	\N
97566	GENERIC_DAY	18	0	f	2010-12-11	4354	\N	27154	\N
97567	GENERIC_DAY	18	14400	f	2010-11-15	4354	\N	27154	\N
97568	GENERIC_DAY	18	14400	f	2010-11-22	4352	\N	27154	\N
97569	GENERIC_DAY	18	0	f	2010-12-05	4352	\N	27154	\N
97570	GENERIC_DAY	18	0	f	2011-01-16	4354	\N	27154	\N
97571	GENERIC_DAY	18	0	f	2010-12-25	4354	\N	27154	\N
97572	GENERIC_DAY	18	14400	f	2011-01-17	4354	\N	27154	\N
97573	GENERIC_DAY	18	14400	f	2011-01-11	4352	\N	27154	\N
97574	GENERIC_DAY	18	14400	f	2010-11-10	4354	\N	27154	\N
97575	GENERIC_DAY	18	14400	f	2010-12-21	4354	\N	27154	\N
97576	GENERIC_DAY	18	14400	f	2011-01-14	4352	\N	27154	\N
97577	GENERIC_DAY	18	14400	f	2010-11-16	4354	\N	27154	\N
97578	GENERIC_DAY	17	0	f	2010-11-06	4350	\N	27155	\N
97579	GENERIC_DAY	17	7200	f	2010-11-04	4350	\N	27155	\N
97580	GENERIC_DAY	17	0	f	2010-10-17	4350	\N	27155	\N
97581	GENERIC_DAY	17	7200	f	2010-10-14	4358	\N	27155	\N
97582	GENERIC_DAY	17	7200	f	2010-11-02	4358	\N	27155	\N
97583	GENERIC_DAY	17	7200	f	2010-10-25	4350	\N	27155	\N
97584	GENERIC_DAY	17	7200	f	2010-10-20	4344	\N	27155	\N
97585	GENERIC_DAY	17	7200	f	2010-11-08	4348	\N	27155	\N
97586	GENERIC_DAY	17	0	f	2010-10-24	4348	\N	27155	\N
97587	GENERIC_DAY	17	7200	f	2010-11-05	4358	\N	27155	\N
97588	GENERIC_DAY	17	0	f	2010-10-16	4348	\N	27155	\N
97589	GENERIC_DAY	17	7200	f	2010-10-25	4344	\N	27155	\N
97590	GENERIC_DAY	17	7200	f	2010-10-13	4350	\N	27155	\N
97591	GENERIC_DAY	17	7200	f	2010-11-01	4344	\N	27155	\N
97592	GENERIC_DAY	17	7200	f	2010-10-21	4350	\N	27155	\N
97593	GENERIC_DAY	17	0	f	2010-11-06	4344	\N	27155	\N
97594	GENERIC_DAY	17	7200	f	2010-10-26	4344	\N	27155	\N
97595	GENERIC_DAY	17	7200	f	2010-10-14	4344	\N	27155	\N
97596	GENERIC_DAY	17	0	f	2010-10-16	4350	\N	27155	\N
97597	GENERIC_DAY	17	0	f	2010-10-30	4350	\N	27155	\N
97598	GENERIC_DAY	17	7200	f	2010-10-25	4358	\N	27155	\N
97599	GENERIC_DAY	17	7200	f	2010-11-02	4348	\N	27155	\N
97600	GENERIC_DAY	17	7200	f	2010-10-22	4344	\N	27155	\N
97601	GENERIC_DAY	17	7200	f	2010-10-27	4344	\N	27155	\N
97602	GENERIC_DAY	17	7200	f	2010-10-18	4350	\N	27155	\N
97603	GENERIC_DAY	17	7200	f	2010-11-01	4358	\N	27155	\N
97604	GENERIC_DAY	17	7200	f	2010-10-21	4348	\N	27155	\N
97605	GENERIC_DAY	17	7200	f	2010-10-15	4348	\N	27155	\N
97606	GENERIC_DAY	17	7200	f	2010-10-18	4344	\N	27155	\N
97607	GENERIC_DAY	17	0	f	2010-10-23	4358	\N	27155	\N
97608	GENERIC_DAY	17	0	f	2010-10-24	4344	\N	27155	\N
97609	GENERIC_DAY	17	7200	f	2010-10-28	4344	\N	27155	\N
97610	GENERIC_DAY	17	0	f	2010-11-06	4348	\N	27155	\N
97611	GENERIC_DAY	17	7200	f	2010-10-25	4348	\N	27155	\N
97612	GENERIC_DAY	17	0	f	2010-10-16	4344	\N	27155	\N
97613	GENERIC_DAY	17	7200	f	2010-10-19	4358	\N	27155	\N
97614	GENERIC_DAY	17	0	f	2010-11-07	4350	\N	27155	\N
97615	GENERIC_DAY	17	7200	f	2010-10-27	4348	\N	27155	\N
97616	GENERIC_DAY	17	7200	f	2010-11-08	4344	\N	27155	\N
97617	GENERIC_DAY	17	0	f	2010-10-31	4344	\N	27155	\N
97618	GENERIC_DAY	17	7200	f	2010-10-26	4358	\N	27155	\N
97619	GENERIC_DAY	17	7200	f	2010-10-26	4350	\N	27155	\N
97620	GENERIC_DAY	17	7200	f	2010-10-27	4358	\N	27155	\N
97621	GENERIC_DAY	17	7200	f	2010-11-01	4350	\N	27155	\N
97622	GENERIC_DAY	17	7200	f	2010-10-29	4348	\N	27155	\N
97623	GENERIC_DAY	17	7200	f	2010-10-20	4348	\N	27155	\N
97624	GENERIC_DAY	17	0	f	2010-10-24	4350	\N	27155	\N
97625	GENERIC_DAY	17	0	f	2010-10-30	4344	\N	27155	\N
97626	GENERIC_DAY	17	0	f	2010-10-31	4350	\N	27155	\N
97627	GENERIC_DAY	17	7200	f	2010-10-18	4348	\N	27155	\N
97628	GENERIC_DAY	17	7200	f	2010-11-03	4348	\N	27155	\N
97629	GENERIC_DAY	17	7200	f	2010-10-28	4350	\N	27155	\N
97630	GENERIC_DAY	17	7200	f	2010-10-13	4348	\N	27155	\N
97631	GENERIC_DAY	17	7200	f	2010-10-29	4358	\N	27155	\N
97632	GENERIC_DAY	17	7200	f	2010-10-14	4348	\N	27155	\N
97633	GENERIC_DAY	17	7200	f	2010-11-03	4344	\N	27155	\N
97634	GENERIC_DAY	17	0	f	2010-10-30	4358	\N	27155	\N
97635	GENERIC_DAY	17	7200	f	2010-10-14	4350	\N	27155	\N
97636	GENERIC_DAY	17	7200	f	2010-11-03	4350	\N	27155	\N
97637	GENERIC_DAY	17	7200	f	2010-11-04	4344	\N	27155	\N
97638	GENERIC_DAY	17	0	f	2010-10-17	4358	\N	27155	\N
97639	GENERIC_DAY	17	7200	f	2010-10-15	4344	\N	27155	\N
97640	GENERIC_DAY	17	7200	f	2010-10-21	4344	\N	27155	\N
97641	GENERIC_DAY	17	0	f	2010-10-24	4358	\N	27155	\N
97642	GENERIC_DAY	17	7200	f	2010-10-19	4348	\N	27155	\N
97643	GENERIC_DAY	17	0	f	2010-11-07	4348	\N	27155	\N
97644	GENERIC_DAY	17	7200	f	2010-10-22	4358	\N	27155	\N
97645	GENERIC_DAY	17	0	f	2010-10-17	4344	\N	27155	\N
97646	GENERIC_DAY	17	0	f	2010-11-07	4358	\N	27155	\N
97647	GENERIC_DAY	17	7200	f	2010-10-13	4358	\N	27155	\N
97648	GENERIC_DAY	17	7200	f	2010-11-03	4358	\N	27155	\N
97649	GENERIC_DAY	17	7200	f	2010-10-29	4344	\N	27155	\N
97650	GENERIC_DAY	17	0	f	2010-10-17	4348	\N	27155	\N
97651	GENERIC_DAY	17	7200	f	2010-11-05	4344	\N	27155	\N
97652	GENERIC_DAY	17	0	f	2010-10-30	4348	\N	27155	\N
97653	GENERIC_DAY	17	7200	f	2010-10-22	4348	\N	27155	\N
97654	GENERIC_DAY	17	0	f	2010-10-16	4358	\N	27155	\N
97655	GENERIC_DAY	17	7200	f	2010-10-27	4350	\N	27155	\N
97656	GENERIC_DAY	17	0	f	2010-10-31	4348	\N	27155	\N
97657	GENERIC_DAY	17	7200	f	2010-10-15	4358	\N	27155	\N
97658	GENERIC_DAY	17	7200	f	2010-11-05	4348	\N	27155	\N
97659	GENERIC_DAY	17	0	f	2010-10-23	4348	\N	27155	\N
97660	GENERIC_DAY	17	7200	f	2010-10-18	4358	\N	27155	\N
97661	GENERIC_DAY	17	7200	f	2010-11-04	4358	\N	27155	\N
97662	GENERIC_DAY	17	7200	f	2010-11-02	4344	\N	27155	\N
97663	GENERIC_DAY	17	7200	f	2010-10-28	4348	\N	27155	\N
97664	GENERIC_DAY	17	7200	f	2010-11-02	4350	\N	27155	\N
97665	GENERIC_DAY	17	7200	f	2010-10-15	4350	\N	27155	\N
97666	GENERIC_DAY	17	7200	f	2010-10-20	4350	\N	27155	\N
97667	GENERIC_DAY	17	7200	f	2010-10-19	4344	\N	27155	\N
97668	GENERIC_DAY	17	7200	f	2010-10-20	4358	\N	27155	\N
97669	GENERIC_DAY	17	0	f	2010-11-07	4344	\N	27155	\N
97670	GENERIC_DAY	17	7200	f	2010-10-19	4350	\N	27155	\N
97671	GENERIC_DAY	17	7200	f	2010-10-21	4358	\N	27155	\N
97672	GENERIC_DAY	17	7200	f	2010-10-29	4350	\N	27155	\N
97673	GENERIC_DAY	17	0	f	2010-10-31	4358	\N	27155	\N
97674	GENERIC_DAY	17	0	f	2010-10-23	4344	\N	27155	\N
97675	GENERIC_DAY	17	7200	f	2010-11-05	4350	\N	27155	\N
97676	GENERIC_DAY	17	3600	f	2010-11-08	4358	\N	27155	\N
97677	GENERIC_DAY	17	7200	f	2010-10-13	4344	\N	27155	\N
97678	GENERIC_DAY	17	7200	f	2010-10-28	4358	\N	27155	\N
97679	GENERIC_DAY	17	7200	f	2010-10-26	4348	\N	27155	\N
97680	GENERIC_DAY	17	7200	f	2010-11-04	4348	\N	27155	\N
97681	GENERIC_DAY	17	7200	f	2010-10-22	4350	\N	27155	\N
97682	GENERIC_DAY	17	7200	f	2010-11-01	4348	\N	27155	\N
97683	GENERIC_DAY	17	0	f	2010-10-23	4350	\N	27155	\N
97684	GENERIC_DAY	17	3600	f	2010-11-08	4350	\N	27155	\N
97685	GENERIC_DAY	17	0	f	2010-11-06	4358	\N	27155	\N
97776	GENERIC_DAY	16	7200	f	2010-11-19	4348	\N	27156	\N
97777	GENERIC_DAY	16	0	f	2010-12-05	4344	\N	27156	\N
97778	GENERIC_DAY	16	7200	f	2010-11-12	4350	\N	27156	\N
97779	GENERIC_DAY	16	7200	f	2010-11-24	4348	\N	27156	\N
97780	GENERIC_DAY	16	0	f	2010-11-13	4348	\N	27156	\N
97781	GENERIC_DAY	16	7200	f	2010-12-13	4348	\N	27156	\N
97782	GENERIC_DAY	16	7200	f	2010-11-09	4344	\N	27156	\N
97783	GENERIC_DAY	16	7200	f	2010-11-10	4350	\N	27156	\N
97784	GENERIC_DAY	16	7200	f	2010-11-23	4350	\N	27156	\N
97785	GENERIC_DAY	16	0	f	2010-11-14	4348	\N	27156	\N
97786	GENERIC_DAY	16	7200	f	2010-12-01	4344	\N	27156	\N
97787	GENERIC_DAY	16	0	f	2010-11-21	4358	\N	27156	\N
97788	GENERIC_DAY	16	7200	f	2010-11-16	4348	\N	27156	\N
97789	GENERIC_DAY	16	0	f	2010-11-14	4344	\N	27156	\N
97790	GENERIC_DAY	16	7200	f	2010-12-01	4358	\N	27156	\N
97791	GENERIC_DAY	16	7200	f	2010-12-06	4350	\N	27156	\N
97792	GENERIC_DAY	16	7200	f	2010-11-26	4348	\N	27156	\N
97793	GENERIC_DAY	16	0	f	2010-12-05	4350	\N	27156	\N
97794	GENERIC_DAY	16	7200	f	2010-12-07	4358	\N	27156	\N
97795	GENERIC_DAY	16	7200	f	2010-12-10	4358	\N	27156	\N
97796	GENERIC_DAY	16	7200	f	2010-11-29	4344	\N	27156	\N
97797	GENERIC_DAY	16	0	f	2010-11-28	4344	\N	27156	\N
97798	GENERIC_DAY	16	7200	f	2010-11-11	4344	\N	27156	\N
97799	GENERIC_DAY	16	0	f	2010-11-20	4344	\N	27156	\N
97800	GENERIC_DAY	16	7200	f	2010-11-30	4344	\N	27156	\N
97801	GENERIC_DAY	16	7200	f	2010-11-17	4350	\N	27156	\N
97802	GENERIC_DAY	16	7200	f	2010-12-03	4358	\N	27156	\N
97803	GENERIC_DAY	16	7200	f	2010-11-25	4344	\N	27156	\N
97804	GENERIC_DAY	16	7200	f	2010-11-18	4350	\N	27156	\N
97805	GENERIC_DAY	16	7200	f	2010-11-15	4350	\N	27156	\N
97806	GENERIC_DAY	16	0	f	2010-12-04	4348	\N	27156	\N
97807	GENERIC_DAY	16	0	f	2010-12-11	4358	\N	27156	\N
97808	GENERIC_DAY	16	7200	f	2010-11-24	4350	\N	27156	\N
97809	GENERIC_DAY	16	7200	f	2010-11-25	4350	\N	27156	\N
97810	GENERIC_DAY	16	7200	f	2010-11-29	4348	\N	27156	\N
97811	GENERIC_DAY	16	7200	f	2010-11-26	4358	\N	27156	\N
97812	GENERIC_DAY	16	0	f	2010-11-13	4358	\N	27156	\N
97813	GENERIC_DAY	16	0	f	2010-12-04	4344	\N	27156	\N
97814	GENERIC_DAY	16	0	f	2010-11-27	4348	\N	27156	\N
97815	GENERIC_DAY	16	7200	f	2010-12-08	4348	\N	27156	\N
97816	GENERIC_DAY	16	7200	f	2010-12-06	4358	\N	27156	\N
97817	GENERIC_DAY	16	7200	f	2010-12-09	4350	\N	27156	\N
97818	GENERIC_DAY	16	0	f	2010-12-12	4358	\N	27156	\N
97819	GENERIC_DAY	16	7200	f	2010-11-26	4344	\N	27156	\N
97820	GENERIC_DAY	16	7200	f	2010-11-15	4348	\N	27156	\N
97821	GENERIC_DAY	16	7200	f	2010-12-10	4344	\N	27156	\N
97822	GENERIC_DAY	16	7200	f	2010-11-09	4350	\N	27156	\N
97823	GENERIC_DAY	16	7200	f	2010-12-07	4348	\N	27156	\N
97824	GENERIC_DAY	16	7200	f	2010-12-10	4348	\N	27156	\N
97825	GENERIC_DAY	16	0	f	2010-12-11	4344	\N	27156	\N
97826	GENERIC_DAY	16	7200	f	2010-12-03	4350	\N	27156	\N
97827	GENERIC_DAY	16	7200	f	2010-12-13	4358	\N	27156	\N
97828	GENERIC_DAY	16	7200	f	2010-11-24	4358	\N	27156	\N
97829	GENERIC_DAY	16	7200	f	2010-12-08	4350	\N	27156	\N
97830	GENERIC_DAY	16	0	f	2010-12-12	4350	\N	27156	\N
97831	GENERIC_DAY	16	7200	f	2010-12-03	4344	\N	27156	\N
97832	GENERIC_DAY	16	7200	f	2010-11-30	4350	\N	27156	\N
97833	GENERIC_DAY	16	7200	f	2010-11-09	4358	\N	27156	\N
97834	GENERIC_DAY	16	0	f	2010-11-13	4344	\N	27156	\N
97835	GENERIC_DAY	16	7200	f	2010-11-18	4358	\N	27156	\N
97836	GENERIC_DAY	16	7200	f	2010-12-06	4344	\N	27156	\N
97837	GENERIC_DAY	16	7200	f	2010-11-11	4358	\N	27156	\N
97838	GENERIC_DAY	16	7200	f	2010-11-16	4344	\N	27156	\N
97839	GENERIC_DAY	16	7200	f	2010-11-19	4358	\N	27156	\N
97840	GENERIC_DAY	16	7200	f	2010-11-15	4358	\N	27156	\N
97841	GENERIC_DAY	16	0	f	2010-12-11	4350	\N	27156	\N
97842	GENERIC_DAY	16	7200	f	2010-12-07	4350	\N	27156	\N
97843	GENERIC_DAY	16	7200	f	2010-11-09	4348	\N	27156	\N
97844	GENERIC_DAY	16	0	f	2010-12-12	4344	\N	27156	\N
97845	GENERIC_DAY	16	7200	f	2010-12-13	4350	\N	27156	\N
97846	GENERIC_DAY	16	7200	f	2010-11-16	4350	\N	27156	\N
97847	GENERIC_DAY	16	7200	f	2010-11-22	4350	\N	27156	\N
97848	GENERIC_DAY	16	0	f	2010-11-14	4358	\N	27156	\N
97849	GENERIC_DAY	16	7200	f	2010-12-09	4348	\N	27156	\N
97850	GENERIC_DAY	16	7200	f	2010-11-17	4344	\N	27156	\N
97851	GENERIC_DAY	16	7200	f	2010-11-22	4344	\N	27156	\N
97852	GENERIC_DAY	16	7200	f	2010-11-18	4348	\N	27156	\N
97853	GENERIC_DAY	16	7200	f	2010-12-02	4344	\N	27156	\N
97854	GENERIC_DAY	16	7200	f	2010-11-23	4358	\N	27156	\N
97855	GENERIC_DAY	16	7200	f	2010-11-17	4358	\N	27156	\N
97856	GENERIC_DAY	16	7200	f	2010-11-11	4350	\N	27156	\N
97857	GENERIC_DAY	16	7200	f	2010-11-19	4350	\N	27156	\N
97858	GENERIC_DAY	16	7200	f	2010-12-02	4358	\N	27156	\N
97859	GENERIC_DAY	16	0	f	2010-11-28	4350	\N	27156	\N
97860	GENERIC_DAY	16	7200	f	2010-11-26	4350	\N	27156	\N
97861	GENERIC_DAY	16	7200	f	2010-12-08	4344	\N	27156	\N
97862	GENERIC_DAY	16	0	f	2010-11-21	4348	\N	27156	\N
97863	GENERIC_DAY	16	0	f	2010-11-14	4350	\N	27156	\N
97864	GENERIC_DAY	16	7200	f	2010-12-07	4344	\N	27156	\N
97865	GENERIC_DAY	16	7200	f	2010-11-16	4358	\N	27156	\N
97866	GENERIC_DAY	16	7200	f	2010-11-17	4348	\N	27156	\N
97867	GENERIC_DAY	16	7200	f	2010-11-18	4344	\N	27156	\N
97868	GENERIC_DAY	16	7200	f	2010-12-01	4348	\N	27156	\N
97869	GENERIC_DAY	16	7200	f	2010-11-24	4344	\N	27156	\N
97870	GENERIC_DAY	16	0	f	2010-11-28	4348	\N	27156	\N
97871	GENERIC_DAY	16	7200	f	2010-11-12	4358	\N	27156	\N
97872	GENERIC_DAY	16	0	f	2010-11-21	4344	\N	27156	\N
97873	GENERIC_DAY	16	7200	f	2010-12-08	4358	\N	27156	\N
97874	GENERIC_DAY	16	7200	f	2010-11-10	4348	\N	27156	\N
97875	GENERIC_DAY	16	7200	f	2010-11-23	4344	\N	27156	\N
97876	GENERIC_DAY	16	0	f	2010-12-04	4358	\N	27156	\N
97877	GENERIC_DAY	16	7200	f	2010-11-25	4348	\N	27156	\N
97878	GENERIC_DAY	16	7200	f	2010-11-30	4348	\N	27156	\N
97879	GENERIC_DAY	16	7200	f	2010-11-10	4358	\N	27156	\N
97880	GENERIC_DAY	16	7200	f	2010-11-11	4348	\N	27156	\N
97881	GENERIC_DAY	16	7200	f	2010-12-02	4348	\N	27156	\N
97882	GENERIC_DAY	16	7200	f	2010-11-30	4358	\N	27156	\N
97883	GENERIC_DAY	16	0	f	2010-11-20	4348	\N	27156	\N
97884	GENERIC_DAY	16	0	f	2010-11-20	4358	\N	27156	\N
97885	GENERIC_DAY	16	7200	f	2010-12-02	4350	\N	27156	\N
97886	GENERIC_DAY	16	7200	f	2010-11-12	4344	\N	27156	\N
97887	GENERIC_DAY	16	7200	f	2010-11-29	4358	\N	27156	\N
97888	GENERIC_DAY	16	7200	f	2010-12-06	4348	\N	27156	\N
97889	GENERIC_DAY	16	7200	f	2010-12-13	4344	\N	27156	\N
97890	GENERIC_DAY	16	0	f	2010-12-11	4348	\N	27156	\N
97891	GENERIC_DAY	16	0	f	2010-11-27	4358	\N	27156	\N
97892	GENERIC_DAY	16	7200	f	2010-11-22	4348	\N	27156	\N
97893	GENERIC_DAY	16	0	f	2010-12-04	4350	\N	27156	\N
97894	GENERIC_DAY	16	0	f	2010-12-12	4348	\N	27156	\N
97895	GENERIC_DAY	16	0	f	2010-11-28	4358	\N	27156	\N
97896	GENERIC_DAY	16	0	f	2010-11-13	4350	\N	27156	\N
97897	GENERIC_DAY	16	0	f	2010-11-27	4350	\N	27156	\N
97898	GENERIC_DAY	16	0	f	2010-11-27	4344	\N	27156	\N
97899	GENERIC_DAY	16	7200	f	2010-11-25	4358	\N	27156	\N
97900	GENERIC_DAY	16	0	f	2010-11-20	4350	\N	27156	\N
97901	GENERIC_DAY	16	7200	f	2010-12-03	4348	\N	27156	\N
97902	GENERIC_DAY	16	0	f	2010-12-05	4348	\N	27156	\N
97903	GENERIC_DAY	16	0	f	2010-12-05	4358	\N	27156	\N
97904	GENERIC_DAY	16	7200	f	2010-12-09	4344	\N	27156	\N
97905	GENERIC_DAY	16	7200	f	2010-11-10	4344	\N	27156	\N
97906	GENERIC_DAY	16	7200	f	2010-11-15	4344	\N	27156	\N
97907	GENERIC_DAY	16	7200	f	2010-12-09	4358	\N	27156	\N
97908	GENERIC_DAY	16	7200	f	2010-12-10	4350	\N	27156	\N
97909	GENERIC_DAY	16	7200	f	2010-12-01	4350	\N	27156	\N
97910	GENERIC_DAY	16	7200	f	2010-11-19	4344	\N	27156	\N
97911	GENERIC_DAY	16	7200	f	2010-11-23	4348	\N	27156	\N
97912	GENERIC_DAY	16	0	f	2010-11-21	4350	\N	27156	\N
97913	GENERIC_DAY	16	7200	f	2010-11-12	4348	\N	27156	\N
97914	GENERIC_DAY	16	7200	f	2010-11-29	4350	\N	27156	\N
97915	GENERIC_DAY	16	7200	f	2010-11-22	4358	\N	27156	\N
97916	SPECIFIC_DAY	16	28800	f	2010-07-05	4344	31227	\N	\N
97917	SPECIFIC_DAY	16	28800	f	2010-06-30	4344	31227	\N	\N
97918	SPECIFIC_DAY	16	0	f	2010-06-19	4344	31227	\N	\N
97919	SPECIFIC_DAY	16	28800	f	2010-07-15	4344	31227	\N	\N
97920	SPECIFIC_DAY	16	28800	f	2010-06-21	4344	31227	\N	\N
97921	SPECIFIC_DAY	16	28800	f	2010-07-09	4344	31227	\N	\N
97922	SPECIFIC_DAY	16	28800	f	2010-06-28	4344	31227	\N	\N
97923	SPECIFIC_DAY	16	28800	f	2010-07-12	4344	31227	\N	\N
97924	SPECIFIC_DAY	16	28800	f	2010-07-14	4344	31227	\N	\N
97925	SPECIFIC_DAY	16	0	f	2010-07-11	4344	31227	\N	\N
97926	SPECIFIC_DAY	16	28800	f	2010-06-14	4344	31227	\N	\N
97927	SPECIFIC_DAY	16	0	f	2010-07-10	4344	31227	\N	\N
97928	SPECIFIC_DAY	16	28800	f	2010-07-06	4344	31227	\N	\N
97929	SPECIFIC_DAY	16	0	f	2010-07-04	4344	31227	\N	\N
97930	SPECIFIC_DAY	16	28800	f	2010-07-01	4344	31227	\N	\N
97931	SPECIFIC_DAY	16	28800	f	2010-06-15	4344	31227	\N	\N
97932	SPECIFIC_DAY	16	28800	f	2010-06-22	4344	31227	\N	\N
97933	SPECIFIC_DAY	16	28800	f	2010-06-17	4344	31227	\N	\N
97934	SPECIFIC_DAY	16	28800	f	2010-07-07	4344	31227	\N	\N
97935	SPECIFIC_DAY	16	0	f	2010-06-26	4344	31227	\N	\N
97936	SPECIFIC_DAY	16	28800	f	2010-06-16	4344	31227	\N	\N
97937	SPECIFIC_DAY	16	28800	f	2010-06-23	4344	31227	\N	\N
97938	SPECIFIC_DAY	16	0	f	2010-06-27	4344	31227	\N	\N
97939	SPECIFIC_DAY	16	28800	f	2010-06-24	4344	31227	\N	\N
97940	SPECIFIC_DAY	16	28800	f	2010-07-16	4344	31227	\N	\N
97941	SPECIFIC_DAY	16	28800	f	2010-07-13	4344	31227	\N	\N
97942	SPECIFIC_DAY	16	28800	f	2010-06-25	4344	31227	\N	\N
97943	SPECIFIC_DAY	16	28800	f	2010-07-02	4344	31227	\N	\N
97944	SPECIFIC_DAY	16	0	f	2010-07-03	4344	31227	\N	\N
97945	SPECIFIC_DAY	16	28800	f	2010-06-18	4344	31227	\N	\N
97946	SPECIFIC_DAY	16	28800	f	2010-06-29	4344	31227	\N	\N
97947	SPECIFIC_DAY	16	28800	f	2010-07-08	4344	31227	\N	\N
97948	SPECIFIC_DAY	16	0	f	2010-06-20	4344	31227	\N	\N
97958	SPECIFIC_DAY	16	0	f	2010-06-20	4350	31226	\N	\N
97959	SPECIFIC_DAY	16	28800	f	2010-06-24	4350	31226	\N	\N
97960	SPECIFIC_DAY	16	0	f	2010-06-19	4350	31226	\N	\N
97961	SPECIFIC_DAY	16	28800	f	2010-06-16	4350	31226	\N	\N
97962	SPECIFIC_DAY	16	28800	f	2010-06-25	4350	31226	\N	\N
97963	SPECIFIC_DAY	16	28800	f	2010-06-15	4350	31226	\N	\N
97964	SPECIFIC_DAY	16	28800	f	2010-07-01	4350	31226	\N	\N
97965	SPECIFIC_DAY	16	28800	f	2010-06-21	4350	31226	\N	\N
97966	SPECIFIC_DAY	16	0	f	2010-06-27	4350	31226	\N	\N
97967	SPECIFIC_DAY	16	28800	f	2010-06-14	4350	31226	\N	\N
97968	SPECIFIC_DAY	16	28800	f	2010-06-29	4350	31226	\N	\N
97969	SPECIFIC_DAY	16	28800	f	2010-06-30	4350	31226	\N	\N
97970	SPECIFIC_DAY	16	28800	f	2010-07-05	4350	31226	\N	\N
97971	SPECIFIC_DAY	16	0	f	2010-07-04	4350	31226	\N	\N
97972	SPECIFIC_DAY	16	28800	f	2010-06-23	4350	31226	\N	\N
97973	SPECIFIC_DAY	16	28800	f	2010-07-07	4350	31226	\N	\N
97974	SPECIFIC_DAY	16	28800	f	2010-06-17	4350	31226	\N	\N
97975	SPECIFIC_DAY	16	21600	f	2010-07-08	4350	31226	\N	\N
97976	SPECIFIC_DAY	16	28800	f	2010-07-02	4350	31226	\N	\N
97977	SPECIFIC_DAY	16	28800	f	2010-06-22	4350	31226	\N	\N
97978	SPECIFIC_DAY	16	0	f	2010-06-26	4350	31226	\N	\N
97979	SPECIFIC_DAY	16	28800	f	2010-07-06	4350	31226	\N	\N
97980	SPECIFIC_DAY	16	28800	f	2010-06-18	4350	31226	\N	\N
97981	SPECIFIC_DAY	16	28800	f	2010-06-28	4350	31226	\N	\N
97982	SPECIFIC_DAY	16	0	f	2010-07-03	4350	31226	\N	\N
97983	GENERIC_DAY	15	0	f	2010-06-20	4352	\N	27157	\N
97984	GENERIC_DAY	15	0	f	2010-06-20	1216	\N	27157	\N
97985	GENERIC_DAY	15	0	f	2010-06-19	4354	\N	27157	\N
97986	GENERIC_DAY	15	0	f	2010-06-20	4348	\N	27157	\N
97987	GENERIC_DAY	15	0	f	2010-06-17	21817	\N	27157	\N
97988	GENERIC_DAY	15	0	f	2010-06-20	1220	\N	27157	\N
97989	GENERIC_DAY	15	0	f	2010-06-19	4358	\N	27157	\N
97990	GENERIC_DAY	15	0	f	2010-06-18	4358	\N	27157	\N
97991	GENERIC_DAY	15	0	f	2010-06-16	1216	\N	27157	\N
97992	GENERIC_DAY	15	0	f	2010-06-21	4358	\N	27157	\N
97993	GENERIC_DAY	15	0	f	2010-06-19	1214	\N	27157	\N
97994	GENERIC_DAY	15	7200	f	2010-06-18	72319	\N	27157	\N
97995	GENERIC_DAY	15	0	f	2010-06-15	4354	\N	27157	\N
97996	GENERIC_DAY	15	0	f	2010-06-16	4358	\N	27157	\N
97997	GENERIC_DAY	15	0	f	2010-06-18	4356	\N	27157	\N
97998	GENERIC_DAY	15	0	f	2010-06-16	4356	\N	27157	\N
97999	GENERIC_DAY	15	0	f	2010-06-17	4356	\N	27157	\N
98000	GENERIC_DAY	15	10800	f	2010-06-18	72317	\N	27157	\N
98001	GENERIC_DAY	15	0	f	2010-06-20	4358	\N	27157	\N
98002	GENERIC_DAY	15	0	f	2010-06-20	72317	\N	27157	\N
98003	GENERIC_DAY	15	10800	f	2010-06-21	72321	\N	27157	\N
98004	GENERIC_DAY	15	0	f	2010-06-18	4344	\N	27157	\N
98005	GENERIC_DAY	15	0	f	2010-06-17	4358	\N	27157	\N
98006	GENERIC_DAY	15	0	f	2010-06-15	4350	\N	27157	\N
98007	GENERIC_DAY	15	0	f	2010-06-16	4350	\N	27157	\N
98008	GENERIC_DAY	15	0	f	2010-06-15	21817	\N	27157	\N
98009	GENERIC_DAY	15	10800	f	2010-06-17	72321	\N	27157	\N
98010	GENERIC_DAY	15	0	f	2010-06-18	1220	\N	27157	\N
98011	GENERIC_DAY	15	0	f	2010-06-14	4344	\N	27157	\N
98012	GENERIC_DAY	15	0	f	2010-06-15	1216	\N	27157	\N
98013	GENERIC_DAY	15	0	f	2010-06-17	4350	\N	27157	\N
98014	GENERIC_DAY	15	0	f	2010-06-17	1220	\N	27157	\N
98015	GENERIC_DAY	15	0	f	2010-06-21	4344	\N	27157	\N
98016	GENERIC_DAY	15	0	f	2010-06-14	4354	\N	27157	\N
98017	GENERIC_DAY	15	7200	f	2010-06-15	1220	\N	27157	\N
98018	GENERIC_DAY	15	0	f	2010-06-15	4352	\N	27157	\N
98019	GENERIC_DAY	15	0	f	2010-06-16	4352	\N	27157	\N
98020	GENERIC_DAY	15	0	f	2010-06-19	4350	\N	27157	\N
98021	GENERIC_DAY	15	0	f	2010-06-19	1220	\N	27157	\N
98022	GENERIC_DAY	15	0	f	2010-06-18	1216	\N	27157	\N
98023	GENERIC_DAY	15	0	f	2010-06-20	72321	\N	27157	\N
98024	GENERIC_DAY	15	7200	f	2010-06-17	72319	\N	27157	\N
98025	GENERIC_DAY	15	0	f	2010-06-19	72317	\N	27157	\N
98026	GENERIC_DAY	15	7200	f	2010-06-14	1214	\N	27157	\N
98027	GENERIC_DAY	15	0	f	2010-06-15	4344	\N	27157	\N
98028	GENERIC_DAY	15	0	f	2010-06-16	4348	\N	27157	\N
98029	GENERIC_DAY	15	0	f	2010-06-19	4356	\N	27157	\N
98030	GENERIC_DAY	15	3600	f	2010-06-14	1220	\N	27157	\N
98031	GENERIC_DAY	15	7200	f	2010-06-14	4356	\N	27157	\N
98032	GENERIC_DAY	15	0	f	2010-06-21	4354	\N	27157	\N
98033	GENERIC_DAY	15	0	f	2010-06-19	1216	\N	27157	\N
98034	GENERIC_DAY	15	0	f	2010-06-17	4352	\N	27157	\N
98035	GENERIC_DAY	15	0	f	2010-06-21	4350	\N	27157	\N
98036	GENERIC_DAY	15	0	f	2010-06-21	1216	\N	27157	\N
98037	GENERIC_DAY	15	10800	f	2010-06-15	4356	\N	27157	\N
98038	GENERIC_DAY	15	0	f	2010-06-14	4350	\N	27157	\N
98039	GENERIC_DAY	15	0	f	2010-06-18	4354	\N	27157	\N
98040	GENERIC_DAY	15	0	f	2010-06-14	4348	\N	27157	\N
98041	GENERIC_DAY	15	0	f	2010-06-16	4354	\N	27157	\N
98042	GENERIC_DAY	15	0	f	2010-06-20	1214	\N	27157	\N
98043	GENERIC_DAY	15	0	f	2010-06-14	4358	\N	27157	\N
98044	GENERIC_DAY	15	0	f	2010-06-19	4348	\N	27157	\N
98045	GENERIC_DAY	15	0	f	2010-06-20	4350	\N	27157	\N
98046	GENERIC_DAY	15	7200	f	2010-06-16	72319	\N	27157	\N
98047	GENERIC_DAY	15	10800	f	2010-06-18	72321	\N	27157	\N
98048	GENERIC_DAY	15	0	f	2010-06-16	4344	\N	27157	\N
98049	GENERIC_DAY	15	0	f	2010-06-19	21817	\N	27157	\N
98050	GENERIC_DAY	15	0	f	2010-06-20	72319	\N	27157	\N
98051	GENERIC_DAY	15	10800	f	2010-06-21	72317	\N	27157	\N
98052	GENERIC_DAY	15	0	f	2010-06-15	4358	\N	27157	\N
98053	GENERIC_DAY	15	0	f	2010-06-17	4348	\N	27157	\N
98054	GENERIC_DAY	15	10800	f	2010-06-17	72317	\N	27157	\N
98055	GENERIC_DAY	15	0	f	2010-06-18	4350	\N	27157	\N
98056	GENERIC_DAY	15	0	f	2010-06-15	4348	\N	27157	\N
98057	GENERIC_DAY	15	7200	f	2010-06-21	72319	\N	27157	\N
98058	GENERIC_DAY	15	10800	f	2010-06-16	72321	\N	27157	\N
98059	GENERIC_DAY	15	0	f	2010-06-21	1214	\N	27157	\N
98060	GENERIC_DAY	15	0	f	2010-06-18	4352	\N	27157	\N
98061	GENERIC_DAY	15	0	f	2010-06-18	1214	\N	27157	\N
98062	GENERIC_DAY	15	0	f	2010-06-14	4352	\N	27157	\N
98063	GENERIC_DAY	15	0	f	2010-06-17	4344	\N	27157	\N
98064	GENERIC_DAY	15	0	f	2010-06-16	1220	\N	27157	\N
98065	GENERIC_DAY	15	0	f	2010-06-20	4354	\N	27157	\N
98066	GENERIC_DAY	15	0	f	2010-06-21	4352	\N	27157	\N
98067	GENERIC_DAY	15	10800	f	2010-06-14	21817	\N	27157	\N
98068	GENERIC_DAY	15	0	f	2010-06-20	4356	\N	27157	\N
98069	GENERIC_DAY	15	0	f	2010-06-19	4352	\N	27157	\N
98070	GENERIC_DAY	15	0	f	2010-06-19	4344	\N	27157	\N
98071	GENERIC_DAY	15	0	f	2010-06-18	4348	\N	27157	\N
98072	GENERIC_DAY	15	0	f	2010-06-17	1214	\N	27157	\N
98073	GENERIC_DAY	15	0	f	2010-06-21	4348	\N	27157	\N
98074	GENERIC_DAY	15	0	f	2010-06-21	21817	\N	27157	\N
98075	GENERIC_DAY	15	0	f	2010-06-17	4354	\N	27157	\N
98076	GENERIC_DAY	15	0	f	2010-06-16	1214	\N	27157	\N
98077	GENERIC_DAY	15	0	f	2010-06-19	72321	\N	27157	\N
98078	GENERIC_DAY	15	0	f	2010-06-14	1216	\N	27157	\N
98079	GENERIC_DAY	15	0	f	2010-06-21	4356	\N	27157	\N
98080	GENERIC_DAY	15	0	f	2010-06-20	4344	\N	27157	\N
98081	GENERIC_DAY	15	0	f	2010-06-18	21817	\N	27157	\N
98082	GENERIC_DAY	15	10800	f	2010-06-16	72317	\N	27157	\N
98083	GENERIC_DAY	15	0	f	2010-06-19	72319	\N	27157	\N
98084	GENERIC_DAY	15	0	f	2010-06-16	21817	\N	27157	\N
98085	GENERIC_DAY	15	0	f	2010-06-21	1220	\N	27157	\N
98086	GENERIC_DAY	15	0	f	2010-06-20	21817	\N	27157	\N
98087	GENERIC_DAY	15	0	f	2010-06-17	1216	\N	27157	\N
98088	GENERIC_DAY	15	10800	f	2010-06-15	1214	\N	27157	\N
98610	SPECIFIC_DAY	15	28800	f	2010-06-16	4348	31228	\N	\N
98611	SPECIFIC_DAY	15	28800	f	2010-06-17	4348	31228	\N	\N
98612	SPECIFIC_DAY	15	14400	f	2010-06-22	4348	31228	\N	\N
98613	SPECIFIC_DAY	15	28800	f	2010-06-15	4348	31228	\N	\N
98614	SPECIFIC_DAY	15	0	f	2010-06-19	4348	31228	\N	\N
98615	SPECIFIC_DAY	15	28800	f	2010-06-21	4348	31228	\N	\N
98616	SPECIFIC_DAY	15	28800	f	2010-06-18	4348	31228	\N	\N
98617	SPECIFIC_DAY	15	0	f	2010-06-20	4348	31228	\N	\N
98618	SPECIFIC_DAY	15	28800	f	2010-06-14	4348	31228	\N	\N
98619	SPECIFIC_DAY	15	0	f	2010-09-19	1220	31230	\N	\N
98620	SPECIFIC_DAY	15	28800	f	2010-09-21	1220	31230	\N	\N
98621	SPECIFIC_DAY	15	28800	f	2010-09-13	1220	31230	\N	\N
98622	SPECIFIC_DAY	15	14400	f	2010-09-10	1220	31230	\N	\N
98623	SPECIFIC_DAY	15	28800	f	2010-09-23	1220	31230	\N	\N
98624	SPECIFIC_DAY	15	28800	f	2010-09-22	1220	31230	\N	\N
98625	SPECIFIC_DAY	15	0	f	2010-09-11	1220	31230	\N	\N
98626	SPECIFIC_DAY	15	0	f	2010-09-12	1220	31230	\N	\N
98627	SPECIFIC_DAY	15	0	f	2010-09-25	1220	31230	\N	\N
98628	SPECIFIC_DAY	15	0	f	2010-09-18	1220	31230	\N	\N
98629	SPECIFIC_DAY	15	28800	f	2010-09-14	1220	31230	\N	\N
98630	SPECIFIC_DAY	15	0	f	2010-09-26	1220	31230	\N	\N
98631	SPECIFIC_DAY	15	28800	f	2010-09-20	1220	31230	\N	\N
98632	SPECIFIC_DAY	15	28800	f	2010-09-28	1220	31230	\N	\N
98633	SPECIFIC_DAY	15	28800	f	2010-09-15	1220	31230	\N	\N
98634	SPECIFIC_DAY	15	28800	f	2010-09-17	1220	31230	\N	\N
98635	SPECIFIC_DAY	15	28800	f	2010-09-27	1220	31230	\N	\N
98636	SPECIFIC_DAY	15	28800	f	2010-09-16	1220	31230	\N	\N
98637	SPECIFIC_DAY	15	28800	f	2010-09-24	1220	31230	\N	\N
98638	GENERIC_DAY	15	0	f	2010-09-19	1216	\N	53631	\N
98639	GENERIC_DAY	15	28800	f	2010-09-02	1216	\N	53631	\N
98640	GENERIC_DAY	15	28800	f	2010-10-12	1216	\N	53631	\N
98641	GENERIC_DAY	15	0	f	2010-09-05	1216	\N	53631	\N
98642	GENERIC_DAY	15	28800	f	2010-09-24	1216	\N	53631	\N
98643	GENERIC_DAY	15	28800	f	2010-09-09	1216	\N	53631	\N
98644	GENERIC_DAY	15	28800	f	2010-09-14	1216	\N	53631	\N
98645	GENERIC_DAY	15	0	f	2010-08-29	1216	\N	53631	\N
98646	GENERIC_DAY	15	28800	f	2010-09-22	1216	\N	53631	\N
98647	GENERIC_DAY	15	28800	f	2010-09-08	1216	\N	53631	\N
98648	GENERIC_DAY	15	28800	f	2010-08-26	1216	\N	53631	\N
98649	GENERIC_DAY	15	28800	f	2010-09-13	1216	\N	53631	\N
98650	GENERIC_DAY	15	28800	f	2010-10-07	1216	\N	53631	\N
98651	GENERIC_DAY	15	28800	f	2010-09-06	1216	\N	53631	\N
98652	GENERIC_DAY	15	0	f	2010-10-09	1216	\N	53631	\N
98653	GENERIC_DAY	15	28800	f	2010-09-27	1216	\N	53631	\N
98654	GENERIC_DAY	15	0	f	2010-09-25	1216	\N	53631	\N
98655	GENERIC_DAY	15	28800	f	2010-09-17	1216	\N	53631	\N
98656	GENERIC_DAY	15	0	f	2010-10-03	1216	\N	53631	\N
98657	GENERIC_DAY	15	0	f	2010-09-12	1216	\N	53631	\N
98658	GENERIC_DAY	15	28800	f	2010-09-16	1216	\N	53631	\N
98659	GENERIC_DAY	15	0	f	2010-09-18	1216	\N	53631	\N
98660	GENERIC_DAY	15	28800	f	2010-09-29	1216	\N	53631	\N
98661	GENERIC_DAY	15	0	f	2010-09-26	1216	\N	53631	\N
98662	GENERIC_DAY	15	0	f	2010-08-23	1216	\N	53631	\N
98663	GENERIC_DAY	15	28800	f	2010-10-05	1216	\N	53631	\N
98664	GENERIC_DAY	15	28800	f	2010-10-04	1216	\N	53631	\N
98665	GENERIC_DAY	15	28800	f	2010-09-21	1216	\N	53631	\N
98666	GENERIC_DAY	15	0	f	2010-10-10	1216	\N	53631	\N
98667	GENERIC_DAY	15	28800	f	2010-08-30	1216	\N	53631	\N
98668	GENERIC_DAY	15	28800	f	2010-08-24	1216	\N	53631	\N
98669	GENERIC_DAY	15	28800	f	2010-09-30	1216	\N	53631	\N
98670	GENERIC_DAY	15	28800	f	2010-09-28	1216	\N	53631	\N
98671	GENERIC_DAY	15	28800	f	2010-10-11	1216	\N	53631	\N
98672	GENERIC_DAY	15	28800	f	2010-08-25	1216	\N	53631	\N
98673	GENERIC_DAY	15	28800	f	2010-09-23	1216	\N	53631	\N
98674	GENERIC_DAY	15	28800	f	2010-08-27	1216	\N	53631	\N
98675	GENERIC_DAY	15	0	f	2010-10-02	1216	\N	53631	\N
98676	GENERIC_DAY	15	0	f	2010-09-11	1216	\N	53631	\N
98677	GENERIC_DAY	15	28800	f	2010-08-31	1216	\N	53631	\N
98678	GENERIC_DAY	15	28800	f	2010-09-07	1216	\N	53631	\N
98679	GENERIC_DAY	15	28800	f	2010-10-13	1216	\N	53631	\N
98680	GENERIC_DAY	15	28800	f	2010-09-15	1216	\N	53631	\N
98681	GENERIC_DAY	15	28800	f	2010-09-10	1216	\N	53631	\N
98682	GENERIC_DAY	15	28800	f	2010-09-01	1216	\N	53631	\N
98683	GENERIC_DAY	15	28800	f	2010-09-03	1216	\N	53631	\N
98684	GENERIC_DAY	15	28800	f	2010-09-20	1216	\N	53631	\N
98685	GENERIC_DAY	15	14400	f	2010-10-14	1216	\N	53631	\N
98686	GENERIC_DAY	15	28800	f	2010-10-06	1216	\N	53631	\N
98687	GENERIC_DAY	15	28800	f	2010-10-08	1216	\N	53631	\N
98688	GENERIC_DAY	15	0	f	2010-08-28	1216	\N	53631	\N
98689	GENERIC_DAY	15	28800	f	2010-10-01	1216	\N	53631	\N
98690	GENERIC_DAY	15	0	f	2010-09-04	1216	\N	53631	\N
98691	GENERIC_DAY	15	28800	f	2011-03-18	1216	\N	83236	\N
98692	GENERIC_DAY	15	28800	f	2011-03-10	1216	\N	83236	\N
98693	GENERIC_DAY	15	28800	f	2011-03-02	1216	\N	83236	\N
98694	GENERIC_DAY	15	28800	f	2011-02-22	1216	\N	83236	\N
98695	GENERIC_DAY	15	28800	f	2011-02-18	1216	\N	83236	\N
98696	GENERIC_DAY	15	28800	f	2011-03-15	1216	\N	83236	\N
98697	GENERIC_DAY	15	28800	f	2011-03-17	1216	\N	83236	\N
98698	GENERIC_DAY	15	28800	f	2011-02-24	1216	\N	83236	\N
98699	GENERIC_DAY	15	28800	f	2011-02-17	1216	\N	83236	\N
98700	GENERIC_DAY	15	28800	f	2011-03-07	1216	\N	83236	\N
98701	GENERIC_DAY	15	28800	f	2011-02-16	1216	\N	83236	\N
98702	GENERIC_DAY	15	28800	f	2011-02-21	1216	\N	83236	\N
98703	GENERIC_DAY	15	28800	f	2011-03-01	1216	\N	83236	\N
98704	GENERIC_DAY	15	28800	f	2011-03-09	1216	\N	83236	\N
98705	GENERIC_DAY	15	28800	f	2011-02-28	1216	\N	83236	\N
98706	GENERIC_DAY	15	28800	f	2011-03-08	1216	\N	83236	\N
98707	GENERIC_DAY	15	28800	f	2011-03-04	1216	\N	83236	\N
98708	GENERIC_DAY	15	28800	f	2011-03-16	1216	\N	83236	\N
98709	GENERIC_DAY	15	28800	f	2011-02-15	1216	\N	83236	\N
98710	GENERIC_DAY	15	28800	f	2011-02-14	1216	\N	83236	\N
98711	GENERIC_DAY	15	28800	f	2011-03-03	1216	\N	83236	\N
98712	GENERIC_DAY	15	28800	f	2011-02-23	1216	\N	83236	\N
98713	GENERIC_DAY	15	0	f	2011-02-11	1216	\N	83236	\N
98714	GENERIC_DAY	15	28800	f	2011-03-11	1216	\N	83236	\N
98715	GENERIC_DAY	15	28800	f	2011-02-25	1216	\N	83236	\N
98716	GENERIC_DAY	15	28800	f	2011-03-14	1216	\N	83236	\N
98717	SPECIFIC_DAY	15	28800	f	2010-07-01	1216	31234	\N	\N
98718	SPECIFIC_DAY	15	28800	f	2010-07-08	1216	31234	\N	\N
98719	SPECIFIC_DAY	15	28800	f	2010-07-16	1216	31234	\N	\N
98720	SPECIFIC_DAY	15	0	f	2010-07-10	1216	31234	\N	\N
98721	SPECIFIC_DAY	15	0	f	2010-07-11	1216	31234	\N	\N
98722	SPECIFIC_DAY	15	0	f	2010-07-04	1216	31234	\N	\N
98723	SPECIFIC_DAY	15	28800	f	2010-07-12	1216	31234	\N	\N
98724	SPECIFIC_DAY	15	14400	f	2010-06-30	1216	31234	\N	\N
98725	SPECIFIC_DAY	15	28800	f	2010-07-06	1216	31234	\N	\N
98726	SPECIFIC_DAY	15	28800	f	2010-07-07	1216	31234	\N	\N
98727	SPECIFIC_DAY	15	28800	f	2010-07-14	1216	31234	\N	\N
98728	SPECIFIC_DAY	15	28800	f	2010-07-13	1216	31234	\N	\N
98729	SPECIFIC_DAY	15	28800	f	2010-07-15	1216	31234	\N	\N
98730	SPECIFIC_DAY	15	3600	f	2010-07-19	1216	31234	\N	\N
98731	SPECIFIC_DAY	15	0	f	2010-07-17	1216	31234	\N	\N
98732	SPECIFIC_DAY	15	28800	f	2010-07-09	1216	31234	\N	\N
98733	SPECIFIC_DAY	15	0	f	2010-07-03	1216	31234	\N	\N
98734	SPECIFIC_DAY	15	0	f	2010-07-18	1216	31234	\N	\N
98735	SPECIFIC_DAY	15	28800	f	2010-07-05	1216	31234	\N	\N
98736	SPECIFIC_DAY	15	28800	f	2010-07-02	1216	31234	\N	\N
98737	SPECIFIC_DAY	15	28800	f	2010-08-10	1216	31231	\N	\N
98738	SPECIFIC_DAY	15	28800	f	2010-08-20	1216	31231	\N	\N
98739	SPECIFIC_DAY	15	28800	f	2010-08-17	1216	31231	\N	\N
98740	SPECIFIC_DAY	15	14400	f	2010-08-05	1216	31231	\N	\N
98741	SPECIFIC_DAY	15	28800	f	2010-08-16	1216	31231	\N	\N
98742	SPECIFIC_DAY	15	28800	f	2010-08-13	1216	31231	\N	\N
98743	SPECIFIC_DAY	15	28800	f	2010-08-06	1216	31231	\N	\N
98744	SPECIFIC_DAY	15	28800	f	2010-08-19	1216	31231	\N	\N
98745	SPECIFIC_DAY	15	28800	f	2010-08-18	1216	31231	\N	\N
98746	SPECIFIC_DAY	15	28800	f	2010-08-09	1216	31231	\N	\N
98747	SPECIFIC_DAY	15	28800	f	2010-08-23	1216	31231	\N	\N
98748	SPECIFIC_DAY	15	28800	f	2010-08-12	1216	31231	\N	\N
98749	SPECIFIC_DAY	15	28800	f	2010-08-11	1216	31231	\N	\N
98750	SPECIFIC_DAY	15	0	f	2010-11-13	1216	31233	\N	\N
98751	SPECIFIC_DAY	15	28800	f	2010-12-15	1216	31233	\N	\N
98752	SPECIFIC_DAY	15	28800	f	2010-11-19	1216	31233	\N	\N
98753	SPECIFIC_DAY	15	14400	f	2010-12-29	1216	31233	\N	\N
98754	SPECIFIC_DAY	15	0	f	2010-12-25	1216	31233	\N	\N
98755	SPECIFIC_DAY	15	28800	f	2010-11-23	1216	31233	\N	\N
98756	SPECIFIC_DAY	15	28800	f	2010-12-28	1216	31233	\N	\N
98757	SPECIFIC_DAY	15	0	f	2010-11-21	1216	31233	\N	\N
98758	SPECIFIC_DAY	15	0	f	2010-11-06	1216	31233	\N	\N
98759	SPECIFIC_DAY	15	28800	f	2010-11-15	1216	31233	\N	\N
98760	SPECIFIC_DAY	15	28800	f	2010-11-18	1216	31233	\N	\N
98761	SPECIFIC_DAY	15	28800	f	2010-11-30	1216	31233	\N	\N
98762	SPECIFIC_DAY	15	28800	f	2010-11-12	1216	31233	\N	\N
98763	SPECIFIC_DAY	15	28800	f	2010-12-06	1216	31233	\N	\N
98764	SPECIFIC_DAY	15	0	f	2010-12-11	1216	31233	\N	\N
98765	SPECIFIC_DAY	15	28800	f	2010-12-13	1216	31233	\N	\N
98766	SPECIFIC_DAY	15	0	f	2010-11-05	1216	31233	\N	\N
98767	SPECIFIC_DAY	15	28800	f	2010-11-24	1216	31233	\N	\N
98768	SPECIFIC_DAY	15	28800	f	2010-12-27	1216	31233	\N	\N
98769	SPECIFIC_DAY	15	28800	f	2010-12-03	1216	31233	\N	\N
98770	SPECIFIC_DAY	15	0	f	2010-12-19	1216	31233	\N	\N
98771	SPECIFIC_DAY	15	0	f	2010-12-18	1216	31233	\N	\N
98772	SPECIFIC_DAY	15	0	f	2010-11-27	1216	31233	\N	\N
98773	SPECIFIC_DAY	15	28800	f	2010-12-02	1216	31233	\N	\N
98774	SPECIFIC_DAY	15	28800	f	2010-12-08	1216	31233	\N	\N
98775	SPECIFIC_DAY	15	28800	f	2010-12-07	1216	31233	\N	\N
98776	SPECIFIC_DAY	15	0	f	2010-11-20	1216	31233	\N	\N
98777	SPECIFIC_DAY	15	28800	f	2010-12-21	1216	31233	\N	\N
98778	SPECIFIC_DAY	15	28800	f	2010-12-09	1216	31233	\N	\N
98779	SPECIFIC_DAY	15	28800	f	2010-11-26	1216	31233	\N	\N
98780	SPECIFIC_DAY	15	0	f	2010-12-26	1216	31233	\N	\N
98781	SPECIFIC_DAY	15	0	f	2010-12-12	1216	31233	\N	\N
98782	SPECIFIC_DAY	15	0	f	2010-12-05	1216	31233	\N	\N
98783	SPECIFIC_DAY	15	28800	f	2010-11-16	1216	31233	\N	\N
98784	SPECIFIC_DAY	15	0	f	2010-11-28	1216	31233	\N	\N
98785	SPECIFIC_DAY	15	28800	f	2010-12-16	1216	31233	\N	\N
98786	SPECIFIC_DAY	15	28800	f	2010-11-17	1216	31233	\N	\N
98787	SPECIFIC_DAY	15	28800	f	2010-11-11	1216	31233	\N	\N
98788	SPECIFIC_DAY	15	28800	f	2010-12-24	1216	31233	\N	\N
98789	SPECIFIC_DAY	15	28800	f	2010-12-14	1216	31233	\N	\N
98790	SPECIFIC_DAY	15	0	f	2010-11-07	1216	31233	\N	\N
98791	SPECIFIC_DAY	15	28800	f	2010-11-08	1216	31233	\N	\N
98792	SPECIFIC_DAY	15	28800	f	2010-11-09	1216	31233	\N	\N
98793	SPECIFIC_DAY	15	28800	f	2010-12-17	1216	31233	\N	\N
98794	SPECIFIC_DAY	15	28800	f	2010-12-01	1216	31233	\N	\N
98795	SPECIFIC_DAY	15	28800	f	2010-12-22	1216	31233	\N	\N
98796	SPECIFIC_DAY	15	28800	f	2010-12-23	1216	31233	\N	\N
98797	SPECIFIC_DAY	15	28800	f	2010-12-20	1216	31233	\N	\N
98798	SPECIFIC_DAY	15	28800	f	2010-11-25	1216	31233	\N	\N
98799	SPECIFIC_DAY	15	28800	f	2010-12-10	1216	31233	\N	\N
98800	SPECIFIC_DAY	15	28800	f	2010-11-22	1216	31233	\N	\N
98801	SPECIFIC_DAY	15	28800	f	2010-11-29	1216	31233	\N	\N
98802	SPECIFIC_DAY	15	0	f	2010-12-04	1216	31233	\N	\N
98803	SPECIFIC_DAY	15	0	f	2010-11-14	1216	31233	\N	\N
98804	SPECIFIC_DAY	15	28800	f	2010-11-10	1216	31233	\N	\N
98805	SPECIFIC_DAY	15	28800	f	2010-07-21	1216	31229	\N	\N
98806	SPECIFIC_DAY	15	28800	f	2010-07-26	1216	31229	\N	\N
98807	SPECIFIC_DAY	15	28800	f	2010-07-23	1216	31229	\N	\N
98808	SPECIFIC_DAY	15	28800	f	2010-08-03	1216	31229	\N	\N
98809	SPECIFIC_DAY	15	28800	f	2010-08-02	1216	31229	\N	\N
98810	SPECIFIC_DAY	15	28800	f	2010-07-20	1216	31229	\N	\N
98811	SPECIFIC_DAY	15	28800	f	2010-07-30	1216	31229	\N	\N
98812	SPECIFIC_DAY	15	28800	f	2010-07-22	1216	31229	\N	\N
98813	SPECIFIC_DAY	15	28800	f	2010-07-29	1216	31229	\N	\N
98814	SPECIFIC_DAY	15	28800	f	2010-08-04	1216	31229	\N	\N
98815	SPECIFIC_DAY	15	14400	f	2010-07-19	1216	31229	\N	\N
98816	SPECIFIC_DAY	15	28800	f	2010-07-28	1216	31229	\N	\N
98817	SPECIFIC_DAY	15	28800	f	2010-07-27	1216	31229	\N	\N
98818	SPECIFIC_DAY	15	28800	f	2011-01-21	1216	31232	\N	\N
98819	SPECIFIC_DAY	15	28800	f	2011-01-14	1216	31232	\N	\N
98820	SPECIFIC_DAY	15	14400	f	2011-01-07	1216	31232	\N	\N
98821	SPECIFIC_DAY	15	28800	f	2011-01-25	1216	31232	\N	\N
98822	SPECIFIC_DAY	15	28800	f	2011-01-18	1216	31232	\N	\N
98823	SPECIFIC_DAY	15	28800	f	2011-01-11	1216	31232	\N	\N
98824	SPECIFIC_DAY	15	28800	f	2011-01-12	1216	31232	\N	\N
98825	SPECIFIC_DAY	15	28800	f	2011-01-13	1216	31232	\N	\N
98826	SPECIFIC_DAY	15	28800	f	2011-01-20	1216	31232	\N	\N
98827	SPECIFIC_DAY	15	28800	f	2011-01-24	1216	31232	\N	\N
98828	SPECIFIC_DAY	15	28800	f	2011-01-17	1216	31232	\N	\N
98829	SPECIFIC_DAY	15	28800	f	2011-01-10	1216	31232	\N	\N
98830	SPECIFIC_DAY	15	28800	f	2011-01-19	1216	31232	\N	\N
98831	GENERIC_DAY	14	14400	f	2010-07-06	4352	\N	27158	\N
98832	GENERIC_DAY	14	0	f	2010-06-26	4352	\N	27158	\N
98833	GENERIC_DAY	14	0	f	2010-08-01	4354	\N	27158	\N
98834	GENERIC_DAY	14	14400	f	2010-07-13	4352	\N	27158	\N
98835	GENERIC_DAY	14	18000	f	2010-07-12	4354	\N	27158	\N
98836	GENERIC_DAY	14	14400	f	2010-07-29	4354	\N	27158	\N
98837	GENERIC_DAY	14	14400	t	2010-06-15	4354	\N	27158	\N
98838	GENERIC_DAY	14	14400	t	2010-06-25	4354	\N	27158	\N
98839	GENERIC_DAY	14	18000	f	2010-07-30	4352	\N	27158	\N
98840	GENERIC_DAY	14	14400	f	2010-07-27	4354	\N	27158	\N
98841	GENERIC_DAY	14	14400	t	2010-06-18	4352	\N	27158	\N
98842	GENERIC_DAY	14	0	f	2010-07-03	4354	\N	27158	\N
98843	GENERIC_DAY	14	0	f	2010-07-04	4352	\N	27158	\N
98844	GENERIC_DAY	14	0	t	2010-06-20	4354	\N	27158	\N
98845	GENERIC_DAY	14	14400	f	2010-07-21	4354	\N	27158	\N
98846	GENERIC_DAY	14	14400	f	2010-08-03	4354	\N	27158	\N
98847	GENERIC_DAY	14	0	f	2010-07-18	4352	\N	27158	\N
98848	GENERIC_DAY	14	18000	f	2010-08-02	4352	\N	27158	\N
98849	GENERIC_DAY	14	14400	t	2010-06-21	4354	\N	27158	\N
98850	GENERIC_DAY	14	0	f	2010-07-10	4352	\N	27158	\N
98851	GENERIC_DAY	14	18000	f	2010-07-14	4354	\N	27158	\N
98852	GENERIC_DAY	14	14400	t	2010-06-25	4352	\N	27158	\N
98853	GENERIC_DAY	14	14400	f	2010-07-01	4352	\N	27158	\N
98854	GENERIC_DAY	14	14400	f	2010-07-14	4352	\N	27158	\N
98855	GENERIC_DAY	14	18000	f	2010-07-16	4354	\N	27158	\N
98856	GENERIC_DAY	14	0	f	2010-06-26	4354	\N	27158	\N
98857	GENERIC_DAY	14	0	f	2010-07-18	4354	\N	27158	\N
98858	GENERIC_DAY	14	18000	f	2010-06-29	4354	\N	27158	\N
98859	GENERIC_DAY	14	0	f	2010-07-24	4354	\N	27158	\N
98860	GENERIC_DAY	14	0	t	2010-06-19	4352	\N	27158	\N
98861	GENERIC_DAY	14	14400	f	2010-07-16	4352	\N	27158	\N
98862	GENERIC_DAY	14	14400	t	2010-06-15	4352	\N	27158	\N
98863	GENERIC_DAY	14	0	f	2010-07-31	4352	\N	27158	\N
98864	GENERIC_DAY	14	14400	t	2010-06-22	4354	\N	27158	\N
98865	GENERIC_DAY	14	18000	f	2010-07-28	4352	\N	27158	\N
98866	GENERIC_DAY	14	7200	f	2010-08-04	4354	\N	27158	\N
98867	GENERIC_DAY	14	18000	f	2010-07-22	4352	\N	27158	\N
98868	GENERIC_DAY	14	14400	t	2010-06-22	4352	\N	27158	\N
98869	GENERIC_DAY	14	0	f	2010-07-25	4354	\N	27158	\N
98870	GENERIC_DAY	14	14400	t	2010-06-17	4354	\N	27158	\N
98871	GENERIC_DAY	14	14400	t	2010-06-23	4354	\N	27158	\N
98872	GENERIC_DAY	14	0	f	2010-07-17	4352	\N	27158	\N
98873	GENERIC_DAY	14	14400	f	2010-08-02	4354	\N	27158	\N
98874	GENERIC_DAY	14	14400	f	2010-07-30	4354	\N	27158	\N
98875	GENERIC_DAY	14	10800	f	2010-08-04	4352	\N	27158	\N
98876	GENERIC_DAY	14	14400	f	2010-07-23	4354	\N	27158	\N
98877	GENERIC_DAY	14	14400	f	2010-07-26	4354	\N	27158	\N
98878	GENERIC_DAY	14	18000	f	2010-07-21	4352	\N	27158	\N
98879	GENERIC_DAY	14	14400	f	2010-06-29	4352	\N	27158	\N
98880	GENERIC_DAY	14	18000	f	2010-07-13	4354	\N	27158	\N
98881	GENERIC_DAY	14	0	t	2010-06-19	4354	\N	27158	\N
98882	GENERIC_DAY	14	0	f	2010-07-03	4352	\N	27158	\N
98883	GENERIC_DAY	14	0	f	2010-07-25	4352	\N	27158	\N
98884	GENERIC_DAY	14	18000	f	2010-07-23	4352	\N	27158	\N
98885	GENERIC_DAY	14	18000	f	2010-07-02	4354	\N	27158	\N
98886	GENERIC_DAY	14	0	f	2010-07-24	4352	\N	27158	\N
98887	GENERIC_DAY	14	18000	f	2010-07-20	4354	\N	27158	\N
98888	GENERIC_DAY	14	14400	f	2010-07-15	4352	\N	27158	\N
98889	GENERIC_DAY	14	14400	t	2010-06-21	4352	\N	27158	\N
98890	GENERIC_DAY	14	18000	f	2010-07-15	4354	\N	27158	\N
98891	GENERIC_DAY	14	0	f	2010-07-10	4354	\N	27158	\N
98892	GENERIC_DAY	14	14400	f	2010-06-30	4352	\N	27158	\N
98893	GENERIC_DAY	14	14400	t	2010-06-16	4352	\N	27158	\N
98894	GENERIC_DAY	14	14400	f	2010-07-20	4352	\N	27158	\N
98895	GENERIC_DAY	14	18000	f	2010-08-03	4352	\N	27158	\N
98896	GENERIC_DAY	14	18000	f	2010-07-05	4354	\N	27158	\N
98897	GENERIC_DAY	14	0	f	2010-07-11	4354	\N	27158	\N
98898	GENERIC_DAY	14	14400	f	2010-07-22	4354	\N	27158	\N
98899	GENERIC_DAY	14	14400	t	2010-06-24	4352	\N	27158	\N
98900	GENERIC_DAY	14	14400	t	2010-06-16	4354	\N	27158	\N
98901	GENERIC_DAY	14	0	f	2010-06-27	4352	\N	27158	\N
98902	GENERIC_DAY	14	0	f	2010-08-01	4352	\N	27158	\N
98903	GENERIC_DAY	14	14400	f	2010-07-07	4352	\N	27158	\N
98904	GENERIC_DAY	14	0	t	2010-06-20	4352	\N	27158	\N
98905	GENERIC_DAY	14	18000	f	2010-06-28	4354	\N	27158	\N
98906	GENERIC_DAY	14	0	f	2010-07-31	4354	\N	27158	\N
98907	GENERIC_DAY	14	14400	t	2010-06-24	4354	\N	27158	\N
98908	GENERIC_DAY	14	0	f	2010-07-17	4354	\N	27158	\N
98909	GENERIC_DAY	14	18000	f	2010-07-08	4354	\N	27158	\N
98910	GENERIC_DAY	14	14400	f	2010-07-12	4352	\N	27158	\N
98911	GENERIC_DAY	14	18000	f	2010-06-30	4354	\N	27158	\N
98912	GENERIC_DAY	14	28800	t	2010-06-14	4354	\N	27158	\N
98913	GENERIC_DAY	14	14400	f	2010-07-05	4352	\N	27158	\N
98914	GENERIC_DAY	14	14400	t	2010-06-18	4354	\N	27158	\N
98915	GENERIC_DAY	14	14400	t	2010-06-23	4352	\N	27158	\N
98916	GENERIC_DAY	14	18000	f	2010-07-19	4354	\N	27158	\N
98917	GENERIC_DAY	14	14400	f	2010-06-28	4352	\N	27158	\N
98918	GENERIC_DAY	14	14400	f	2010-07-02	4352	\N	27158	\N
98919	GENERIC_DAY	14	14400	f	2010-07-08	4352	\N	27158	\N
98920	GENERIC_DAY	14	14400	f	2010-07-28	4354	\N	27158	\N
98921	GENERIC_DAY	14	0	f	2010-07-11	4352	\N	27158	\N
98922	GENERIC_DAY	14	18000	f	2010-07-01	4354	\N	27158	\N
98923	GENERIC_DAY	14	18000	f	2010-07-27	4352	\N	27158	\N
98924	GENERIC_DAY	14	0	f	2010-06-27	4354	\N	27158	\N
98925	GENERIC_DAY	14	18000	f	2010-07-29	4352	\N	27158	\N
98926	GENERIC_DAY	14	18000	f	2010-07-06	4354	\N	27158	\N
98927	GENERIC_DAY	14	14400	f	2010-07-19	4352	\N	27158	\N
98928	GENERIC_DAY	14	18000	f	2010-07-09	4354	\N	27158	\N
98929	GENERIC_DAY	14	0	f	2010-07-04	4354	\N	27158	\N
98930	GENERIC_DAY	14	14400	f	2010-07-09	4352	\N	27158	\N
98931	GENERIC_DAY	14	14400	t	2010-06-17	4352	\N	27158	\N
98932	GENERIC_DAY	14	18000	f	2010-07-26	4352	\N	27158	\N
98933	GENERIC_DAY	14	18000	f	2010-07-07	4354	\N	27158	\N
98934	GENERIC_DAY	13	0	f	2010-07-03	4350	\N	27159	\N
98935	GENERIC_DAY	13	0	f	2010-07-04	21817	\N	27159	\N
98936	GENERIC_DAY	13	10800	f	2010-07-01	21817	\N	27159	\N
98937	GENERIC_DAY	13	0	f	2010-07-01	4344	\N	27159	\N
98938	GENERIC_DAY	13	3600	f	2010-07-08	4348	\N	27159	\N
98939	GENERIC_DAY	13	0	f	2010-06-16	4344	\N	27159	\N
98940	GENERIC_DAY	13	0	f	2010-07-07	4350	\N	27159	\N
98941	GENERIC_DAY	13	0	f	2010-07-04	4350	\N	27159	\N
98942	GENERIC_DAY	13	0	f	2010-07-03	4344	\N	27159	\N
98943	GENERIC_DAY	13	0	f	2010-06-18	4350	\N	27159	\N
98944	GENERIC_DAY	13	0	f	2010-06-21	4344	\N	27159	\N
98945	GENERIC_DAY	13	10800	f	2010-06-23	4348	\N	27159	\N
98946	GENERIC_DAY	13	0	f	2010-07-04	4348	\N	27159	\N
98947	GENERIC_DAY	13	10800	f	2010-06-28	21817	\N	27159	\N
98948	GENERIC_DAY	13	0	f	2010-06-26	4358	\N	27159	\N
98949	GENERIC_DAY	13	7200	f	2010-07-02	21817	\N	27159	\N
98950	GENERIC_DAY	13	7200	f	2010-06-25	21817	\N	27159	\N
98951	GENERIC_DAY	13	0	f	2010-07-05	4350	\N	27159	\N
98952	GENERIC_DAY	13	0	f	2010-06-21	4350	\N	27159	\N
98953	GENERIC_DAY	13	0	f	2010-06-27	4348	\N	27159	\N
98954	GENERIC_DAY	13	0	f	2010-07-04	4358	\N	27159	\N
98955	GENERIC_DAY	13	7200	f	2010-06-29	4358	\N	27159	\N
98956	GENERIC_DAY	13	10800	f	2010-06-28	4348	\N	27159	\N
98957	GENERIC_DAY	13	0	f	2010-06-24	4344	\N	27159	\N
98958	GENERIC_DAY	13	14400	f	2010-06-21	21817	\N	27159	\N
98959	GENERIC_DAY	13	10800	f	2010-07-01	4348	\N	27159	\N
98960	GENERIC_DAY	13	0	f	2010-06-27	21817	\N	27159	\N
98961	GENERIC_DAY	13	0	f	2010-06-26	4348	\N	27159	\N
98962	GENERIC_DAY	13	3600	f	2010-07-02	4350	\N	27159	\N
98963	GENERIC_DAY	13	14400	f	2010-06-14	4358	\N	27159	\N
98964	GENERIC_DAY	13	0	f	2010-06-19	4350	\N	27159	\N
98965	GENERIC_DAY	13	0	f	2010-06-20	4350	\N	27159	\N
98966	GENERIC_DAY	13	0	f	2010-06-20	4358	\N	27159	\N
98967	GENERIC_DAY	13	0	f	2010-06-22	4344	\N	27159	\N
98968	GENERIC_DAY	13	14400	f	2010-06-15	21817	\N	27159	\N
98969	GENERIC_DAY	13	0	f	2010-07-03	4348	\N	27159	\N
98970	GENERIC_DAY	13	0	f	2010-06-25	4350	\N	27159	\N
98971	GENERIC_DAY	13	14400	f	2010-06-16	21817	\N	27159	\N
98972	GENERIC_DAY	13	0	f	2010-06-19	4358	\N	27159	\N
98973	GENERIC_DAY	13	0	f	2010-06-27	4358	\N	27159	\N
98974	GENERIC_DAY	13	0	f	2010-06-17	4348	\N	27159	\N
98975	GENERIC_DAY	13	14400	f	2010-06-21	4358	\N	27159	\N
98976	GENERIC_DAY	13	7200	f	2010-06-30	4358	\N	27159	\N
98977	GENERIC_DAY	13	0	f	2010-06-28	4344	\N	27159	\N
98978	GENERIC_DAY	13	7200	f	2010-07-07	4358	\N	27159	\N
98979	GENERIC_DAY	13	7200	f	2010-07-08	21817	\N	27159	\N
98980	GENERIC_DAY	13	0	f	2010-06-15	4350	\N	27159	\N
98981	GENERIC_DAY	13	0	f	2010-06-19	21817	\N	27159	\N
98982	GENERIC_DAY	13	0	f	2010-06-18	4348	\N	27159	\N
98983	GENERIC_DAY	13	10800	f	2010-06-22	4358	\N	27159	\N
98984	GENERIC_DAY	13	14400	f	2010-06-17	4358	\N	27159	\N
98985	GENERIC_DAY	13	10800	f	2010-06-24	4358	\N	27159	\N
98986	GENERIC_DAY	13	0	f	2010-06-25	4344	\N	27159	\N
98987	GENERIC_DAY	13	7200	f	2010-07-06	4358	\N	27159	\N
98988	GENERIC_DAY	13	0	f	2010-06-22	4350	\N	27159	\N
98989	GENERIC_DAY	13	14400	f	2010-06-18	4358	\N	27159	\N
98990	GENERIC_DAY	13	0	f	2010-07-03	4358	\N	27159	\N
98991	GENERIC_DAY	13	7200	f	2010-07-02	4344	\N	27159	\N
98992	GENERIC_DAY	13	0	f	2010-06-30	4350	\N	27159	\N
98993	GENERIC_DAY	13	0	f	2010-06-29	4344	\N	27159	\N
98994	GENERIC_DAY	13	0	f	2010-06-29	4350	\N	27159	\N
98995	GENERIC_DAY	13	10800	f	2010-06-29	4348	\N	27159	\N
98996	GENERIC_DAY	13	14400	f	2010-06-15	4358	\N	27159	\N
98997	GENERIC_DAY	13	0	f	2010-06-26	4344	\N	27159	\N
98998	GENERIC_DAY	13	0	f	2010-06-16	4350	\N	27159	\N
98999	GENERIC_DAY	13	7200	f	2010-07-05	4358	\N	27159	\N
99000	GENERIC_DAY	13	10800	f	2010-06-25	4348	\N	27159	\N
99001	GENERIC_DAY	13	7200	f	2010-07-01	4358	\N	27159	\N
99002	GENERIC_DAY	13	0	f	2010-07-07	4344	\N	27159	\N
99003	GENERIC_DAY	13	0	f	2010-06-19	4344	\N	27159	\N
99004	GENERIC_DAY	13	0	f	2010-06-28	4350	\N	27159	\N
99005	GENERIC_DAY	13	3600	f	2010-07-02	4348	\N	27159	\N
99006	GENERIC_DAY	13	0	f	2010-07-03	21817	\N	27159	\N
99007	GENERIC_DAY	13	0	f	2010-06-19	4348	\N	27159	\N
99008	GENERIC_DAY	13	7200	f	2010-07-08	4358	\N	27159	\N
99009	GENERIC_DAY	13	14400	f	2010-06-17	21817	\N	27159	\N
99010	GENERIC_DAY	13	7200	f	2010-07-02	4358	\N	27159	\N
99011	GENERIC_DAY	13	0	f	2010-06-15	4344	\N	27159	\N
99012	GENERIC_DAY	13	0	f	2010-06-17	4350	\N	27159	\N
99013	GENERIC_DAY	13	0	f	2010-06-17	4344	\N	27159	\N
99014	GENERIC_DAY	13	0	f	2010-06-20	21817	\N	27159	\N
99015	GENERIC_DAY	13	10800	f	2010-06-29	21817	\N	27159	\N
99016	GENERIC_DAY	13	7200	f	2010-06-24	21817	\N	27159	\N
99017	GENERIC_DAY	13	0	f	2010-07-06	4350	\N	27159	\N
99018	GENERIC_DAY	13	10800	f	2010-06-25	4358	\N	27159	\N
99019	GENERIC_DAY	13	7200	f	2010-06-23	21817	\N	27159	\N
99020	GENERIC_DAY	13	0	f	2010-06-15	4348	\N	27159	\N
99021	GENERIC_DAY	13	0	f	2010-07-01	4350	\N	27159	\N
99022	GENERIC_DAY	13	10800	f	2010-06-22	4348	\N	27159	\N
99023	GENERIC_DAY	13	0	f	2010-07-08	4344	\N	27159	\N
99024	GENERIC_DAY	13	0	f	2010-06-27	4344	\N	27159	\N
99025	GENERIC_DAY	13	10800	f	2010-07-05	4348	\N	27159	\N
99026	GENERIC_DAY	13	10800	f	2010-06-23	4358	\N	27159	\N
99027	GENERIC_DAY	13	14400	f	2010-06-18	21817	\N	27159	\N
99028	GENERIC_DAY	13	10800	f	2010-06-30	4348	\N	27159	\N
99029	GENERIC_DAY	13	0	f	2010-06-23	4344	\N	27159	\N
99030	GENERIC_DAY	13	0	f	2010-06-27	4350	\N	27159	\N
99031	GENERIC_DAY	13	7200	f	2010-06-22	21817	\N	27159	\N
99032	GENERIC_DAY	13	0	f	2010-06-26	21817	\N	27159	\N
99033	GENERIC_DAY	13	0	f	2010-06-20	4344	\N	27159	\N
99034	GENERIC_DAY	13	0	f	2010-06-23	4350	\N	27159	\N
99035	GENERIC_DAY	13	0	f	2010-06-26	4350	\N	27159	\N
99036	GENERIC_DAY	13	0	f	2010-06-20	4348	\N	27159	\N
99037	GENERIC_DAY	13	3600	f	2010-07-05	4344	\N	27159	\N
99038	GENERIC_DAY	13	0	f	2010-06-30	4344	\N	27159	\N
99039	GENERIC_DAY	13	3600	f	2010-07-08	4350	\N	27159	\N
99040	GENERIC_DAY	13	7200	f	2010-06-28	4358	\N	27159	\N
99041	GENERIC_DAY	13	10800	f	2010-07-06	21817	\N	27159	\N
99042	GENERIC_DAY	13	0	f	2010-07-04	4344	\N	27159	\N
99043	GENERIC_DAY	13	7200	f	2010-07-05	21817	\N	27159	\N
99044	GENERIC_DAY	13	0	f	2010-07-06	4344	\N	27159	\N
99045	GENERIC_DAY	13	0	f	2010-06-18	4344	\N	27159	\N
99046	GENERIC_DAY	13	10800	f	2010-06-24	4348	\N	27159	\N
99047	GENERIC_DAY	13	10800	f	2010-07-06	4348	\N	27159	\N
99048	GENERIC_DAY	13	10800	f	2010-06-30	21817	\N	27159	\N
99049	GENERIC_DAY	13	0	f	2010-06-21	4348	\N	27159	\N
99050	GENERIC_DAY	13	10800	f	2010-07-07	21817	\N	27159	\N
99051	GENERIC_DAY	13	0	f	2010-06-16	4348	\N	27159	\N
99052	GENERIC_DAY	13	0	f	2010-06-24	4350	\N	27159	\N
99053	GENERIC_DAY	13	10800	f	2010-07-07	4348	\N	27159	\N
99054	GENERIC_DAY	13	14400	f	2010-06-14	4350	\N	27159	\N
99055	GENERIC_DAY	13	14400	f	2010-06-16	4358	\N	27159	\N
99094	GENERIC_DAY	11	14400	f	2010-08-17	4354	\N	27161	\N
99095	GENERIC_DAY	11	0	f	2010-08-15	4354	\N	27161	\N
99096	GENERIC_DAY	11	14400	f	2010-08-11	4352	\N	27161	\N
99097	GENERIC_DAY	11	0	f	2010-08-29	4352	\N	27161	\N
99098	GENERIC_DAY	11	14400	f	2010-08-27	4352	\N	27161	\N
99099	GENERIC_DAY	11	14400	f	2010-08-05	4354	\N	27161	\N
99100	GENERIC_DAY	11	14400	f	2010-08-09	4354	\N	27161	\N
99101	GENERIC_DAY	11	0	f	2010-08-28	4354	\N	27161	\N
99102	GENERIC_DAY	11	28800	f	2010-08-30	4352	\N	27161	\N
99103	GENERIC_DAY	11	0	f	2010-08-29	4354	\N	27161	\N
99104	GENERIC_DAY	11	14400	f	2010-08-26	4352	\N	27161	\N
99105	GENERIC_DAY	11	14400	f	2010-08-04	4352	\N	27161	\N
99106	GENERIC_DAY	11	0	f	2010-08-21	4354	\N	27161	\N
99107	GENERIC_DAY	11	14400	f	2010-07-28	4354	\N	27161	\N
99108	GENERIC_DAY	11	0	f	2010-08-30	4354	\N	27161	\N
99109	GENERIC_DAY	11	14400	f	2010-08-24	4352	\N	27161	\N
99110	GENERIC_DAY	11	14400	f	2010-08-12	4352	\N	27161	\N
99111	GENERIC_DAY	11	0	f	2010-08-08	4354	\N	27161	\N
99112	GENERIC_DAY	11	28800	f	2010-08-31	4352	\N	27161	\N
99113	GENERIC_DAY	11	0	f	2010-08-07	4354	\N	27161	\N
99114	GENERIC_DAY	11	0	f	2010-08-01	4354	\N	27161	\N
99115	GENERIC_DAY	11	0	f	2010-08-14	4354	\N	27161	\N
99116	GENERIC_DAY	11	14400	f	2010-08-20	4354	\N	27161	\N
99117	GENERIC_DAY	11	14400	f	2010-08-27	4354	\N	27161	\N
99118	GENERIC_DAY	11	0	f	2010-08-15	4352	\N	27161	\N
99119	GENERIC_DAY	11	14400	f	2010-08-19	4354	\N	27161	\N
99120	GENERIC_DAY	11	14400	f	2010-07-30	4354	\N	27161	\N
99121	GENERIC_DAY	11	14400	f	2010-08-09	4352	\N	27161	\N
99122	GENERIC_DAY	11	14400	f	2010-07-28	4352	\N	27161	\N
99123	GENERIC_DAY	11	0	f	2010-08-22	4354	\N	27161	\N
99124	GENERIC_DAY	11	14400	f	2010-08-19	4352	\N	27161	\N
99125	GENERIC_DAY	11	0	f	2010-08-22	4352	\N	27161	\N
99126	GENERIC_DAY	11	14400	f	2010-08-11	4354	\N	27161	\N
99127	GENERIC_DAY	11	14400	f	2010-08-20	4352	\N	27161	\N
99128	GENERIC_DAY	11	14400	f	2010-08-18	4352	\N	27161	\N
99129	GENERIC_DAY	11	14400	f	2010-08-06	4352	\N	27161	\N
99130	GENERIC_DAY	11	14400	f	2010-08-02	4354	\N	27161	\N
99131	GENERIC_DAY	11	0	f	2010-08-08	4352	\N	27161	\N
99132	GENERIC_DAY	11	0	f	2010-08-31	4354	\N	27161	\N
99133	GENERIC_DAY	11	14400	f	2010-08-02	4352	\N	27161	\N
99134	GENERIC_DAY	11	14400	f	2010-08-10	4354	\N	27161	\N
99135	GENERIC_DAY	11	0	f	2010-07-31	4354	\N	27161	\N
99136	GENERIC_DAY	11	0	f	2010-08-14	4352	\N	27161	\N
99137	GENERIC_DAY	11	0	f	2010-08-07	4352	\N	27161	\N
99138	GENERIC_DAY	11	14400	f	2010-08-23	4352	\N	27161	\N
99139	GENERIC_DAY	11	14400	f	2010-08-13	4354	\N	27161	\N
99140	GENERIC_DAY	11	14400	f	2010-07-29	4352	\N	27161	\N
99141	GENERIC_DAY	11	14400	f	2010-08-18	4354	\N	27161	\N
99142	GENERIC_DAY	11	14400	f	2010-08-23	4354	\N	27161	\N
99143	GENERIC_DAY	11	14400	f	2010-08-26	4354	\N	27161	\N
99144	GENERIC_DAY	11	0	f	2010-08-28	4352	\N	27161	\N
99145	GENERIC_DAY	11	14400	f	2010-08-25	4354	\N	27161	\N
99146	GENERIC_DAY	11	14400	f	2010-08-03	4354	\N	27161	\N
99147	GENERIC_DAY	11	14400	f	2010-08-05	4352	\N	27161	\N
99148	GENERIC_DAY	11	0	f	2010-08-21	4352	\N	27161	\N
99149	GENERIC_DAY	11	14400	f	2010-07-29	4354	\N	27161	\N
99150	GENERIC_DAY	11	14400	f	2010-08-24	4354	\N	27161	\N
99151	GENERIC_DAY	11	14400	f	2010-08-16	4352	\N	27161	\N
99152	GENERIC_DAY	11	14400	f	2010-08-16	4354	\N	27161	\N
99153	GENERIC_DAY	11	14400	f	2010-08-17	4352	\N	27161	\N
99154	GENERIC_DAY	11	0	f	2010-07-31	4352	\N	27161	\N
99155	GENERIC_DAY	11	14400	f	2010-08-13	4352	\N	27161	\N
99156	GENERIC_DAY	11	14400	f	2010-08-10	4352	\N	27161	\N
99157	GENERIC_DAY	11	14400	f	2010-08-04	4354	\N	27161	\N
99158	GENERIC_DAY	11	14400	f	2010-08-12	4354	\N	27161	\N
99159	GENERIC_DAY	11	14400	f	2010-08-25	4352	\N	27161	\N
99160	GENERIC_DAY	11	14400	f	2010-08-03	4352	\N	27161	\N
99161	GENERIC_DAY	11	0	f	2010-08-01	4352	\N	27161	\N
99162	GENERIC_DAY	11	14400	f	2010-07-30	4352	\N	27161	\N
99163	GENERIC_DAY	11	14400	f	2010-08-06	4354	\N	27161	\N
99164	GENERIC_DAY	10	7200	f	2010-07-12	4350	\N	27162	\N
99165	GENERIC_DAY	10	7200	f	2010-07-28	4348	\N	27162	\N
99166	GENERIC_DAY	10	7200	f	2010-07-26	4358	\N	27162	\N
99167	GENERIC_DAY	10	0	f	2010-07-14	4344	\N	27162	\N
99168	GENERIC_DAY	10	10800	f	2010-07-06	4348	\N	27162	\N
99169	GENERIC_DAY	10	10800	f	2010-07-15	4358	\N	27162	\N
99170	GENERIC_DAY	10	0	f	2010-07-08	4344	\N	27162	\N
99171	GENERIC_DAY	10	0	f	2010-07-18	4348	\N	27162	\N
99172	GENERIC_DAY	10	7200	f	2010-07-27	4358	\N	27162	\N
99173	GENERIC_DAY	10	0	f	2010-07-24	4344	\N	27162	\N
99174	GENERIC_DAY	10	7200	f	2010-07-22	4350	\N	27162	\N
99175	GENERIC_DAY	10	0	f	2010-07-17	4350	\N	27162	\N
99176	GENERIC_DAY	10	7200	f	2010-07-06	4358	\N	27162	\N
99177	GENERIC_DAY	10	3600	f	2010-07-02	4348	\N	27162	\N
99178	GENERIC_DAY	10	10800	f	2010-07-06	21817	\N	27162	\N
99179	GENERIC_DAY	10	7200	f	2010-07-14	4358	\N	27162	\N
99180	GENERIC_DAY	10	7200	f	2010-07-08	21817	\N	27162	\N
99181	GENERIC_DAY	10	7200	f	2010-07-22	4344	\N	27162	\N
99182	GENERIC_DAY	10	0	f	2010-07-03	21817	\N	27162	\N
99183	GENERIC_DAY	10	7200	f	2010-07-19	4344	\N	27162	\N
99184	GENERIC_DAY	10	0	f	2010-07-11	4358	\N	27162	\N
99185	GENERIC_DAY	10	7200	f	2010-07-23	4348	\N	27162	\N
99186	GENERIC_DAY	10	7200	f	2010-07-05	21817	\N	27162	\N
99187	GENERIC_DAY	10	0	f	2010-07-17	4358	\N	27162	\N
99188	GENERIC_DAY	10	7200	f	2010-07-23	4344	\N	27162	\N
99189	GENERIC_DAY	10	0	f	2010-07-11	4350	\N	27162	\N
99190	GENERIC_DAY	10	7200	f	2010-07-09	4348	\N	27162	\N
99191	GENERIC_DAY	10	0	f	2010-07-17	4344	\N	27162	\N
99192	GENERIC_DAY	10	7200	f	2010-07-20	4344	\N	27162	\N
99193	GENERIC_DAY	10	0	f	2010-07-10	4350	\N	27162	\N
99194	GENERIC_DAY	10	7200	f	2010-07-27	4350	\N	27162	\N
99195	GENERIC_DAY	10	7200	f	2010-07-22	4358	\N	27162	\N
99196	GENERIC_DAY	10	7200	f	2010-07-26	4344	\N	27162	\N
99197	GENERIC_DAY	10	3600	f	2010-07-28	4344	\N	27162	\N
99198	GENERIC_DAY	10	7200	f	2010-07-13	4350	\N	27162	\N
99199	GENERIC_DAY	10	7200	f	2010-07-21	4344	\N	27162	\N
99200	GENERIC_DAY	10	7200	f	2010-07-12	21817	\N	27162	\N
99201	GENERIC_DAY	10	0	f	2010-07-18	4350	\N	27162	\N
99202	GENERIC_DAY	10	7200	f	2010-07-19	4348	\N	27162	\N
99203	GENERIC_DAY	10	7200	f	2010-07-02	4358	\N	27162	\N
99204	GENERIC_DAY	10	0	f	2010-07-25	4358	\N	27162	\N
99205	GENERIC_DAY	10	0	f	2010-07-04	4348	\N	27162	\N
99206	GENERIC_DAY	10	7200	f	2010-07-22	4348	\N	27162	\N
99207	GENERIC_DAY	10	7200	f	2010-07-09	21817	\N	27162	\N
99208	GENERIC_DAY	10	0	f	2010-07-07	4344	\N	27162	\N
99209	GENERIC_DAY	10	0	f	2010-07-24	4348	\N	27162	\N
99210	GENERIC_DAY	10	0	f	2010-07-05	4350	\N	27162	\N
99211	GENERIC_DAY	10	0	f	2010-07-12	4344	\N	27162	\N
99212	GENERIC_DAY	10	0	f	2010-07-06	4350	\N	27162	\N
99213	GENERIC_DAY	10	0	f	2010-07-04	21817	\N	27162	\N
99214	GENERIC_DAY	10	10800	f	2010-07-07	21817	\N	27162	\N
99215	GENERIC_DAY	10	0	f	2010-07-16	4344	\N	27162	\N
99216	GENERIC_DAY	10	7200	f	2010-07-16	4350	\N	27162	\N
99217	GENERIC_DAY	10	0	f	2010-07-11	4348	\N	27162	\N
99218	GENERIC_DAY	10	7200	f	2010-07-09	4350	\N	27162	\N
99219	GENERIC_DAY	10	0	f	2010-07-18	4358	\N	27162	\N
99220	GENERIC_DAY	10	7200	f	2010-07-07	4358	\N	27162	\N
99221	GENERIC_DAY	10	7200	f	2010-07-23	4350	\N	27162	\N
99222	GENERIC_DAY	10	0	f	2010-07-10	4344	\N	27162	\N
99223	GENERIC_DAY	10	7200	f	2010-07-13	21817	\N	27162	\N
99224	GENERIC_DAY	10	0	f	2010-07-04	4358	\N	27162	\N
99225	GENERIC_DAY	10	7200	f	2010-07-27	4344	\N	27162	\N
99226	GENERIC_DAY	10	7200	f	2010-07-08	4358	\N	27162	\N
99227	GENERIC_DAY	10	7200	f	2010-07-26	4348	\N	27162	\N
99228	GENERIC_DAY	10	7200	f	2010-07-02	21817	\N	27162	\N
99229	GENERIC_DAY	10	0	f	2010-07-17	4348	\N	27162	\N
99230	GENERIC_DAY	10	3600	f	2010-07-05	4344	\N	27162	\N
99231	GENERIC_DAY	10	10800	f	2010-07-15	4348	\N	27162	\N
99232	GENERIC_DAY	10	7200	f	2010-07-20	4350	\N	27162	\N
99233	GENERIC_DAY	10	7200	f	2010-07-12	4358	\N	27162	\N
99234	GENERIC_DAY	10	10800	f	2010-07-14	4348	\N	27162	\N
99235	GENERIC_DAY	10	10800	f	2010-07-07	4348	\N	27162	\N
99236	GENERIC_DAY	10	0	f	2010-07-07	4350	\N	27162	\N
99237	GENERIC_DAY	10	0	f	2010-07-09	4344	\N	27162	\N
99238	GENERIC_DAY	10	7200	f	2010-07-05	4358	\N	27162	\N
99239	GENERIC_DAY	10	0	f	2010-07-04	4350	\N	27162	\N
99240	GENERIC_DAY	10	7200	f	2010-07-21	4348	\N	27162	\N
99241	GENERIC_DAY	10	0	f	2010-07-18	4344	\N	27162	\N
99242	GENERIC_DAY	10	0	f	2010-07-24	4358	\N	27162	\N
99243	GENERIC_DAY	10	7200	f	2010-07-20	4348	\N	27162	\N
99244	GENERIC_DAY	10	0	f	2010-07-13	4344	\N	27162	\N
99245	GENERIC_DAY	10	7200	f	2010-07-28	4358	\N	27162	\N
99246	GENERIC_DAY	10	0	f	2010-07-11	4344	\N	27162	\N
99247	GENERIC_DAY	10	0	f	2010-07-25	4348	\N	27162	\N
99248	GENERIC_DAY	10	0	f	2010-07-25	4344	\N	27162	\N
99249	GENERIC_DAY	10	7200	f	2010-07-08	4348	\N	27162	\N
99250	GENERIC_DAY	10	7200	f	2010-07-08	4350	\N	27162	\N
99251	GENERIC_DAY	10	7200	f	2010-07-19	4350	\N	27162	\N
99252	GENERIC_DAY	10	10800	f	2010-07-05	4348	\N	27162	\N
99253	GENERIC_DAY	10	0	f	2010-07-10	4358	\N	27162	\N
99254	GENERIC_DAY	10	10800	f	2010-07-16	4358	\N	27162	\N
99255	GENERIC_DAY	10	7200	f	2010-07-13	4358	\N	27162	\N
99256	GENERIC_DAY	10	3600	f	2010-07-28	4350	\N	27162	\N
99257	GENERIC_DAY	10	7200	f	2010-07-21	4358	\N	27162	\N
99258	GENERIC_DAY	10	0	f	2010-07-06	4344	\N	27162	\N
99259	GENERIC_DAY	10	7200	f	2010-07-02	4344	\N	27162	\N
99260	GENERIC_DAY	10	0	f	2010-07-10	21817	\N	27162	\N
99261	GENERIC_DAY	10	0	f	2010-07-03	4350	\N	27162	\N
99262	GENERIC_DAY	10	0	f	2010-07-04	4344	\N	27162	\N
99263	GENERIC_DAY	10	0	f	2010-07-24	4350	\N	27162	\N
99264	GENERIC_DAY	10	0	f	2010-07-15	4344	\N	27162	\N
99265	GENERIC_DAY	10	0	f	2010-07-03	4344	\N	27162	\N
99266	GENERIC_DAY	10	0	f	2010-07-25	4350	\N	27162	\N
99267	GENERIC_DAY	10	7200	f	2010-07-20	4358	\N	27162	\N
99268	GENERIC_DAY	10	10800	f	2010-07-14	4350	\N	27162	\N
99269	GENERIC_DAY	10	7200	f	2010-07-12	4348	\N	27162	\N
99270	GENERIC_DAY	10	0	f	2010-07-10	4348	\N	27162	\N
99271	GENERIC_DAY	10	7200	f	2010-07-23	4358	\N	27162	\N
99272	GENERIC_DAY	10	7200	f	2010-07-19	4358	\N	27162	\N
99273	GENERIC_DAY	10	0	f	2010-07-03	4348	\N	27162	\N
99274	GENERIC_DAY	10	7200	f	2010-07-09	4358	\N	27162	\N
99275	GENERIC_DAY	10	3600	f	2010-07-02	4350	\N	27162	\N
99276	GENERIC_DAY	10	7200	f	2010-07-13	4348	\N	27162	\N
99277	GENERIC_DAY	10	0	f	2010-07-11	21817	\N	27162	\N
99278	GENERIC_DAY	10	7200	f	2010-07-21	4350	\N	27162	\N
99279	GENERIC_DAY	10	0	f	2010-07-03	4358	\N	27162	\N
99280	GENERIC_DAY	10	10800	f	2010-07-16	4348	\N	27162	\N
99281	GENERIC_DAY	10	7200	f	2010-07-15	4350	\N	27162	\N
99282	GENERIC_DAY	10	7200	f	2010-07-27	4348	\N	27162	\N
99283	GENERIC_DAY	10	7200	f	2010-07-26	4350	\N	27162	\N
99354	SPECIFIC_DAY	9	28800	f	2010-07-29	4352	31239	\N	\N
99355	SPECIFIC_DAY	9	28800	f	2010-07-21	4352	31239	\N	\N
99356	SPECIFIC_DAY	9	28800	f	2010-07-20	4352	31239	\N	\N
99357	SPECIFIC_DAY	9	28800	f	2010-07-19	4352	31239	\N	\N
99358	SPECIFIC_DAY	9	28800	f	2010-07-13	4352	31239	\N	\N
99359	SPECIFIC_DAY	9	28800	f	2010-07-02	4352	31239	\N	\N
99360	SPECIFIC_DAY	9	28800	f	2010-07-23	4352	31239	\N	\N
99361	SPECIFIC_DAY	9	28800	f	2010-07-16	4352	31239	\N	\N
99362	SPECIFIC_DAY	9	28800	f	2010-06-30	4352	31239	\N	\N
99363	SPECIFIC_DAY	9	0	f	2010-07-31	4352	31239	\N	\N
99364	SPECIFIC_DAY	9	0	f	2010-07-25	4352	31239	\N	\N
99365	SPECIFIC_DAY	9	0	f	2010-07-24	4352	31239	\N	\N
99366	SPECIFIC_DAY	9	0	f	2010-07-10	4352	31239	\N	\N
99367	SPECIFIC_DAY	9	0	f	2010-06-27	4352	31239	\N	\N
99368	SPECIFIC_DAY	9	28800	f	2010-07-07	4352	31239	\N	\N
99369	SPECIFIC_DAY	9	28800	f	2010-07-15	4352	31239	\N	\N
99370	SPECIFIC_DAY	9	28800	f	2010-06-14	4352	31239	\N	\N
99371	SPECIFIC_DAY	9	28800	f	2010-07-22	4352	31239	\N	\N
99372	SPECIFIC_DAY	9	0	f	2010-06-13	4352	31239	\N	\N
99373	SPECIFIC_DAY	9	14400	f	2010-08-04	4352	31239	\N	\N
99374	SPECIFIC_DAY	9	28800	f	2010-06-24	4352	31239	\N	\N
99375	SPECIFIC_DAY	9	28800	f	2010-07-08	4352	31239	\N	\N
99376	SPECIFIC_DAY	9	0	f	2010-06-20	4352	31239	\N	\N
99377	SPECIFIC_DAY	9	0	f	2010-06-19	4352	31239	\N	\N
99378	SPECIFIC_DAY	9	28800	f	2010-07-09	4352	31239	\N	\N
99379	SPECIFIC_DAY	9	28800	f	2010-06-18	4352	31239	\N	\N
99380	SPECIFIC_DAY	9	28800	f	2010-08-03	4352	31239	\N	\N
99381	SPECIFIC_DAY	9	28800	f	2010-07-14	4352	31239	\N	\N
99382	SPECIFIC_DAY	9	0	f	2010-07-17	4352	31239	\N	\N
99383	SPECIFIC_DAY	9	0	f	2010-07-04	4352	31239	\N	\N
99384	SPECIFIC_DAY	9	28800	f	2010-07-28	4352	31239	\N	\N
99385	SPECIFIC_DAY	9	0	f	2010-08-01	4352	31239	\N	\N
99386	SPECIFIC_DAY	9	0	f	2010-07-18	4352	31239	\N	\N
99387	SPECIFIC_DAY	9	0	f	2010-07-11	4352	31239	\N	\N
99388	SPECIFIC_DAY	9	28800	f	2010-06-15	4352	31239	\N	\N
99389	SPECIFIC_DAY	9	28800	f	2010-06-21	4352	31239	\N	\N
99390	SPECIFIC_DAY	9	28800	f	2010-06-22	4352	31239	\N	\N
99391	SPECIFIC_DAY	9	28800	f	2010-07-30	4352	31239	\N	\N
99392	SPECIFIC_DAY	9	28800	f	2010-07-26	4352	31239	\N	\N
99393	SPECIFIC_DAY	9	28800	f	2010-08-02	4352	31239	\N	\N
99394	SPECIFIC_DAY	9	28800	f	2010-06-23	4352	31239	\N	\N
99395	SPECIFIC_DAY	9	28800	f	2010-06-25	4352	31239	\N	\N
99396	SPECIFIC_DAY	9	28800	f	2010-06-17	4352	31239	\N	\N
99397	SPECIFIC_DAY	9	28800	f	2010-07-05	4352	31239	\N	\N
99398	SPECIFIC_DAY	9	28800	f	2010-06-28	4352	31239	\N	\N
99399	SPECIFIC_DAY	9	0	f	2010-07-03	4352	31239	\N	\N
99400	SPECIFIC_DAY	9	28800	f	2010-07-06	4352	31239	\N	\N
99401	SPECIFIC_DAY	9	28800	f	2010-07-01	4352	31239	\N	\N
99402	SPECIFIC_DAY	9	0	f	2010-06-26	4352	31239	\N	\N
99403	SPECIFIC_DAY	9	28800	f	2010-07-27	4352	31239	\N	\N
99404	SPECIFIC_DAY	9	28800	f	2010-06-29	4352	31239	\N	\N
99405	SPECIFIC_DAY	9	28800	f	2010-07-12	4352	31239	\N	\N
99406	SPECIFIC_DAY	9	28800	f	2010-06-16	4352	31239	\N	\N
99468	GENERIC_DAY	9	7200	f	2010-08-02	4344	\N	27163	\N
99469	GENERIC_DAY	9	0	f	2010-08-15	4358	\N	27163	\N
99470	GENERIC_DAY	9	0	f	2010-08-28	4350	\N	27163	\N
99471	GENERIC_DAY	9	0	f	2010-08-14	4348	\N	27163	\N
99472	GENERIC_DAY	9	7200	f	2010-08-09	4348	\N	27163	\N
99473	GENERIC_DAY	9	0	f	2010-08-15	4350	\N	27163	\N
99474	GENERIC_DAY	9	7200	f	2010-07-29	4348	\N	27163	\N
99475	GENERIC_DAY	9	7200	f	2010-08-17	4358	\N	27163	\N
99476	GENERIC_DAY	9	0	f	2010-08-08	4348	\N	27163	\N
99477	GENERIC_DAY	9	0	f	2010-08-08	4350	\N	27163	\N
99478	GENERIC_DAY	9	7200	f	2010-09-01	4348	\N	27163	\N
99479	GENERIC_DAY	9	7200	f	2010-08-02	4350	\N	27163	\N
99480	GENERIC_DAY	9	7200	f	2010-08-10	4344	\N	27163	\N
99481	GENERIC_DAY	9	7200	f	2010-08-23	4348	\N	27163	\N
99482	GENERIC_DAY	9	7200	f	2010-08-03	4348	\N	27163	\N
99483	GENERIC_DAY	9	7200	f	2010-08-31	4344	\N	27163	\N
99484	GENERIC_DAY	9	7200	f	2010-08-19	4344	\N	27163	\N
99485	GENERIC_DAY	9	0	f	2010-08-08	4358	\N	27163	\N
99486	GENERIC_DAY	9	7200	f	2010-08-04	4344	\N	27163	\N
99487	GENERIC_DAY	9	7200	f	2010-08-11	4344	\N	27163	\N
99488	GENERIC_DAY	9	7200	f	2010-08-25	4358	\N	27163	\N
99489	GENERIC_DAY	9	7200	f	2010-08-03	4344	\N	27163	\N
99490	GENERIC_DAY	9	7200	f	2010-08-05	4348	\N	27163	\N
99491	GENERIC_DAY	9	7200	f	2010-08-06	4348	\N	27163	\N
99492	GENERIC_DAY	9	7200	f	2010-08-24	4348	\N	27163	\N
99493	GENERIC_DAY	9	7200	f	2010-08-18	4350	\N	27163	\N
99494	GENERIC_DAY	9	0	f	2010-08-14	4350	\N	27163	\N
99495	GENERIC_DAY	9	0	f	2010-08-21	4344	\N	27163	\N
99496	GENERIC_DAY	9	7200	f	2010-08-11	4350	\N	27163	\N
99497	GENERIC_DAY	9	0	f	2010-08-28	4348	\N	27163	\N
99498	GENERIC_DAY	9	7200	f	2010-08-04	4350	\N	27163	\N
99499	GENERIC_DAY	9	7200	f	2010-08-19	4350	\N	27163	\N
99500	GENERIC_DAY	9	7200	f	2010-08-16	4358	\N	27163	\N
99501	GENERIC_DAY	9	0	f	2010-08-21	4358	\N	27163	\N
99502	GENERIC_DAY	9	7200	f	2010-08-19	4358	\N	27163	\N
99503	GENERIC_DAY	9	7200	f	2010-07-29	4350	\N	27163	\N
99504	GENERIC_DAY	9	7200	f	2010-07-30	4350	\N	27163	\N
99505	GENERIC_DAY	9	7200	f	2010-08-19	4348	\N	27163	\N
99506	GENERIC_DAY	9	7200	f	2010-08-09	4358	\N	27163	\N
99507	GENERIC_DAY	9	7200	f	2010-08-06	4350	\N	27163	\N
99508	GENERIC_DAY	9	7200	f	2010-09-01	4344	\N	27163	\N
99509	GENERIC_DAY	9	0	f	2010-08-14	4358	\N	27163	\N
99510	GENERIC_DAY	9	7200	f	2010-08-23	4358	\N	27163	\N
99511	GENERIC_DAY	9	0	f	2010-08-14	4344	\N	27163	\N
99512	GENERIC_DAY	9	7200	f	2010-07-30	4348	\N	27163	\N
99513	GENERIC_DAY	9	0	f	2010-07-31	4348	\N	27163	\N
99514	GENERIC_DAY	9	7200	f	2010-08-27	4350	\N	27163	\N
99515	GENERIC_DAY	9	7200	f	2010-08-31	4358	\N	27163	\N
99516	GENERIC_DAY	9	7200	f	2010-08-04	4348	\N	27163	\N
99517	GENERIC_DAY	9	0	f	2010-08-07	4350	\N	27163	\N
99518	GENERIC_DAY	9	0	f	2010-08-29	4344	\N	27163	\N
99519	GENERIC_DAY	9	0	f	2010-08-07	4344	\N	27163	\N
99520	GENERIC_DAY	9	7200	f	2010-08-10	4358	\N	27163	\N
99521	GENERIC_DAY	9	0	f	2010-08-21	4350	\N	27163	\N
99522	GENERIC_DAY	9	7200	f	2010-08-06	4358	\N	27163	\N
99523	GENERIC_DAY	9	7200	f	2010-08-30	4348	\N	27163	\N
99524	GENERIC_DAY	9	0	f	2010-07-31	4344	\N	27163	\N
99525	GENERIC_DAY	9	7200	f	2010-08-23	4350	\N	27163	\N
99526	GENERIC_DAY	9	7200	f	2010-08-25	4348	\N	27163	\N
99527	GENERIC_DAY	9	0	f	2010-08-29	4358	\N	27163	\N
99528	GENERIC_DAY	9	7200	f	2010-08-30	4350	\N	27163	\N
99529	GENERIC_DAY	9	0	f	2010-08-15	4344	\N	27163	\N
99530	GENERIC_DAY	9	0	f	2010-08-08	4344	\N	27163	\N
99531	GENERIC_DAY	9	0	f	2010-08-22	4348	\N	27163	\N
99532	GENERIC_DAY	9	7200	f	2010-08-24	4344	\N	27163	\N
99533	GENERIC_DAY	9	0	f	2010-08-01	4358	\N	27163	\N
99534	GENERIC_DAY	9	7200	f	2010-08-24	4358	\N	27163	\N
99535	GENERIC_DAY	9	7200	f	2010-08-26	4358	\N	27163	\N
99536	GENERIC_DAY	9	0	f	2010-08-28	4344	\N	27163	\N
99537	GENERIC_DAY	9	7200	f	2010-08-10	4348	\N	27163	\N
99538	GENERIC_DAY	9	7200	f	2010-08-13	4348	\N	27163	\N
99539	GENERIC_DAY	9	7200	f	2010-08-26	4350	\N	27163	\N
99540	GENERIC_DAY	9	7200	f	2010-08-17	4348	\N	27163	\N
99541	GENERIC_DAY	9	7200	f	2010-08-12	4350	\N	27163	\N
99542	GENERIC_DAY	9	7200	f	2010-08-12	4358	\N	27163	\N
99543	GENERIC_DAY	9	7200	f	2010-08-02	4348	\N	27163	\N
99544	GENERIC_DAY	9	7200	f	2010-08-16	4348	\N	27163	\N
99545	GENERIC_DAY	9	7200	f	2010-08-20	4350	\N	27163	\N
99546	GENERIC_DAY	9	0	f	2010-08-21	4348	\N	27163	\N
99547	GENERIC_DAY	9	7200	f	2010-08-12	4344	\N	27163	\N
99548	GENERIC_DAY	9	0	f	2010-07-31	4358	\N	27163	\N
99549	GENERIC_DAY	9	7200	f	2010-08-10	4350	\N	27163	\N
99550	GENERIC_DAY	9	0	f	2010-08-22	4358	\N	27163	\N
99551	GENERIC_DAY	9	7200	f	2010-08-09	4350	\N	27163	\N
99552	GENERIC_DAY	9	7200	f	2010-08-31	4350	\N	27163	\N
99553	GENERIC_DAY	9	7200	f	2010-08-09	4344	\N	27163	\N
99554	GENERIC_DAY	9	0	f	2010-07-31	4350	\N	27163	\N
99555	GENERIC_DAY	9	7200	f	2010-08-20	4348	\N	27163	\N
99556	GENERIC_DAY	9	7200	f	2010-08-18	4348	\N	27163	\N
99557	GENERIC_DAY	9	7200	f	2010-08-25	4350	\N	27163	\N
99558	GENERIC_DAY	9	0	f	2010-08-01	4350	\N	27163	\N
99559	GENERIC_DAY	9	0	f	2010-08-15	4348	\N	27163	\N
99560	GENERIC_DAY	9	0	f	2010-08-22	4344	\N	27163	\N
99561	GENERIC_DAY	9	7200	f	2010-08-16	4350	\N	27163	\N
99562	GENERIC_DAY	9	0	f	2010-08-28	4358	\N	27163	\N
99563	GENERIC_DAY	9	7200	f	2010-08-23	4344	\N	27163	\N
99564	GENERIC_DAY	9	7200	f	2010-07-29	4358	\N	27163	\N
99565	GENERIC_DAY	9	7200	f	2010-08-11	4348	\N	27163	\N
99566	GENERIC_DAY	9	7200	f	2010-09-01	4358	\N	27163	\N
99567	GENERIC_DAY	9	0	f	2010-08-01	4344	\N	27163	\N
99568	GENERIC_DAY	9	0	f	2010-08-07	4358	\N	27163	\N
99569	GENERIC_DAY	9	7200	f	2010-07-30	4344	\N	27163	\N
99570	GENERIC_DAY	9	7200	f	2010-08-06	4344	\N	27163	\N
99571	GENERIC_DAY	9	7200	f	2010-08-30	4344	\N	27163	\N
99572	GENERIC_DAY	9	0	f	2010-08-29	4348	\N	27163	\N
99573	GENERIC_DAY	9	7200	f	2010-08-26	4344	\N	27163	\N
99574	GENERIC_DAY	9	7200	f	2010-08-27	4344	\N	27163	\N
99575	GENERIC_DAY	9	7200	f	2010-08-30	4358	\N	27163	\N
99576	GENERIC_DAY	9	7200	f	2010-08-27	4358	\N	27163	\N
99577	GENERIC_DAY	9	7200	f	2010-08-05	4358	\N	27163	\N
99578	GENERIC_DAY	9	7200	f	2010-08-20	4344	\N	27163	\N
99579	GENERIC_DAY	9	7200	f	2010-08-11	4358	\N	27163	\N
99580	GENERIC_DAY	9	7200	f	2010-08-02	4358	\N	27163	\N
99581	GENERIC_DAY	9	7200	f	2010-07-30	4358	\N	27163	\N
99582	GENERIC_DAY	9	7200	f	2010-08-24	4350	\N	27163	\N
99583	GENERIC_DAY	9	7200	f	2010-08-04	4358	\N	27163	\N
99584	GENERIC_DAY	9	7200	f	2010-08-17	4350	\N	27163	\N
99585	GENERIC_DAY	9	7200	f	2010-07-29	4344	\N	27163	\N
99586	GENERIC_DAY	9	7200	f	2010-09-01	4350	\N	27163	\N
99587	GENERIC_DAY	9	7200	f	2010-08-25	4344	\N	27163	\N
99588	GENERIC_DAY	9	7200	f	2010-08-18	4344	\N	27163	\N
99589	GENERIC_DAY	9	7200	f	2010-08-17	4344	\N	27163	\N
99590	GENERIC_DAY	9	7200	f	2010-08-18	4358	\N	27163	\N
99591	GENERIC_DAY	9	7200	f	2010-08-12	4348	\N	27163	\N
99592	GENERIC_DAY	9	0	f	2010-08-01	4348	\N	27163	\N
99593	GENERIC_DAY	9	7200	f	2010-08-20	4358	\N	27163	\N
99594	GENERIC_DAY	9	7200	f	2010-08-03	4350	\N	27163	\N
99595	GENERIC_DAY	9	7200	f	2010-08-26	4348	\N	27163	\N
99596	GENERIC_DAY	9	0	f	2010-08-07	4348	\N	27163	\N
99597	GENERIC_DAY	9	7200	f	2010-08-27	4348	\N	27163	\N
99598	GENERIC_DAY	9	7200	f	2010-08-03	4358	\N	27163	\N
99599	GENERIC_DAY	9	7200	f	2010-08-13	4358	\N	27163	\N
99600	GENERIC_DAY	9	0	f	2010-08-22	4350	\N	27163	\N
99601	GENERIC_DAY	9	7200	f	2010-08-13	4350	\N	27163	\N
99602	GENERIC_DAY	9	0	f	2010-08-29	4350	\N	27163	\N
99603	GENERIC_DAY	9	7200	f	2010-08-31	4348	\N	27163	\N
99604	GENERIC_DAY	9	7200	f	2010-08-05	4344	\N	27163	\N
99605	GENERIC_DAY	9	7200	f	2010-08-05	4350	\N	27163	\N
99606	GENERIC_DAY	9	7200	f	2010-08-16	4344	\N	27163	\N
99607	GENERIC_DAY	9	7200	f	2010-08-13	4344	\N	27163	\N
99715	GENERIC_DAY	9	28800	f	2010-09-07	1220	\N	73033	\N
99716	GENERIC_DAY	9	28800	f	2010-08-25	1220	\N	73033	\N
99717	GENERIC_DAY	9	28800	f	2010-08-24	1220	\N	73033	\N
99718	GENERIC_DAY	9	14400	f	2010-09-08	1220	\N	73033	\N
99719	GENERIC_DAY	9	28800	f	2010-08-31	1220	\N	73033	\N
99720	GENERIC_DAY	9	0	f	2010-08-29	1220	\N	73033	\N
99721	GENERIC_DAY	9	28800	f	2010-09-06	1220	\N	73033	\N
99722	GENERIC_DAY	9	28800	f	2010-09-01	1220	\N	73033	\N
99723	GENERIC_DAY	9	28800	f	2010-09-03	1220	\N	73033	\N
99724	GENERIC_DAY	9	0	f	2010-08-20	1220	\N	73033	\N
99725	GENERIC_DAY	9	0	f	2010-08-28	1220	\N	73033	\N
99726	GENERIC_DAY	9	28800	f	2010-08-30	1220	\N	73033	\N
99727	GENERIC_DAY	9	0	f	2010-08-21	1220	\N	73033	\N
99728	GENERIC_DAY	9	28800	f	2010-08-23	1220	\N	73033	\N
99729	GENERIC_DAY	9	28800	f	2010-08-27	1220	\N	73033	\N
99730	GENERIC_DAY	9	0	f	2010-09-04	1220	\N	73033	\N
99731	GENERIC_DAY	9	0	f	2010-09-05	1220	\N	73033	\N
99732	GENERIC_DAY	9	0	f	2010-08-22	1220	\N	73033	\N
99733	GENERIC_DAY	9	28800	f	2010-09-02	1220	\N	73033	\N
99734	GENERIC_DAY	9	28800	f	2010-08-26	1220	\N	73033	\N
99735	SPECIFIC_DAY	9	28800	f	2010-07-02	1220	31236	\N	\N
99736	SPECIFIC_DAY	9	28800	f	2010-07-05	1220	31236	\N	\N
99737	SPECIFIC_DAY	9	28800	f	2010-07-14	1220	31236	\N	\N
99738	SPECIFIC_DAY	9	0	f	2010-07-04	1220	31236	\N	\N
99739	SPECIFIC_DAY	9	28800	f	2010-07-07	1220	31236	\N	\N
99740	SPECIFIC_DAY	9	0	f	2010-07-03	1220	31236	\N	\N
99741	SPECIFIC_DAY	9	0	f	2010-07-10	1220	31236	\N	\N
99742	SPECIFIC_DAY	9	28800	f	2010-07-09	1220	31236	\N	\N
99743	SPECIFIC_DAY	9	28800	f	2010-07-13	1220	31236	\N	\N
99744	SPECIFIC_DAY	9	14400	f	2010-06-30	1220	31236	\N	\N
99745	SPECIFIC_DAY	9	28800	f	2010-07-16	1220	31236	\N	\N
99746	SPECIFIC_DAY	9	28800	f	2010-07-06	1220	31236	\N	\N
99747	SPECIFIC_DAY	9	28800	f	2010-07-12	1220	31236	\N	\N
99748	SPECIFIC_DAY	9	28800	f	2010-07-15	1220	31236	\N	\N
99749	SPECIFIC_DAY	9	28800	f	2010-07-08	1220	31236	\N	\N
99750	SPECIFIC_DAY	9	28800	f	2010-07-01	1220	31236	\N	\N
99751	SPECIFIC_DAY	9	0	f	2010-07-11	1220	31236	\N	\N
99752	SPECIFIC_DAY	9	28800	f	2010-07-22	1220	31237	\N	\N
99753	SPECIFIC_DAY	9	0	f	2010-07-25	1220	31237	\N	\N
99754	SPECIFIC_DAY	9	28800	f	2010-07-27	1220	31237	\N	\N
99755	SPECIFIC_DAY	9	0	f	2010-07-17	1220	31237	\N	\N
99756	SPECIFIC_DAY	9	0	f	2010-07-16	1220	31237	\N	\N
99757	SPECIFIC_DAY	9	28800	f	2010-08-03	1220	31237	\N	\N
99758	SPECIFIC_DAY	9	28800	f	2010-07-20	1220	31237	\N	\N
99759	SPECIFIC_DAY	9	0	f	2010-07-31	1220	31237	\N	\N
99760	SPECIFIC_DAY	9	28800	f	2010-07-21	1220	31237	\N	\N
99761	SPECIFIC_DAY	9	28800	f	2010-07-30	1220	31237	\N	\N
99762	SPECIFIC_DAY	9	28800	f	2010-07-29	1220	31237	\N	\N
99763	SPECIFIC_DAY	9	28800	f	2010-07-19	1220	31237	\N	\N
99764	SPECIFIC_DAY	9	28800	f	2010-07-28	1220	31237	\N	\N
99765	SPECIFIC_DAY	9	0	f	2010-07-24	1220	31237	\N	\N
99766	SPECIFIC_DAY	9	28800	f	2010-08-02	1220	31237	\N	\N
99767	SPECIFIC_DAY	9	14400	f	2010-08-04	1220	31237	\N	\N
99768	SPECIFIC_DAY	9	28800	f	2010-07-23	1220	31237	\N	\N
99769	SPECIFIC_DAY	9	0	f	2010-07-18	1220	31237	\N	\N
99770	SPECIFIC_DAY	9	28800	f	2010-07-26	1220	31237	\N	\N
99771	SPECIFIC_DAY	9	0	f	2010-08-01	1220	31237	\N	\N
99772	SPECIFIC_DAY	9	28800	f	2011-02-04	1216	31238	\N	\N
99773	SPECIFIC_DAY	9	28800	f	2011-02-10	1216	31238	\N	\N
99774	SPECIFIC_DAY	9	28800	f	2011-02-02	1216	31238	\N	\N
99775	SPECIFIC_DAY	9	14400	f	2011-01-26	1216	31238	\N	\N
99776	SPECIFIC_DAY	9	28800	f	2011-02-03	1216	31238	\N	\N
99777	SPECIFIC_DAY	9	28800	f	2011-02-09	1216	31238	\N	\N
99778	SPECIFIC_DAY	9	28800	f	2011-01-31	1216	31238	\N	\N
99779	SPECIFIC_DAY	9	28800	f	2011-02-01	1216	31238	\N	\N
99780	SPECIFIC_DAY	9	28800	f	2011-01-28	1216	31238	\N	\N
99781	SPECIFIC_DAY	9	28800	f	2011-02-07	1216	31238	\N	\N
99782	SPECIFIC_DAY	9	28800	f	2011-02-11	1216	31238	\N	\N
99783	SPECIFIC_DAY	9	28800	f	2011-01-27	1216	31238	\N	\N
99784	SPECIFIC_DAY	9	28800	f	2011-02-08	1216	31238	\N	\N
99785	SPECIFIC_DAY	9	0	f	2010-06-26	1216	31235	\N	\N
99786	SPECIFIC_DAY	9	28800	f	2010-06-28	1216	31235	\N	\N
99787	SPECIFIC_DAY	9	28800	f	2010-06-23	1216	31235	\N	\N
99788	SPECIFIC_DAY	9	28800	f	2010-06-29	1216	31235	\N	\N
99789	SPECIFIC_DAY	9	28800	f	2010-06-17	1216	31235	\N	\N
99790	SPECIFIC_DAY	9	28800	f	2010-06-14	1216	31235	\N	\N
99791	SPECIFIC_DAY	9	14400	f	2010-06-30	1216	31235	\N	\N
99792	SPECIFIC_DAY	9	0	f	2010-06-19	1216	31235	\N	\N
99793	SPECIFIC_DAY	9	0	f	2010-06-20	1216	31235	\N	\N
99794	SPECIFIC_DAY	9	28800	f	2010-06-22	1216	31235	\N	\N
99795	SPECIFIC_DAY	9	28800	f	2010-06-25	1216	31235	\N	\N
99796	SPECIFIC_DAY	9	28800	f	2010-06-16	1216	31235	\N	\N
99797	SPECIFIC_DAY	9	28800	f	2010-06-15	1216	31235	\N	\N
99798	SPECIFIC_DAY	9	0	f	2010-06-27	1216	31235	\N	\N
99799	SPECIFIC_DAY	9	28800	f	2010-06-21	1216	31235	\N	\N
99800	SPECIFIC_DAY	9	28800	f	2010-06-18	1216	31235	\N	\N
99801	SPECIFIC_DAY	9	0	f	2010-06-13	1216	31235	\N	\N
99802	SPECIFIC_DAY	9	28800	f	2010-06-24	1216	31235	\N	\N
99803	GENERIC_DAY	8	0	f	2010-07-04	4348	\N	27164	\N
99804	GENERIC_DAY	8	0	f	2010-07-03	4350	\N	27164	\N
99805	GENERIC_DAY	8	7200	f	2010-06-30	4358	\N	27164	\N
99806	GENERIC_DAY	8	10800	f	2010-06-30	21817	\N	27164	\N
99807	GENERIC_DAY	8	14400	f	2010-06-21	21817	\N	27164	\N
99808	GENERIC_DAY	8	14400	f	2010-06-21	4358	\N	27164	\N
99809	GENERIC_DAY	8	0	f	2010-07-05	4350	\N	27164	\N
99810	GENERIC_DAY	8	0	f	2010-06-19	21817	\N	27164	\N
99811	GENERIC_DAY	8	0	f	2010-07-04	4344	\N	27164	\N
99812	GENERIC_DAY	8	18000	t	2010-06-16	21817	\N	27164	\N
99813	GENERIC_DAY	8	0	f	2010-07-04	21817	\N	27164	\N
99814	GENERIC_DAY	8	14400	f	2010-06-17	21817	\N	27164	\N
99815	GENERIC_DAY	8	0	f	2010-06-24	4350	\N	27164	\N
99816	GENERIC_DAY	8	0	f	2010-07-06	4344	\N	27164	\N
99817	GENERIC_DAY	8	3600	f	2010-07-08	4358	\N	27164	\N
99818	GENERIC_DAY	8	0	f	2010-06-20	4348	\N	27164	\N
99819	GENERIC_DAY	8	0	f	2010-06-20	4350	\N	27164	\N
99820	GENERIC_DAY	8	28800	t	2010-06-14	4358	\N	27164	\N
99821	GENERIC_DAY	8	0	f	2010-06-29	4350	\N	27164	\N
99822	GENERIC_DAY	8	10800	f	2010-06-25	4348	\N	27164	\N
99823	GENERIC_DAY	8	0	t	2010-06-15	4348	\N	27164	\N
99824	GENERIC_DAY	8	0	f	2010-07-01	4344	\N	27164	\N
99825	GENERIC_DAY	8	10800	f	2010-07-01	21817	\N	27164	\N
99826	GENERIC_DAY	8	0	f	2010-06-27	4350	\N	27164	\N
99827	GENERIC_DAY	8	0	t	2010-06-14	4350	\N	27164	\N
99828	GENERIC_DAY	8	0	f	2010-06-30	4344	\N	27164	\N
99829	GENERIC_DAY	8	10800	f	2010-06-29	4348	\N	27164	\N
99830	GENERIC_DAY	8	0	f	2010-06-26	4344	\N	27164	\N
99831	GENERIC_DAY	8	7200	f	2010-06-23	21817	\N	27164	\N
99832	GENERIC_DAY	8	0	t	2010-06-16	4348	\N	27164	\N
99833	GENERIC_DAY	8	0	f	2010-06-20	4344	\N	27164	\N
99834	GENERIC_DAY	8	3600	f	2010-07-08	4350	\N	27164	\N
99835	GENERIC_DAY	8	10800	f	2010-06-30	4348	\N	27164	\N
99836	GENERIC_DAY	8	0	f	2010-06-17	4350	\N	27164	\N
99837	GENERIC_DAY	8	10800	f	2010-06-29	21817	\N	27164	\N
99838	GENERIC_DAY	8	7200	f	2010-07-05	4358	\N	27164	\N
99839	GENERIC_DAY	8	0	f	2010-06-22	4350	\N	27164	\N
99840	GENERIC_DAY	8	0	f	2010-06-19	4350	\N	27164	\N
99841	GENERIC_DAY	8	10800	f	2010-06-22	4348	\N	27164	\N
99842	GENERIC_DAY	8	0	f	2010-06-21	4348	\N	27164	\N
99843	GENERIC_DAY	8	0	f	2010-06-24	4344	\N	27164	\N
99844	GENERIC_DAY	8	0	f	2010-07-03	21817	\N	27164	\N
99845	GENERIC_DAY	8	7200	f	2010-07-01	4358	\N	27164	\N
99846	GENERIC_DAY	8	7200	f	2010-06-24	21817	\N	27164	\N
99847	GENERIC_DAY	8	0	t	2010-06-15	4350	\N	27164	\N
99848	GENERIC_DAY	8	0	f	2010-07-06	4350	\N	27164	\N
99849	GENERIC_DAY	8	0	f	2010-06-21	4344	\N	27164	\N
99850	GENERIC_DAY	8	10800	f	2010-06-23	4358	\N	27164	\N
99851	GENERIC_DAY	8	3600	f	2010-07-05	4344	\N	27164	\N
99852	GENERIC_DAY	8	0	f	2010-07-08	4344	\N	27164	\N
99853	GENERIC_DAY	8	0	f	2010-06-26	21817	\N	27164	\N
99854	GENERIC_DAY	8	7200	f	2010-07-06	4358	\N	27164	\N
99855	GENERIC_DAY	8	0	f	2010-06-28	4350	\N	27164	\N
99856	GENERIC_DAY	8	7200	f	2010-07-07	4358	\N	27164	\N
99857	GENERIC_DAY	8	0	f	2010-06-26	4348	\N	27164	\N
99858	GENERIC_DAY	8	10800	f	2010-06-28	4348	\N	27164	\N
99859	GENERIC_DAY	8	10800	f	2010-07-01	4348	\N	27164	\N
99860	GENERIC_DAY	8	0	f	2010-06-21	4350	\N	27164	\N
99861	GENERIC_DAY	8	0	f	2010-06-23	4344	\N	27164	\N
99862	GENERIC_DAY	8	10800	f	2010-07-05	4348	\N	27164	\N
99863	GENERIC_DAY	8	0	t	2010-06-15	4344	\N	27164	\N
99864	GENERIC_DAY	8	0	f	2010-07-04	4350	\N	27164	\N
99865	GENERIC_DAY	8	0	f	2010-07-07	4344	\N	27164	\N
99866	GENERIC_DAY	8	0	f	2010-07-03	4348	\N	27164	\N
99867	GENERIC_DAY	8	10800	f	2010-06-24	4348	\N	27164	\N
99868	GENERIC_DAY	8	0	f	2010-06-20	4358	\N	27164	\N
99869	GENERIC_DAY	8	0	f	2010-06-26	4350	\N	27164	\N
99870	GENERIC_DAY	8	10800	f	2010-06-23	4348	\N	27164	\N
99871	GENERIC_DAY	8	0	f	2010-06-23	4350	\N	27164	\N
99872	GENERIC_DAY	8	0	f	2010-07-03	4344	\N	27164	\N
99873	GENERIC_DAY	8	14400	f	2010-06-18	4358	\N	27164	\N
99874	GENERIC_DAY	8	0	f	2010-06-25	4350	\N	27164	\N
99875	GENERIC_DAY	8	10800	f	2010-06-25	4358	\N	27164	\N
99876	GENERIC_DAY	8	0	f	2010-06-19	4344	\N	27164	\N
99877	GENERIC_DAY	8	0	f	2010-07-07	4350	\N	27164	\N
99878	GENERIC_DAY	8	7200	f	2010-06-28	4358	\N	27164	\N
99879	GENERIC_DAY	8	0	f	2010-06-17	4348	\N	27164	\N
99880	GENERIC_DAY	8	18000	t	2010-06-15	21817	\N	27164	\N
99881	GENERIC_DAY	8	14400	f	2010-06-17	4358	\N	27164	\N
99882	GENERIC_DAY	8	7200	f	2010-06-29	4358	\N	27164	\N
99883	GENERIC_DAY	8	0	f	2010-06-20	21817	\N	27164	\N
99884	GENERIC_DAY	8	0	f	2010-06-25	4344	\N	27164	\N
99885	GENERIC_DAY	8	0	f	2010-06-28	4344	\N	27164	\N
99886	GENERIC_DAY	8	10800	f	2010-07-07	21817	\N	27164	\N
99887	GENERIC_DAY	8	7200	f	2010-07-02	4358	\N	27164	\N
99888	GENERIC_DAY	8	7200	f	2010-07-05	21817	\N	27164	\N
99889	GENERIC_DAY	8	0	f	2010-06-27	4348	\N	27164	\N
99890	GENERIC_DAY	8	7200	f	2010-06-25	21817	\N	27164	\N
99891	GENERIC_DAY	8	0	t	2010-06-16	4344	\N	27164	\N
99892	GENERIC_DAY	8	0	f	2010-06-29	4344	\N	27164	\N
99893	GENERIC_DAY	8	3600	f	2010-07-08	4348	\N	27164	\N
99894	GENERIC_DAY	8	0	t	2010-06-16	4350	\N	27164	\N
99895	GENERIC_DAY	8	10800	f	2010-07-06	4348	\N	27164	\N
99896	GENERIC_DAY	8	10800	f	2010-07-06	21817	\N	27164	\N
99897	GENERIC_DAY	8	10800	f	2010-06-28	21817	\N	27164	\N
99898	GENERIC_DAY	8	0	f	2010-06-19	4348	\N	27164	\N
99899	GENERIC_DAY	8	3600	f	2010-07-08	21817	\N	27164	\N
99900	GENERIC_DAY	8	0	f	2010-06-17	4344	\N	27164	\N
99901	GENERIC_DAY	8	7200	f	2010-07-02	4344	\N	27164	\N
99902	GENERIC_DAY	8	0	f	2010-06-27	21817	\N	27164	\N
99903	GENERIC_DAY	8	14400	f	2010-06-18	21817	\N	27164	\N
99904	GENERIC_DAY	8	3600	f	2010-07-02	4350	\N	27164	\N
99905	GENERIC_DAY	8	0	f	2010-06-30	4350	\N	27164	\N
99906	GENERIC_DAY	8	0	f	2010-06-22	4344	\N	27164	\N
99907	GENERIC_DAY	8	10800	t	2010-06-15	4358	\N	27164	\N
99908	GENERIC_DAY	8	10800	t	2010-06-16	4358	\N	27164	\N
99909	GENERIC_DAY	8	0	f	2010-06-19	4358	\N	27164	\N
99910	GENERIC_DAY	8	0	f	2010-06-18	4348	\N	27164	\N
99911	GENERIC_DAY	8	0	f	2010-07-04	4358	\N	27164	\N
99912	GENERIC_DAY	8	7200	f	2010-07-02	21817	\N	27164	\N
99913	GENERIC_DAY	8	0	f	2010-06-26	4358	\N	27164	\N
99914	GENERIC_DAY	8	0	f	2010-07-01	4350	\N	27164	\N
99915	GENERIC_DAY	8	0	f	2010-06-27	4358	\N	27164	\N
99916	GENERIC_DAY	8	7200	f	2010-06-22	21817	\N	27164	\N
99917	GENERIC_DAY	8	0	f	2010-06-27	4344	\N	27164	\N
99918	GENERIC_DAY	8	10800	f	2010-07-07	4348	\N	27164	\N
99919	GENERIC_DAY	8	0	f	2010-07-03	4358	\N	27164	\N
99920	GENERIC_DAY	8	10800	f	2010-06-24	4358	\N	27164	\N
99921	GENERIC_DAY	8	3600	f	2010-07-02	4348	\N	27164	\N
99922	GENERIC_DAY	8	0	f	2010-06-18	4350	\N	27164	\N
99923	GENERIC_DAY	8	10800	f	2010-06-22	4358	\N	27164	\N
99924	GENERIC_DAY	8	0	f	2010-06-18	4344	\N	27164	\N
99925	GENERIC_DAY	7	0	f	2010-07-17	4354	\N	27165	\N
99926	GENERIC_DAY	7	0	f	2010-07-11	4352	\N	27165	\N
99927	GENERIC_DAY	7	0	f	2010-07-31	4352	\N	27165	\N
99928	GENERIC_DAY	7	14400	f	2010-07-29	4352	\N	27165	\N
99929	GENERIC_DAY	7	14400	f	2010-08-05	4354	\N	27165	\N
99930	GENERIC_DAY	7	0	f	2010-07-10	4352	\N	27165	\N
99931	GENERIC_DAY	7	14400	f	2010-08-09	4354	\N	27165	\N
99932	GENERIC_DAY	7	14400	f	2010-07-13	4354	\N	27165	\N
99933	GENERIC_DAY	7	0	f	2010-07-25	4352	\N	27165	\N
99934	GENERIC_DAY	7	14400	f	2010-07-09	4354	\N	27165	\N
99935	GENERIC_DAY	7	14400	f	2010-07-27	4354	\N	27165	\N
99936	GENERIC_DAY	7	14400	f	2010-08-09	4352	\N	27165	\N
99937	GENERIC_DAY	7	14400	f	2010-07-23	4354	\N	27165	\N
99938	GENERIC_DAY	7	14400	f	2010-07-27	4352	\N	27165	\N
99939	GENERIC_DAY	7	0	f	2010-07-24	4354	\N	27165	\N
99940	GENERIC_DAY	7	0	f	2010-07-17	4352	\N	27165	\N
99941	GENERIC_DAY	7	0	f	2010-07-18	4352	\N	27165	\N
99942	GENERIC_DAY	7	14400	f	2010-08-11	4354	\N	27165	\N
99943	GENERIC_DAY	7	14400	f	2010-08-02	4352	\N	27165	\N
99944	GENERIC_DAY	7	14400	f	2010-07-28	4352	\N	27165	\N
99945	GENERIC_DAY	7	14400	f	2010-07-20	4354	\N	27165	\N
99946	GENERIC_DAY	7	14400	f	2010-07-14	4352	\N	27165	\N
99947	GENERIC_DAY	7	0	f	2010-07-25	4354	\N	27165	\N
99948	GENERIC_DAY	7	0	f	2010-08-07	4352	\N	27165	\N
99949	GENERIC_DAY	7	14400	f	2010-08-10	4352	\N	27165	\N
99950	GENERIC_DAY	7	14400	f	2010-07-15	4352	\N	27165	\N
99951	GENERIC_DAY	7	14400	f	2010-08-04	4354	\N	27165	\N
99952	GENERIC_DAY	7	14400	f	2010-07-19	4354	\N	27165	\N
99953	GENERIC_DAY	7	14400	f	2010-07-21	4354	\N	27165	\N
99954	GENERIC_DAY	7	14400	f	2010-07-16	4352	\N	27165	\N
99955	GENERIC_DAY	7	14400	f	2010-07-14	4354	\N	27165	\N
99956	GENERIC_DAY	7	0	f	2010-07-31	4354	\N	27165	\N
99957	GENERIC_DAY	7	0	f	2010-07-10	4354	\N	27165	\N
99958	GENERIC_DAY	7	0	f	2010-07-18	4354	\N	27165	\N
99959	GENERIC_DAY	7	14400	f	2010-07-20	4352	\N	27165	\N
99960	GENERIC_DAY	7	14400	f	2010-07-22	4354	\N	27165	\N
99961	GENERIC_DAY	7	14400	f	2010-08-12	4352	\N	27165	\N
99962	GENERIC_DAY	7	14400	f	2010-08-05	4352	\N	27165	\N
99963	GENERIC_DAY	7	0	f	2010-08-01	4354	\N	27165	\N
99964	GENERIC_DAY	7	14400	f	2010-07-21	4352	\N	27165	\N
99965	GENERIC_DAY	7	0	f	2010-07-24	4352	\N	27165	\N
99966	GENERIC_DAY	7	14400	f	2010-07-12	4354	\N	27165	\N
99967	GENERIC_DAY	7	14400	f	2010-07-12	4352	\N	27165	\N
99968	GENERIC_DAY	7	14400	f	2010-07-22	4352	\N	27165	\N
99969	GENERIC_DAY	7	14400	f	2010-08-11	4352	\N	27165	\N
99970	GENERIC_DAY	7	14400	f	2010-07-23	4352	\N	27165	\N
99971	GENERIC_DAY	7	14400	f	2010-08-10	4354	\N	27165	\N
99972	GENERIC_DAY	7	14400	f	2010-07-30	4352	\N	27165	\N
99973	GENERIC_DAY	7	14400	f	2010-07-29	4354	\N	27165	\N
99974	GENERIC_DAY	7	14400	f	2010-08-03	4354	\N	27165	\N
99975	GENERIC_DAY	7	0	f	2010-08-07	4354	\N	27165	\N
99976	GENERIC_DAY	7	14400	f	2010-07-13	4352	\N	27165	\N
99977	GENERIC_DAY	7	14400	f	2010-08-03	4352	\N	27165	\N
99978	GENERIC_DAY	7	0	f	2010-08-01	4352	\N	27165	\N
99979	GENERIC_DAY	7	14400	f	2010-08-02	4354	\N	27165	\N
99980	GENERIC_DAY	7	14400	f	2010-07-30	4354	\N	27165	\N
99981	GENERIC_DAY	7	14400	f	2010-07-09	4352	\N	27165	\N
99982	GENERIC_DAY	7	14400	f	2010-07-15	4354	\N	27165	\N
99983	GENERIC_DAY	7	14400	f	2010-08-06	4352	\N	27165	\N
99984	GENERIC_DAY	7	0	f	2010-08-08	4352	\N	27165	\N
99985	GENERIC_DAY	7	14400	f	2010-07-26	4354	\N	27165	\N
99986	GENERIC_DAY	7	14400	f	2010-08-06	4354	\N	27165	\N
99987	GENERIC_DAY	7	14400	f	2010-07-28	4354	\N	27165	\N
99988	GENERIC_DAY	7	14400	f	2010-07-16	4354	\N	27165	\N
99989	GENERIC_DAY	7	14400	f	2010-07-19	4352	\N	27165	\N
99990	GENERIC_DAY	7	14400	f	2010-08-12	4354	\N	27165	\N
99991	GENERIC_DAY	7	14400	f	2010-07-26	4352	\N	27165	\N
99992	GENERIC_DAY	7	14400	f	2010-08-04	4352	\N	27165	\N
99993	GENERIC_DAY	7	0	f	2010-07-11	4354	\N	27165	\N
99994	GENERIC_DAY	7	0	f	2010-08-08	4354	\N	27165	\N
100169	GENERIC_DAY	6	32400	f	2010-07-02	4354	\N	83237	\N
100170	GENERIC_DAY	6	32400	f	2010-06-22	4354	\N	83237	\N
100171	GENERIC_DAY	6	18000	f	2010-06-26	4352	\N	83237	\N
100172	GENERIC_DAY	6	0	t	2010-06-16	4352	\N	83237	\N
100173	GENERIC_DAY	6	18000	f	2010-07-03	4354	\N	83237	\N
100174	GENERIC_DAY	6	32400	f	2010-06-21	4352	\N	83237	\N
100175	GENERIC_DAY	6	28800	f	2010-07-07	4352	\N	83237	\N
100176	GENERIC_DAY	6	28800	t	2010-06-14	4354	\N	83237	\N
100177	GENERIC_DAY	6	18000	f	2010-06-19	4354	\N	83237	\N
100178	GENERIC_DAY	6	32400	f	2010-07-14	4354	\N	83237	\N
100179	GENERIC_DAY	6	14400	f	2010-07-11	4352	\N	83237	\N
100180	GENERIC_DAY	6	32400	f	2010-07-07	4354	\N	83237	\N
100181	GENERIC_DAY	6	18000	f	2010-07-11	4354	\N	83237	\N
100182	GENERIC_DAY	6	28800	f	2010-07-12	4352	\N	83237	\N
100183	GENERIC_DAY	6	28800	f	2010-06-30	4352	\N	83237	\N
100184	GENERIC_DAY	6	28800	t	2010-06-16	4354	\N	83237	\N
100185	GENERIC_DAY	6	32400	f	2010-06-22	4352	\N	83237	\N
100186	GENERIC_DAY	6	32400	f	2010-07-09	4354	\N	83237	\N
100187	GENERIC_DAY	6	28800	f	2010-07-05	4352	\N	83237	\N
100188	GENERIC_DAY	6	32400	f	2010-07-05	4354	\N	83237	\N
100189	GENERIC_DAY	6	32400	f	2010-07-01	4354	\N	83237	\N
83552	GENERIC_DAY	0	3600	f	2011-02-22	72319	\N	83226	\N
83553	GENERIC_DAY	0	3600	f	2011-02-22	83633	\N	83226	\N
83554	GENERIC_DAY	0	0	f	2011-02-19	83633	\N	83226	\N
83555	GENERIC_DAY	0	0	f	2011-02-20	83633	\N	83226	\N
83556	GENERIC_DAY	0	28800	f	2011-02-17	72317	\N	83226	\N
83557	GENERIC_DAY	0	28800	f	2011-02-21	72317	\N	83226	\N
83558	GENERIC_DAY	0	0	f	2011-02-19	72319	\N	83226	\N
83559	GENERIC_DAY	0	28800	f	2011-02-17	72319	\N	83226	\N
83560	GENERIC_DAY	0	28800	f	2011-02-18	72319	\N	83226	\N
83561	GENERIC_DAY	0	7200	f	2011-02-22	72317	\N	83226	\N
83562	GENERIC_DAY	0	28800	f	2011-02-18	72317	\N	83226	\N
83563	GENERIC_DAY	0	28800	f	2011-02-21	72319	\N	83226	\N
83564	GENERIC_DAY	0	28800	f	2011-02-16	72319	\N	83226	\N
83565	GENERIC_DAY	0	28800	f	2011-02-16	83633	\N	83226	\N
83566	GENERIC_DAY	0	28800	f	2011-02-21	83633	\N	83226	\N
83567	GENERIC_DAY	0	0	f	2011-02-20	72319	\N	83226	\N
83568	GENERIC_DAY	0	28800	f	2011-02-17	83633	\N	83226	\N
83569	GENERIC_DAY	0	0	f	2011-02-19	72317	\N	83226	\N
100190	GENERIC_DAY	6	28800	f	2010-07-01	4352	\N	83237	\N
100191	GENERIC_DAY	6	28800	t	2010-06-15	4354	\N	83237	\N
100192	GENERIC_DAY	6	32400	f	2010-07-08	4354	\N	83237	\N
100193	GENERIC_DAY	6	32400	f	2010-06-28	4352	\N	83237	\N
100194	GENERIC_DAY	6	28800	f	2010-06-29	4352	\N	83237	\N
100195	GENERIC_DAY	6	18000	f	2010-07-04	4354	\N	83237	\N
100196	GENERIC_DAY	6	0	t	2010-06-15	4352	\N	83237	\N
100197	GENERIC_DAY	6	32400	f	2010-06-24	4354	\N	83237	\N
100198	GENERIC_DAY	6	28800	f	2010-07-06	4352	\N	83237	\N
100199	GENERIC_DAY	6	32400	f	2010-06-29	4354	\N	83237	\N
100200	GENERIC_DAY	6	32400	f	2010-06-17	4352	\N	83237	\N
100201	GENERIC_DAY	6	14400	f	2010-07-10	4352	\N	83237	\N
100202	GENERIC_DAY	6	18000	f	2010-06-19	4352	\N	83237	\N
100203	GENERIC_DAY	6	14400	f	2010-07-03	4352	\N	83237	\N
100204	GENERIC_DAY	6	32400	f	2010-07-12	4354	\N	83237	\N
100205	GENERIC_DAY	6	14400	f	2010-07-04	4352	\N	83237	\N
100206	GENERIC_DAY	6	32400	f	2010-06-24	4352	\N	83237	\N
83570	GENERIC_DAY	0	28800	f	2011-02-16	72317	\N	83226	\N
83571	GENERIC_DAY	0	28800	f	2011-02-18	83633	\N	83226	\N
83572	GENERIC_DAY	0	0	f	2011-02-20	72317	\N	83226	\N
83573	GENERIC_DAY	0	28800	f	2011-02-24	72317	\N	83227	\N
83574	GENERIC_DAY	0	0	f	2011-02-26	83633	\N	83227	\N
83575	GENERIC_DAY	0	28800	f	2011-02-28	72319	\N	83227	\N
83576	GENERIC_DAY	0	7200	f	2011-03-01	72317	\N	83227	\N
83577	GENERIC_DAY	0	28800	f	2011-02-23	72319	\N	83227	\N
83578	GENERIC_DAY	0	0	f	2011-02-27	72317	\N	83227	\N
83579	GENERIC_DAY	0	28800	f	2011-02-25	72317	\N	83227	\N
83580	GENERIC_DAY	0	28800	f	2011-02-23	72317	\N	83227	\N
83581	GENERIC_DAY	0	28800	f	2011-02-28	83633	\N	83227	\N
83582	GENERIC_DAY	0	28800	f	2011-02-25	72319	\N	83227	\N
83583	GENERIC_DAY	0	0	f	2011-02-27	72319	\N	83227	\N
83584	GENERIC_DAY	0	28800	f	2011-02-23	83633	\N	83227	\N
83585	GENERIC_DAY	0	3600	f	2011-03-01	72319	\N	83227	\N
83586	GENERIC_DAY	0	0	f	2011-02-27	83633	\N	83227	\N
83587	GENERIC_DAY	0	0	f	2011-02-26	72319	\N	83227	\N
83588	GENERIC_DAY	0	0	f	2011-02-26	72317	\N	83227	\N
83589	GENERIC_DAY	0	28800	f	2011-02-28	72317	\N	83227	\N
83590	GENERIC_DAY	0	28800	f	2011-02-25	83633	\N	83227	\N
83591	GENERIC_DAY	0	28800	f	2011-02-24	83633	\N	83227	\N
83592	GENERIC_DAY	0	28800	f	2011-02-24	72319	\N	83227	\N
83593	GENERIC_DAY	0	3600	f	2011-03-01	83633	\N	83227	\N
83594	GENERIC_DAY	0	0	f	2011-03-06	72317	\N	83229	\N
83595	GENERIC_DAY	0	0	f	2011-03-05	72317	\N	83229	\N
83596	GENERIC_DAY	0	28800	f	2011-03-03	72317	\N	83229	\N
83597	GENERIC_DAY	0	0	f	2011-03-06	83633	\N	83229	\N
83598	GENERIC_DAY	0	0	f	2011-03-06	72319	\N	83229	\N
83599	GENERIC_DAY	0	0	f	2011-03-05	72319	\N	83229	\N
83600	GENERIC_DAY	0	28800	f	2011-03-02	83633	\N	83229	\N
83601	GENERIC_DAY	0	28800	f	2011-03-07	72317	\N	83229	\N
83602	GENERIC_DAY	0	28800	f	2011-03-04	72317	\N	83229	\N
83603	GENERIC_DAY	0	7200	f	2011-03-08	72317	\N	83229	\N
83604	GENERIC_DAY	0	28800	f	2011-03-07	83633	\N	83229	\N
83605	GENERIC_DAY	0	28800	f	2011-03-03	72319	\N	83229	\N
83606	GENERIC_DAY	0	28800	f	2011-03-07	72319	\N	83229	\N
83607	GENERIC_DAY	0	28800	f	2011-03-04	83633	\N	83229	\N
83608	GENERIC_DAY	0	3600	f	2011-03-08	72319	\N	83229	\N
83609	GENERIC_DAY	0	0	f	2011-03-05	83633	\N	83229	\N
83610	GENERIC_DAY	0	28800	f	2011-03-02	72317	\N	83229	\N
83611	GENERIC_DAY	0	3600	f	2011-03-08	83633	\N	83229	\N
83612	GENERIC_DAY	0	28800	f	2011-03-04	72319	\N	83229	\N
83613	GENERIC_DAY	0	28800	f	2011-03-03	83633	\N	83229	\N
83614	GENERIC_DAY	0	28800	f	2011-03-02	72319	\N	83229	\N
100207	GENERIC_DAY	6	18000	f	2010-06-26	4354	\N	83237	\N
100208	GENERIC_DAY	6	18000	f	2010-06-20	4354	\N	83237	\N
100209	GENERIC_DAY	6	32400	f	2010-07-13	4354	\N	83237	\N
100210	GENERIC_DAY	6	32400	f	2010-07-06	4354	\N	83237	\N
100211	GENERIC_DAY	6	18000	f	2010-06-27	4352	\N	83237	\N
100212	GENERIC_DAY	6	18000	f	2010-06-27	4354	\N	83237	\N
100213	GENERIC_DAY	6	18000	f	2010-07-10	4354	\N	83237	\N
100214	GENERIC_DAY	6	32400	f	2010-06-21	4354	\N	83237	\N
100215	GENERIC_DAY	6	32400	f	2010-06-17	4354	\N	83237	\N
100216	GENERIC_DAY	6	28800	f	2010-07-14	4352	\N	83237	\N
100217	GENERIC_DAY	6	28800	f	2010-07-08	4352	\N	83237	\N
100218	GENERIC_DAY	6	32400	f	2010-06-25	4352	\N	83237	\N
100219	GENERIC_DAY	6	18000	f	2010-06-20	4352	\N	83237	\N
100220	GENERIC_DAY	6	32400	f	2010-06-18	4354	\N	83237	\N
100221	GENERIC_DAY	6	32400	f	2010-06-28	4354	\N	83237	\N
100222	GENERIC_DAY	6	32400	f	2010-06-30	4354	\N	83237	\N
100223	GENERIC_DAY	6	32400	f	2010-06-18	4352	\N	83237	\N
100224	GENERIC_DAY	6	32400	f	2010-06-23	4354	\N	83237	\N
100225	GENERIC_DAY	6	32400	f	2010-06-23	4352	\N	83237	\N
100226	GENERIC_DAY	6	28800	f	2010-07-02	4352	\N	83237	\N
100227	GENERIC_DAY	6	28800	f	2010-07-09	4352	\N	83237	\N
100228	GENERIC_DAY	6	32400	f	2010-06-25	4354	\N	83237	\N
100229	GENERIC_DAY	6	28800	f	2010-07-13	4352	\N	83237	\N
100419	SPECIFIC_DAY	6	14400	f	2010-08-04	1220	31240	\N	\N
100420	SPECIFIC_DAY	6	28800	f	2010-08-17	1220	31240	\N	\N
100421	SPECIFIC_DAY	6	28800	f	2010-08-12	1220	31240	\N	\N
100422	SPECIFIC_DAY	6	0	f	2010-08-08	1220	31240	\N	\N
100423	SPECIFIC_DAY	6	28800	f	2010-08-05	1220	31240	\N	\N
100424	SPECIFIC_DAY	6	28800	f	2010-08-18	1220	31240	\N	\N
100425	SPECIFIC_DAY	6	28800	f	2010-08-10	1220	31240	\N	\N
100426	SPECIFIC_DAY	6	28800	f	2010-08-16	1220	31240	\N	\N
100427	SPECIFIC_DAY	6	28800	f	2010-08-11	1220	31240	\N	\N
100428	SPECIFIC_DAY	6	28800	f	2010-08-19	1220	31240	\N	\N
100429	SPECIFIC_DAY	6	28800	f	2010-08-13	1220	31240	\N	\N
100430	SPECIFIC_DAY	6	28800	f	2010-08-20	1220	31240	\N	\N
100431	SPECIFIC_DAY	6	0	f	2010-08-07	1220	31240	\N	\N
75527	GENERIC_DAY	7	0	f	2010-07-27	4352	\N	16802	\N
75512	GENERIC_DAY	7	25200	f	2010-07-09	4354	\N	16802	\N
75552	GENERIC_DAY	7	0	f	2010-08-07	4352	\N	16802	\N
75568	GENERIC_DAY	7	28800	f	2010-08-02	4354	\N	16802	\N
75543	GENERIC_DAY	7	14400	f	2010-08-09	4352	\N	16802	\N
75513	GENERIC_DAY	7	3600	f	2010-07-07	4352	\N	16802	\N
75536	GENERIC_DAY	7	0	f	2010-08-08	4354	\N	16802	\N
75520	GENERIC_DAY	7	0	f	2010-07-17	4354	\N	16802	\N
75540	GENERIC_DAY	7	0	f	2010-07-23	4352	\N	16802	\N
75563	GENERIC_DAY	7	28800	f	2010-07-28	4354	\N	16802	\N
75545	GENERIC_DAY	7	3600	f	2010-07-16	4352	\N	16802	\N
75522	GENERIC_DAY	7	21600	f	2010-08-04	4354	\N	16802	\N
75551	GENERIC_DAY	7	0	f	2010-08-01	4354	\N	16802	\N
75544	GENERIC_DAY	7	0	f	2010-07-31	4354	\N	16802	\N
75509	GENERIC_DAY	7	0	f	2010-07-18	4352	\N	16802	\N
75514	GENERIC_DAY	7	25200	f	2010-07-13	4354	\N	16802	\N
100432	SPECIFIC_DAY	6	0	f	2010-08-14	1220	31240	\N	\N
100433	SPECIFIC_DAY	6	28800	f	2010-08-06	1220	31240	\N	\N
100434	SPECIFIC_DAY	6	0	f	2010-08-15	1220	31240	\N	\N
100435	SPECIFIC_DAY	6	28800	f	2010-08-09	1220	31240	\N	\N
100436	GENERIC_DAY	5	0	f	2010-07-03	4358	\N	27166	\N
100437	GENERIC_DAY	5	10800	f	2010-07-07	4348	\N	27166	\N
100438	GENERIC_DAY	5	7200	f	2010-07-13	4350	\N	27166	\N
100439	GENERIC_DAY	5	3600	f	2010-07-02	4348	\N	27166	\N
100440	GENERIC_DAY	5	7200	f	2010-06-28	4358	\N	27166	\N
100441	GENERIC_DAY	5	0	f	2010-07-04	4350	\N	27166	\N
100442	GENERIC_DAY	5	3600	f	2010-07-02	4350	\N	27166	\N
100443	GENERIC_DAY	5	7200	f	2010-07-07	4358	\N	27166	\N
100444	GENERIC_DAY	5	10800	f	2010-07-01	4348	\N	27166	\N
100445	GENERIC_DAY	5	0	f	2010-07-11	4348	\N	27166	\N
100446	GENERIC_DAY	5	0	f	2010-07-03	21817	\N	27166	\N
100447	GENERIC_DAY	5	0	f	2010-07-07	4344	\N	27166	\N
100448	GENERIC_DAY	5	7200	f	2010-07-14	4348	\N	27166	\N
100449	GENERIC_DAY	5	0	f	2010-06-30	4344	\N	27166	\N
100450	GENERIC_DAY	5	0	f	2010-07-10	4350	\N	27166	\N
100451	GENERIC_DAY	5	0	f	2010-07-13	4344	\N	27166	\N
100452	GENERIC_DAY	5	10800	f	2010-07-06	4348	\N	27166	\N
100453	GENERIC_DAY	5	7200	f	2010-07-05	4358	\N	27166	\N
100454	GENERIC_DAY	5	0	f	2010-07-14	4344	\N	27166	\N
100455	GENERIC_DAY	5	0	f	2010-06-27	4358	\N	27166	\N
100456	GENERIC_DAY	5	0	f	2010-07-11	4358	\N	27166	\N
100457	GENERIC_DAY	5	10800	f	2010-07-01	21817	\N	27166	\N
100458	GENERIC_DAY	5	0	f	2010-06-28	4350	\N	27166	\N
100459	GENERIC_DAY	5	7200	f	2010-07-12	21817	\N	27166	\N
100460	GENERIC_DAY	5	0	f	2010-07-03	4350	\N	27166	\N
100461	GENERIC_DAY	5	0	f	2010-07-10	21817	\N	27166	\N
100462	GENERIC_DAY	5	10800	f	2010-06-30	21817	\N	27166	\N
100463	GENERIC_DAY	5	0	f	2010-06-30	4350	\N	27166	\N
100464	GENERIC_DAY	5	7200	f	2010-07-12	4350	\N	27166	\N
100465	GENERIC_DAY	5	7200	f	2010-07-13	4348	\N	27166	\N
100466	GENERIC_DAY	5	7200	f	2010-07-08	4350	\N	27166	\N
100467	GENERIC_DAY	5	0	f	2010-07-01	4350	\N	27166	\N
100468	GENERIC_DAY	5	0	f	2010-06-28	4344	\N	27166	\N
100469	GENERIC_DAY	5	10800	f	2010-06-28	4348	\N	27166	\N
100470	GENERIC_DAY	5	7200	f	2010-07-06	4358	\N	27166	\N
100471	GENERIC_DAY	5	0	f	2010-07-05	4350	\N	27166	\N
100472	GENERIC_DAY	5	0	f	2010-07-11	4350	\N	27166	\N
100473	GENERIC_DAY	5	0	f	2010-07-04	21817	\N	27166	\N
100474	GENERIC_DAY	5	0	f	2010-06-29	4344	\N	27166	\N
100475	GENERIC_DAY	5	0	f	2010-07-06	4350	\N	27166	\N
100476	GENERIC_DAY	5	10800	f	2010-06-29	21817	\N	27166	\N
100477	GENERIC_DAY	5	0	f	2010-07-09	4344	\N	27166	\N
100478	GENERIC_DAY	5	0	f	2010-06-27	4348	\N	27166	\N
100479	GENERIC_DAY	5	7200	f	2010-07-08	4348	\N	27166	\N
100480	GENERIC_DAY	5	7200	f	2010-07-08	21817	\N	27166	\N
100481	GENERIC_DAY	5	0	f	2010-07-10	4348	\N	27166	\N
100482	GENERIC_DAY	5	7200	f	2010-07-02	21817	\N	27166	\N
100483	GENERIC_DAY	5	10800	f	2010-07-06	21817	\N	27166	\N
100484	GENERIC_DAY	5	0	f	2010-07-11	4344	\N	27166	\N
100485	GENERIC_DAY	5	10800	f	2010-06-29	4348	\N	27166	\N
100486	GENERIC_DAY	5	10800	f	2010-06-28	21817	\N	27166	\N
100487	GENERIC_DAY	5	7200	f	2010-07-09	4350	\N	27166	\N
100488	GENERIC_DAY	5	7200	f	2010-07-12	4358	\N	27166	\N
100489	GENERIC_DAY	5	0	f	2010-06-29	4350	\N	27166	\N
100490	GENERIC_DAY	5	10800	f	2010-07-07	21817	\N	27166	\N
100491	GENERIC_DAY	5	0	f	2010-07-07	4350	\N	27166	\N
100492	GENERIC_DAY	5	0	f	2010-07-03	4344	\N	27166	\N
100493	GENERIC_DAY	5	0	f	2010-07-04	4348	\N	27166	\N
100494	GENERIC_DAY	5	0	f	2010-07-04	4358	\N	27166	\N
100495	GENERIC_DAY	5	0	f	2010-06-27	4350	\N	27166	\N
100496	GENERIC_DAY	5	7200	f	2010-07-09	21817	\N	27166	\N
100497	GENERIC_DAY	5	3600	f	2010-07-05	4344	\N	27166	\N
100498	GENERIC_DAY	5	10800	f	2010-07-05	4348	\N	27166	\N
100499	GENERIC_DAY	5	10800	f	2010-06-30	4348	\N	27166	\N
100500	GENERIC_DAY	5	7200	f	2010-07-08	4358	\N	27166	\N
100501	GENERIC_DAY	5	3600	f	2010-07-14	4350	\N	27166	\N
100502	GENERIC_DAY	5	7200	f	2010-07-12	4348	\N	27166	\N
100503	GENERIC_DAY	5	7200	f	2010-07-13	4358	\N	27166	\N
100504	GENERIC_DAY	5	7200	f	2010-07-02	4358	\N	27166	\N
100505	GENERIC_DAY	5	0	f	2010-07-04	4344	\N	27166	\N
100506	GENERIC_DAY	5	0	f	2010-07-01	4344	\N	27166	\N
100507	GENERIC_DAY	5	0	f	2010-07-10	4358	\N	27166	\N
100508	GENERIC_DAY	5	0	f	2010-07-11	21817	\N	27166	\N
100509	GENERIC_DAY	5	7200	f	2010-06-29	4358	\N	27166	\N
100510	GENERIC_DAY	5	7200	f	2010-07-02	4344	\N	27166	\N
100511	GENERIC_DAY	5	0	f	2010-07-03	4348	\N	27166	\N
100512	GENERIC_DAY	5	0	f	2010-07-08	4344	\N	27166	\N
100513	GENERIC_DAY	5	0	f	2010-06-27	21817	\N	27166	\N
100514	GENERIC_DAY	5	0	f	2010-07-12	4344	\N	27166	\N
100515	GENERIC_DAY	5	7200	f	2010-07-13	21817	\N	27166	\N
100516	GENERIC_DAY	5	0	f	2010-06-27	4344	\N	27166	\N
100517	GENERIC_DAY	5	7200	f	2010-07-01	4358	\N	27166	\N
100518	GENERIC_DAY	5	7200	f	2010-07-05	21817	\N	27166	\N
100519	GENERIC_DAY	5	3600	f	2010-07-14	4358	\N	27166	\N
100520	GENERIC_DAY	5	7200	f	2010-06-30	4358	\N	27166	\N
100521	GENERIC_DAY	5	0	f	2010-07-10	4344	\N	27166	\N
100522	GENERIC_DAY	5	7200	f	2010-07-09	4358	\N	27166	\N
100523	GENERIC_DAY	5	7200	f	2010-07-09	4348	\N	27166	\N
100524	GENERIC_DAY	5	0	f	2010-07-06	4344	\N	27166	\N
100525	GENERIC_DAY	4	0	f	2010-07-31	4352	\N	27167	\N
100526	GENERIC_DAY	4	14400	f	2010-07-26	4352	\N	27167	\N
100527	GENERIC_DAY	4	14400	f	2010-08-09	4352	\N	27167	\N
100528	GENERIC_DAY	4	14400	f	2010-08-17	4354	\N	27167	\N
100529	GENERIC_DAY	4	14400	f	2010-07-19	4352	\N	27167	\N
100530	GENERIC_DAY	4	14400	f	2010-08-18	4354	\N	27167	\N
100531	GENERIC_DAY	4	14400	f	2010-08-05	4354	\N	27167	\N
100532	GENERIC_DAY	4	0	f	2010-07-31	4354	\N	27167	\N
100533	GENERIC_DAY	4	0	f	2010-07-17	4354	\N	27167	\N
100534	GENERIC_DAY	4	14400	f	2010-08-12	4352	\N	27167	\N
100535	GENERIC_DAY	4	14400	f	2010-07-29	4352	\N	27167	\N
100536	GENERIC_DAY	4	14400	f	2010-07-22	4354	\N	27167	\N
100537	GENERIC_DAY	4	14400	f	2010-08-04	4354	\N	27167	\N
100538	GENERIC_DAY	4	0	f	2010-07-18	4352	\N	27167	\N
100539	GENERIC_DAY	4	0	f	2010-08-08	4352	\N	27167	\N
100540	GENERIC_DAY	4	14400	f	2010-07-26	4354	\N	27167	\N
100541	GENERIC_DAY	4	0	f	2010-08-15	4354	\N	27167	\N
100542	GENERIC_DAY	4	14400	f	2010-07-16	4352	\N	27167	\N
100543	GENERIC_DAY	4	14400	f	2010-08-03	4352	\N	27167	\N
100544	GENERIC_DAY	4	14400	f	2010-07-19	4354	\N	27167	\N
100545	GENERIC_DAY	4	14400	f	2010-07-20	4352	\N	27167	\N
100546	GENERIC_DAY	4	14400	f	2010-08-02	4354	\N	27167	\N
100547	GENERIC_DAY	4	14400	f	2010-08-16	4352	\N	27167	\N
100548	GENERIC_DAY	4	0	f	2010-08-01	4352	\N	27167	\N
100549	GENERIC_DAY	4	0	f	2010-08-08	4354	\N	27167	\N
100550	GENERIC_DAY	4	14400	f	2010-07-27	4352	\N	27167	\N
100551	GENERIC_DAY	4	14400	f	2010-07-15	4352	\N	27167	\N
100552	GENERIC_DAY	4	14400	f	2010-08-13	4352	\N	27167	\N
100553	GENERIC_DAY	4	14400	f	2010-08-06	4352	\N	27167	\N
100554	GENERIC_DAY	4	14400	f	2010-08-05	4352	\N	27167	\N
100555	GENERIC_DAY	4	14400	f	2010-08-10	4352	\N	27167	\N
100556	GENERIC_DAY	4	0	f	2010-07-24	4354	\N	27167	\N
100557	GENERIC_DAY	4	14400	f	2010-08-03	4354	\N	27167	\N
100558	GENERIC_DAY	4	0	f	2010-07-18	4354	\N	27167	\N
100559	GENERIC_DAY	4	14400	f	2010-07-16	4354	\N	27167	\N
100560	GENERIC_DAY	4	14400	f	2010-07-30	4354	\N	27167	\N
100561	GENERIC_DAY	4	14400	f	2010-07-29	4354	\N	27167	\N
100562	GENERIC_DAY	4	0	f	2010-07-25	4352	\N	27167	\N
100563	GENERIC_DAY	4	14400	f	2010-07-22	4352	\N	27167	\N
100564	GENERIC_DAY	4	14400	f	2010-08-04	4352	\N	27167	\N
100565	GENERIC_DAY	4	0	f	2010-07-17	4352	\N	27167	\N
100566	GENERIC_DAY	4	14400	f	2010-07-23	4352	\N	27167	\N
100567	GENERIC_DAY	4	14400	f	2010-08-16	4354	\N	27167	\N
100568	GENERIC_DAY	4	0	f	2010-08-07	4354	\N	27167	\N
100569	GENERIC_DAY	4	14400	f	2010-08-11	4354	\N	27167	\N
100570	GENERIC_DAY	4	0	f	2010-07-24	4352	\N	27167	\N
100571	GENERIC_DAY	4	14400	f	2010-07-23	4354	\N	27167	\N
100572	GENERIC_DAY	4	0	f	2010-08-01	4354	\N	27167	\N
100573	GENERIC_DAY	4	14400	f	2010-07-21	4352	\N	27167	\N
100574	GENERIC_DAY	4	14400	f	2010-07-28	4354	\N	27167	\N
100575	GENERIC_DAY	4	14400	f	2010-08-09	4354	\N	27167	\N
100576	GENERIC_DAY	4	14400	f	2010-08-06	4354	\N	27167	\N
100577	GENERIC_DAY	4	0	f	2010-08-14	4354	\N	27167	\N
100578	GENERIC_DAY	4	14400	f	2010-08-17	4352	\N	27167	\N
100579	GENERIC_DAY	4	14400	f	2010-07-28	4352	\N	27167	\N
100580	GENERIC_DAY	4	14400	f	2010-07-21	4354	\N	27167	\N
100581	GENERIC_DAY	4	0	f	2010-08-14	4352	\N	27167	\N
100582	GENERIC_DAY	4	0	f	2010-08-15	4352	\N	27167	\N
100583	GENERIC_DAY	4	14400	f	2010-07-30	4352	\N	27167	\N
100584	GENERIC_DAY	4	14400	f	2010-08-10	4354	\N	27167	\N
100585	GENERIC_DAY	4	0	f	2010-07-25	4354	\N	27167	\N
100586	GENERIC_DAY	4	14400	f	2010-08-13	4354	\N	27167	\N
100587	GENERIC_DAY	4	14400	f	2010-07-20	4354	\N	27167	\N
100588	GENERIC_DAY	4	14400	f	2010-08-02	4352	\N	27167	\N
100589	GENERIC_DAY	4	14400	f	2010-07-15	4354	\N	27167	\N
100590	GENERIC_DAY	4	14400	f	2010-08-11	4352	\N	27167	\N
100591	GENERIC_DAY	4	0	f	2010-08-07	4352	\N	27167	\N
100592	GENERIC_DAY	4	14400	f	2010-08-18	4352	\N	27167	\N
100593	GENERIC_DAY	4	14400	f	2010-07-27	4354	\N	27167	\N
100594	GENERIC_DAY	4	14400	f	2010-08-12	4354	\N	27167	\N
100595	GENERIC_DAY	3	7200	f	2010-09-02	4348	\N	27168	\N
100596	GENERIC_DAY	3	7200	f	2010-09-09	4348	\N	27168	\N
100597	GENERIC_DAY	3	7200	f	2010-08-27	4350	\N	27168	\N
100598	GENERIC_DAY	3	7200	f	2010-08-31	4344	\N	27168	\N
100599	GENERIC_DAY	3	7200	f	2010-08-30	4344	\N	27168	\N
100600	GENERIC_DAY	3	0	f	2010-09-12	4348	\N	27168	\N
100601	GENERIC_DAY	3	7200	f	2010-09-13	4358	\N	27168	\N
100602	GENERIC_DAY	3	7200	f	2010-08-20	4344	\N	27168	\N
100603	GENERIC_DAY	3	7200	f	2010-08-20	4348	\N	27168	\N
100604	GENERIC_DAY	3	7200	f	2010-09-10	4344	\N	27168	\N
100605	GENERIC_DAY	3	0	f	2010-09-12	4350	\N	27168	\N
100606	GENERIC_DAY	3	7200	f	2010-08-25	4344	\N	27168	\N
100607	GENERIC_DAY	3	7200	f	2010-09-06	4358	\N	27168	\N
100608	GENERIC_DAY	3	0	f	2010-09-12	4358	\N	27168	\N
100609	GENERIC_DAY	3	7200	f	2010-09-03	4358	\N	27168	\N
100610	GENERIC_DAY	3	7200	f	2010-09-13	4344	\N	27168	\N
100611	GENERIC_DAY	3	0	f	2010-08-28	4344	\N	27168	\N
100612	GENERIC_DAY	3	7200	f	2010-08-20	4350	\N	27168	\N
100613	GENERIC_DAY	3	7200	f	2010-08-30	4348	\N	27168	\N
100614	GENERIC_DAY	3	7200	f	2010-09-03	4348	\N	27168	\N
100615	GENERIC_DAY	3	7200	f	2010-08-24	4344	\N	27168	\N
100616	GENERIC_DAY	3	3600	f	2010-09-15	4350	\N	27168	\N
100617	GENERIC_DAY	3	0	f	2010-09-11	4358	\N	27168	\N
100618	GENERIC_DAY	3	7200	f	2010-09-06	4344	\N	27168	\N
100619	GENERIC_DAY	3	0	f	2010-08-28	4358	\N	27168	\N
100620	GENERIC_DAY	3	0	f	2010-09-05	4348	\N	27168	\N
100621	GENERIC_DAY	3	7200	f	2010-09-13	4348	\N	27168	\N
100622	GENERIC_DAY	3	7200	f	2010-08-27	4358	\N	27168	\N
100623	GENERIC_DAY	3	0	f	2010-08-21	4358	\N	27168	\N
100624	GENERIC_DAY	3	7200	f	2010-08-23	4350	\N	27168	\N
100625	GENERIC_DAY	3	7200	f	2010-09-03	4350	\N	27168	\N
100626	GENERIC_DAY	3	7200	f	2010-09-10	4348	\N	27168	\N
100627	GENERIC_DAY	3	0	f	2010-08-22	4358	\N	27168	\N
100628	GENERIC_DAY	3	3600	f	2010-09-15	4358	\N	27168	\N
100629	GENERIC_DAY	3	0	f	2010-09-11	4344	\N	27168	\N
100630	GENERIC_DAY	3	7200	f	2010-09-01	4344	\N	27168	\N
100631	GENERIC_DAY	3	7200	f	2010-08-30	4358	\N	27168	\N
100632	GENERIC_DAY	3	0	f	2010-09-04	4350	\N	27168	\N
100633	GENERIC_DAY	3	7200	f	2010-09-14	4350	\N	27168	\N
100634	GENERIC_DAY	3	7200	f	2010-09-07	4348	\N	27168	\N
100635	GENERIC_DAY	3	7200	f	2010-08-25	4358	\N	27168	\N
100636	GENERIC_DAY	3	7200	f	2010-09-02	4350	\N	27168	\N
100637	GENERIC_DAY	3	7200	f	2010-08-24	4350	\N	27168	\N
100638	GENERIC_DAY	3	0	f	2010-09-04	4344	\N	27168	\N
100639	GENERIC_DAY	3	0	f	2010-08-22	4348	\N	27168	\N
100640	GENERIC_DAY	3	7200	f	2010-08-24	4348	\N	27168	\N
100641	GENERIC_DAY	3	0	f	2010-08-28	4348	\N	27168	\N
100642	GENERIC_DAY	3	0	f	2010-09-04	4358	\N	27168	\N
100643	GENERIC_DAY	3	7200	f	2010-08-26	4350	\N	27168	\N
100644	GENERIC_DAY	3	7200	f	2010-09-08	4348	\N	27168	\N
100645	GENERIC_DAY	3	0	f	2010-08-21	4350	\N	27168	\N
100646	GENERIC_DAY	3	7200	f	2010-09-08	4344	\N	27168	\N
100647	GENERIC_DAY	3	7200	f	2010-08-31	4358	\N	27168	\N
100648	GENERIC_DAY	3	7200	f	2010-09-07	4358	\N	27168	\N
100649	GENERIC_DAY	3	7200	f	2010-08-31	4350	\N	27168	\N
100650	GENERIC_DAY	3	7200	f	2010-08-26	4344	\N	27168	\N
100651	GENERIC_DAY	3	7200	f	2010-09-08	4358	\N	27168	\N
100652	GENERIC_DAY	3	7200	f	2010-09-03	4344	\N	27168	\N
100653	GENERIC_DAY	3	7200	f	2010-08-31	4348	\N	27168	\N
100654	GENERIC_DAY	3	7200	f	2010-08-20	4358	\N	27168	\N
100655	GENERIC_DAY	3	7200	f	2010-08-23	4348	\N	27168	\N
100656	GENERIC_DAY	3	0	f	2010-08-21	4348	\N	27168	\N
100657	GENERIC_DAY	3	0	f	2010-08-29	4344	\N	27168	\N
100658	GENERIC_DAY	3	7200	f	2010-09-13	4350	\N	27168	\N
100659	GENERIC_DAY	3	0	f	2010-08-29	4358	\N	27168	\N
100660	GENERIC_DAY	3	0	f	2010-09-11	4350	\N	27168	\N
100661	GENERIC_DAY	3	7200	f	2010-08-24	4358	\N	27168	\N
100662	GENERIC_DAY	3	7200	f	2010-09-10	4358	\N	27168	\N
100663	GENERIC_DAY	3	7200	f	2010-09-15	4344	\N	27168	\N
100664	GENERIC_DAY	3	7200	f	2010-09-06	4350	\N	27168	\N
100665	GENERIC_DAY	3	7200	f	2010-09-09	4358	\N	27168	\N
100666	GENERIC_DAY	3	0	f	2010-09-05	4358	\N	27168	\N
100667	GENERIC_DAY	3	7200	f	2010-08-26	4358	\N	27168	\N
100668	GENERIC_DAY	3	7200	f	2010-08-25	4350	\N	27168	\N
100669	GENERIC_DAY	3	0	f	2010-09-11	4348	\N	27168	\N
100670	GENERIC_DAY	3	0	f	2010-08-21	4344	\N	27168	\N
100671	GENERIC_DAY	3	0	f	2010-08-28	4350	\N	27168	\N
100672	GENERIC_DAY	3	7200	f	2010-08-27	4348	\N	27168	\N
100673	GENERIC_DAY	3	7200	f	2010-09-14	4344	\N	27168	\N
100674	GENERIC_DAY	3	0	f	2010-09-05	4344	\N	27168	\N
100675	GENERIC_DAY	3	7200	f	2010-09-07	4344	\N	27168	\N
100676	GENERIC_DAY	3	7200	f	2010-08-23	4344	\N	27168	\N
100677	GENERIC_DAY	3	0	f	2010-09-12	4344	\N	27168	\N
100678	GENERIC_DAY	3	7200	f	2010-09-14	4348	\N	27168	\N
100679	GENERIC_DAY	3	7200	f	2010-08-25	4348	\N	27168	\N
100680	GENERIC_DAY	3	7200	f	2010-09-08	4350	\N	27168	\N
100681	GENERIC_DAY	3	7200	f	2010-08-26	4348	\N	27168	\N
100682	GENERIC_DAY	3	7200	f	2010-09-02	4358	\N	27168	\N
100683	GENERIC_DAY	3	0	f	2010-09-05	4350	\N	27168	\N
100684	GENERIC_DAY	3	7200	f	2010-09-07	4350	\N	27168	\N
100685	GENERIC_DAY	3	7200	f	2010-09-10	4350	\N	27168	\N
100686	GENERIC_DAY	3	7200	f	2010-09-06	4348	\N	27168	\N
100687	GENERIC_DAY	3	0	f	2010-08-22	4344	\N	27168	\N
100688	GENERIC_DAY	3	7200	f	2010-09-02	4344	\N	27168	\N
100689	GENERIC_DAY	3	7200	f	2010-09-01	4350	\N	27168	\N
100690	GENERIC_DAY	3	7200	f	2010-09-09	4350	\N	27168	\N
100691	GENERIC_DAY	3	0	f	2010-09-04	4348	\N	27168	\N
100692	GENERIC_DAY	3	7200	f	2010-09-14	4358	\N	27168	\N
100693	GENERIC_DAY	3	7200	f	2010-09-01	4348	\N	27168	\N
100694	GENERIC_DAY	3	0	f	2010-08-29	4348	\N	27168	\N
100695	GENERIC_DAY	3	0	f	2010-08-22	4350	\N	27168	\N
100696	GENERIC_DAY	3	7200	f	2010-08-27	4344	\N	27168	\N
100697	GENERIC_DAY	3	0	f	2010-08-29	4350	\N	27168	\N
100698	GENERIC_DAY	3	7200	f	2010-09-15	4348	\N	27168	\N
100699	GENERIC_DAY	3	7200	f	2010-09-09	4344	\N	27168	\N
100700	GENERIC_DAY	3	7200	f	2010-08-23	4358	\N	27168	\N
100701	GENERIC_DAY	3	7200	f	2010-08-30	4350	\N	27168	\N
100702	GENERIC_DAY	3	7200	f	2010-09-01	4358	\N	27168	\N
100703	GENERIC_DAY	2	28800	f	2010-08-30	4352	\N	42521	\N
100704	GENERIC_DAY	2	28800	f	2010-08-31	4352	\N	42521	\N
100705	GENERIC_DAY	2	0	f	2010-09-11	4354	\N	42521	\N
100706	GENERIC_DAY	2	0	f	2010-09-10	4354	\N	42521	\N
100707	GENERIC_DAY	2	14400	f	2010-08-26	4352	\N	42521	\N
100708	GENERIC_DAY	2	0	f	2010-08-22	4354	\N	42521	\N
100709	GENERIC_DAY	2	28800	f	2010-09-15	4352	\N	42521	\N
100710	GENERIC_DAY	2	0	f	2010-09-19	4352	\N	42521	\N
100711	GENERIC_DAY	2	0	f	2010-09-02	4354	\N	42521	\N
100712	GENERIC_DAY	2	28800	f	2010-09-09	4352	\N	42521	\N
100713	GENERIC_DAY	2	28800	f	2010-09-02	4352	\N	42521	\N
100714	GENERIC_DAY	2	0	f	2010-08-29	4354	\N	42521	\N
100715	GENERIC_DAY	2	28800	f	2010-09-17	4352	\N	42521	\N
100716	GENERIC_DAY	2	28800	f	2010-09-08	4352	\N	42521	\N
100717	GENERIC_DAY	2	0	f	2010-09-04	4354	\N	42521	\N
100718	GENERIC_DAY	2	28800	f	2010-09-06	4352	\N	42521	\N
100719	GENERIC_DAY	2	28800	f	2010-09-14	4352	\N	42521	\N
100720	GENERIC_DAY	2	0	f	2010-09-21	4354	\N	42521	\N
100721	GENERIC_DAY	2	0	f	2010-09-11	4352	\N	42521	\N
100722	GENERIC_DAY	2	0	f	2010-09-07	4354	\N	42521	\N
100723	GENERIC_DAY	2	0	f	2010-09-18	4352	\N	42521	\N
100724	GENERIC_DAY	2	0	f	2010-08-21	4352	\N	42521	\N
100725	GENERIC_DAY	2	0	f	2010-09-22	4354	\N	42521	\N
100726	GENERIC_DAY	2	28800	f	2010-09-10	4352	\N	42521	\N
100727	GENERIC_DAY	2	14400	f	2010-08-27	4354	\N	42521	\N
100728	GENERIC_DAY	2	0	f	2010-09-14	4354	\N	42521	\N
100729	GENERIC_DAY	2	0	f	2010-08-28	4352	\N	42521	\N
100730	GENERIC_DAY	2	0	f	2010-09-23	4354	\N	42521	\N
100731	GENERIC_DAY	2	0	f	2010-09-05	4352	\N	42521	\N
100732	GENERIC_DAY	2	0	f	2010-09-19	4354	\N	42521	\N
100733	GENERIC_DAY	2	28800	f	2010-09-20	4352	\N	42521	\N
100734	GENERIC_DAY	2	0	f	2010-08-28	4354	\N	42521	\N
100735	GENERIC_DAY	2	14400	f	2010-08-27	4352	\N	42521	\N
100736	GENERIC_DAY	2	0	f	2010-09-06	4354	\N	42521	\N
100737	GENERIC_DAY	2	0	f	2010-08-21	4354	\N	42521	\N
100738	GENERIC_DAY	2	0	f	2010-09-20	4354	\N	42521	\N
100739	GENERIC_DAY	2	0	f	2010-09-09	4354	\N	42521	\N
100740	GENERIC_DAY	2	0	f	2010-09-03	4354	\N	42521	\N
100741	GENERIC_DAY	2	14400	f	2010-08-20	4354	\N	42521	\N
100742	GENERIC_DAY	2	28800	f	2010-09-22	4352	\N	42521	\N
100743	GENERIC_DAY	2	0	f	2010-09-17	4354	\N	42521	\N
100744	GENERIC_DAY	2	0	f	2010-08-31	4354	\N	42521	\N
100745	GENERIC_DAY	2	0	f	2010-08-29	4352	\N	42521	\N
100746	GENERIC_DAY	2	14400	f	2010-08-26	4354	\N	42521	\N
100747	GENERIC_DAY	2	28800	f	2010-09-01	4352	\N	42521	\N
100748	GENERIC_DAY	2	0	f	2010-09-15	4354	\N	42521	\N
100749	GENERIC_DAY	2	0	f	2010-09-04	4352	\N	42521	\N
100750	GENERIC_DAY	2	28800	f	2010-09-03	4352	\N	42521	\N
100751	GENERIC_DAY	2	28800	f	2010-09-13	4352	\N	42521	\N
100752	GENERIC_DAY	2	0	f	2010-09-01	4354	\N	42521	\N
100753	GENERIC_DAY	2	0	f	2010-09-13	4354	\N	42521	\N
100754	GENERIC_DAY	2	0	f	2010-09-18	4354	\N	42521	\N
100755	GENERIC_DAY	2	14400	f	2010-08-25	4354	\N	42521	\N
100756	GENERIC_DAY	2	0	f	2010-09-16	4354	\N	42521	\N
100757	GENERIC_DAY	2	14400	f	2010-08-24	4354	\N	42521	\N
100758	GENERIC_DAY	2	0	f	2010-09-05	4354	\N	42521	\N
100759	GENERIC_DAY	2	14400	f	2010-08-20	4352	\N	42521	\N
100760	GENERIC_DAY	2	14400	f	2010-08-23	4352	\N	42521	\N
100761	GENERIC_DAY	2	28800	f	2010-09-16	4352	\N	42521	\N
100762	GENERIC_DAY	2	28800	f	2010-09-21	4352	\N	42521	\N
100763	GENERIC_DAY	2	14400	f	2010-08-24	4352	\N	42521	\N
100764	GENERIC_DAY	2	0	f	2010-08-30	4354	\N	42521	\N
100765	GENERIC_DAY	2	14400	f	2010-08-25	4352	\N	42521	\N
100766	GENERIC_DAY	2	0	f	2010-09-08	4354	\N	42521	\N
100767	GENERIC_DAY	2	28800	f	2010-09-07	4352	\N	42521	\N
100768	GENERIC_DAY	2	14400	f	2010-08-23	4354	\N	42521	\N
100769	GENERIC_DAY	2	0	f	2010-09-12	4352	\N	42521	\N
100770	GENERIC_DAY	2	28800	f	2010-09-23	4352	\N	42521	\N
100771	GENERIC_DAY	2	0	f	2010-09-12	4354	\N	42521	\N
100772	GENERIC_DAY	2	0	f	2010-08-22	4352	\N	42521	\N
100773	GENERIC_DAY	1	0	f	2010-09-25	4354	\N	42522	\N
100774	GENERIC_DAY	1	0	f	2010-09-28	4354	\N	42522	\N
100775	GENERIC_DAY	1	0	f	2010-10-09	4352	\N	42522	\N
100776	GENERIC_DAY	1	0	f	2010-10-03	4352	\N	42522	\N
100777	GENERIC_DAY	1	0	f	2010-10-02	4352	\N	42522	\N
100778	GENERIC_DAY	1	0	f	2010-10-12	4354	\N	42522	\N
100779	GENERIC_DAY	1	28800	f	2010-10-06	4352	\N	42522	\N
100780	GENERIC_DAY	1	28800	f	2010-10-07	4352	\N	42522	\N
100781	GENERIC_DAY	1	14400	f	2010-10-12	4352	\N	42522	\N
100782	GENERIC_DAY	1	28800	f	2010-09-27	4352	\N	42522	\N
100783	GENERIC_DAY	1	0	f	2010-10-10	4354	\N	42522	\N
100784	GENERIC_DAY	1	0	f	2010-10-08	4354	\N	42522	\N
100785	GENERIC_DAY	1	0	f	2010-10-07	4354	\N	42522	\N
100786	GENERIC_DAY	1	28800	f	2010-10-01	4352	\N	42522	\N
100787	GENERIC_DAY	1	0	f	2010-09-26	4354	\N	42522	\N
100788	GENERIC_DAY	1	0	f	2010-09-29	4354	\N	42522	\N
100789	GENERIC_DAY	1	28800	f	2010-10-04	4352	\N	42522	\N
100790	GENERIC_DAY	1	0	f	2010-10-09	4354	\N	42522	\N
100791	GENERIC_DAY	1	28800	f	2010-09-24	4352	\N	42522	\N
100792	GENERIC_DAY	1	28800	f	2010-10-08	4352	\N	42522	\N
100793	GENERIC_DAY	1	0	f	2010-09-24	4354	\N	42522	\N
100794	GENERIC_DAY	1	0	f	2010-10-06	4354	\N	42522	\N
100795	GENERIC_DAY	1	0	f	2010-09-25	4352	\N	42522	\N
100796	GENERIC_DAY	1	28800	f	2010-10-11	4352	\N	42522	\N
100797	GENERIC_DAY	1	0	f	2010-10-11	4354	\N	42522	\N
100798	GENERIC_DAY	1	0	f	2010-10-01	4354	\N	42522	\N
100799	GENERIC_DAY	1	28800	f	2010-09-28	4352	\N	42522	\N
100800	GENERIC_DAY	1	0	f	2010-09-30	4354	\N	42522	\N
100801	GENERIC_DAY	1	0	f	2010-09-27	4354	\N	42522	\N
100802	GENERIC_DAY	1	0	f	2010-10-05	4354	\N	42522	\N
100803	GENERIC_DAY	1	0	f	2010-10-03	4354	\N	42522	\N
100804	GENERIC_DAY	1	0	f	2010-10-02	4354	\N	42522	\N
100805	GENERIC_DAY	1	28800	f	2010-09-29	4352	\N	42522	\N
100806	GENERIC_DAY	1	0	f	2010-09-26	4352	\N	42522	\N
100807	GENERIC_DAY	1	0	f	2010-10-10	4352	\N	42522	\N
100808	GENERIC_DAY	1	0	f	2010-10-04	4354	\N	42522	\N
100809	GENERIC_DAY	1	28800	f	2010-10-05	4352	\N	42522	\N
100810	GENERIC_DAY	1	28800	f	2010-09-30	4352	\N	42522	\N
75547	GENERIC_DAY	7	28800	f	2010-07-29	4354	\N	16802	\N
75574	GENERIC_DAY	7	3600	f	2010-07-13	4352	\N	16802	\N
75533	GENERIC_DAY	7	7200	f	2010-08-04	4352	\N	16802	\N
75550	GENERIC_DAY	7	25200	f	2010-07-14	4354	\N	16802	\N
75549	GENERIC_DAY	7	0	f	2010-08-08	4352	\N	16802	\N
75538	GENERIC_DAY	7	25200	f	2010-07-15	4354	\N	16802	\N
75529	GENERIC_DAY	7	0	f	2010-07-17	4352	\N	16802	\N
75558	GENERIC_DAY	7	0	f	2010-07-25	4354	\N	16802	\N
75542	GENERIC_DAY	7	25200	f	2010-07-16	4354	\N	16802	\N
75557	GENERIC_DAY	7	25200	f	2010-07-20	4354	\N	16802	\N
75539	GENERIC_DAY	7	0	f	2010-07-25	4352	\N	16802	\N
75528	GENERIC_DAY	7	25200	f	2010-07-19	4354	\N	16802	\N
75555	GENERIC_DAY	7	14400	f	2010-08-05	4354	\N	16802	\N
75531	GENERIC_DAY	7	14400	f	2010-08-06	4352	\N	16802	\N
75567	GENERIC_DAY	7	28800	f	2010-07-30	4354	\N	16802	\N
75569	GENERIC_DAY	7	25200	f	2010-07-08	4354	\N	16802	\N
75562	GENERIC_DAY	7	0	f	2010-07-28	4352	\N	16802	\N
75511	GENERIC_DAY	7	14400	f	2010-08-06	4354	\N	16802	\N
75537	GENERIC_DAY	7	28800	f	2010-07-26	4354	\N	16802	\N
75525	GENERIC_DAY	7	3600	f	2010-07-19	4352	\N	16802	\N
75565	GENERIC_DAY	7	3600	f	2010-07-15	4352	\N	16802	\N
75556	GENERIC_DAY	7	28800	f	2010-08-03	4354	\N	16802	\N
75566	GENERIC_DAY	7	0	f	2010-08-07	4354	\N	16802	\N
75526	GENERIC_DAY	7	28800	f	2010-07-22	4354	\N	16802	\N
75535	GENERIC_DAY	7	0	f	2010-07-11	4352	\N	16802	\N
75534	GENERIC_DAY	7	0	f	2010-07-21	4352	\N	16802	\N
75572	GENERIC_DAY	7	0	f	2010-08-03	4352	\N	16802	\N
75523	GENERIC_DAY	7	0	f	2010-07-30	4352	\N	16802	\N
75573	GENERIC_DAY	7	0	f	2010-08-01	4352	\N	16802	\N
75506	GENERIC_DAY	7	0	f	2010-07-22	4352	\N	16802	\N
75532	GENERIC_DAY	7	28800	f	2010-07-23	4354	\N	16802	\N
75554	GENERIC_DAY	7	0	f	2010-07-26	4352	\N	16802	\N
75515	GENERIC_DAY	7	3600	f	2010-07-08	4352	\N	16802	\N
75521	GENERIC_DAY	7	0	f	2010-07-18	4354	\N	16802	\N
75541	GENERIC_DAY	7	3600	f	2010-07-12	4352	\N	16802	\N
75548	GENERIC_DAY	7	14400	f	2010-08-05	4352	\N	16802	\N
75517	GENERIC_DAY	7	0	f	2010-07-24	4354	\N	16802	\N
75524	GENERIC_DAY	7	0	f	2010-07-24	4352	\N	16802	\N
75560	GENERIC_DAY	7	0	f	2010-07-11	4354	\N	16802	\N
75561	GENERIC_DAY	7	25200	f	2010-07-06	4354	\N	16802	\N
75530	GENERIC_DAY	7	25200	f	2010-07-07	4354	\N	16802	\N
75553	GENERIC_DAY	7	0	f	2010-07-10	4352	\N	16802	\N
75559	GENERIC_DAY	7	0	f	2010-07-29	4352	\N	16802	\N
75570	GENERIC_DAY	7	14400	f	2010-08-09	4354	\N	16802	\N
75546	GENERIC_DAY	7	28800	f	2010-07-21	4354	\N	16802	\N
75508	GENERIC_DAY	7	3600	f	2010-07-06	4352	\N	16802	\N
75519	GENERIC_DAY	7	25200	f	2010-07-12	4354	\N	16802	\N
75507	GENERIC_DAY	7	0	f	2010-07-10	4354	\N	16802	\N
75571	GENERIC_DAY	7	3600	f	2010-07-14	4352	\N	16802	\N
75564	GENERIC_DAY	7	3600	f	2010-07-20	4352	\N	16802	\N
75575	GENERIC_DAY	7	3600	f	2010-07-09	4352	\N	16802	\N
75516	GENERIC_DAY	7	0	f	2010-07-31	4352	\N	16802	\N
75518	GENERIC_DAY	7	28800	f	2010-07-27	4354	\N	16802	\N
75510	GENERIC_DAY	7	0	f	2010-08-02	4352	\N	16802	\N
75586	GENERIC_DAY	7	18000	t	2010-06-15	21817	\N	16800	\N
75606	GENERIC_DAY	7	18000	f	2010-06-21	21817	\N	16800	\N
75623	GENERIC_DAY	7	0	f	2010-06-23	4344	\N	16800	\N
75658	GENERIC_DAY	7	0	f	2010-06-30	4350	\N	16800	\N
75581	GENERIC_DAY	7	10800	t	2010-06-15	4358	\N	16800	\N
75666	GENERIC_DAY	7	0	f	2010-06-25	4350	\N	16800	\N
75663	GENERIC_DAY	7	0	f	2010-06-24	4350	\N	16800	\N
75671	GENERIC_DAY	7	7200	f	2010-06-24	4358	\N	16800	\N
75577	GENERIC_DAY	7	14400	f	2010-06-25	21817	\N	16800	\N
75635	GENERIC_DAY	7	0	f	2010-07-04	4344	\N	16800	\N
75681	GENERIC_DAY	7	3600	f	2010-07-05	4348	\N	16800	\N
75662	GENERIC_DAY	7	0	f	2010-06-30	4344	\N	16800	\N
75614	GENERIC_DAY	7	7200	f	2010-06-28	4348	\N	16800	\N
75615	GENERIC_DAY	7	0	f	2010-06-17	4348	\N	16800	\N
75628	GENERIC_DAY	7	0	f	2010-07-04	4348	\N	16800	\N
75660	GENERIC_DAY	7	14400	f	2010-06-28	21817	\N	16800	\N
75611	GENERIC_DAY	7	0	t	2010-06-16	4348	\N	16800	\N
75613	GENERIC_DAY	7	0	f	2010-06-22	4344	\N	16800	\N
75672	GENERIC_DAY	7	0	f	2010-07-05	4344	\N	16800	\N
75612	GENERIC_DAY	7	0	f	2010-06-27	4344	\N	16800	\N
75602	GENERIC_DAY	7	7200	f	2010-06-29	4358	\N	16800	\N
75665	GENERIC_DAY	7	0	f	2010-06-19	21817	\N	16800	\N
75584	GENERIC_DAY	7	0	f	2010-06-28	4344	\N	16800	\N
75679	GENERIC_DAY	7	0	f	2010-07-04	4350	\N	16800	\N
75632	GENERIC_DAY	7	0	f	2010-07-04	4358	\N	16800	\N
75582	GENERIC_DAY	7	7200	f	2010-06-25	4348	\N	16800	\N
75616	GENERIC_DAY	7	0	f	2010-06-21	4348	\N	16800	\N
75622	GENERIC_DAY	7	7200	f	2010-06-23	4358	\N	16800	\N
75634	GENERIC_DAY	7	0	f	2010-06-22	4348	\N	16800	\N
75655	GENERIC_DAY	7	10800	f	2010-06-30	21817	\N	16800	\N
75664	GENERIC_DAY	7	0	f	2010-07-03	4350	\N	16800	\N
75654	GENERIC_DAY	7	0	t	2010-06-16	4350	\N	16800	\N
75576	GENERIC_DAY	7	0	f	2010-06-26	4348	\N	16800	\N
75651	GENERIC_DAY	7	0	f	2010-06-26	21817	\N	16800	\N
75648	GENERIC_DAY	7	10800	f	2010-07-01	4348	\N	16800	\N
75674	GENERIC_DAY	7	0	t	2010-06-16	4344	\N	16800	\N
75617	GENERIC_DAY	7	0	t	2010-06-14	4350	\N	16800	\N
75624	GENERIC_DAY	7	0	f	2010-06-29	4344	\N	16800	\N
75619	GENERIC_DAY	7	0	f	2010-06-23	4350	\N	16800	\N
75649	GENERIC_DAY	7	18000	f	2010-06-18	21817	\N	16800	\N
75647	GENERIC_DAY	7	0	f	2010-06-24	4344	\N	16800	\N
75609	GENERIC_DAY	7	18000	f	2010-06-22	21817	\N	16800	\N
75646	GENERIC_DAY	7	7200	f	2010-07-01	21817	\N	16800	\N
75661	GENERIC_DAY	7	0	f	2010-07-02	4344	\N	16800	\N
75604	GENERIC_DAY	7	0	f	2010-06-26	4350	\N	16800	\N
75579	GENERIC_DAY	7	0	f	2010-06-26	4344	\N	16800	\N
75631	GENERIC_DAY	7	14400	f	2010-06-23	21817	\N	16800	\N
75678	GENERIC_DAY	7	0	f	2010-06-19	4344	\N	16800	\N
75578	GENERIC_DAY	7	3600	f	2010-07-05	4358	\N	16800	\N
75601	GENERIC_DAY	7	0	f	2010-07-03	21817	\N	16800	\N
75610	GENERIC_DAY	7	0	f	2010-06-27	4350	\N	16800	\N
75656	GENERIC_DAY	7	0	f	2010-07-01	4350	\N	16800	\N
75670	GENERIC_DAY	7	0	t	2010-06-15	4350	\N	16800	\N
75636	GENERIC_DAY	7	0	f	2010-06-20	4358	\N	16800	\N
75605	GENERIC_DAY	7	0	f	2010-06-19	4358	\N	16800	\N
75625	GENERIC_DAY	7	0	f	2010-07-05	4350	\N	16800	\N
75580	GENERIC_DAY	7	0	f	2010-06-26	4358	\N	16800	\N
75669	GENERIC_DAY	7	0	f	2010-06-25	4344	\N	16800	\N
75653	GENERIC_DAY	7	0	f	2010-06-17	4344	\N	16800	\N
75608	GENERIC_DAY	7	0	f	2010-06-20	4344	\N	16800	\N
75627	GENERIC_DAY	7	0	f	2010-06-18	4350	\N	16800	\N
75630	GENERIC_DAY	7	7200	f	2010-06-29	4348	\N	16800	\N
75633	GENERIC_DAY	7	0	f	2010-06-18	4344	\N	16800	\N
75607	GENERIC_DAY	7	0	f	2010-06-20	4348	\N	16800	\N
75673	GENERIC_DAY	7	7200	f	2010-07-05	21817	\N	16800	\N
75675	GENERIC_DAY	7	0	f	2010-06-28	4350	\N	16800	\N
75676	GENERIC_DAY	7	0	f	2010-06-27	4358	\N	16800	\N
75626	GENERIC_DAY	7	7200	f	2010-06-25	4358	\N	16800	\N
75583	GENERIC_DAY	7	0	f	2010-06-17	4350	\N	16800	\N
75682	GENERIC_DAY	7	10800	f	2010-06-18	4358	\N	16800	\N
75650	GENERIC_DAY	7	10800	f	2010-07-02	4348	\N	16800	\N
75680	GENERIC_DAY	7	7200	f	2010-07-02	4358	\N	16800	\N
75677	GENERIC_DAY	7	7200	f	2010-06-24	4348	\N	16800	\N
75620	GENERIC_DAY	7	28800	t	2010-06-14	4358	\N	16800	\N
75657	GENERIC_DAY	7	0	f	2010-07-01	4344	\N	16800	\N
75652	GENERIC_DAY	7	10800	f	2010-06-22	4358	\N	16800	\N
75667	GENERIC_DAY	7	14400	f	2010-06-29	21817	\N	16800	\N
75621	GENERIC_DAY	7	10800	t	2010-06-16	4358	\N	16800	\N
75585	GENERIC_DAY	7	0	f	2010-07-03	4348	\N	16800	\N
75629	GENERIC_DAY	7	0	f	2010-06-20	21817	\N	16800	\N
75603	GENERIC_DAY	7	14400	f	2010-06-24	21817	\N	16800	\N
75618	GENERIC_DAY	7	0	f	2010-06-22	4350	\N	16800	\N
75668	GENERIC_DAY	7	0	f	2010-07-03	4358	\N	16800	\N
75659	GENERIC_DAY	7	0	f	2010-06-19	4348	\N	16800	\N
75697	GENERIC_DAY	4	28800	f	2010-08-24	1220	\N	73032	\N
75690	GENERIC_DAY	4	14400	f	2010-09-08	1220	\N	73032	\N
75683	GENERIC_DAY	4	28800	f	2010-08-25	1220	\N	73032	\N
75691	GENERIC_DAY	4	0	f	2010-09-05	1220	\N	73032	\N
75701	GENERIC_DAY	4	28800	f	2010-08-27	1220	\N	73032	\N
75700	GENERIC_DAY	4	28800	f	2010-08-30	1220	\N	73032	\N
75693	GENERIC_DAY	4	28800	f	2010-09-03	1220	\N	73032	\N
75684	GENERIC_DAY	4	28800	f	2010-08-31	1220	\N	73032	\N
85820	GENERIC_DAY	0	28800	f	2010-07-12	4354	\N	83231	\N
85821	GENERIC_DAY	0	28800	f	2010-07-06	4354	\N	83231	\N
85822	GENERIC_DAY	0	43200	f	2010-06-24	4354	\N	83231	\N
85823	GENERIC_DAY	0	28800	t	2010-06-16	4354	\N	83231	\N
85824	GENERIC_DAY	0	28800	f	2010-07-09	4354	\N	83231	\N
85825	GENERIC_DAY	0	18000	f	2010-07-05	4352	\N	83231	\N
85826	GENERIC_DAY	0	18000	f	2010-06-27	4352	\N	83231	\N
85827	GENERIC_DAY	0	18000	f	2010-06-19	4352	\N	83231	\N
85828	GENERIC_DAY	0	18000	f	2010-07-10	4352	\N	83231	\N
85829	GENERIC_DAY	0	18000	f	2010-06-30	4352	\N	83231	\N
85830	GENERIC_DAY	0	43200	f	2010-06-23	4354	\N	83231	\N
85831	GENERIC_DAY	0	10800	f	2010-07-11	4354	\N	83231	\N
85832	GENERIC_DAY	0	43200	f	2010-07-01	4354	\N	83231	\N
85833	GENERIC_DAY	0	18000	f	2010-07-01	4352	\N	83231	\N
85834	GENERIC_DAY	0	28800	f	2010-07-13	4354	\N	83231	\N
85835	GENERIC_DAY	0	28800	t	2010-06-15	4354	\N	83231	\N
85836	GENERIC_DAY	0	43200	f	2010-06-25	4354	\N	83231	\N
85837	GENERIC_DAY	0	18000	f	2010-07-02	4352	\N	83231	\N
85838	GENERIC_DAY	0	18000	f	2010-06-29	4352	\N	83231	\N
85839	GENERIC_DAY	0	10800	f	2010-07-03	4354	\N	83231	\N
85840	GENERIC_DAY	0	43200	f	2010-06-28	4354	\N	83231	\N
85841	GENERIC_DAY	0	28800	f	2010-07-12	4352	\N	83231	\N
85842	GENERIC_DAY	0	18000	f	2010-07-04	4352	\N	83231	\N
85843	GENERIC_DAY	0	43200	f	2010-06-30	4354	\N	83231	\N
85844	GENERIC_DAY	0	28800	t	2010-06-14	4354	\N	83231	\N
85845	GENERIC_DAY	0	18000	f	2010-06-21	4352	\N	83231	\N
85846	GENERIC_DAY	0	18000	f	2010-06-25	4352	\N	83231	\N
85847	GENERIC_DAY	0	18000	f	2010-06-20	4352	\N	83231	\N
85848	GENERIC_DAY	0	14400	f	2010-06-20	4354	\N	83231	\N
85849	GENERIC_DAY	0	28800	f	2010-07-08	4352	\N	83231	\N
85850	GENERIC_DAY	0	18000	f	2010-06-28	4352	\N	83231	\N
85851	GENERIC_DAY	0	43200	f	2010-06-22	4354	\N	83231	\N
85852	GENERIC_DAY	0	10800	f	2010-07-10	4354	\N	83231	\N
85853	GENERIC_DAY	0	28800	f	2010-07-07	4352	\N	83231	\N
85854	GENERIC_DAY	0	0	t	2010-06-15	4352	\N	83231	\N
85855	GENERIC_DAY	0	28800	f	2010-07-09	4352	\N	83231	\N
85856	GENERIC_DAY	0	28800	f	2010-07-14	4352	\N	83231	\N
85857	GENERIC_DAY	0	28800	f	2010-07-13	4352	\N	83231	\N
85858	GENERIC_DAY	0	18000	f	2010-06-24	4352	\N	83231	\N
85859	GENERIC_DAY	0	14400	f	2010-06-26	4354	\N	83231	\N
85860	GENERIC_DAY	0	28800	f	2010-07-08	4354	\N	83231	\N
85861	GENERIC_DAY	0	28800	f	2010-07-07	4354	\N	83231	\N
85862	GENERIC_DAY	0	43200	f	2010-06-21	4354	\N	83231	\N
85863	GENERIC_DAY	0	43200	f	2010-06-18	4354	\N	83231	\N
85864	GENERIC_DAY	0	10800	f	2010-07-04	4354	\N	83231	\N
85865	GENERIC_DAY	0	14400	f	2010-06-19	4354	\N	83231	\N
85866	GENERIC_DAY	0	39600	f	2010-07-05	4354	\N	83231	\N
85867	GENERIC_DAY	0	18000	f	2010-06-23	4352	\N	83231	\N
85868	GENERIC_DAY	0	28800	f	2010-07-14	4354	\N	83231	\N
85869	GENERIC_DAY	0	43200	f	2010-06-29	4354	\N	83231	\N
85870	GENERIC_DAY	0	14400	f	2010-06-27	4354	\N	83231	\N
85871	GENERIC_DAY	0	18000	f	2010-06-22	4352	\N	83231	\N
85872	GENERIC_DAY	0	43200	f	2010-07-02	4354	\N	83231	\N
85873	GENERIC_DAY	0	18000	f	2010-06-18	4352	\N	83231	\N
85874	GENERIC_DAY	0	0	t	2010-06-16	4352	\N	83231	\N
85875	GENERIC_DAY	0	43200	f	2010-06-17	4354	\N	83231	\N
85876	GENERIC_DAY	0	28800	f	2010-07-06	4352	\N	83231	\N
85877	GENERIC_DAY	0	18000	f	2010-07-03	4352	\N	83231	\N
85878	GENERIC_DAY	0	18000	f	2010-06-17	4352	\N	83231	\N
85879	GENERIC_DAY	0	18000	f	2010-07-11	4352	\N	83231	\N
85880	GENERIC_DAY	0	18000	f	2010-06-26	4352	\N	83231	\N
101436	SPECIFIC_DAY	0	28800	f	2011-01-14	4356	100902	\N	\N
101437	SPECIFIC_DAY	0	0	f	2010-11-28	4356	100902	\N	\N
101438	SPECIFIC_DAY	0	28800	f	2010-12-28	4356	100902	\N	\N
101439	SPECIFIC_DAY	0	28800	f	2010-11-30	4356	100902	\N	\N
101440	SPECIFIC_DAY	0	28800	f	2010-10-06	4356	100902	\N	\N
101441	SPECIFIC_DAY	0	28800	f	2010-10-20	4356	100902	\N	\N
101442	SPECIFIC_DAY	0	0	f	2011-01-23	4356	100902	\N	\N
101443	SPECIFIC_DAY	0	28800	f	2010-12-01	4356	100902	\N	\N
101444	SPECIFIC_DAY	0	28800	f	2010-11-22	4356	100902	\N	\N
101445	SPECIFIC_DAY	0	28800	f	2011-02-24	4356	100902	\N	\N
101446	SPECIFIC_DAY	0	28800	f	2011-01-26	4356	100902	\N	\N
101447	SPECIFIC_DAY	0	28800	f	2010-11-24	4356	100902	\N	\N
101448	SPECIFIC_DAY	0	28800	f	2010-12-30	4356	100902	\N	\N
101449	SPECIFIC_DAY	0	28800	f	2010-12-07	4356	100902	\N	\N
101450	SPECIFIC_DAY	0	28800	f	2010-12-09	4356	100902	\N	\N
101451	SPECIFIC_DAY	0	0	f	2010-12-26	4356	100902	\N	\N
101452	SPECIFIC_DAY	0	28800	f	2011-02-16	4356	100902	\N	\N
101453	SPECIFIC_DAY	0	0	f	2010-10-30	4356	100902	\N	\N
101454	SPECIFIC_DAY	0	28800	f	2011-02-01	4356	100902	\N	\N
101455	SPECIFIC_DAY	0	28800	f	2010-11-09	4356	100902	\N	\N
101456	SPECIFIC_DAY	0	28800	f	2010-10-28	4356	100902	\N	\N
101457	SPECIFIC_DAY	0	28800	f	2011-01-04	4356	100902	\N	\N
101458	SPECIFIC_DAY	0	0	f	2010-12-19	4356	100902	\N	\N
101459	SPECIFIC_DAY	0	28800	f	2010-09-23	4356	100902	\N	\N
101460	SPECIFIC_DAY	0	0	f	2010-10-17	4356	100902	\N	\N
101461	SPECIFIC_DAY	0	0	f	2011-01-22	4356	100902	\N	\N
101462	SPECIFIC_DAY	0	28800	f	2011-01-31	4356	100902	\N	\N
101463	SPECIFIC_DAY	0	28800	f	2011-01-24	4356	100902	\N	\N
101464	SPECIFIC_DAY	0	28800	f	2011-02-22	4356	100902	\N	\N
101465	SPECIFIC_DAY	0	28800	f	2010-12-24	4356	100902	\N	\N
101466	SPECIFIC_DAY	0	0	f	2011-02-05	4356	100902	\N	\N
101467	SPECIFIC_DAY	0	28800	f	2010-11-26	4356	100902	\N	\N
101468	SPECIFIC_DAY	0	0	f	2011-01-01	4356	100902	\N	\N
101469	SPECIFIC_DAY	0	28800	f	2011-01-21	4356	100902	\N	\N
101470	SPECIFIC_DAY	0	28800	f	2010-11-04	4356	100902	\N	\N
101471	SPECIFIC_DAY	0	0	f	2011-01-02	4356	100902	\N	\N
101472	SPECIFIC_DAY	0	0	f	2010-12-12	4356	100902	\N	\N
101473	SPECIFIC_DAY	0	28800	f	2010-12-03	4356	100902	\N	\N
101474	SPECIFIC_DAY	0	0	f	2011-01-08	4356	100902	\N	\N
101475	SPECIFIC_DAY	0	28800	f	2011-01-18	4356	100902	\N	\N
101476	SPECIFIC_DAY	0	28800	f	2010-12-16	4356	100902	\N	\N
101477	SPECIFIC_DAY	0	0	f	2010-10-24	4356	100902	\N	\N
101478	SPECIFIC_DAY	0	28800	f	2011-02-07	4356	100902	\N	\N
101479	SPECIFIC_DAY	0	28800	f	2010-10-14	4356	100902	\N	\N
101480	SPECIFIC_DAY	0	0	f	2010-12-04	4356	100902	\N	\N
101481	SPECIFIC_DAY	0	0	f	2010-11-21	4356	100902	\N	\N
101482	SPECIFIC_DAY	0	0	f	2011-01-15	4356	100902	\N	\N
101483	SPECIFIC_DAY	0	28800	f	2010-11-12	4356	100902	\N	\N
101484	SPECIFIC_DAY	0	28800	f	2011-03-08	4356	100902	\N	\N
101485	SPECIFIC_DAY	0	28800	f	2010-11-16	4356	100902	\N	\N
101486	SPECIFIC_DAY	0	28800	f	2010-12-23	4356	100902	\N	\N
101487	SPECIFIC_DAY	0	28800	f	2010-12-29	4356	100902	\N	\N
101488	SPECIFIC_DAY	0	28800	f	2011-02-03	4356	100902	\N	\N
101489	SPECIFIC_DAY	0	28800	f	2011-02-17	4356	100902	\N	\N
101490	SPECIFIC_DAY	0	28800	f	2010-12-15	4356	100902	\N	\N
101491	SPECIFIC_DAY	0	28800	f	2011-01-05	4356	100902	\N	\N
101492	SPECIFIC_DAY	0	28800	f	2011-01-17	4356	100902	\N	\N
101493	SPECIFIC_DAY	0	28800	f	2010-09-22	4356	100902	\N	\N
101494	SPECIFIC_DAY	0	28800	f	2010-11-18	4356	100902	\N	\N
101495	SPECIFIC_DAY	0	0	f	2010-10-23	4356	100902	\N	\N
101496	SPECIFIC_DAY	0	28800	f	2011-02-14	4356	100902	\N	\N
101497	SPECIFIC_DAY	0	28800	f	2011-03-07	4356	100902	\N	\N
101498	SPECIFIC_DAY	0	28800	f	2010-12-13	4356	100902	\N	\N
101499	SPECIFIC_DAY	0	0	f	2010-10-03	4356	100902	\N	\N
101500	SPECIFIC_DAY	0	28800	f	2010-10-22	4356	100902	\N	\N
101501	SPECIFIC_DAY	0	28800	f	2011-03-03	4356	100902	\N	\N
101502	SPECIFIC_DAY	0	28800	f	2011-02-04	4356	100902	\N	\N
101503	SPECIFIC_DAY	0	28800	f	2010-09-27	4356	100902	\N	\N
101504	SPECIFIC_DAY	0	28800	f	2010-12-27	4356	100902	\N	\N
101505	SPECIFIC_DAY	0	0	f	2011-02-12	4356	100902	\N	\N
101506	SPECIFIC_DAY	0	28800	f	2011-02-21	4356	100902	\N	\N
101507	SPECIFIC_DAY	0	28800	f	2010-10-18	4356	100902	\N	\N
101508	SPECIFIC_DAY	0	28800	f	2011-01-03	4356	100902	\N	\N
101509	SPECIFIC_DAY	0	28800	f	2011-01-13	4356	100902	\N	\N
101510	SPECIFIC_DAY	0	28800	f	2010-10-08	4356	100902	\N	\N
101511	SPECIFIC_DAY	0	0	f	2010-10-09	4356	100902	\N	\N
101512	SPECIFIC_DAY	0	0	f	2011-02-06	4356	100902	\N	\N
101513	SPECIFIC_DAY	0	28800	f	2011-03-09	4356	100902	\N	\N
101514	SPECIFIC_DAY	0	28800	f	2010-09-29	4356	100902	\N	\N
101515	SPECIFIC_DAY	0	28800	f	2011-03-01	4356	100902	\N	\N
101516	SPECIFIC_DAY	0	28800	f	2011-02-28	4356	100902	\N	\N
101517	SPECIFIC_DAY	0	0	f	2010-11-07	4356	100902	\N	\N
101518	SPECIFIC_DAY	0	0	f	2010-12-11	4356	100902	\N	\N
101519	SPECIFIC_DAY	0	0	f	2011-01-09	4356	100902	\N	\N
101520	SPECIFIC_DAY	0	0	f	2011-01-16	4356	100902	\N	\N
101521	SPECIFIC_DAY	0	28800	f	2011-02-23	4356	100902	\N	\N
101522	SPECIFIC_DAY	0	28800	f	2010-12-08	4356	100902	\N	\N
101523	SPECIFIC_DAY	0	28800	f	2010-11-03	4356	100902	\N	\N
101524	SPECIFIC_DAY	0	28800	f	2011-03-10	4356	100902	\N	\N
101525	SPECIFIC_DAY	0	28800	f	2010-12-06	4356	100902	\N	\N
101526	SPECIFIC_DAY	0	0	f	2011-03-06	4356	100902	\N	\N
101527	SPECIFIC_DAY	0	28800	f	2011-01-07	4356	100902	\N	\N
101528	SPECIFIC_DAY	0	0	f	2010-10-16	4356	100902	\N	\N
101529	SPECIFIC_DAY	0	28800	f	2010-12-31	4356	100902	\N	\N
101530	SPECIFIC_DAY	0	28800	f	2010-11-10	4356	100902	\N	\N
101531	SPECIFIC_DAY	0	28800	f	2011-02-15	4356	100902	\N	\N
101532	SPECIFIC_DAY	0	28800	f	2010-09-28	4356	100902	\N	\N
101533	SPECIFIC_DAY	0	28800	f	2011-02-10	4356	100902	\N	\N
101534	SPECIFIC_DAY	0	0	f	2010-10-02	4356	100902	\N	\N
101535	SPECIFIC_DAY	0	28800	f	2010-10-27	4356	100902	\N	\N
101536	SPECIFIC_DAY	0	28800	f	2010-10-19	4356	100902	\N	\N
101537	SPECIFIC_DAY	0	28800	f	2010-10-25	4356	100902	\N	\N
101538	SPECIFIC_DAY	0	0	f	2010-11-13	4356	100902	\N	\N
101539	SPECIFIC_DAY	0	28800	f	2011-01-19	4356	100902	\N	\N
101540	SPECIFIC_DAY	0	28800	f	2010-12-22	4356	100902	\N	\N
101541	SPECIFIC_DAY	0	0	f	2011-02-13	4356	100902	\N	\N
101542	SPECIFIC_DAY	0	28800	f	2010-11-11	4356	100902	\N	\N
101543	SPECIFIC_DAY	0	0	f	2011-03-05	4356	100902	\N	\N
101544	SPECIFIC_DAY	0	28800	f	2010-11-19	4356	100902	\N	\N
101545	SPECIFIC_DAY	0	28800	f	2010-10-12	4356	100902	\N	\N
101546	SPECIFIC_DAY	0	28800	f	2010-11-02	4356	100902	\N	\N
101547	SPECIFIC_DAY	0	28800	f	2011-01-06	4356	100902	\N	\N
101548	SPECIFIC_DAY	0	0	f	2010-11-20	4356	100902	\N	\N
101549	SPECIFIC_DAY	0	28800	f	2010-10-01	4356	100902	\N	\N
101550	SPECIFIC_DAY	0	28800	f	2010-12-20	4356	100902	\N	\N
101551	SPECIFIC_DAY	0	28800	f	2010-12-21	4356	100902	\N	\N
101552	SPECIFIC_DAY	0	28800	f	2010-10-07	4356	100902	\N	\N
101553	SPECIFIC_DAY	0	28800	f	2011-03-02	4356	100902	\N	\N
101554	SPECIFIC_DAY	0	28800	f	2011-02-18	4356	100902	\N	\N
101555	SPECIFIC_DAY	0	28800	f	2011-01-25	4356	100902	\N	\N
101556	SPECIFIC_DAY	0	0	f	2011-02-20	4356	100902	\N	\N
101557	SPECIFIC_DAY	0	28800	f	2010-09-20	4356	100902	\N	\N
101558	SPECIFIC_DAY	0	0	f	2010-09-25	4356	100902	\N	\N
101559	SPECIFIC_DAY	0	28800	f	2010-11-29	4356	100902	\N	\N
101560	SPECIFIC_DAY	0	0	f	2010-10-10	4356	100902	\N	\N
101561	SPECIFIC_DAY	0	0	f	2011-01-29	4356	100902	\N	\N
101562	SPECIFIC_DAY	0	0	f	2010-09-19	4356	100902	\N	\N
101563	SPECIFIC_DAY	0	28800	f	2010-09-30	4356	100902	\N	\N
101564	SPECIFIC_DAY	0	28800	f	2010-11-17	4356	100902	\N	\N
101565	SPECIFIC_DAY	0	28800	f	2010-10-21	4356	100902	\N	\N
101566	SPECIFIC_DAY	0	0	f	2010-10-31	4356	100902	\N	\N
101567	SPECIFIC_DAY	0	28800	f	2010-09-21	4356	100902	\N	\N
101568	SPECIFIC_DAY	0	0	f	2010-11-06	4356	100902	\N	\N
101569	SPECIFIC_DAY	0	28800	f	2011-01-12	4356	100902	\N	\N
101570	SPECIFIC_DAY	0	28800	f	2010-10-26	4356	100902	\N	\N
101571	SPECIFIC_DAY	0	0	f	2010-09-26	4356	100902	\N	\N
101572	SPECIFIC_DAY	0	28800	f	2011-01-28	4356	100902	\N	\N
101573	SPECIFIC_DAY	0	0	f	2010-11-27	4356	100902	\N	\N
101574	SPECIFIC_DAY	0	28800	f	2011-02-25	4356	100902	\N	\N
101575	SPECIFIC_DAY	0	28800	f	2011-02-08	4356	100902	\N	\N
101576	SPECIFIC_DAY	0	28800	f	2010-10-05	4356	100902	\N	\N
101577	SPECIFIC_DAY	0	28800	f	2011-01-27	4356	100902	\N	\N
101578	SPECIFIC_DAY	0	0	f	2011-02-27	4356	100902	\N	\N
101579	SPECIFIC_DAY	0	28800	f	2011-03-11	4356	100902	\N	\N
101580	SPECIFIC_DAY	0	28800	f	2010-11-23	4356	100902	\N	\N
101581	SPECIFIC_DAY	0	28800	f	2011-03-04	4356	100902	\N	\N
101582	SPECIFIC_DAY	0	0	f	2011-02-19	4356	100902	\N	\N
101583	SPECIFIC_DAY	0	28800	f	2011-02-11	4356	100902	\N	\N
101584	SPECIFIC_DAY	0	28800	f	2010-12-17	4356	100902	\N	\N
101585	SPECIFIC_DAY	0	28800	f	2010-12-02	4356	100902	\N	\N
101586	SPECIFIC_DAY	0	28800	f	2010-10-13	4356	100902	\N	\N
101587	SPECIFIC_DAY	0	28800	f	2011-01-11	4356	100902	\N	\N
101588	SPECIFIC_DAY	0	28800	f	2010-10-04	4356	100902	\N	\N
101589	SPECIFIC_DAY	0	28800	f	2011-01-20	4356	100902	\N	\N
101590	SPECIFIC_DAY	0	0	f	2011-02-26	4356	100902	\N	\N
101591	SPECIFIC_DAY	0	28800	f	2010-10-15	4356	100902	\N	\N
101592	SPECIFIC_DAY	0	28800	f	2010-11-25	4356	100902	\N	\N
101593	SPECIFIC_DAY	0	28800	f	2010-12-10	4356	100902	\N	\N
101594	SPECIFIC_DAY	0	0	f	2010-11-14	4356	100902	\N	\N
101595	SPECIFIC_DAY	0	28800	f	2010-11-05	4356	100902	\N	\N
101596	SPECIFIC_DAY	0	28800	f	2010-11-01	4356	100902	\N	\N
101597	SPECIFIC_DAY	0	28800	f	2010-10-11	4356	100902	\N	\N
101598	SPECIFIC_DAY	0	28800	f	2011-01-10	4356	100902	\N	\N
101599	SPECIFIC_DAY	0	28800	f	2010-12-14	4356	100902	\N	\N
101600	SPECIFIC_DAY	0	0	f	2010-12-18	4356	100902	\N	\N
101601	SPECIFIC_DAY	0	28800	f	2010-11-15	4356	100902	\N	\N
101602	SPECIFIC_DAY	0	28800	f	2010-09-24	4356	100902	\N	\N
101603	SPECIFIC_DAY	0	28800	f	2011-02-09	4356	100902	\N	\N
101604	SPECIFIC_DAY	0	28800	f	2010-10-29	4356	100902	\N	\N
101605	SPECIFIC_DAY	0	0	f	2010-12-05	4356	100902	\N	\N
101606	SPECIFIC_DAY	0	28800	f	2011-02-02	4356	100902	\N	\N
101607	SPECIFIC_DAY	0	28800	f	2010-11-08	4356	100902	\N	\N
101608	SPECIFIC_DAY	0	0	f	2011-01-30	4356	100902	\N	\N
101609	SPECIFIC_DAY	0	0	f	2010-12-25	4356	100902	\N	\N
75688	GENERIC_DAY	4	0	f	2010-08-20	1220	\N	73032	\N
75692	GENERIC_DAY	4	0	f	2010-08-22	1220	\N	73032	\N
75687	GENERIC_DAY	4	28800	f	2010-09-02	1220	\N	73032	\N
75686	GENERIC_DAY	4	0	f	2010-08-29	1220	\N	73032	\N
75696	GENERIC_DAY	4	28800	f	2010-08-23	1220	\N	73032	\N
75699	GENERIC_DAY	4	0	f	2010-08-21	1220	\N	73032	\N
75698	GENERIC_DAY	4	0	f	2010-08-28	1220	\N	73032	\N
75689	GENERIC_DAY	4	28800	f	2010-08-26	1220	\N	73032	\N
75702	GENERIC_DAY	4	28800	f	2010-09-07	1220	\N	73032	\N
75695	GENERIC_DAY	4	0	f	2010-09-04	1220	\N	73032	\N
75685	GENERIC_DAY	4	28800	f	2010-09-06	1220	\N	73032	\N
75694	GENERIC_DAY	4	28800	f	2010-09-01	1220	\N	73032	\N
102243	GENERIC_DAY	1	0	f	2010-07-24	4358	\N	83242	\N
102244	GENERIC_DAY	1	0	f	2010-07-21	4348	\N	83242	\N
102245	GENERIC_DAY	1	0	f	2010-07-25	72319	\N	83242	\N
102246	GENERIC_DAY	1	7200	f	2010-07-27	21817	\N	83242	\N
102247	GENERIC_DAY	1	0	f	2010-07-26	1216	\N	83242	\N
102248	GENERIC_DAY	1	0	f	2010-07-23	4352	\N	83242	\N
102249	GENERIC_DAY	1	0	f	2010-07-27	4354	\N	83242	\N
102250	GENERIC_DAY	1	0	f	2010-07-23	4344	\N	83242	\N
102251	GENERIC_DAY	1	0	f	2010-07-25	4352	\N	83242	\N
102252	GENERIC_DAY	1	0	f	2010-07-21	1220	\N	83242	\N
102253	GENERIC_DAY	1	7200	f	2010-07-26	21817	\N	83242	\N
102254	GENERIC_DAY	1	0	f	2010-07-26	4348	\N	83242	\N
102255	GENERIC_DAY	1	0	f	2010-07-22	4344	\N	83242	\N
102256	GENERIC_DAY	1	0	f	2010-07-25	72317	\N	83242	\N
102257	GENERIC_DAY	1	7200	f	2010-07-21	21817	\N	83242	\N
102258	GENERIC_DAY	1	0	f	2010-07-21	4352	\N	83242	\N
102259	GENERIC_DAY	1	0	f	2010-07-26	4358	\N	83242	\N
102260	GENERIC_DAY	1	0	f	2010-07-29	4354	\N	83242	\N
102261	GENERIC_DAY	1	7200	f	2010-07-21	4356	\N	83242	\N
102262	GENERIC_DAY	1	0	f	2010-07-27	4348	\N	83242	\N
102263	GENERIC_DAY	1	0	f	2010-07-29	4344	\N	83242	\N
102264	GENERIC_DAY	1	3600	f	2010-07-28	72317	\N	83242	\N
102265	GENERIC_DAY	1	0	f	2010-07-22	4350	\N	83242	\N
75711	SPECIFIC_DAY	2	28800	f	2010-09-28	1220	31222	\N	\N
75717	SPECIFIC_DAY	2	28800	f	2010-09-14	1220	31222	\N	\N
75712	SPECIFIC_DAY	2	0	f	2010-09-26	1220	31222	\N	\N
75706	SPECIFIC_DAY	2	28800	f	2010-09-23	1220	31222	\N	\N
75716	SPECIFIC_DAY	2	28800	f	2010-09-17	1220	31222	\N	\N
75719	SPECIFIC_DAY	2	0	f	2010-09-25	1220	31222	\N	\N
102338	GENERIC_DAY	1	3600	f	2010-07-21	1214	\N	83242	\N
102339	GENERIC_DAY	1	0	f	2010-07-23	4354	\N	83242	\N
102340	GENERIC_DAY	1	0	f	2010-07-29	1220	\N	83242	\N
102341	GENERIC_DAY	1	7200	f	2010-07-26	4356	\N	83242	\N
102342	GENERIC_DAY	1	0	f	2010-07-25	1214	\N	83242	\N
102343	GENERIC_DAY	1	0	f	2010-07-25	4356	\N	83242	\N
102344	GENERIC_DAY	1	0	f	2010-07-24	4350	\N	83242	\N
75714	SPECIFIC_DAY	2	0	f	2010-09-18	1220	31222	\N	\N
75709	SPECIFIC_DAY	2	0	f	2010-09-12	1220	31222	\N	\N
75704	SPECIFIC_DAY	2	28800	f	2010-09-21	1220	31222	\N	\N
75720	SPECIFIC_DAY	2	28800	f	2010-09-13	1220	31222	\N	\N
75718	SPECIFIC_DAY	2	14400	f	2010-09-10	1220	31222	\N	\N
75715	SPECIFIC_DAY	2	28800	f	2010-09-15	1220	31222	\N	\N
75896	SPECIFIC_DAY	2	28800	f	2010-11-25	1216	31224	\N	\N
75912	SPECIFIC_DAY	2	0	f	2010-12-12	1216	31224	\N	\N
75872	SPECIFIC_DAY	2	28800	f	2010-11-18	1216	31224	\N	\N
75915	SPECIFIC_DAY	2	0	f	2010-12-26	1216	31224	\N	\N
75866	SPECIFIC_DAY	2	0	f	2010-11-06	1216	31224	\N	\N
75865	SPECIFIC_DAY	2	0	f	2010-11-07	1216	31224	\N	\N
75897	SPECIFIC_DAY	2	28800	f	2010-11-30	1216	31224	\N	\N
75863	SPECIFIC_DAY	2	28800	f	2010-12-13	1216	31224	\N	\N
75907	SPECIFIC_DAY	2	28800	f	2010-11-09	1216	31224	\N	\N
75905	SPECIFIC_DAY	2	0	f	2010-12-05	1216	31224	\N	\N
75879	SPECIFIC_DAY	2	28800	f	2010-11-29	1216	31224	\N	\N
75908	SPECIFIC_DAY	2	28800	f	2010-12-14	1216	31224	\N	\N
75881	SPECIFIC_DAY	2	0	f	2010-11-13	1216	31224	\N	\N
75892	SPECIFIC_DAY	2	28800	f	2010-11-26	1216	31224	\N	\N
75869	SPECIFIC_DAY	2	0	f	2010-11-28	1216	31224	\N	\N
75878	SPECIFIC_DAY	2	28800	f	2010-11-17	1216	31224	\N	\N
75880	SPECIFIC_DAY	2	28800	f	2010-12-15	1216	31224	\N	\N
75902	SPECIFIC_DAY	2	28800	f	2010-12-02	1216	31224	\N	\N
75882	SPECIFIC_DAY	2	28800	f	2010-12-03	1216	31224	\N	\N
75891	SPECIFIC_DAY	2	28800	f	2010-12-17	1216	31224	\N	\N
75911	SPECIFIC_DAY	2	28800	f	2010-11-19	1216	31224	\N	\N
75914	SPECIFIC_DAY	2	28800	f	2010-11-08	1216	31224	\N	\N
75889	SPECIFIC_DAY	2	28800	f	2010-12-08	1216	31224	\N	\N
75870	SPECIFIC_DAY	2	28800	f	2010-11-16	1216	31224	\N	\N
75867	SPECIFIC_DAY	2	28800	f	2010-12-06	1216	31224	\N	\N
75913	SPECIFIC_DAY	2	28800	f	2010-11-12	1216	31224	\N	\N
75874	SPECIFIC_DAY	2	0	f	2010-11-27	1216	31224	\N	\N
75885	SPECIFIC_DAY	2	28800	f	2010-12-28	1216	31224	\N	\N
75903	SPECIFIC_DAY	2	28800	f	2010-12-23	1216	31224	\N	\N
75916	SPECIFIC_DAY	2	0	f	2010-12-04	1216	31224	\N	\N
75886	SPECIFIC_DAY	2	28800	f	2010-11-22	1216	31224	\N	\N
75894	SPECIFIC_DAY	2	0	f	2010-12-25	1216	31224	\N	\N
75898	SPECIFIC_DAY	2	28800	f	2010-12-21	1216	31224	\N	\N
75895	SPECIFIC_DAY	2	0	f	2010-11-20	1216	31224	\N	\N
75899	SPECIFIC_DAY	2	0	f	2010-12-18	1216	31224	\N	\N
75876	SPECIFIC_DAY	2	28800	f	2010-11-15	1216	31224	\N	\N
75864	SPECIFIC_DAY	2	28800	f	2010-11-11	1216	31224	\N	\N
75877	SPECIFIC_DAY	2	28800	f	2010-11-23	1216	31224	\N	\N
75875	SPECIFIC_DAY	2	14400	f	2010-12-29	1216	31224	\N	\N
75890	SPECIFIC_DAY	2	0	f	2010-12-19	1216	31224	\N	\N
102266	GENERIC_DAY	1	0	f	2010-07-25	1220	\N	83242	\N
102267	GENERIC_DAY	1	0	f	2010-07-24	1220	\N	83242	\N
102268	GENERIC_DAY	1	0	f	2010-07-21	1216	\N	83242	\N
102269	GENERIC_DAY	1	0	f	2010-07-26	4344	\N	83242	\N
102270	GENERIC_DAY	1	3600	f	2010-07-26	1214	\N	83242	\N
102271	GENERIC_DAY	1	0	f	2010-07-25	4350	\N	83242	\N
102272	GENERIC_DAY	1	0	f	2010-07-29	4358	\N	83242	\N
102273	GENERIC_DAY	1	0	f	2010-07-22	4348	\N	83242	\N
102274	GENERIC_DAY	1	0	f	2010-07-21	4354	\N	83242	\N
102275	GENERIC_DAY	1	3600	f	2010-07-23	72319	\N	83242	\N
102276	GENERIC_DAY	1	0	f	2010-07-28	4344	\N	83242	\N
102277	GENERIC_DAY	1	0	f	2010-07-29	72317	\N	83242	\N
102278	GENERIC_DAY	1	0	f	2010-07-28	4352	\N	83242	\N
102279	GENERIC_DAY	1	3600	f	2010-07-27	72317	\N	83242	\N
102280	GENERIC_DAY	1	0	f	2010-07-24	21817	\N	83242	\N
102281	GENERIC_DAY	1	0	f	2010-07-24	4348	\N	83242	\N
102282	GENERIC_DAY	1	3600	f	2010-07-23	72317	\N	83242	\N
102283	GENERIC_DAY	1	0	f	2010-07-28	4350	\N	83242	\N
102284	GENERIC_DAY	1	3600	f	2010-07-27	72321	\N	83242	\N
102285	GENERIC_DAY	1	0	f	2010-07-21	4350	\N	83242	\N
102286	GENERIC_DAY	1	0	f	2010-07-29	4350	\N	83242	\N
102287	GENERIC_DAY	1	0	f	2010-07-24	1216	\N	83242	\N
102288	GENERIC_DAY	1	0	f	2010-07-27	4350	\N	83242	\N
102289	GENERIC_DAY	1	0	f	2010-07-22	1216	\N	83242	\N
102290	GENERIC_DAY	1	0	f	2010-07-29	1214	\N	83242	\N
102291	GENERIC_DAY	1	0	f	2010-07-28	1216	\N	83242	\N
102292	GENERIC_DAY	1	0	f	2010-07-25	4358	\N	83242	\N
102293	GENERIC_DAY	1	3600	f	2010-07-28	1214	\N	83242	\N
102294	GENERIC_DAY	1	0	f	2010-07-24	72319	\N	83242	\N
102295	GENERIC_DAY	1	0	f	2010-07-25	21817	\N	83242	\N
102296	GENERIC_DAY	1	3600	f	2010-07-23	1214	\N	83242	\N
102297	GENERIC_DAY	1	3600	f	2010-07-23	72321	\N	83242	\N
102298	GENERIC_DAY	1	7200	f	2010-07-22	21817	\N	83242	\N
102299	GENERIC_DAY	1	0	f	2010-07-25	4344	\N	83242	\N
102300	GENERIC_DAY	1	7200	f	2010-07-23	21817	\N	83242	\N
102301	GENERIC_DAY	1	7200	f	2010-07-28	4356	\N	83242	\N
102302	GENERIC_DAY	1	3600	f	2010-07-22	1214	\N	83242	\N
102303	GENERIC_DAY	1	3600	f	2010-07-22	72317	\N	83242	\N
102304	GENERIC_DAY	1	3600	f	2010-07-21	72319	\N	83242	\N
102305	GENERIC_DAY	1	0	f	2010-07-25	4348	\N	83242	\N
102306	GENERIC_DAY	1	3600	f	2010-07-22	72321	\N	83242	\N
102307	GENERIC_DAY	1	0	f	2010-07-26	4352	\N	83242	\N
102308	GENERIC_DAY	1	7200	f	2010-07-28	21817	\N	83242	\N
102309	GENERIC_DAY	1	0	f	2010-07-26	4350	\N	83242	\N
102310	GENERIC_DAY	1	0	f	2010-07-23	4350	\N	83242	\N
102311	GENERIC_DAY	1	0	f	2010-07-29	1216	\N	83242	\N
102312	GENERIC_DAY	1	3600	f	2010-07-28	72319	\N	83242	\N
75852	SPECIFIC_DAY	2	28800	f	2010-08-13	1216	31221	\N	\N
75861	SPECIFIC_DAY	2	28800	f	2010-08-16	1216	31221	\N	\N
45827	SPECIFIC_DAY	3	28800	f	2011-01-17	1216	31225	\N	\N
45825	SPECIFIC_DAY	3	28800	f	2011-01-21	1216	31225	\N	\N
45830	SPECIFIC_DAY	3	28800	f	2011-01-24	1216	31225	\N	\N
45833	SPECIFIC_DAY	3	28800	f	2011-01-13	1216	31225	\N	\N
45834	SPECIFIC_DAY	3	28800	f	2011-01-10	1216	31225	\N	\N
45823	SPECIFIC_DAY	3	28800	f	2011-01-14	1216	31225	\N	\N
45824	SPECIFIC_DAY	3	28800	f	2011-01-12	1216	31225	\N	\N
45826	SPECIFIC_DAY	3	28800	f	2011-01-20	1216	31225	\N	\N
45828	SPECIFIC_DAY	3	28800	f	2011-01-18	1216	31225	\N	\N
45835	SPECIFIC_DAY	3	28800	f	2011-01-19	1216	31225	\N	\N
45829	SPECIFIC_DAY	3	14400	f	2011-01-07	1216	31225	\N	\N
45831	SPECIFIC_DAY	3	28800	f	2011-01-25	1216	31225	\N	\N
45832	SPECIFIC_DAY	3	28800	f	2011-01-11	1216	31225	\N	\N
102313	GENERIC_DAY	1	0	f	2010-07-27	4344	\N	83242	\N
102314	GENERIC_DAY	1	3600	f	2010-07-27	72319	\N	83242	\N
102315	GENERIC_DAY	1	0	f	2010-07-24	1214	\N	83242	\N
102316	GENERIC_DAY	1	0	f	2010-07-26	1220	\N	83242	\N
102317	GENERIC_DAY	1	0	f	2010-07-29	72321	\N	83242	\N
102318	GENERIC_DAY	1	0	f	2010-07-25	4354	\N	83242	\N
102319	GENERIC_DAY	1	0	f	2010-07-24	4354	\N	83242	\N
102320	GENERIC_DAY	1	0	f	2010-07-27	4358	\N	83242	\N
102321	GENERIC_DAY	1	0	f	2010-07-23	4358	\N	83242	\N
102322	GENERIC_DAY	1	0	f	2010-07-29	4348	\N	83242	\N
102323	GENERIC_DAY	1	3600	f	2010-07-29	21817	\N	83242	\N
102324	GENERIC_DAY	1	0	f	2010-07-27	1216	\N	83242	\N
102325	GENERIC_DAY	1	0	f	2010-07-22	1220	\N	83242	\N
102326	GENERIC_DAY	1	3600	f	2010-07-28	72321	\N	83242	\N
102327	GENERIC_DAY	1	0	f	2010-07-24	72317	\N	83242	\N
102328	GENERIC_DAY	1	3600	f	2010-07-22	72319	\N	83242	\N
102329	GENERIC_DAY	1	0	f	2010-07-21	4358	\N	83242	\N
102330	GENERIC_DAY	1	0	f	2010-07-24	4352	\N	83242	\N
102331	GENERIC_DAY	1	0	f	2010-07-22	4354	\N	83242	\N
102332	GENERIC_DAY	1	0	f	2010-07-22	4352	\N	83242	\N
102333	GENERIC_DAY	1	0	f	2010-07-22	4358	\N	83242	\N
102334	GENERIC_DAY	1	0	f	2010-07-27	1220	\N	83242	\N
102335	GENERIC_DAY	1	0	f	2010-07-29	72319	\N	83242	\N
102336	GENERIC_DAY	1	0	f	2010-07-28	4348	\N	83242	\N
102337	GENERIC_DAY	1	7200	f	2010-07-23	4356	\N	83242	\N
102345	GENERIC_DAY	1	7200	f	2010-07-22	4356	\N	83242	\N
102346	GENERIC_DAY	1	0	f	2010-07-29	4352	\N	83242	\N
102347	GENERIC_DAY	1	0	f	2010-07-27	4352	\N	83242	\N
102348	GENERIC_DAY	1	0	f	2010-07-24	4344	\N	83242	\N
102349	GENERIC_DAY	1	3600	f	2010-07-21	72317	\N	83242	\N
102350	GENERIC_DAY	1	0	f	2010-07-23	4348	\N	83242	\N
102351	GENERIC_DAY	1	3600	f	2010-07-29	4356	\N	83242	\N
102352	GENERIC_DAY	1	3600	f	2010-07-26	72321	\N	83242	\N
102353	GENERIC_DAY	1	0	f	2010-07-23	1216	\N	83242	\N
102354	GENERIC_DAY	1	0	f	2010-07-25	1216	\N	83242	\N
102355	GENERIC_DAY	1	3600	f	2010-07-26	72317	\N	83242	\N
102356	GENERIC_DAY	1	0	f	2010-07-25	72321	\N	83242	\N
102357	GENERIC_DAY	1	0	f	2010-07-21	4344	\N	83242	\N
102358	GENERIC_DAY	1	0	f	2010-07-24	72321	\N	83242	\N
102359	GENERIC_DAY	1	0	f	2010-07-24	4356	\N	83242	\N
102360	GENERIC_DAY	1	0	f	2010-07-28	1220	\N	83242	\N
102361	GENERIC_DAY	1	3600	f	2010-07-27	1214	\N	83242	\N
102362	GENERIC_DAY	1	0	f	2010-07-26	4354	\N	83242	\N
102363	GENERIC_DAY	1	0	f	2010-07-28	4358	\N	83242	\N
102364	GENERIC_DAY	1	0	f	2010-07-28	4354	\N	83242	\N
102365	GENERIC_DAY	1	7200	f	2010-07-27	4356	\N	83242	\N
102366	GENERIC_DAY	1	0	f	2010-07-23	1220	\N	83242	\N
102367	GENERIC_DAY	1	3600	f	2010-07-21	72321	\N	83242	\N
102368	GENERIC_DAY	1	3600	f	2010-07-26	72319	\N	83242	\N
85907	GENERIC_DAY	0	0	f	2010-09-05	1216	\N	42597	\N
85911	GENERIC_DAY	0	28800	f	2010-09-03	1216	\N	42597	\N
85912	GENERIC_DAY	0	28800	f	2010-08-31	1216	\N	42597	\N
85913	GENERIC_DAY	0	28800	f	2010-10-05	1216	\N	42597	\N
85914	GENERIC_DAY	0	28800	f	2010-09-09	1216	\N	42597	\N
85915	GENERIC_DAY	0	28800	f	2010-09-20	1216	\N	42597	\N
85916	GENERIC_DAY	0	28800	f	2010-10-12	1216	\N	42597	\N
85917	GENERIC_DAY	0	28800	f	2010-09-06	1216	\N	42597	\N
85918	GENERIC_DAY	0	0	f	2010-09-25	1216	\N	42597	\N
85919	GENERIC_DAY	0	0	f	2010-10-02	1216	\N	42597	\N
85920	GENERIC_DAY	0	28800	f	2010-09-29	1216	\N	42597	\N
85921	GENERIC_DAY	0	28800	f	2010-09-21	1216	\N	42597	\N
85922	GENERIC_DAY	0	0	f	2010-09-11	1216	\N	42597	\N
85923	GENERIC_DAY	0	28800	f	2010-09-10	1216	\N	42597	\N
85924	GENERIC_DAY	0	28800	f	2010-09-27	1216	\N	42597	\N
85925	GENERIC_DAY	0	28800	f	2010-09-22	1216	\N	42597	\N
85926	GENERIC_DAY	0	28800	f	2010-09-01	1216	\N	42597	\N
85927	GENERIC_DAY	0	0	f	2010-10-09	1216	\N	42597	\N
85928	GENERIC_DAY	0	28800	f	2010-08-25	1216	\N	42597	\N
85929	GENERIC_DAY	0	0	f	2010-09-19	1216	\N	42597	\N
85930	GENERIC_DAY	0	0	f	2010-09-26	1216	\N	42597	\N
85931	GENERIC_DAY	0	28800	f	2010-09-08	1216	\N	42597	\N
85932	GENERIC_DAY	0	28800	f	2010-10-04	1216	\N	42597	\N
85933	GENERIC_DAY	0	0	f	2010-09-12	1216	\N	42597	\N
85934	GENERIC_DAY	0	28800	f	2010-09-24	1216	\N	42597	\N
85935	GENERIC_DAY	0	28800	f	2010-08-24	1216	\N	42597	\N
85936	GENERIC_DAY	0	28800	f	2010-10-11	1216	\N	42597	\N
85937	GENERIC_DAY	0	28800	f	2010-09-14	1216	\N	42597	\N
85938	GENERIC_DAY	0	28800	f	2010-09-28	1216	\N	42597	\N
85939	GENERIC_DAY	0	28800	f	2010-10-01	1216	\N	42597	\N
85940	GENERIC_DAY	0	28800	f	2010-10-08	1216	\N	42597	\N
85941	GENERIC_DAY	0	28800	f	2010-09-16	1216	\N	42597	\N
85942	GENERIC_DAY	0	0	f	2010-08-29	1216	\N	42597	\N
85943	GENERIC_DAY	0	28800	f	2010-09-13	1216	\N	42597	\N
85944	GENERIC_DAY	0	28800	f	2010-10-07	1216	\N	42597	\N
85945	GENERIC_DAY	0	28800	f	2010-09-02	1216	\N	42597	\N
85946	GENERIC_DAY	0	0	f	2010-09-18	1216	\N	42597	\N
85947	GENERIC_DAY	0	28800	f	2010-09-30	1216	\N	42597	\N
85948	GENERIC_DAY	0	0	f	2010-08-23	1216	\N	42597	\N
85949	GENERIC_DAY	0	28800	f	2010-08-27	1216	\N	42597	\N
85950	GENERIC_DAY	0	28800	f	2010-09-17	1216	\N	42597	\N
86153	GENERIC_DAY	0	14400	f	2010-10-14	1216	\N	42597	\N
86154	GENERIC_DAY	0	0	f	2010-10-10	1216	\N	42597	\N
86155	GENERIC_DAY	0	0	f	2010-10-03	1216	\N	42597	\N
86156	GENERIC_DAY	0	0	f	2010-08-28	1216	\N	42597	\N
86157	GENERIC_DAY	0	28800	f	2010-09-07	1216	\N	42597	\N
86158	GENERIC_DAY	0	28800	f	2010-08-30	1216	\N	42597	\N
86159	GENERIC_DAY	0	28800	f	2010-08-26	1216	\N	42597	\N
86160	GENERIC_DAY	0	28800	f	2010-09-23	1216	\N	42597	\N
86161	GENERIC_DAY	0	28800	f	2010-10-06	1216	\N	42597	\N
85881	GENERIC_DAY	0	28800	f	2011-02-21	1216	\N	83232	\N
85882	GENERIC_DAY	0	0	f	2011-02-11	1216	\N	83232	\N
85883	GENERIC_DAY	0	28800	f	2011-03-16	1216	\N	83232	\N
85884	GENERIC_DAY	0	28800	f	2011-02-14	1216	\N	83232	\N
85885	GENERIC_DAY	0	28800	f	2011-02-17	1216	\N	83232	\N
85886	GENERIC_DAY	0	28800	f	2011-02-28	1216	\N	83232	\N
85887	GENERIC_DAY	0	28800	f	2011-03-08	1216	\N	83232	\N
85888	GENERIC_DAY	0	28800	f	2011-03-04	1216	\N	83232	\N
85889	GENERIC_DAY	0	28800	f	2011-02-23	1216	\N	83232	\N
85890	GENERIC_DAY	0	28800	f	2011-02-22	1216	\N	83232	\N
85891	GENERIC_DAY	0	28800	f	2011-03-01	1216	\N	83232	\N
85892	GENERIC_DAY	0	28800	f	2011-02-18	1216	\N	83232	\N
85893	GENERIC_DAY	0	28800	f	2011-03-15	1216	\N	83232	\N
85894	GENERIC_DAY	0	28800	f	2011-03-03	1216	\N	83232	\N
85895	GENERIC_DAY	0	28800	f	2011-02-15	1216	\N	83232	\N
85896	GENERIC_DAY	0	28800	f	2011-02-24	1216	\N	83232	\N
85897	GENERIC_DAY	0	28800	f	2011-02-25	1216	\N	83232	\N
85898	GENERIC_DAY	0	28800	f	2011-03-02	1216	\N	83232	\N
85899	GENERIC_DAY	0	28800	f	2011-03-18	1216	\N	83232	\N
85900	GENERIC_DAY	0	28800	f	2011-03-17	1216	\N	83232	\N
85901	GENERIC_DAY	0	28800	f	2011-03-10	1216	\N	83232	\N
85902	GENERIC_DAY	0	28800	f	2011-03-07	1216	\N	83232	\N
85903	GENERIC_DAY	0	28800	f	2011-02-16	1216	\N	83232	\N
85904	GENERIC_DAY	0	28800	f	2011-03-14	1216	\N	83232	\N
85905	GENERIC_DAY	0	28800	f	2011-03-11	1216	\N	83232	\N
85906	GENERIC_DAY	0	28800	f	2011-03-09	1216	\N	83232	\N
104924	GENERIC_DAY	2	0	f	2010-07-24	4344	\N	104235	\N
104925	GENERIC_DAY	2	7200	f	2010-07-21	4358	\N	104235	\N
104926	GENERIC_DAY	2	7200	f	2010-07-27	4348	\N	104235	\N
104927	GENERIC_DAY	2	0	f	2010-07-17	4348	\N	104235	\N
104928	GENERIC_DAY	2	0	f	2010-07-31	4344	\N	104235	\N
104929	GENERIC_DAY	2	7200	f	2010-07-19	4344	\N	104235	\N
104930	GENERIC_DAY	2	7200	f	2010-07-20	4358	\N	104235	\N
104931	GENERIC_DAY	2	0	f	2010-08-07	4350	\N	104235	\N
104932	GENERIC_DAY	2	7200	f	2010-07-28	4358	\N	104235	\N
104933	GENERIC_DAY	2	0	f	2010-07-17	4350	\N	104235	\N
104934	GENERIC_DAY	2	0	f	2010-07-25	4350	\N	104235	\N
104935	GENERIC_DAY	2	7200	f	2010-07-20	4350	\N	104235	\N
104936	GENERIC_DAY	2	7200	f	2010-08-10	4348	\N	104235	\N
104937	GENERIC_DAY	2	7200	f	2010-08-10	4344	\N	104235	\N
104938	GENERIC_DAY	2	7200	f	2010-08-09	4350	\N	104235	\N
104939	GENERIC_DAY	2	7200	f	2010-07-27	4358	\N	104235	\N
104940	GENERIC_DAY	2	7200	f	2010-07-22	4350	\N	104235	\N
104941	GENERIC_DAY	2	7200	f	2010-07-29	4348	\N	104235	\N
104942	GENERIC_DAY	2	3600	f	2010-08-10	4358	\N	104235	\N
104943	GENERIC_DAY	2	10800	f	2010-07-15	4358	\N	104235	\N
104944	GENERIC_DAY	2	7200	f	2010-07-29	4358	\N	104235	\N
104945	GENERIC_DAY	2	7200	f	2010-08-02	4350	\N	104235	\N
104946	GENERIC_DAY	2	7200	f	2010-08-04	4358	\N	104235	\N
104947	GENERIC_DAY	2	7200	f	2010-08-05	4344	\N	104235	\N
104948	GENERIC_DAY	2	7200	f	2010-07-22	4344	\N	104235	\N
104949	GENERIC_DAY	2	10800	f	2010-07-16	4350	\N	104235	\N
104950	GENERIC_DAY	2	7200	f	2010-07-15	4348	\N	104235	\N
104951	GENERIC_DAY	2	0	f	2010-07-25	4358	\N	104235	\N
104952	GENERIC_DAY	2	0	f	2010-07-18	4344	\N	104235	\N
104953	GENERIC_DAY	2	7200	f	2010-07-20	4348	\N	104235	\N
104954	GENERIC_DAY	2	0	f	2010-08-07	4344	\N	104235	\N
104955	GENERIC_DAY	2	0	f	2010-07-31	4348	\N	104235	\N
104956	GENERIC_DAY	2	0	f	2010-08-01	4348	\N	104235	\N
104957	GENERIC_DAY	2	0	f	2010-07-25	4348	\N	104235	\N
104958	GENERIC_DAY	2	0	f	2010-07-24	4358	\N	104235	\N
104959	GENERIC_DAY	2	0	f	2010-07-17	4358	\N	104235	\N
104960	GENERIC_DAY	2	0	f	2010-08-08	4348	\N	104235	\N
104961	GENERIC_DAY	2	0	f	2010-08-01	4344	\N	104235	\N
104962	GENERIC_DAY	2	7200	f	2010-08-04	4344	\N	104235	\N
104963	GENERIC_DAY	2	7200	f	2010-08-06	4348	\N	104235	\N
104964	GENERIC_DAY	2	7200	f	2010-08-05	4358	\N	104235	\N
104965	GENERIC_DAY	2	7200	f	2010-07-20	4344	\N	104235	\N
104966	GENERIC_DAY	2	7200	f	2010-07-22	4348	\N	104235	\N
104967	GENERIC_DAY	2	7200	f	2010-07-27	4350	\N	104235	\N
104968	GENERIC_DAY	2	7200	f	2010-07-28	4348	\N	104235	\N
104969	GENERIC_DAY	2	0	f	2010-07-18	4350	\N	104235	\N
104970	GENERIC_DAY	2	7200	f	2010-08-03	4358	\N	104235	\N
104971	GENERIC_DAY	2	10800	f	2010-07-16	4358	\N	104235	\N
104972	GENERIC_DAY	2	3600	f	2010-08-10	4350	\N	104235	\N
104973	GENERIC_DAY	2	0	f	2010-07-18	4358	\N	104235	\N
104974	GENERIC_DAY	2	7200	f	2010-07-28	4344	\N	104235	\N
104975	GENERIC_DAY	2	7200	f	2010-08-05	4348	\N	104235	\N
104976	GENERIC_DAY	2	7200	f	2010-07-26	4358	\N	104235	\N
104977	GENERIC_DAY	2	7200	f	2010-08-03	4350	\N	104235	\N
104978	GENERIC_DAY	2	7200	f	2010-08-09	4358	\N	104235	\N
104979	SPECIFIC_DAY	2	0	f	2010-07-11	4352	104738	\N	\N
104980	SPECIFIC_DAY	2	25200	f	2010-07-06	4352	104738	\N	\N
104981	SPECIFIC_DAY	2	0	f	2010-07-10	4352	104738	\N	\N
104982	SPECIFIC_DAY	2	25200	f	2010-07-09	4352	104738	\N	\N
104983	SPECIFIC_DAY	2	25200	f	2010-07-13	4352	104738	\N	\N
104984	SPECIFIC_DAY	2	25200	f	2010-07-08	4352	104738	\N	\N
104985	SPECIFIC_DAY	2	25200	f	2010-07-05	4352	104738	\N	\N
104986	SPECIFIC_DAY	2	3600	f	2010-07-14	4352	104738	\N	\N
104987	SPECIFIC_DAY	2	25200	f	2010-07-12	4352	104738	\N	\N
104988	SPECIFIC_DAY	2	25200	f	2010-07-07	4352	104738	\N	\N
104989	GENERIC_DAY	2	14400	f	2010-08-26	72317	\N	104236	\N
104990	GENERIC_DAY	2	14400	f	2010-09-02	72319	\N	104236	\N
104991	GENERIC_DAY	2	0	f	2010-09-05	72319	\N	104236	\N
104992	GENERIC_DAY	2	0	f	2010-09-05	72317	\N	104236	\N
104993	GENERIC_DAY	2	0	f	2010-08-22	72319	\N	104236	\N
104994	GENERIC_DAY	2	14400	f	2010-09-10	72319	\N	104236	\N
104995	GENERIC_DAY	2	14400	f	2010-08-27	72319	\N	104236	\N
104996	GENERIC_DAY	2	14400	f	2010-08-31	72317	\N	104236	\N
104997	GENERIC_DAY	2	0	f	2010-08-29	72317	\N	104236	\N
104998	GENERIC_DAY	2	14400	f	2010-08-16	72319	\N	104236	\N
104999	GENERIC_DAY	2	10800	f	2010-08-13	72321	\N	104236	\N
105000	GENERIC_DAY	2	10800	f	2010-08-11	72319	\N	104236	\N
105001	GENERIC_DAY	2	0	f	2010-08-07	72321	\N	104236	\N
105002	GENERIC_DAY	2	14400	f	2010-08-25	72319	\N	104236	\N
105003	GENERIC_DAY	2	14400	f	2010-08-23	72317	\N	104236	\N
105004	GENERIC_DAY	2	14400	f	2010-09-09	72319	\N	104236	\N
105005	GENERIC_DAY	2	14400	f	2010-09-03	72317	\N	104236	\N
105006	GENERIC_DAY	2	0	f	2010-08-22	72317	\N	104236	\N
105007	GENERIC_DAY	2	14400	f	2010-08-27	72317	\N	104236	\N
105008	GENERIC_DAY	2	0	f	2010-08-14	72319	\N	104236	\N
105009	GENERIC_DAY	2	0	f	2010-08-14	72317	\N	104236	\N
105010	GENERIC_DAY	2	7200	f	2010-08-12	72321	\N	104236	\N
105011	GENERIC_DAY	2	0	f	2010-08-15	72317	\N	104236	\N
105012	GENERIC_DAY	2	0	f	2010-08-28	72319	\N	104236	\N
105013	GENERIC_DAY	2	10800	f	2010-08-10	72319	\N	104236	\N
105014	GENERIC_DAY	2	0	f	2010-08-21	72317	\N	104236	\N
105015	GENERIC_DAY	2	14400	f	2010-08-19	72317	\N	104236	\N
105016	GENERIC_DAY	2	0	f	2010-08-21	72319	\N	104236	\N
105017	GENERIC_DAY	2	10800	f	2010-08-11	72317	\N	104236	\N
105018	GENERIC_DAY	2	14400	f	2010-09-02	72317	\N	104236	\N
105019	GENERIC_DAY	2	14400	f	2010-09-07	72319	\N	104236	\N
105020	GENERIC_DAY	2	14400	f	2010-09-06	72319	\N	104236	\N
105021	GENERIC_DAY	2	10800	f	2010-08-12	72317	\N	104236	\N
105022	GENERIC_DAY	2	7200	f	2010-08-10	72321	\N	104236	\N
105023	GENERIC_DAY	2	14400	f	2010-08-17	72319	\N	104236	\N
105024	GENERIC_DAY	2	14400	f	2010-09-03	72319	\N	104236	\N
105025	GENERIC_DAY	2	14400	f	2010-08-24	72319	\N	104236	\N
105026	GENERIC_DAY	2	14400	f	2010-08-20	72317	\N	104236	\N
105027	GENERIC_DAY	2	14400	f	2010-08-30	72319	\N	104236	\N
105028	GENERIC_DAY	2	0	f	2010-08-28	72317	\N	104236	\N
105029	GENERIC_DAY	2	0	f	2010-08-15	72319	\N	104236	\N
105030	GENERIC_DAY	2	14400	f	2010-08-17	72317	\N	104236	\N
105031	GENERIC_DAY	2	0	f	2010-08-08	72321	\N	104236	\N
105032	GENERIC_DAY	2	14400	f	2010-09-08	72317	\N	104236	\N
105033	GENERIC_DAY	2	0	f	2010-08-07	72319	\N	104236	\N
105034	GENERIC_DAY	2	14400	f	2010-09-01	72319	\N	104236	\N
105035	GENERIC_DAY	2	10800	f	2010-08-09	72319	\N	104236	\N
105036	GENERIC_DAY	2	0	f	2010-08-29	72319	\N	104236	\N
105037	GENERIC_DAY	2	10800	f	2010-08-09	72317	\N	104236	\N
105038	GENERIC_DAY	2	10800	f	2010-08-12	72319	\N	104236	\N
105039	GENERIC_DAY	2	14400	f	2010-08-31	72319	\N	104236	\N
105040	GENERIC_DAY	2	14400	f	2010-08-26	72319	\N	104236	\N
105041	GENERIC_DAY	2	14400	f	2010-09-10	72317	\N	104236	\N
105042	GENERIC_DAY	2	0	f	2010-09-04	72317	\N	104236	\N
105043	GENERIC_DAY	2	7200	f	2010-08-11	72321	\N	104236	\N
105044	GENERIC_DAY	2	7200	f	2010-08-13	72319	\N	104236	\N
105045	GENERIC_DAY	2	14400	f	2010-09-06	72317	\N	104236	\N
105046	GENERIC_DAY	2	14400	f	2010-08-16	72317	\N	104236	\N
105047	GENERIC_DAY	2	14400	f	2010-08-19	72319	\N	104236	\N
105048	GENERIC_DAY	2	0	f	2010-08-08	72319	\N	104236	\N
105049	GENERIC_DAY	2	14400	f	2010-09-07	72317	\N	104236	\N
105050	GENERIC_DAY	2	0	f	2010-08-07	72317	\N	104236	\N
105051	GENERIC_DAY	2	14400	f	2010-08-30	72317	\N	104236	\N
105052	GENERIC_DAY	2	14400	f	2010-08-25	72317	\N	104236	\N
105053	GENERIC_DAY	2	14400	f	2010-09-01	72317	\N	104236	\N
105054	GENERIC_DAY	2	14400	f	2010-08-18	72319	\N	104236	\N
105055	GENERIC_DAY	2	14400	f	2010-08-18	72317	\N	104236	\N
105056	GENERIC_DAY	2	10800	f	2010-08-13	72317	\N	104236	\N
105057	GENERIC_DAY	2	7200	f	2010-08-09	72321	\N	104236	\N
105058	GENERIC_DAY	2	14400	f	2010-08-24	72317	\N	104236	\N
105059	GENERIC_DAY	2	14400	f	2010-08-23	72319	\N	104236	\N
105060	GENERIC_DAY	2	10800	f	2010-08-10	72317	\N	104236	\N
105061	GENERIC_DAY	2	14400	f	2010-08-20	72319	\N	104236	\N
105062	GENERIC_DAY	2	0	f	2010-09-04	72319	\N	104236	\N
105063	GENERIC_DAY	2	0	f	2010-08-08	72317	\N	104236	\N
105064	GENERIC_DAY	2	14400	f	2010-09-08	72319	\N	104236	\N
105065	GENERIC_DAY	2	14400	f	2010-09-09	72317	\N	104236	\N
105066	GENERIC_DAY	2	10800	f	2010-07-15	4348	\N	104237	\N
105067	GENERIC_DAY	2	7200	f	2010-07-20	4344	\N	104237	\N
105068	GENERIC_DAY	2	7200	f	2010-07-29	4348	\N	104237	\N
105069	GENERIC_DAY	2	0	f	2010-07-18	4358	\N	104237	\N
105070	GENERIC_DAY	2	7200	f	2010-08-05	4358	\N	104237	\N
105071	GENERIC_DAY	2	7200	f	2010-07-28	4344	\N	104237	\N
105072	GENERIC_DAY	2	7200	f	2010-08-03	4358	\N	104237	\N
105073	GENERIC_DAY	2	0	f	2010-07-31	4350	\N	104237	\N
105074	GENERIC_DAY	2	7200	f	2010-07-26	4348	\N	104237	\N
105075	GENERIC_DAY	2	7200	f	2010-07-22	4350	\N	104237	\N
105076	GENERIC_DAY	2	7200	f	2010-07-26	4350	\N	104237	\N
105077	GENERIC_DAY	2	7200	f	2010-07-06	4358	\N	104237	\N
105078	GENERIC_DAY	2	0	f	2010-07-11	4358	\N	104237	\N
105079	GENERIC_DAY	2	7200	f	2010-07-30	4358	\N	104237	\N
105080	GENERIC_DAY	2	7200	f	2010-07-23	4358	\N	104237	\N
105081	GENERIC_DAY	2	0	f	2010-08-01	4344	\N	104237	\N
105082	GENERIC_DAY	2	7200	f	2010-07-26	4358	\N	104237	\N
105083	GENERIC_DAY	2	7200	f	2010-07-21	4350	\N	104237	\N
105084	GENERIC_DAY	2	7200	f	2010-07-28	4358	\N	104237	\N
105085	GENERIC_DAY	2	0	f	2010-07-18	4350	\N	104237	\N
105086	GENERIC_DAY	2	0	f	2010-07-07	4350	\N	104237	\N
105087	GENERIC_DAY	2	0	f	2010-08-01	4348	\N	104237	\N
105088	GENERIC_DAY	2	7200	f	2010-07-23	4348	\N	104237	\N
105089	GENERIC_DAY	2	7200	f	2010-07-21	4358	\N	104237	\N
105090	GENERIC_DAY	2	3600	f	2010-07-05	4344	\N	104237	\N
105091	GENERIC_DAY	2	7200	f	2010-07-12	4350	\N	104237	\N
105092	GENERIC_DAY	2	7200	f	2010-08-04	4348	\N	104237	\N
105093	GENERIC_DAY	2	7200	f	2010-08-04	4344	\N	104237	\N
105094	GENERIC_DAY	2	3600	f	2010-07-12	21817	\N	104237	\N
105095	GENERIC_DAY	2	7200	f	2010-08-02	4344	\N	104237	\N
105096	GENERIC_DAY	2	10800	f	2010-07-14	4348	\N	104237	\N
105097	GENERIC_DAY	2	0	f	2010-07-24	4344	\N	104237	\N
105098	GENERIC_DAY	2	0	f	2010-07-25	4344	\N	104237	\N
105099	GENERIC_DAY	2	0	f	2010-07-17	4344	\N	104237	\N
105100	GENERIC_DAY	2	0	f	2010-07-10	4358	\N	104237	\N
105101	GENERIC_DAY	2	7200	f	2010-08-06	4344	\N	104237	\N
105102	GENERIC_DAY	2	7200	f	2010-07-20	4358	\N	104237	\N
105103	GENERIC_DAY	2	0	f	2010-07-25	4358	\N	104237	\N
105104	GENERIC_DAY	2	7200	f	2010-07-14	4350	\N	104237	\N
105105	GENERIC_DAY	2	7200	f	2010-07-23	4344	\N	104237	\N
105106	GENERIC_DAY	2	0	f	2010-07-08	4344	\N	104237	\N
105107	GENERIC_DAY	2	7200	f	2010-08-05	4344	\N	104237	\N
105108	GENERIC_DAY	2	3600	f	2010-07-09	4358	\N	104237	\N
105109	GENERIC_DAY	2	7200	f	2010-08-04	4358	\N	104237	\N
105110	GENERIC_DAY	2	7200	f	2010-08-03	4344	\N	104237	\N
105111	GENERIC_DAY	2	7200	f	2010-07-21	4344	\N	104237	\N
105112	GENERIC_DAY	2	7200	f	2010-07-30	4350	\N	104237	\N
105113	GENERIC_DAY	2	7200	f	2010-08-06	4348	\N	104237	\N
105114	GENERIC_DAY	2	7200	f	2010-07-27	4358	\N	104237	\N
105115	GENERIC_DAY	2	0	f	2010-07-11	4344	\N	104237	\N
105116	GENERIC_DAY	2	0	f	2010-07-18	4344	\N	104237	\N
105117	GENERIC_DAY	2	7200	f	2010-07-13	4344	\N	104237	\N
105118	GENERIC_DAY	2	0	f	2010-08-01	4358	\N	104237	\N
105119	GENERIC_DAY	2	7200	f	2010-08-05	4348	\N	104237	\N
105120	GENERIC_DAY	2	7200	f	2010-07-29	4350	\N	104237	\N
105121	GENERIC_DAY	2	7200	f	2010-07-30	4348	\N	104237	\N
105122	GENERIC_DAY	2	0	f	2010-07-17	4358	\N	104237	\N
105123	GENERIC_DAY	2	7200	f	2010-08-02	4350	\N	104237	\N
105124	GENERIC_DAY	2	0	f	2010-07-10	4348	\N	104237	\N
105125	GENERIC_DAY	2	3600	f	2010-07-13	4358	\N	104237	\N
105126	GENERIC_DAY	2	0	f	2010-07-14	4344	\N	104237	\N
105127	GENERIC_DAY	2	7200	f	2010-07-29	4358	\N	104237	\N
105128	GENERIC_DAY	2	7200	f	2010-08-04	4350	\N	104237	\N
105129	GENERIC_DAY	2	0	f	2010-07-10	4344	\N	104237	\N
105130	GENERIC_DAY	2	7200	f	2010-08-06	4350	\N	104237	\N
105131	GENERIC_DAY	2	7200	f	2010-07-27	4348	\N	104237	\N
105132	GENERIC_DAY	2	3600	f	2010-07-12	4358	\N	104237	\N
105133	GENERIC_DAY	2	7200	f	2010-08-03	4348	\N	104237	\N
105134	GENERIC_DAY	2	10800	f	2010-07-15	4358	\N	104237	\N
105135	GENERIC_DAY	2	7200	f	2010-07-09	4344	\N	104237	\N
105136	GENERIC_DAY	2	7200	f	2010-07-20	4350	\N	104237	\N
105137	GENERIC_DAY	2	7200	f	2010-07-09	4348	\N	104237	\N
105138	GENERIC_DAY	2	7200	f	2010-07-19	4348	\N	104237	\N
105139	GENERIC_DAY	2	10800	f	2010-07-06	4348	\N	104237	\N
105140	GENERIC_DAY	2	0	f	2010-07-05	4350	\N	104237	\N
105141	GENERIC_DAY	2	7200	f	2010-07-19	4344	\N	104237	\N
105142	GENERIC_DAY	2	7200	f	2010-07-07	4358	\N	104237	\N
105143	GENERIC_DAY	2	7200	f	2010-07-19	4358	\N	104237	\N
105144	GENERIC_DAY	2	10800	f	2010-07-14	4358	\N	104237	\N
105145	GENERIC_DAY	2	3600	f	2010-07-28	4350	\N	104237	\N
105146	GENERIC_DAY	2	7200	f	2010-08-05	4350	\N	104237	\N
105147	GENERIC_DAY	2	10800	f	2010-07-16	4358	\N	104237	\N
105148	GENERIC_DAY	2	0	f	2010-07-07	4344	\N	104237	\N
105149	GENERIC_DAY	2	0	f	2010-07-15	4344	\N	104237	\N
105150	GENERIC_DAY	2	0	f	2010-07-24	4348	\N	104237	\N
105151	GENERIC_DAY	2	7200	f	2010-07-27	4350	\N	104237	\N
105152	GENERIC_DAY	2	7200	f	2010-07-13	4350	\N	104237	\N
105153	GENERIC_DAY	2	0	f	2010-07-11	21817	\N	104237	\N
105154	GENERIC_DAY	2	7200	f	2010-08-02	4348	\N	104237	\N
105155	GENERIC_DAY	2	0	f	2010-07-25	4350	\N	104237	\N
105156	GENERIC_DAY	2	7200	f	2010-07-05	4358	\N	104237	\N
105157	GENERIC_DAY	2	7200	f	2010-07-23	4350	\N	104237	\N
105158	GENERIC_DAY	2	7200	f	2010-07-26	4344	\N	104237	\N
105159	GENERIC_DAY	2	0	f	2010-07-10	4350	\N	104237	\N
105160	GENERIC_DAY	2	7200	f	2010-08-06	4358	\N	104237	\N
105161	GENERIC_DAY	2	7200	f	2010-07-29	4344	\N	104237	\N
105162	GENERIC_DAY	2	7200	f	2010-07-12	4348	\N	104237	\N
105163	GENERIC_DAY	2	0	f	2010-07-11	4350	\N	104237	\N
105164	GENERIC_DAY	2	7200	f	2010-07-16	4350	\N	104237	\N
105165	GENERIC_DAY	2	0	f	2010-07-06	4344	\N	104237	\N
105166	GENERIC_DAY	2	0	f	2010-08-01	4350	\N	104237	\N
105167	GENERIC_DAY	2	0	f	2010-07-10	21817	\N	104237	\N
105168	GENERIC_DAY	2	10800	f	2010-07-06	21817	\N	104237	\N
105169	GENERIC_DAY	2	3600	f	2010-07-13	21817	\N	104237	\N
105170	GENERIC_DAY	2	7200	f	2010-07-08	21817	\N	104237	\N
105171	GENERIC_DAY	2	7200	f	2010-07-20	4348	\N	104237	\N
105172	GENERIC_DAY	2	7200	f	2010-07-08	4350	\N	104237	\N
105173	GENERIC_DAY	2	7200	f	2010-08-02	4358	\N	104237	\N
105174	GENERIC_DAY	2	10800	f	2010-07-16	4348	\N	104237	\N
105175	GENERIC_DAY	2	0	f	2010-07-31	4348	\N	104237	\N
105176	GENERIC_DAY	2	10800	f	2010-07-07	21817	\N	104237	\N
105177	GENERIC_DAY	2	0	f	2010-07-31	4344	\N	104237	\N
105178	GENERIC_DAY	2	7200	f	2010-07-13	4348	\N	104237	\N
105179	GENERIC_DAY	2	0	f	2010-07-16	4344	\N	104237	\N
105180	GENERIC_DAY	2	0	f	2010-07-17	4348	\N	104237	\N
105181	GENERIC_DAY	2	10800	f	2010-07-05	4348	\N	104237	\N
105182	GENERIC_DAY	2	7200	f	2010-07-05	21817	\N	104237	\N
105183	GENERIC_DAY	2	7200	f	2010-07-08	4358	\N	104237	\N
105184	GENERIC_DAY	2	7200	f	2010-07-19	4350	\N	104237	\N
105185	GENERIC_DAY	2	7200	f	2010-08-03	4350	\N	104237	\N
105186	GENERIC_DAY	2	7200	f	2010-07-27	4344	\N	104237	\N
105187	GENERIC_DAY	2	0	f	2010-07-06	4350	\N	104237	\N
105188	GENERIC_DAY	2	7200	f	2010-07-15	4350	\N	104237	\N
105189	GENERIC_DAY	2	0	f	2010-07-31	4358	\N	104237	\N
105190	GENERIC_DAY	2	0	f	2010-07-24	4358	\N	104237	\N
105191	GENERIC_DAY	2	0	f	2010-07-25	4348	\N	104237	\N
105192	GENERIC_DAY	2	3600	f	2010-07-09	21817	\N	104237	\N
105193	GENERIC_DAY	2	7200	f	2010-07-08	4348	\N	104237	\N
105194	GENERIC_DAY	2	7200	f	2010-07-22	4358	\N	104237	\N
105195	GENERIC_DAY	2	0	f	2010-07-18	4348	\N	104237	\N
105196	GENERIC_DAY	2	7200	f	2010-07-30	4344	\N	104237	\N
105197	GENERIC_DAY	2	7200	f	2010-07-09	4350	\N	104237	\N
105198	GENERIC_DAY	2	0	f	2010-07-24	4350	\N	104237	\N
105199	GENERIC_DAY	2	10800	f	2010-07-07	4348	\N	104237	\N
149460	GENERIC_DAY	4	10800	f	2011-01-06	111404	\N	116244	\N
149461	GENERIC_DAY	4	0	f	2011-01-15	111404	\N	116244	\N
149468	GENERIC_DAY	4	0	f	2011-01-01	111406	\N	116244	\N
149488	GENERIC_DAY	4	10800	f	2011-01-12	111404	\N	116244	\N
149456	GENERIC_DAY	4	10800	f	2011-01-19	111404	\N	116244	\N
149471	GENERIC_DAY	4	3600	f	2011-01-10	111406	\N	116244	\N
149489	GENERIC_DAY	4	10800	f	2011-01-17	111404	\N	116244	\N
149451	GENERIC_DAY	4	3600	f	2010-12-30	111406	\N	116244	\N
149473	GENERIC_DAY	4	7200	f	2011-01-11	111406	\N	116244	\N
149486	GENERIC_DAY	4	7200	f	2011-01-11	111404	\N	116244	\N
149453	GENERIC_DAY	4	3600	f	2011-01-14	111406	\N	116244	\N
149472	GENERIC_DAY	4	10800	f	2011-01-05	111404	\N	116244	\N
149466	GENERIC_DAY	4	3600	f	2011-01-19	111406	\N	116244	\N
149457	GENERIC_DAY	4	0	f	2011-01-02	111406	\N	116244	\N
149459	GENERIC_DAY	4	0	f	2011-01-08	111406	\N	116244	\N
149487	GENERIC_DAY	4	3600	f	2011-01-20	111406	\N	116244	\N
149462	GENERIC_DAY	4	10800	f	2011-01-13	111404	\N	116244	\N
149449	GENERIC_DAY	4	10800	f	2011-01-18	111404	\N	116244	\N
149463	GENERIC_DAY	4	7200	f	2011-01-20	111404	\N	116244	\N
149470	GENERIC_DAY	4	0	f	2011-01-08	111404	\N	116244	\N
149465	GENERIC_DAY	4	0	f	2011-01-09	111404	\N	116244	\N
149346	GENERIC_DAY	4	10800	f	2010-12-03	111404	\N	116239	\N
149340	GENERIC_DAY	4	10800	f	2010-12-06	111404	\N	116239	\N
149344	GENERIC_DAY	4	3600	f	2010-12-06	111406	\N	116239	\N
149353	GENERIC_DAY	4	0	f	2010-12-04	111404	\N	116239	\N
149345	GENERIC_DAY	4	3600	f	2010-12-01	111406	\N	116239	\N
149347	GENERIC_DAY	4	10800	f	2010-12-07	111404	\N	116239	\N
149349	GENERIC_DAY	4	10800	f	2010-12-02	111404	\N	116239	\N
149350	GENERIC_DAY	4	10800	f	2010-12-01	111404	\N	116239	\N
149356	GENERIC_DAY	4	0	f	2010-12-05	111406	\N	116239	\N
149352	GENERIC_DAY	4	3600	f	2010-12-02	111406	\N	116239	\N
149339	GENERIC_DAY	4	7200	f	2010-12-08	111406	\N	116239	\N
149351	GENERIC_DAY	4	0	f	2010-12-05	111404	\N	116239	\N
149343	GENERIC_DAY	4	3600	f	2010-12-09	111406	\N	116239	\N
149341	GENERIC_DAY	4	3600	f	2010-12-09	111404	\N	116239	\N
149355	GENERIC_DAY	4	0	f	2010-12-04	111406	\N	116239	\N
149342	GENERIC_DAY	4	3600	f	2010-12-07	111406	\N	116239	\N
149348	GENERIC_DAY	4	7200	f	2010-12-08	111404	\N	116239	\N
149354	GENERIC_DAY	4	3600	f	2010-12-03	111406	\N	116239	\N
112278	GENERIC_DAY	9	3600	f	2011-01-21	111406	\N	112010	\N
112218	GENERIC_DAY	9	3600	f	2010-11-05	111406	\N	112010	\N
112241	GENERIC_DAY	9	3600	f	2010-10-19	111406	\N	112010	\N
112285	GENERIC_DAY	9	3600	f	2010-09-01	111406	\N	112010	\N
112275	GENERIC_DAY	9	3600	f	2010-10-18	111406	\N	112010	\N
112225	GENERIC_DAY	9	3600	f	2010-12-07	111406	\N	112010	\N
112254	GENERIC_DAY	9	3600	f	2010-09-03	111406	\N	112010	\N
112222	GENERIC_DAY	9	3600	f	2011-01-04	111406	\N	112010	\N
112296	GENERIC_DAY	9	3600	f	2010-12-27	111406	\N	112010	\N
112230	GENERIC_DAY	9	3600	f	2010-09-14	111406	\N	112010	\N
112284	GENERIC_DAY	9	3600	f	2011-01-11	111406	\N	112010	\N
112242	GENERIC_DAY	9	3600	f	2010-10-13	111406	\N	112010	\N
112217	GENERIC_DAY	9	3600	f	2010-09-29	111406	\N	112010	\N
112239	GENERIC_DAY	9	3600	f	2010-12-03	111406	\N	112010	\N
112228	GENERIC_DAY	9	3600	f	2011-01-07	111406	\N	112010	\N
112277	GENERIC_DAY	9	3600	f	2010-10-22	111406	\N	112010	\N
112244	GENERIC_DAY	9	3600	f	2010-12-01	111406	\N	112010	\N
112255	GENERIC_DAY	9	3600	f	2010-10-27	111406	\N	112010	\N
112281	GENERIC_DAY	9	3600	f	2010-10-25	111406	\N	112010	\N
112263	GENERIC_DAY	9	3600	f	2010-10-11	111406	\N	112010	\N
112283	GENERIC_DAY	9	3600	f	2010-12-14	111406	\N	112010	\N
112233	GENERIC_DAY	9	3600	f	2010-12-23	111406	\N	112010	\N
112232	GENERIC_DAY	9	3600	f	2011-01-24	111406	\N	112010	\N
112292	GENERIC_DAY	9	3600	f	2010-10-20	111406	\N	112010	\N
112270	GENERIC_DAY	9	3600	f	2010-10-05	111406	\N	112010	\N
112267	GENERIC_DAY	9	3600	f	2010-09-20	111406	\N	112010	\N
112273	GENERIC_DAY	9	3600	f	2010-12-08	111406	\N	112010	\N
112219	GENERIC_DAY	9	3600	f	2011-01-19	111406	\N	112010	\N
112240	GENERIC_DAY	9	3600	f	2010-09-28	111406	\N	112010	\N
112286	GENERIC_DAY	9	3600	f	2010-10-26	111406	\N	112010	\N
112253	GENERIC_DAY	9	3600	f	2011-01-17	111406	\N	112010	\N
112295	GENERIC_DAY	9	3600	f	2010-10-14	111406	\N	112010	\N
112227	GENERIC_DAY	9	3600	f	2010-11-11	111406	\N	112010	\N
112265	GENERIC_DAY	9	3600	f	2011-01-06	111406	\N	112010	\N
112261	GENERIC_DAY	9	3600	f	2010-11-09	111406	\N	112010	\N
112290	GENERIC_DAY	9	3600	f	2010-12-15	111406	\N	112010	\N
112250	GENERIC_DAY	9	3600	f	2010-12-09	111406	\N	112010	\N
112289	GENERIC_DAY	9	3600	f	2010-10-06	111406	\N	112010	\N
112226	GENERIC_DAY	9	3600	f	2011-01-12	111406	\N	112010	\N
112279	GENERIC_DAY	9	3600	f	2010-09-17	111406	\N	112010	\N
112268	GENERIC_DAY	9	3600	f	2010-11-12	111406	\N	112010	\N
112245	GENERIC_DAY	9	3600	f	2010-12-31	111406	\N	112010	\N
112276	GENERIC_DAY	9	3600	f	2011-01-13	111406	\N	112010	\N
112288	GENERIC_DAY	9	3600	f	2010-10-29	111406	\N	112010	\N
112236	GENERIC_DAY	9	3600	f	2010-09-23	111406	\N	112010	\N
112223	GENERIC_DAY	9	3600	f	2010-11-17	111406	\N	112010	\N
112246	GENERIC_DAY	9	3600	f	2010-11-22	111406	\N	112010	\N
112224	GENERIC_DAY	9	3600	f	2011-01-18	111406	\N	112010	\N
112274	GENERIC_DAY	9	3600	f	2010-09-16	111406	\N	112010	\N
112234	GENERIC_DAY	9	3600	f	2010-09-21	111406	\N	112010	\N
112248	GENERIC_DAY	9	3600	f	2010-11-04	111406	\N	112010	\N
112260	GENERIC_DAY	9	3600	f	2010-11-16	111406	\N	112010	\N
112235	GENERIC_DAY	9	3600	f	2010-10-07	111406	\N	112010	\N
112229	GENERIC_DAY	9	3600	f	2010-09-08	111406	\N	112010	\N
112243	GENERIC_DAY	9	3600	f	2010-12-22	111406	\N	112010	\N
112280	GENERIC_DAY	9	3600	f	2010-11-02	111406	\N	112010	\N
112297	GENERIC_DAY	9	3600	f	2010-11-18	111406	\N	112010	\N
112221	GENERIC_DAY	9	3600	f	2010-11-10	111406	\N	112010	\N
112266	GENERIC_DAY	9	3600	f	2010-12-13	111406	\N	112010	\N
112291	GENERIC_DAY	9	3600	f	2010-12-30	111406	\N	112010	\N
112249	GENERIC_DAY	9	3600	f	2010-11-01	111406	\N	112010	\N
112264	GENERIC_DAY	9	3600	f	2010-12-17	111406	\N	112010	\N
112287	GENERIC_DAY	9	3600	f	2010-11-25	111406	\N	112010	\N
112220	GENERIC_DAY	9	3600	f	2010-12-06	111406	\N	112010	\N
112271	GENERIC_DAY	9	3600	f	2010-12-02	111406	\N	112010	\N
112231	GENERIC_DAY	9	3600	f	2010-12-28	111406	\N	112010	\N
112294	GENERIC_DAY	9	3600	f	2010-12-20	111406	\N	112010	\N
112536	GENERIC_DAY	7	18000	f	2010-09-14	111404	\N	112013	\N
112523	GENERIC_DAY	7	18000	f	2010-09-16	111404	\N	112013	\N
112535	GENERIC_DAY	7	18000	f	2010-09-29	111404	\N	112013	\N
112534	GENERIC_DAY	7	0	f	2010-09-25	111404	\N	112013	\N
112531	GENERIC_DAY	7	18000	f	2010-09-13	111404	\N	112013	\N
112519	GENERIC_DAY	7	0	f	2010-09-18	111404	\N	112013	\N
112530	GENERIC_DAY	7	0	f	2010-09-12	111404	\N	112013	\N
112533	GENERIC_DAY	7	0	f	2010-09-26	111404	\N	112013	\N
112529	GENERIC_DAY	7	10800	f	2010-09-21	111406	\N	112013	\N
112538	GENERIC_DAY	7	10800	f	2010-09-24	111406	\N	112013	\N
112520	GENERIC_DAY	7	10800	f	2010-09-27	111406	\N	112013	\N
112527	GENERIC_DAY	7	10800	f	2010-09-20	111406	\N	112013	\N
112526	GENERIC_DAY	7	0	f	2010-09-11	111406	\N	112013	\N
112528	GENERIC_DAY	7	10800	f	2010-09-28	111406	\N	112013	\N
112532	GENERIC_DAY	7	18000	f	2010-09-20	111404	\N	112013	\N
112522	GENERIC_DAY	7	10800	f	2010-09-16	111406	\N	112013	\N
112537	GENERIC_DAY	7	18000	f	2010-09-21	111404	\N	112013	\N
112521	GENERIC_DAY	7	10800	f	2010-09-15	111406	\N	112013	\N
112525	GENERIC_DAY	7	18000	f	2010-09-15	111404	\N	112013	\N
112524	GENERIC_DAY	7	0	f	2010-09-18	111406	\N	112013	\N
149506	GENERIC_DAY	4	14400	f	2010-11-19	111404	\N	116245	\N
149509	GENERIC_DAY	4	3600	f	2010-11-18	111406	\N	116245	\N
149494	GENERIC_DAY	4	3600	f	2010-11-12	111406	\N	116245	\N
149499	GENERIC_DAY	4	7200	f	2010-11-15	111406	\N	116245	\N
149495	GENERIC_DAY	4	3600	f	2010-11-19	111406	\N	116245	\N
149507	GENERIC_DAY	4	10800	f	2010-11-16	111404	\N	116245	\N
149510	GENERIC_DAY	4	10800	f	2010-11-15	111404	\N	116245	\N
149497	GENERIC_DAY	4	0	f	2010-11-14	111404	\N	116245	\N
149504	GENERIC_DAY	4	7200	f	2010-11-16	111406	\N	116245	\N
149500	GENERIC_DAY	4	0	f	2010-11-14	111406	\N	116245	\N
149501	GENERIC_DAY	4	0	f	2010-11-13	111404	\N	116245	\N
149516	GENERIC_DAY	4	7200	f	2010-11-30	111404	\N	116246	\N
149524	GENERIC_DAY	4	7200	f	2010-11-25	111406	\N	116246	\N
149515	GENERIC_DAY	4	10800	f	2010-11-22	111404	\N	116246	\N
149528	GENERIC_DAY	4	10800	f	2010-11-29	111406	\N	116246	\N
149530	GENERIC_DAY	4	0	f	2010-11-27	111404	\N	116246	\N
149529	GENERIC_DAY	4	0	f	2010-11-21	111404	\N	116246	\N
149513	GENERIC_DAY	4	0	f	2010-11-28	111406	\N	116246	\N
149517	GENERIC_DAY	4	7200	f	2010-11-22	111406	\N	116246	\N
149532	GENERIC_DAY	4	7200	f	2010-11-23	111406	\N	116246	\N
149518	GENERIC_DAY	4	7200	f	2010-11-29	111404	\N	116246	\N
149527	GENERIC_DAY	4	10800	f	2010-11-23	111404	\N	116246	\N
149522	GENERIC_DAY	4	0	f	2010-11-20	111406	\N	116246	\N
149525	GENERIC_DAY	4	10800	f	2010-11-26	111404	\N	116246	\N
149512	GENERIC_DAY	4	7200	f	2010-11-24	111406	\N	116246	\N
149514	GENERIC_DAY	4	10800	f	2010-11-25	111404	\N	116246	\N
149511	GENERIC_DAY	4	0	f	2010-11-21	111406	\N	116246	\N
149531	GENERIC_DAY	4	10800	f	2010-11-24	111404	\N	116246	\N
149519	GENERIC_DAY	4	0	f	2010-11-20	111404	\N	116246	\N
149523	GENERIC_DAY	4	7200	f	2010-11-26	111406	\N	116246	\N
149520	GENERIC_DAY	4	0	f	2010-11-28	111404	\N	116246	\N
149521	GENERIC_DAY	4	10800	f	2010-11-30	111406	\N	116246	\N
149526	GENERIC_DAY	4	0	f	2010-11-27	111406	\N	116246	\N
149293	GENERIC_DAY	4	10800	f	2010-09-13	111406	\N	116236	\N
149285	GENERIC_DAY	4	7200	f	2010-09-10	111404	\N	116236	\N
149297	GENERIC_DAY	4	10800	f	2010-09-17	111406	\N	116236	\N
149286	GENERIC_DAY	4	10800	f	2010-09-24	111406	\N	116236	\N
149291	GENERIC_DAY	4	7200	f	2010-09-24	111404	\N	116236	\N
149296	GENERIC_DAY	4	7200	f	2010-09-13	111404	\N	116236	\N
149287	GENERIC_DAY	4	10800	f	2010-09-20	111406	\N	116236	\N
149295	GENERIC_DAY	4	10800	f	2010-09-22	111406	\N	116236	\N
149298	GENERIC_DAY	4	0	f	2010-09-19	111404	\N	116236	\N
149290	GENERIC_DAY	4	7200	f	2010-09-20	111404	\N	116236	\N
149292	GENERIC_DAY	4	10800	f	2010-09-21	111406	\N	116236	\N
149238	GENERIC_DAY	4	0	f	2010-11-06	111404	\N	116235	\N
149254	GENERIC_DAY	4	10800	f	2010-11-01	111404	\N	116235	\N
149245	GENERIC_DAY	4	7200	f	2010-10-22	111406	\N	116235	\N
149255	GENERIC_DAY	4	10800	f	2010-10-28	111404	\N	116235	\N
149239	GENERIC_DAY	4	10800	f	2010-10-25	111404	\N	116235	\N
149248	GENERIC_DAY	4	0	f	2010-10-30	111404	\N	116235	\N
149253	GENERIC_DAY	4	10800	f	2010-10-27	111404	\N	116235	\N
149237	GENERIC_DAY	4	10800	f	2010-11-04	111406	\N	116235	\N
149247	GENERIC_DAY	4	7200	f	2010-11-02	111406	\N	116235	\N
149233	GENERIC_DAY	4	3600	f	2010-11-08	111406	\N	116235	\N
149249	GENERIC_DAY	4	7200	f	2010-10-21	111406	\N	116235	\N
149252	GENERIC_DAY	4	0	f	2010-10-23	111404	\N	116235	\N
149251	GENERIC_DAY	4	0	f	2010-11-07	111406	\N	116235	\N
149236	GENERIC_DAY	4	10800	f	2010-10-26	111404	\N	116235	\N
149243	GENERIC_DAY	4	0	f	2010-10-31	111406	\N	116235	\N
149242	GENERIC_DAY	4	0	f	2010-10-24	111404	\N	116235	\N
149935	GENERIC_DAY	1	0	f	2011-01-23	111406	\N	128597	\N
149929	GENERIC_DAY	1	14400	f	2011-01-20	111406	\N	128597	\N
149933	GENERIC_DAY	1	18000	f	2011-01-25	111404	\N	128597	\N
149928	GENERIC_DAY	1	0	f	2011-01-23	111404	\N	128597	\N
149942	GENERIC_DAY	1	18000	f	2011-01-21	111404	\N	128597	\N
149937	GENERIC_DAY	1	10800	f	2011-01-24	111406	\N	128597	\N
149931	GENERIC_DAY	1	14400	f	2011-01-20	111404	\N	128597	\N
149934	GENERIC_DAY	1	10800	f	2011-01-21	111406	\N	128597	\N
149943	GENERIC_DAY	1	14400	f	2011-01-27	111404	\N	128597	\N
149936	GENERIC_DAY	1	14400	f	2011-01-19	111406	\N	128597	\N
149927	GENERIC_DAY	1	14400	f	2011-01-26	111404	\N	128597	\N
149938	GENERIC_DAY	1	14400	f	2011-01-26	111406	\N	128597	\N
149940	GENERIC_DAY	1	18000	f	2011-01-24	111404	\N	128597	\N
149932	GENERIC_DAY	1	14400	f	2011-01-19	111404	\N	128597	\N
149930	GENERIC_DAY	1	0	f	2011-01-22	111406	\N	128597	\N
149939	GENERIC_DAY	1	10800	f	2011-01-25	111406	\N	128597	\N
149944	GENERIC_DAY	1	7200	f	2011-01-28	111404	\N	128597	\N
149941	GENERIC_DAY	1	14400	f	2011-01-27	111406	\N	128597	\N
112419	GENERIC_DAY	8	3600	f	2010-11-02	111404	\N	112011	\N
112446	GENERIC_DAY	8	3600	f	2010-09-27	111404	\N	112011	\N
112457	GENERIC_DAY	8	3600	f	2010-10-13	111404	\N	112011	\N
112439	GENERIC_DAY	8	3600	f	2010-09-22	111404	\N	112011	\N
112309	GENERIC_DAY	8	3600	f	2010-10-29	111404	\N	112011	\N
112435	GENERIC_DAY	8	3600	f	2010-09-01	111404	\N	112011	\N
112432	GENERIC_DAY	8	3600	f	2010-12-03	111404	\N	112011	\N
112441	GENERIC_DAY	8	3600	f	2010-09-17	111404	\N	112011	\N
112465	GENERIC_DAY	8	3600	f	2010-11-30	111404	\N	112011	\N
112442	GENERIC_DAY	8	3600	f	2010-10-19	111404	\N	112011	\N
112425	GENERIC_DAY	8	3600	f	2010-11-18	111404	\N	112011	\N
112438	GENERIC_DAY	8	3600	f	2010-10-12	111404	\N	112011	\N
112468	GENERIC_DAY	8	3600	f	2010-09-02	111404	\N	112011	\N
112454	GENERIC_DAY	8	3600	f	2010-09-07	111404	\N	112011	\N
112427	GENERIC_DAY	8	3600	f	2010-09-16	111404	\N	112011	\N
112429	GENERIC_DAY	8	3600	f	2010-10-25	111404	\N	112011	\N
112472	GENERIC_DAY	8	3600	f	2010-09-10	111404	\N	112011	\N
112443	GENERIC_DAY	8	3600	f	2010-10-28	111404	\N	112011	\N
112448	GENERIC_DAY	8	3600	f	2010-11-25	111404	\N	112011	\N
112417	GENERIC_DAY	8	3600	f	2010-11-08	111404	\N	112011	\N
112308	GENERIC_DAY	8	3600	f	2010-09-14	111404	\N	112011	\N
112458	GENERIC_DAY	8	3600	f	2010-09-28	111404	\N	112011	\N
112420	GENERIC_DAY	8	3600	f	2010-09-03	111404	\N	112011	\N
112452	GENERIC_DAY	8	3600	f	2010-11-17	111404	\N	112011	\N
112413	GENERIC_DAY	8	3600	f	2010-09-08	111404	\N	112011	\N
112418	GENERIC_DAY	8	3600	f	2010-11-09	111404	\N	112011	\N
112455	GENERIC_DAY	8	3600	f	2010-09-13	111404	\N	112011	\N
112307	GENERIC_DAY	8	3600	f	2010-10-01	111404	\N	112011	\N
112451	GENERIC_DAY	8	3600	f	2010-10-21	111404	\N	112011	\N
112424	GENERIC_DAY	8	3600	f	2010-10-15	111404	\N	112011	\N
112434	GENERIC_DAY	8	3600	f	2010-10-06	111404	\N	112011	\N
112311	GENERIC_DAY	8	3600	f	2010-11-05	111404	\N	112011	\N
112467	GENERIC_DAY	8	3600	f	2010-09-23	111404	\N	112011	\N
112436	GENERIC_DAY	8	3600	f	2010-09-06	111404	\N	112011	\N
112447	GENERIC_DAY	8	3600	f	2010-11-19	111404	\N	112011	\N
112421	GENERIC_DAY	8	3600	f	2010-10-04	111404	\N	112011	\N
112471	GENERIC_DAY	8	3600	f	2010-09-29	111404	\N	112011	\N
112462	GENERIC_DAY	8	3600	f	2010-11-11	111404	\N	112011	\N
112469	GENERIC_DAY	8	3600	f	2010-11-04	111404	\N	112011	\N
112415	GENERIC_DAY	8	3600	f	2010-11-29	111404	\N	112011	\N
112464	GENERIC_DAY	8	3600	f	2010-09-15	111404	\N	112011	\N
112426	GENERIC_DAY	8	3600	f	2010-11-23	111404	\N	112011	\N
112460	GENERIC_DAY	8	3600	f	2010-11-03	111404	\N	112011	\N
112466	GENERIC_DAY	8	3600	f	2010-09-30	111404	\N	112011	\N
112428	GENERIC_DAY	8	3600	f	2010-10-07	111404	\N	112011	\N
112310	GENERIC_DAY	8	3600	f	2010-12-07	111404	\N	112011	\N
112440	GENERIC_DAY	8	3600	f	2010-11-22	111404	\N	112011	\N
112437	GENERIC_DAY	8	3600	f	2010-10-27	111404	\N	112011	\N
112453	GENERIC_DAY	8	3600	f	2010-09-24	111404	\N	112011	\N
112414	GENERIC_DAY	8	3600	f	2010-12-06	111404	\N	112011	\N
112445	GENERIC_DAY	8	3600	f	2010-10-26	111404	\N	112011	\N
112416	GENERIC_DAY	8	3600	f	2010-10-22	111404	\N	112011	\N
112430	GENERIC_DAY	8	3600	f	2010-10-14	111404	\N	112011	\N
112449	GENERIC_DAY	8	3600	f	2010-11-15	111404	\N	112011	\N
112306	GENERIC_DAY	8	3600	f	2010-10-11	111404	\N	112011	\N
112463	GENERIC_DAY	8	3600	f	2010-12-02	111404	\N	112011	\N
112470	GENERIC_DAY	8	3600	f	2010-09-09	111404	\N	112011	\N
112422	GENERIC_DAY	8	3600	f	2010-11-12	111404	\N	112011	\N
112459	GENERIC_DAY	8	3600	f	2010-10-08	111404	\N	112011	\N
112444	GENERIC_DAY	8	3600	f	2010-10-05	111404	\N	112011	\N
112423	GENERIC_DAY	8	3600	f	2010-12-01	111404	\N	112011	\N
112456	GENERIC_DAY	8	3600	f	2010-09-21	111404	\N	112011	\N
112461	GENERIC_DAY	8	3600	f	2010-11-01	111404	\N	112011	\N
112433	GENERIC_DAY	8	3600	f	2010-11-26	111404	\N	112011	\N
112431	GENERIC_DAY	8	3600	f	2010-11-10	111404	\N	112011	\N
112450	GENERIC_DAY	8	3600	f	2010-11-16	111404	\N	112011	\N
128814	GENERIC_DAY	5	0	f	2010-10-24	111406	\N	128590	\N
128811	GENERIC_DAY	5	10800	f	2010-10-25	111406	\N	128590	\N
128812	GENERIC_DAY	5	14400	f	2010-10-25	111404	\N	128590	\N
128813	GENERIC_DAY	5	14400	f	2010-10-26	111404	\N	128590	\N
128818	GENERIC_DAY	5	10800	f	2010-10-28	111406	\N	128591	\N
128819	GENERIC_DAY	5	0	f	2010-10-30	111404	\N	128591	\N
128823	GENERIC_DAY	5	0	f	2010-10-30	111406	\N	128591	\N
128816	GENERIC_DAY	5	10800	f	2010-10-29	111406	\N	128591	\N
128815	GENERIC_DAY	5	0	f	2010-10-31	111404	\N	128591	\N
128817	GENERIC_DAY	5	0	f	2010-10-31	111406	\N	128591	\N
128824	GENERIC_DAY	5	14400	f	2010-10-28	111404	\N	128591	\N
128821	GENERIC_DAY	5	10800	f	2010-11-01	111406	\N	128591	\N
128820	GENERIC_DAY	5	14400	f	2010-11-01	111404	\N	128591	\N
128822	GENERIC_DAY	5	14400	f	2010-10-29	111404	\N	128591	\N
128826	GENERIC_DAY	5	10800	f	2010-11-04	111404	\N	128592	\N
128828	GENERIC_DAY	5	10800	f	2010-11-03	111406	\N	128592	\N
128825	GENERIC_DAY	5	14400	f	2010-11-04	111406	\N	128592	\N
128829	GENERIC_DAY	5	14400	f	2010-11-02	111404	\N	128592	\N
128830	GENERIC_DAY	5	10800	f	2010-11-02	111406	\N	128592	\N
128827	GENERIC_DAY	5	14400	f	2010-11-03	111404	\N	128592	\N
128839	GENERIC_DAY	5	0	f	2010-11-07	111406	\N	128593	\N
128838	GENERIC_DAY	5	14400	f	2010-11-05	111406	\N	128593	\N
128836	GENERIC_DAY	5	14400	f	2010-11-09	111406	\N	128593	\N
128835	GENERIC_DAY	5	14400	f	2010-11-08	111406	\N	128593	\N
128840	GENERIC_DAY	5	10800	f	2010-11-05	111404	\N	128593	\N
128831	GENERIC_DAY	5	0	f	2010-11-06	111404	\N	128593	\N
128833	GENERIC_DAY	5	0	f	2010-11-07	111404	\N	128593	\N
128837	GENERIC_DAY	5	10800	f	2010-11-09	111404	\N	128593	\N
128834	GENERIC_DAY	5	10800	f	2010-11-08	111404	\N	128593	\N
151804	GENERIC_DAY	0	0	f	2010-12-05	111404	\N	128584	\N
151805	GENERIC_DAY	0	0	f	2010-11-27	111406	\N	128584	\N
151806	GENERIC_DAY	0	18000	f	2010-11-30	111404	\N	128584	\N
151807	GENERIC_DAY	0	0	f	2010-11-27	111404	\N	128584	\N
151808	GENERIC_DAY	0	14400	f	2010-12-01	111404	\N	128584	\N
151809	GENERIC_DAY	0	0	f	2010-10-03	111406	\N	128585	\N
151810	GENERIC_DAY	0	14400	f	2010-10-04	111406	\N	128585	\N
151811	GENERIC_DAY	0	10800	f	2010-10-05	111404	\N	128585	\N
151812	GENERIC_DAY	0	0	f	2010-10-03	111404	\N	128585	\N
151813	GENERIC_DAY	0	0	f	2010-10-02	111406	\N	128585	\N
151814	GENERIC_DAY	0	14400	f	2010-10-05	111406	\N	128585	\N
151815	GENERIC_DAY	0	10800	f	2010-10-04	111404	\N	128585	\N
151816	GENERIC_DAY	0	0	f	2010-10-02	111404	\N	128585	\N
151817	GENERIC_DAY	0	10800	f	2010-10-06	111404	\N	128585	\N
151818	GENERIC_DAY	0	14400	f	2010-10-06	111406	\N	128585	\N
151819	GENERIC_DAY	0	10800	f	2010-10-08	111404	\N	128586	\N
151820	GENERIC_DAY	0	18000	f	2010-10-07	111404	\N	128586	\N
151821	GENERIC_DAY	0	14400	f	2010-10-08	111406	\N	128586	\N
151822	GENERIC_DAY	0	0	f	2010-10-10	111406	\N	128586	\N
151823	GENERIC_DAY	0	10800	f	2010-10-11	111404	\N	128586	\N
151824	GENERIC_DAY	0	0	f	2010-10-09	111406	\N	128586	\N
151825	GENERIC_DAY	0	7200	f	2010-10-07	111406	\N	128586	\N
151826	GENERIC_DAY	0	14400	f	2010-10-11	111406	\N	128586	\N
151827	GENERIC_DAY	0	0	f	2010-10-10	111404	\N	128586	\N
151828	GENERIC_DAY	0	0	f	2010-10-09	111404	\N	128586	\N
151829	GENERIC_DAY	0	0	f	2010-11-20	111406	\N	151306	\N
151830	GENERIC_DAY	0	14400	f	2010-11-16	111404	\N	151306	\N
151831	GENERIC_DAY	0	10800	f	2010-11-25	111404	\N	151306	\N
151832	GENERIC_DAY	0	14400	f	2010-11-17	111406	\N	151306	\N
151833	GENERIC_DAY	0	14400	f	2010-11-15	111404	\N	151306	\N
151834	GENERIC_DAY	0	14400	f	2010-11-22	111406	\N	151306	\N
151835	GENERIC_DAY	0	14400	f	2010-11-15	111406	\N	151306	\N
151836	GENERIC_DAY	0	14400	f	2010-11-23	111406	\N	151306	\N
112262	GENERIC_DAY	9	3600	f	2010-11-26	111406	\N	112010	\N
112293	GENERIC_DAY	9	3600	f	2010-11-03	111406	\N	112010	\N
112269	GENERIC_DAY	9	3600	f	2010-09-24	111406	\N	112010	\N
112256	GENERIC_DAY	9	3600	f	2010-11-19	111406	\N	112010	\N
112237	GENERIC_DAY	9	3600	f	2010-11-15	111406	\N	112010	\N
112272	GENERIC_DAY	9	3600	f	2010-11-08	111406	\N	112010	\N
112259	GENERIC_DAY	9	3600	f	2010-09-02	111406	\N	112010	\N
112238	GENERIC_DAY	9	3600	f	2010-09-13	111406	\N	112010	\N
112247	GENERIC_DAY	9	3600	f	2010-10-12	111406	\N	112010	\N
112282	GENERIC_DAY	9	3600	f	2011-01-05	111406	\N	112010	\N
112251	GENERIC_DAY	9	3600	f	2010-12-16	111406	\N	112010	\N
112258	GENERIC_DAY	9	3600	f	2010-12-29	111406	\N	112010	\N
112252	GENERIC_DAY	9	3600	f	2010-09-06	111406	\N	112010	\N
112257	GENERIC_DAY	9	3600	f	2010-10-08	111406	\N	112010	\N
166455	GENERIC_DAY	1	28800	f	2010-11-26	151909	\N	160726	\N
166456	GENERIC_DAY	1	28800	f	2010-11-24	151909	\N	160726	\N
166457	GENERIC_DAY	1	14400	f	2010-12-08	151909	\N	160726	\N
166458	GENERIC_DAY	1	0	f	2010-11-20	151909	\N	160726	\N
166459	GENERIC_DAY	1	0	f	2010-12-04	151909	\N	160726	\N
166460	GENERIC_DAY	1	0	f	2010-11-27	151909	\N	160726	\N
166461	GENERIC_DAY	1	28800	f	2010-12-03	151909	\N	160726	\N
166462	GENERIC_DAY	1	0	f	2010-12-05	151909	\N	160726	\N
166463	GENERIC_DAY	1	28800	f	2010-11-30	151909	\N	160726	\N
166464	GENERIC_DAY	1	28800	f	2010-12-02	151909	\N	160726	\N
166465	GENERIC_DAY	1	28800	f	2010-12-01	151909	\N	160726	\N
166466	GENERIC_DAY	1	28800	f	2010-12-06	151909	\N	160726	\N
166467	GENERIC_DAY	1	28800	f	2010-11-25	151909	\N	160726	\N
166468	GENERIC_DAY	1	28800	f	2010-12-07	151909	\N	160726	\N
166469	GENERIC_DAY	1	28800	f	2010-11-29	151909	\N	160726	\N
166470	GENERIC_DAY	1	0	f	2010-11-21	151909	\N	160726	\N
166471	GENERIC_DAY	1	28800	f	2010-11-23	151909	\N	160726	\N
166472	GENERIC_DAY	1	28800	f	2010-11-22	151909	\N	160726	\N
166473	GENERIC_DAY	1	0	f	2010-11-28	151909	\N	160726	\N
166474	GENERIC_DAY	1	28800	f	2010-11-08	151909	\N	160728	\N
166475	GENERIC_DAY	1	28800	f	2010-11-12	151909	\N	160728	\N
166476	GENERIC_DAY	1	28800	f	2010-11-05	151909	\N	160728	\N
166477	GENERIC_DAY	1	28800	f	2010-11-11	151909	\N	160728	\N
166478	GENERIC_DAY	1	0	f	2010-11-14	151909	\N	160728	\N
166479	GENERIC_DAY	1	28800	f	2010-11-19	151909	\N	160728	\N
166480	GENERIC_DAY	1	0	f	2010-10-23	151909	\N	160728	\N
166481	GENERIC_DAY	1	28800	f	2010-10-25	151909	\N	160728	\N
166482	GENERIC_DAY	1	28800	f	2010-11-18	151909	\N	160728	\N
166483	GENERIC_DAY	1	28800	f	2010-10-21	151909	\N	160728	\N
166484	GENERIC_DAY	1	0	f	2010-11-07	151909	\N	160728	\N
166485	GENERIC_DAY	1	0	f	2010-10-30	151909	\N	160728	\N
166486	GENERIC_DAY	1	28800	f	2010-10-26	151909	\N	160728	\N
166487	GENERIC_DAY	1	28800	f	2010-10-22	151909	\N	160728	\N
166488	GENERIC_DAY	1	0	f	2010-10-24	151909	\N	160728	\N
166489	GENERIC_DAY	1	28800	f	2010-10-28	151909	\N	160728	\N
166490	GENERIC_DAY	1	28800	f	2010-10-18	151909	\N	160728	\N
166491	GENERIC_DAY	1	28800	f	2010-11-09	151909	\N	160728	\N
166492	GENERIC_DAY	1	28800	f	2010-11-02	151909	\N	160728	\N
166493	GENERIC_DAY	1	28800	f	2010-10-29	151909	\N	160728	\N
166494	GENERIC_DAY	1	0	f	2010-11-13	151909	\N	160728	\N
166495	GENERIC_DAY	1	0	f	2010-11-06	151909	\N	160728	\N
166496	GENERIC_DAY	1	28800	f	2010-11-01	151909	\N	160728	\N
166497	GENERIC_DAY	1	0	f	2010-10-16	151909	\N	160728	\N
166498	GENERIC_DAY	1	28800	f	2010-10-19	151909	\N	160728	\N
166499	GENERIC_DAY	1	28800	f	2010-11-15	151909	\N	160728	\N
166500	GENERIC_DAY	1	28800	f	2010-11-03	151909	\N	160728	\N
166501	GENERIC_DAY	1	28800	f	2010-10-27	151909	\N	160728	\N
166502	GENERIC_DAY	1	28800	f	2010-11-17	151909	\N	160728	\N
166503	GENERIC_DAY	1	28800	f	2010-11-16	151909	\N	160728	\N
166504	GENERIC_DAY	1	0	f	2010-10-31	151909	\N	160728	\N
166505	GENERIC_DAY	1	28800	f	2010-11-04	151909	\N	160728	\N
166506	GENERIC_DAY	1	0	f	2010-10-17	151909	\N	160728	\N
166507	GENERIC_DAY	1	28800	f	2010-10-20	151909	\N	160728	\N
166508	GENERIC_DAY	1	28800	f	2010-11-10	151909	\N	160728	\N
166509	GENERIC_DAY	1	50400	f	2011-01-04	154733	\N	160729	\N
166510	GENERIC_DAY	1	21600	f	2010-12-25	154733	\N	160729	\N
166511	GENERIC_DAY	1	54000	f	2010-12-22	154733	\N	160729	\N
166512	GENERIC_DAY	1	54000	f	2010-12-09	154733	\N	160729	\N
166513	GENERIC_DAY	1	50400	f	2010-12-29	154733	\N	160729	\N
166514	GENERIC_DAY	1	21600	f	2011-01-01	154733	\N	160729	\N
166515	GENERIC_DAY	1	54000	f	2010-12-16	154733	\N	160729	\N
166516	GENERIC_DAY	1	50400	f	2010-12-30	154733	\N	160729	\N
166517	GENERIC_DAY	1	50400	f	2010-12-27	154733	\N	160729	\N
166518	GENERIC_DAY	1	21600	f	2011-01-02	154733	\N	160729	\N
166519	GENERIC_DAY	1	21600	f	2010-12-26	154733	\N	160729	\N
166520	GENERIC_DAY	1	54000	f	2010-12-10	154733	\N	160729	\N
166521	GENERIC_DAY	1	54000	f	2010-12-17	154733	\N	160729	\N
166522	GENERIC_DAY	1	50400	f	2010-12-23	154733	\N	160729	\N
166523	GENERIC_DAY	1	50400	f	2011-01-03	154733	\N	160729	\N
166524	GENERIC_DAY	1	54000	f	2010-12-13	154733	\N	160729	\N
166525	GENERIC_DAY	1	25200	f	2010-12-18	154733	\N	160729	\N
166526	GENERIC_DAY	1	54000	f	2010-12-15	154733	\N	160729	\N
166527	GENERIC_DAY	1	25200	f	2010-12-19	154733	\N	160729	\N
166528	GENERIC_DAY	1	54000	f	2010-12-14	154733	\N	160729	\N
166529	GENERIC_DAY	1	25200	f	2010-12-11	154733	\N	160729	\N
166530	GENERIC_DAY	1	54000	f	2010-12-21	154733	\N	160729	\N
166531	GENERIC_DAY	1	50400	f	2010-12-28	154733	\N	160729	\N
166532	GENERIC_DAY	1	25200	f	2010-12-12	154733	\N	160729	\N
166533	GENERIC_DAY	1	54000	f	2010-12-20	154733	\N	160729	\N
166534	GENERIC_DAY	1	18000	f	2010-12-18	154733	\N	160730	\N
166535	GENERIC_DAY	1	46800	f	2010-12-14	154733	\N	160730	\N
166536	GENERIC_DAY	1	43200	f	2010-12-28	154733	\N	160730	\N
166537	GENERIC_DAY	1	46800	f	2010-12-21	154733	\N	160730	\N
166538	GENERIC_DAY	1	46800	f	2010-12-20	154733	\N	160730	\N
166539	GENERIC_DAY	1	43200	f	2010-12-27	154733	\N	160730	\N
166540	GENERIC_DAY	1	14400	f	2011-01-02	154733	\N	160730	\N
166541	GENERIC_DAY	1	18000	f	2010-12-19	154733	\N	160730	\N
166542	GENERIC_DAY	1	46800	f	2010-12-10	154733	\N	160730	\N
166543	GENERIC_DAY	1	46800	f	2010-12-17	154733	\N	160730	\N
166544	GENERIC_DAY	1	43200	f	2010-12-29	154733	\N	160730	\N
166545	GENERIC_DAY	1	18000	f	2010-12-12	154733	\N	160730	\N
166546	GENERIC_DAY	1	43200	f	2011-01-03	154733	\N	160730	\N
166547	GENERIC_DAY	1	43200	f	2010-12-30	154733	\N	160730	\N
166548	GENERIC_DAY	1	46800	f	2010-12-15	154733	\N	160730	\N
166650	GENERIC_DAY	1	46800	f	2010-12-09	154733	\N	160730	\N
166651	GENERIC_DAY	1	46800	f	2010-12-13	154733	\N	160730	\N
166652	GENERIC_DAY	1	46800	f	2010-12-16	154733	\N	160730	\N
166653	GENERIC_DAY	1	14400	f	2011-01-01	154733	\N	160730	\N
166654	GENERIC_DAY	1	43200	f	2011-01-04	154733	\N	160730	\N
166655	GENERIC_DAY	1	43200	f	2010-12-23	154733	\N	160730	\N
166656	GENERIC_DAY	1	14400	f	2010-12-26	154733	\N	160730	\N
166657	GENERIC_DAY	1	14400	f	2010-12-25	154733	\N	160730	\N
166658	GENERIC_DAY	1	46800	f	2010-12-22	154733	\N	160730	\N
166659	GENERIC_DAY	1	18000	f	2010-12-11	154733	\N	160730	\N
163966	SPECIFIC_DAY	3	3600	f	2010-09-18	151915	159582	\N	\N
164016	SPECIFIC_DAY	3	10800	f	2010-10-08	151915	159582	\N	\N
163965	SPECIFIC_DAY	3	10800	f	2010-09-30	151915	159582	\N	\N
164002	SPECIFIC_DAY	3	10800	f	2010-10-04	151915	159582	\N	\N
163982	SPECIFIC_DAY	3	10800	f	2010-10-09	151915	159582	\N	\N
164017	SPECIFIC_DAY	3	10800	f	2010-10-07	151915	159582	\N	\N
164014	SPECIFIC_DAY	3	3600	f	2010-09-08	151915	159582	\N	\N
163991	SPECIFIC_DAY	3	3600	f	2010-09-06	151915	159582	\N	\N
163990	SPECIFIC_DAY	3	3600	f	2010-09-12	151915	159582	\N	\N
163979	SPECIFIC_DAY	3	14400	f	2010-10-20	151915	159582	\N	\N
164003	SPECIFIC_DAY	3	21600	f	2010-11-14	151915	159582	\N	\N
163978	SPECIFIC_DAY	3	10800	f	2010-10-14	151915	159582	\N	\N
163972	SPECIFIC_DAY	3	3600	f	2010-09-25	151915	159582	\N	\N
164000	SPECIFIC_DAY	3	14400	f	2010-10-19	151915	159582	\N	\N
164011	SPECIFIC_DAY	3	18000	f	2010-10-28	151915	159582	\N	\N
163980	SPECIFIC_DAY	3	3600	f	2010-09-26	151915	159582	\N	\N
163973	SPECIFIC_DAY	3	3600	f	2010-10-01	151915	159582	\N	\N
163976	SPECIFIC_DAY	3	18000	f	2010-10-30	151915	159582	\N	\N
164019	SPECIFIC_DAY	3	3600	f	2010-09-24	151915	159582	\N	\N
164008	SPECIFIC_DAY	3	10800	f	2010-09-27	151915	159582	\N	\N
163981	SPECIFIC_DAY	3	10800	f	2010-10-02	151915	159582	\N	\N
163988	SPECIFIC_DAY	3	10800	f	2010-10-11	151915	159582	\N	\N
163994	SPECIFIC_DAY	3	3600	f	2010-09-19	151915	159582	\N	\N
163999	SPECIFIC_DAY	3	14400	f	2010-10-23	151915	159582	\N	\N
164010	SPECIFIC_DAY	3	10800	f	2010-10-12	151915	159582	\N	\N
163998	SPECIFIC_DAY	3	18000	f	2010-10-25	151915	159582	\N	\N
163985	SPECIFIC_DAY	3	3600	f	2010-09-15	151915	159582	\N	\N
164015	SPECIFIC_DAY	3	21600	f	2010-11-15	151915	159582	\N	\N
164013	SPECIFIC_DAY	3	21600	f	2010-11-01	151915	159582	\N	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, queue_dependency, type) FROM stdin;
8716297	1	26480	26481	\N	0
8716298	1	26477	26480	\N	0
8716299	1	26470	26475	\N	0
8716300	1	26471	26473	\N	0
8716301	1	26472	26476	\N	0
8716302	1	26473	26478	\N	0
8716305	8	26484	26485	38179	0
8716303	9	26484	26490	38180	0
8716304	9	26487	26488	38178	0
27066370	2	26487	83027	86052	0
5537800	7	5464	5465	\N	0
4620295	9	5455	5456	\N	0
4620296	9	5456	5457	\N	0
4620297	9	5457	5463	\N	0
4620298	9	5459	5460	\N	0
27066371	0	5459	5454	\N	0
27066380	2	83057	83058	\N	0
8716336	5	26519	26520	\N	0
8716334	5	26516	26519	\N	0
1310720	4	2122	2124	4141	0
786500	13	2121	2122	2525	0
8716337	5	26521	26524	\N	0
8716335	5	26516	26521	\N	0
8716332	5	26514	26515	\N	0
8716333	5	26516	26517	\N	0
8716326	2	26497	26498	\N	0
8716327	2	26494	26497	\N	0
8716328	2	26499	26502	\N	0
8716329	2	26494	26499	\N	0
8716330	2	26492	26493	\N	0
8716331	2	26494	26495	\N	0
786498	14	2124	2125	2528	0
23756801	5	72215	72216	\N	0
23756802	5	72216	72217	\N	0
21037056	1	64741	64742	\N	0
27066369	1	83022	83023	\N	0
27066368	1	83023	83025	\N	0
21037057	1	64743	64744	\N	0
21037058	1	64743	64746	\N	0
21037060	1	64746	64747	\N	0
21037059	1	64743	64748	\N	0
21037061	1	64748	64751	\N	0
8716289	10	26462	26463	\N	0
8716291	10	26467	26468	\N	0
8716290	11	26464	26467	\N	0
8716288	11	26462	26464	\N	0
21037062	1	26468	64755	\N	0
5537806	11	22830	22832	\N	0
5537805	11	22826	22827	\N	0
5537804	12	22828	22829	\N	0
23756803	5	22826	22828	\N	0
36438319	1	109714	109720	\N	0
36438284	8	109693	109694	\N	0
33914896	2	103932	103931	\N	0
33914897	2	103929	103930	\N	0
36438285	8	109694	109695	\N	0
36438286	8	109695	109696	\N	0
36438287	8	109696	109697	\N	0
36438288	8	109697	109698	\N	0
34471943	3	106153	106154	\N	0
34471942	3	106151	106152	\N	0
36438289	8	109698	109699	\N	0
36438290	8	109699	109700	\N	0
36438281	8	109710	109715	\N	0
36438271	8	109713	109688	\N	0
36438318	1	109720	109719	\N	0
36438277	8	109707	109708	\N	0
36438279	8	109708	109709	\N	0
36438280	8	109709	109710	\N	0
36438282	8	109710	109714	\N	0
36438274	8	109688	109693	\N	0
36438275	8	109688	109689	\N	0
36438276	8	109689	109690	\N	0
36438273	8	109690	109692	\N	0
36438270	8	109713	109712	\N	0
36438278	8	109705	109707	\N	0
36438294	8	109712	109704	\N	0
36438295	6	109712	109693	\N	0
36438293	8	109704	109705	\N	0
36438272	8	109692	109704	\N	0
36438283	8	109702	109717	\N	0
36438291	8	109700	109701	\N	0
36438292	8	109701	109702	\N	0
48955416	0	109702	150692	\N	0
49938558	1	153539	153524	\N	0
49938559	1	153522	153532	\N	0
49938560	1	153523	153522	\N	0
49938561	1	153525	153526	\N	0
49938562	1	153526	153527	\N	0
49938563	1	153527	153528	\N	0
49938564	1	153528	153529	\N	0
49938565	1	153529	153530	\N	0
49938609	0	153531	153534	\N	0
49938610	0	153530	153531	\N	0
49938612	0	153536	153535	\N	0
49938611	0	153531	153536	\N	0
49938613	1	153536	153542	\N	0
51707936	17	159280	159278	\N	0
51707937	17	159279	159280	\N	0
51707935	17	159281	159285	\N	0
51707938	17	159282	159284	\N	2
51707939	17	159283	159282	\N	1
51707940	18	159284	159289	\N	0
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: deriveddayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY deriveddayassignmentscontainer (id, version, derived_allocation_id, scenario) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
164529	Observacións	
164530	Observacións	
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
14140	Incidencias	
14141	Incidencias	
81810	Incidencias	
81811	Incidencias	
81815	Incidencias	
81816	Incidencias	
164431	Incidencias	
164428	Incidencias	
164429	Incidencias	
164430	Incidencias	
164439	Incidencias	
164440	Incidencias	Inc
164441	Incidencias	
164442	Incidencias	
164443	Incidencias	
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
71883	71666	100.00
76063	71666	100.00
76066	71672	100.00
71884	71672	100.00
5353	4980	100.00
5354	4981	100.00
5355	4982	100.00
5356	4983	100.00
5359	4985	100.00
5360	4986	100.00
5361	4987	100.00
5362	4988	100.00
43686	43507	100.00
43679	43501	100.00
43680	43502	100.00
43681	43503	100.00
43682	43505	100.00
43683	43506	100.00
2020	1533	100.00
2021	1534	100.00
2030	1543	100.00
2024	1536	100.00
2025	1537	100.00
43644	43475	100.00
43227	43464	100.00
43632	43465	100.00
43633	43466	100.00
43634	43467	100.00
43643	43474	100.00
43637	43469	100.00
43638	43470	100.00
43639	43471	100.00
43640	43472	100.00
26109	25898	100.00
26108	25897	100.00
26110	25899	100.00
31525	25948	100.00
31526	25949	100.00
31527	25950	100.00
26111	25901	100.00
26112	25902	100.00
31528	25951	100.00
31531	25953	100.00
31532	25954	100.00
31533	25955	100.00
31534	25956	100.00
31537	31816	100.00
31538	31817	100.00
26115	25903	100.00
5365	4990	100.00
5366	4991	100.00
22732	22345	100.00
22725	22339	100.00
22726	22340	100.00
22727	22341	100.00
22728	22343	100.00
22729	22344	100.00
82973	4985	100.00
82971	82491	100.00
82932	82491	100.00
82933	82497	100.00
71871	71658	100.00
71872	71659	100.00
71873	71660	100.00
71874	71661	100.00
71877	71663	100.00
71878	71664	100.00
71865	71653	100.00
71866	71654	100.00
71867	71655	100.00
76067	71656	100.00
43689	43510	100.00
82925	82476	100.00
82921	82474	100.00
82922	82475	100.00
9191	7577	100.00
9192	7585	100.00
9193	7586	100.00
31576	31844	100.00
31577	31845	100.00
31580	31847	100.00
31581	31848	100.00
31584	31849	100.00
82928	82482	100.00
82929	82489	100.00
109618	108940	100.00
109585	108927	100.00
109586	108928	100.00
109587	108930	100.00
109588	108931	100.00
109589	108932	100.00
109592	108933	100.00
109593	108934	100.00
109594	108973	100.00
109595	108974	100.00
109596	108975	100.00
109597	108976	100.00
109598	108977	100.00
109599	108978	100.00
109600	109282	100.00
103830	103438	100.00
103828	103436	100.00
103829	103437	100.00
103831	103439	100.00
109601	109283	100.00
109602	109284	100.00
150591	150189	100.00
109605	109306	100.00
109606	109307	100.00
109609	108935	100.00
109610	109295	100.00
109611	109294	100.00
109612	109296	100.00
109615	108937	100.00
109616	108938	100.00
109617	108939	100.00
106050	105559	100.00
106051	105560	100.00
106052	105562	100.00
106053	105563	100.00
153435	153020	100.00
153419	152605	100.00
153420	153034	100.00
153421	153017	100.00
153422	153045	100.00
153425	153018	100.00
153426	153077	100.00
153427	153078	100.00
153428	153079	100.00
153429	153080	100.00
153430	153081	100.00
153431	153082	100.00
109619	108941	100.00
153434	153083	100.00
109620	109312	100.00
153436	153021	100.00
109623	109315	100.00
153437	153085	100.00
165798	167383	100.00
159176	158709	100.00
159177	158713	100.00
159178	158714	5.00
159179	158715	10.00
159265	158716	10.00
159182	158717	100.00
159183	158718	100.00
159184	158719	100.00
\.


--
-- Data for Name: effortperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY effortperday (base_calendar_id, effort, day_id) FROM stdin;
101	28800	0
101	28800	1
101	28800	2
101	28800	3
101	28800	4
101	0	5
101	0	6
107565	7200	0
107565	7200	1
107565	7200	2
107565	7200	3
107565	7200	4
152108	32400	0
152108	32400	1
152108	32400	2
152108	32400	3
152108	14400	4
152109	14400	0
152109	14400	1
152109	14400	2
152109	14400	3
\.


--
-- Data for Name: external_company; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY external_company (id, version, name, nif, client, subcontractor, interactswithapplications, appuri, ourcompanylogin, ourcompanypassword, companyuser) FROM stdin;
1819	1	Navantia	2B	t	f	f	\N	\N	\N	1111
1820	1	Barreras	3C	t	f	f	\N	\N	\N	1111
1818	5	Igalia	B15804842	t	t	t	http://localhost:8080/navalplanner-webapp/	wswriter	wswriter	1114
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
5861
5863
7892
7908
16672
16673
16699
16701
26970
26972
26973
26974
26989
27040
27041
27042
27043
27044
27045
27046
27047
27048
27049
43936
43941
43943
43944
43945
43946
45989
45990
72925
72929
72930
72931
83125
83126
83128
83130
83131
83140
83141
83142
83152
83153
104135
104137
104138
106354
111908
111909
111910
111911
111912
116134
116135
116136
116137
116138
116139
116140
116141
116142
116143
116144
116145
128483
128484
128485
128486
128487
128488
128489
128490
128491
128492
128493
128496
151205
159517
159518
159519
159520
159521
\.


--
-- Data for Name: genericdayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY genericdayassignmentscontainer (id, version, resource_allocation_id, scenario) FROM stdin;
27071	9	26970	707
27074	9	26973	707
27075	9	26974	707
27090	4	26989	707
73033	15	72931	38380
27073	9	26972	707
27137	0	27040	707
27138	0	27041	707
27139	0	27042	707
27140	0	27043	707
27141	0	27044	707
27142	0	27045	707
27143	0	27046	707
27144	0	27047	707
27145	0	27048	707
27146	0	27049	707
83244	1	83142	38380
53632	1	45989	38380
53633	1	45990	38380
16773	7	16672	707
16774	7	16673	707
5962	18	5861	707
5964	15	5863	707
9412	8	7908	707
9406	8	7892	707
16802	8	16701	707
16800	10	16699	707
83232	0	83131	707
73026	5	72925	707
83226	2	83125	707
83227	2	83126	707
42595	3	43944	707
42596	4	43945	707
83254	2	83152	707
83255	2	83153	707
83233	33	83125	38380
83234	33	83126	38380
83235	33	83128	38380
83236	17	83131	38380
83237	13	83130	38380
83229	1	83128	707
83242	2	83140	38380
42597	5	43946	707
73030	4	72929	707
73031	4	72930	707
42531	0	43943	38380
27166	23	26989	38380
27167	23	26970	38380
27168	23	26973	38380
42521	23	26974	38380
42522	23	26972	38380
83243	1	83141	38380
27162	31	16672	38380
27163	31	16673	38380
27158	31	5861	38380
27159	31	5863	38380
27161	31	7908	38380
83231	3	83130	707
73032	4	72931	707
27147	41	27042	38380
27148	41	27043	38380
27149	41	27044	38380
27150	41	27045	38380
27151	41	27046	38380
27152	41	27047	38380
27153	41	27048	38380
27154	41	27049	38380
27155	41	27040	38380
27156	41	27041	38380
27157	32	7892	38380
53631	24	43946	38380
27164	32	16699	38380
27165	33	16701	38380
116244	6	116143	707
112012	7	111911	707
112009	9	111908	707
116239	6	116138	707
116240	6	116139	707
116241	6	116140	707
104235	2	104135	707
104236	2	104137	707
104237	2	104138	707
116242	6	116141	707
112010	9	111909	707
112013	7	111912	707
106455	3	106354	707
116245	6	116144	707
116246	6	116145	707
128584	5	128483	707
116236	6	116135	707
116237	6	116136	707
116238	6	116137	707
116243	6	116142	707
116235	6	116134	707
112011	8	111910	707
128585	5	128484	707
128586	5	128485	707
128587	5	128486	707
128588	5	128487	707
128589	5	128488	707
128590	5	128489	707
128591	5	128490	707
128592	5	128491	707
128593	5	128492	707
128594	5	128493	707
128597	1	128496	707
151306	0	151205	707
160726	9	159517	707
160727	9	159518	707
160728	9	159519	707
160729	9	159520	707
160730	9	159521	707
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, positionnumber) FROM stdin;
164327	Observacións	40	0
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
1671
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, code, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
164935	2	cb0b98df-ec07-4842-a39a-b4d5e3d6e7ec	22.00	2010-09-03	\N	13938	164833
164936	2	af827319-d6b8-43ea-b559-b5aaa8537fd3	15.00	2010-09-03	\N	13939	164833
164934	2	a5fbed1e-cf42-45b7-aef4-340053c48c7e	20.00	2010-09-03	2010-12-31	13939	164832
164933	2	8d44b4e5-fa55-49fe-a680-a8a3ebabdcb3	22.00	2011-01-01	\N	13939	164832
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, code, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line, order_line_template) FROM stdin;
22639	19	PREFIX-00006-00006-00001	WORKER	150	1.00	f	22343	\N
22640	19	PREFIX-00006-00007-00001	WORKER	200	1.00	f	22344	\N
26458	5	PREFIX-00008-00004-00001	WORKER	210	1.00	f	25948	\N
26459	5	PREFIX-00008-00005-00001	WORKER	70	0.46	f	25949	\N
22641	19	PREFIX-00006-00005-00001	WORKER	100	1.00	f	22345	\N
5272	29	PREFIX-00003-00004-00001	WORKER	210	1.00	f	4980	\N
9106	15	PREFIX-00003-00005-00002	WORKER	70	0.46	f	4981	\N
5273	29	PREFIX-00003-00005-00001	WORKER	80	1.00	f	4981	\N
5280	29	PREFIX-00003-00012-00001	WORKER	150	1.00	f	4990	\N
5281	29	PREFIX-00003-00013-00001	WORKER	200	1.00	f	4991	\N
22636	19	PREFIX-00006-00001-00001	WORKER	100	1.00	f	22339	\N
22637	19	PREFIX-00006-00002-00001	WORKER	200	1.00	f	22340	\N
22638	19	PREFIX-00006-00003-00001	MACHINE	100	1.00	f	22341	\N
26414	1	d4dd6199-87e1-4100-84ce-2fafd72803d6	WORKER	210	1.00	f	\N	26614
26415	1	99b6ff06-2be1-4696-a642-549cd2a4670d	WORKER	70	0.46	f	\N	26615
26416	1	e49031a6-3ec1-4de4-b08a-1df4344e8043	WORKER	80	0.53	f	\N	26615
26417	1	397a6f1c-ce67-4e62-a0cd-1632d509c4c6	WORKER	101	1.00	f	\N	26616
26418	1	0a857d14-ebe2-4b2f-9cef-a7a6ba6a5308	WORKER	200	1.00	f	\N	26617
26419	1	eba58985-d591-4d98-bf04-4bbd76375616	WORKER	100	1.00	f	\N	26619
26420	1	eb0a9aa5-7584-4b1e-9eb0-71acf24ee6e0	WORKER	200	1.00	f	\N	26620
26421	1	93a5a9b6-a15e-44d4-95fb-a0fd5ada3c69	WORKER	200	1.00	f	\N	26621
26422	1	910643dd-deb4-41bb-b738-172989c7cb4b	WORKER	400	1.00	f	\N	26622
26423	1	2ee35234-87fd-4cb7-babf-122bf1e46781	WORKER	150	1.00	f	\N	26624
26424	1	119e0a40-4cf1-4508-968e-c7c13657ca8c	WORKER	200	1.00	f	\N	26625
25720	2	660c29b9-1753-4455-aea5-5ec31036c9ca	WORKER	100	1.00	f	\N	25436
25721	2	ea64a919-5168-4ac0-bee8-69b0f503b92d	WORKER	200	1.00	f	\N	25437
25722	2	1a68a0d8-0270-4b2f-b8e2-9328e57bd510	MACHINE	100	1.00	f	\N	25438
25723	2	4cb59afa-8cc7-4f79-8189-68f6a2b2b847	WORKER	150	1.00	f	\N	25440
25724	2	32760635-b673-4580-ab5d-59217b41ad7c	WORKER	200	1.00	f	\N	25441
25725	2	8deed49b-6563-40e5-be9c-10a078c847d0	WORKER	100	1.00	f	\N	25442
1927	17	PREFIX-00002-00003-00001	WORKER	100	1.00	f	1533	\N
1928	17	PREFIX-00002-00004-00001	WORKER	100	1.00	f	1534	\N
1936	16	PREFIX-00002-00007-00001	WORKER	300	1.00	f	1543	\N
1929	17	PREFIX-00002-00005-00001	WORKER	100	1.00	f	1536	\N
1930	17	PREFIX-00002-00006-00001	WORKER	100	1.00	f	1537	\N
26362	14	PREFIX-00007-00001-00001	WORKER	100	1.00	f	25897	\N
26364	14	PREFIX-00007-00003-00001	MACHINE	100	1.00	f	25899	\N
26365	14	PREFIX-00007-00006-00001	WORKER	150	1.00	f	25901	\N
26366	14	PREFIX-00007-00007-00001	WORKER	200	1.00	f	25902	\N
26367	14	PREFIX-00007-00005-00001	WORKER	100	1.00	f	25903	\N
26363	14	PREFIX-00007-00002-00001	WORKER	200	1.00	f	25898	\N
9090	13	PREFIX-00005-00001-00001	WORKER	150	1.00	f	7577	\N
9095	13	PREFIX-00005-00003-00001	WORKER	200	1.00	f	7585	\N
9096	13	PREFIX-00005-00004-00001	WORKER	100	1.00	f	7586	\N
5274	29	PREFIX-00003-00006-00001	WORKER	101	1.00	f	4982	\N
5275	29	PREFIX-00003-00007-00001	WORKER	200	1.00	f	4983	\N
5276	29	PREFIX-00003-00008-00001	WORKER	100	1.00	f	4985	\N
5277	29	PREFIX-00003-00009-00001	WORKER	200	1.00	f	4986	\N
5278	29	PREFIX-00003-00010-00001	WORKER	200	1.00	f	4987	\N
5279	29	PREFIX-00003-00011-00001	WORKER	400	1.00	f	4988	\N
43375	15	PREFIX-00010-00011-00001	WORKER	400	1.00	f	43472	\N
43376	15	PREFIX-00010-00012-00001	WORKER	150	1.00	f	43474	\N
43377	15	PREFIX-00010-00013-00001	WORKER	200	1.00	f	43475	\N
43396	3	PREFIX-00011-00001-00001	WORKER	100	1.00	f	43501	\N
43397	3	PREFIX-00011-00002-00001	WORKER	200	1.00	f	43502	\N
43398	3	PREFIX-00011-00003-00001	MACHINE	100	1.00	f	43503	\N
43399	3	PREFIX-00011-00006-00001	WORKER	150	1.00	f	43505	\N
26460	5	PREFIX-00008-00005-00002	WORKER	80	0.53	f	25949	\N
26461	5	PREFIX-00008-00006-00001	WORKER	101	1.00	f	25950	\N
31714	5	PREFIX-00008-00007-00001	WORKER	200	1.00	f	25951	\N
31715	5	PREFIX-00008-00008-00001	WORKER	100	1.00	f	25953	\N
31716	5	PREFIX-00008-00009-00001	WORKER	200	1.00	f	25954	\N
31717	5	PREFIX-00008-00010-00001	WORKER	200	1.00	f	25955	\N
31718	5	PREFIX-00008-00011-00001	WORKER	400	1.00	f	25956	\N
31719	5	PREFIX-00008-00012-00001	WORKER	150	1.00	f	31816	\N
31720	5	PREFIX-00008-00013-00001	WORKER	200	1.00	f	31817	\N
31736	1	fc19490d-ad1b-4b0a-8c38-83d60e511310	WORKER	100	1.00	f	\N	26652
31737	1	1ac2c837-f52e-45ac-9696-e6f2628792b9	WORKER	100	1.00	f	\N	26653
31738	1	86b4173d-0ef3-40e0-9eca-c7ac726f6828	WORKER	100	1.00	f	\N	26655
31739	1	6e396811-99a6-4aed-aad0-a304dcdc25ec	WORKER	100	1.00	f	\N	26656
31740	1	31bd0579-f473-418c-b793-828086d4a133	WORKER	300	1.00	f	\N	26657
43400	3	PREFIX-00011-00007-00001	WORKER	200	1.00	f	43506	\N
43401	3	PREFIX-00011-00005-00001	WORKER	100	1.00	f	43507	\N
72047	14	PREFIX-00012-00005-00001	WORKER	70	0.46	f	71654	\N
72048	14	PREFIX-00012-00005-00002	WORKER	80	0.53	f	71654	\N
72049	14	PREFIX-00012-00006-00001	WORKER	101	1.00	f	71655	\N
72050	14	PREFIX-00012-00007-00001	WORKER	200	1.00	f	71656	\N
82763	5	PREFIX-00015-00001-00001	WORKER	1000	1.00	f	82489	\N
31756	13	PREFIX-00009-00004-00001	WORKER	100	1.00	f	31844	\N
43367	15	PREFIX-00010-00004-00001	WORKER	210	1.00	f	43464	\N
43368	15	PREFIX-00010-00005-00001	WORKER	70	0.46	f	43465	\N
43369	15	PREFIX-00010-00005-00002	WORKER	80	0.53	f	43465	\N
43370	15	PREFIX-00010-00006-00001	WORKER	101	1.00	f	43466	\N
43371	15	PREFIX-00010-00007-00001	WORKER	200	1.00	f	43467	\N
43372	15	PREFIX-00010-00008-00001	WORKER	100	1.00	f	43469	\N
82760	5	PREFIX-00009-00009-00001	MACHINE	200	1.00	f	82482	\N
31757	13	PREFIX-00009-00005-00001	WORKER	100	1.00	f	31845	\N
43373	15	PREFIX-00010-00009-00001	WORKER	200	1.00	f	43470	\N
43404	7	PREFIX-00009-00008-00001	WORKER	300	1.00	f	43510	\N
82764	7	PREFIX-00016-00001-00001	WORKER	50	1.00	f	82491	\N
82767	7	PREFIX-00016-00003-00001	WORKER	20	1.00	f	82497	\N
72051	10	PREFIX-00012-00008-00001	WORKER	100	1.00	f	71658	\N
72052	10	PREFIX-00012-00009-00001	WORKER	200	1.00	f	71659	\N
72053	10	PREFIX-00012-00010-00001	WORKER	200	1.00	f	71660	\N
72054	10	PREFIX-00012-00011-00001	WORKER	400	1.00	f	71661	\N
72055	10	PREFIX-00012-00012-00001	WORKER	150	1.00	f	71663	\N
43374	15	PREFIX-00010-00010-00001	WORKER	200	1.00	f	43471	\N
72057	11	PREFIX-00013-00001-00001	WORKER	50	1.00	f	71666	\N
82754	7	PREFIX-00014-00002-00001	WORKER	100	1.00	f	82476	\N
82752	7	PREFIX-00014-00003-00001	WORKER	100	1.00	f	82474	\N
82753	7	PREFIX-00014-00004-00001	WORKER	100	1.00	f	82475	\N
72056	10	PREFIX-00012-00013-00001	WORKER	200	1.00	f	71664	\N
72046	14	PREFIX-00012-00004-00001	WORKER	210	1.00	f	71653	\N
31758	13	PREFIX-00009-00006-00001	WORKER	100	1.00	f	31847	\N
31759	13	PREFIX-00009-00007-00001	WORKER	100	1.00	f	31848	\N
31760	13	PREFIX-00009-00003-00001	WORKER	300	1.00	f	31849	\N
72060	11	PREFIX-00013-00003-00001	WORKER	100	1.00	f	71672	\N
103737	8	PREFIX-00018-00003-00001	WORKER	150	1.00	f	103438	\N
103751	1	ef87b349-65a4-44d9-8ef7-e45406d802b1	WORKER	200	1.00	f	\N	105258
103752	1	5ff86a9e-4dda-407c-b04c-e47012c264f7	WORKER	200	1.00	f	\N	105259
103753	1	e210dc0b-1b3e-45ae-a324-3fd5d2d2121e	WORKER	150	1.00	f	\N	105260
103754	1	a1fd81cf-e85c-46a0-a007-8eff4c51b729	WORKER	50	1.00	f	\N	105261
105858	9	PREFIX-00019-00004-00001	WORKER	300	1.00	f	105562	\N
105859	9	PREFIX-00019-00005-00001	WORKER	100	1.00	f	105563	\N
103735	8	PREFIX-00018-00001-00001	WORKER	200	1.00	f	103436	\N
103736	8	PREFIX-00018-00002-00001	WORKER	200	1.00	f	103437	\N
103738	8	PREFIX-00018-00004-00001	WORKER	50	1.00	f	103439	\N
105856	9	PREFIX-00019-00001-00001	WORKER	200	1.00	f	105559	\N
105857	9	PREFIX-00019-00002-00001	WORKER	100	1.00	f	105560	\N
109229	27	PREFIX-00022-00005-00001	WORKER	21	1.00	f	108934	\N
109264	25	PREFIX-00022-00017-00001	WORKER	21	1.00	f	108973	\N
109265	25	PREFIX-00022-00018-00001	WORKER	21	1.00	f	108974	\N
109266	25	PREFIX-00022-00019-00001	WORKER	21	1.00	f	108975	\N
109267	25	PREFIX-00022-00020-00001	WORKER	21	1.00	f	108976	\N
153003	10	PREFIX-00024-00013-00001	WORKER	7	1.00	f	153015	\N
153004	10	PREFIX-00024-00002-00001	WORKER	4	1.00	f	153016	\N
109268	25	PREFIX-00022-00021-00001	WORKER	21	1.00	f	108977	\N
109269	25	PREFIX-00022-00022-00001	WORKER	21	1.00	f	108978	\N
153005	10	PREFIX-00024-00003-00001	WORKER	7	1.00	f	153017	\N
109270	25	PREFIX-00022-00023-00001	WORKER	21	1.00	f	109282	\N
109271	25	PREFIX-00022-00024-00001	WORKER	21	1.00	f	109283	\N
109272	25	PREFIX-00022-00025-00001	WORKER	21	1.00	f	109284	\N
150492	3	PREFIX-00022-00035-00001	WORKER	70	1.00	f	150189	\N
109490	21	PREFIX-00022-00031-00001	WORKER	35	1.00	f	109306	\N
109491	21	PREFIX-00022-00032-00001	WORKER	35	1.00	f	109307	\N
109230	27	PREFIX-00022-00006-00001	WORKER	26	1.00	f	108935	\N
109280	23	PREFIX-00022-00028-00001	WORKER	25	1.00	f	109295	\N
109279	23	PREFIX-00022-00027-00001	WORKER	40	1.00	f	109294	\N
109281	23	PREFIX-00022-00029-00001	WORKER	28	1.00	f	109296	\N
109232	27	PREFIX-00022-00008-00001	WORKER	126	1.00	f	108937	\N
109233	27	PREFIX-00022-00009-00001	WORKER	56	1.00	f	108938	\N
109234	27	PREFIX-00022-00010-00001	WORKER	35	1.00	f	108939	\N
109223	27	PREFIX-00022-00001-00001	WORKER	105	1.00	f	108927	\N
109224	27	PREFIX-00022-00002-00001	WORKER	91	1.00	f	108928	\N
109225	27	PREFIX-00022-00013-00001	WORKER	63	1.00	f	108930	\N
109236	27	PREFIX-00022-00012-00001	WORKER	70	1.00	f	108941	\N
109226	27	PREFIX-00022-00014-00001	WORKER	35	1.00	f	108931	\N
109227	27	PREFIX-00022-00015-00001	WORKER	35	1.00	f	108932	\N
109228	27	PREFIX-00022-00004-00001	WORKER	84	1.00	f	108933	\N
109495	20	PREFIX-00022-00033-00001	WORKER	56	1.00	f	109312	\N
109498	6	PREFIX-00022-00034-00001	WORKER	60	1.00	f	109315	\N
109235	27	PREFIX-00022-00011-00001	WORKER	63	1.00	f	108940	\N
152998	10	PREFIX-00024-00008-00001	WORKER	7	1.00	f	152606	\N
152999	10	PREFIX-00024-00009-00001	WORKER	7	1.00	f	152607	\N
153000	10	PREFIX-00024-00010-00001	WORKER	7	1.00	f	152608	\N
153001	10	PREFIX-00024-00011-00001	WORKER	14	1.00	f	152609	\N
153002	10	PREFIX-00024-00012-00001	WORKER	7	1.00	f	152610	\N
157063	3	PREFIX-00028-00004-00001	WORKER	0	1.00	f	156666	\N
157064	3	PREFIX-00028-00005-00001	WORKER	0	1.00	f	156667	\N
157065	3	PREFIX-00028-00002-00001	WORKER	0	1.00	f	156668	\N
157066	3	PREFIX-00028-00003-00001	WORKER	0	1.00	f	156669	\N
167083	1	4ef11981-a8a9-45b7-830e-6ec4f01a0248	WORKER	300	1.00	f	\N	166897
167084	1	7b5fc004-8ba9-4806-9655-23b456d6441b	WORKER	250	1.00	f	\N	166898
159103	24	PREFIX-00032-00008-00001	WORKER	200	1.00	f	158715	\N
159104	24	PREFIX-00032-00009-00001	WORKER	300	1.00	f	158717	\N
159105	24	PREFIX-00032-00010-00001	WORKER	250	1.00	f	158718	\N
157570	3	PREFIX-00029-00005-00001	WORKER	200	1.00	f	157173	\N
157571	3	PREFIX-00029-00006-00001	WORKER	100	1.00	f	157174	\N
157572	3	PREFIX-00029-00002-00001	WORKER	300	1.00	f	157175	\N
157573	3	PREFIX-00029-00003-00001	WORKER	200	1.00	f	157176	\N
157574	3	PREFIX-00029-00004-00001	WORKER	100	1.00	f	157177	\N
167085	1	277e0a20-69e6-4f94-9491-3efdf910d123	WORKER	200	1.00	f	\N	166899
159106	24	PREFIX-00032-00011-00001	WORKER	200	1.00	f	158719	\N
167104	2	PREFIX-00032-00012-00001	WORKER	20	1.00	f	167383	\N
153322	9	PREFIX-00024-00015-00001	WORKER	4	1.00	f	153035	\N
153323	9	PREFIX-00024-00016-00001	WORKER	4	1.00	f	153036	\N
153324	9	PREFIX-00024-00017-00001	WORKER	4	1.00	f	153037	\N
153328	8	PREFIX-00024-00019-00001	WORKER	7	1.00	f	153045	\N
153006	10	PREFIX-00024-00004-00001	WORKER	7	1.00	f	153018	\N
153353	7	PREFIX-00024-00023-00001	WORKER	53	1.00	f	153077	\N
153354	7	PREFIX-00024-00024-00001	WORKER	14	1.00	f	153078	\N
153355	7	PREFIX-00024-00025-00001	WORKER	14	1.00	f	153079	\N
153356	7	PREFIX-00024-00026-00001	WORKER	14	1.00	f	153080	\N
153357	7	PREFIX-00024-00027-00001	WORKER	35	1.00	f	153081	\N
153358	7	PREFIX-00024-00028-00001	WORKER	28	1.00	f	153082	\N
153007	10	PREFIX-00024-00005-00001	WORKER	4	1.00	f	153019	\N
158578	3	PREFIX-00031-00003-00001	WORKER	100	1.00	f	158183	\N
158579	3	PREFIX-00031-00004-00001	WORKER	0	1.00	f	158184	\N
158580	3	PREFIX-00031-00005-00001	WORKER	200	1.00	f	158186	\N
158581	3	PREFIX-00031-00006-00001	WORKER	0	1.00	f	158187	\N
153359	7	PREFIX-00024-00029-00001	WORKER	6	1.00	f	153084	\N
153009	10	PREFIX-00024-00007-00001	WORKER	7	1.00	f	153021	\N
153360	7	PREFIX-00024-00022-00001	WORKER	14	1.00	f	153085	\N
153008	10	PREFIX-00024-00006-00001	WORKER	7	1.00	f	153020	\N
167078	1	9737e9b0-c973-404c-a317-6835c0d1ce9b	WORKER	100	1.00	f	\N	166890
167079	1	0d0f63b4-2760-4bfc-9715-4e0606803143	WORKER	100	1.00	f	\N	166891
167080	1	ba9f166b-9f98-4d75-908f-fdb01d63091b	WORKER	100	1.00	f	\N	166893
167081	1	15b384b3-1941-43be-9a5b-8e780bac931b	WORKER	200	1.00	f	\N	166894
167082	1	2710293b-3bde-4d18-90b5-ba982f0a379b	WORKER	200	1.00	f	\N	166895
159099	24	PREFIX-00032-00004-00001	WORKER	100	1.00	f	158710	\N
159100	24	PREFIX-00032-00005-00001	WORKER	100	1.00	f	158711	\N
159101	24	PREFIX-00032-00006-00001	WORKER	100	1.00	f	158713	\N
159102	24	PREFIX-00032-00007-00001	WORKER	200	1.00	f	158714	\N
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
2023	1532
2022	1532
2029	1531
2028	1531
2027	1535
2026	1535
82936	82490
82970	82490
82937	82490
82974	4984
82975	4952
5358	4979
5357	4979
5364	4984
5363	4984
5367	4989
5368	4989
5370	4952
5369	4952
82935	82496
71870	71652
31530	25947
31529	25947
31535	25952
31536	25952
31542	25946
31541	25946
31540	31815
31539	31815
76068	71652
71869	71652
71876	71657
71875	71657
26114	25900
26113	25900
26117	25896
26116	25896
71879	71662
71880	71662
43684	43504
43685	43504
43687	43500
43688	43500
71882	71651
71881	71651
76069	71651
82923	82473
82924	82473
82926	82472
82972	82496
82934	82496
82927	82472
22731	22342
22730	22342
22733	22338
22734	22338
43635	43463
43636	43463
43641	43468
43642	43468
43645	43473
43646	43473
43647	43462
43648	43462
9197	7576
9196	7576
9195	7584
9194	7584
31579	31843
31578	31843
31583	31846
31582	31846
31585	31842
31586	31842
82930	82488
82931	82488
76065	71665
71888	71665
71887	71665
71885	71671
71886	71671
76064	71671
109590	108929
109591	108929
109603	108972
109604	108972
103833	103435
103832	103435
106055	105561
106054	105561
106056	105558
106057	105558
109608	109293
109607	109293
109613	109308
109614	109308
109621	108881
109622	108881
153423	153044
153424	153044
153433	153076
153432	153076
153438	152513
153439	152513
159264	158712
159180	158712
159181	158712
159186	158716
159185	158716
159188	158708
159187	158708
159263	158708
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, code, name, label_type_id) FROM stdin;
14847	44	9c283fde-f94a-456e-a490-af07e9669a63	Zona Motor	14746
14848	39	86a9a95b-3609-47af-a9e1-5dad1ead1d9a	Zona Bodegas	14746
14849	58	ec89906f-369e-4ac3-b6fb-15c64a016bc4	Zona Cubierta	14746
154631	1	d70fa457-04c6-4c30-96d7-441c1158537e	Media	154530
154632	1	ca7cc805-f5a3-476a-b68a-a608af179829	Moi urxente	154530
154633	1	05914dc3-51b5-4ef4-923b-bdd47dd37c1d	Urxente	154530
154634	1	3180283f-490a-4328-8903-a4b9afea7ac0	Baixa	154530
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, code, name, generatecode) FROM stdin;
14746	1	62ab1b94-706b-49a8-8618-e4f279f683b3	Zonas	t
154530	1	43dd5835-3e97-488a-b4b4-e435a529f338	Prioridade	t
\.


--
-- Data for Name: limiting_resource_queue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue (id, version, resource_id) FROM stdin;
1415	2	1220
1414	4	1216
\.


--
-- Data for Name: limiting_resource_queue_dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_dependency (id, type, origin_queue_element_id, destiny_queue_element_id) FROM stdin;
4141	1	2327	2388
2525	1	2326	2327
2528	1	2388	2389
38179	1	37991	37992
38180	1	37991	37988
38178	1	37989	37990
86052	1	37989	85951
\.


--
-- Data for Name: limiting_resource_queue_element; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_element (id, version, resource_allocation_id, limiting_resource_queue_id, earlier_start_date_because_of_gantt, earliest_end_date_because_of_gantt, creation_timestamp, start_date, start_hour, end_date, end_hour) FROM stdin;
75750	6	72931	1415	2010-07-09 18:10:13.82	2010-06-14 18:10:13.82	1276676237193	2010-08-20	8	2010-09-08	4
37991	7	27065	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276597033207	2010-07-19	0	2010-08-04	8
37992	6	27066	1415	2010-07-01 00:00:00	2010-07-01 00:00:00	1276597056978	2010-09-10	4	2010-09-28	8
37988	6	27062	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276597131694	2010-11-05	8	2010-12-29	4
2388	9	2287	1415	2010-06-13 12:33:10.77	2010-06-13 12:33:10.77	1276427087598	2010-07-16	8	2010-08-04	4
37989	7	27063	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276597077782	2010-08-05	0	2010-08-23	8
2326	11	2225	1414	2010-06-13 12:33:10.77	2010-06-13 12:33:10.77	1276425557107	2010-06-13	0	2010-06-30	4
2327	12	2226	1415	2010-06-13 12:33:10.77	2010-06-13 12:33:10.77	1276425619376	2010-06-30	4	2010-07-16	8
37990	6	27064	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276597108509	2011-01-07	4	2011-01-25	8
85951	2	83131	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276702440770	2011-02-11	8	2011-03-18	8
37994	5	43946	1414	2010-07-01 00:00:00	2010-07-01 00:00:00	1276603010805	2010-08-23	8	2010-10-14	4
7979	14	7878	1414	2010-07-09 12:59:30.412	2010-06-14 12:59:30.412	1276514604779	2010-06-30	4	2010-07-19	1
37983	3	27057	1415	2010-07-15 00:00:00	2010-06-15 09:45:17.731	1276591908517	2010-08-04	4	2010-08-20	8
2389	10	2288	1414	2010-06-13 12:33:10.77	2010-06-13 12:33:10.77	1276427111444	2011-01-26	0	2011-02-11	8
108477	0	106358	\N	2010-07-13 11:46:27.203	2010-07-06 11:46:27.203	1278412298871	\N	0	\N	0
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, positionnumber) FROM stdin;
13837	Incidencias	100	0
164327	Incidencias	20	0
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, name, description) FROM stdin;
1220	Torno 2	Torno para realizar eixes de ata 30 m
1216	Torno 1	Torno para realizar eixes de ata 10 metros.
167965	Torno1	Desc
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
165236	2	t1	Tornillo: 15mm	10.00	1010	\N	165136
165237	2	t2	Tornillo: 20mm	20.00	1010	\N	165136
165238	1	t3	Tornillo: 17mm	10.00	1010	\N	165137
165239	1	t4	Tornillo: 19mm	12.00	1010	\N	165137
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, material_id, estimated_availability, status, order_element_id) FROM stdin;
165343	3	10	10.00	165238	2010-09-30 00:00:00	1	158717
165344	3	10	20.00	165237	2010-09-23 00:00:00	1	158718
\.


--
-- Data for Name: material_assigment_template; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment_template (id, version, units, unit_price, material_id, order_element_template_id) FROM stdin;
167262	1	10	10.00	165238	166897
167263	1	10	20.00	165237	166898
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, code, name, generatecode, parent_id) FROM stdin;
909	3	37e9d60d-43c1-4a2e-93cc-01c505293d45	Imported materials without category	f	\N
165135	2	e4d489ab-4f6f-4d73-a453-8bb7805dbe64	Tornillos	t	\N
165136	2	3dcf24c0-b9ee-430b-9ffe-2d7d173ca6c7	Tornillos de bronce	t	165135
165137	2	ecaa1770-41c2-4abf-92f3-fccbf9f38334	Tornillos de aceiro	t	165135
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled, lastconnectedscenario) FROM stdin;
1111	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f	\N
1113	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f	\N
1114	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f	\N
1112	21	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f	707
167761	1	grupo1_permisos	099c8a1f2442e1939ad98a3808341f39874630134d42f3dd9ffe7ea2350266f59d47fcd6a422de03c8c53b5560220527dcd00a588c7757992a7d2b9d927a2e6a	\N	f	\N
\.


--
-- Data for Name: order_authorization; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_authorization (id, order_authorization_subclass, version, authorizationtype, order_id, user_id, profile_id) FROM stdin;
167862	USER	4	READ_AUTHORIZATION	158708	167761	\N
167863	USER	4	WRITE_AUTHORIZATION	158708	167761	\N
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
4980	14849
4981	14847
4982	14847
4983	14849
4985	14849
4987	14847
4990	14848
25948	14849
25949	14847
25950	14847
25951	14849
25953	14849
25955	14847
31816	14848
43464	14849
43465	14847
43466	14847
43467	14849
43469	14849
43471	14847
43474	14848
71653	14849
71654	14847
71655	14847
71656	14849
71658	14849
71660	14847
71663	14848
71666	14849
82491	14849
\.


--
-- Data for Name: order_element_template_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_label (order_element_template_id, label_id) FROM stdin;
26614	14849
26615	14847
26616	14847
26617	14849
26619	14849
26621	14847
26624	14848
\.


--
-- Data for Name: order_element_template_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_quality_form (order_element_template_id, quality_form_id) FROM stdin;
166888	165539
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, dependenciesconstraintshavepriority, codeautogenerated, lastorderelementsequencecode, workbudget, materialsbudget, totalhours, customerreference, externalcode, state, customer, base_calendar_id) FROM stdin;
71651	\N	\N	t	13	20000.00	0.00	1911	\N	\N	0	\N	1
1531	Javier Moran	\N	t	7	0.00	0.00	700	ref 1	\N	0	1820	1
25946	\N	\N	t	13	30000.00	0.00	1911	\N	\N	0	\N	1
82472	\N	\N	t	4	30000.00	0.00	300	\N	\N	0	\N	1
22338	\N	\N	t	7	0.00	0.00	850	\N	\N	0	\N	1
31842	\N	\N	t	9	0.00	0.00	1200	\N	\N	0	\N	1
82488	\N	\N	t	1	0.00	0.00	1000	\N	\N	0	\N	1
43500	\N	\N	t	7	0.00	0.00	850	\N	\N	0	\N	1
71665	\N	\N	t	3	30000.00	0.00	150	Igalia_0001	\N	1	1818	1
4952	Xavi	\N	t	13	0.00	0.00	1911	\N	\N	0	1818	1
43462	\N	\N	t	13	0.00	0.00	1911	\N	\N	0	\N	1
25896	\N	\N	t	7	0.00	0.00	850	\N	\N	0	\N	1
82490	\N	\N	t	3	10000.00	0.00	70	0001	\N	5	1818	1
7576	\N	\N	t	4	20000.00	0.00	450	001	\N	5	1818	1
103435	Responsable	\N	t	4	0.00	0.00	600	\N	\N	0	1818	1
158708	Xavier	\N	t	12	100000.00	0.00	1470	Ref.	\N	0	\N	1
105558	\N	\N	t	5	0.00	0.00	700	\N	\N	0	1818	1
108881	\N	\N	t	35	60000.00	0.00	1348	\N	\N	0	\N	1
152513	Lorenzo Tilve	\N	t	29	0.00	0.00	282	001	\N	0	\N	1
156664	Xavier Castaño García	\N	t	5	0.00	0.00	0	\N	\N	0	1819	1
157171	\N	\N	t	6	0.00	0.00	900	\N	\N	0	\N	1
158181	avier	\N	t	6	0.00	0.00	300	\N	\N	0	1819	1
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, description, code, initdate, deadline, lastadvancemeausurementforspreading, dirtylastadvancemeasurementforspreading, parent, template, externalcode, positionincontainer, sum_charged_hours_id) FROM stdin;
1543	16	tarefa limitantes 5	\N	PREFIX-00002-00007	\N	\N	0.40	f	1531	\N	\N	2	\N
1536	17	tarefa limitantes 3	\N	PREFIX-00002-00005	\N	\N	0.00	f	1535	\N	\N	0	\N
1537	17	tarefa limitantes 4	\N	PREFIX-00002-00006	\N	\N	0.00	f	1535	\N	\N	1	\N
4987	30	Tarea 2.3	\N	PREFIX-00003-00010	\N	\N	0.00	f	4984	\N	\N	2	\N
4988	30	Tarea 2.4	\N	PREFIX-00003-00011	\N	\N	0.00	f	4984	\N	\N	3	\N
4990	30	Tarea 3.2	\N	PREFIX-00003-00012	\N	\N	0.00	f	4989	\N	\N	0	\N
71671	12	Tarea 1.4	\N	PREFIX-00013-00002	2010-07-16 00:00:00	2010-08-10 00:00:00	0.29	t	71665	\N	PREFIX-00012-00007	0	\N
71672	11	Tarefa 1	\N	PREFIX-00013-00003	\N	\N	0.25	f	71671	\N	\N	1	\N
4989	30	Tarea 3	\N	PREFIX-00003-00003	\N	\N	0.00	f	4952	\N	\N	2	\N
4979	36	Tarea1	\N	PREFIX-00003-00001	\N	\N	0.10	f	4952	\N	\N	0	\N
22345	20	Tarefa 5	\N	PREFIX-00006-00005	\N	\N	0.00	f	22338	\N	\N	4	\N
22338	20	Pedido 2	\N	PREFIX-00006	2010-06-14 18:10:13.82	2010-09-22 00:00:00	0.12	f	\N	\N	\N	\N	\N
22339	20	Tarefa 1	\N	PREFIX-00006-00001	\N	\N	0.10	f	22338	\N	\N	0	\N
22340	20	Tarefa 2	\N	PREFIX-00006-00002	\N	\N	0.00	f	22338	\N	\N	1	\N
22341	20	Tarefa 3	\N	PREFIX-00006-00003	\N	\N	0.00	f	22338	\N	\N	2	\N
22342	20	Tarefa 4	\N	PREFIX-00006-00004	\N	\N	0.28	f	22338	\N	\N	3	\N
22343	20	Tarefa 4.2	\N	PREFIX-00006-00006	\N	\N	0.00	f	22342	\N	\N	0	\N
22344	20	Tarefa 4.1	\N	PREFIX-00006-00007	\N	\N	0.50	f	22342	\N	\N	1	\N
4980	30	Tarea 1.2	\N	PREFIX-00003-00004	\N	\N	0.20	f	4979	\N	\N	0	\N
4981	30	Tarea 1.1	\N	PREFIX-00003-00005	\N	\N	0.00	f	4979	\N	\N	1	\N
4982	31	Tarea 1.3	\N	PREFIX-00003-00006	\N	\N	0.25	f	4979	\N	\N	2	\N
82489	6	Tarefa 1	\N	PREFIX-00015-00001	\N	\N	0.00	f	82488	\N	\N	0	\N
25898	14	Tarefa 2	\N	PREFIX-00007-00002	\N	\N	0.00	f	25896	25437	\N	1	\N
25896	15	Pedido 3	\N	PREFIX-00007	2010-06-15 09:45:17.731	2010-09-22 00:00:00	0.05	f	\N	\N	\N	\N	\N
4983	30	Tarea 1.4	\N	PREFIX-00003-00007	\N	\N	0.00	f	4979	\N	\N	3	\N
25897	14	Tarefa 1	\N	PREFIX-00007-00001	\N	\N	0.20	f	25896	25436	\N	0	\N
25899	14	Recursos lim Tarefa 3	\N	PREFIX-00007-00003	\N	\N	0.25	f	25896	25438	\N	2	\N
25900	14	Tarefa 4	\N	PREFIX-00007-00004	\N	\N	0.00	f	25896	25439	\N	3	\N
25901	14	Tarefa 4.2	\N	PREFIX-00007-00006	\N	\N	0.00	f	25900	25440	\N	0	\N
25902	14	Tarefa 4.1	\N	PREFIX-00007-00007	\N	\N	0.00	f	25900	25441	\N	1	\N
25903	14	Tarefa 5	\N	PREFIX-00007-00005	\N	\N	0.00	f	25896	25442	\N	4	\N
82488	6	Pedido 3 escenario 2	\N	PREFIX-00015	2010-06-16 17:56:47.998	2010-11-26 00:00:00	0.00	f	\N	\N	\N	\N	\N
4991	30	Tarea 3.1	\N	PREFIX-00003-00013	\N	\N	0.00	f	4989	\N	\N	1	\N
7584	14	Tarea 1.4	\N	PREFIX-00005-00002	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	0.25	f	7576	\N	PREFIX-00003-00007	0	\N
7576	15	Desarrollo de un proyecto para el cliente.	\N	PREFIX-00005	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	0.25	f	\N	\N	\N	\N	\N
7577	14	Subtarefa 1.4.3	\N	PREFIX-00005-00001	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	0.30	f	7584	\N	\N	0	\N
7585	14	Subtarefa 1.4.1	\N	PREFIX-00005-00003	\N	\N	0.35	f	7584	\N	\N	1	\N
7586	14	Subtarefa 1.4.2	\N	PREFIX-00005-00004	\N	\N	0.00	f	7584	\N	\N	2	\N
4985	31	Tarea 2.2 	\N	PREFIX-00003-00008	\N	\N	0.00	t	4984	\N	\N	0	\N
1535	17	container 2	\N	PREFIX-00002-00002	\N	\N	0.00	f	1531	\N	\N	1	\N
1531	18	Pedido recursos limitantes	Pedido para proba con recursos limitantes	PREFIX-00002	2010-06-13 12:33:10.77	\N	0.24	f	\N	\N	\N	\N	\N
1532	17	container 1	\N	PREFIX-00002-00001	\N	\N	0.25	f	1531	\N	\N	0	\N
1533	17	tarefa limitantes 1	\N	PREFIX-00002-00003	\N	\N	0.50	f	1532	\N	\N	0	\N
1534	17	tarefa limitantes 2	\N	PREFIX-00002-00004	\N	\N	0.00	f	1532	\N	\N	1	\N
4984	31	Tarea2	\N	PREFIX-00003-00002	\N	\N	0.00	t	4952	\N	\N	1	\N
4986	30	Tarea 2.1	\N	PREFIX-00003-00009	\N	\N	0.00	f	4984	\N	\N	1	\N
4952	38	Pedido 1	\N	PREFIX-00003	2010-06-14 12:59:30.412	2010-09-23 00:00:00	0.03	t	\N	\N	\N	\N	\N
25956	5	Tarea 2.4	\N	PREFIX-00008-00011	\N	\N	0.00	f	25952	26622	\N	3	\N
31816	5	Tarea 3.2	\N	PREFIX-00008-00012	\N	\N	0.00	f	31815	26624	\N	0	\N
31817	5	Tarea 3.1	\N	PREFIX-00008-00013	\N	\N	0.00	f	31815	26625	\N	1	\N
31843	13	container 1	\N	PREFIX-00009-00001	\N	\N	0.00	f	31842	26651	\N	0	\N
31844	13	tarefa limitantes 1	\N	PREFIX-00009-00004	\N	\N	0.00	f	31843	26652	\N	0	\N
31845	13	tarefa limitantes 2	\N	PREFIX-00009-00005	\N	\N	0.00	f	31843	26653	\N	1	\N
43507	3	Tarefa 5	\N	PREFIX-00011-00005	\N	\N	0.00	f	43500	25442	\N	4	\N
43500	3	Pedido 2 Escenarios	\N	PREFIX-00011	2010-06-15 13:49:04.771	2010-09-22 00:00:00	0.00	f	\N	\N	\N	\N	\N
43501	3	Tarefa 1	\N	PREFIX-00011-00001	\N	\N	0.00	f	43500	25436	\N	0	\N
43502	3	Tarefa 2	\N	PREFIX-00011-00002	\N	\N	0.00	f	43500	25437	\N	1	\N
43503	3	Tarefa 3	\N	PREFIX-00011-00003	\N	\N	0.00	f	43500	25438	\N	2	\N
43504	3	Tarefa 4	\N	PREFIX-00011-00004	\N	\N	0.00	f	43500	25439	\N	3	\N
43505	3	Tarefa 4.2	\N	PREFIX-00011-00006	\N	\N	0.00	f	43504	25440	\N	0	\N
43465	15	Tarea 1.1	\N	PREFIX-00010-00005	\N	\N	0.00	f	43463	26615	\N	1	\N
31815	5	Tarea 3	\N	PREFIX-00008-00003	\N	\N	0.00	f	25946	26623	\N	2	\N
25946	5	Pedido 5	\N	PREFIX-00008	2010-09-08 00:00:00	2010-12-31 00:00:00	0.00	f	\N	\N	\N	\N	\N
25947	5	Tarea1	\N	PREFIX-00008-00001	\N	\N	0.00	f	25946	26613	\N	0	\N
25948	5	Tarea 1.2	\N	PREFIX-00008-00004	\N	\N	0.00	f	25947	26614	\N	0	\N
25949	5	Tarea 1.1	\N	PREFIX-00008-00005	\N	\N	0.00	f	25947	26615	\N	1	\N
25950	5	Tarea 1.3	\N	PREFIX-00008-00006	\N	\N	0.00	f	25947	26616	\N	2	\N
25951	5	Tarea 1.4	\N	PREFIX-00008-00007	\N	\N	0.00	f	25947	26617	\N	3	\N
25952	5	Tarea2	\N	PREFIX-00008-00002	\N	\N	0.00	f	25946	26618	\N	1	\N
25953	5	Tarea 2.2 	\N	PREFIX-00008-00008	\N	\N	0.00	f	25952	26619	\N	0	\N
25954	5	Tarea 2.1	\N	PREFIX-00008-00009	\N	\N	0.00	f	25952	26620	\N	1	\N
25955	5	Tarea 2.3	\N	PREFIX-00008-00010	\N	\N	0.00	f	25952	26621	\N	2	\N
43506	3	Tarefa 4.1	\N	PREFIX-00011-00007	\N	\N	0.00	f	43504	25441	\N	1	\N
43466	15	Tarea 1.3	\N	PREFIX-00010-00006	\N	\N	0.00	f	43463	26616	\N	2	\N
43467	15	Tarea 1.4	\N	PREFIX-00010-00007	\N	\N	0.00	f	43463	26617	\N	3	\N
43468	17	Tarea2	\N	PREFIX-00010-00002	\N	\N	0.04	f	43462	26618	\N	1	\N
43469	15	Tarea 2.2 	\N	PREFIX-00010-00008	\N	\N	0.00	f	43468	26619	\N	0	\N
82476	8	Tarefa 2	\N	PREFIX-00014-00002	\N	\N	0.00	f	82472	\N	\N	1	\N
82474	8	Subtarefa 1.1	\N	PREFIX-00014-00003	\N	\N	0.00	f	82473	\N	\N	0	\N
82475	8	Subtarefa 1.2	\N	PREFIX-00014-00004	\N	\N	0.00	f	82473	\N	\N	1	\N
82491	8	Subtarefa 1.2	\N	PREFIX-00016-00001	2010-07-09 12:59:30.412	2010-07-28 12:59:30.412	0.10	f	82496	\N	\N	0	\N
31846	13	container 2	\N	PREFIX-00009-00002	\N	\N	0.00	f	31842	26654	\N	1	\N
31847	13	tarefa limitantes 3	\N	PREFIX-00009-00006	\N	\N	0.00	f	31846	26655	\N	0	\N
31848	13	tarefa limitantes 4	\N	PREFIX-00009-00007	\N	\N	0.00	f	31846	26656	\N	1	\N
43470	15	Tarea 2.1	\N	PREFIX-00010-00009	\N	\N	0.00	f	43468	26620	\N	1	\N
43471	15	Tarea 2.3	\N	PREFIX-00010-00010	\N	\N	0.00	f	43468	26621	\N	2	\N
43472	15	Tarea 2.4	\N	PREFIX-00010-00011	\N	\N	0.10	f	43468	26622	\N	3	\N
43473	15	Tarea 3	\N	PREFIX-00010-00003	\N	\N	0.00	f	43462	26623	\N	2	\N
43474	15	Tarea 3.2	\N	PREFIX-00010-00012	\N	\N	0.00	f	43473	26624	\N	0	\N
43475	15	Tarea 3.1	\N	PREFIX-00010-00013	\N	\N	0.00	f	43473	26625	\N	1	\N
31849	13	tarefa limitantes 5	\N	PREFIX-00009-00003	\N	\N	0.00	f	31842	26657	\N	2	\N
43510	7	Recurso limitante xenérica	\N	PREFIX-00009-00008	\N	\N	0.00	f	31842	\N	\N	3	\N
43462	17	Pedido Escenario 2	\N	PREFIX-00010	2010-06-15 13:42:02.981	2010-09-23 00:00:00	0.01	f	\N	\N	\N	\N	\N
43463	15	Tarea1	\N	PREFIX-00010-00001	\N	\N	0.00	f	43462	26613	\N	0	\N
43464	15	Tarea 1.2	\N	PREFIX-00010-00004	\N	\N	0.00	f	43463	26614	\N	0	\N
31842	15	Pedido recursos limitantes 2	Pedido para proba con recursos limitantes	PREFIX-00009	2010-07-01 00:00:00	2010-09-01 00:00:00	0.00	f	\N	\N	\N	\N	\N
82473	8	Tarefa 1	\N	PREFIX-00014-00001	\N	\N	0.00	f	82472	\N	\N	0	\N
82472	8	Pedido con Andamieros	\N	PREFIX-00014	2011-02-16 00:00:00	2011-04-16 00:00:00	0.00	f	\N	\N	\N	\N	\N
82490	8	Montaje de andamios	\N	PREFIX-00016	2010-07-09 12:59:30.412	2010-07-28 12:59:30.412	0.15	f	\N	\N	\N	\N	\N
71665	13	Montaje de andamios	\N	PREFIX-00013	2010-07-16 00:00:00	2010-08-10 00:00:00	0.29	t	\N	\N	\N	\N	\N
71666	13	Tarea 2	\N	PREFIX-00013-00001	2010-07-16 00:00:00	2010-08-10 00:00:00	0.40	f	71671	\N	\N	0	\N
82496	7	Tarea 2.2 	\N	PREFIX-00016-00002	2010-07-09 12:59:30.412	2010-07-28 12:59:30.412	0.15	f	82490	\N	PREFIX-00003-00008	0	\N
82497	7	Subtarefa 1.1	\N	PREFIX-00016-00003	\N	\N	0.00	f	82496	\N	\N	1	\N
71652	16	Tarea1	\N	PREFIX-00012-00001	\N	\N	0.08	f	71651	26613	\N	0	\N
71651	16	Pedido 6	\N	PREFIX-00012	2010-07-16 00:00:00	2010-09-30 00:00:00	0.02	f	\N	\N	\N	\N	\N
71657	14	Tarea2	\N	PREFIX-00012-00002	\N	\N	0.00	f	71651	26618	\N	1	\N
71658	14	Tarea 2.2 	\N	PREFIX-00012-00008	\N	\N	0.00	f	71657	26619	\N	0	\N
71659	14	Tarea 2.1	\N	PREFIX-00012-00009	\N	\N	0.00	f	71657	26620	\N	1	\N
71660	14	Tarea 2.3	\N	PREFIX-00012-00010	\N	\N	0.00	f	71657	26621	\N	2	\N
71661	14	Tarea 2.4	\N	PREFIX-00012-00011	\N	\N	0.00	f	71657	26622	\N	3	\N
71662	14	Tarea 3	\N	PREFIX-00012-00003	\N	\N	0.00	f	71651	26623	\N	2	\N
71663	14	Tarea 3.2	\N	PREFIX-00012-00012	\N	\N	0.00	f	71662	26624	\N	0	\N
71664	14	Tarea 3.1	\N	PREFIX-00012-00013	\N	\N	0.00	f	71662	26625	\N	1	\N
71653	14	Tarea 1.2	\N	PREFIX-00012-00004	\N	\N	0.00	f	71652	26614	\N	0	\N
71654	14	Tarea 1.1	\N	PREFIX-00012-00005	\N	\N	0.00	f	71652	26615	\N	1	\N
71655	14	Tarea 1.3	\N	PREFIX-00012-00006	\N	\N	0.00	f	71652	26616	\N	2	\N
71656	16	Tarea 1.4	\N	PREFIX-00012-00007	\N	\N	0.29	f	71652	26617	\N	3	\N
82482	6	Tarefa Recurso limitantes N	\N	PREFIX-00009-00009	\N	\N	0.00	f	31842	\N	\N	4	\N
103436	8	Tarea 1	\N	PREFIX-00018-00001	\N	\N	0.00	f	103435	\N	\N	0	\N
103437	8	Tarea 2	\N	PREFIX-00018-00002	\N	\N	0.00	f	103435	\N	\N	1	\N
103439	8	Tarea 4	\N	PREFIX-00018-00004	\N	\N	0.00	f	103435	\N	\N	3	\N
109306	22	Autenticación con servicio REST de Guadalinfo	\N	PREFIX-00022-00031	\N	\N	0.00	f	109293	\N	\N	0	\N
109307	22	Autenticación vía OpenID	\N	PREFIX-00022-00032	\N	\N	0.00	f	109293	\N	\N	1	\N
109308	22	Sistema de etiquetado	\N	PREFIX-00022-00030	\N	\N	0.00	f	108881	\N	\N	6	\N
103438	8	Tarea 3	\N	PREFIX-00018-00003	\N	\N	0.00	f	103435	\N	\N	2	\N
103435	8	Construcción de barco 1	Desc.	PREFIX-00018	2010-07-05 15:14:38.224	2010-07-28 00:00:00	0.00	f	\N	\N	\N	\N	\N
108881	31	Proyecto consistente en montaje de prototipo para PLE para Guadalinfo con la implantación de Mugshot	\N	PREFIX-00022	2010-09-01 00:00:00	2011-01-31 00:00:00	0.00	f	\N	\N	\N	\N	\N
108927	28	Coordinación	\N	PREFIX-00022-00001	\N	\N	0.00	f	108881	\N	\N	0	\N
108928	28	Análisis	\N	PREFIX-00022-00002	\N	\N	0.00	f	108881	\N	\N	1	\N
109312	21	Adaptación visual	\N	PREFIX-00022-00033	\N	\N	0.00	f	108881	\N	\N	12	\N
156664	3	Pedido 1	\N	PREFIX-00028	2010-09-02 13:49:51.32	2013-09-02 00:00:00	0.00	f	\N	\N	\N	\N	156765
156665	3	Coordinación	\N	PREFIX-00028-00001	\N	\N	0.00	f	156664	\N	\N	0	156766
156666	3	Coordinación (copy)	\N	PREFIX-00028-00004	\N	\N	0.00	f	156665	\N	\N	0	156767
156667	3	Exempl o1	\N	PREFIX-00028-00005	\N	\N	0.00	f	156665	\N	\N	1	156768
156668	3	Exemplo 2	\N	PREFIX-00028-00002	\N	\N	0.00	f	156664	\N	\N	1	156769
156669	3	Exemplo 3	\N	PREFIX-00028-00003	\N	\N	0.00	f	156664	\N	\N	2	156770
105561	10	tarefa3	\N	PREFIX-00019-00003	\N	\N	0.00	f	105558	\N	\N	2	\N
105558	10	Barco 1	\N	PREFIX-00019	2010-07-06 11:46:27.203	2010-09-22 00:00:00	0.07	f	\N	\N	\N	\N	\N
105559	10	tqrefa1	\N	PREFIX-00019-00001	\N	\N	0.25	f	105558	\N	\N	0	\N
105560	10	tarefa2	\N	PREFIX-00019-00002	\N	\N	0.00	f	105558	\N	\N	1	\N
105562	10	subtarefa 3.1	\N	PREFIX-00019-00004	\N	\N	0.00	f	105561	\N	\N	0	\N
105563	10	subtarefa 1	\N	PREFIX-00019-00005	\N	\N	0.00	f	105561	\N	\N	1	\N
108940	28	Documentación	\N	PREFIX-00022-00011	\N	\N	0.00	f	108881	\N	\N	10	\N
108929	28	Implantación de Mugshot	\N	PREFIX-00022-00003	\N	\N	0.00	f	108881	\N	\N	2	\N
108930	28	Implantación del servidor	\N	PREFIX-00022-00013	\N	\N	0.00	f	108929	\N	\N	0	\N
108931	28	Parametrización del servidor	\N	PREFIX-00022-00014	\N	\N	0.00	f	108929	\N	\N	1	\N
108932	28	Parametrización de páginas	\N	PREFIX-00022-00015	\N	\N	0.00	f	108929	\N	\N	2	\N
108933	28	Implantación de cliente de escritorio	\N	PREFIX-00022-00004	\N	\N	0.00	f	108881	\N	\N	3	\N
108934	28	Pruebas y adaptación de Facebook	\N	PREFIX-00022-00005	\N	\N	0.00	f	108972	\N	\N	0	\N
108935	28	CU – Mostrado de nube de tags	\N	PREFIX-00022-00006	\N	\N	0.00	f	109308	\N	\N	0	\N
108937	28	Arquitectura	\N	PREFIX-00022-00008	\N	\N	0.00	f	108881	\N	\N	7	\N
108938	28	Infraestructura del proyecto	\N	PREFIX-00022-00009	\N	\N	0.00	f	108881	\N	\N	8	\N
108939	28	Pruebas	\N	PREFIX-00022-00010	\N	\N	0.00	f	108881	\N	\N	9	\N
108941	28	Entorno	\N	PREFIX-00022-00012	\N	\N	0.00	f	108881	\N	\N	11	\N
109315	6	Implantación	\N	PREFIX-00022-00034	\N	\N	0.00	f	108881	\N	\N	13	\N
157171	3	Pedido	\N	PREFIX-00029	2010-09-02 14:01:05.566	2011-12-02 00:00:00	0.00	f	\N	\N	\N	\N	157272
157172	3	Coordinacion	\N	PREFIX-00029-00001	\N	\N	0.00	f	157171	\N	\N	0	157273
157173	3	Coordinacion (copy)	\N	PREFIX-00029-00005	\N	\N	0.00	f	157172	\N	\N	0	157274
157174	3	tarefa interna	\N	PREFIX-00029-00006	\N	\N	0.00	f	157172	\N	\N	1	157275
157175	3	Tarefa 1	\N	PREFIX-00029-00002	\N	\N	0.00	f	157171	\N	\N	1	157276
157176	3	Tarefa 2	\N	PREFIX-00029-00003	\N	\N	0.00	f	157171	\N	\N	2	157277
157177	3	Tarefa 3	\N	PREFIX-00029-00004	\N	\N	0.00	f	157171	\N	\N	3	157278
108972	27	Integración con redes sociales	\N	PREFIX-00022-00016	\N	\N	0.00	f	108881	\N	\N	4	\N
108973	26	Pruebas y adaptación de Last.fm	\N	PREFIX-00022-00017	\N	\N	0.00	f	108972	\N	\N	1	\N
108974	26	Pruebas y adaptación de Rhapsody	\N	PREFIX-00022-00018	\N	\N	0.00	f	108972	\N	\N	2	\N
108975	26	Pruebas y adaptación de Google Reader	\N	PREFIX-00022-00019	\N	\N	0.00	f	108972	\N	\N	3	\N
108976	26	Pruebas y adaptación de Digg and Reddit	\N	PREFIX-00022-00020	\N	\N	0.00	f	108972	\N	\N	4	\N
108977	26	Pruebas y adaptación de Flickr	\N	PREFIX-00022-00021	\N	\N	0.00	f	108972	\N	\N	5	\N
108978	26	Pruebas y adaptación de Twitter	\N	PREFIX-00022-00022	\N	\N	0.00	f	108972	\N	\N	6	\N
109282	26	Pruebas y adaptación de Delicious	\N	PREFIX-00022-00023	\N	\N	0.00	f	108972	\N	\N	7	\N
109283	26	Pruebas y adaptación de RSS	\N	PREFIX-00022-00024	\N	\N	0.00	f	108972	\N	\N	8	\N
109284	26	Pruebas y adaptación de Youtube	\N	PREFIX-00022-00025	\N	\N	0.00	f	108972	\N	\N	9	\N
150189	3	Implementación y pruebas de integración con Tuenti	\N	PREFIX-00022-00035	\N	\N	0.00	f	108972	\N	\N	10	\N
109293	24	Sistema de autenticación	\N	PREFIX-00022-00026	\N	\N	0.00	f	108881	\N	\N	5	\N
109295	24	CU – Edición de etiquetas de recurso	\N	PREFIX-00022-00028	\N	\N	0.00	f	109308	\N	\N	1	\N
109294	24	CU – Asignación de etiqueta a recurso de Mugshot.	\N	PREFIX-00022-00027	\N	\N	0.00	f	109308	\N	\N	2	\N
109296	24	CU – Edición de etiquetas de recurso	\N	PREFIX-00022-00029	\N	\N	0.00	f	109308	\N	\N	3	\N
152513	12	Desarrollo web Personalia	Desc.	PREFIX-00024	2010-09-19 00:00:00	2010-11-15 00:00:00	0.00	f	\N	\N	\N	\N	152614
158181	3	Desc.	Desc	PREFIX-00031	2010-09-02 14:13:33.312	2010-12-02 00:00:00	0.00	f	\N	\N	\N	\N	158282
158182	3	Coordiacion	\N	PREFIX-00031-00001	\N	\N	0.00	f	158181	\N	\N	0	158283
158183	3	Coordiacion (copy)	\N	PREFIX-00031-00003	\N	\N	0.00	f	158182	\N	\N	0	158284
158184	3	asfasf	\N	PREFIX-00031-00004	\N	\N	0.00	f	158182	\N	\N	1	158285
158185	3	Desc	\N	PREFIX-00031-00002	\N	\N	0.00	f	158181	\N	\N	1	158286
158186	3	Desc (copy)	\N	PREFIX-00031-00005	\N	\N	0.00	f	158185	\N	\N	0	158287
158187	3	asdasdfsdf	\N	PREFIX-00031-00006	\N	\N	0.00	f	158185	\N	\N	1	158288
152608	10	Comunicaciones con implicados	\N	PREFIX-00024-00010	\N	\N	0.00	f	152605	\N	\N	2	152709
152609	10	Reuniones de coordinación	\N	PREFIX-00024-00011	\N	\N	0.00	f	152605	\N	\N	3	152710
152610	10	Control de la calidad	\N	PREFIX-00024-00012	\N	\N	0.00	f	152605	\N	\N	4	152711
153015	10	Seguimiento	\N	PREFIX-00024-00013	\N	\N	0.00	f	152605	\N	\N	5	153116
153034	10	Análisis	\N	PREFIX-00024-00014	\N	\N	0.00	f	152513	\N	\N	1	153135
153016	10	Noticias y eventos	\N	PREFIX-00024-00002	\N	\N	0.00	f	153034	\N	\N	0	153117
153035	9	Arquitectura de contenidos	\N	PREFIX-00024-00015	\N	\N	0.00	f	153034	\N	\N	1	153136
153036	9	Deficiones de entidades	\N	PREFIX-00024-00016	\N	\N	0.00	f	153034	\N	\N	2	153137
153037	9	Análisis funcional	\N	PREFIX-00024-00017	\N	\N	0.00	f	153034	\N	\N	3	153138
153044	9	Módulo de usuarios	\N	PREFIX-00024-00018	\N	\N	0.00	f	152513	\N	\N	2	153145
153017	11	Configuración de permisos y grupos	\N	PREFIX-00024-00003	\N	\N	0.00	f	153044	\N	\N	0	153118
153045	9	Configuración sistema de usuarios	\N	PREFIX-00024-00019	\N	\N	0.00	f	153044	\N	\N	1	153146
153018	11	Montaje del árbol de contenidos	\N	PREFIX-00024-00004	\N	\N	0.00	f	153076	\N	\N	0	153119
153021	11	Implantación	\N	PREFIX-00024-00007	\N	\N	0.00	f	152513	\N	\N	6	153122
153020	11	Formación	\N	PREFIX-00024-00006	\N	\N	0.00	f	152513	\N	\N	5	153121
152605	11	Coordinación	\N	PREFIX-00024-00001	\N	\N	0.00	f	152513	\N	\N	0	152706
152606	10	Informes periódicos	\N	PREFIX-00024-00008	\N	\N	0.00	f	152605	\N	\N	0	152707
152607	10	Planificación periódica	\N	PREFIX-00024-00009	\N	\N	0.00	f	152605	\N	\N	1	152708
158715	25	Soldar unións do chan	\N	PREFIX-00032-00008	\N	\N	0.30	f	158712	\N	\N	2	158816
158716	25	Bloque 2 - 1 	\N	PREFIX-00032-00003	\N	\N	0.50	f	158708	\N	\N	2	158817
158717	25	Cama e mesilla do camarote	\N	PREFIX-00032-00009	\N	\N	0.00	f	158716	\N	\N	0	158818
158718	25	Teito de madeira de camarote	\N	PREFIX-00032-00010	\N	\N	0.00	f	158716	\N	\N	1	158819
158719	25	Poñer escotillas a camarote	\N	PREFIX-00032-00011	\N	\N	0.00	f	158716	\N	\N	2	158820
158708	31	Pedido grupo 1	Desc.	PREFIX-00032	2010-09-02 16:56:16.759	2010-12-02 00:00:00	0.38	f	\N	\N	\N	\N	158809
167383	2	Limitante	\N	PREFIX-00032-00012	\N	\N	0.00	f	158708	\N	\N	3	167484
153076	8	Gestión de contenidos y plantillas	\N	PREFIX-00024-00020	\N	\N	0.00	f	152513	\N	\N	3	153177
153077	8	Implantación de diseño general	\N	PREFIX-00024-00023	\N	\N	0.00	f	153076	\N	\N	1	153178
153078	8	Migración de contenidos	\N	PREFIX-00024-00024	\N	\N	0.00	f	153076	\N	\N	2	153179
153079	8	Montaje herramienta galería	\N	PREFIX-00024-00025	\N	\N	0.00	f	153076	\N	\N	3	153180
153080	8	Montaje herramienta noticias	\N	PREFIX-00024-00026	\N	\N	0.00	f	153076	\N	\N	4	153181
153081	8	configuración de secciones y subsecciones principales	\N	PREFIX-00024-00027	\N	\N	0.00	f	153076	\N	\N	5	153182
153082	8	Centros	\N	PREFIX-00024-00028	\N	\N	0.00	f	153076	\N	\N	6	153183
153083	8	Entorno	\N	PREFIX-00024-00021	\N	\N	0.00	f	152513	\N	\N	4	153184
153019	10	Configuración básica	\N	PREFIX-00024-00005	\N	\N	0.00	f	153083	\N	\N	0	153120
153084	7	Gestión de repositorios	\N	PREFIX-00024-00029	\N	\N	0.00	f	153083	\N	\N	1	153185
153085	8	Pruebas	\N	PREFIX-00024-00022	\N	\N	0.00	f	152513	\N	\N	7	153186
158709	25	Coordinación	\N	PREFIX-00032-00001	\N	\N	0.25	f	158708	\N	\N	0	158810
158710	24	Reunións con traballadores	\N	PREFIX-00032-00004	\N	\N	0.00	f	158709	\N	\N	0	158811
158711	24	Reunións con cliente	\N	PREFIX-00032-00005	\N	\N	0.00	f	158709	\N	\N	1	158812
158712	25	Bloque 1	\N	PREFIX-00032-00002	\N	\N	0.28	f	158708	\N	\N	1	158813
158713	25	Repasar soldaduras ocos	\N	PREFIX-00032-00006	\N	\N	0.00	f	158712	\N	\N	0	158814
158714	25	Soldar unións do teito	\N	PREFIX-00032-00007	\N	\N	0.40	f	158712	\N	\N	1	158815
\.


--
-- Data for Name: orderelementtemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelementtemplate (id, version, name, description, code, startasdaysfrombeginning, deadlineasdaysfrombeginning, schedulingstatetype, parent, positionincontainer) FROM stdin;
26650	1	Pedido recursos limitantes	Pedido para proba con recursos limitantes	PREFIX-00002	0	\N	3	\N	\N
26651	1	container 1	\N	PREFIX-00002-00001	\N	\N	3	26650	0
26612	1	Pedido 1 Template	\N	PREFIX-00003	0	100	3	\N	\N
26654	1	container 2	\N	PREFIX-00002-00002	\N	\N	3	26650	1
26657	1	tarefa limitantes 5	\N	PREFIX-00002-00007	\N	\N	0	26650	2
26652	1	tarefa limitantes 1	\N	PREFIX-00002-00003	\N	\N	0	26651	0
26653	1	tarefa limitantes 2	\N	PREFIX-00002-00004	\N	\N	0	26651	1
26655	1	tarefa limitantes 3	\N	PREFIX-00002-00005	\N	\N	0	26654	0
26656	1	tarefa limitantes 4	\N	PREFIX-00002-00006	\N	\N	0	26654	1
26613	1	Tarea1	\N	PREFIX-00003-00001	\N	\N	3	26612	0
26618	1	Tarea2	\N	PREFIX-00003-00002	\N	\N	3	26612	1
26623	1	Tarea 3	\N	PREFIX-00003-00003	\N	\N	3	26612	2
26614	1	Tarea 1.2	\N	PREFIX-00003-00004	\N	\N	0	26613	0
26615	1	Tarea 1.1	\N	PREFIX-00003-00005	\N	\N	0	26613	1
26616	1	Tarea 1.3	\N	PREFIX-00003-00006	\N	\N	0	26613	2
26617	1	Tarea 1.4	\N	PREFIX-00003-00007	\N	\N	0	26613	3
26619	1	Tarea 2.2 	\N	PREFIX-00003-00008	\N	\N	0	26618	0
26620	1	Tarea 2.1	\N	PREFIX-00003-00009	\N	\N	0	26618	1
26621	1	Tarea 2.3	\N	PREFIX-00003-00010	\N	\N	0	26618	2
26622	1	Tarea 2.4	\N	PREFIX-00003-00011	\N	\N	0	26618	3
26624	1	Tarea 3.2	\N	PREFIX-00003-00012	\N	\N	0	26623	0
26625	1	Tarea 3.1	\N	PREFIX-00003-00013	\N	\N	0	26623	1
25435	2	Pedido 2 Template	\N	PREFIX-00006	0	99	3	\N	\N
25436	2	Tarefa 1	\N	PREFIX-00006-00001	\N	\N	0	25435	0
25437	2	Tarefa 2	\N	PREFIX-00006-00002	\N	\N	0	25435	1
25438	2	Tarefa 3	\N	PREFIX-00006-00003	\N	\N	0	25435	2
25439	2	Tarefa 4	\N	PREFIX-00006-00004	\N	\N	3	25435	3
25440	2	Tarefa 4.2	\N	PREFIX-00006-00006	\N	\N	0	25439	0
25441	2	Tarefa 4.1	\N	PREFIX-00006-00007	\N	\N	0	25439	1
25442	2	Tarefa 5	\N	PREFIX-00006-00005	\N	\N	0	25435	4
105257	1	Construcción de barco de tipo 3	Desc.	PREFIX-00018	0	22	3	\N	\N
166896	1	Bloque 2	\N	PREFIX-00032-00003	\N	\N	3	166888	2
166890	1	Reunións con traballadores	\N	PREFIX-00032-00004	\N	\N	1	166889	0
166891	1	Reunións con cliente	\N	PREFIX-00032-00005	\N	\N	1	166889	1
166893	1	Repasar soldaduras ocos	\N	PREFIX-00032-00006	\N	\N	0	166892	0
105258	1	Tarea 1	\N	PREFIX-00018-00001	\N	\N	0	105257	0
105259	1	Tarea 2	\N	PREFIX-00018-00002	\N	\N	0	105257	1
105260	1	Tarea 3	\N	PREFIX-00018-00003	\N	\N	0	105257	2
105261	1	Tarea 4	\N	PREFIX-00018-00004	\N	\N	0	105257	3
166888	1	Plantilla - Pedido grupo 1	Desc.	PREFIX-00032	0	90	3	\N	\N
166889	1	Coordinación	\N	PREFIX-00032-00001	\N	\N	0	166888	0
166892	1	Bloque 1	\N	PREFIX-00032-00002	\N	\N	3	166888	1
166894	1	Soldar unións do teito	\N	PREFIX-00032-00007	\N	\N	0	166892	1
166895	1	Soldar unións do chan	\N	PREFIX-00032-00008	\N	\N	0	166892	2
166897	1	Cama e mesilla do camarote	\N	PREFIX-00032-00009	\N	\N	0	166896	0
166898	1	Teito de madeira de camarote	\N	PREFIX-00032-00010	\N	\N	0	166896	1
166899	1	Poñer escotillas a camarote	\N	PREFIX-00032-00011	\N	\N	0	166896	2
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid, lasthoursgroupsequencecode) FROM stdin;
43507	1
1533	1
1534	1
1543	1
1536	1
71666	1
71672	1
4980	1
82476	1
82474	1
82475	1
43501	1
43502	1
43503	1
43505	1
43506	1
1537	1
4981	2
4982	1
4983	1
4985	1
4986	1
4987	1
7577	1
7585	1
7586	1
4988	1
4990	1
4991	1
25948	1
25949	2
25950	1
25951	1
25953	1
25954	1
25955	1
25956	1
31816	1
31817	1
82491	1
82497	1
22345	1
22339	1
43464	1
43465	2
43466	1
43467	1
43469	1
43470	1
43471	1
43472	1
43474	1
43475	1
25898	1
25897	1
25899	1
25901	1
25902	1
25903	1
22340	1
22341	1
22343	1
22344	1
71658	1
71659	1
43510	1
31844	1
31845	1
31847	1
31848	1
31849	1
82482	1
71660	1
71661	1
71663	1
71664	1
71653	1
71654	2
71655	1
71656	1
82489	1
109284	1
150189	1
109306	1
109307	1
108935	1
109295	1
153020	1
103438	1
103436	1
103437	1
103439	1
152606	1
152607	1
109294	1
109296	1
108937	1
152608	1
108938	1
152609	1
152610	1
108940	1
108927	1
108928	1
108930	1
108931	1
105559	1
105560	1
105562	1
105563	1
108932	1
108939	1
108941	1
109312	1
109315	1
156666	1
156667	1
156668	1
156669	1
108933	1
108934	1
108973	1
108974	1
108975	1
108976	1
108977	1
157173	1
157174	1
157175	1
157176	1
157177	1
158183	1
158184	1
158186	1
158187	1
108978	1
109282	1
109283	1
153015	1
153016	1
153035	1
153036	1
153037	1
153017	1
153045	1
153018	1
153077	1
153078	1
167383	1
158710	1
158711	1
153079	1
153080	1
153081	1
153082	1
153019	1
153084	1
153021	1
153085	1
158713	1
158714	1
158715	1
158717	1
158718	1
158719	1
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1531
1532
1535
4952
4979
4984
4989
7576
7584
22338
22342
25896
25900
25946
25947
25952
31815
31842
31843
31846
43462
43463
43468
43473
43500
43504
71651
71652
71657
71662
71665
71671
82472
82473
82488
82490
82496
103435
105558
105561
108881
108929
108972
109293
109308
152513
152605
153034
153044
153076
153083
156664
156665
157171
157172
158181
158182
158185
158708
158709
158712
158716
\.


--
-- Data for Name: orderlinegrouptemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegrouptemplate (group_template_id) FROM stdin;
25435
25439
26612
26613
26618
26623
26650
26651
26654
105257
166888
166889
166892
166896
\.


--
-- Data for Name: orderlinetemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinetemplate (order_line_template_id, lasthoursgroupsequencecode) FROM stdin;
26614	0
26615	0
26616	0
26617	0
26619	0
26620	0
26621	0
26622	0
26624	0
26625	0
25436	0
25437	0
25438	0
25440	0
25441	0
25442	0
26652	0
26653	0
26655	0
26656	0
26657	0
105258	0
105259	0
105260	0
105261	0
166890	0
166891	0
166893	0
166894	0
166895	0
166897	0
166898	0
166899	0
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
303	40	PREFIX	37	5	t
\.


--
-- Data for Name: ordertemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordertemplate (order_template_id, base_calendar_id) FROM stdin;
26612	1
25435	1
26650	1
105257	1
166888	1
\.


--
-- Data for Name: orderversion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderversion (id, version, modificationbyownertimestamp, ownerscenario) FROM stdin;
82636	2	2010-06-16 17:59:16.918	707
72118	16	2010-06-16 18:00:19.408	707
82649	1	2010-06-16 18:03:00.958	38380
82650	1	2010-06-16 18:05:06.519	707
82631	2	2010-06-16 16:52:38.041	707
82651	1	2010-06-16 18:05:06.519	707
82652	1	2010-06-16 18:05:21.287	707
26180	17	2010-06-15 17:07:12.613	38380
26185	8	2010-06-15 16:52:47.491	707
72117	20	2010-06-16 11:05:03.225	707
109085	2	2010-07-08 10:21:36.345	707
26168	41	2010-06-16 18:00:23.966	707
64640	26	2010-06-15 17:14:12.93	38380
82635	28	2010-06-16 18:02:28.943	38380
5154	74	2010-06-16 18:22:51.177	707
82653	31	2010-06-16 18:28:55.715	707
109083	55	2010-07-08 17:31:22.919	707
82648	25	2010-06-16 18:03:00.958	38380
105751	2	2010-07-06 11:49:01.688	707
105750	28	2010-07-06 12:31:41.451	707
82630	34	2010-06-16 18:00:19.664	707
158472	7	2010-09-02 14:17:20.766	707
26184	28	2010-06-15 13:50:02.701	38380
7778	51	2010-06-16 18:00:24.605	707
1721	56	2010-06-16 18:00:29.089	707
152819	2	2010-08-30 14:15:18.823	707
26172	53	2010-06-16 18:00:24.73	707
109086	2	2010-07-08 10:21:36.345	707
103629	30	2010-07-05 15:23:11.277	707
156957	9	2010-09-02 13:53:40.34	707
103630	2	2010-07-05 15:16:06.831	707
157462	8	2010-09-02 14:02:34.787	707
22526	59	2010-06-16 18:00:31.729	707
152816	23	2010-08-30 14:49:36.31	707
26164	50	2010-06-16 18:00:36.278	707
105752	2	2010-07-06 11:49:01.688	707
158981	2	2010-09-02 16:59:55.503	707
103631	2	2010-07-05 15:16:06.831	707
152820	2	2010-08-30 14:15:18.823	707
158979	2	2010-09-02 16:59:55.503	707
152817	2	2010-08-30 14:15:18.823	707
158978	34	2010-09-06 17:43:44.527	707
152818	2	2010-08-30 14:15:18.823	707
152821	2	2010-08-30 14:15:18.823	707
109084	2	2010-07-08 10:21:36.345	707
158980	2	2010-09-02 16:59:55.503	707
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype, reportadvance, advance_type_id) FROM stdin;
165539	1	Formulario de calidade	Calidade	0	t	165438
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
165539	Entrega doc.	25.00	0	0
165539	Revisión procesos de calidade	50.00	1	1
165539	certificación	75.00	2	2
165539	Completado	100.00	3	3
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, code, generatecode, limited_resource, base_calendar_id) FROM stdin;
4356	20	2211b5bd-80f0-4f60-a5da-bc8f1de8b94e	t	f	4449
72321	7	8d11a0e5-fe7d-418a-94d6-2e9d526dd921	t	f	72419
1214	20	5aef0e25-573b-442e-b321-ce6c3be6608b	t	f	2
72317	18	056db5ff-1776-4ac5-8ab8-33595df6b3cb	t	f	72417
83633	14	5d0ebf6a-7b20-4353-9274-1082dff37e6f	t	f	83732
72319	18	08ca766e-1984-4015-9bee-1754660398a2	t	f	72418
4352	162	94cf72ff-85f9-4eb0-bb30-2f0518688201	t	f	4447
4354	163	3767394d-4be9-4a09-b7cf-42da82a53b24	t	f	4448
1216	32	bb5d29ab-e802-4d90-841a-2cc87d937a6d	t	t	3
1220	39	d692db0b-e344-467d-8cd5-c746c94ae8f4	t	t	5
4348	121	62f19cfb-2859-4bbb-91d6-b178cb48eb2f	t	f	4445
4350	121	98a4b590-e399-43f0-a46f-f11358cb6445	t	f	4446
21817	65	0b1cfd52-d327-4d01-9bf9-e64626a5ec2d	t	f	21917
4358	121	62dee224-2641-4c34-bbc6-153f98cdf250	t	f	4450
4344	122	e3974c04-4785-407d-bea4-0aa4530f8a02	t	f	4444
107364	2	fc0dd16c-d97e-4040-a5ec-c589039a6256	t	f	107464
111404	1	bdd8ffe9-335f-4210-b575-4eb76014f87b	t	f	111504
151905	1	14c8d487-4224-4939-a0bd-620efcd7f0b8	t	f	152005
151907	2	85db40f0-2f8c-4c82-9e02-8a44297e4459	t	f	152006
111406	2	246c611a-c69d-4399-b23a-46d8295d833e	t	f	111505
151915	9	6d6bff5d-4de6-4735-af33-d2905f1feb57	t	f	152011
151909	11	20782924-2339-4d6a-b710-6c1a8c175f0e	t	f	152009
154733	11	f79ed622-0f9d-450e-9f7b-a3e192fefa82	t	f	154833
167965	1	c9d5ade4-df16-42c7-83f0-baf585db3459	t	f	168266
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, intended_total_hours, originaltotalassignment, task, assignment_function) FROM stdin;
83152	2	2.00	\N	50	83057	\N
83153	2	3.00	\N	20	83058	\N
2288	11	1.00	100	100	2125	\N
45988	2	1.16	\N	400	26522	\N
2225	12	1.00	100	100	2121	\N
2226	13	1.00	100	100	2122	\N
2287	10	1.00	100	100	2124	\N
26993	1	1.00	\N	300	2129	\N
7894	4	0.99	\N	150	9292	\N
7901	2	1.00	\N	200	9293	\N
27065	8	1.00	100	100	26484	\N
27066	7	1.00	100	100	26485	\N
27062	7	1.00	300	300	26490	\N
72925	5	3.00	\N	210	72215	\N
72929	4	3.00	\N	150	72216	\N
72930	4	3.00	\N	101	72217	\N
27063	8	1.00	100	100	26487	\N
27064	7	1.00	100	100	26488	\N
43944	6	1.00	\N	210	26514	\N
43945	6	1.00	\N	150	26515	\N
43936	3	1.00	\N	210	26492	\N
43941	2	1.00	\N	150	26493	\N
45989	1	1.00	\N	210	64741	\N
43946	6	1.00	300	300	26528	\N
45990	1	1.00	\N	150	64742	\N
45991	1	1.16	\N	400	64749	\N
26970	10	1.00	\N	200	26463	\N
26973	10	1.00	\N	150	26465	\N
26974	10	1.00	\N	200	26466	\N
43943	0	1.00	\N	100	26506	\N
27057	4	1.00	100	100	26464	\N
26989	5	0.96	\N	100	26462	\N
26972	10	1.00	\N	100	26468	\N
83125	3	3.00	\N	100	83022	\N
27042	1	1.00	\N	210	26470	\N
27043	1	1.00	\N	150	26471	\N
27044	1	1.00	\N	101	26472	\N
27045	1	1.00	\N	200	26473	\N
27046	1	1.00	\N	100	26475	\N
27047	1	1.00	\N	200	26476	\N
27048	1	1.00	\N	200	26477	\N
27049	1	1.00	\N	400	26478	\N
27040	1	1.00	\N	150	26480	\N
27041	1	1.00	\N	200	26481	\N
83126	3	3.00	\N	100	83023	\N
83128	2	3.00	\N	100	83025	\N
7902	5	1.00	\N	52	9294	\N
7892	12	0.96	\N	48	9294	\N
83131	3	1.00	200	200	83027	\N
83130	5	2.43	\N	530	22830	\N
83135	0	1.00	\N	1000	83028	\N
83140	2	1.00	\N	50	83047	\N
83141	1	1.00	\N	50	83049	\N
83142	1	1.00	\N	50	83053	\N
16672	8	1.00	\N	150	5464	\N
16673	8	1.00	\N	200	5465	\N
5861	20	1.15	\N	310	5454	\N
5863	16	0.99	\N	150	5455	\N
7878	15	1.00	101	101	5456	\N
7908	9	1.00	\N	200	5460	\N
16701	9	1.00	\N	200	22827	\N
16699	12	0.96	\N	137	22826	\N
72931	7	1.00	100	100	22828	\N
116143	6	0.49	\N	63	109715	\N
111911	7	1.00	\N	56	109713	\N
111908	9	0.13	\N	91	109687	\N
116138	6	0.46	\N	26	109707	\N
104135	2	0.99	\N	150	103931	\N
104136	2	0.78	\N	50	103932	\N
104137	2	1.00	\N	200	103930	\N
104138	2	1.00	\N	200	103929	\N
116139	6	0.63	\N	25	109708	\N
116140	6	1.00	\N	40	109709	\N
116141	6	0.88	\N	28	109710	\N
106354	3	5.00	\N	200	106151	\N
106358	0	0.00	100	0	106152	\N
111909	9	0.13	\N	105	109686	\N
111912	7	0.98	\N	126	109712	\N
116144	6	0.63	\N	35	109704	\N
116145	6	0.63	\N	35	109705	\N
128483	5	1.00	\N	56	109717	\N
116135	6	0.61	\N	63	109688	\N
116136	6	0.63	\N	35	109689	\N
116137	6	0.63	\N	35	109690	\N
116142	6	0.31	\N	35	109714	\N
116134	6	0.62	\N	84	109692	\N
111910	8	0.13	\N	70	109716	\N
128484	5	0.88	\N	21	109693	\N
128485	5	0.88	\N	21	109694	\N
128486	5	0.88	\N	21	109695	\N
128496	1	0.94	\N	60	109720	\N
128487	5	0.88	\N	21	109696	\N
128488	5	0.88	\N	21	109697	\N
128489	5	0.88	\N	21	109698	\N
128490	5	0.88	\N	21	109699	\N
128491	5	0.88	\N	21	109700	\N
128492	5	0.88	\N	21	109701	\N
128493	5	0.88	\N	21	109702	\N
151205	0	0.97	\N	70	150692	\N
153621	2	0.15	\N	49	153520	\N
153622	2	0.13	\N	16	153521	\N
153667	1	0.88	\N	7	153522	\N
153668	1	0.88	\N	7	153523	\N
153669	1	0.88	\N	7	153525	\N
153670	1	0.95	\N	53	153526	\N
153671	1	0.88	\N	14	153527	\N
153672	1	0.88	\N	14	153528	\N
153673	1	0.88	\N	14	153529	\N
153674	1	0.88	\N	35	153530	\N
153675	1	0.88	\N	28	153531	\N
153676	1	0.14	\N	10	153533	\N
153681	0	0.88	\N	7	153534	\N
153682	0	0.88	\N	7	153535	\N
153683	0	0.88	\N	14	153536	\N
159517	9	0.96	\N	100	159278	\N
159518	9	0.83	\N	200	159279	\N
159519	9	1.00	\N	200	159280	\N
159520	9	2.21	\N	300	159282	\N
159521	9	1.84	\N	250	159283	\N
159481	11	1.16	\N	200	159277	164025
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
2	1
5	1
4444	1
4445	1
4446	1
4447	1
4448	1
4449	1
4450	1
21917	1
72417	1
72418	1
72419	1
83732	1
3	1
107464	1
111504	1
152005	1
152006	1
111505	1
152011	1
152009	1
154833	1
168266	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, code, initdate, enddate, cost_category_id, resource_id) FROM stdin;
165035	1	c9acf2f6-c77d-4ebb-aa1f-99f8138f0251	2010-09-03	\N	164833	151915
165036	2	f3fb0b4c-3f3d-46c8-b719-7891ba1c45e9	2010-09-03	\N	164833	151909
165034	2	ee3e360b-cb43-4569-adc7-a09aad7637db	2010-09-03	\N	164832	154733
\.


--
-- Data for Name: scenario; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scenario (id, version, name, description, lastnotownedreassignationstimestamp, predecessor) FROM stdin;
707	0	master	\N	\N	\N
38380	27	Escenario 2	Escenario de proba.	\N	707
\.


--
-- Data for Name: scenario_orders; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scenario_orders (order_id, order_version_id, scenario_id) FROM stdin;
1531	1721	707
4952	5154	707
7576	7778	707
22338	22526	707
25896	26164	707
25946	26168	707
31842	26172	707
25946	26168	38380
7576	7778	38380
1531	1721	38380
4952	5154	38380
31842	26172	38380
22338	22526	38380
25896	26164	38380
43500	26184	38380
43462	26185	707
43462	64640	38380
71651	72117	707
82472	82630	707
82472	82630	38380
82488	82635	38380
82488	82636	707
71665	82648	38380
71665	82652	707
82490	82653	38380
82490	82653	707
103435	103629	707
103435	103629	38380
105558	105750	707
105558	105750	38380
108881	109083	707
108881	109083	38380
152513	152816	707
152513	152816	38380
156664	156957	707
156664	156957	38380
157171	157462	707
157171	157462	38380
158181	158472	707
158181	158472	38380
158708	158978	707
158708	158978	38380
\.


--
-- Data for Name: scheduling_states_by_order_version; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scheduling_states_by_order_version (order_element_id, scheduling_state_for_version_id, order_version_id) FROM stdin;
1531	1632	1721
1532	1633	1721
1533	1634	1721
1534	1635	1721
1535	1636	1721
1536	1637	1721
1537	1638	1721
1543	1644	1721
4952	5053	5154
4979	5080	5154
4980	5081	5154
4981	5082	5154
4982	5083	5154
4983	5084	5154
4984	5085	5154
4985	5086	5154
4986	5087	5154
4987	5088	5154
4988	5089	5154
4989	5090	5154
4990	5091	5154
4991	5092	5154
7576	7677	7778
7577	7678	7778
7584	7685	7778
7585	7686	7778
7586	7687	7778
22338	22439	22526
22339	22440	22526
22340	22441	22526
22341	22442	22526
22342	22443	22526
22343	22444	22526
22344	22445	22526
22345	22446	22526
25896	25997	26164
25897	25998	26164
25898	25999	26164
25899	26000	26164
25900	26001	26164
25901	26002	26164
25902	26003	26164
25903	26004	26164
25946	26047	26168
25947	26048	26168
25948	26049	26168
25949	26050	26168
25950	26051	26168
25951	26052	26168
25952	26053	26168
25953	26054	26168
25954	26055	26168
25955	26056	26168
25956	26057	26168
31815	31916	26168
31816	31917	26168
31817	31918	26168
31842	31943	26172
31843	31944	26172
31844	31945	26172
31845	31946	26172
31846	31947	26172
31847	31948	26172
31848	31949	26172
31849	31950	26172
43462	43563	26180
43463	43564	26180
43464	43565	26180
43465	43566	26180
43466	43567	26180
43467	43568	26180
43468	43569	26180
43469	43570	26180
43470	43571	26180
43471	43572	26180
43472	43573	26180
43473	43574	26180
43474	43575	26180
43475	43576	26180
43500	43601	26184
43501	43602	26184
43502	43603	26184
43503	43604	26184
43504	43605	26184
43505	43606	26184
43506	43607	26184
43507	43608	26184
43462	43609	26185
43463	43610	26185
43464	43611	26185
43465	43612	26185
43466	43613	26185
43467	43614	26185
43468	43615	26185
43469	43616	26185
43470	43617	26185
43471	43618	26185
43472	43619	26185
43473	43620	26185
43474	43621	26185
43475	43622	26185
43510	43625	26172
43462	64539	64640
43463	64540	64640
43464	64541	64640
43465	64542	64640
43466	64543	64640
43467	64544	64640
43468	64545	64640
43469	64546	64640
43470	64547	64640
43471	64548	64640
43472	64549	64640
43473	64550	64640
43474	64551	64640
43475	64552	64640
71651	71752	72117
71652	71753	72117
71653	71754	72117
71654	71755	72117
71655	71756	72117
71656	71757	72117
71657	71758	72117
71658	71759	72117
71659	71760	72117
71660	71761	72117
71661	71762	72117
71662	71763	72117
71663	71764	72117
71664	71765	72117
71665	71766	72118
71666	71767	72118
71671	71772	72118
71672	71773	72118
82472	82573	82630
82473	82574	82630
82474	82575	82630
82475	82576	82630
82476	82577	82630
82482	82583	26172
82488	82589	82635
82489	82590	82635
82488	82591	82636
82489	82592	82636
71665	101726	82648
71671	101727	82648
71666	101728	82648
71672	101729	82648
71665	101734	82650
71671	101735	82650
71666	101736	82650
71672	101737	82650
71665	101742	82652
71671	101743	82652
71666	101744	82652
71672	101745	82652
82490	101746	82653
82491	101747	82653
82496	101752	82653
82497	101753	82653
103435	103536	103629
103436	103537	103629
103437	103538	103629
103438	103539	103629
103439	103540	103629
105558	105659	105750
105559	105660	105750
105560	105661	105750
105561	105662	105750
105562	105663	105750
105563	105664	105750
108881	108982	109083
108927	109028	109083
108928	109029	109083
108929	109030	109083
108930	109031	109083
108931	109032	109083
108932	109033	109083
108933	109034	109083
108934	109035	109083
108935	109036	109083
108937	109038	109083
108938	109039	109083
108939	109040	109083
108940	109041	109083
108941	109042	109083
108972	109073	109083
108973	109074	109083
108974	109075	109083
108975	109076	109083
108976	109077	109083
108977	109078	109083
108978	109079	109083
109282	109383	109083
109283	109384	109083
109284	109385	109083
109293	109394	109083
109294	109395	109083
109295	109396	109083
109296	109397	109083
109306	109407	109083
109307	109408	109083
109308	109409	109083
109312	109413	109083
109315	109416	109083
150189	150391	109083
152513	152715	152816
152605	152807	152816
152606	152808	152816
152607	152809	152816
152608	152810	152816
152609	152811	152816
152610	152812	152816
153015	153217	152816
153016	153218	152816
153017	153219	152816
153018	153220	152816
153019	153221	152816
153020	153222	152816
153021	153223	152816
153034	153236	152816
153035	153237	152816
153036	153238	152816
153037	153239	152816
153044	153246	152816
153045	153247	152816
153076	153278	152816
153077	153279	152816
153078	153280	152816
153079	153281	152816
153080	153282	152816
153081	153283	152816
153082	153284	152816
153083	153285	152816
153084	153286	152816
153085	153287	152816
156664	156866	156957
156665	156867	156957
156666	156868	156957
156667	156869	156957
156668	156870	156957
156669	156871	156957
157171	157373	157462
157172	157374	157462
157173	157375	157462
157174	157376	157462
157175	157377	157462
157176	157378	157462
157177	157379	157462
158181	158383	158472
158182	158384	158472
158183	158385	158472
158184	158386	158472
158185	158387	158472
158186	158388	158472
158187	158389	158472
158708	158910	158978
158709	158911	158978
158710	158912	158978
158711	158913	158978
158712	158914	158978
158713	158915	158978
158714	158916	158978
158715	158917	158978
158716	158918	158978
158717	158919	158978
158718	158920	158978
158719	158921	158978
167383	167585	158978
\.


--
-- Data for Name: schedulingdataforversion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY schedulingdataforversion (id, version, schedulingstatetype, order_element_id) FROM stdin;
26054	5	0	25953
26055	5	0	25954
26056	5	0	25955
26057	5	0	25956
31916	5	3	31815
31917	5	0	31816
31918	5	0	31817
31946	13	0	31845
31947	13	3	31846
7677	14	3	7576
7685	14	3	7584
7678	14	0	7577
7686	14	0	7585
7687	14	0	7586
101731	1	3	71671
82591	2	3	82488
22439	20	3	22338
25997	14	3	25896
25998	14	0	25897
26000	14	0	25899
26001	14	3	25900
26002	14	0	25901
22440	20	0	22339
5053	31	3	4952
101732	1	0	71666
22441	20	0	22340
22442	20	0	22341
26003	14	0	25902
26004	14	0	25903
25999	14	0	25898
31948	13	0	31847
22443	20	3	22342
31949	13	0	31848
31950	13	0	31849
82583	6	0	82482
43625	7	0	43510
82592	2	0	82489
101746	7	3	82490
101747	7	0	82491
22444	20	0	22343
22445	20	0	22344
22446	20	0	22345
1632	19	3	1531
1633	17	3	1532
1634	17	0	1533
1635	17	0	1534
26047	5	3	25946
26048	5	3	25947
26049	5	0	25948
101738	1	3	71665
101739	1	3	71671
101733	1	0	71672
31943	15	3	31842
26050	5	0	25949
26051	5	0	25950
26052	5	0	25951
26053	5	3	25952
1644	18	0	1543
1636	17	3	1535
1637	17	0	1536
1638	17	0	1537
31944	13	3	31843
31945	13	0	31844
101730	1	3	71665
5080	30	3	4979
43601	3	3	43500
43602	3	0	43501
43563	14	2	43462
43609	8	3	43462
43564	13	3	43463
43603	3	0	43502
43604	3	0	43503
43605	3	3	43504
43606	3	0	43505
43607	3	0	43506
43608	3	0	43507
43610	8	3	43463
43565	13	0	43464
43611	8	0	43464
43566	13	0	43465
43612	8	0	43465
43567	13	0	43466
43613	8	0	43466
43568	13	0	43467
43614	8	0	43467
43620	8	3	43473
43575	13	0	43474
43621	8	0	43474
43622	8	0	43475
43569	13	3	43468
43615	8	3	43468
43570	13	0	43469
43616	8	0	43469
43571	13	0	43470
43617	8	0	43470
43572	13	0	43471
43618	8	0	43471
43573	13	0	43472
71772	9	3	71671
101740	1	0	71666
101741	1	0	71672
71773	9	0	71672
101742	1	3	71665
101743	1	3	71671
101744	1	0	71666
101745	1	0	71672
5081	30	0	4980
5082	30	0	4981
5083	30	0	4982
5084	30	0	4983
5085	30	3	4984
5086	30	0	4985
5087	30	0	4986
5088	30	0	4987
5089	30	0	4988
5090	30	3	4989
43574	14	2	43473
43576	14	4	43475
43619	8	0	43472
64539	1	3	43462
64540	1	3	43463
64541	1	0	43464
64542	1	0	43465
64543	1	0	43466
64544	1	0	43467
64545	1	3	43468
64546	1	0	43469
64547	1	0	43470
64548	1	0	43471
64549	1	0	43472
64550	1	3	43473
64551	1	0	43474
64552	1	0	43475
82589	5	3	82488
82590	5	0	82489
71752	15	2	71651
71758	15	4	71657
71759	15	4	71658
71760	15	4	71659
71761	15	4	71660
71762	15	4	71661
71763	15	4	71662
71764	15	4	71663
71765	15	4	71664
71753	16	3	71652
71754	14	0	71653
71755	14	0	71654
71756	14	0	71655
71757	16	0	71656
101734	1	3	71665
101735	1	3	71671
101736	1	0	71666
101737	1	0	71672
101726	2	3	71665
71766	10	3	71665
101727	2	3	71671
101728	2	0	71666
71767	10	0	71666
101729	2	0	71672
5091	30	0	4990
5092	30	0	4991
101752	6	3	82496
101753	6	0	82497
82573	8	3	82472
82577	8	0	82476
82574	8	3	82473
82575	8	0	82474
82576	8	0	82475
105659	10	3	105558
105660	10	0	105559
105661	10	0	105560
105662	10	3	105561
105663	10	0	105562
105664	10	0	105563
103536	8	3	103435
103537	8	0	103436
103538	8	0	103437
103540	8	0	103439
103539	8	0	103438
108982	29	3	108881
109028	28	0	108927
109029	28	0	108928
109030	28	3	108929
109031	28	0	108930
109032	28	0	108931
109033	28	0	108932
109034	28	0	108933
109073	26	3	108972
109035	28	0	108934
109074	26	0	108973
109075	26	0	108974
109076	26	0	108975
109077	26	0	108976
109078	26	0	108977
109079	26	0	108978
109383	26	0	109282
109384	26	0	109283
109385	26	0	109284
109394	24	3	109293
109407	22	0	109306
109408	22	0	109307
109409	22	3	109308
109036	28	0	108935
109416	6	0	109315
153281	8	0	153079
153282	8	0	153080
153283	8	0	153081
153284	8	0	153082
153285	8	0	153083
153221	11	1	153019
153286	8	1	153084
153223	11	0	153021
153287	8	0	153085
153222	11	0	153020
157378	3	4	157176
157379	3	4	157177
150391	3	0	150189
109396	24	0	109295
109395	24	0	109294
109397	24	0	109296
109038	28	0	108937
109039	28	0	108938
109040	28	0	108939
109042	28	0	108941
109413	21	0	109312
109041	28	0	108940
158919	25	0	158717
158920	25	0	158718
158921	25	0	158719
167585	2	0	167383
158383	3	4	158181
158384	3	4	158182
158385	3	4	158183
158386	3	4	158184
158387	3	4	158185
158388	3	4	158186
158389	3	4	158187
152715	12	3	152513
152807	11	0	152605
152808	11	1	152606
156866	3	4	156664
156867	3	4	156665
156868	3	4	156666
156869	3	4	156667
156870	3	4	156668
156871	3	4	156669
152809	11	1	152607
152810	11	1	152608
152811	11	1	152609
152812	11	1	152610
153217	11	1	153015
153236	10	0	153034
153218	11	1	153016
153237	10	1	153035
153238	10	1	153036
153239	10	1	153037
153246	9	3	153044
153219	11	0	153017
153247	9	0	153045
153278	8	3	153076
153220	11	0	153018
153279	8	0	153077
153280	8	0	153078
157373	3	4	157171
157374	3	4	157172
157375	3	4	157173
157376	3	4	157174
157377	3	4	157175
158910	25	3	158708
158911	25	0	158709
158912	25	1	158710
158913	25	1	158711
158914	25	3	158712
158915	25	0	158713
158916	25	0	158714
158917	25	0	158715
158918	25	3	158716
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
27065	1216
27066	1220
27062	1216
27063	1216
27064	1216
83135	4356
7878	1216
26993	4352
2287	1220
2225	1216
2226	1220
45988	4354
45991	4354
27057	1220
2288	1216
7894	4350
7901	4344
7902	4348
104136	4352
106358	1216
153681	151907
153682	151907
153683	151907
153621	111406
153622	111406
153667	151907
153668	151907
153669	151907
153670	151907
153671	151907
153672	151907
153673	151907
153674	151907
153675	151907
153676	111406
159481	151915
\.


--
-- Data for Name: specificdayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specificdayassignmentscontainer (id, version, resource_allocation_id, scenario) FROM stdin;
31213	2	27057	707
31223	7	27065	707
31222	6	27066	707
2732	10	2288	707
31224	5	27062	707
31221	7	27063	707
31225	5	27064	707
8080	14	7878	707
46089	2	45988	707
8082	3	7894	707
8089	1	7901	707
8090	1	7902	707
2731	8	2287	707
2729	9	2225	707
2730	10	2226	707
31212	0	26993	707
100902	0	83135	38380
31234	23	7878	38380
31227	24	7901	38380
31226	24	7894	38380
31228	32	7902	38380
31230	26	27066	38380
31231	27	27063	38380
31233	26	27062	38380
31229	27	27065	38380
31232	26	27064	38380
31239	16	26993	38380
31236	16	2226	38380
31237	16	2287	38380
31238	17	2288	38380
31235	16	2225	38380
31240	15	27057	38380
104738	2	104136	707
153722	2	153621	707
153723	2	153622	707
153768	1	153667	707
153769	1	153668	707
153770	1	153669	707
153771	1	153670	707
153772	1	153671	707
153773	1	153672	707
153774	1	153673	707
153775	1	153674	707
153776	1	153675	707
153777	1	153676	707
153782	0	153681	707
153783	0	153682	707
153784	0	153683	707
159582	11	159481	707
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
164025	2010-10-11	0.50	0.20	0
164025	2010-10-30	0.75	0.50	1
164025	2010-11-19	1.00	1.00	2
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id, type) FROM stdin;
164025	1
\.


--
-- Data for Name: subcontractedtaskdata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY subcontractedtaskdata (id, version, externalcompany, subcontratationdate, subcontractcommunicationdate, workdescription, subcontractprice, subcontractedcode, nodewithoutchildrenexported, labelsexported, materialassignmentsexported, hoursgroupsexported, state) FROM stdin;
24641537	5	1818	2010-06-16 10:51:54.089	2010-06-16 10:52:40.724	Montaje de andamios	30000.00	Igalia_0001	\N	t	t	t	2
2916353	21	1818	2010-06-14 15:38:54.504	2010-06-14 15:45:03.801	Desarrollo de un proyecto para el cliente.	20000.00	001	t	t	t	t	2
33325057	3	1818	2010-06-16 18:21:07.494	2010-06-16 18:23:40.22	Montaje de andamios	10000.00	0001	\N	t	t	t	2
54034434	10	1818	2010-09-06 15:37:41.093	\N	proba subcontratación	10000.00	\N	t	t	t	t	1
\.


--
-- Data for Name: sumchargedhours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY sumchargedhours (id, version, directchargedhours, indirectchargedhours) FROM stdin;
156765	3	0	0
156766	3	0	0
156767	3	0	0
156768	3	0	0
156769	3	0	0
156770	3	0	0
152614	11	0	0
152706	10	0	0
152707	10	0	0
152708	10	0	0
152709	10	0	0
152710	10	0	0
152711	10	0	0
153116	10	0	0
158809	26	2	57
153135	9	0	0
153117	10	0	0
153136	9	0	0
158810	25	19	0
158811	24	0	0
158812	24	0	0
158813	25	0	38
158814	25	38	0
153137	9	0	0
153138	9	0	0
153145	8	0	0
153118	10	0	0
158815	24	0	0
158816	24	0	0
158817	24	0	0
158818	24	0	0
153146	8	0	0
158819	24	0	0
153177	7	0	0
158820	24	0	0
157272	3	0	0
157273	3	0	0
157274	3	0	0
157275	3	0	0
157276	3	0	0
153119	10	0	0
157277	3	0	0
153178	7	0	0
153179	7	0	0
157278	3	0	0
167484	2	0	0
153180	7	0	0
153181	7	0	0
153182	7	0	0
153183	7	0	0
153184	7	0	0
153120	10	0	0
153185	7	0	0
153122	10	0	0
153186	7	0	0
153121	10	0	0
158282	3	0	0
158283	3	0	0
158284	3	0	0
158285	3	0	0
158286	3	0	0
158287	3	0	0
158288	3	0	0
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate, subcontrated_task_data_id, priority) FROM stdin;
9292	1	1	2010-06-14 00:00:00	\N	\N
9293	1	1	2010-06-14 00:00:00	\N	\N
9294	1	1	2010-06-14 00:00:00	\N	\N
22826	1	0	\N	\N	\N
22828	1	1	2010-08-20 00:00:00	\N	5
83053	1	1	2010-07-21 02:24:00	\N	\N
83054	1	1	2010-07-16 00:00:00	\N	\N
5464	1	1	2010-07-02 12:48:00	\N	\N
5465	1	0	\N	\N	\N
5454	1	0	\N	\N	\N
5455	1	0	\N	\N	\N
5456	1	1	2010-06-30 00:00:00	\N	5
26512	1	0	\N	\N	\N
26508	1	0	\N	\N	\N
26509	1	0	\N	\N	\N
26510	1	0	\N	\N	\N
26506	1	0	\N	\N	\N
26507	1	0	\N	\N	\N
2124	1	1	2010-07-16 00:00:00	\N	5
2121	1	1	2010-06-13 00:00:00	\N	5
2122	1	1	2010-06-30 00:00:00	\N	5
2129	1	0	\N	\N	\N
5457	1	2	2010-06-14 12:59:30.412	2916353	\N
5459	1	2	2010-07-09 12:59:30.412	33325057	\N
5460	1	0	\N	\N	\N
5461	1	0	\N	\N	\N
5462	1	0	\N	\N	\N
26497	1	0	\N	\N	\N
26498	1	0	\N	\N	\N
26499	1	0	\N	\N	\N
26500	1	0	\N	\N	\N
26480	1	0	\N	\N	\N
26481	1	0	\N	\N	\N
26470	1	0	\N	\N	\N
26471	1	0	\N	\N	\N
26472	1	0	\N	\N	\N
26473	1	0	\N	\N	\N
26475	1	0	\N	\N	\N
26476	1	0	\N	\N	\N
26477	1	0	\N	\N	\N
26478	1	0	\N	\N	\N
26492	1	0	\N	\N	\N
26493	1	0	\N	\N	5
26494	1	0	\N	\N	\N
26495	1	0	\N	\N	\N
26502	1	0	\N	\N	\N
64741	1	1	2010-08-25 00:00:00	\N	\N
64742	1	0	\N	\N	5
64743	1	1	2010-09-05 14:08:17.391	\N	\N
64744	1	0	\N	\N	\N
64746	1	0	\N	\N	\N
64747	1	0	\N	\N	\N
64748	1	0	\N	\N	\N
64749	1	1	2010-08-29 00:00:00	\N	\N
64751	1	0	\N	\N	\N
64752	1	1	2010-09-04 18:14:23.937	\N	\N
26463	1	1	2010-07-07 00:00:00	\N	\N
26465	1	0	\N	\N	\N
26466	1	0	\N	\N	\N
26464	1	1	2010-08-04 00:00:00	\N	5
26462	1	1	2010-06-27 00:00:00	\N	\N
26468	1	0	\N	\N	\N
72215	1	0	\N	\N	\N
72216	1	0	\N	\N	\N
72217	1	0	\N	\N	\N
72229	1	2	2010-07-16 00:00:00	24641537	\N
83057	1	1	2010-07-09 00:00:00	\N	\N
83058	1	1	2010-07-09 00:00:00	\N	\N
26484	1	1	2010-07-19 00:00:00	\N	5
26485	1	1	2010-09-10 00:00:00	\N	5
26490	1	1	2010-11-05 00:00:00	\N	5
26487	1	1	2010-08-05 00:00:00	\N	5
83022	1	0	\N	\N	\N
83023	1	0	\N	\N	\N
83025	1	0	\N	\N	\N
26488	1	1	2011-01-07 00:00:00	\N	5
26519	1	0	\N	\N	\N
26520	1	0	\N	\N	\N
26521	1	0	\N	\N	\N
26522	1	1	2010-08-29 00:00:00	\N	\N
26524	1	0	\N	\N	\N
26525	1	1	2010-09-04 18:14:23.937	\N	\N
26514	1	1	2010-08-25 00:00:00	\N	\N
26515	1	0	\N	\N	5
26516	1	1	2010-09-05 14:08:17.391	\N	\N
26517	1	0	\N	\N	\N
83027	1	1	2011-02-11 00:00:00	\N	5
26528	1	1	2010-08-23 00:00:00	\N	5
83030	1	0	\N	\N	\N
83028	1	1	2010-09-19 13:05:27.20	\N	\N
83047	1	1	2010-07-21 02:24:00	\N	\N
83048	1	1	2010-07-16 00:00:00	\N	\N
72230	1	1	2010-07-16 00:00:00	\N	\N
72231	1	1	2010-07-16 00:00:00	\N	\N
83049	1	1	2010-07-21 02:24:00	\N	\N
83050	1	1	2010-07-16 00:00:00	\N	\N
22832	1	0	\N	\N	\N
22827	1	0	\N	\N	\N
22829	1	0	\N	\N	\N
22830	2	0	\N	\N	\N
2125	1	1	2011-01-26 00:00:00	\N	5
109715	1	0	\N	\N	\N
109713	1	0	\N	\N	\N
109687	2	0	\N	\N	\N
109707	1	0	\N	\N	\N
109708	1	0	\N	\N	\N
109709	1	0	\N	\N	\N
109710	1	0	\N	\N	\N
109686	2	0	\N	\N	\N
109712	1	0	\N	\N	\N
109704	1	0	\N	\N	\N
109705	1	0	\N	\N	\N
109717	1	1	2010-11-26 12:35:31.352	\N	\N
109688	1	0	\N	\N	\N
109689	1	0	\N	\N	\N
109690	1	0	\N	\N	\N
109714	2	0	\N	\N	\N
103931	1	0	\N	\N	\N
103932	1	0	\N	\N	\N
103930	1	0	\N	\N	\N
103929	1	0	\N	\N	\N
109692	1	0	\N	\N	\N
109720	1	0	\N	\N	\N
109716	2	0	\N	\N	\N
109693	1	0	\N	\N	\N
109694	1	0	\N	\N	\N
109695	1	0	\N	\N	\N
109696	1	0	\N	\N	\N
109697	1	0	\N	\N	\N
109698	1	0	\N	\N	\N
109699	1	0	\N	\N	\N
109700	1	0	\N	\N	\N
109701	1	0	\N	\N	\N
106153	1	1	2010-07-11 18:24:00	\N	\N
106154	1	0	\N	\N	\N
106151	1	0	\N	\N	\N
106152	1	0	\N	\N	5
153534	1	0	\N	\N	\N
153520	2	0	\N	\N	\N
153521	2	0	\N	\N	\N
153522	1	0	\N	\N	\N
153523	1	0	\N	\N	\N
153525	1	0	\N	\N	\N
153526	1	0	\N	\N	\N
153527	1	0	\N	\N	\N
153528	1	0	\N	\N	\N
153529	1	0	\N	\N	\N
153530	1	0	\N	\N	\N
153531	1	0	\N	\N	\N
153533	2	1	2010-09-21 22:37:05.696	\N	\N
153535	1	0	\N	\N	\N
109702	1	0	\N	\N	\N
150692	1	0	\N	\N	\N
153536	1	0	\N	\N	\N
159277	1	0	\N	\N	\N
159278	1	0	\N	\N	\N
159279	1	0	\N	\N	\N
159280	1	0	\N	\N	\N
159282	2	0	\N	\N	\N
159283	2	0	\N	\N	\N
159284	2	2	2010-12-09 00:00:00	54034434	\N
168670	1	0	\N	\N	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id, reportadvance) FROM stdin;
165642	3	165539	158708	f
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
165642	Entrega doc.	25.00	0	t	2010-09-06 00:00:00	0
165642	certificación	75.00	2	f	\N	2
165642	Completado	100.00	3	f	\N	3
165642	Revisión procesos de calidade	50.00	1	t	2010-09-21 00:00:00	1
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
2121	1927
2122	1928
2124	1929
2125	1930
2129	1936
26462	26362
26463	26363
26464	26364
26465	26365
26466	26366
26468	26367
64741	43367
64742	43368
64742	43369
64743	43370
64744	43371
64746	43372
64747	43373
64748	43374
64749	43375
64751	43376
64752	43377
9292	9090
9293	9095
9294	9096
22826	22636
22827	22637
22828	22638
22829	22639
22830	22640
22832	22641
5454	5272
5455	5273
5455	9106
5456	5274
5457	5275
5459	5276
5460	5277
5461	5278
5462	5279
5464	5280
5465	5281
26506	43396
26507	43397
26508	43398
26470	26458
26471	26460
26471	26459
26472	26461
26473	31714
26475	31715
26476	31716
26477	31717
26478	31718
26480	31719
26481	31720
26509	43399
26510	43400
26512	43401
26514	43367
26515	43369
26515	43368
26516	43370
26517	43371
26519	43372
26520	43373
26521	43374
26522	43375
26524	43376
26525	43377
72230	72057
72231	72060
72215	72046
72216	72048
72216	72047
26492	43367
26493	43369
26493	43368
26494	43370
26495	43371
26497	43372
26498	43373
26499	43374
26500	43375
26502	43376
72217	72049
72229	72050
83022	82752
83023	82753
83025	82754
26484	31756
26485	31757
26487	31758
26488	31759
26490	31760
26528	43404
83027	82760
83028	82763
83030	82763
83047	72057
83048	72060
83049	72057
83050	72060
83053	72057
83054	72060
83057	82764
83058	82767
153520	153003
153520	153002
153520	153000
153520	153001
153520	152998
153520	152999
153521	153322
153521	153324
103929	103735
103930	103736
103931	103737
103932	103738
106151	105856
106152	105857
106153	105858
106154	105859
153521	153004
153521	153323
153522	153005
153523	153328
153525	153006
153526	153353
153527	153354
153528	153355
153529	153356
153530	153357
153531	153358
153533	153359
153533	153007
153534	153008
153535	153009
153536	153360
109686	109223
109687	109224
109688	109225
109689	109226
109690	109227
109692	109228
109693	109229
109694	109264
109695	109265
109696	109266
109697	109267
109698	109268
109699	109269
109700	109270
109701	109271
109702	109272
109704	109490
109705	109491
109707	109230
109708	109280
109709	109279
109710	109281
109712	109232
109713	109233
109714	109234
109715	109235
109716	109236
109717	109495
109720	109498
150692	150492
159277	159100
159277	159099
159278	159101
159279	159102
159280	159103
159282	159104
159283	159105
159284	159106
168670	167104
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, advance_percentage, parent, base_calendar_id, positioninparent, startdayduration, enddayduration) FROM stdin;
2127	20	Pedido recursos limitantes	\N	2010-06-13 12:33:10.77	2010-08-20 00:00:00	\N	0.24	\N	\N	\N	\N	\N
22830	18	Tarefa 4.1	\N	2010-06-14 18:10:13.82	2010-07-15 18:10:13.82	\N	0.50	22831	\N	1	\N	\N
83047	2	Tarea 2	\N	2010-07-21 02:24:00	2010-07-30 02:24:00	2010-08-10	0.40	83046	\N	0	\N	\N
22827	19	Tarefa 2	\N	2010-07-09 18:10:13.82	2010-08-13 18:10:13.82	\N	0.00	22833	\N	1	\N	\N
22833	22	Pedido 2	\N	2010-06-14 18:10:13.82	2010-09-26 18:00:00	2010-09-22	0.12	\N	\N	\N	\N	\N
26471	4	Tarea 1.1	\N	2010-09-08 00:00:00	2010-10-05 00:00:00	\N	0.00	26474	\N	1	\N	\N
26472	4	Tarea 1.3	\N	2010-09-08 00:00:00	2010-09-25 00:00:00	\N	0.00	26474	\N	2	\N	\N
26473	4	Tarea 1.4	\N	2010-10-05 00:00:00	2010-11-09 00:00:00	\N	0.00	26474	\N	3	\N	\N
26475	4	Tarea 2.2 	\N	2010-10-15 00:00:00	2010-11-03 00:00:00	\N	0.00	26479	\N	0	\N	\N
72229	5	Tarea 1.4	\N	2010-07-16 00:00:00	2010-08-10 00:00:00	\N	0.29	72219	\N	3	\N	\N
26476	4	Tarea 2.1	\N	2010-09-25 00:00:00	2010-10-30 00:00:00	\N	0.00	26479	\N	1	\N	\N
22832	18	Tarefa 5	\N	2010-07-15 18:10:13.82	2010-07-28 06:10:13.82	\N	0.00	22833	\N	4	\N	\N
83045	0	Montaje de andamios	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	2010-08-10	0.29	\N	\N	\N	\N	\N
26483	5	Pedido 5	\N	2010-09-08 00:00:00	2011-01-18 00:00:00	2010-12-31	0.00	\N	\N	\N	\N	\N
22831	21	Tarefa 4	\N	2010-06-14 18:10:13.82	2010-09-26 18:00:00	\N	0.28	22833	\N	3	\N	\N
22829	17	Tarefa 4.2	\N	2010-09-08 00:00:00	2010-09-26 18:00:00	\N	0.00	22831	\N	0	\N	\N
83048	2	Tarefa 1	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	\N	0.25	83046	\N	1	\N	\N
5466	35	Tarea 3	\N	2010-07-02 12:48:00	2010-09-02 12:48:00	\N	0.00	5467	\N	2	\N	\N
5464	27	Tarea 3.2	\N	2010-07-02 12:48:00	2010-07-29 12:48:00	\N	0.00	5466	\N	0	\N	\N
5465	28	Tarea 3.1	\N	2010-07-29 12:48:00	2010-09-02 12:48:00	\N	0.00	5466	\N	1	\N	\N
5457	27	Tarea 1.4	\N	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	\N	0.00	5458	\N	3	\N	\N
5458	35	Tarea1	\N	2010-06-14 12:59:30.412	2010-08-05 12:59:30.412	\N	0.10	5467	\N	0	\N	\N
83057	5	Subtarefa 1.2	\N	2010-07-09 12:59:30.412	2010-07-15 12:59:30.412	2010-07-28	0.10	83059	\N	0	\N	\N
83058	5	Subtarefa 1.1	\N	2010-07-15 12:59:30.412	2010-07-16 12:59:30.412	\N	0.00	83059	\N	1	\N	\N
22826	18	Tarefa 1	\N	2010-06-14 18:10:13.82	2010-07-09 18:10:13.82	\N	0.10	22833	\N	0	\N	\N
2126	20	container 2	\N	2010-07-16 00:00:00	2010-08-20 00:00:00	\N	0.00	2127	\N	1	\N	\N
2124	18	tarefa limitantes 3	\N	2010-07-16 00:00:00	2010-08-04 00:00:00	\N	0.00	2126	\N	0	\N	\N
83027	4	Tarefa Recurso limitantes N	\N	2011-02-11 00:00:00	2011-03-18 00:00:00	\N	0.00	26491	\N	4	\N	\N
5463	34	Tarea2	\N	2010-07-09 12:59:30.412	2010-09-01 12:59:30.412	\N	0.00	5467	\N	1	\N	\N
22828	18	Tarefa 3	\N	2010-08-20 00:00:00	2010-09-08 00:00:00	\N	0.00	22833	\N	2	\N	\N
83060	6	Montaje de andamios	\N	2010-07-09 12:59:30.412	2010-07-16 12:59:30.412	2010-07-28	0.15	\N	\N	\N	\N	\N
2123	20	container 1	\N	2010-06-13 12:33:10.77	2010-07-16 00:00:00	\N	0.25	2127	\N	0	\N	\N
2125	20	tarefa limitantes 4	\N	2011-01-26 00:00:00	2011-02-11 00:00:00	\N	0.00	2126	\N	1	\N	\N
9295	12	Tarea 1.4	\N	2010-06-14 12:59:30.412	2010-07-17 12:59:30.412	2010-07-09	0.25	9296	\N	0	\N	\N
2121	17	tarefa limitantes 1	\N	2010-06-13 00:00:00	2010-06-30 00:00:00	2010-07-01	0.50	2123	\N	0	\N	\N
83059	6	Tarea 2.2 	\N	2010-07-09 12:59:30.412	2010-07-16 12:59:30.412	2010-07-28	0.15	83060	\N	0	\N	\N
2122	18	tarefa limitantes 2	\N	2010-06-30 00:00:00	2010-07-16 00:00:00	\N	0.00	2123	\N	1	\N	\N
2129	13	tarefa limitantes 5	\N	2010-06-13 12:33:10.77	2010-08-05 12:33:10.77	\N	0.40	2127	\N	2	\N	\N
9292	11	Subtarefa 1.4.3	\N	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	2010-07-09	0.30	9295	\N	0	\N	\N
9293	11	Subtarefa 1.4.1	\N	2010-06-14 12:59:30.412	2010-07-17 12:59:30.412	\N	0.35	9295	\N	1	\N	\N
9294	11	Subtarefa 1.4.2	\N	2010-06-14 12:59:30.412	2010-06-23 12:59:30.412	\N	0.00	9295	\N	2	\N	\N
9296	12	Desarrollo de un proyecto para el cliente.	\N	2010-06-14 12:59:30.412	2010-07-17 12:59:30.412	2010-07-09	0.25	\N	\N	\N	\N	\N
5459	27	Tarea 2.2 	\N	2010-07-09 12:59:30.412	2010-07-28 12:59:30.412	\N	0.00	5463	\N	0	\N	\N
83046	2	Tarea 1.4	\N	2010-07-16 00:00:00	2010-07-30 02:24:00	2010-08-10	0.29	83045	\N	0	\N	\N
5454	28	Tarea 1.2	\N	2010-06-14 12:59:30.412	2010-08-05 12:59:30.412	\N	0.20	5458	\N	0	\N	\N
5455	28	Tarea 1.1	\N	2010-06-14 12:59:30.412	2010-07-09 12:59:30.412	\N	0.00	5458	\N	1	\N	\N
5456	29	Tarea 1.3	\N	2010-06-30 00:00:00	2010-07-19 00:00:00	\N	0.25	5458	\N	2	\N	\N
26463	13	Tarefa 2	\N	2010-07-15 00:00:00	2010-08-19 00:00:00	\N	0.00	26469	\N	1	\N	\N
26467	17	Tarefa 4	\N	2010-08-20 00:00:00	2010-09-24 00:00:00	\N	0.00	26469	\N	3	\N	\N
5460	27	Tarea 2.1	\N	2010-07-28 12:59:30.412	2010-09-01 12:59:30.412	\N	0.00	5463	\N	1	\N	\N
26465	14	Tarefa 4.2	\N	2010-08-20 00:00:00	2010-09-16 00:00:00	\N	0.00	26467	\N	0	\N	\N
26466	14	Tarefa 4.1	\N	2010-08-20 00:00:00	2010-09-24 00:00:00	\N	0.00	26467	\N	1	\N	\N
26464	15	Recursos lim Tarefa 3	\N	2010-08-04 00:00:00	2010-08-20 00:00:00	\N	0.25	26469	\N	2	\N	\N
26469	16	Pedido 3	\N	2010-06-27 00:00:00	2010-10-13 00:00:00	2010-09-22	0.05	\N	\N	\N	\N	\N
26462	13	Tarefa 1	\N	2010-06-27 00:00:00	2010-07-15 00:00:00	\N	0.20	26469	\N	0	\N	\N
26468	15	Tarefa 5	\N	2010-09-24 00:00:00	2010-10-13 00:00:00	\N	0.00	26469	\N	4	\N	\N
5461	27	Tarea 2.3	\N	2010-07-09 12:59:30.412	2010-08-03 12:59:30.412	\N	0.00	5463	\N	2	\N	\N
26470	4	Tarea 1.2	\N	2010-09-08 00:00:00	2010-10-15 00:00:00	\N	0.00	26474	\N	0	\N	\N
5462	27	Tarea 2.4	\N	2010-07-09 12:59:30.412	2010-08-28 12:59:30.412	\N	0.00	5463	\N	3	\N	\N
5467	35	Pedido 1	\N	2010-06-14 12:59:30.412	2010-09-02 12:48:00	2010-09-23	0.03	\N	\N	\N	\N	\N
83028	2	Tarefa 1	\N	2010-09-19 13:05:27.20	2011-03-12 13:05:27.20	\N	0.00	83029	\N	0	\N	\N
26487	15	tarefa limitantes 3	\N	2010-08-05 00:00:00	2010-08-23 00:00:00	\N	0.00	26489	\N	0	\N	\N
26482	5	Tarea 3	\N	2010-10-13 00:00:00	2010-12-14 00:00:00	\N	0.00	26483	\N	2	\N	\N
26480	4	Tarea 3.2	\N	2010-10-13 00:00:00	2010-11-09 00:00:00	\N	0.00	26482	\N	0	\N	\N
26481	4	Tarea 3.1	\N	2010-11-09 00:00:00	2010-12-14 00:00:00	\N	0.00	26482	\N	1	\N	\N
26474	5	Tarea1	\N	2010-09-08 00:00:00	2010-11-09 00:00:00	\N	0.00	26483	\N	0	\N	\N
26479	5	Tarea2	\N	2010-09-08 00:00:00	2011-01-18 00:00:00	\N	0.00	26483	\N	1	\N	\N
26477	4	Tarea 2.3	\N	2010-09-08 00:00:00	2010-10-13 00:00:00	\N	0.00	26479	\N	2	\N	\N
26478	4	Tarea 2.4	\N	2010-11-09 00:00:00	2011-01-18 00:00:00	\N	0.00	26479	\N	3	\N	\N
26488	14	tarefa limitantes 4	\N	2011-01-07 00:00:00	2011-01-25 00:00:00	\N	0.00	26489	\N	1	\N	\N
83029	2	Pedido 3 escenario 2	\N	2010-09-19 13:05:27.20	2011-03-12 13:05:27.20	2010-11-26	0.00	\N	\N	\N	\N	\N
26497	8	Tarea 2.2 	\N	2010-06-28 04:42:02.981	2010-07-10 16:42:02.981	\N	0.00	26501	\N	0	\N	\N
26498	8	Tarea 2.1	\N	2010-07-10 16:42:02.981	2010-08-04 16:42:02.981	\N	0.00	26501	\N	1	\N	\N
26491	17	Pedido recursos limitantes 2	\N	2010-07-19 00:00:00	2011-01-25 00:00:00	2010-09-01	0.00	\N	\N	\N	\N	\N
26499	8	Tarea 2.3	\N	2010-06-28 04:42:02.981	2010-07-23 04:42:02.981	\N	0.00	26501	\N	2	\N	\N
26500	9	Tarea 2.4	\N	2010-06-15 13:42:02.981	2010-08-04 13:42:02.981	\N	0.10	26501	\N	3	\N	\N
26496	12	Tarea1	\N	2010-06-15 13:42:02.981	2010-08-18 13:42:02.981	\N	0.00	26505	\N	0	\N	\N
26523	5	Tarea2	\N	2010-08-29 00:00:00	2010-11-06 00:00:00	\N	0.04	26527	\N	1	\N	\N
26519	5	Tarea 2.2 	\N	2010-09-18 05:08:17.391	2010-09-30 17:08:17.391	\N	0.00	26523	\N	0	\N	\N
26520	5	Tarea 2.1	\N	2010-09-30 17:08:17.391	2010-10-25 17:08:17.391	\N	0.00	26523	\N	1	\N	\N
26512	2	Tarefa 5	\N	2010-06-15 13:49:04.771	2010-06-28 01:49:04.771	\N	0.00	26513	\N	4	\N	\N
26508	2	Tarefa 3	\N	2010-06-15 13:49:04.771	2010-06-28 01:49:04.771	\N	0.00	26513	\N	2	\N	\N
26511	2	Tarefa 4	\N	2010-06-15 13:49:04.771	2010-07-10 13:49:04.771	\N	0.00	26513	\N	3	\N	\N
26509	2	Tarefa 4.2	\N	2010-06-15 13:49:04.771	2010-07-04 07:49:04.771	\N	0.00	26511	\N	0	\N	\N
26510	2	Tarefa 4.1	\N	2010-06-15 13:49:04.771	2010-07-10 13:49:04.771	\N	0.00	26511	\N	1	\N	\N
26506	2	Tarefa 1	\N	2010-06-15 13:49:04.771	2010-07-02 13:49:04.771	\N	0.00	26513	\N	0	\N	\N
26507	2	Tarefa 2	\N	2010-06-15 13:49:04.771	2010-07-10 13:49:04.771	\N	0.00	26513	\N	1	\N	\N
26513	2	Pedido 2 Escenarios	\N	2010-06-15 13:49:04.771	2010-07-10 13:49:04.771	2010-09-22	0.00	\N	\N	\N	\N	\N
26522	5	Tarea 2.4	\N	2010-08-29 00:00:00	2010-11-06 00:00:00	\N	0.10	26523	\N	3	\N	\N
26492	8	Tarea 1.2	\N	2010-06-15 13:42:02.981	2010-07-22 13:42:02.981	\N	0.00	26496	\N	0	\N	\N
83052	1	Montaje de andamios	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	2010-08-10	0.29	\N	\N	\N	\N	\N
26524	5	Tarea 3.2	\N	2010-10-13 05:08:17.391	2010-10-31 22:08:17.391	\N	0.00	26526	\N	0	\N	\N
26493	8	Tarea 1.1	\N	2010-07-22 13:42:02.981	2010-08-18 13:42:02.981	\N	0.00	26496	\N	1	\N	\N
26494	8	Tarea 1.3	\N	2010-06-15 13:42:02.981	2010-06-28 04:42:02.981	\N	0.00	26496	\N	2	\N	\N
83049	1	Tarea 2	\N	2010-07-21 02:24:00	2010-07-30 02:24:00	2010-08-10	0.40	83051	\N	0	\N	\N
83050	1	Tarefa 1	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	\N	0.25	83051	\N	1	\N	\N
72233	8	Montaje de andamios	\N	2010-07-16 00:00:00	2010-07-30 02:24:00	2010-08-10	0.29	\N	\N	\N	\N	\N
26486	17	container 1	\N	2010-07-19 00:00:00	2010-09-28 00:00:00	\N	0.00	26491	\N	0	\N	\N
26501	13	Tarea2	\N	2010-06-15 13:42:02.981	2010-08-04 16:42:02.981	\N	0.04	26505	\N	1	\N	\N
26495	8	Tarea 1.4	\N	2010-06-28 04:42:02.981	2010-07-23 04:42:02.981	\N	0.00	26496	\N	3	\N	\N
26521	5	Tarea 2.3	\N	2010-09-18 05:08:17.391	2010-10-13 05:08:17.391	\N	0.00	26523	\N	2	\N	\N
26525	5	Tarea 3.1	\N	2010-09-04 18:14:23.937	2010-09-29 18:14:23.937	\N	0.00	26526	\N	1	\N	\N
26518	5	Tarea1	\N	2010-08-25 00:00:00	2010-10-28 00:00:00	\N	0.00	26527	\N	0	\N	\N
26514	5	Tarea 1.2	\N	2010-08-25 00:00:00	2010-10-01 00:00:00	\N	0.00	26518	\N	0	\N	\N
26515	5	Tarea 1.1	\N	2010-10-01 00:00:00	2010-10-28 00:00:00	\N	0.00	26518	\N	1	\N	\N
26516	5	Tarea 1.3	\N	2010-09-05 14:08:17.391	2010-09-18 05:08:17.391	\N	0.00	26518	\N	2	\N	\N
26517	5	Tarea 1.4	\N	2010-09-18 05:08:17.391	2010-10-13 05:08:17.391	\N	0.00	26518	\N	3	\N	\N
26527	5	Pedido Escenario 2	\N	2010-06-15 13:42:02.981	2010-11-06 00:00:00	2010-09-23	0.01	\N	\N	\N	\N	\N
26504	12	Tarea 3	\N	2010-06-15 13:42:02.981	2010-08-10 22:42:02.981	\N	0.00	26505	\N	2	\N	\N
72232	8	Tarea 1.4	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	2010-08-10	0.29	72233	\N	0	\N	\N
26502	8	Tarea 3.2	\N	2010-07-23 04:42:02.981	2010-08-10 22:42:02.981	\N	0.00	26504	\N	0	\N	\N
26505	12	Pedido Escenario 2	\N	2010-06-15 13:42:02.981	2010-08-18 13:42:02.981	2010-09-23	0.01	\N	\N	\N	\N	\N
26484	16	tarefa limitantes 1	\N	2010-07-19 00:00:00	2010-08-04 00:00:00	\N	0.00	26486	\N	0	\N	\N
72230	7	Tarea 2	\N	2010-07-16 00:00:00	2010-07-22 06:00:00	2010-08-10	0.40	72232	\N	0	\N	\N
26485	14	tarefa limitantes 2	\N	2010-09-10 00:00:00	2010-09-28 00:00:00	\N	0.00	26486	\N	1	\N	\N
26490	14	tarefa limitantes 5	\N	2010-11-05 00:00:00	2010-12-29 00:00:00	\N	0.00	26491	\N	2	\N	\N
26489	17	container 2	\N	2010-08-05 00:00:00	2011-01-25 00:00:00	\N	0.00	26491	\N	1	\N	\N
83051	1	Tarea 1.4	\N	2010-07-16 00:00:00	2010-07-30 02:24:00	2010-08-10	0.29	83052	\N	0	\N	\N
72231	7	Tarefa 1	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	\N	0.25	72232	\N	1	\N	\N
26526	5	Tarea 3	\N	2010-06-15 13:42:02.981	2010-10-31 22:08:17.391	\N	0.00	26527	\N	2	\N	\N
64754	1	Pedido Escenario 2	\N	2010-06-15 13:42:02.981	2010-11-06 00:00:00	2010-09-23	0.01	\N	\N	\N	\N	\N
64741	1	Tarea 1.2	\N	2010-08-25 00:00:00	2010-10-01 00:00:00	\N	0.00	64745	\N	0	\N	\N
64742	1	Tarea 1.1	\N	2010-10-01 00:00:00	2010-10-28 00:00:00	\N	0.00	64745	\N	1	\N	\N
64743	1	Tarea 1.3	\N	2010-09-05 14:08:17.391	2010-09-18 05:08:17.391	\N	0.00	64745	\N	2	\N	\N
64744	1	Tarea 1.4	\N	2010-09-18 05:08:17.391	2010-10-13 05:08:17.391	\N	0.00	64745	\N	3	\N	\N
64746	1	Tarea 2.2 	\N	2010-09-18 05:08:17.391	2010-09-30 17:08:17.391	\N	0.00	64750	\N	0	\N	\N
64747	1	Tarea 2.1	\N	2010-09-30 17:08:17.391	2010-10-25 17:08:17.391	\N	0.00	64750	\N	1	\N	\N
64748	1	Tarea 2.3	\N	2010-09-18 05:08:17.391	2010-10-13 05:08:17.391	\N	0.00	64750	\N	2	\N	\N
64749	1	Tarea 2.4	\N	2010-08-29 00:00:00	2010-11-06 00:00:00	\N	0.10	64750	\N	3	\N	\N
64751	1	Tarea 3.2	\N	2010-10-13 05:08:17.391	2010-10-31 22:08:17.391	\N	0.00	64753	\N	0	\N	\N
64752	1	Tarea 3.1	\N	2010-09-04 18:14:23.937	2010-09-29 18:14:23.937	\N	0.00	64753	\N	1	\N	\N
64745	1	Tarea1	\N	2010-08-25 00:00:00	2010-10-28 00:00:00	\N	0.00	64754	\N	0	\N	\N
64750	1	Tarea2	\N	2010-08-29 00:00:00	2010-11-06 00:00:00	\N	0.04	64754	\N	1	\N	\N
64753	1	Tarea 3	\N	2010-06-15 13:42:02.981	2010-10-31 22:08:17.391	\N	0.00	64754	\N	2	\N	\N
64755	0	Entrega pedido	\N	2010-10-13 00:00:00	2010-10-13 00:00:00	\N	0.00	26469	\N	5	\N	\N
83024	5	Tarefa 1	\N	2011-02-16 00:00:00	2011-03-02 00:00:00	\N	0.00	83026	\N	0	\N	\N
83022	5	Subtarefa 1.1	\N	2011-02-16 00:00:00	2011-02-23 00:00:00	\N	0.00	83024	\N	0	\N	\N
83023	5	Subtarefa 1.2	\N	2011-02-23 00:00:00	2011-03-02 00:00:00	2010-06-16	0.00	83024	\N	1	\N	\N
83025	5	Tarefa 2	\N	2011-03-02 00:00:00	2011-03-09 00:00:00	\N	0.00	83026	\N	1	\N	\N
83026	5	Pedido con Andamieros	\N	2011-02-16 00:00:00	2011-03-09 00:00:00	2011-04-16	0.00	\N	\N	\N	\N	\N
72219	19	Tarea1	\N	2010-07-16 00:00:00	2010-08-14 00:00:00	\N	0.08	72228	\N	0	\N	\N
72215	13	Tarea 1.2	\N	2010-07-16 00:00:00	2010-07-29 00:00:00	\N	0.00	72219	\N	0	\N	\N
72216	13	Tarea 1.1	\N	2010-07-29 00:00:00	2010-08-07 00:00:00	\N	0.00	72219	\N	1	\N	\N
72217	13	Tarea 1.3	\N	2010-08-07 00:00:00	2010-08-14 00:00:00	\N	0.00	72219	\N	2	\N	\N
72228	19	Pedido 6	\N	2010-07-16 00:00:00	2010-08-14 00:00:00	2010-09-30	0.02	\N	\N	\N	\N	\N
26528	10	Recurso limitante xenérica	\N	2010-08-23 00:00:00	2010-10-14 00:00:00	\N	0.00	26491	\N	3	\N	\N
83031	1	Pedido 3 escenario 2	\N	2010-06-16 17:56:47.998	2010-10-19 17:56:47.998	2010-11-26	0.00	\N	\N	\N	\N	\N
83030	1	Tarefa 1	\N	2010-06-16 17:56:47.998	2010-10-19 17:56:47.998	\N	0.00	83031	\N	0	\N	\N
83056	1	Montaje de andamios	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	2010-08-10	0.29	\N	\N	\N	\N	\N
83053	1	Tarea 2	\N	2010-07-21 02:24:00	2010-07-30 02:24:00	2010-08-10	0.40	83055	\N	0	\N	\N
83054	1	Tarefa 1	\N	2010-07-16 00:00:00	2010-07-28 12:00:00	\N	0.25	83055	\N	1	\N	\N
83055	1	Tarea 1.4	\N	2010-07-16 00:00:00	2010-07-30 02:24:00	2010-08-10	0.29	83056	\N	0	\N	\N
109719	4	Implantación proyecto	\N	2011-01-31 00:00:00	2011-01-31 00:00:00	\N	0.00	109718	\N	10	\N	\N
106155	6	tarefa3	\N	2010-07-11 18:24:00	2010-08-30 18:24:00	\N	0.00	106156	\N	2	\N	\N
106153	6	subtarefa 3.1	\N	2010-07-11 18:24:00	2010-08-18 06:24:00	\N	0.00	106155	\N	0	\N	\N
106154	6	subtarefa 1	\N	2010-08-18 06:24:00	2010-08-30 18:24:00	\N	0.00	106155	\N	1	\N	\N
106151	6	tqrefa1	\N	2010-07-06 11:46:27.203	2010-07-13 11:46:27.203	\N	0.25	106156	\N	0	\N	\N
106152	6	tarefa2	\N	2010-07-13 11:46:27.203	2010-07-25 23:46:27.203	\N	0.00	106156	\N	1	\N	\N
106156	6	Barco 1	\N	2010-07-06 11:46:27.203	2010-08-30 18:24:00	2010-09-22	0.07	\N	\N	\N	\N	\N
159285	29	Bloque 2 - 1 	\N	2010-12-09 00:00:00	2011-01-05 00:00:00	\N	0.50	159286	\N	2	0	0
159286	29	Pedido grupo 1	\N	2010-09-02 00:00:00	2011-01-05 00:00:00	2010-12-02	0.38	\N	\N	\N	0	0
103931	7	Tarea 3	\N	2010-07-15 15:14:38.224	2010-08-11 15:14:38.224	\N	0.00	103933	\N	2	\N	\N
103932	7	Tarea 4	\N	2010-07-05 15:14:38.224	2010-07-15 15:14:38.224	\N	0.00	103933	\N	3	\N	\N
103930	7	Tarea 2	\N	2010-08-07 15:14:38.224	2010-09-11 15:14:38.224	\N	0.00	103933	\N	1	\N	\N
103929	7	Tarea 1	\N	2010-07-05 15:14:38.224	2010-08-07 15:14:38.224	\N	0.00	103933	\N	0	\N	\N
103933	9	Construcción de barco 1	\N	2010-07-05 15:14:38.224	2010-09-11 15:14:38.224	2010-07-28	0.00	\N	\N	\N	\N	\N
159277	23	Coordinación	\N	2010-09-02 00:00:00	2010-11-19 00:00:00	\N	0.25	159286	\N	0	0	0
159278	24	Repasar soldaduras ocos	\N	2010-11-20 00:00:00	2010-12-09 00:00:00	\N	0.00	159281	\N	0	0	0
159279	23	Soldar unións do teito	\N	2010-09-02 00:00:00	2010-10-16 00:00:00	\N	0.40	159281	\N	1	0	0
159280	23	Soldar unións do chan	\N	2010-10-16 00:00:00	2010-11-20 00:00:00	\N	0.30	159281	\N	2	0	0
159282	24	Cama e mesilla do camarote	\N	2010-12-09 00:00:00	2011-01-05 00:00:00	\N	0.00	159285	\N	0	0	0
159283	24	Teito de madeira de camarote	\N	2010-12-09 00:00:00	2011-01-05 00:00:00	\N	0.00	159285	\N	1	0	0
159284	25	Poñer escotillas a camarote	\N	2010-12-09 00:00:00	2011-01-03 00:00:00	\N	0.00	159285	\N	2	0	0
159281	29	Bloque 1	\N	2010-09-02 00:00:00	2010-12-09 00:00:00	\N	0.28	159286	\N	1	0	0
109713	18	Infraestructura del proyecto	\N	2010-09-01 00:00:00	2010-09-10 00:00:00	\N	0.00	109718	\N	8	\N	\N
109687	18	Análisis	\N	2010-09-01 00:00:00	2011-01-06 00:00:00	\N	0.00	109718	\N	1	\N	\N
109707	18	CU – Mostrado de nube de tags	\N	2010-12-01 00:00:00	2010-12-10 00:00:00	\N	0.00	109711	\N	0	\N	\N
109708	18	CU – Edición de etiquetas de recurso	\N	2010-12-10 00:00:00	2010-12-17 00:00:00	\N	0.00	109711	\N	1	\N	\N
109709	18	CU – Asignación de etiqueta a recurso de Mugshot.	\N	2010-12-17 00:00:00	2010-12-24 00:00:00	\N	0.00	109711	\N	2	\N	\N
109710	18	CU – Edición de etiquetas de recurso	\N	2010-12-24 00:00:00	2010-12-30 00:00:00	\N	0.00	109711	\N	3	\N	\N
109686	18	Coordinación	\N	2010-09-01 00:00:00	2011-01-26 00:00:00	\N	0.00	109718	\N	0	\N	\N
109712	18	Arquitectura	\N	2010-09-10 00:00:00	2010-10-02 00:00:00	\N	0.00	109718	\N	7	\N	\N
109704	18	Autenticación con servicio REST de Guadalinfo	\N	2010-11-11 00:00:00	2010-11-20 00:00:00	\N	0.00	109706	\N	0	\N	\N
109705	18	Autenticación vía OpenID	\N	2010-11-20 00:00:00	2010-12-01 00:00:00	\N	0.00	109706	\N	1	\N	\N
109717	18	Adaptación visual	\N	2010-11-26 12:35:31.352	2010-12-07 12:35:31.352	\N	0.00	109718	\N	13	\N	\N
109688	18	Implantación del servidor	\N	2010-09-10 00:00:00	2010-09-29 00:00:00	\N	0.00	109691	\N	0	\N	\N
109689	18	Parametrización del servidor	\N	2010-09-29 00:00:00	2010-10-08 00:00:00	\N	0.00	109691	\N	1	\N	\N
109690	18	Parametrización de páginas	\N	2010-10-08 00:00:00	2010-10-19 00:00:00	\N	0.00	109691	\N	2	\N	\N
109714	18	Pruebas	\N	2010-12-30 00:00:00	2011-01-19 00:00:00	\N	0.00	109718	\N	9	\N	\N
109692	18	Implantación de cliente de escritorio	\N	2010-10-19 00:00:00	2010-11-11 00:00:00	\N	0.00	109718	\N	3	\N	\N
109720	5	Implantación	\N	2011-01-19 00:00:00	2011-01-29 00:00:00	\N	0.00	109718	\N	14	\N	\N
109716	18	Entorno	\N	2010-09-01 00:00:00	2010-12-08 00:00:00	\N	0.00	109718	\N	12	\N	\N
109693	18	Pruebas y adaptación de Facebook	\N	2010-10-02 00:00:00	2010-10-07 00:00:00	\N	0.00	109703	\N	0	\N	\N
109694	18	Pruebas y adaptación de Last.fm	\N	2010-10-07 00:00:00	2010-10-12 00:00:00	\N	0.00	109703	\N	1	\N	\N
109695	18	Pruebas y adaptación de Rhapsody	\N	2010-10-12 00:00:00	2010-10-15 00:00:00	\N	0.00	109703	\N	2	\N	\N
109696	18	Pruebas y adaptación de Google Reader	\N	2010-10-15 00:00:00	2010-10-20 00:00:00	\N	0.00	109703	\N	3	\N	\N
109697	18	Pruebas y adaptación de Digg and Reddit	\N	2010-10-20 00:00:00	2010-10-23 00:00:00	\N	0.00	109703	\N	4	\N	\N
109698	18	Pruebas y adaptación de Flickr	\N	2010-10-23 00:00:00	2010-10-28 00:00:00	\N	0.00	109703	\N	5	\N	\N
109699	18	Pruebas y adaptación de Twitter	\N	2010-10-28 00:00:00	2010-11-02 00:00:00	\N	0.00	109703	\N	6	\N	\N
159289	17	Recepción de material	\N	2011-01-05 00:00:00	2011-01-05 00:00:00	\N	0.00	159286	\N	3	0	0
109700	18	Pruebas y adaptación de Delicious	\N	2010-11-02 00:00:00	2010-11-05 00:00:00	\N	0.00	109703	\N	7	\N	\N
109715	18	Documentación	\N	2010-12-30 00:00:00	2011-01-21 00:00:00	\N	0.00	109718	\N	11	\N	\N
109701	18	Pruebas y adaptación de RSS	\N	2010-11-05 00:00:00	2010-11-10 00:00:00	\N	0.00	109703	\N	8	\N	\N
109702	18	Pruebas y adaptación de Youtube	\N	2010-11-10 00:00:00	2010-11-13 00:00:00	\N	0.00	109703	\N	9	\N	\N
109711	24	Sistema de etiquetado	\N	2010-12-01 00:00:00	2010-12-30 00:00:00	\N	0.00	109718	\N	6	\N	\N
109706	24	Sistema de autenticación	\N	2010-11-11 00:00:00	2010-12-01 00:00:00	\N	0.00	109718	\N	5	\N	\N
109691	24	Implantación de Mugshot	\N	2010-09-10 00:00:00	2010-10-19 00:00:00	\N	0.00	109718	\N	2	\N	\N
109703	24	Integración con redes sociales	\N	2010-10-02 00:00:00	2010-11-26 00:00:00	\N	0.00	109718	\N	4	\N	\N
150692	2	Implementación y pruebas de integración con Tuenti	\N	2010-11-13 00:00:00	2010-11-26 00:00:00	\N	0.00	109703	\N	10	\N	\N
109718	24	Proyecto consistente en montaje de prototipo para PLE para Guadalinfo con la implantación de Mugshot	\N	2010-09-01 00:00:00	2011-01-31 00:00:00	2011-01-31	0.00	\N	\N	\N	\N	\N
153520	5	Coordinación	\N	2010-09-19 00:00:00	2010-11-13 00:00:00	\N	0.00	153537	\N	0	0	0
153521	5	Análisis	\N	2010-09-19 00:00:00	2010-10-12 00:00:00	\N	0.00	153537	\N	1	0	0
153524	5	Módulo de usuarios	\N	2010-09-19 00:00:00	2010-09-22 00:00:00	\N	0.00	153537	\N	3	0	0
153522	5	Configuración de permisos y grupos	\N	2010-09-21 00:00:00	2010-09-22 00:00:00	\N	0.00	153524	\N	0	0	0
153523	5	Configuración sistema de usuarios	\N	2010-09-19 00:00:00	2010-09-21 00:00:00	\N	0.00	153524	\N	1	0	0
153525	5	Montaje del árbol de contenidos	\N	2010-09-22 00:00:00	2010-09-23 00:00:00	\N	0.00	153532	\N	0	0	0
153526	5	Implantación de diseño general	\N	2010-09-23 00:00:00	2010-10-02 00:00:00	\N	0.00	153532	\N	1	0	0
168670	1	Limitante	\N	2010-09-02 00:00:00	2010-09-04 00:00:00	\N	0.00	159286	\N	4	0	0
153534	5	Formación	\N	2010-10-23 00:00:00	2010-10-26 00:00:00	\N	0.00	153537	\N	6	0	0
153537	5	Desarrollo web Personalia	\N	2010-09-19 00:00:00	2010-11-13 00:00:00	2010-11-15	0.00	\N	\N	\N	0	0
153539	1	Diseño es entregado al comienzo del proyecto	\N	2010-09-19 00:00:00	2010-09-19 00:00:00	\N	0.00	153537	\N	2	0	0
153532	5	Gestión de contenidos y plantillas	\N	2010-09-22 00:00:00	2010-10-23 00:00:00	\N	0.00	153537	\N	4	0	0
153527	5	Migración de contenidos	\N	2010-10-02 00:00:00	2010-10-06 00:00:00	\N	0.00	153532	\N	2	0	0
153528	5	Montaje herramienta galería	\N	2010-10-06 00:00:00	2010-10-08 00:00:00	\N	0.00	153532	\N	3	0	0
153529	5	Montaje herramienta noticias	\N	2010-10-08 00:00:00	2010-10-12 00:00:00	\N	0.00	153532	\N	4	0	0
153530	5	configuración de secciones y subsecciones principales	\N	2010-10-12 00:00:00	2010-10-19 00:00:00	\N	0.00	153532	\N	5	0	0
153531	5	Centros	\N	2010-10-19 00:00:00	2010-10-23 00:00:00	\N	0.00	153532	\N	6	0	0
153533	5	Entorno	\N	2010-09-21 00:00:00	2010-10-04 00:00:00	\N	0.00	153537	\N	5	0	0
153535	5	Implantación	\N	2010-10-27 00:00:00	2010-10-28 00:00:00	\N	0.00	153537	\N	7	0	0
153536	5	Pruebas	\N	2010-10-23 00:00:00	2010-10-27 00:00:00	\N	0.00	153537	\N	8	0	0
153542	0	Entrega	\N	2010-10-27 00:00:00	2010-10-27 00:00:00	\N	0.00	153537	\N	9	0	0
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
2123
2126
2127
5458
5463
5466
5467
9295
9296
22831
22833
26467
26469
26474
26479
26482
26483
26486
26489
26491
26496
26501
26504
26505
26511
26513
26518
26523
26526
26527
64745
64750
64753
64754
72219
72228
72232
72233
83024
83026
83029
83031
83045
83046
83051
83052
83055
83056
83059
83060
103933
106155
106156
109691
109703
109706
109711
109718
153524
153532
153537
159281
159285
159286
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id, startconstrainttype, constraintdate) FROM stdin;
64755	\N	\N
109719	\N	\N
153542	0	\N
153539	0	\N
159289	0	\N
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, schedulingdata) FROM stdin;
2123	5	1633
2126	5	1636
2127	5	1632
2121	9	1634
2122	9	1635
2124	9	1637
2125	9	1638
2129	3	1644
26483	2	26047
26470	3	26049
26471	3	26050
26472	3	26051
26473	3	26052
26475	3	26054
26476	3	26055
26477	3	26056
26478	3	26057
26480	3	31917
26481	3	31918
26467	2	26001
26469	2	25997
26462	3	25998
26463	3	25999
26464	3	26000
26465	3	26002
26466	3	26003
9295	2	7685
9296	2	7677
9292	3	7678
9293	3	7686
9294	3	7687
26468	3	26004
5458	8	5080
5463	8	5085
64741	1	64541
26504	5	43574
5466	8	5090
5467	8	5053
5454	15	5081
22831	5	22443
5455	15	5082
22833	5	22439
22826	9	22440
22827	9	22441
22828	9	22442
22829	9	22444
26505	5	43563
22830	9	22445
22832	9	22446
26492	9	43565
26506	1	43602
26507	1	43603
26508	1	43604
5456	15	5083
5457	15	5084
5459	15	5086
5460	15	5087
5461	15	5088
5462	15	5089
5464	15	5091
5465	15	5092
26509	1	43606
26510	1	43607
26511	1	43605
26517	1	43614
26512	1	43608
26513	1	43601
26518	1	43610
26519	1	43616
26520	1	43617
26521	1	43618
26522	1	43619
26523	1	43615
26524	1	43621
26525	1	43622
26474	2	26048
26526	1	43620
26527	1	43609
26493	9	43566
26494	9	43567
26479	2	26053
26495	9	43568
26482	2	31916
64742	1	64542
26497	9	43570
26498	9	43571
26486	6	31944
26499	9	43572
26500	9	43573
26489	6	31947
64743	1	64543
64744	1	64544
64745	1	64540
64746	1	64546
64747	1	64547
64748	1	64548
64749	1	64549
26502	9	43575
26514	1	43611
26515	1	43612
26516	1	43613
26491	6	31943
64750	1	64545
64751	1	64551
64752	1	64552
64753	1	64550
64754	1	64539
26496	5	43564
26501	5	43569
26484	11	31945
26485	11	31946
72219	7	71753
72228	7	71752
72215	13	71754
72216	13	71755
72217	13	71756
26487	11	31948
26488	11	31949
26490	11	31950
26528	5	43625
72232	2	71772
72233	2	71766
72230	3	71767
72231	3	71773
72229	3	71757
83022	2	82575
83023	2	82576
83024	2	82574
83025	2	82577
83026	2	82573
83027	1	82583
83028	1	82590
83029	1	82589
83030	1	82592
83031	1	82591
83045	0	101726
83046	0	101727
83047	0	101728
83048	0	101729
83049	1	101736
83050	1	101737
83051	1	101735
83052	1	101734
83053	1	101744
83054	1	101745
83055	1	101743
83056	1	101742
83059	2	101752
83060	2	101746
83057	3	101747
83058	3	101753
153520	2	152807
153521	2	153236
153522	2	153219
153523	2	153247
153524	2	153246
153525	2	153220
153526	2	153279
153527	2	153280
103933	4	103536
103929	6	103537
103930	6	103538
103931	6	103539
103932	6	103540
153528	2	153281
153529	2	153282
153530	2	153283
153531	2	153284
153532	2	153278
153533	2	153285
106151	2	105660
106152	2	105661
106153	2	105663
106154	2	105664
106155	2	105662
106156	2	105659
153534	2	153222
109718	7	108982
109686	13	109028
109687	13	109029
109688	13	109031
109689	13	109032
109690	13	109033
109692	13	109034
109693	13	109035
109694	13	109074
109695	13	109075
109696	13	109076
109697	13	109077
109698	13	109078
109699	13	109079
109700	13	109383
109701	13	109384
109702	13	109385
109704	13	109407
109705	13	109408
109707	13	109036
109708	13	109396
109709	13	109395
109710	13	109397
109712	13	109038
109713	13	109039
109714	13	109040
109715	13	109041
109716	13	109042
109717	13	109413
109720	5	109416
153535	2	153223
150692	1	150391
153536	2	153287
153537	2	152715
159281	10	158914
109691	7	109030
159285	10	158918
159286	10	158910
159277	18	158911
159278	18	158915
159279	18	158916
159280	18	158917
159282	18	158919
159283	18	158920
159284	18	158921
168670	1	167585
109703	7	109073
109706	7	109394
109711	7	109409
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled, generatecode) FROM stdin;
13938	1	EXTRA	f970c975-7dec-426a-8fb6-a4a16c933b7e	12.00	t	t
13939	1	NORMAL	cae21596-0a34-48cd-9631-8c518c8e771d	7.00	t	t
164731	1	HORA NORMAL METAL	b60eb1b3-28db-4fa1-80da-0430eed45d1e	20.00	t	t
164732	1	EXTRA CONVENIO METAL	351ccfca-0fbb-4cb6-9e88-cfd42f9d83cb	24.00	t	t
\.


--
-- Data for Name: unit_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY unit_type (id, version, code, measure, generatecode) FROM stdin;
1010	1	6ebce9b1-edb0-4aa8-80ba-11110ab2d66d	units	f
1011	1	7f8ae0ce-c0db-4a86-a111-33f9f54f3b0d	kg	f
1012	1	602c5c22-0965-4ac1-a222-c573f7a2a808	km	f
1013	1	d4122110-85f4-414a-a0a5-a8200a1863c1	l	f
1014	1	214f0d77-aea5-4c54-8599-c522487249f9	m	f
1015	1	b2e7552f-bdee-4506-885e-076d0c9168ab	m2	f
1016	1	2a21466d-d5b7-47e5-8ca9-7f72917c937f	m3	f
1017	1	bf517748-e2f1-4710-b5c2-1bbd96f59f91	tn	f
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
1112	ROLE_READ_ALL_ORDERS
1112	ROLE_CREATE_ORDER
1112	ROLE_EDIT_ALL_ORDERS
1112	ROLE_ADMINISTRATION
1113	ROLE_WS_READER
1114	ROLE_WS_WRITER
1114	ROLE_WS_READER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
21817	Desc.
72321	\N
83633	\N
107364	\N
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, code, date, generatecode, work_report_type_id, resource_id, order_element_id) FROM stdin;
14039	1	54569b70-811f-4acb-b885-a088fa0fa1ee	\N	t	13837	\N	\N
81709	1	3dd14ec6-6768-4fd6-baca-62c53c12e0e9	\N	t	13837	\N	\N
81712	1	6624fbdb-60a2-4761-9dc7-c4dcd6c3d2aa	\N	t	13837	\N	\N
164529	2	2f9cddc8-07e0-41c5-a7dd-88eb66adffdb	\N	t	164327	151915	\N
164530	1	97817bd4-a6eb-4045-9f53-ed7352c4b6a1	\N	t	164327	151909	\N
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, positionnumber, label_type_id, label_id, work_report_type_id) FROM stdin;
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, code, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
14140	1	08f228ff-3818-477c-aa17-d46ec755ca03	8	2010-06-15 00:00:00	\N	\N	14039	4344	4980	13939
14141	1	4b970514-ee0c-4f69-a077-864c837cfd29	8	2010-06-14 00:00:00	\N	\N	14039	4344	4982	13939
81810	1	9b9affac-7e80-4df2-b1be-c8b530841b2c	30	2010-06-15 00:00:00	\N	\N	81709	4344	1537	13939
81811	1	544ebbe1-966f-41bd-b7f7-19c70c909527	40	2010-06-16 00:00:00	\N	\N	81709	4344	1543	13939
81815	1	f0bedb10-5234-4b69-ad37-a32acd5c841b	24	2010-06-21 00:00:00	\N	\N	81712	4350	22340	13939
81816	1	2700acbe-9543-42be-8861-72123ef24811	24	2010-06-22 00:00:00	\N	\N	81712	4352	22341	13939
164431	2	a7a02b6b-0f16-4c2b-b335-1436d0477d04	6	2010-09-06 00:00:00	\N	\N	164529	151915	158709	13939
164428	2	e6215508-6f9e-4cce-a1b7-e038e1798521	8	2010-09-03 08:31:28.786	\N	\N	164529	151915	158709	13939
164429	2	e44a0189-babe-49d8-afea-6052c55402fa	5	2010-09-03 08:31:07.988	\N	\N	164529	151915	158709	13939
164430	2	6a86e5b1-4723-4823-a806-5e1b39fce1be	2	2010-09-03 08:31:28.083	\N	\N	164529	151915	158708	13939
164439	1	791db90c-ade6-400a-b033-c3fb9a0df7d1	8	2010-09-07 00:00:00	\N	\N	164530	151909	158713	13939
164440	1	4d4645c0-a89b-4c9c-a204-b01d8f6424d2	8	2010-09-03 09:42:08.141	\N	\N	164530	151909	158713	13939
164441	1	d04c8d32-4da2-4543-8dc9-357cf1f64c20	4	2010-09-08 00:00:00	\N	\N	164530	151909	158713	13938
164442	1	2c0cd276-310c-4575-94b6-20b5ccfa1096	9	2010-09-06 00:00:00	\N	\N	164530	151909	158713	13939
164443	1	2aa23f73-5d68-4217-909e-4962ec56866a	9	2010-09-09 00:00:00	\N	\N	164530	151909	158713	13939
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
13837	1	Tipo de parte de trabajo	01	f	f	f	0
164327	1	Tipo Grupo 1	Cof1	f	t	f	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1214	Javier	Moran	78736622D
4344	Carlos	Villa Soldador1	11111111A
4348	Simón	Marchena Soldador2	22222222A
4350	Santiago	Alonso Soldador3	11111111W
4352	Tomás	Del Oro Pintor1	11111111Q
4354	Santiago	Lajos Pintor2	11111111R
4356	Rodrigo	Romero Pintor3	11111111T
4358	Laura	Gómez PintorSoldador	11111111T
21817	Soldadores	---	[Virtual]
72317	Samuel	Andamiero 1	99999999A
72319	Miriam	Andamiera 2	88888888A
72321	Andamiero	---	[Virtual]
83633	Andamieros 2011	---	[Virtual]
107364	gruppo de soldadores de proba	---	[Virtual]
111404	Diego	Pino García	11111111C
151905	Jacobo	Aragunde	123123123A
151907	Lorenzo	Tilve	23423424C
111406	Manuel	Rego Casasnovas	22222222D
151915	Javier	Pérez Campos	56565656L
151909	Javier 	Martínez Álvarez	11111111F
154733	María	Mariño Pérez	22222222F
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advanceassignmenttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT advanceassignmenttemplate_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_code_key UNIQUE (code);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_code_key UNIQUE (code);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_code_key UNIQUE (code);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_code_key UNIQUE (code);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: consolidatedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT consolidatedvalue_pkey PRIMARY KEY (id);


--
-- Name: consolidation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT consolidation_pkey PRIMARY KEY (id);


--
-- Name: cost_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_code_key UNIQUE (code);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_code_key UNIQUE (code);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_code_key UNIQUE (code);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_code_key UNIQUE (code);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: deriveddayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT deriveddayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: external_company_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_name_key UNIQUE (name);


--
-- Name: external_company_nif_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_nif_key UNIQUE (nif);


--
-- Name: external_company_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: genericdayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT genericdayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: hour_cost_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_code_key UNIQUE (code);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY effortperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_code_key UNIQUE (code);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_code_key UNIQUE (code);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT limiting_resource_queue_dependency_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_resource_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_resource_allocation_id_key UNIQUE (resource_allocation_id);


--
-- Name: limiting_resource_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_resource_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_resource_id_key UNIQUE (resource_id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_template_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT material_assigment_template_pkey PRIMARY KEY (id);


--
-- Name: material_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_code_key UNIQUE (code);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT order_authorization_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_element_template_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT order_element_template_label_pkey PRIMARY KEY (order_element_template_id, label_id);


--
-- Name: order_element_template_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT order_element_template_quality_form_pkey PRIMARY KEY (order_element_template_id, quality_form_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_code_key UNIQUE (code);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderelement_sum_charged_hours_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_sum_charged_hours_id_key UNIQUE (sum_charged_hours_id);


--
-- Name: orderelementtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT orderelementtemplate_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegrouptemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT orderlinegrouptemplate_pkey PRIMARY KEY (group_template_id);


--
-- Name: orderlinetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT orderlinetemplate_pkey PRIMARY KEY (order_line_template_id);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: ordertemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT ordertemplate_pkey PRIMARY KEY (order_template_id);


--
-- Name: orderversion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderversion
    ADD CONSTRAINT orderversion_pkey PRIMARY KEY (id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_base_calendar_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_base_calendar_id_key UNIQUE (base_calendar_id);


--
-- Name: resource_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_code_key UNIQUE (code);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_code_key UNIQUE (code);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: scenario_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT scenario_orders_pkey PRIMARY KEY (scenario_id, order_id);


--
-- Name: scenario_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scenario
    ADD CONSTRAINT scenario_pkey PRIMARY KEY (id);


--
-- Name: scheduling_states_by_order_version_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT scheduling_states_by_order_version_pkey PRIMARY KEY (order_element_id, order_version_id);


--
-- Name: schedulingdataforversion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY schedulingdataforversion
    ADD CONSTRAINT schedulingdataforversion_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: specificdayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT specificdayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: subcontractedtaskdata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT subcontractedtaskdata_pkey PRIMARY KEY (id);


--
-- Name: sumchargedhours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY sumchargedhours
    ADD CONSTRAINT sumchargedhours_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: task_subcontrated_task_data_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_subcontrated_task_data_id_key UNIQUE (subcontrated_task_data_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: tasksource_schedulingdata_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_schedulingdata_key UNIQUE (schedulingdata);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: unit_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_code_key UNIQUE (code);


--
-- Name: unit_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_code_key UNIQUE (code);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_code_key UNIQUE (code);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk1ccb0f7419b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f7419b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk1ccb0f74b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f74b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fk1fc5f45575ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f45575ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk1fc5f455bd2209e8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f455bd2209e8 FOREIGN KEY (limiting_resource_queue_id) REFERENCES limiting_resource_queue(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk27a9a55b595a0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a55b595a0 FOREIGN KEY (subcontrated_task_data_id) REFERENCES subcontractedtaskdata(id);


--
-- Name: fk2999e7e5421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT fk2999e7e5421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fk2999e7e57518838c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT fk2999e7e57518838c FOREIGN KEY (resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fk29d0015519b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d0015519b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk29d001558b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d001558b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk3a79eb0219b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0219b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk40795527f11b2d0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk40795527f11b2d0 FOREIGN KEY (unit_type) REFERENCES unit_type(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk4a1d42dc9fb7fc18; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT fk4a1d42dc9fb7fc18 FOREIGN KEY (order_line_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk4d68b9c89a4a7d90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c89a4a7d90 FOREIGN KEY (order_template_id) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fk4d68b9c8a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c8a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk53cd4dcaa2380ca7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderversion
    ADD CONSTRAINT fk53cd4dcaa2380ca7 FOREIGN KEY (ownerscenario) REFERENCES scenario(id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5948535228f2695; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk5948535228f2695 FOREIGN KEY (origin_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk59485352e42f8d29; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk59485352e42f8d29 FOREIGN KEY (destiny_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk698876da1b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT fk698876da1b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fk698876da421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT fk698876da421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk711ace7423b85cf1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace7423b85cf1 FOREIGN KEY (order_version_id) REFERENCES orderversion(id);


--
-- Name: fk711ace7487287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace7487287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fk711ace74c0fb9d8e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace74c0fb9d8e FOREIGN KEY (scenario_id) REFERENCES scenario(id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6b9e788f90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b9e788f90 FOREIGN KEY (queue_dependency) REFERENCES limiting_resource_queue_dependency(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39d4ec080cf; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39d4ec080cf FOREIGN KEY (customer) REFERENCES external_company(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk7e57469848d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT fk7e57469848d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk8217a424b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT fk8217a424b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fk9bb0b28841638aab; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT fk9bb0b28841638aab FOREIGN KEY (parent) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka04a45b123b85cf1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b123b85cf1 FOREIGN KEY (order_version_id) REFERENCES orderversion(id);


--
-- Name: fka04a45b19bfe55d0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b19bfe55d0 FOREIGN KEY (scheduling_state_for_version_id) REFERENCES schedulingdataforversion(id);


--
-- Name: fka04a45b1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fka87c31085567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c31085567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fka87c310887287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c310887287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fka87c3108edc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c3108edc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fka9542ec319b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec319b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fka9542ec3c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec3c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkab89a5edefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY schedulingdataforversion
    ADD CONSTRAINT fkab89a5edefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e209a2c0abd; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e209a2c0abd FOREIGN KEY (schedulingdata) REFERENCES schedulingdataforversion(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f5019256004; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5019256004 FOREIGN KEY (generic_container_id) REFERENCES genericdayassignmentscontainer(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f50510e7a78; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50510e7a78 FOREIGN KEY (derived_container_id) REFERENCES deriveddayassignmentscontainer(id);


--
-- Name: fkbb493f50756348a8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50756348a8 FOREIGN KEY (specific_container_id) REFERENCES specificdayassignmentscontainer(id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY effortperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkcf1f2cd08bdc6ac6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd08bdc6ac6 FOREIGN KEY (order_line_template) REFERENCES orderlinetemplate(order_line_template_id);


--
-- Name: fkd06071e0421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT fkd06071e0421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fkd06071e0ee970b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT fkd06071e0ee970b FOREIGN KEY (resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkd3056ef7ddc82952; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT fkd3056ef7ddc82952 FOREIGN KEY (group_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkd59fd7b0fd99606d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario
    ADD CONSTRAINT fkd59fd7b0fd99606d FOREIGN KEY (predecessor) REFERENCES scenario(id);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fkdbbb4fee7ec17fa6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee7ec17fa6 FOREIGN KEY (sum_charged_hours_id) REFERENCES sumchargedhours(id);


--
-- Name: fkdbbb4feed97bcc8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4feed97bcc8c FOREIGN KEY (template) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb026919b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb026919b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb0269b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb0269b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke562c7e93fee60cc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT fke562c7e93fee60cc FOREIGN KEY (companyuser) REFERENCES naval_user(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkecc6114019960f43; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT fkecc6114019960f43 FOREIGN KEY (externalcompany) REFERENCES external_company(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkeeedb0fc4cd98327; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT fkeeedb0fc4cd98327 FOREIGN KEY (lastconnectedscenario) REFERENCES scenario(id);


--
-- Name: fkef86282edc874c20; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282edc874c20 FOREIGN KEY (base_calendar_id) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf436a4163ae24ff8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a4163ae24ff8 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf436a416b96bba28; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416b96bba28 FOREIGN KEY (advance_measurement_id) REFERENCES advancemeasurement(id);


--
-- Name: fkf436a416cec54333; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416cec54333 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf8df3e0c430ea1de; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c430ea1de FOREIGN KEY (ind_advance_assignment_id) REFERENCES indirectadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0c9f1d6611; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c9f1d6611 FOREIGN KEY (dir_advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0cff2b2ba3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0cff2b2ba3 FOREIGN KEY (id) REFERENCES task(task_element_id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

