--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advanceassignmenttemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignmenttemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    advance_type_id bigint,
    order_element_template_id bigint,
    reportglobaladvance boolean,
    maxvalue numeric(19,2)
);


ALTER TABLE public.advanceassignmenttemplate OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint,
    communicationdate timestamp without time zone
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean,
    qualityform boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date date,
    duration integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255),
    generatecodeforcriterion boolean NOT NULL,
    generatecodeforlabel boolean NOT NULL,
    generatecodeforworkreport boolean NOT NULL,
    generatecodeforresources boolean NOT NULL,
    generatecodefortypesofworkhours boolean NOT NULL,
    generatecodeformaterialcategories boolean NOT NULL,
    generatecodeforunittypes boolean NOT NULL,
    expandcompanyplanningviewcharts boolean NOT NULL,
    expandorderplanningviewcharts boolean NOT NULL,
    expandresourceloadviewcharts boolean NOT NULL
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: consolidatedvalue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidatedvalue (
    id bigint NOT NULL,
    consolidated_value_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    taskenddate date,
    consolidation_id bigint,
    advance_measurement_id bigint
);


ALTER TABLE public.consolidatedvalue OWNER TO naval;

--
-- Name: consolidation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidation (
    id bigint NOT NULL,
    consolidation_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    dir_advance_assignment_id bigint,
    ind_advance_assignment_id bigint
);


ALTER TABLE public.consolidation OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    predefinedcriterioninternalname character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    order_element_template_id bigint,
    criterion_id bigint,
    parent bigint,
    valid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    predefinedtypeinternalname character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    generatecode boolean NOT NULL,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    duration integer NOT NULL,
    consolidated boolean,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_container_id bigint,
    generic_container_id bigint,
    derived_container_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    queue_dependency bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: deriveddayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE deriveddayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    derived_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.deriveddayassignmentscontainer OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: effortperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE effortperday (
    base_calendar_id bigint NOT NULL,
    effort integer,
    day_id integer NOT NULL
);


ALTER TABLE public.effortperday OWNER TO naval;

--
-- Name: external_company; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE external_company (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    nif character varying(255),
    client boolean,
    subcontractor boolean,
    interactswithapplications boolean,
    appuri character varying(255),
    ourcompanylogin character varying(255),
    ourcompanypassword character varying(255),
    companyuser bigint
);


ALTER TABLE public.external_company OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: genericdayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE genericdayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.genericdayassignmentscontainer OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    resourcetype character varying(255),
    workinghours integer NOT NULL,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint,
    order_line_template bigint
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: limiting_resource_queue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_id bigint
);


ALTER TABLE public.limiting_resource_queue OWNER TO naval;

--
-- Name: limiting_resource_queue_dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_dependency (
    id bigint NOT NULL,
    type integer,
    origin_queue_element_id bigint,
    destiny_queue_element_id bigint
);


ALTER TABLE public.limiting_resource_queue_dependency OWNER TO naval;

--
-- Name: limiting_resource_queue_element; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_element (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    limiting_resource_queue_id bigint,
    earlier_start_date_because_of_gantt timestamp without time zone,
    earliest_end_date_because_of_gantt timestamp without time zone,
    creation_timestamp bigint,
    start_date date,
    start_hour integer,
    end_date date,
    end_hour integer
);


ALTER TABLE public.limiting_resource_queue_element OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type bigint,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_assigment_template; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment_template (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment_template OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL,
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean,
    lastconnectedscenario bigint
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_authorization; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_authorization (
    id bigint NOT NULL,
    order_authorization_subclass character varying(255) NOT NULL,
    version bigint NOT NULL,
    authorizationtype character varying(255) NOT NULL,
    order_id bigint,
    user_id bigint,
    profile_id bigint
);


ALTER TABLE public.order_authorization OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_element_template_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_label (
    order_element_template_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_label OWNER TO naval;

--
-- Name: order_element_template_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_quality_form (
    order_element_template_id bigint NOT NULL,
    quality_form_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_quality_form OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    dependenciesconstraintshavepriority boolean,
    codeautogenerated boolean,
    lastorderelementsequencecode integer,
    workbudget numeric(19,2),
    materialsbudget numeric(19,2),
    totalhours integer,
    customerreference character varying(255),
    externalcode character varying(255),
    state integer,
    customer bigint,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    lastadvancemeausurementforspreading numeric(19,2),
    dirtylastadvancemeasurementforspreading boolean,
    parent bigint,
    template bigint,
    externalcode character varying(255),
    sum_charged_hours_id bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderelementtemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelementtemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    startasdaysfrombeginning integer,
    deadlineasdaysfrombeginning integer,
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelementtemplate OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: orderlinegrouptemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegrouptemplate (
    group_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinegrouptemplate OWNER TO naval;

--
-- Name: orderlinetemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinetemplate (
    order_line_template_id bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderlinetemplate OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: ordertemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordertemplate (
    order_template_id bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.ordertemplate OWNER TO naval;

--
-- Name: orderversion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderversion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    modificationbyownertimestamp timestamp without time zone,
    ownerscenario bigint
);


ALTER TABLE public.orderversion OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer,
    reportadvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    generatecode boolean NOT NULL,
    limited_resource boolean NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    intended_total_hours integer,
    originaltotalassignment integer,
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: scenario; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scenario (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    lastnotownedreassignationstimestamp timestamp without time zone,
    predecessor bigint
);


ALTER TABLE public.scenario OWNER TO naval;

--
-- Name: scenario_orders; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scenario_orders (
    order_id bigint NOT NULL,
    order_version_id bigint NOT NULL,
    scenario_id bigint NOT NULL
);


ALTER TABLE public.scenario_orders OWNER TO naval;

--
-- Name: scheduling_states_by_order_version; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE scheduling_states_by_order_version (
    order_element_id bigint NOT NULL,
    scheduling_state_for_version_id bigint NOT NULL,
    order_version_id bigint NOT NULL
);


ALTER TABLE public.scheduling_states_by_order_version OWNER TO naval;

--
-- Name: schedulingdataforversion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE schedulingdataforversion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    schedulingstatetype integer,
    order_element_id bigint
);


ALTER TABLE public.schedulingdataforversion OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: specificdayassignmentscontainer; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specificdayassignmentscontainer (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    scenario bigint
);


ALTER TABLE public.specificdayassignmentscontainer OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL,
    type integer
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: subcontractedtaskdata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE subcontractedtaskdata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    externalcompany bigint,
    subcontratationdate timestamp without time zone,
    subcontractcommunicationdate timestamp without time zone,
    workdescription character varying(255),
    subcontractprice numeric(19,2),
    subcontractedcode character varying(255),
    nodewithoutchildrenexported boolean,
    labelsexported boolean,
    materialassignmentsexported boolean,
    hoursgroupsexported boolean,
    state integer
);


ALTER TABLE public.subcontractedtaskdata OWNER TO naval;

--
-- Name: sumchargedhours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE sumchargedhours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    directchargedhours integer,
    indirectchargedhours integer
);


ALTER TABLE public.sumchargedhours OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone,
    subcontrated_task_data_id bigint,
    priority integer
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint,
    reportadvance boolean
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate date NOT NULL,
    startdayduration integer,
    enddate date NOT NULL,
    enddayduration integer,
    deadline date,
    advance_percentage numeric(19,2),
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL,
    startconstrainttype integer,
    constraintdate timestamp without time zone
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    schedulingdata bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean,
    generatecode boolean NOT NULL
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: unit_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE unit_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    measure character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.unit_type OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date timestamp without time zone,
    generatecode boolean NOT NULL,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    positionnumber integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart integer,
    clockfinish integer,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
16150	3	t	1011
16151	3	t	1012
16152	3	t	1012
16153	3	t	1012
16155	3	f	1012
16154	3	t	1010
16156	3	t	1011
16157	3	t	1013
16159	3	f	1010
16158	3	f	1013
16365	3	f	1011
16364	3	f	1012
16363	3	f	1013
16362	3	t	1010
16424	2	t	1011
9383	7	f	1010
9382	7	t	1013
9381	9	t	1013
16425	2	t	1013
16426	2	f	1010
16427	2	f	1013
16428	2	f	1011
16429	2	f	1013
16430	2	t	1010
16431	2	f	1012
16432	4	t	1011
16433	4	t	1011
16434	4	t	1011
16437	4	t	1011
16438	4	t	1011
23085	0	f	10201
9324	7	t	1011
2626	20	t	1011
5941	11	t	1012
5942	11	t	1012
2629	20	t	1012
2631	15	t	1010
23086	0	t	1012
23087	0	f	1012
23088	0	f	10201
16435	3	f	1011
16436	3	t	1010
16440	3	f	1011
16439	3	f	1010
16442	3	t	1010
16441	3	f	1011
5943	7	f	1012
2637	15	f	1011
9387	4	f	1013
2638	15	t	1010
5944	7	f	1012
9384	6	t	1013
9386	4	f	1010
9385	4	f	1013
16418	2	t	1011
16419	2	t	1012
16420	2	t	1012
16421	2	t	1012
16422	2	f	1012
16423	2	t	1010
\.


--
-- Data for Name: advanceassignmenttemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignmenttemplate (id, version, advance_type_id, order_element_template_id, reportglobaladvance, maxvalue) FROM stdin;
11229	1	1011	11046	t	100.00
11230	1	1012	11050	t	15.00
11231	1	1012	11051	t	10.00
11232	1	1012	11052	t	5.00
11233	1	1011	11053	t	100.00
11234	1	1013	11056	t	100.00
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id, communicationdate) FROM stdin;
9393	7	2010-09-16	5.00	9324	\N
5845	11	2010-10-15	25.00	2626	\N
5846	11	2010-09-15	5.00	5941	\N
5847	11	2010-10-03	3.00	5942	\N
5848	11	2010-10-29	2.00	2629	\N
5849	11	2010-10-01	1.00	2629	\N
9410	7	2011-01-18	60.00	9384	\N
22877	0	2010-09-08	5.00	23086	\N
16696	3	2011-01-20	60.00	9381	2010-09-07 17:37:07.047
9409	9	2011-01-18	30.00	9381	2010-09-07 17:37:07.047
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage, qualityform) FROM stdin;
1010	4	children	100.0000	f	0.0100	t	t	f
1011	3	percentage	100.0000	f	0.0100	t	t	f
1012	2	units	2147483647.0000	f	1.0000	t	f	f
1013	1	subcontractor	100.0000	f	0.0100	t	t	f
10201	1	QF: Formulario de calidade procesos tipo 1	100.0000	f	0.0100	t	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
3151	144
3152	144
3153	144
20348	144
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, code, name) FROM stdin;
505	2	e4ad6e06-cabf-48ff-801a-31403af9c429	Default
507	1	a3f68afd-f08d-468f-bd83-c7f8e794cc9a	Galicia Media Xornada
506	2	9d9084ed-7232-4e81-8037-1b6e3c95199f	Galicia
509	3	842ec0d3-f403-4ffa-8e18-fc216d36970f	\N
508	9	f6087309-20aa-4bf9-81e5-f82251817b04	\N
511	10	92b45c5a-efac-4111-b3e4-bfbe2861ffbe	\N
510	9	9e1fbeb4-7e19-49cf-8ec4-de930d5bf944	\N
19897	2	12368f69-6d50-486b-bea8-7730e0a669f0	\N
19898	2	2218a87c-bc79-49f1-8973-51cef640c234	\N
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
1617	3	2010-09-15	2011-09-15	509	0
1616	9	2010-09-09	\N	508	0
1619	10	2010-09-15	2011-09-15	511	0
1618	9	2010-09-01	\N	510	0
20099	2	2010-09-08	\N	19897	0
20100	2	2010-09-08	2010-12-08	19898	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, code, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
606	2	ab2ad633-91db-4216-a10a-99270d3496fe	\N	\N	505	0
608	1	dcaecd81-eb80-4933-b510-309d498e2dfd	506	\N	507	0
607	2	b758e48c-6bf0-4178-a4d2-e82f73d0cb63	505	\N	506	0
610	3	50f7bfe2-776c-496e-a217-9b71afc5442e	505	\N	509	0
609	9	8f4244e6-00fd-45f7-97ae-fc5b63141904	506	\N	508	0
612	10	0b132552-2c12-4820-92a5-215380e9a111	507	\N	511	0
611	9	e8db9ede-4015-40e5-9591-8484774013a3	506	\N	510	0
19998	2	40028340-46be-4757-9103-857b771184de	505	\N	19897	0
19999	2	cdb4e144-23dd-439b-97cf-13d7bdf1d635	506	\N	19898	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, code, date, duration, calendar_exception_id, base_calendar_id) FROM stdin;
1215	1	84c75ca3-6db2-47f4-b0fb-bd9a5d916eb9	2010-11-01	0	913	505
1216	1	a1c92f09-0b2a-4689-9e7f-21888493f50d	2010-12-06	0	913	505
1217	1	2ce20ac4-5fec-4d91-9171-e25f7560f2be	2010-12-08	0	913	505
1213	2	8937b6dd-43b6-477f-982b-a3c4d40ad23e	2011-05-17	0	913	506
1218	1	c106a7be-b5be-490e-bdd1-812818befba4	2010-12-31	0	913	506
1219	1	4e85a638-cbe9-4a94-b0fc-fd4865717683	2010-12-24	14400	913	506
1222	8	77d08d5d-8570-4a9e-aea1-8d89e48dcd5c	2010-11-06	0	909	511
1220	8	e73882f3-abfd-487f-90b2-277685e41278	2010-11-09	0	909	511
1223	8	cdd2bed6-17fb-4925-8249-43d4805d5b55	2010-11-04	0	909	511
1226	8	8c7b28b9-6874-4d68-aadf-adf21e998ae2	2010-11-03	0	909	511
1225	8	68c9aa98-e285-40ac-a8b9-4be4bcdc6328	2010-11-05	0	909	511
1221	8	c4183588-573c-4004-a15a-701f9b06030c	2010-11-07	0	909	511
1224	8	aa453753-0080-48a6-aa27-2987f182a290	2010-11-08	0	909	511
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, code, name, color, notassignable) FROM stdin;
909	6	HOLIDAY	HOLIDAY	red	t
910	5	SICK_LEAVE	SICK_LEAVE	red	t
911	4	LEAVE	LEAVE	red	t
912	3	STRIKE	STRIKE	red	t
913	2	BANK_HOLIDAY	BANK_HOLIDAY	red	t
914	1	WORKABLE_BANK_HOLIDAY	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode, generatecodeforcriterion, generatecodeforlabel, generatecodeforworkreport, generatecodeforresources, generatecodefortypesofworkhours, generatecodeformaterialcategories, generatecodeforunittypes, expandcompanyplanningviewcharts, expandorderplanningviewcharts, expandresourceloadviewcharts) FROM stdin;
707	2	505	COMPANY_CODE	t	t	t	t	t	t	t	t	t	t
\.


--
-- Data for Name: consolidatedvalue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidatedvalue (id, consolidated_value_type, version, date, value, taskenddate, consolidation_id, advance_measurement_id) FROM stdin;
\.


--
-- Data for Name: consolidation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidation (id, consolidation_type, version, dir_advance_assignment_id, ind_advance_assignment_id) FROM stdin;
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, code, name, enabled) FROM stdin;
9595	1	058d64c4-7338-4cc0-97cf-854556beb1cf	Operarios con menos de 5 anos de experiencia	t
9596	1	e2df9c01-d852-4eff-9cb4-f01d8bc01158	Operarios con máis de 5 anos de experiencia	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, code, name, predefinedcriterioninternalname, active, id_criterion_type, parent) FROM stdin;
101	17	5a0c90ab-d6e5-4f68-83b5-1cb09712df18	medicalLeave	medicalLeave	t	1	\N
102	15	a6d56e50-15fc-40f7-9eaf-c72ad2806c16	paternityLeave	paternityLeave	t	1	\N
103	5	54cf6db2-01fb-42ad-9df7-41eb3bd5700e	hiredResourceWorkingRelationship	hiredResourceWorkingRelationship	t	5	\N
104	3	0e91477d-a25f-4de5-90ad-5d8679f375f7	firedResourceWorkingRelationship	firedResourceWorkingRelationship	t	5	\N
141	1	a02045b5-4468-41a4-b3ce-7413d76bf228	Pintor	\N	t	16	\N
142	1	8ff46a4a-2a9d-4981-843d-cfb694de9a38	Electricista	\N	t	16	\N
143	1	376cff90-94a2-4328-97fb-660a9c42bc9d	Carpinteiro	\N	t	16	\N
144	1	77b7c789-fab5-425d-a26c-cfb07e2fd909	Soldador	\N	t	16	\N
145	1	71f18c5d-cc09-45c5-8307-f66ce1bdc8a8	Oficial 1º	\N	t	17	\N
146	1	5ebe8df8-6113-48b1-a227-8faed5ceb916	Peón	\N	t	17	\N
147	1	132c2c2c-6935-4950-94ce-39e32d3d78a4	Oficial 2º	\N	t	17	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, order_element_template_id, criterion_id, parent, valid) FROM stdin;
11169	DIRECT	1	\N	\N	11050	144	\N	\N
11170	INDIRECT	1	11338	\N	\N	144	11169	t
11171	DIRECT	1	\N	\N	11051	144	\N	\N
11172	INDIRECT	1	11339	\N	\N	144	11171	t
11173	DIRECT	1	\N	\N	11052	144	\N	\N
11174	INDIRECT	1	11340	\N	\N	144	11173	t
11175	DIRECT	1	\N	\N	11053	143	\N	\N
11176	INDIRECT	1	\N	\N	11054	143	11175	t
11177	INDIRECT	1	11341	\N	\N	143	11175	t
11178	INDIRECT	1	\N	\N	11055	143	11175	t
11179	INDIRECT	1	11342	\N	\N	143	11175	t
11180	INDIRECT	1	\N	\N	11056	143	11175	t
11181	INDIRECT	1	11343	\N	\N	143	11175	t
2987	INDIRECT	11	2284	\N	\N	145	2985	t
2989	INDIRECT	11	2285	\N	\N	145	2985	t
2943	INDIRECT	10	2286	\N	\N	144	2942	t
2945	INDIRECT	10	2287	\N	\N	144	2944	t
2947	INDIRECT	12	2288	\N	\N	144	2946	t
2948	DIRECT	13	\N	1918	\N	143	\N	\N
2954	INDIRECT	11	2291	\N	\N	143	2948	t
16248	DIRECT	3	\N	15734	\N	145	\N	\N
16249	INDIRECT	3	\N	15735	\N	145	16248	t
16250	INDIRECT	3	15638	\N	\N	145	16248	t
16251	INDIRECT	3	\N	15736	\N	145	16248	t
16252	INDIRECT	3	15639	\N	\N	145	16248	t
16253	DIRECT	3	\N	15738	\N	144	\N	\N
11164	DIRECT	1	\N	\N	11046	145	\N	\N
11165	INDIRECT	1	\N	\N	11047	145	11164	t
11166	INDIRECT	1	11336	\N	\N	145	11164	t
11167	INDIRECT	1	\N	\N	11048	145	11164	t
11168	INDIRECT	1	11337	\N	\N	145	11164	t
16254	INDIRECT	3	15640	\N	\N	144	16253	t
16255	DIRECT	3	\N	15739	\N	144	\N	\N
16256	INDIRECT	3	15641	\N	\N	144	16255	t
16257	DIRECT	3	\N	15740	\N	144	\N	\N
16258	INDIRECT	3	15642	\N	\N	144	16257	t
16259	DIRECT	3	\N	15741	\N	143	\N	\N
16260	INDIRECT	3	\N	15742	\N	143	16259	t
16261	INDIRECT	3	15643	\N	\N	143	16259	t
2985	DIRECT	12	\N	1911	\N	145	\N	\N
2986	INDIRECT	12	\N	1912	\N	145	2985	t
2988	INDIRECT	12	\N	1913	\N	145	2985	t
2942	DIRECT	13	\N	1915	\N	144	\N	\N
2944	DIRECT	13	\N	1916	\N	144	\N	\N
2946	DIRECT	13	\N	1917	\N	144	\N	\N
2949	INDIRECT	13	\N	2323	\N	143	2948	t
2950	INDIRECT	13	2289	\N	\N	143	2948	t
2951	INDIRECT	13	\N	2324	\N	143	2948	t
2952	INDIRECT	14	2290	\N	\N	143	2948	t
2953	INDIRECT	13	\N	2325	\N	143	2948	t
16262	INDIRECT	3	\N	15743	\N	143	16259	t
16263	INDIRECT	3	15644	\N	\N	143	16259	t
16264	INDIRECT	3	\N	15744	\N	143	16259	t
16265	INDIRECT	3	15645	\N	\N	143	16259	t
16320	DIRECT	2	\N	20832	\N	145	\N	\N
16321	INDIRECT	2	\N	20833	\N	145	16320	t
16322	INDIRECT	2	21124	\N	\N	145	16320	t
16323	INDIRECT	2	\N	20834	\N	145	16320	t
16324	INDIRECT	2	21125	\N	\N	145	16320	t
16325	DIRECT	2	\N	20836	\N	144	\N	\N
16326	INDIRECT	2	21126	\N	\N	144	16325	t
16327	DIRECT	2	\N	20837	\N	144	\N	\N
16328	INDIRECT	2	21127	\N	\N	144	16327	t
16329	DIRECT	2	\N	20838	\N	144	\N	\N
16330	INDIRECT	2	21128	\N	\N	144	16329	t
16331	DIRECT	2	\N	20839	\N	143	\N	\N
16332	INDIRECT	2	\N	20840	\N	143	16331	t
16333	INDIRECT	2	21129	\N	\N	143	16331	t
16334	INDIRECT	2	\N	20841	\N	143	16331	t
16335	INDIRECT	2	21130	\N	\N	143	16331	t
16336	INDIRECT	2	\N	20842	\N	143	16331	t
16337	INDIRECT	2	21131	\N	\N	143	16331	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, code, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
24240	2	75ec9874-4837-4a5d-a29d-1a4fcb8f3239	2010-09-08 00:00:00	\N	f	144	19799
1718	9	e9dd7d02-7679-4078-b71b-78467f3901ee	2010-10-01 00:00:00	\N	f	145	1516
1717	9	48b220ff-07f3-48d2-a367-c827c4057f6b	2010-10-01 00:00:00	\N	f	144	1516
1720	13	ffb86d67-6da1-4619-b4db-39ce88c26652	2010-09-01 00:00:00	\N	f	145	1518
1719	13	a7b1f6d5-84b5-435e-8178-11fc507ee737	2010-09-01 00:00:00	\N	f	143	1518
1721	9	ce34b811-2522-4b1a-905e-96a22315766d	2010-09-01 00:00:00	\N	f	144	1520
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, code, name, predefinedtypeinternalname, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, generatecode, resource) FROM stdin;
16	1	f8bb7667-cdf3-44e4-a25c-9ac0cfc094cd	Tipo de traballo	\N	\N	t	f	t	t	0
1	18	b9f31052-3bba-447f-b981-e2602b488ff1	LEAVE	LEAVE	Leave	f	f	t	f	1
2	13	7872c9d3-ffbd-4778-801b-f2c2fc8f7e3f	CATEGORY	CATEGORY	Professional category	t	t	t	f	1
3	11	5602f200-522f-4209-aa6b-f901de23d9f3	TRAINING	TRAINING	Training courses and labor training	t	t	t	f	1
4	9	0e4dcc2b-24be-4ea1-9057-89e2414f5236	JOB	JOB	Job	t	t	t	f	1
5	7	03c2ba9d-928d-4c4c-9a9e-8ae11b01244a	WORK_RELATIONSHIP	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	f	1
6	1	bd43f311-ece0-4dae-8f7c-4e1e4aaae80e	LOCATION_GROUP	LOCATION_GROUP	Location where the resource work	t	f	t	f	0
17	1	5393d112-b350-4f1e-b308-dda9fb35f1a2	Capacitación	\N	\N	t	f	t	t	0
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, duration, consolidated, day, resource_id, specific_container_id, generic_container_id, derived_container_id) FROM stdin;
8366	SPECIFIC_DAY	6	0	f	2010-12-06	1516	3232	\N	\N
8422	SPECIFIC_DAY	6	18000	f	2010-11-02	1516	3232	\N	\N
8439	SPECIFIC_DAY	6	0	f	2010-10-16	1516	3232	\N	\N
24546	SPECIFIC_DAY	0	28800	f	2010-09-13	1516	20521	\N	\N
24547	SPECIFIC_DAY	0	0	f	2010-09-26	1516	20521	\N	\N
24548	SPECIFIC_DAY	0	28800	f	2010-10-12	1516	20521	\N	\N
24549	SPECIFIC_DAY	0	14400	f	2010-09-24	1516	20521	\N	\N
24550	SPECIFIC_DAY	0	28800	f	2010-09-22	1516	20521	\N	\N
19782	SPECIFIC_DAY	4	28800	f	2010-10-19	19797	20503	\N	\N
19766	SPECIFIC_DAY	4	28800	f	2010-10-01	19797	20503	\N	\N
19777	SPECIFIC_DAY	4	28800	f	2010-09-22	19797	20503	\N	\N
19753	SPECIFIC_DAY	4	28800	f	2010-09-30	19797	20503	\N	\N
19783	SPECIFIC_DAY	4	0	f	2010-10-10	19797	20503	\N	\N
19767	SPECIFIC_DAY	4	0	f	2010-09-12	19797	20503	\N	\N
19774	SPECIFIC_DAY	4	28800	f	2010-10-20	19797	20503	\N	\N
24551	SPECIFIC_DAY	0	28800	f	2010-09-15	1516	20521	\N	\N
24552	SPECIFIC_DAY	0	14400	f	2010-10-08	1516	20521	\N	\N
24553	SPECIFIC_DAY	0	0	f	2010-10-16	1516	20521	\N	\N
24554	SPECIFIC_DAY	0	28800	f	2010-10-14	1516	20521	\N	\N
24555	SPECIFIC_DAY	0	28800	f	2010-09-28	1516	20521	\N	\N
24556	SPECIFIC_DAY	0	0	f	2010-10-02	1516	20521	\N	\N
24557	SPECIFIC_DAY	0	28800	f	2010-09-20	1516	20521	\N	\N
24558	SPECIFIC_DAY	0	0	f	2010-09-11	1516	20521	\N	\N
24559	SPECIFIC_DAY	0	28800	f	2010-10-07	1516	20521	\N	\N
24560	SPECIFIC_DAY	0	14400	f	2010-10-01	1516	20521	\N	\N
24561	SPECIFIC_DAY	0	28800	f	2010-09-16	1516	20521	\N	\N
24562	SPECIFIC_DAY	0	28800	f	2010-09-23	1516	20521	\N	\N
24563	SPECIFIC_DAY	0	28800	f	2010-09-27	1516	20521	\N	\N
24564	SPECIFIC_DAY	0	0	f	2010-09-25	1516	20521	\N	\N
24565	SPECIFIC_DAY	0	28800	f	2010-09-21	1516	20521	\N	\N
24566	SPECIFIC_DAY	0	14400	f	2010-09-17	1516	20521	\N	\N
24567	SPECIFIC_DAY	0	14400	f	2010-10-15	1516	20521	\N	\N
24568	SPECIFIC_DAY	0	0	f	2010-10-10	1516	20521	\N	\N
24569	SPECIFIC_DAY	0	28800	f	2010-10-11	1516	20521	\N	\N
24570	SPECIFIC_DAY	0	0	f	2010-10-03	1516	20521	\N	\N
24571	SPECIFIC_DAY	0	28800	f	2010-10-06	1516	20521	\N	\N
24572	SPECIFIC_DAY	0	0	f	2010-10-09	1516	20521	\N	\N
24573	SPECIFIC_DAY	0	28800	f	2010-10-18	1516	20521	\N	\N
24574	SPECIFIC_DAY	0	0	f	2010-09-12	1516	20521	\N	\N
24575	SPECIFIC_DAY	0	28800	f	2010-10-04	1516	20521	\N	\N
24576	SPECIFIC_DAY	0	0	f	2010-09-18	1516	20521	\N	\N
24577	SPECIFIC_DAY	0	28800	f	2010-09-30	1516	20521	\N	\N
24578	SPECIFIC_DAY	0	28800	f	2010-09-09	1516	20521	\N	\N
24579	SPECIFIC_DAY	0	28800	f	2010-09-14	1516	20521	\N	\N
24580	SPECIFIC_DAY	0	0	f	2010-09-19	1516	20521	\N	\N
24581	SPECIFIC_DAY	0	28800	f	2010-10-05	1516	20521	\N	\N
24582	SPECIFIC_DAY	0	0	f	2010-10-17	1516	20521	\N	\N
24583	SPECIFIC_DAY	0	28800	f	2010-09-29	1516	20521	\N	\N
24584	SPECIFIC_DAY	0	14400	f	2010-09-10	1516	20521	\N	\N
24585	SPECIFIC_DAY	0	0	f	2010-09-08	1516	20521	\N	\N
24586	SPECIFIC_DAY	0	28800	f	2010-10-13	1516	20521	\N	\N
24587	GENERIC_DAY	0	50400	f	2010-09-16	19799	\N	21238	\N
24588	GENERIC_DAY	0	50400	f	2010-09-23	19799	\N	21238	\N
24589	GENERIC_DAY	0	0	f	2010-09-16	1520	\N	21238	\N
24590	GENERIC_DAY	0	0	f	2010-09-19	1520	\N	21238	\N
24591	GENERIC_DAY	0	0	f	2010-09-25	19799	\N	21238	\N
24592	GENERIC_DAY	0	50400	f	2010-09-22	19799	\N	21238	\N
24593	GENERIC_DAY	0	0	f	2010-09-21	1520	\N	21238	\N
24594	GENERIC_DAY	0	0	f	2010-09-13	1520	\N	21238	\N
24595	GENERIC_DAY	0	0	f	2010-09-12	1520	\N	21238	\N
24596	GENERIC_DAY	0	0	f	2010-09-17	1520	\N	21238	\N
24597	GENERIC_DAY	0	0	f	2010-09-18	19799	\N	21238	\N
24598	GENERIC_DAY	0	0	f	2010-09-19	19799	\N	21238	\N
24599	GENERIC_DAY	0	0	f	2010-09-26	1520	\N	21238	\N
24600	GENERIC_DAY	0	50400	f	2010-09-20	19799	\N	21238	\N
24601	GENERIC_DAY	0	0	f	2010-09-11	19799	\N	21238	\N
24602	GENERIC_DAY	0	50400	f	2010-09-24	19799	\N	21238	\N
24603	GENERIC_DAY	0	0	f	2010-09-22	1520	\N	21238	\N
24604	GENERIC_DAY	0	50400	f	2010-09-21	19799	\N	21238	\N
24605	GENERIC_DAY	0	25200	f	2010-09-08	19799	\N	21238	\N
24606	GENERIC_DAY	0	0	f	2010-09-24	1520	\N	21238	\N
24607	GENERIC_DAY	0	50400	f	2010-09-14	19799	\N	21238	\N
24608	GENERIC_DAY	0	0	f	2010-09-14	1520	\N	21238	\N
24609	GENERIC_DAY	0	0	f	2010-09-11	1520	\N	21238	\N
24610	GENERIC_DAY	0	0	f	2010-09-26	19799	\N	21238	\N
24611	GENERIC_DAY	0	0	f	2010-09-12	19799	\N	21238	\N
24612	GENERIC_DAY	0	50400	f	2010-09-10	19799	\N	21238	\N
24613	GENERIC_DAY	0	39600	f	2010-09-27	19799	\N	21238	\N
24614	GENERIC_DAY	0	0	f	2010-09-15	1520	\N	21238	\N
24615	GENERIC_DAY	0	25200	f	2010-09-08	1520	\N	21238	\N
24616	GENERIC_DAY	0	14400	f	2010-09-28	19799	\N	21238	\N
24617	GENERIC_DAY	0	0	f	2010-09-20	1520	\N	21238	\N
24618	GENERIC_DAY	0	0	f	2010-09-25	1520	\N	21238	\N
24619	GENERIC_DAY	0	0	f	2010-09-09	1520	\N	21238	\N
24620	GENERIC_DAY	0	0	f	2010-09-10	1520	\N	21238	\N
24621	GENERIC_DAY	0	10800	f	2010-09-27	1520	\N	21238	\N
24622	GENERIC_DAY	0	0	f	2010-09-18	1520	\N	21238	\N
24623	GENERIC_DAY	0	50400	f	2010-09-17	19799	\N	21238	\N
24624	GENERIC_DAY	0	50400	f	2010-09-15	19799	\N	21238	\N
24625	GENERIC_DAY	0	50400	f	2010-09-09	19799	\N	21238	\N
24626	GENERIC_DAY	0	0	f	2010-09-23	1520	\N	21238	\N
24627	GENERIC_DAY	0	50400	f	2010-09-13	19799	\N	21238	\N
24628	GENERIC_DAY	0	0	f	2010-09-28	1520	\N	21238	\N
19794	SPECIFIC_DAY	4	0	f	2010-10-09	19797	20503	\N	\N
19793	SPECIFIC_DAY	4	28800	f	2010-10-12	19797	20503	\N	\N
7223	GENERIC_DAY	8	21600	f	2010-10-05	1520	\N	3454	\N
7254	GENERIC_DAY	8	0	f	2010-10-17	1516	\N	3454	\N
7237	GENERIC_DAY	8	10800	f	2010-10-22	1516	\N	3454	\N
7243	GENERIC_DAY	8	0	f	2010-10-02	1520	\N	3454	\N
7216	GENERIC_DAY	8	0	f	2010-10-09	1520	\N	3454	\N
7238	GENERIC_DAY	8	0	f	2010-10-03	1520	\N	3454	\N
7256	GENERIC_DAY	8	0	f	2010-10-31	1520	\N	3454	\N
7236	GENERIC_DAY	8	0	f	2010-10-02	1516	\N	3454	\N
7260	GENERIC_DAY	8	0	f	2010-10-31	1516	\N	3454	\N
7242	GENERIC_DAY	8	18000	f	2010-10-15	1520	\N	3454	\N
7244	GENERIC_DAY	8	21600	f	2010-10-04	1520	\N	3454	\N
7228	GENERIC_DAY	8	7200	f	2010-10-13	1516	\N	3454	\N
7255	GENERIC_DAY	8	28800	f	2010-09-30	1520	\N	3454	\N
7252	GENERIC_DAY	8	21600	f	2010-11-02	1520	\N	3454	\N
7246	GENERIC_DAY	8	7200	f	2010-10-05	1516	\N	3454	\N
7261	GENERIC_DAY	8	21600	f	2010-10-28	1520	\N	3454	\N
7247	GENERIC_DAY	8	0	f	2010-10-23	1520	\N	3454	\N
7245	GENERIC_DAY	8	21600	f	2010-10-21	1520	\N	3454	\N
7251	GENERIC_DAY	8	21600	f	2010-10-27	1520	\N	3454	\N
7232	GENERIC_DAY	8	0	f	2010-10-30	1520	\N	3454	\N
7225	GENERIC_DAY	8	10800	f	2010-10-15	1516	\N	3454	\N
7263	GENERIC_DAY	8	21600	f	2010-10-12	1520	\N	3454	\N
7215	GENERIC_DAY	8	10800	f	2010-10-01	1516	\N	3454	\N
7248	GENERIC_DAY	8	7200	f	2010-10-20	1516	\N	3454	\N
7235	GENERIC_DAY	8	0	f	2010-10-23	1516	\N	3454	\N
7257	GENERIC_DAY	8	0	f	2010-10-03	1516	\N	3454	\N
7262	GENERIC_DAY	8	7200	f	2010-10-28	1516	\N	3454	\N
7222	GENERIC_DAY	8	0	f	2010-10-09	1516	\N	3454	\N
19785	SPECIFIC_DAY	4	28800	f	2010-10-21	19797	20503	\N	\N
19778	SPECIFIC_DAY	4	28800	f	2010-09-14	19797	20503	\N	\N
19752	SPECIFIC_DAY	4	28800	f	2010-09-09	19797	20503	\N	\N
19757	SPECIFIC_DAY	4	28800	f	2010-09-27	19797	20503	\N	\N
19759	SPECIFIC_DAY	4	0	f	2010-09-25	19797	20503	\N	\N
19771	SPECIFIC_DAY	4	28800	f	2010-10-11	19797	20503	\N	\N
19761	SPECIFIC_DAY	4	28800	f	2010-09-24	19797	20503	\N	\N
19789	SPECIFIC_DAY	4	0	f	2010-10-02	19797	20503	\N	\N
19781	SPECIFIC_DAY	4	28800	f	2010-09-10	19797	20503	\N	\N
8448	SPECIFIC_DAY	6	0	f	2010-12-04	1516	3232	\N	\N
8442	SPECIFIC_DAY	6	18000	f	2010-11-16	1516	3232	\N	\N
8441	SPECIFIC_DAY	6	0	f	2011-01-01	1516	3232	\N	\N
8433	SPECIFIC_DAY	6	18000	f	2010-11-11	1516	3232	\N	\N
8447	SPECIFIC_DAY	6	18000	f	2010-10-07	1516	3232	\N	\N
8472	SPECIFIC_DAY	6	18000	f	2010-12-30	1516	3232	\N	\N
8452	SPECIFIC_DAY	6	18000	f	2010-10-06	1516	3232	\N	\N
8438	SPECIFIC_DAY	6	0	f	2010-11-13	1516	3232	\N	\N
8440	SPECIFIC_DAY	6	18000	f	2010-12-13	1516	3232	\N	\N
8423	SPECIFIC_DAY	6	18000	f	2010-11-30	1516	3232	\N	\N
8397	SPECIFIC_DAY	6	18000	f	2011-01-05	1516	3232	\N	\N
8416	SPECIFIC_DAY	6	18000	f	2010-09-15	1516	3232	\N	\N
8384	SPECIFIC_DAY	6	0	f	2010-10-23	1516	3232	\N	\N
8368	SPECIFIC_DAY	6	0	f	2010-12-31	1516	3232	\N	\N
8346	SPECIFIC_DAY	6	18000	f	2011-01-03	1516	3232	\N	\N
8468	SPECIFIC_DAY	6	0	f	2011-01-15	1516	3232	\N	\N
8358	SPECIFIC_DAY	6	18000	f	2010-10-12	1516	3232	\N	\N
8465	SPECIFIC_DAY	6	0	f	2011-01-16	1516	3232	\N	\N
8385	SPECIFIC_DAY	6	18000	f	2011-01-17	1516	3232	\N	\N
8380	SPECIFIC_DAY	6	18000	f	2011-01-13	1516	3232	\N	\N
8455	SPECIFIC_DAY	6	0	f	2010-12-19	1516	3232	\N	\N
8443	SPECIFIC_DAY	6	0	f	2010-12-18	1516	3232	\N	\N
8435	SPECIFIC_DAY	6	18000	f	2010-09-21	1516	3232	\N	\N
8406	SPECIFIC_DAY	6	18000	f	2010-12-29	1516	3232	\N	\N
8399	SPECIFIC_DAY	6	18000	f	2011-01-18	1516	3232	\N	\N
8398	SPECIFIC_DAY	6	0	f	2010-11-20	1516	3232	\N	\N
8355	SPECIFIC_DAY	6	7200	f	2010-09-10	1516	3232	\N	\N
8445	SPECIFIC_DAY	6	18000	f	2010-11-15	1516	3232	\N	\N
8407	SPECIFIC_DAY	6	0	f	2010-09-11	1516	3232	\N	\N
8464	SPECIFIC_DAY	6	0	f	2010-09-19	1516	3232	\N	\N
8427	SPECIFIC_DAY	6	0	f	2010-10-02	1516	3232	\N	\N
8456	SPECIFIC_DAY	6	18000	f	2010-10-05	1516	3232	\N	\N
8345	SPECIFIC_DAY	6	0	f	2010-09-18	1516	3232	\N	\N
8401	SPECIFIC_DAY	6	18000	f	2010-11-22	1516	3232	\N	\N
8356	SPECIFIC_DAY	6	0	f	2010-09-26	1516	3232	\N	\N
8383	SPECIFIC_DAY	6	0	f	2010-11-06	1516	3232	\N	\N
8347	SPECIFIC_DAY	6	18000	f	2010-09-27	1516	3232	\N	\N
8418	SPECIFIC_DAY	6	0	f	2010-10-09	1516	3232	\N	\N
8419	SPECIFIC_DAY	6	18000	f	2010-10-18	1516	3232	\N	\N
8351	SPECIFIC_DAY	6	18000	f	2010-10-13	1516	3232	\N	\N
8437	SPECIFIC_DAY	6	0	f	2010-11-21	1516	3232	\N	\N
8388	SPECIFIC_DAY	6	7200	f	2011-01-14	1516	3232	\N	\N
8449	SPECIFIC_DAY	6	18000	f	2010-09-20	1516	3232	\N	\N
8392	SPECIFIC_DAY	6	18000	f	2010-09-13	1516	3232	\N	\N
8364	SPECIFIC_DAY	6	18000	f	2010-09-29	1516	3232	\N	\N
8463	SPECIFIC_DAY	6	7200	f	2010-11-05	1516	3232	\N	\N
8387	SPECIFIC_DAY	6	18000	f	2010-10-14	1516	3232	\N	\N
8348	SPECIFIC_DAY	6	7200	f	2010-12-03	1516	3232	\N	\N
8378	SPECIFIC_DAY	6	18000	f	2010-09-28	1516	3232	\N	\N
8446	SPECIFIC_DAY	6	7200	f	2010-09-17	1516	3232	\N	\N
8432	SPECIFIC_DAY	6	0	f	2010-12-25	1516	3232	\N	\N
8466	SPECIFIC_DAY	6	0	f	2010-12-26	1516	3232	\N	\N
8359	SPECIFIC_DAY	6	18000	f	2010-10-26	1516	3232	\N	\N
8444	SPECIFIC_DAY	6	18000	f	2011-01-04	1516	3232	\N	\N
8342	SPECIFIC_DAY	6	0	f	2010-11-14	1516	3232	\N	\N
8362	SPECIFIC_DAY	6	18000	f	2010-12-14	1516	3232	\N	\N
8352	SPECIFIC_DAY	6	18000	f	2010-12-01	1516	3232	\N	\N
8457	SPECIFIC_DAY	6	7200	f	2010-09-24	1516	3232	\N	\N
8371	SPECIFIC_DAY	6	7200	f	2010-11-12	1516	3232	\N	\N
8390	SPECIFIC_DAY	6	18000	f	2010-11-10	1516	3232	\N	\N
8461	SPECIFIC_DAY	6	0	f	2010-10-30	1516	3232	\N	\N
8411	SPECIFIC_DAY	6	18000	f	2010-11-29	1516	3232	\N	\N
8393	SPECIFIC_DAY	6	7200	f	2010-10-08	1516	3232	\N	\N
8425	SPECIFIC_DAY	6	18000	f	2010-11-09	1516	3232	\N	\N
8344	SPECIFIC_DAY	6	18000	f	2010-12-22	1516	3232	\N	\N
8473	SPECIFIC_DAY	6	18000	f	2010-09-14	1516	3232	\N	\N
8375	SPECIFIC_DAY	6	18000	f	2010-09-22	1516	3232	\N	\N
6703	GENERIC_DAY	8	7200	f	2010-11-08	1516	\N	3453	\N
7069	GENERIC_DAY	8	21600	f	2010-11-09	1520	\N	3453	\N
7117	GENERIC_DAY	8	7200	f	2010-12-15	1520	\N	3453	\N
7084	GENERIC_DAY	8	7200	f	2010-11-16	1516	\N	3453	\N
7111	GENERIC_DAY	8	7200	f	2010-12-01	1516	\N	3453	\N
6676	GENERIC_DAY	8	7200	f	2010-12-16	1516	\N	3453	\N
6722	GENERIC_DAY	8	21600	f	2010-11-08	1520	\N	3453	\N
7089	GENERIC_DAY	8	7200	f	2010-12-14	1516	\N	3453	\N
7057	GENERIC_DAY	8	7200	f	2010-11-18	1516	\N	3453	\N
7086	GENERIC_DAY	8	18000	f	2010-11-05	1520	\N	3453	\N
7080	GENERIC_DAY	8	21600	f	2010-11-17	1520	\N	3453	\N
6720	GENERIC_DAY	8	21600	f	2010-11-17	1520	\N	3453	\N
7091	GENERIC_DAY	8	7200	f	2010-11-29	1516	\N	3453	\N
6739	GENERIC_DAY	8	0	f	2010-11-20	1516	\N	3453	\N
7077	GENERIC_DAY	8	0	f	2010-11-07	1520	\N	3453	\N
6672	GENERIC_DAY	8	7200	f	2010-12-02	1516	\N	3453	\N
19770	SPECIFIC_DAY	4	28800	f	2010-10-04	19797	20503	\N	\N
19784	SPECIFIC_DAY	4	0	f	2010-09-26	19797	20503	\N	\N
19779	SPECIFIC_DAY	4	0	f	2010-09-11	19797	20503	\N	\N
19775	SPECIFIC_DAY	4	28800	f	2010-09-28	19797	20503	\N	\N
19786	SPECIFIC_DAY	4	28800	f	2010-10-06	19797	20503	\N	\N
19760	SPECIFIC_DAY	4	0	f	2010-10-03	19797	20503	\N	\N
19755	SPECIFIC_DAY	4	28800	f	2010-09-13	19797	20503	\N	\N
6734	GENERIC_DAY	8	7200	f	2010-11-22	1516	\N	3453	\N
7115	GENERIC_DAY	8	7200	f	2010-11-23	1516	\N	3453	\N
6727	GENERIC_DAY	8	21600	f	2010-11-03	1520	\N	3453	\N
6726	GENERIC_DAY	8	10800	f	2010-11-26	1516	\N	3453	\N
7065	GENERIC_DAY	8	7200	f	2010-12-02	1520	\N	3453	\N
8394	SPECIFIC_DAY	6	7200	f	2010-11-26	1516	3232	\N	\N
8377	SPECIFIC_DAY	6	18000	f	2010-12-09	1516	3232	\N	\N
8431	SPECIFIC_DAY	6	18000	f	2010-11-25	1516	3232	\N	\N
8382	SPECIFIC_DAY	6	7200	f	2010-10-15	1516	3232	\N	\N
8369	SPECIFIC_DAY	6	18000	f	2010-10-28	1516	3232	\N	\N
8367	SPECIFIC_DAY	6	18000	f	2010-12-02	1516	3232	\N	\N
8361	SPECIFIC_DAY	6	18000	f	2010-12-27	1516	3232	\N	\N
8372	SPECIFIC_DAY	6	0	f	2010-11-01	1516	3232	\N	\N
8379	SPECIFIC_DAY	6	18000	f	2011-01-06	1516	3232	\N	\N
8436	SPECIFIC_DAY	6	18000	f	2010-12-28	1516	3232	\N	\N
8460	SPECIFIC_DAY	6	7200	f	2010-11-19	1516	3232	\N	\N
8353	SPECIFIC_DAY	6	0	f	2010-09-12	1516	3232	\N	\N
8343	SPECIFIC_DAY	6	0	f	2010-09-25	1516	3232	\N	\N
8426	SPECIFIC_DAY	6	18000	f	2010-12-23	1516	3232	\N	\N
8434	SPECIFIC_DAY	6	14400	f	2011-01-19	1516	3232	\N	\N
8349	SPECIFIC_DAY	6	18000	f	2010-10-20	1516	3232	\N	\N
8357	SPECIFIC_DAY	6	0	f	2010-10-17	1516	3232	\N	\N
8403	SPECIFIC_DAY	6	0	f	2010-11-27	1516	3232	\N	\N
8409	SPECIFIC_DAY	6	18000	f	2010-10-11	1516	3232	\N	\N
8341	SPECIFIC_DAY	6	18000	f	2010-09-30	1516	3232	\N	\N
8381	SPECIFIC_DAY	6	18000	f	2010-11-18	1516	3232	\N	\N
8412	SPECIFIC_DAY	6	0	f	2011-01-08	1516	3232	\N	\N
8471	SPECIFIC_DAY	6	18000	f	2011-01-10	1516	3232	\N	\N
8454	SPECIFIC_DAY	6	18000	f	2011-01-11	1516	3232	\N	\N
19754	SPECIFIC_DAY	4	28800	f	2010-09-29	19797	20503	\N	\N
19751	SPECIFIC_DAY	4	28800	f	2010-09-15	19797	20503	\N	\N
19792	SPECIFIC_DAY	4	28800	f	2010-09-20	19797	20503	\N	\N
19764	SPECIFIC_DAY	4	7200	f	2010-10-22	19797	20503	\N	\N
19769	SPECIFIC_DAY	4	28800	f	2010-10-13	19797	20503	\N	\N
19788	SPECIFIC_DAY	4	28800	f	2010-09-21	19797	20503	\N	\N
19758	SPECIFIC_DAY	4	28800	f	2010-09-23	19797	20503	\N	\N
19772	SPECIFIC_DAY	4	28800	f	2010-10-14	19797	20503	\N	\N
19762	SPECIFIC_DAY	4	28800	f	2010-10-15	19797	20503	\N	\N
19790	SPECIFIC_DAY	4	28800	f	2010-10-08	19797	20503	\N	\N
19756	SPECIFIC_DAY	4	0	f	2010-10-17	19797	20503	\N	\N
19791	SPECIFIC_DAY	4	28800	f	2010-10-18	19797	20503	\N	\N
19776	SPECIFIC_DAY	4	28800	f	2010-10-05	19797	20503	\N	\N
19780	SPECIFIC_DAY	4	28800	f	2010-10-07	19797	20503	\N	\N
19765	SPECIFIC_DAY	4	28800	f	2010-09-17	19797	20503	\N	\N
19768	SPECIFIC_DAY	4	0	f	2010-09-19	19797	20503	\N	\N
19763	SPECIFIC_DAY	4	0	f	2010-10-16	19797	20503	\N	\N
19787	SPECIFIC_DAY	4	28800	f	2010-09-16	19797	20503	\N	\N
19773	SPECIFIC_DAY	4	0	f	2010-09-18	19797	20503	\N	\N
7092	GENERIC_DAY	8	7200	f	2010-11-11	1516	\N	3453	\N
7085	GENERIC_DAY	8	10800	f	2010-11-12	1516	\N	3453	\N
7067	GENERIC_DAY	8	7200	f	2010-12-16	1516	\N	3453	\N
6729	GENERIC_DAY	8	10800	f	2010-11-12	1516	\N	3453	\N
6736	GENERIC_DAY	8	7200	f	2010-11-04	1516	\N	3453	\N
7103	GENERIC_DAY	8	7200	f	2010-12-15	1516	\N	3453	\N
7130	GENERIC_DAY	8	7200	f	2010-12-03	1520	\N	3453	\N
6689	GENERIC_DAY	8	7200	f	2010-12-13	1520	\N	3453	\N
6699	GENERIC_DAY	8	7200	f	2010-12-14	1516	\N	3453	\N
6707	GENERIC_DAY	8	21600	f	2010-11-16	1520	\N	3453	\N
6716	GENERIC_DAY	8	21600	f	2010-11-23	1520	\N	3453	\N
6717	GENERIC_DAY	8	7200	f	2010-12-01	1520	\N	3453	\N
7129	GENERIC_DAY	8	18000	f	2010-11-26	1520	\N	3453	\N
6677	GENERIC_DAY	8	7200	f	2010-11-25	1516	\N	3453	\N
6691	GENERIC_DAY	8	0	f	2010-11-21	1516	\N	3453	\N
7088	GENERIC_DAY	8	7200	f	2010-11-10	1516	\N	3453	\N
6708	GENERIC_DAY	8	18000	f	2010-11-12	1520	\N	3453	\N
6723	GENERIC_DAY	8	10800	f	2010-11-19	1516	\N	3453	\N
7113	GENERIC_DAY	8	7200	f	2010-12-14	1520	\N	3453	\N
6733	GENERIC_DAY	8	21600	f	2010-11-25	1520	\N	3453	\N
6698	GENERIC_DAY	8	0	f	2010-11-07	1520	\N	3453	\N
6683	GENERIC_DAY	8	7200	f	2010-11-23	1516	\N	3453	\N
7100	GENERIC_DAY	8	21600	f	2010-11-25	1520	\N	3453	\N
6715	GENERIC_DAY	8	18000	f	2010-11-19	1520	\N	3453	\N
7058	GENERIC_DAY	8	21600	f	2010-11-16	1520	\N	3453	\N
7094	GENERIC_DAY	8	21600	f	2010-11-08	1520	\N	3453	\N
7060	GENERIC_DAY	8	0	f	2010-11-20	1516	\N	3453	\N
7098	GENERIC_DAY	8	7200	f	2010-12-13	1516	\N	3453	\N
6711	GENERIC_DAY	8	0	f	2010-11-14	1520	\N	3453	\N
6666	GENERIC_DAY	8	0	f	2010-11-14	1516	\N	3453	\N
7062	GENERIC_DAY	8	7200	f	2010-11-24	1516	\N	3453	\N
6695	GENERIC_DAY	8	10800	f	2010-11-05	1516	\N	3453	\N
7116	GENERIC_DAY	8	0	f	2010-11-21	1520	\N	3453	\N
7082	GENERIC_DAY	8	21600	f	2010-11-22	1520	\N	3453	\N
7059	GENERIC_DAY	8	0	f	2010-11-14	1520	\N	3453	\N
6713	GENERIC_DAY	8	7200	f	2010-12-02	1520	\N	3453	\N
6735	GENERIC_DAY	8	21600	f	2010-11-04	1520	\N	3453	\N
6673	GENERIC_DAY	8	14400	f	2010-12-09	1516	\N	3453	\N
6714	GENERIC_DAY	8	21600	f	2010-11-22	1520	\N	3453	\N
6674	GENERIC_DAY	8	7200	f	2010-12-15	1520	\N	3453	\N
7127	GENERIC_DAY	8	0	f	2010-11-13	1516	\N	3453	\N
7258	GENERIC_DAY	8	18000	f	2010-10-22	1520	\N	3454	\N
7200	GENERIC_DAY	8	21600	f	2010-10-13	1520	\N	3454	\N
7210	GENERIC_DAY	8	7200	f	2010-10-27	1516	\N	3454	\N
6775	GENERIC_DAY	8	28800	f	2010-09-30	1520	\N	3454	\N
6796	GENERIC_DAY	8	7200	f	2010-10-13	1516	\N	3454	\N
7249	GENERIC_DAY	8	21600	f	2010-10-18	1520	\N	3454	\N
7198	GENERIC_DAY	8	0	f	2010-10-16	1520	\N	3454	\N
6770	GENERIC_DAY	8	7200	f	2010-10-07	1516	\N	3454	\N
7201	GENERIC_DAY	8	28800	f	2010-09-28	1520	\N	3454	\N
6799	GENERIC_DAY	8	21600	f	2010-10-13	1520	\N	3454	\N
6751	GENERIC_DAY	8	0	f	2010-10-31	1516	\N	3454	\N
7211	GENERIC_DAY	8	7200	f	2010-10-11	1516	\N	3454	\N
6780	GENERIC_DAY	8	18000	f	2010-10-08	1520	\N	3454	\N
6794	GENERIC_DAY	8	10800	f	2010-10-01	1516	\N	3454	\N
7241	GENERIC_DAY	8	18000	f	2010-10-01	1520	\N	3454	\N
6766	GENERIC_DAY	8	7200	f	2010-10-27	1516	\N	3454	\N
6696	GENERIC_DAY	8	18000	f	2010-11-26	1520	\N	3453	\N
7096	GENERIC_DAY	8	7200	f	2010-12-01	1520	\N	3453	\N
7093	GENERIC_DAY	8	0	f	2010-11-28	1520	\N	3453	\N
6694	GENERIC_DAY	8	7200	f	2010-12-13	1516	\N	3453	\N
7081	GENERIC_DAY	8	7200	f	2010-12-02	1516	\N	3453	\N
6732	GENERIC_DAY	8	0	f	2010-11-28	1520	\N	3453	\N
6669	GENERIC_DAY	8	0	f	2010-11-06	1516	\N	3453	\N
6709	GENERIC_DAY	8	14400	f	2010-12-07	1520	\N	3453	\N
6685	GENERIC_DAY	8	7200	f	2010-11-29	1516	\N	3453	\N
7073	GENERIC_DAY	8	7200	f	2010-11-29	1520	\N	3453	\N
6738	GENERIC_DAY	8	18000	f	2010-11-05	1520	\N	3453	\N
6675	GENERIC_DAY	8	7200	f	2010-12-16	1520	\N	3453	\N
7076	GENERIC_DAY	8	0	f	2010-11-07	1516	\N	3453	\N
6687	GENERIC_DAY	8	0	f	2010-11-27	1516	\N	3453	\N
6705	GENERIC_DAY	8	0	f	2010-11-07	1516	\N	3453	\N
6682	GENERIC_DAY	8	7200	f	2010-11-15	1516	\N	3453	\N
6702	GENERIC_DAY	8	7200	f	2010-12-15	1516	\N	3453	\N
6680	GENERIC_DAY	8	0	f	2010-11-27	1520	\N	3453	\N
6684	GENERIC_DAY	8	21600	f	2010-11-09	1520	\N	3453	\N
7056	GENERIC_DAY	8	7200	f	2010-11-17	1516	\N	3453	\N
7063	GENERIC_DAY	8	21600	f	2010-11-10	1520	\N	3453	\N
7107	GENERIC_DAY	8	0	f	2010-11-20	1520	\N	3453	\N
7108	GENERIC_DAY	8	7200	f	2010-11-04	1516	\N	3453	\N
7078	GENERIC_DAY	8	21600	f	2010-11-23	1520	\N	3453	\N
6700	GENERIC_DAY	8	7200	f	2010-12-01	1516	\N	3453	\N
6678	GENERIC_DAY	8	0	f	2010-11-21	1520	\N	3453	\N
6710	GENERIC_DAY	8	7200	f	2010-11-17	1516	\N	3453	\N
7095	GENERIC_DAY	8	7200	f	2010-11-08	1516	\N	3453	\N
7083	GENERIC_DAY	8	7200	f	2010-12-13	1520	\N	3453	\N
6789	GENERIC_DAY	8	0	f	2010-10-16	1516	\N	3454	\N
6760	GENERIC_DAY	8	0	f	2010-10-09	1516	\N	3454	\N
7217	GENERIC_DAY	8	10800	f	2010-10-29	1516	\N	3454	\N
7203	GENERIC_DAY	8	7200	f	2010-10-19	1516	\N	3454	\N
6784	GENERIC_DAY	8	18000	f	2010-10-01	1520	\N	3454	\N
7202	GENERIC_DAY	8	7200	f	2010-10-25	1516	\N	3454	\N
7229	GENERIC_DAY	8	0	f	2010-10-16	1516	\N	3454	\N
6759	GENERIC_DAY	8	7200	f	2010-10-19	1516	\N	3454	\N
7219	GENERIC_DAY	8	18000	f	2010-10-08	1520	\N	3454	\N
7231	GENERIC_DAY	8	0	f	2010-10-30	1516	\N	3454	\N
7205	GENERIC_DAY	8	0	f	2010-10-24	1520	\N	3454	\N
6745	GENERIC_DAY	8	7200	f	2010-10-25	1516	\N	3454	\N
7212	GENERIC_DAY	8	0	f	2010-10-10	1516	\N	3454	\N
6787	GENERIC_DAY	8	28800	f	2010-09-29	1520	\N	3454	\N
6765	GENERIC_DAY	8	7200	f	2010-10-14	1516	\N	3454	\N
6771	GENERIC_DAY	8	0	f	2010-10-10	1520	\N	3454	\N
7204	GENERIC_DAY	8	28800	f	2010-09-29	1520	\N	3454	\N
7209	GENERIC_DAY	8	21600	f	2010-10-26	1520	\N	3454	\N
6772	GENERIC_DAY	8	21600	f	2010-10-20	1520	\N	3454	\N
7207	GENERIC_DAY	8	7200	f	2010-10-18	1516	\N	3454	\N
7226	GENERIC_DAY	8	21600	f	2010-10-14	1520	\N	3454	\N
7206	GENERIC_DAY	8	7200	f	2010-10-21	1516	\N	3454	\N
6742	GENERIC_DAY	8	7200	f	2010-10-04	1516	\N	3454	\N
6748	GENERIC_DAY	8	10800	f	2010-10-08	1516	\N	3454	\N
7218	GENERIC_DAY	8	7200	f	2010-10-07	1516	\N	3454	\N
6776	GENERIC_DAY	8	21600	f	2010-10-04	1520	\N	3454	\N
6761	GENERIC_DAY	8	0	f	2010-10-24	1520	\N	3454	\N
7199	GENERIC_DAY	8	7200	f	2010-10-04	1516	\N	3454	\N
7259	GENERIC_DAY	8	0	f	2010-10-17	1520	\N	3454	\N
7208	GENERIC_DAY	8	21600	f	2010-10-19	1520	\N	3454	\N
6778	GENERIC_DAY	8	0	f	2010-10-03	1516	\N	3454	\N
6755	GENERIC_DAY	8	21600	f	2010-10-28	1520	\N	3454	\N
6750	GENERIC_DAY	8	0	f	2010-10-30	1516	\N	3454	\N
6743	GENERIC_DAY	8	21600	f	2010-10-25	1520	\N	3454	\N
6788	GENERIC_DAY	8	7200	f	2010-11-02	1516	\N	3454	\N
6798	GENERIC_DAY	8	10800	f	2010-10-15	1516	\N	3454	\N
7213	GENERIC_DAY	8	21600	f	2010-10-25	1520	\N	3454	\N
6768	GENERIC_DAY	8	21600	f	2010-10-14	1520	\N	3454	\N
6747	GENERIC_DAY	8	7200	f	2010-10-20	1516	\N	3454	\N
7253	GENERIC_DAY	8	21600	f	2010-10-06	1520	\N	3454	\N
7292	GENERIC_DAY	8	28800	f	2010-09-10	1520	\N	3455	\N
7299	GENERIC_DAY	8	28800	f	2010-09-13	1520	\N	3455	\N
7293	GENERIC_DAY	8	28800	f	2010-09-23	1520	\N	3455	\N
7298	GENERIC_DAY	8	28800	f	2010-09-14	1520	\N	3455	\N
7290	GENERIC_DAY	8	28800	f	2010-09-24	1520	\N	3455	\N
7295	GENERIC_DAY	8	0	f	2010-09-11	1520	\N	3455	\N
7285	GENERIC_DAY	8	28800	f	2010-09-21	1520	\N	3455	\N
7287	GENERIC_DAY	8	0	f	2010-09-19	1520	\N	3455	\N
7301	GENERIC_DAY	8	28800	f	2010-09-22	1520	\N	3455	\N
7297	GENERIC_DAY	8	0	f	2010-09-26	1520	\N	3455	\N
7284	GENERIC_DAY	8	28800	f	2010-09-20	1520	\N	3455	\N
7296	GENERIC_DAY	8	28800	f	2010-09-15	1520	\N	3455	\N
7288	GENERIC_DAY	8	0	f	2010-09-12	1520	\N	3455	\N
7294	GENERIC_DAY	8	0	f	2010-09-25	1520	\N	3455	\N
7286	GENERIC_DAY	8	0	f	2010-09-18	1520	\N	3455	\N
7291	GENERIC_DAY	8	28800	f	2010-09-09	1520	\N	3455	\N
7302	GENERIC_DAY	8	28800	f	2010-09-17	1520	\N	3455	\N
7289	GENERIC_DAY	8	14400	f	2010-09-27	1520	\N	3455	\N
7300	GENERIC_DAY	8	28800	f	2010-09-16	1520	\N	3455	\N
8421	SPECIFIC_DAY	6	18000	f	2010-12-20	1516	3232	\N	\N
8469	SPECIFIC_DAY	6	0	f	2010-12-08	1516	3232	\N	\N
8453	SPECIFIC_DAY	6	18000	f	2010-10-25	1516	3232	\N	\N
8391	SPECIFIC_DAY	6	18000	f	2010-10-27	1516	3232	\N	\N
8350	SPECIFIC_DAY	6	18000	f	2010-11-04	1516	3232	\N	\N
8467	SPECIFIC_DAY	6	7200	f	2010-12-17	1516	3232	\N	\N
8429	SPECIFIC_DAY	6	7200	f	2011-01-07	1516	3232	\N	\N
8389	SPECIFIC_DAY	6	18000	f	2010-09-09	1516	3232	\N	\N
8410	SPECIFIC_DAY	6	18000	f	2011-01-12	1516	3232	\N	\N
8415	SPECIFIC_DAY	6	0	f	2010-12-11	1516	3232	\N	\N
8459	SPECIFIC_DAY	6	18000	f	2010-12-21	1516	3232	\N	\N
8451	SPECIFIC_DAY	6	18000	f	2010-10-19	1516	3232	\N	\N
8354	SPECIFIC_DAY	6	0	f	2010-10-10	1516	3232	\N	\N
8395	SPECIFIC_DAY	6	18000	f	2010-11-23	1516	3232	\N	\N
8458	SPECIFIC_DAY	6	18000	f	2010-09-23	1516	3232	\N	\N
8450	SPECIFIC_DAY	6	18000	f	2010-11-24	1516	3232	\N	\N
8373	SPECIFIC_DAY	6	7200	f	2010-10-22	1516	3232	\N	\N
6719	GENERIC_DAY	8	14400	f	2010-12-07	1516	\N	3453	\N
7072	GENERIC_DAY	8	7200	f	2010-12-03	1516	\N	3453	\N
6693	GENERIC_DAY	8	21600	f	2010-11-11	1520	\N	3453	\N
7102	GENERIC_DAY	8	21600	f	2010-11-03	1520	\N	3453	\N
7123	GENERIC_DAY	8	0	f	2010-11-13	1520	\N	3453	\N
7070	GENERIC_DAY	8	0	f	2010-11-28	1516	\N	3453	\N
7119	GENERIC_DAY	8	0	f	2010-11-06	1516	\N	3453	\N
7097	GENERIC_DAY	8	0	f	2010-11-21	1516	\N	3453	\N
7064	GENERIC_DAY	8	7200	f	2010-12-17	1520	\N	3453	\N
7125	GENERIC_DAY	8	21600	f	2010-11-18	1520	\N	3453	\N
7128	GENERIC_DAY	8	7200	f	2010-12-16	1520	\N	3453	\N
7105	GENERIC_DAY	8	14400	f	2010-12-09	1520	\N	3453	\N
7099	GENERIC_DAY	8	21600	f	2010-11-11	1520	\N	3453	\N
6670	GENERIC_DAY	8	0	f	2010-11-13	1516	\N	3453	\N
6692	GENERIC_DAY	8	7200	f	2010-11-10	1516	\N	3453	\N
19795	SPECIFIC_DAY	1	28800	f	2010-12-14	19797	20504	\N	\N
20705	SPECIFIC_DAY	1	28800	f	2010-11-03	19797	20504	\N	\N
20706	SPECIFIC_DAY	1	28800	f	2010-11-22	19797	20504	\N	\N
20707	SPECIFIC_DAY	1	28800	f	2010-10-28	19797	20504	\N	\N
20708	SPECIFIC_DAY	1	28800	f	2010-11-18	19797	20504	\N	\N
20709	SPECIFIC_DAY	1	28800	f	2010-11-05	19797	20504	\N	\N
20710	SPECIFIC_DAY	1	0	f	2010-11-28	19797	20504	\N	\N
20711	SPECIFIC_DAY	1	0	f	2010-10-31	19797	20504	\N	\N
20712	SPECIFIC_DAY	1	28800	f	2010-12-03	19797	20504	\N	\N
20713	SPECIFIC_DAY	1	28800	f	2010-11-02	19797	20504	\N	\N
7087	GENERIC_DAY	8	14400	f	2010-12-07	1520	\N	3453	\N
7114	GENERIC_DAY	8	7200	f	2010-12-17	1516	\N	3453	\N
7124	GENERIC_DAY	8	0	f	2010-11-06	1520	\N	3453	\N
7122	GENERIC_DAY	8	10800	f	2010-11-05	1516	\N	3453	\N
6671	GENERIC_DAY	8	7200	f	2010-11-29	1520	\N	3453	\N
6668	GENERIC_DAY	8	7200	f	2010-12-03	1520	\N	3453	\N
7079	GENERIC_DAY	8	7200	f	2010-11-30	1516	\N	3453	\N
7055	GENERIC_DAY	8	21600	f	2010-11-04	1520	\N	3453	\N
6681	GENERIC_DAY	8	7200	f	2010-12-03	1516	\N	3453	\N
6731	GENERIC_DAY	8	0	f	2010-11-06	1520	\N	3453	\N
7071	GENERIC_DAY	8	18000	f	2010-11-19	1520	\N	3453	\N
7121	GENERIC_DAY	8	10800	f	2010-11-26	1516	\N	3453	\N
7118	GENERIC_DAY	8	21600	f	2010-11-15	1520	\N	3453	\N
6704	GENERIC_DAY	8	0	f	2010-11-28	1516	\N	3453	\N
7120	GENERIC_DAY	8	14400	f	2010-12-07	1516	\N	3453	\N
7112	GENERIC_DAY	8	0	f	2010-11-14	1516	\N	3453	\N
7090	GENERIC_DAY	8	7200	f	2010-11-03	1516	\N	3453	\N
7101	GENERIC_DAY	8	21600	f	2010-11-24	1520	\N	3453	\N
6697	GENERIC_DAY	8	21600	f	2010-11-15	1520	\N	3453	\N
6730	GENERIC_DAY	8	7200	f	2010-12-14	1520	\N	3453	\N
20714	SPECIFIC_DAY	1	28800	f	2010-11-08	19797	20504	\N	\N
20715	SPECIFIC_DAY	1	28800	f	2010-12-10	19797	20504	\N	\N
20716	SPECIFIC_DAY	1	0	f	2010-11-07	19797	20504	\N	\N
20717	SPECIFIC_DAY	1	28800	f	2010-10-27	19797	20504	\N	\N
20718	SPECIFIC_DAY	1	0	f	2010-11-06	19797	20504	\N	\N
20719	SPECIFIC_DAY	1	0	f	2010-10-23	19797	20504	\N	\N
20720	SPECIFIC_DAY	1	28800	f	2010-12-02	19797	20504	\N	\N
20721	SPECIFIC_DAY	1	28800	f	2010-11-24	19797	20504	\N	\N
20722	SPECIFIC_DAY	1	28800	f	2010-11-23	19797	20504	\N	\N
20723	SPECIFIC_DAY	1	0	f	2010-12-12	19797	20504	\N	\N
20724	SPECIFIC_DAY	1	0	f	2010-12-06	19797	20504	\N	\N
20725	SPECIFIC_DAY	1	28800	f	2010-10-26	19797	20504	\N	\N
20726	SPECIFIC_DAY	1	0	f	2010-11-13	19797	20504	\N	\N
20727	SPECIFIC_DAY	1	0	f	2010-11-21	19797	20504	\N	\N
20728	SPECIFIC_DAY	1	28800	f	2010-11-15	19797	20504	\N	\N
20729	SPECIFIC_DAY	1	0	f	2010-10-24	19797	20504	\N	\N
6718	GENERIC_DAY	8	7200	f	2010-12-17	1520	\N	3453	\N
6686	GENERIC_DAY	8	7200	f	2010-11-18	1516	\N	3453	\N
7109	GENERIC_DAY	8	7200	f	2010-11-30	1520	\N	3453	\N
6679	GENERIC_DAY	8	21600	f	2010-11-18	1520	\N	3453	\N
7104	GENERIC_DAY	8	0	f	2010-11-27	1516	\N	3453	\N
7061	GENERIC_DAY	8	18000	f	2010-11-12	1520	\N	3453	\N
6712	GENERIC_DAY	8	7200	f	2010-11-30	1520	\N	3453	\N
7068	GENERIC_DAY	8	7200	f	2010-11-15	1516	\N	3453	\N
6706	GENERIC_DAY	8	7200	f	2010-11-24	1516	\N	3453	\N
6737	GENERIC_DAY	8	7200	f	2010-11-09	1516	\N	3453	\N
6741	GENERIC_DAY	8	14400	f	2010-12-09	1520	\N	3453	\N
6721	GENERIC_DAY	8	7200	f	2010-11-16	1516	\N	3453	\N
7106	GENERIC_DAY	8	7200	f	2010-11-22	1516	\N	3453	\N
6724	GENERIC_DAY	8	0	f	2010-11-13	1520	\N	3453	\N
7075	GENERIC_DAY	8	10800	f	2010-11-19	1516	\N	3453	\N
6667	GENERIC_DAY	8	7200	f	2010-11-03	1516	\N	3453	\N
7066	GENERIC_DAY	8	14400	f	2010-12-09	1516	\N	3453	\N
7126	GENERIC_DAY	8	7200	f	2010-11-25	1516	\N	3453	\N
6690	GENERIC_DAY	8	7200	f	2010-12-17	1516	\N	3453	\N
6740	GENERIC_DAY	8	7200	f	2010-11-30	1516	\N	3453	\N
7110	GENERIC_DAY	8	7200	f	2010-11-09	1516	\N	3453	\N
6728	GENERIC_DAY	8	7200	f	2010-11-11	1516	\N	3453	\N
6688	GENERIC_DAY	8	21600	f	2010-11-10	1520	\N	3453	\N
6725	GENERIC_DAY	8	0	f	2010-11-20	1520	\N	3453	\N
7074	GENERIC_DAY	8	0	f	2010-11-27	1520	\N	3453	\N
6701	GENERIC_DAY	8	21600	f	2010-11-24	1520	\N	3453	\N
6786	GENERIC_DAY	8	18000	f	2010-10-15	1520	\N	3454	\N
6753	GENERIC_DAY	8	18000	f	2010-10-29	1520	\N	3454	\N
6779	GENERIC_DAY	8	0	f	2010-10-17	1520	\N	3454	\N
6806	GENERIC_DAY	8	21600	f	2010-10-26	1520	\N	3454	\N
6756	GENERIC_DAY	8	18000	f	2010-10-22	1520	\N	3454	\N
6746	GENERIC_DAY	8	0	f	2010-10-10	1516	\N	3454	\N
7214	GENERIC_DAY	8	7200	f	2010-10-12	1516	\N	3454	\N
6754	GENERIC_DAY	8	21600	f	2010-10-11	1520	\N	3454	\N
7240	GENERIC_DAY	8	21600	f	2010-10-07	1520	\N	3454	\N
6758	GENERIC_DAY	8	0	f	2010-10-31	1520	\N	3454	\N
20730	SPECIFIC_DAY	1	28800	f	2010-11-25	19797	20504	\N	\N
20731	SPECIFIC_DAY	1	28800	f	2010-11-17	19797	20504	\N	\N
20732	SPECIFIC_DAY	1	28800	f	2010-11-29	19797	20504	\N	\N
20733	SPECIFIC_DAY	1	28800	f	2010-12-16	19797	20504	\N	\N
20734	SPECIFIC_DAY	1	28800	f	2010-11-11	19797	20504	\N	\N
20735	SPECIFIC_DAY	1	28800	f	2010-11-10	19797	20504	\N	\N
20736	SPECIFIC_DAY	1	28800	f	2010-11-30	19797	20504	\N	\N
6774	GENERIC_DAY	8	7200	f	2010-10-11	1516	\N	3454	\N
6762	GENERIC_DAY	8	0	f	2010-10-23	1520	\N	3454	\N
6804	GENERIC_DAY	8	7200	f	2010-10-28	1516	\N	3454	\N
6800	GENERIC_DAY	8	7200	f	2010-10-21	1516	\N	3454	\N
7239	GENERIC_DAY	8	21600	f	2010-10-11	1520	\N	3454	\N
6781	GENERIC_DAY	8	0	f	2010-10-03	1520	\N	3454	\N
7264	GENERIC_DAY	8	21600	f	2010-10-20	1520	\N	3454	\N
6757	GENERIC_DAY	8	10800	f	2010-10-29	1516	\N	3454	\N
6803	GENERIC_DAY	8	0	f	2010-10-02	1516	\N	3454	\N
7227	GENERIC_DAY	8	7200	f	2010-10-26	1516	\N	3454	\N
7224	GENERIC_DAY	8	0	f	2010-10-24	1516	\N	3454	\N
7230	GENERIC_DAY	8	7200	f	2010-10-14	1516	\N	3454	\N
6777	GENERIC_DAY	8	0	f	2010-10-02	1520	\N	3454	\N
7250	GENERIC_DAY	8	10800	f	2010-10-08	1516	\N	3454	\N
6752	GENERIC_DAY	8	21600	f	2010-10-19	1520	\N	3454	\N
6795	GENERIC_DAY	8	21600	f	2010-10-05	1520	\N	3454	\N
6805	GENERIC_DAY	8	0	f	2010-10-24	1516	\N	3454	\N
6808	GENERIC_DAY	8	28800	f	2010-09-28	1520	\N	3454	\N
6782	GENERIC_DAY	8	21600	f	2010-10-27	1520	\N	3454	\N
6790	GENERIC_DAY	8	21600	f	2010-10-06	1520	\N	3454	\N
7234	GENERIC_DAY	8	7200	f	2010-10-06	1516	\N	3454	\N
6802	GENERIC_DAY	8	7200	f	2010-10-06	1516	\N	3454	\N
6769	GENERIC_DAY	8	0	f	2010-10-09	1520	\N	3454	\N
6763	GENERIC_DAY	8	10800	f	2010-10-22	1516	\N	3454	\N
6785	GENERIC_DAY	8	7200	f	2010-10-26	1516	\N	3454	\N
20737	SPECIFIC_DAY	1	0	f	2010-12-04	19797	20504	\N	\N
20738	SPECIFIC_DAY	1	28800	f	2010-11-19	19797	20504	\N	\N
20739	SPECIFIC_DAY	1	0	f	2010-12-08	19797	20504	\N	\N
20740	SPECIFIC_DAY	1	0	f	2010-11-14	19797	20504	\N	\N
20741	SPECIFIC_DAY	1	28800	f	2010-11-16	19797	20504	\N	\N
20742	SPECIFIC_DAY	1	28800	f	2010-11-26	19797	20504	\N	\N
20743	SPECIFIC_DAY	1	0	f	2010-11-20	19797	20504	\N	\N
20744	SPECIFIC_DAY	1	28800	f	2010-11-12	19797	20504	\N	\N
20745	SPECIFIC_DAY	1	28800	f	2010-12-01	19797	20504	\N	\N
20746	SPECIFIC_DAY	1	28800	f	2010-12-07	19797	20504	\N	\N
20747	SPECIFIC_DAY	1	21600	f	2010-10-22	19797	20504	\N	\N
20748	SPECIFIC_DAY	1	28800	f	2010-10-29	19797	20504	\N	\N
20749	SPECIFIC_DAY	1	28800	f	2010-11-04	19797	20504	\N	\N
20750	SPECIFIC_DAY	1	28800	f	2010-12-13	19797	20504	\N	\N
20751	SPECIFIC_DAY	1	28800	f	2010-12-09	19797	20504	\N	\N
20752	SPECIFIC_DAY	1	28800	f	2010-11-09	19797	20504	\N	\N
20753	SPECIFIC_DAY	1	0	f	2010-11-01	19797	20504	\N	\N
20754	SPECIFIC_DAY	1	0	f	2010-11-27	19797	20504	\N	\N
20755	SPECIFIC_DAY	1	21600	f	2010-12-17	19797	20504	\N	\N
20756	SPECIFIC_DAY	1	28800	f	2010-10-25	19797	20504	\N	\N
20757	SPECIFIC_DAY	1	28800	f	2010-12-15	19797	20504	\N	\N
20758	SPECIFIC_DAY	1	0	f	2010-12-05	19797	20504	\N	\N
20759	SPECIFIC_DAY	1	0	f	2010-12-11	19797	20504	\N	\N
20760	SPECIFIC_DAY	1	0	f	2010-10-30	19797	20504	\N	\N
6797	GENERIC_DAY	8	21600	f	2010-10-18	1520	\N	3454	\N
6793	GENERIC_DAY	8	21600	f	2010-10-12	1520	\N	3454	\N
6801	GENERIC_DAY	8	7200	f	2010-10-05	1516	\N	3454	\N
6783	GENERIC_DAY	8	0	f	2010-10-17	1516	\N	3454	\N
6749	GENERIC_DAY	8	21600	f	2010-11-02	1520	\N	3454	\N
6764	GENERIC_DAY	8	0	f	2010-10-23	1516	\N	3454	\N
7220	GENERIC_DAY	8	0	f	2010-10-10	1520	\N	3454	\N
6767	GENERIC_DAY	8	0	f	2010-10-16	1520	\N	3454	\N
7221	GENERIC_DAY	8	18000	f	2010-10-29	1520	\N	3454	\N
6744	GENERIC_DAY	8	7200	f	2010-10-18	1516	\N	3454	\N
6791	GENERIC_DAY	8	7200	f	2010-10-12	1516	\N	3454	\N
6807	GENERIC_DAY	8	0	f	2010-10-30	1520	\N	3454	\N
6792	GENERIC_DAY	8	21600	f	2010-10-07	1520	\N	3454	\N
7233	GENERIC_DAY	8	7200	f	2010-11-02	1516	\N	3454	\N
6773	GENERIC_DAY	8	21600	f	2010-10-21	1520	\N	3454	\N
6819	GENERIC_DAY	8	0	f	2010-09-12	1520	\N	3455	\N
6821	GENERIC_DAY	8	28800	f	2010-09-23	1520	\N	3455	\N
6816	GENERIC_DAY	8	28800	f	2010-09-22	1520	\N	3455	\N
6817	GENERIC_DAY	8	28800	f	2010-09-15	1520	\N	3455	\N
6812	GENERIC_DAY	8	28800	f	2010-09-20	1520	\N	3455	\N
6825	GENERIC_DAY	8	28800	f	2010-09-14	1520	\N	3455	\N
6822	GENERIC_DAY	8	0	f	2010-09-11	1520	\N	3455	\N
6811	GENERIC_DAY	8	0	f	2010-09-18	1520	\N	3455	\N
6820	GENERIC_DAY	8	28800	f	2010-09-09	1520	\N	3455	\N
6815	GENERIC_DAY	8	28800	f	2010-09-17	1520	\N	3455	\N
6824	GENERIC_DAY	8	28800	f	2010-09-16	1520	\N	3455	\N
6826	GENERIC_DAY	8	28800	f	2010-09-24	1520	\N	3455	\N
6813	GENERIC_DAY	8	14400	f	2010-09-27	1520	\N	3455	\N
6809	GENERIC_DAY	8	0	f	2010-09-25	1520	\N	3455	\N
6810	GENERIC_DAY	8	28800	f	2010-09-13	1520	\N	3455	\N
6827	GENERIC_DAY	8	0	f	2010-09-26	1520	\N	3455	\N
6814	GENERIC_DAY	8	0	f	2010-09-19	1520	\N	3455	\N
6823	GENERIC_DAY	8	28800	f	2010-09-10	1520	\N	3455	\N
6818	GENERIC_DAY	8	28800	f	2010-09-21	1520	\N	3455	\N
8420	SPECIFIC_DAY	6	7200	f	2010-12-24	1516	3232	\N	\N
8376	SPECIFIC_DAY	6	0	f	2010-10-31	1516	3232	\N	\N
8360	SPECIFIC_DAY	6	0	f	2010-11-28	1516	3232	\N	\N
8462	SPECIFIC_DAY	6	7200	f	2010-12-10	1516	3232	\N	\N
8365	SPECIFIC_DAY	6	0	f	2011-01-09	1516	3232	\N	\N
8370	SPECIFIC_DAY	6	18000	f	2010-11-03	1516	3232	\N	\N
8428	SPECIFIC_DAY	6	18000	f	2010-10-21	1516	3232	\N	\N
8374	SPECIFIC_DAY	6	18000	f	2010-11-17	1516	3232	\N	\N
8363	SPECIFIC_DAY	6	18000	f	2010-11-08	1516	3232	\N	\N
8424	SPECIFIC_DAY	6	0	f	2010-11-07	1516	3232	\N	\N
8396	SPECIFIC_DAY	6	18000	f	2010-09-16	1516	3232	\N	\N
8408	SPECIFIC_DAY	6	0	f	2010-12-12	1516	3232	\N	\N
8417	SPECIFIC_DAY	6	18000	f	2010-12-15	1516	3232	\N	\N
8414	SPECIFIC_DAY	6	18000	f	2010-12-16	1516	3232	\N	\N
8404	SPECIFIC_DAY	6	7200	f	2010-10-01	1516	3232	\N	\N
8400	SPECIFIC_DAY	6	0	f	2010-12-05	1516	3232	\N	\N
8405	SPECIFIC_DAY	6	18000	f	2010-12-07	1516	3232	\N	\N
8413	SPECIFIC_DAY	6	0	f	2010-10-24	1516	3232	\N	\N
8402	SPECIFIC_DAY	6	7200	f	2010-10-29	1516	3232	\N	\N
8470	SPECIFIC_DAY	6	0	f	2010-10-03	1516	3232	\N	\N
8430	SPECIFIC_DAY	6	0	f	2011-01-02	1516	3232	\N	\N
8386	SPECIFIC_DAY	6	18000	f	2010-10-04	1516	3232	\N	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, queue_dependency, type) FROM stdin;
983054	15	2731	2735	\N	0
983057	16	2750	2734	\N	0
983058	15	2729	2728	\N	0
983059	15	2730	2729	\N	0
983055	16	2732	2734	\N	0
983056	17	2733	2732	20604	1
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: deriveddayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY deriveddayassignmentscontainer (id, version, derived_allocation_id, scenario) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
8989	Obvs	Ningunha
8990	Obvs	Problemas de acceso
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
8798	Incidencias	
8799	Incidencias	
8800	Incidencias	Problemas no ...
8801	Incidencias	Non houbo
8802	Incidencias	
8810	Incidencias	
8812	Incidencias	
8814	Incidencias	
8811	Incidencias	
8813	Incidencias	
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
9324	1918	100.00
2626	1911	100.00
5941	1915	15.00
5942	1916	10.00
2629	1917	5.00
9384	2325	100.00
16418	20832	100.00
16419	20836	15.00
16420	20837	10.00
16421	20838	5.00
16424	20839	100.00
16425	20842	100.00
23085	20881	100.00
23086	20881	10.00
16432	20875	100.00
16433	20879	100.00
16434	20880	100.00
16437	20882	100.00
16438	20883	100.00
16150	15734	100.00
16151	15738	15.00
16152	15739	10.00
16153	15740	5.00
16156	15741	100.00
16157	15744	100.00
9381	2352	100.00
\.


--
-- Data for Name: effortperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY effortperday (base_calendar_id, effort, day_id) FROM stdin;
606	28800	0
606	28800	1
606	28800	2
606	28800	3
606	28800	4
606	0	5
606	0	6
607	32400	0
607	32400	1
607	32400	2
607	32400	3
607	14400	4
608	14400	0
608	14400	1
608	14400	2
608	14400	3
\.


--
-- Data for Name: external_company; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY external_company (id, version, name, nif, client, subcontractor, interactswithapplications, appuri, ourcompanylogin, ourcompanypassword, companyuser) FROM stdin;
10605	1	Igalia	COMPANY_CODE	t	t	t	http://localhost:8080/navalplanner-webapp/	wswriter	wswriter	1114
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
3151
3152
3153
20348
\.


--
-- Data for Name: genericdayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY genericdayassignmentscontainer (id, version, resource_allocation_id, scenario) FROM stdin;
3453	12	3151	404
3454	12	3152	404
3455	12	3153	404
21238	1	20348	404
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, positionnumber) FROM stdin;
8585	Obvs	40	0
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
244
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, code, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
9696	1	790a9463-0558-413c-add3-c733d8e98c4d	17.00	2010-09-07	2010-12-31	8889	9595
9697	1	4d6f2920-58ec-4d18-92b2-5e717160a458	18.00	2011-01-01	\N	8889	9595
9698	1	3518227f-c683-4cd8-a56f-b866e0b1b8d3	15.00	2010-09-07	2010-12-31	8888	9595
9699	1	828e8e24-1cbb-4bb9-a27b-0aa63da628ff	16.00	2011-01-01	\N	8888	9595
9700	1	bdf96072-8689-4190-81ba-7d9f9475ed2c	17.00	2010-09-07	2010-12-31	8888	9596
9701	1	07965d92-f378-43af-a0cf-8c73ace6f00f	18.00	2011-01-01	2011-01-01	8888	9596
9702	1	c428afa2-b3ed-40df-b12b-ed15b58a5598	20.00	2010-09-07	2010-12-31	8889	9596
9703	1	34abe033-92aa-4790-bbfc-c9039ec11ff4	21.00	2011-01-01	2011-01-01	8889	9596
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, code, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line, order_line_template) FROM stdin;
15641	3	PREFIX-00005-00007-00001	WORKER	200	1.00	f	15739	\N
2287	21	PREFIX-00002-00007-00001	WORKER	200	1.00	f	1916	\N
2288	21	PREFIX-00002-00008-00001	WORKER	100	1.00	f	1917	\N
2289	21	PREFIX-00002-00009-00001	WORKER	300	1.00	f	2323	\N
2290	21	PREFIX-00002-00010-00001	WORKER	250	1.00	f	2324	\N
2291	21	PREFIX-00002-00011-00001	WORKER	200	1.00	f	2325	\N
11336	1	b808df95-72da-472e-b690-315593507e19	WORKER	100	1.00	f	\N	11047
11337	1	15d2828c-6cf8-4726-afa6-d62ee0fc6d09	WORKER	100	1.00	f	\N	11048
11338	1	75bef552-456a-47b7-8941-886e850e493e	WORKER	200	1.00	f	\N	11050
11339	1	34a47c36-e156-464f-a43c-8db45bba1dab	WORKER	200	1.00	f	\N	11051
11340	1	8b5ec20c-3b42-48e4-8cc9-2366c745b596	WORKER	100	1.00	f	\N	11052
11341	1	48647e3b-9af9-4770-b89e-4bcce9cc0855	WORKER	300	1.00	f	\N	11054
11342	1	73dbe8e7-c059-4722-a42b-8e6e86d9f23d	WORKER	250	1.00	f	\N	11055
11343	1	63da1840-4cbe-4496-903d-6adb2b9be917	WORKER	200	1.00	f	\N	11056
2302	4	PREFIX-00003-00004-00001	WORKER	0	1.00	f	2345	\N
2303	4	PREFIX-00003-00005-00001	WORKER	0	1.00	f	2346	\N
2304	4	PREFIX-00003-00006-00001	WORKER	0	1.00	f	2348	\N
2305	4	PREFIX-00003-00007-00001	WORKER	0	1.00	f	2349	\N
2306	4	PREFIX-00003-00003-00001	WORKER	0	1.00	f	2350	\N
15642	3	PREFIX-00005-00008-00001	WORKER	100	1.00	f	15740	\N
15643	3	PREFIX-00005-00009-00001	WORKER	300	1.00	f	15742	\N
15644	3	PREFIX-00005-00010-00001	WORKER	250	1.00	f	15743	\N
15645	3	PREFIX-00005-00011-00001	WORKER	200	1.00	f	15744	\N
2307	9	PREFIX-00004-00001-00001	WORKER	300	1.00	f	2352	\N
21153	6	PREFIX-00007-00006-00001	WORKER	200	1.00	f	20879	\N
21124	2	PREFIX-00006-00004-00001	WORKER	100	1.00	f	20833	\N
21125	2	PREFIX-00006-00005-00001	WORKER	100	1.00	f	20834	\N
21126	2	PREFIX-00006-00006-00001	WORKER	200	1.00	f	20836	\N
21127	2	PREFIX-00006-00007-00001	WORKER	200	1.00	f	20837	\N
21128	2	PREFIX-00006-00008-00001	WORKER	100	1.00	f	20838	\N
21129	2	PREFIX-00006-00009-00001	WORKER	300	1.00	f	20840	\N
21130	2	PREFIX-00006-00010-00001	WORKER	250	1.00	f	20841	\N
21131	2	PREFIX-00006-00011-00001	WORKER	200	1.00	f	20842	\N
15638	3	PREFIX-00005-00004-00001	WORKER	100	1.00	f	15735	\N
15639	3	PREFIX-00005-00005-00001	WORKER	100	1.00	f	15736	\N
15640	3	PREFIX-00005-00006-00001	WORKER	200	1.00	f	15738	\N
21154	6	PREFIX-00007-00007-00001	WORKER	200	1.00	f	20880	\N
21155	6	PREFIX-00007-00008-00001	WORKER	200	1.00	f	20882	\N
21156	6	PREFIX-00007-00009-00001	WORKER	200	1.00	f	20883	\N
21151	6	PREFIX-00007-00004-00001	WORKER	200	1.00	f	20876	\N
2284	21	PREFIX-00002-00004-00001	WORKER	100	1.00	f	1912	\N
2285	21	PREFIX-00002-00005-00001	WORKER	100	1.00	f	1913	\N
2286	21	PREFIX-00002-00006-00001	WORKER	200	1.00	f	1915	\N
21152	6	PREFIX-00007-00005-00001	WORKER	200	1.00	f	20877	\N
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
16155	15737
16154	15737
16159	15741
16158	15741
16365	15733
16364	15733
16363	15733
16362	15733
9383	2351
9382	2351
2631	1914
5943	1914
2637	1825
9387	1825
2638	1825
5944	1825
9386	1918
9385	1918
16422	20835
16423	20835
16426	20839
16427	20839
16428	20831
16429	20831
16430	20831
16431	20831
23087	20874
23088	20874
16435	20878
16436	20878
16440	20881
16439	20881
16442	20874
16441	20874
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, code, name, label_type_id) FROM stdin;
1414	1	799bf2fa-a61c-4c5f-ad36-2c30de009bc3	A Coruña	1313
1415	1	b27a9277-5dd2-424b-bf19-789fa2498a7c	Ferrol	1313
1416	1	510af141-2ebb-4203-9cee-da9a810acc24	Vigo	1313
1417	1	ad563bdb-dec3-42b3-8111-3879a574dfb3	Santiago	1313
1418	1	05f208c2-e039-41ac-83bd-298bee6d04c0	Fuentes	1314
1419	1	666aff83-2fd4-497e-94d8-a50f347e9eba	Bodegas	1314
1420	1	6f7d3f58-c0d8-4067-87fc-0c363870bafc	Casco	1314
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, code, name, generatecode) FROM stdin;
1313	1	d4ad1bcd-6e02-429e-8ad2-1bea70bae3af	Centro de custo	t
1314	1	682db6e8-e49d-4d2c-9071-2d41f32db79a	Zonas	t
\.


--
-- Data for Name: limiting_resource_queue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue (id, version, resource_id) FROM stdin;
20200	2	19797
\.


--
-- Data for Name: limiting_resource_queue_dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_dependency (id, type, origin_queue_element_id, destiny_queue_element_id) FROM stdin;
20604	0	20402	20403
\.


--
-- Data for Name: limiting_resource_queue_element; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_element (id, version, resource_allocation_id, limiting_resource_queue_id, earlier_start_date_because_of_gantt, earliest_end_date_because_of_gantt, creation_timestamp, start_date, start_hour, end_date, end_hour) FROM stdin;
20402	4	20301	20200	2010-09-09 00:00:00	2010-09-09 00:00:00	1283942659199	2010-09-09	0	2010-10-22	2
20403	3	20302	20200	2010-09-09 00:00:00	2010-09-09 00:00:00	1283944603357	2010-10-22	2	2010-12-17	6
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, positionnumber) FROM stdin;
8585	Incidencias	20	0
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, name, description) FROM stdin;
19797	Torno 20mm	Desc.
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
10000	2	t1	Tornillo 15mm	0.50	202	\N	9899
9999	2	t2	Tornillo 20mm	0.75	202	\N	9899
10001	1	t3	Tornillo 17mm	0.50	202	\N	9900
10002	1	t4	Tornillo 19mm	0.75	202	\N	9900
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, material_id, estimated_availability, status, order_element_id) FROM stdin;
15971	2	200	0.75	10002	\N	1	15742
15972	2	100	0.50	10000	\N	1	15743
10106	4	200	0.75	10002	2010-10-21 00:00:00	1	2323
10107	4	100	0.50	10000	2010-10-21 00:00:00	1	2324
15979	2	200	0.75	10002	\N	1	20840
15980	2	100	0.50	10000	\N	1	20841
\.


--
-- Data for Name: material_assigment_template; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment_template (id, version, units, unit_price, material_id, order_element_template_id) FROM stdin;
11419	1	200	0.75	10002	11054
11420	1	100	0.50	10000	11055
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, code, name, generatecode, parent_id) FROM stdin;
303	3	dfc2760d-afc3-42be-9019-58b1098412c6	Imported materials without category	f	\N
9898	2	58205a42-3e71-4484-8617-d62224aa8332	Tornillos	t	\N
9899	2	4ccaeb67-a00f-4647-a7a9-630149ea2ba1	Tornillos de bronce	t	9898
9900	2	3fe88b9e-660c-4314-981a-c601f9c9c22e	Tornillos de aceiro	t	9898
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled, lastconnectedscenario) FROM stdin;
1111	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f	\N
1112	3	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f	\N
1113	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f	\N
1114	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f	\N
16564	1	grupo1_permisos	07580e19beef5c894660f2e9cd02e3d3d7eed0e3ee78a94ecfba63ec57f97d1b0b2f479469a2b49bf383e566718826fbb8c805ad5343ae412664d19ff2959d20	grupo1_permisos@grupo1_permisos.com	f	\N
\.


--
-- Data for Name: order_authorization; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_authorization (id, order_authorization_subclass, version, authorizationtype, order_id, user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
\.


--
-- Data for Name: order_element_template_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_label (order_element_template_id, label_id) FROM stdin;
\.


--
-- Data for Name: order_element_template_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_quality_form (order_element_template_id, quality_form_id) FROM stdin;
11045	10302
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, dependenciesconstraintshavepriority, codeautogenerated, lastorderelementsequencecode, workbudget, materialsbudget, totalhours, customerreference, externalcode, state, customer, base_calendar_id) FROM stdin;
2343	\N	\N	t	7	0.00	0.00	0	\N	\N	0	\N	505
15733	\N	\N	t	11	0.00	0.00	1450	\N	\N	0	\N	505
2351	\N	\N	t	1	10000.00	0.00	300	code1	\N	1	10605	505
1825	\N	\N	t	11	0.00	0.00	1450	\N	\N	0	\N	505
20831	\N	\N	t	11	0.00	0.00	1450	\N	\N	0	\N	505
20874	\N	\N	t	9	0.00	0.00	1200	\N	\N	0	\N	505
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, description, code, initdate, deadline, lastadvancemeausurementforspreading, dirtylastadvancemeasurementforspreading, parent, template, externalcode, sum_charged_hours_id, positionincontainer) FROM stdin;
15733	3	Pedido grupo 2	\N	PREFIX-00005	2010-09-07 17:32:24.689	2011-01-19 00:00:00	0.00	f	\N	11045	\N	15834	\N
15734	3	Xestión	\N	PREFIX-00005-00001	\N	\N	0.00	f	15733	11046	\N	15835	0
15735	3	Reunión de traballadores	\N	PREFIX-00005-00004	\N	\N	0.00	f	15734	11047	\N	15836	0
15736	3	Reunión de clientes	\N	PREFIX-00005-00005	\N	\N	0.00	f	15734	11048	\N	15837	1
15737	3	Bloque 1	\N	PREFIX-00005-00002	\N	\N	0.00	f	15733	11049	\N	15838	1
15738	3	Repasar soldadura ocos	\N	PREFIX-00005-00006	\N	\N	0.00	f	15737	11050	\N	15839	0
1915	22	Repasar soldadura ocos	\N	PREFIX-00002-00006	\N	\N	0.33	f	1914	\N	\N	2016	0
1916	22	Soldar unións do chan	\N	PREFIX-00002-00007	\N	\N	0.30	f	1914	\N	\N	2017	1
1917	22	Soldar unións do teito	\N	PREFIX-00002-00008	\N	\N	0.40	f	1914	\N	\N	2018	2
2323	23	Cama e mesilla de camarote A	\N	PREFIX-00002-00009	\N	\N	0.00	f	1918	\N	\N	2424	0
2324	23	Teito de madeira de camarote A	\N	PREFIX-00002-00010	\N	\N	0.00	f	1918	\N	\N	2425	1
2325	25	Poñer escotillas camarote A	\N	PREFIX-00002-00011	\N	\N	0.30	t	1918	\N	\N	2426	2
2351	14	Contratación de escotillas	\N	PREFIX-00004	2011-01-17 00:00:00	2011-01-23 00:00:00	0.60	f	\N	\N	\N	2452	\N
2352	14	Poñer escotillas camarote A	\N	PREFIX-00004-00001	2011-01-17 00:00:00	2011-01-23 00:00:00	0.60	f	2351	\N	PREFIX-00002-00011	2453	0
2343	4	Pedido exemplo	\N	PREFIX-00003	2010-09-07 13:55:26.056	\N	0.00	f	\N	\N	\N	2444	\N
2344	4	Exemplo 1	\N	PREFIX-00003-00001	\N	\N	0.00	f	2343	\N	\N	2445	0
2345	4	Subexemplo 1	\N	PREFIX-00003-00004	\N	\N	0.00	f	2344	\N	\N	2446	0
2346	4	Subexemplo 2	\N	PREFIX-00003-00005	\N	\N	0.00	f	2344	\N	\N	2447	1
2347	4	Exemplo 2	\N	PREFIX-00003-00002	\N	\N	0.00	f	2343	\N	\N	2448	1
2348	4	Subexemplo 3	\N	PREFIX-00003-00006	\N	\N	0.00	f	2347	\N	\N	2449	0
2349	4	Subexemplo 4	\N	PREFIX-00003-00007	\N	\N	0.00	f	2347	\N	\N	2450	1
2350	4	Exemplo 3	\N	PREFIX-00003-00003	\N	\N	0.00	f	2343	\N	\N	2451	2
1918	25	Bloque 2	\N	PREFIX-00002-00003	\N	\N	0.05	t	1825	\N	\N	2019	2
1825	28	Pedido grupo 1	\N	PREFIX-00002	2010-09-09 00:00:00	2011-01-21 00:00:00	0.17	t	\N	\N	\N	1926	\N
1911	22	Xestión	\N	PREFIX-00002-00001	\N	\N	0.25	f	1825	\N	\N	2012	0
1912	21	Reunión de traballadores	\N	PREFIX-00002-00004	\N	\N	0.00	f	1911	\N	\N	2013	0
1913	21	Reunión de clientes	\N	PREFIX-00002-00005	\N	\N	0.00	f	1911	\N	\N	2014	1
1914	22	Bloque 1	\N	PREFIX-00002-00002	\N	\N	0.33	f	1825	\N	\N	2015	1
15739	3	Soldar unións do chan	\N	PREFIX-00005-00007	\N	\N	0.00	f	15737	11051	\N	15840	1
15740	3	Soldar unións do teito	\N	PREFIX-00005-00008	\N	\N	0.00	f	15737	11052	\N	15841	2
15741	3	Bloque 2	\N	PREFIX-00005-00003	\N	\N	0.00	f	15733	11053	\N	15842	2
15742	3	Cama e mesilla de camarote A	\N	PREFIX-00005-00009	\N	\N	0.00	f	15741	11054	\N	15843	0
15743	3	Teito de madeira de camarote A	\N	PREFIX-00005-00010	\N	\N	0.00	f	15741	11055	\N	15844	1
15744	3	Poñer escotillas camarote A	\N	PREFIX-00005-00011	\N	\N	0.00	f	15741	11056	\N	15845	2
20875	7	exemplo 2	\N	PREFIX-00007-00001	\N	\N	0.00	f	20874	\N	\N	20976	0
20874	7	Pedido exemplo 1	\N	PREFIX-00007	2010-09-08 13:29:31.678	\N	0.16	f	\N	\N	\N	20975	\N
20878	7	exemplo 3	\N	PREFIX-00007-00002	\N	\N	0.00	f	20874	\N	\N	20979	1
20879	7	exemplo 2	\N	PREFIX-00007-00006	\N	\N	0.00	f	20878	\N	\N	20980	0
20880	7	exemplo 3 (copy)	\N	PREFIX-00007-00007	\N	\N	0.00	f	20878	\N	\N	20981	1
20881	7	exemplo 4	\N	PREFIX-00007-00003	\N	\N	0.50	f	20874	\N	\N	20982	2
20882	7	exemplo 4 (copy)	\N	PREFIX-00007-00008	\N	\N	0.00	f	20881	\N	\N	20983	0
20883	7	exempl 2.2	\N	PREFIX-00007-00009	\N	\N	0.00	f	20881	\N	\N	20984	1
20831	2	Plantilla - Pedido grupo 1	\N	PREFIX-00006	2010-09-08 13:28:24.432	2011-01-20 00:00:00	0.00	f	\N	11045	\N	20932	\N
20832	2	Xestión	\N	PREFIX-00006-00001	\N	\N	0.00	f	20831	11046	\N	20933	0
20833	2	Reunión de traballadores	\N	PREFIX-00006-00004	\N	\N	0.00	f	20832	11047	\N	20934	0
20834	2	Reunión de clientes	\N	PREFIX-00006-00005	\N	\N	0.00	f	20832	11048	\N	20935	1
20835	2	Bloque 1	\N	PREFIX-00006-00002	\N	\N	0.00	f	20831	11049	\N	20936	1
20836	2	Repasar soldadura ocos	\N	PREFIX-00006-00006	\N	\N	0.00	f	20835	11050	\N	20937	0
20837	2	Soldar unións do chan	\N	PREFIX-00006-00007	\N	\N	0.00	f	20835	11051	\N	20938	1
20838	2	Soldar unións do teito	\N	PREFIX-00006-00008	\N	\N	0.00	f	20835	11052	\N	20939	2
20839	2	Bloque 2	\N	PREFIX-00006-00003	\N	\N	0.00	f	20831	11053	\N	20940	2
20840	2	Cama e mesilla de camarote A	\N	PREFIX-00006-00009	\N	\N	0.00	f	20839	11054	\N	20941	0
20841	2	Teito de madeira de camarote A	\N	PREFIX-00006-00010	\N	\N	0.00	f	20839	11055	\N	20942	1
20842	2	Poñer escotillas camarote A	\N	PREFIX-00006-00011	\N	\N	0.00	f	20839	11056	\N	20943	2
20876	6	exemplo 1	\N	PREFIX-00007-00004	\N	\N	0.00	f	20875	\N	\N	20977	0
20877	6	exemplo 2 (copy)	\N	PREFIX-00007-00005	\N	\N	0.00	f	20875	\N	\N	20978	1
\.


--
-- Data for Name: orderelementtemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelementtemplate (id, version, name, description, code, startasdaysfrombeginning, deadlineasdaysfrombeginning, schedulingstatetype, parent, positionincontainer) FROM stdin;
11045	1	Plantilla - Pedido grupo 1	\N	PREFIX-00002	0	134	3	\N	\N
11046	1	Xestión	\N	PREFIX-00002-00001	\N	\N	0	11045	0
11049	1	Bloque 1	\N	PREFIX-00002-00002	\N	\N	3	11045	1
11053	1	Bloque 2	\N	PREFIX-00002-00003	\N	\N	3	11045	2
11047	1	Reunión de traballadores	\N	PREFIX-00002-00004	\N	\N	1	11046	0
11048	1	Reunión de clientes	\N	PREFIX-00002-00005	\N	\N	1	11046	1
11050	1	Repasar soldadura ocos	\N	PREFIX-00002-00006	\N	\N	0	11049	0
11051	1	Soldar unións do chan	\N	PREFIX-00002-00007	\N	\N	0	11049	1
11052	1	Soldar unións do teito	\N	PREFIX-00002-00008	\N	\N	0	11049	2
11054	1	Cama e mesilla de camarote A	\N	PREFIX-00002-00009	\N	\N	0	11053	0
11055	1	Teito de madeira de camarote A	\N	PREFIX-00002-00010	\N	\N	0	11053	1
11056	1	Poñer escotillas camarote A	\N	PREFIX-00002-00011	\N	\N	0	11053	2
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid, lasthoursgroupsequencecode) FROM stdin;
1912	1
1913	1
1915	1
1916	1
1917	1
2345	1
2346	1
2348	1
2349	1
2350	1
2323	1
2324	1
2325	1
20833	1
20834	1
20836	1
20837	1
20838	1
20840	1
20841	1
20842	1
15735	1
15736	1
15738	1
15739	1
15740	1
15742	1
15743	1
15744	1
2352	1
20879	1
20880	1
20882	1
20883	1
20876	1
20877	1
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1825
1911
1914
1918
2343
2344
2347
2351
15733
15734
15737
15741
20831
20832
20835
20839
20874
20875
20878
20881
\.


--
-- Data for Name: orderlinegrouptemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegrouptemplate (group_template_id) FROM stdin;
11045
11046
11049
11053
\.


--
-- Data for Name: orderlinetemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinetemplate (order_line_template_id, lasthoursgroupsequencecode) FROM stdin;
11047	0
11048	0
11050	0
11051	0
11052	0
11054	0
11055	0
11056	0
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
808	9	PREFIX	7	5	t
\.


--
-- Data for Name: ordertemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordertemplate (order_template_id, base_calendar_id) FROM stdin;
11045	505
\.


--
-- Data for Name: orderversion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderversion (id, version, modificationbyownertimestamp, ownerscenario) FROM stdin;
2128	29	2010-09-08 13:18:27.473	404
12181	2	2010-09-08 13:28:38.001	404
2132	6	2010-09-07 13:56:54.553	404
12187	8	2010-09-08 13:42:02.487	404
12177	4	2010-09-07 17:35:55.611	404
2133	13	2010-09-07 17:36:56.952	404
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype, reportadvance, advance_type_id) FROM stdin;
10302	1	Formulario de calidade procesos tipo 1	Desc.	0	t	10201
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
10302	Paso 1	25.00	0	0
10302	Paso 2	50.00	1	1
10302	Paso 3	75.00	2	2
10302	Paso 4	100.00	3	3
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, code, generatecode, limited_resource, base_calendar_id) FROM stdin;
1516	9	93918d50-1f9a-4aca-be75-3481876d5310	t	f	508
1518	13	0353917e-1693-4fb7-acf1-0849341c8a06	t	f	511
1520	9	fe77cfd3-12f7-4a26-a852-59aa2a48b6bd	t	f	510
19797	2	281c8e82-5a3e-4fc4-819c-32f0e5fbed64	t	t	19897
19799	2	31efc8bd-cdb5-4f7e-a4af-bac7fd88132d	t	f	19898
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, intended_total_hours, originaltotalassignment, task, assignment_function) FROM stdin;
20301	4	1.00	250	250	2733	\N
3151	12	0.83	\N	200	2728	\N
3152	12	1.00	\N	200	2729	\N
3153	12	0.96	\N	100	2730	\N
3131	13	0.61	\N	400	2727	\N
20302	3	1.00	300	300	2732	\N
20347	1	1.00	\N	200	16487	\N
20348	1	1.67	\N	200	16488	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
509	1
508	1
511	1
510	1
19897	1
19898	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, code, initdate, enddate, cost_category_id, resource_id) FROM stdin;
9797	1	caf10582-a9c7-44b4-be00-c06f72b03b94	2010-09-07	\N	9595	1518
9798	1	202dda6f-6df7-480f-9f7e-3cdcc36d3bf9	2010-09-07	\N	9596	1520
\.


--
-- Data for Name: scenario; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scenario (id, version, name, description, lastnotownedreassignationstimestamp, predecessor) FROM stdin;
404	0	master	\N	\N	\N
\.


--
-- Data for Name: scenario_orders; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scenario_orders (order_id, order_version_id, scenario_id) FROM stdin;
1825	2128	404
2343	2132	404
2351	2133	404
15733	12177	404
20831	12181	404
20874	12187	404
\.


--
-- Data for Name: scheduling_states_by_order_version; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY scheduling_states_by_order_version (order_element_id, scheduling_state_for_version_id, order_version_id) FROM stdin;
1825	2027	2128
1911	2113	2128
1912	2114	2128
1913	2115	2128
1914	2116	2128
1915	2117	2128
1916	2118	2128
1917	2119	2128
1918	2120	2128
2323	2525	2128
2324	2526	2128
2325	2527	2128
2343	2545	2132
2344	2546	2132
2345	2547	2132
2346	2548	2132
2347	2549	2132
2348	2550	2132
2349	2551	2132
2350	2552	2132
2351	2553	2133
2352	2554	2133
15733	15935	12177
15734	15936	12177
15735	15937	12177
15736	15938	12177
15737	15939	12177
15738	15940	12177
15739	15941	12177
15740	15942	12177
15741	15943	12177
15742	15944	12177
15743	15945	12177
15744	15946	12177
20831	21033	12181
20832	21034	12181
20833	21035	12181
20834	21036	12181
20835	21037	12181
20836	21038	12181
20837	21039	12181
20838	21040	12181
20839	21041	12181
20840	21042	12181
20841	21043	12181
20842	21044	12181
20874	21076	12187
20875	21077	12187
20876	21078	12187
20877	21079	12187
20878	21080	12187
20879	21081	12187
20880	21082	12187
20881	21083	12187
20882	21084	12187
20883	21085	12187
\.


--
-- Data for Name: schedulingdataforversion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY schedulingdataforversion (id, version, schedulingstatetype, order_element_id) FROM stdin;
2553	8	3	2351
2554	8	0	2352
21083	7	3	20881
21084	7	0	20882
21085	7	0	20883
21077	7	0	20875
21078	7	1	20876
21079	7	1	20877
2545	4	4	2343
2546	4	4	2344
2547	4	4	2345
2548	4	4	2346
2549	4	4	2347
2550	4	4	2348
2551	4	4	2349
2552	4	4	2350
2027	23	3	1825
2113	22	0	1911
2114	22	1	1912
2115	22	1	1913
2116	22	3	1914
2117	22	0	1915
2118	22	0	1916
2119	22	0	1917
2120	22	3	1918
2525	22	0	2323
15935	3	3	15733
15936	3	0	15734
15937	3	1	15735
15938	3	1	15736
15939	3	3	15737
15940	3	0	15738
15941	3	0	15739
15942	3	0	15740
15943	3	3	15741
15944	3	0	15742
15945	3	0	15743
15946	3	0	15744
2526	22	0	2324
2527	22	0	2325
21033	2	3	20831
21034	2	0	20832
21035	2	1	20833
21036	2	1	20834
21037	2	3	20835
21038	2	0	20836
21039	2	0	20837
21040	2	0	20838
21041	2	3	20839
21042	2	0	20840
21043	2	0	20841
21044	2	0	20842
21076	7	3	20874
21080	7	3	20878
21081	7	0	20879
21082	7	0	20880
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
20301	19797
3131	1516
20302	19797
20347	1516
\.


--
-- Data for Name: specificdayassignmentscontainer; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specificdayassignmentscontainer (id, version, resource_allocation_id, scenario) FROM stdin;
20503	4	20301	404
3232	13	3131	404
20504	1	20302	404
20521	1	20347	404
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id, type) FROM stdin;
\.


--
-- Data for Name: subcontractedtaskdata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY subcontractedtaskdata (id, version, externalcompany, subcontratationdate, subcontractcommunicationdate, workdescription, subcontractprice, subcontractedcode, nodewithoutchildrenexported, labelsexported, materialassignmentsexported, hoursgroupsexported, state) FROM stdin;
3506183	8	10605	2010-09-07 17:09:26.116	2010-09-07 17:10:43.782	Contratación de escotillas	10000.00	code1	\N	\N	\N	\N	2
\.


--
-- Data for Name: sumchargedhours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY sumchargedhours (id, version, directchargedhours, indirectchargedhours) FROM stdin;
2452	9	0	0
2453	9	0	0
2444	4	0	0
2445	4	0	0
2446	4	0	0
2447	4	0	0
2448	4	0	0
2449	4	0	0
2450	4	0	0
2451	4	0	0
1926	24	0	63
2012	22	25	0
2013	21	0	0
2014	21	0	0
2015	22	0	38
2016	22	38	0
2017	21	0	0
2018	21	0	0
15834	3	0	0
15835	3	0	0
15836	3	0	0
15837	3	0	0
15838	3	0	0
15839	3	0	0
15840	3	0	0
15841	3	0	0
15842	3	0	0
15843	3	0	0
15844	3	0	0
15845	3	0	0
2019	21	0	0
2424	21	0	0
2425	21	0	0
2426	21	0	0
20975	6	0	0
20979	6	0	0
20980	6	0	0
20981	6	0	0
20932	2	0	0
20933	2	0	0
20934	2	0	0
20935	2	0	0
20936	2	0	0
20937	2	0	0
20938	2	0	0
20939	2	0	0
20940	2	0	0
20941	2	0	0
20942	2	0	0
20943	2	0	0
20982	6	0	0
20983	6	0	0
20984	6	0	0
20976	6	0	0
20977	6	0	0
20978	6	0	0
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate, subcontrated_task_data_id, priority) FROM stdin;
16463	1	0	\N	\N	\N
16464	1	0	\N	\N	\N
16465	1	0	\N	\N	\N
16466	1	0	\N	\N	\N
16468	1	0	\N	\N	\N
16469	1	0	\N	\N	\N
16470	1	0	\N	\N	\N
2751	1	1	2011-01-17 00:00:00	\N	\N
2733	2	1	2010-09-09 00:00:00	\N	5
2734	1	2	2011-01-17 00:00:00	3506183	\N
2728	1	0	\N	\N	\N
2729	1	0	\N	\N	\N
2730	1	0	\N	\N	\N
2727	1	0	\N	\N	\N
2732	2	1	2010-10-22 00:00:00	\N	5
16473	1	0	\N	\N	\N
16474	1	0	\N	\N	\N
16475	1	0	\N	\N	\N
16476	1	0	\N	\N	\N
16478	1	0	\N	\N	\N
16479	1	0	\N	\N	\N
16480	1	0	\N	\N	\N
16483	1	0	\N	\N	\N
16484	1	0	\N	\N	\N
16485	1	0	\N	\N	\N
16487	1	0	\N	\N	\N
16488	1	0	\N	\N	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id, reportadvance) FROM stdin;
10405	2	10302	1825	f
11773	2	10302	15733	f
11777	2	10302	20831	f
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
10405	Paso 1	25.00	0	t	2010-09-07 00:00:00	0
10405	Paso 2	50.00	1	f	\N	1
10405	Paso 3	75.00	2	f	\N	2
10405	Paso 4	100.00	3	f	\N	3
11773	Paso 1	25.00	0	f	\N	0
11773	Paso 2	50.00	1	f	\N	1
11773	Paso 3	75.00	2	f	\N	2
11773	Paso 4	100.00	3	f	\N	3
11777	Paso 1	25.00	0	f	\N	0
11777	Paso 2	50.00	1	f	\N	1
11777	Paso 3	75.00	2	f	\N	2
11777	Paso 4	100.00	3	f	\N	3
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
16473	21124
16473	21125
16474	21126
16475	21127
16476	21128
16478	21129
16479	21130
16480	21131
16483	21152
16483	21151
16484	21153
16485	21154
16487	21155
16488	21156
2727	2285
2727	2284
2728	2286
2729	2287
2730	2288
2732	2289
2733	2290
2734	2291
16463	15638
16463	15639
16464	15640
16465	15641
16466	15642
16468	15643
16469	15644
16470	15645
2751	2307
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, startdayduration, enddate, enddayduration, deadline, advance_percentage, parent, base_calendar_id, positioninparent) FROM stdin;
16463	2	Xestión	\N	2010-09-07	0	2010-10-02	0	\N	0.00	16472	\N	0
16464	2	Repasar soldadura ocos	\N	2010-09-07	0	2010-10-02	0	\N	0.00	16467	\N	0
16465	2	Soldar unións do chan	\N	2010-09-07	0	2010-10-02	0	\N	0.00	16467	\N	1
16466	2	Soldar unións do teito	\N	2010-09-07	0	2010-09-19	0	\N	0.00	16467	\N	2
16482	1	Plantilla - Pedido grupo 1	\N	2010-09-08	0	2010-10-15	0	2011-01-20	0.00	\N	\N	\N
16468	2	Cama e mesilla de camarote A	\N	2010-09-07	0	2010-10-14	0	\N	0.00	16471	\N	0
16469	2	Teito de madeira de camarote A	\N	2010-09-07	0	2010-10-08	0	\N	0.00	16471	\N	1
16470	2	Poñer escotillas camarote A	\N	2010-09-07	0	2010-10-02	0	\N	0.00	16471	\N	2
16474	1	Repasar soldadura ocos	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16477	\N	0
16475	1	Soldar unións do chan	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16477	\N	1
16476	1	Soldar unións do teito	\N	2010-09-08	0	2010-09-20	0	\N	0.00	16477	\N	2
16467	3	Bloque 1	\N	2010-09-07	0	2010-10-02	0	\N	0.00	16472	\N	1
16478	1	Cama e mesilla de camarote A	\N	2010-09-08	0	2010-10-15	0	\N	0.00	16481	\N	0
16479	1	Teito de madeira de camarote A	\N	2010-09-08	0	2010-10-09	0	\N	0.00	16481	\N	1
16480	1	Poñer escotillas camarote A	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16481	\N	2
16473	1	Xestión	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16482	\N	0
16477	1	Bloque 1	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16482	\N	1
16481	1	Bloque 2	\N	2010-09-08	0	2010-10-15	0	\N	0.00	16482	\N	2
2735	24	Bloque 2	\N	2010-12-18	0	2011-01-23	0	\N	0.05	2736	\N	2
2733	22	Teito de madeira de camarote A	\N	2010-09-09	0	2010-10-22	0	\N	0.00	2735	\N	1
2734	21	Poñer escotillas camarote A	\N	2011-01-17	0	2011-01-23	0	\N	0.30	2735	\N	2
2731	24	Bloque 1	\N	2010-09-09	0	2010-12-18	0	\N	0.33	2736	\N	1
2728	21	Repasar soldadura ocos	\N	2010-11-03	0	2010-12-18	0	\N	0.33	2731	\N	0
16471	3	Bloque 2	\N	2010-09-07	0	2010-10-14	0	\N	0.00	16472	\N	2
16472	3	Pedido grupo 2	\N	2010-09-07	0	2010-10-14	0	2011-01-19	0.00	\N	\N	\N
2729	21	Soldar unións do chan	\N	2010-09-28	0	2010-11-03	0	\N	0.30	2731	\N	1
2730	21	Soldar unións do teito	\N	2010-09-09	0	2010-09-28	0	\N	0.40	2731	\N	2
2751	7	Poñer escotillas camarote A	\N	2011-01-17	0	2011-02-23	0	2011-01-23	0.60	2752	\N	0
2752	9	Contratación de escotillas	\N	2011-01-17	0	2011-02-23	0	2011-01-23	0.60	\N	\N	\N
2750	15	Recepción material	\N	2010-10-21	0	2010-10-21	0	\N	0.00	2736	\N	3
2727	21	Xestión	\N	2010-09-09	0	2011-01-20	0	\N	0.25	2736	\N	0
2736	24	Pedido grupo 1	\N	2010-09-09	0	2011-01-23	0	2011-01-21	0.17	\N	\N	\N
2732	22	Cama e mesilla de camarote A	\N	2010-10-22	0	2010-12-17	0	\N	0.00	2735	\N	0
16484	3	exemplo 2	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16486	\N	0
16485	3	exemplo 3 (copy)	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16486	\N	1
16489	3	exemplo 4	\N	2010-09-08	0	2010-10-19	0	\N	0.50	16490	\N	2
16487	3	exemplo 4 (copy)	\N	2010-09-08	0	2010-10-19	0	\N	0.00	16489	\N	0
16488	3	exempl 2.2	\N	2010-09-08	0	2010-09-29	0	\N	0.00	16489	\N	1
16490	3	Pedido exemplo 1	\N	2010-09-08	0	2010-10-28	0	\N	0.16	\N	\N	\N
16483	3	exemplo 2	\N	2010-09-08	0	2010-10-28	0	\N	0.00	16490	\N	0
16486	3	exemplo 3	\N	2010-09-08	0	2010-10-03	0	\N	0.00	16490	\N	1
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
2731
2735
2736
2752
16467
16471
16472
16477
16481
16482
16486
16489
16490
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id, startconstrainttype, constraintdate) FROM stdin;
2750	2	2010-10-21 00:00:00
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, schedulingdata) FROM stdin;
16467	2	15939
16471	2	15943
16472	2	15935
16463	3	15936
16464	3	15940
16465	3	15941
16466	3	15942
16468	3	15944
16469	3	15945
16470	3	15946
2752	5	2553
2751	9	2554
2731	6	2116
2735	6	2120
2736	6	2027
2727	11	2113
2728	11	2117
2729	11	2118
2730	11	2119
2732	11	2525
2733	11	2526
2734	11	2527
16473	1	21034
16474	1	21038
16475	1	21039
16476	1	21040
16477	1	21037
16478	1	21042
16479	1	21043
16480	1	21044
16481	1	21041
16482	1	21033
16483	1	21077
16484	1	21081
16485	1	21082
16486	1	21080
16487	1	21084
16488	1	21085
16489	1	21083
16490	1	21076
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled, generatecode) FROM stdin;
8888	1	Hora normal convenio metal	9594e338-65ca-4483-ad35-18d2815c7c7d	15.00	t	t
8889	1	Hora extra convenio metal	b619454c-a990-4c16-a41e-26219c2c833b	17.00	t	t
\.


--
-- Data for Name: unit_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY unit_type (id, version, code, measure, generatecode) FROM stdin;
202	1	f09943b1-710f-4829-bbc3-3d253ff2e3b8	units	f
203	1	2042a0bb-d499-4b95-8cde-15c6d3bf8f62	kg	f
204	1	2098b114-e90d-436c-ad36-f8c50656156b	km	f
205	1	86b901e9-e8d6-476e-88d2-f06ddbaf9c09	l	f
206	1	1d5cd58e-81f8-4899-94aa-23a2527ea5d6	m	f
207	1	d375d456-1e45-4f06-9059-3c9928644c4e	m2	f
208	1	cf3e635e-3180-47ed-96d8-e9fdb9d5fa6f	m3	f
209	1	0c968090-90cc-48b8-9b00-6a24e26bea58	tn	f
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
1112	ROLE_CREATE_ORDER
1112	ROLE_ADMINISTRATION
1112	ROLE_EDIT_ALL_ORDERS
1112	ROLE_READ_ALL_ORDERS
1113	ROLE_WS_READER
1114	ROLE_WS_READER
1114	ROLE_WS_WRITER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
19799	\N
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, code, date, generatecode, work_report_type_id, resource_id, order_element_id) FROM stdin;
8989	1	127ed3b1-2bf0-4f46-9fab-ea476b5553f9	\N	t	8585	1520	\N
8990	2	068f3ba5-c2aa-4633-8bb9-174cdff4f29f	\N	t	8585	1516	\N
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, positionnumber, label_type_id, label_id, work_report_type_id) FROM stdin;
8686	1	f	1	1313	1416	8585
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, code, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
8798	1	0ab86551-f727-41c0-8c6b-534657ebe64c	2	2010-09-14 00:00:00	\N	\N	8989	1520	1911	8889
8799	1	c411d484-dc0d-40fe-902c-a5139de71ec0	5	2010-09-10 00:00:00	\N	\N	8989	1520	1911	8888
8800	1	215d6250-6bc3-4441-8835-4ef37b14b6ab	8	2010-09-13 00:00:00	\N	\N	8989	1520	1911	8888
8801	1	155b9555-97c5-4938-aace-7fdda4497abd	6	2010-09-09 00:00:00	\N	\N	8989	1520	1911	8888
8802	1	ba8daa55-7713-4bd4-a387-ef572a94d91e	4	2010-09-15 00:00:00	\N	\N	8989	1520	1911	8888
8810	2	d257bfff-5585-41cf-b084-8fb5fd03ca63	4	2010-09-07 16:12:49.749	\N	\N	8990	1516	1915	8889
8812	2	30d02770-b3c2-4222-a703-41e40f94ab9a	8	2010-09-07 16:12:51.154	\N	\N	8990	1516	1915	8888
8814	2	d4320547-d15c-4a1b-b5d6-00c3bd54a7d2	9	2010-09-07 16:12:49.221	\N	\N	8990	1516	1915	8888
8811	2	29c677ac-877c-466c-8602-2958cc67ba78	9	2010-09-07 16:12:50.578	\N	\N	8990	1516	1915	8888
8813	2	21bcc7ee-8440-4c50-b606-ad9e35b8de24	8	2010-09-07 16:12:50.118	\N	\N	8990	1516	1915	8888
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
8585	1	Tipo grupo 1	tg1	f	t	f	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1516	Javier	Martínez Álvarez	11111111F
1518	María	Pérez Mariño	22222222D
1520	Javier	Pérez Campos	56565656L
19799	Soldadores	---	[Virtual]
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
8798	1416
8799	1416
8800	1416
8801	1416
8802	1416
8810	1416
8811	1416
8812	1416
8813	1416
8814	1416
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advanceassignmenttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT advanceassignmenttemplate_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_code_key UNIQUE (code);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_code_key UNIQUE (code);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_code_key UNIQUE (code);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_code_key UNIQUE (code);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: consolidatedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT consolidatedvalue_pkey PRIMARY KEY (id);


--
-- Name: consolidation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT consolidation_pkey PRIMARY KEY (id);


--
-- Name: cost_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_code_key UNIQUE (code);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_code_key UNIQUE (code);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_code_key UNIQUE (code);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_code_key UNIQUE (code);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: deriveddayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT deriveddayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: effortperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY effortperday
    ADD CONSTRAINT effortperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: external_company_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_name_key UNIQUE (name);


--
-- Name: external_company_nif_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_nif_key UNIQUE (nif);


--
-- Name: external_company_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: genericdayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT genericdayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: hour_cost_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_code_key UNIQUE (code);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_code_key UNIQUE (code);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_code_key UNIQUE (code);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT limiting_resource_queue_dependency_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_resource_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_resource_allocation_id_key UNIQUE (resource_allocation_id);


--
-- Name: limiting_resource_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_resource_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_resource_id_key UNIQUE (resource_id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_template_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT material_assigment_template_pkey PRIMARY KEY (id);


--
-- Name: material_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_code_key UNIQUE (code);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT order_authorization_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_element_template_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT order_element_template_label_pkey PRIMARY KEY (order_element_template_id, label_id);


--
-- Name: order_element_template_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT order_element_template_quality_form_pkey PRIMARY KEY (order_element_template_id, quality_form_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_code_key UNIQUE (code);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderelement_sum_charged_hours_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_sum_charged_hours_id_key UNIQUE (sum_charged_hours_id);


--
-- Name: orderelementtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT orderelementtemplate_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegrouptemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT orderlinegrouptemplate_pkey PRIMARY KEY (group_template_id);


--
-- Name: orderlinetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT orderlinetemplate_pkey PRIMARY KEY (order_line_template_id);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: ordertemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT ordertemplate_pkey PRIMARY KEY (order_template_id);


--
-- Name: orderversion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderversion
    ADD CONSTRAINT orderversion_pkey PRIMARY KEY (id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_base_calendar_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_base_calendar_id_key UNIQUE (base_calendar_id);


--
-- Name: resource_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_code_key UNIQUE (code);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_code_key UNIQUE (code);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: scenario_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT scenario_orders_pkey PRIMARY KEY (scenario_id, order_id);


--
-- Name: scenario_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scenario
    ADD CONSTRAINT scenario_pkey PRIMARY KEY (id);


--
-- Name: scheduling_states_by_order_version_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT scheduling_states_by_order_version_pkey PRIMARY KEY (order_element_id, order_version_id);


--
-- Name: schedulingdataforversion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY schedulingdataforversion
    ADD CONSTRAINT schedulingdataforversion_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: specificdayassignmentscontainer_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT specificdayassignmentscontainer_pkey PRIMARY KEY (id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: subcontractedtaskdata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT subcontractedtaskdata_pkey PRIMARY KEY (id);


--
-- Name: sumchargedhours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY sumchargedhours
    ADD CONSTRAINT sumchargedhours_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: task_subcontrated_task_data_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_subcontrated_task_data_id_key UNIQUE (subcontrated_task_data_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: tasksource_schedulingdata_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_schedulingdata_key UNIQUE (schedulingdata);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: unit_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_code_key UNIQUE (code);


--
-- Name: unit_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_code_key UNIQUE (code);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_code_key UNIQUE (code);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk1ccb0f7419b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f7419b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk1ccb0f74b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f74b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fk1fc5f45575ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f45575ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk1fc5f455bd2209e8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f455bd2209e8 FOREIGN KEY (limiting_resource_queue_id) REFERENCES limiting_resource_queue(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk27a9a55b595a0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a55b595a0 FOREIGN KEY (subcontrated_task_data_id) REFERENCES subcontractedtaskdata(id);


--
-- Name: fk2999e7e5421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT fk2999e7e5421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fk2999e7e57518838c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specificdayassignmentscontainer
    ADD CONSTRAINT fk2999e7e57518838c FOREIGN KEY (resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fk29d0015519b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d0015519b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk29d001558b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d001558b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk3a79eb0219b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0219b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk40795527f11b2d0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk40795527f11b2d0 FOREIGN KEY (unit_type) REFERENCES unit_type(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk4a1d42dc9fb7fc18; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT fk4a1d42dc9fb7fc18 FOREIGN KEY (order_line_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk4d68b9c89a4a7d90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c89a4a7d90 FOREIGN KEY (order_template_id) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fk4d68b9c8a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c8a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk53cd4dcaa2380ca7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderversion
    ADD CONSTRAINT fk53cd4dcaa2380ca7 FOREIGN KEY (ownerscenario) REFERENCES scenario(id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5948535228f2695; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk5948535228f2695 FOREIGN KEY (origin_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk59485352e42f8d29; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk59485352e42f8d29 FOREIGN KEY (destiny_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk698876da1b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT fk698876da1b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fk698876da421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY deriveddayassignmentscontainer
    ADD CONSTRAINT fk698876da421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk711ace7423b85cf1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace7423b85cf1 FOREIGN KEY (order_version_id) REFERENCES orderversion(id);


--
-- Name: fk711ace7487287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace7487287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fk711ace74c0fb9d8e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario_orders
    ADD CONSTRAINT fk711ace74c0fb9d8e FOREIGN KEY (scenario_id) REFERENCES scenario(id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6b9e788f90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b9e788f90 FOREIGN KEY (queue_dependency) REFERENCES limiting_resource_queue_dependency(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39d4ec080cf; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39d4ec080cf FOREIGN KEY (customer) REFERENCES external_company(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk7e57469848d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT fk7e57469848d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk8217a424b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT fk8217a424b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fk9bb0b28841638aab; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT fk9bb0b28841638aab FOREIGN KEY (parent) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka04a45b123b85cf1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b123b85cf1 FOREIGN KEY (order_version_id) REFERENCES orderversion(id);


--
-- Name: fka04a45b19bfe55d0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b19bfe55d0 FOREIGN KEY (scheduling_state_for_version_id) REFERENCES schedulingdataforversion(id);


--
-- Name: fka04a45b1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scheduling_states_by_order_version
    ADD CONSTRAINT fka04a45b1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fka87c31085567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c31085567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fka87c310887287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c310887287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fka87c3108edc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c3108edc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fka9542ec319b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec319b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fka9542ec3c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec3c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkab89a5edefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY schedulingdataforversion
    ADD CONSTRAINT fkab89a5edefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e209a2c0abd; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e209a2c0abd FOREIGN KEY (schedulingdata) REFERENCES schedulingdataforversion(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f5019256004; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5019256004 FOREIGN KEY (generic_container_id) REFERENCES genericdayassignmentscontainer(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f50510e7a78; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50510e7a78 FOREIGN KEY (derived_container_id) REFERENCES deriveddayassignmentscontainer(id);


--
-- Name: fkbb493f50756348a8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50756348a8 FOREIGN KEY (specific_container_id) REFERENCES specificdayassignmentscontainer(id);


--
-- Name: fkc405554bfd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY effortperday
    ADD CONSTRAINT fkc405554bfd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkcf1f2cd08bdc6ac6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd08bdc6ac6 FOREIGN KEY (order_line_template) REFERENCES orderlinetemplate(order_line_template_id);


--
-- Name: fkd06071e0421c7cf4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT fkd06071e0421c7cf4 FOREIGN KEY (scenario) REFERENCES scenario(id);


--
-- Name: fkd06071e0ee970b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY genericdayassignmentscontainer
    ADD CONSTRAINT fkd06071e0ee970b FOREIGN KEY (resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkd3056ef7ddc82952; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT fkd3056ef7ddc82952 FOREIGN KEY (group_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkd59fd7b0fd99606d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY scenario
    ADD CONSTRAINT fkd59fd7b0fd99606d FOREIGN KEY (predecessor) REFERENCES scenario(id);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fkdbbb4fee7ec17fa6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee7ec17fa6 FOREIGN KEY (sum_charged_hours_id) REFERENCES sumchargedhours(id);


--
-- Name: fkdbbb4feed97bcc8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4feed97bcc8c FOREIGN KEY (template) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb026919b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb026919b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb0269b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb0269b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke562c7e93fee60cc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT fke562c7e93fee60cc FOREIGN KEY (companyuser) REFERENCES naval_user(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkecc6114019960f43; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT fkecc6114019960f43 FOREIGN KEY (externalcompany) REFERENCES external_company(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkeeedb0fc4cd98327; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT fkeeedb0fc4cd98327 FOREIGN KEY (lastconnectedscenario) REFERENCES scenario(id);


--
-- Name: fkef86282edc874c20; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282edc874c20 FOREIGN KEY (base_calendar_id) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf436a4163ae24ff8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a4163ae24ff8 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf436a416b96bba28; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416b96bba28 FOREIGN KEY (advance_measurement_id) REFERENCES advancemeasurement(id);


--
-- Name: fkf436a416cec54333; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416cec54333 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf8df3e0c430ea1de; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c430ea1de FOREIGN KEY (ind_advance_assignment_id) REFERENCES indirectadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0c9f1d6611; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c9f1d6611 FOREIGN KEY (dir_advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0cff2b2ba3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0cff2b2ba3 FOREIGN KEY (id) REFERENCES task(task_element_id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

