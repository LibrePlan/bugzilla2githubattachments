--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    hours integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255)
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    criterion_id bigint,
    parent bigint,
    isvalid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint,
    derived_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: external_company; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE external_company (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    nif character varying(255),
    client boolean,
    subcontractor boolean,
    interactswithapplications boolean,
    appuri character varying(255),
    ourcompanylogin character varying(255),
    ourcompanypassword character varying(255),
    companyuser bigint
);


ALTER TABLE public.external_company OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    resourcetype bytea,
    workinghours integer NOT NULL,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint NOT NULL
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    code character varying(255),
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type integer,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_assigment_template; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment_template (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment_template OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_authorization; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_authorization (
    id bigint NOT NULL,
    order_authorization_subclass character varying(255) NOT NULL,
    version bigint NOT NULL,
    authorizationtype character varying(255) NOT NULL,
    order_id bigint,
    user_id bigint,
    profile_id bigint
);


ALTER TABLE public.order_authorization OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_element_template_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_label (
    order_element_template_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_label OWNER TO naval;

--
-- Name: order_element_template_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_quality_form (
    order_element_template_id bigint NOT NULL,
    quality_form_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_quality_form OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    customer character varying(255),
    dependenciesconstraintshavepriority boolean,
    codeautogenerated boolean,
    lastorderelementsequencecode integer,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    mandatoryinit boolean,
    mandatoryend boolean,
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderelementtemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelementtemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    startasdaysfrombeginning integer,
    deadlineasdaysfrombeginning integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelementtemplate OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: orderlinegrouptemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegrouptemplate (
    group_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinegrouptemplate OWNER TO naval;

--
-- Name: orderlinetemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinetemplate (
    order_line_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinetemplate OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: ordertemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordertemplate (
    order_template_id bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.ordertemplate OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: subcontractedtaskdata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE subcontractedtaskdata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    externalcompany bigint,
    subcontratationdate timestamp without time zone,
    subcontractcommunicationdate timestamp without time zone,
    workdescription character varying(255),
    subcontractprice numeric(19,2),
    subcontractedcode character varying(255),
    nodewithoutchildrenexported boolean,
    labelsexported boolean,
    materialassignmentsexported boolean,
    hoursgroupsexported boolean,
    criterionrequirementsexported boolean
);


ALTER TABLE public.subcontractedtaskdata OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone,
    subcontrated_task_data_id bigint
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date timestamp without time zone,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    positionnumber integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart timestamp without time zone,
    clockfinish timestamp without time zone,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
17523	4	t	809
17524	4	t	809
17525	4	t	809
17526	4	t	809
2356	20	t	808
17527	4	f	809
17738	3	t	809
17739	3	f	809
17740	3	t	809
17741	3	t	809
17742	3	f	809
2357	20	t	808
17743	3	t	809
17744	3	f	809
2358	20	t	808
2379	19	t	808
2380	19	t	808
2381	19	t	808
2382	19	t	808
2383	19	t	808
2384	19	t	808
2385	19	t	808
2386	19	t	808
2387	19	t	808
2388	19	t	808
2391	14	t	808
24655	2	t	809
24656	2	f	809
24657	2	t	809
24658	2	f	809
24659	2	t	809
24660	2	f	809
24661	2	t	809
24662	2	t	809
24663	2	f	809
24664	2	t	809
24665	2	t	809
24666	2	t	809
24667	2	t	809
24668	2	f	809
24669	2	t	809
24670	2	f	809
24671	2	t	809
24672	2	t	809
24673	2	f	809
24674	2	t	809
24675	2	t	809
24676	2	t	809
24677	2	t	809
24678	2	t	809
24679	2	t	809
24680	2	f	809
24681	2	t	809
24682	2	t	809
24683	2	t	809
24684	2	t	809
24685	2	f	809
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
17581	4	2010-01-15	100.00	17523
17582	4	2010-01-15	100.00	17524
17583	4	2010-01-15	100.00	17525
17584	4	2010-01-15	100.00	17526
17645	3	2010-01-15	100.00	17738
17646	3	2010-01-15	100.00	17740
17647	3	2010-01-15	100.00	17741
17648	3	2010-01-15	100.00	17743
24748	2	2010-01-15	100.00	24655
24749	2	2010-01-15	100.00	24657
24750	2	2010-01-15	100.00	24659
24751	2	2010-01-15	100.00	24661
24752	2	2010-01-15	100.00	24662
24753	2	2010-01-15	50.00	24664
24754	2	2010-01-15	100.00	24665
24755	2	2010-01-15	100.00	24666
24756	2	2010-01-15	100.00	24667
24757	2	2010-01-15	25.00	24669
24758	2	2010-01-15	100.00	24671
24759	2	2010-01-15	50.00	24672
24760	2	2010-01-15	100.00	24674
24761	2	2010-01-15	100.00	24675
24762	2	2010-01-15	100.00	24676
24763	2	2010-01-15	100.00	24677
24764	2	2010-01-15	100.00	24678
24765	2	2010-01-15	100.00	24679
24766	2	2010-01-15	75.00	24681
24767	2	2010-01-15	75.00	24682
24768	2	2010-01-15	100.00	24683
24769	2	2010-01-15	50.00	24684
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
808	4	children	100.0000	f	0.0100	t	t
809	3	percentage	100.0000	f	0.0100	t	t
810	2	units	2147483647.0000	f	1.0000	t	f
811	1	subcontractor	100.0000	f	0.0100	t	t
1920	1	Toneladas	100000.0000	t	1.0000	t	f
1919	2	Porcentaje pactado	100.0000	t	0.0000	t	t
1921	1	Importe facturado	5000000.0000	t	100.0000	t	f
1922	1	Importe facturado (pactado)	5000000.0000	t	100.0000	t	f
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
303	3	España (por defecto)
1417	1	Galicia
1418	1	Pontevedra
1419	1	Vigo
1422	1	Ferrol
1423	3	\N
1426	3	\N
1424	4	\N
1414	5	\N
1427	3	\N
1420	4	\N
1425	3	\N
1428	2	\N
1429	2	\N
1430	2	\N
1431	1	\N
1432	1	Máquinas
1433	2	\N
1434	1	\N
1435	2	\N
1436	2	\N
1437	2	\N
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
1631	2	2009-01-01	\N	1436	0
1632	2	2009-01-01	\N	1437	0
1618	3	2009-01-01	\N	1423	0
1621	3	2009-01-01	\N	1426	0
1619	4	2009-01-01	\N	1424	0
1616	5	2009-01-01	\N	1414	0
1622	3	2009-01-01	\N	1427	0
1617	4	2010-01-15	\N	1420	0
1620	3	2009-01-01	\N	1425	0
1623	2	2009-01-15	\N	1428	0
1624	2	2009-01-15	\N	1429	0
1625	2	2009-01-15	\N	1430	0
1626	1	2010-01-15	\N	1431	0
1627	2	2010-01-15	\N	1433	0
1628	1	2010-01-15	\N	1434	0
1629	2	2009-01-01	2009-01-01	1435	0
1630	1	2009-01-02	\N	1435	1
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
1531	2	303	\N	1430	0
1532	1	1422	\N	1431	0
1533	1	\N	\N	1432	0
404	3	\N	\N	303	0
1534	2	1432	\N	1433	0
1518	1	303	\N	1417	0
1519	1	1417	\N	1418	0
1520	1	1417	\N	1419	0
1535	1	1432	\N	1434	0
1536	2	303	\N	1435	0
1523	1	1417	\N	1422	0
1537	2	303	\N	1436	0
1538	2	303	\N	1437	0
1524	3	1418	\N	1423	0
1527	3	303	\N	1426	0
1525	4	303	\N	1424	0
1515	5	303	\N	1414	0
1528	3	303	\N	1427	0
1521	4	1418	\N	1420	0
1526	3	303	\N	1425	0
1529	2	1422	\N	1428	0
1530	2	303	\N	1429	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
1826	1	2010-12-08	0	711	303
1827	1	2010-12-06	0	711	303
1828	1	2010-04-01	0	711	303
1829	1	2010-11-01	0	711	303
1830	1	2010-05-17	0	711	1417
1831	1	2010-10-07	0	711	1417
1832	1	2010-04-02	0	711	1417
1833	1	2010-03-19	0	711	1417
1834	1	2010-04-05	0	711	1418
1835	1	2010-02-17	0	711	1418
1836	1	2010-03-29	0	711	1419
1837	1	2010-08-16	0	711	1419
1839	1	2010-04-13	0	711	1422
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, name, color, notassignable) FROM stdin;
707	6	HOLIDAY	red	t
708	5	SICK_LEAVE	red	t
709	4	LEAVE	red	t
710	3	STRIKE	red	t
711	2	BANK_HOLIDAY	red	t
712	1	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode) FROM stdin;
505	1	303	COMPANY_CODE
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, name, enabled) FROM stdin;
2727	2	Oficial 1º	t
2728	1	Peon	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
1257	1	Xefe de Área ou Servizo	t	327681	\N
1259	1	Delineante proxectista	t	327681	\N
1260	1	Aprendiz maior de 18 anos	t	327681	\N
1261	1	Xefe de Taller	t	327681	\N
1262	1	Persoal de Buques	t	327681	\N
1263	1	Chofer de turismo	t	327681	\N
1264	1	Licenciado	t	327681	\N
1265	1	Profesional de siderúrxico de 2ª	t	327681	\N
1266	1	Viaxante	t	327681	\N
1267	1	Técnico de laboratorio	t	327681	\N
1268	1	Auxiliar	t	327681	\N
1269	1	Camareiro	t	327681	\N
1270	1	Técnico de organización	t	327681	\N
1271	1	Listeiro	t	327681	\N
1272	1	Debuxante proxectista	t	327681	\N
1273	1	Mestre Industrial	t	327681	\N
1274	1	Enxeñeiro	t	327681	\N
1275	1	Profesional de oficio de 3ª	t	327681	\N
1276	1	Dependente	t	327681	\N
1277	1	Telefonista	t	327681	\N
1130	3	Enxeñeiro electrónico	t	327680	\N
1118	3	Matemático	t	327680	\N
1122	3	Mecánico de instrumentos de precisión	t	327680	\N
1129	3	Desenvolvedor web e multimedia	t	327680	\N
1278	1	Enxeñeiro en informática	t	327680	\N
1125	3	Operador de máquinas pulidoras, galvanizadoras e recubridoras de metais	t	327680	\N
1154	3	Laminador	t	327680	\N
1134	3	Técnico en control de procesos	t	327680	\N
1145	3	Cortador	t	327680	\N
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
1141	3	Enxeñeiro medioambiental	t	327680	\N
1119	3	Cristaleiro	t	327680	\N
1246	1	Especialista	t	327681	\N
1247	1	Ordenanza	t	327681	\N
1248	1	Arquitecto	t	327681	\N
1249	1	Pesador	t	327681	\N
1250	1	Titulado superior de entrada	t	327681	\N
1251	1	Profesional de siderúrxico de 3ª	t	327681	\N
1252	1	Delineante de 1ª	t	327681	\N
1253	1	Delineante de 2ª	t	327681	\N
1254	1	Director de Área o Servizo	t	327681	\N
1255	1	Condutor de máquina	t	327681	\N
1256	1	Aprendiz de 17 anos	t	327681	\N
1160	3	Técnico da Web	t	327680	\N
1124	3	Moldeador	t	327680	\N
1163	3	Técnico en electrónica e telecomunicacións	t	327680	\N
1128	3	Carpinteiro	t	327680	\N
1132	3	Enxeñeiro técnico medioambiental	t	327680	\N
1111	3	Técnico en ciencias físicas e químicas	t	327680	\N
1126	3	Soldador	t	327680	\N
1113	3	Sondista	t	327680	\N
1114	3	Técnico en electromedicina	t	327680	\N
1123	3	Montador de cubertas	t	327680	\N
1133	3	Xerente	t	327680	\N
1183	3	Técnico en mecánica	t	327680	\N
1282	1	Torno	t	327683	\N
1283	1	Pulidora	t	327683	\N
1284	1	Galvanizadora	t	327683	\N
1170	3	Enxeñeiro en telecomunicacións	t	327680	\N
1190	3	Electricista	t	327680	\N
1142	3	Enxeñeiro de caminos, canles e portos	t	327680	\N
1153	3	Enxeñeiro técnico non clasificado	t	327680	\N
1158	3	Operador de fornos	t	327680	\N
1189	3	Administradores de sistemas	t	327680	\N
1193	3	Chapista	t	327680	\N
1149	3	Reparador	t	327680	\N
1150	3	Parqueteiro	t	327680	\N
1146	3	Axustador	t	327680	\N
1187	3	Xefe de almacén	t	327680	\N
1143	3	Enxeñeiro técnico en electricidade	t	327680	\N
1192	3	Enxeñeiro agrónomo, técnico agrícolas e afíns	t	327680	\N
1151	3	Xefe de taller	t	327680	\N
1162	3	Montador estrutura metálica	t	327680	\N
1155	3	Operador de máquinas de embalaxe, embotellamento e etiquetado	t	327680	\N
1144	3	Enxeñeiro técnico de obras públicas	t	327680	\N
1157	3	Enxeñeiro electricista	t	327680	\N
1182	3	Técnico en metalurxia e minas	t	327680	\N
1166	3	Escaiolista	t	327680	\N
1194	3	Operador en instalacións para a obtención e transformación de metais	t	327680	\N
1164	3	Supervisor	t	327680	\N
1191	3	Operador de grúas, camións montacargas e outros	t	327680	\N
1174	3	Fontaneiros	t	327680	\N
1148	3	Operador de caldeira	t	327680	\N
1161	3	Enxeñeiro técnico mecánico	t	327680	\N
1177	3	Analista de sistemas	t	327680	\N
1188	3	Enxeñeiro químico	t	327680	\N
1152	3	Operador de carretiñas elevadoras	t	327680	\N
1179	3	Pegador	t	327680	\N
1147	3	Químico	t	327680	\N
1167	3	Modelador	t	327680	\N
1195	3	Aplicador de revestimentos	t	327680	\N
1176	3	Delineante e deseñador técnico	t	327680	\N
1181	3	Técnico en electricidade	t	327680	\N
1196	3	Enxeñeiros geógrafos	t	327680	\N
1173	3	Enxeñeiro de produción	t	327680	\N
1168	3	Montadores-instaladores de placas de enerxía solar	t	327680	\N
1180	3	Desenvolvedor de software	t	327680	\N
1169	3	Modelista	t	327680	\N
1156	3	Diseñador de produtos	t	327680	\N
1159	3	Oxicortador	t	327680	\N
1175	3	Empregado de loxística e transportes	t	327680	\N
1165	3	Arquitecto	t	327680	\N
1221	1	Profesional de oficio especial	t	327681	\N
1222	1	Graduado social	t	327681	\N
1223	1	Chofer de camión	t	327681	\N
1224	1	Profesional de siderúrxico de 1ª	t	327681	\N
1225	1	Encargado	t	327681	\N
1226	1	Encargado de pequeno taller	t	327681	\N
1227	1	Profesional de oficio de 1ª	t	327681	\N
1228	1	Cociñeiro	t	327681	\N
1229	1	Arquitecto técnico	t	327681	\N
1230	1	Xefe de Grupo ou Capataces	t	327681	\N
1231	1	Aprendiz de 16 anos	t	327681	\N
1232	1	Enxeñeiro técnico	t	327681	\N
1233	1	ATS	t	327681	\N
1234	1	Profesional de oficio de 2ª	t	327681	\N
1235	1	Titulado de Grao Medio	t	327681	\N
1236	1	Analista programador	t	327681	\N
1237	1	Almaceneiro	t	327681	\N
1238	1	Conserxe	t	327681	\N
1239	1	Persoal de Diques	t	327681	\N
1240	1	Analista de sistemas	t	327681	\N
1241	1	Porteiro	t	327681	\N
1242	1	Caixeiro	t	327681	\N
1243	1	Contramestre	t	327681	\N
1244	1	Operador de ordenador	t	327681	\N
1245	1	Técnico administrativo	t	327681	\N
1258	1	Peón	t	327681	\N
1211	3	Físico	t	327680	\N
1212	3	Empregado de control de abastecemento e inventario	t	327680	\N
1202	3	Técnico de montaxe de instalacións	t	327680	\N
1210	3	Montador	t	327680	\N
1218	3	Ferreiro	t	327680	\N
1220	3	Instaladores de cerramentos metálicos	t	327680	\N
1203	3	Técnico en construción	t	327680	\N
1208	3	Montador-instalador de gas	t	327680	\N
1204	3	Ordeanza	t	327680	\N
1213	3	Enxeñeiro técnico en electrónica	t	327680	\N
1200	3	Pintor	t	327680	\N
1209	3	Enxeñeiro técnico químico	t	327680	\N
1197	3	Enxeñeiro técnico de minas, metalúrxicos e afíns	t	327680	\N
1215	3	Biólogo	t	327680	\N
1201	3	Enxeñeiro técnico en telecomunicacións	t	327680	\N
1214	3	Enxeñeiro superior non clasificado	t	327680	\N
1217	3	Mecánico	t	327680	\N
1219	3	Técnico e analista de laboratorio en química industrial	t	327680	\N
1199	3	Ebanista	t	327680	\N
1207	3	Caldereiro	t	327680	\N
1198	3	Director	t	327680	\N
1205	3	Empregado de oficina de servizos de produción	t	327680	\N
1216	3	Técnico en operacións de TIC e as comunicaciones	t	327680	\N
1206	3	Operador de serrerías, máquinas de contrachapado e outras	t	327680	\N
1172	3	Ensamblador	t	327680	\N
1171	3	Enxeñeiro mecánico	t	327680	\N
1135	3	Xeofísico	t	327680	\N
1116	3	Macheiro	t	327680	\N
1112	3	Meteorólogo	t	327680	\N
1186	3	Enxeñeiro técnico industrial e de produción	t	327680	\N
1137	3	Artesán	t	327680	\N
1184	3	Enxeñeiro técnico en topografía	t	327680	\N
1117	3	Xeólogo	t	327680	\N
1185	3	Matriceiro	t	327680	\N
1115	3	Arquitecto técnico	t	327680	\N
1131	3	Buceador	t	327680	\N
1178	3	Técnico en redes e sistemas informáticos	t	327680	\N
1138	3	Diseñador gráfico e multimedia	t	327680	\N
1139	3	Forxador	t	327680	\N
1140	3	Enxeñeiro industrial	t	327680	\N
1136	3	Instalador	t	327680	\N
1127	3	Enxeñeiros de minas, metalúrgicos e afíns	t	327680	\N
1121	3	Operador de máquina	t	327680	\N
1120	3	Pulidor	t	327680	\N
1279	1	Desarrollador	t	327682	\N
1280	1	Analista	t	327682	\N
1281	1	Coordinador	t	327682	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
10400	INDIRECT	16	3269	\N	1278	10365	t
10403	INDIRECT	16	\N	3340	1278	10365	t
10402	INDIRECT	16	\N	3340	1279	10364	t
10405	INDIRECT	16	3270	\N	1278	10365	t
10404	INDIRECT	16	3270	\N	1279	10364	t
10406	DIRECT	16	\N	3341	1278	\N	\N
10407	DIRECT	16	\N	3341	1281	\N	\N
10409	INDIRECT	16	3271	\N	1278	10406	t
10408	INDIRECT	16	3271	\N	1281	10407	t
10411	DIRECT	16	\N	3342	1281	\N	\N
10410	DIRECT	16	\N	3342	1278	\N	\N
10413	INDIRECT	16	3272	\N	1278	10410	t
10412	INDIRECT	16	3272	\N	1281	10411	t
10973	INDIRECT	13	3290	\N	1278	10948	t
4190	DIRECT	18	\N	2297	1278	\N	\N
10385	INDIRECT	16	3265	\N	1279	10364	t
10384	INDIRECT	16	3265	\N	1278	10365	t
10386	INDIRECT	16	\N	3336	1278	10365	t
10387	INDIRECT	16	\N	3336	1279	10364	t
10389	INDIRECT	16	3266	\N	1278	10365	t
10388	INDIRECT	16	3266	\N	1279	10364	t
10391	INDIRECT	16	\N	3337	1279	10364	t
10390	INDIRECT	16	\N	3337	1278	10365	t
10393	INDIRECT	16	3267	\N	1278	10365	t
10392	INDIRECT	16	3267	\N	1279	10364	t
10394	INDIRECT	16	\N	3338	1278	10365	t
10395	INDIRECT	16	\N	3338	1279	10364	t
10397	INDIRECT	16	3268	\N	1278	10365	t
10396	INDIRECT	16	3268	\N	1279	10364	t
10398	INDIRECT	16	\N	3339	1279	10364	t
10399	INDIRECT	16	\N	3339	1278	10365	t
10401	INDIRECT	16	3269	\N	1279	10364	t
4191	DIRECT	18	\N	2297	1279	\N	\N
4193	INDIRECT	18	\N	2298	1279	4191	t
4192	INDIRECT	18	\N	2298	1278	4190	t
4194	INDIRECT	18	3069	\N	1279	4191	t
4195	INDIRECT	18	3069	\N	1278	4190	t
4197	INDIRECT	18	\N	2299	1278	4190	t
4196	INDIRECT	18	\N	2299	1279	4191	t
4199	INDIRECT	18	3070	\N	1278	4190	t
4198	INDIRECT	18	3070	\N	1279	4191	t
4200	INDIRECT	18	\N	2300	1278	4190	t
4201	INDIRECT	18	\N	2300	1279	4191	t
4203	INDIRECT	18	3071	\N	1279	4191	t
4202	INDIRECT	18	3071	\N	1278	4190	t
4205	INDIRECT	18	\N	2301	1278	4190	t
4204	INDIRECT	18	\N	2301	1279	4191	t
4206	INDIRECT	18	3072	\N	1279	4191	t
4207	INDIRECT	18	3072	\N	1278	4190	t
4209	DIRECT	18	\N	2302	1279	\N	\N
4208	DIRECT	18	\N	2302	1278	\N	\N
4210	INDIRECT	18	\N	2303	1279	4209	t
4211	INDIRECT	18	\N	2303	1278	4208	t
4212	INDIRECT	18	3073	\N	1278	4208	t
4213	INDIRECT	18	3073	\N	1279	4209	t
4215	INDIRECT	18	\N	2304	1279	4209	t
4214	INDIRECT	18	\N	2304	1278	4208	t
5495	INDIRECT	17	3243	\N	1278	5490	t
5494	INDIRECT	17	3243	\N	1279	5491	t
5497	INDIRECT	17	\N	3204	1278	5490	t
5496	INDIRECT	17	\N	3204	1279	5491	t
5499	INDIRECT	17	3244	\N	1279	5491	t
5498	INDIRECT	17	3244	\N	1278	5490	t
5500	DIRECT	17	\N	3205	1278	\N	\N
5501	DIRECT	17	\N	3205	1279	\N	\N
5502	INDIRECT	17	\N	3206	1278	5500	t
5503	INDIRECT	17	\N	3206	1279	5501	t
5505	INDIRECT	17	3245	\N	1278	5500	t
5504	INDIRECT	17	3245	\N	1279	5501	t
5506	DIRECT	17	\N	3207	1278	\N	\N
5507	DIRECT	17	\N	3207	1279	\N	\N
5508	INDIRECT	17	\N	3208	1279	5507	t
10353	DIRECT	16	\N	3222	1278	\N	\N
4216	INDIRECT	18	3074	\N	1278	4208	t
4217	INDIRECT	18	3074	\N	1279	4209	t
4218	INDIRECT	18	\N	2305	1278	4208	t
4219	INDIRECT	18	\N	2305	1279	4209	t
4221	INDIRECT	18	3075	\N	1279	4209	t
4220	INDIRECT	18	3075	\N	1278	4208	t
4222	DIRECT	18	\N	2306	1279	\N	\N
4223	DIRECT	18	\N	2306	1278	\N	\N
4224	INDIRECT	18	\N	2307	1279	4222	t
4225	INDIRECT	18	\N	2307	1278	4223	t
4226	INDIRECT	18	3076	\N	1278	4223	t
4227	INDIRECT	18	3076	\N	1279	4222	t
4229	INDIRECT	18	\N	2308	1278	4223	t
4228	INDIRECT	18	\N	2308	1279	4222	t
4231	INDIRECT	18	3077	\N	1279	4222	t
4230	INDIRECT	18	3077	\N	1278	4223	t
5472	DIRECT	17	\N	2309	1278	\N	\N
5473	DIRECT	17	\N	2309	1279	\N	\N
5474	INDIRECT	17	\N	2310	1279	5473	t
5475	INDIRECT	17	\N	2310	1278	5472	t
5477	INDIRECT	17	3078	\N	1279	5473	t
5476	INDIRECT	17	3078	\N	1278	5472	t
5478	INDIRECT	17	\N	2311	1279	5473	t
5479	INDIRECT	17	\N	2311	1278	5472	t
5481	INDIRECT	17	3079	\N	1279	5473	t
5480	INDIRECT	17	3079	\N	1278	5472	t
5483	INDIRECT	17	\N	2312	1279	5473	t
5482	INDIRECT	17	\N	2312	1278	5472	t
5485	INDIRECT	17	3080	\N	1278	5472	t
5484	INDIRECT	17	3080	\N	1279	5473	t
5487	INDIRECT	17	\N	2313	1279	5473	t
5486	INDIRECT	17	\N	2313	1278	5472	t
5489	INDIRECT	17	3081	\N	1278	5472	t
5488	INDIRECT	17	3081	\N	1279	5473	t
5490	DIRECT	17	\N	3202	1278	\N	\N
5491	DIRECT	17	\N	3202	1279	\N	\N
5493	INDIRECT	17	\N	3203	1279	5491	t
5492	INDIRECT	17	\N	3203	1278	5490	t
10967	INDIRECT	13	\N	3362	1278	10948	t
10968	INDIRECT	13	3289	\N	1279	10949	t
10969	INDIRECT	13	3289	\N	1278	10948	t
10970	INDIRECT	13	\N	3363	1279	10949	t
10971	INDIRECT	13	\N	3363	1278	10948	t
10972	INDIRECT	13	3290	\N	1279	10949	t
10372	INDIRECT	16	3262	\N	1278	10365	t
10373	INDIRECT	16	3262	\N	1279	10364	t
10375	INDIRECT	16	\N	3333	1278	10365	t
10374	INDIRECT	16	\N	3333	1279	10364	t
10376	INDIRECT	16	3263	\N	1279	10364	t
10377	INDIRECT	16	3263	\N	1278	10365	t
10378	INDIRECT	16	\N	3334	1278	10365	t
10379	INDIRECT	16	\N	3334	1279	10364	t
10380	INDIRECT	16	3264	\N	1278	10365	t
10381	INDIRECT	16	3264	\N	1279	10364	t
10382	INDIRECT	16	\N	3335	1278	10365	t
10383	INDIRECT	16	\N	3335	1279	10364	t
10959	INDIRECT	13	\N	3360	1278	10948	t
10958	INDIRECT	13	\N	3360	1279	10949	t
10961	INDIRECT	13	3287	\N	1279	10949	t
10960	INDIRECT	13	3287	\N	1278	10948	t
10962	INDIRECT	13	\N	3361	1279	10949	t
10963	INDIRECT	13	\N	3361	1278	10948	t
10965	INDIRECT	13	3288	\N	1278	10948	t
10964	INDIRECT	13	3288	\N	1279	10949	t
10966	INDIRECT	13	\N	3362	1279	10949	t
5509	INDIRECT	17	\N	3208	1278	5506	t
5511	INDIRECT	17	3246	\N	1278	5506	t
5510	INDIRECT	17	3246	\N	1279	5507	t
10371	INDIRECT	16	\N	3231	1278	10365	t
10318	INDIRECT	16	\N	3212	1279	10308	t
10317	INDIRECT	16	\N	3212	1278	10307	t
10345	INDIRECT	16	\N	3220	1278	10343	t
10347	INDIRECT	16	3255	\N	1279	10344	t
10348	INDIRECT	16	3255	\N	1278	10343	t
10349	INDIRECT	16	\N	3221	1278	10343	t
10350	INDIRECT	16	\N	3221	1279	10344	t
10352	INDIRECT	16	3256	\N	1279	10344	t
10351	INDIRECT	16	3256	\N	1278	10343	t
10354	INDIRECT	16	\N	3223	1278	10353	t
10355	INDIRECT	16	3257	\N	1278	10353	t
10356	INDIRECT	16	\N	3224	1278	10353	t
10357	INDIRECT	16	3258	\N	1278	10353	t
10358	DIRECT	16	\N	3225	1280	\N	\N
10359	DIRECT	16	\N	3225	1278	\N	\N
10361	INDIRECT	16	\N	3226	1278	10359	t
10360	INDIRECT	16	\N	3226	1280	10358	t
10363	INDIRECT	16	3259	\N	1280	10358	t
10362	INDIRECT	16	3259	\N	1278	10359	t
10365	DIRECT	16	\N	3229	1278	\N	\N
10364	DIRECT	16	\N	3229	1279	\N	\N
10367	INDIRECT	16	\N	3230	1278	10365	t
10366	INDIRECT	16	\N	3230	1279	10364	t
10368	INDIRECT	16	3261	\N	1279	10364	t
10369	INDIRECT	16	3261	\N	1278	10365	t
10370	INDIRECT	16	\N	3231	1279	10364	t
10307	DIRECT	16	\N	3209	1278	\N	\N
10308	DIRECT	16	\N	3209	1279	\N	\N
10309	INDIRECT	16	\N	3210	1279	10308	t
10310	INDIRECT	16	\N	3210	1278	10307	t
10312	INDIRECT	16	3247	\N	1278	10307	t
10311	INDIRECT	16	3247	\N	1279	10308	t
10313	INDIRECT	16	\N	3211	1278	10307	t
10314	INDIRECT	16	\N	3211	1279	10308	t
10316	INDIRECT	16	3248	\N	1278	10307	t
10315	INDIRECT	16	3248	\N	1279	10308	t
10325	INDIRECT	16	3250	\N	1278	10322	t
10328	INDIRECT	16	\N	3215	1279	10321	t
10327	INDIRECT	16	\N	3215	1278	10322	t
10330	INDIRECT	16	3251	\N	1278	10322	t
10329	INDIRECT	16	3251	\N	1279	10321	t
10331	INDIRECT	16	\N	3216	1278	10322	t
10332	INDIRECT	16	\N	3216	1279	10321	t
10334	INDIRECT	16	3252	\N	1278	10322	t
10333	INDIRECT	16	3252	\N	1279	10321	t
10336	INDIRECT	16	\N	3217	1278	10322	t
10335	INDIRECT	16	\N	3217	1279	10321	t
10337	INDIRECT	16	3253	\N	1278	10322	t
10338	INDIRECT	16	3253	\N	1279	10321	t
10339	INDIRECT	16	\N	3218	1278	10322	t
10340	INDIRECT	16	\N	3218	1279	10321	t
10341	INDIRECT	16	3254	\N	1279	10321	t
10342	INDIRECT	16	3254	\N	1278	10322	t
10343	DIRECT	16	\N	3219	1278	\N	\N
10344	DIRECT	16	\N	3219	1279	\N	\N
10346	INDIRECT	16	\N	3220	1279	10344	t
10949	DIRECT	13	\N	3357	1279	\N	\N
10948	DIRECT	13	\N	3357	1278	\N	\N
10950	INDIRECT	13	\N	3358	1279	10949	t
10951	INDIRECT	13	\N	3358	1278	10948	t
10953	INDIRECT	13	3285	\N	1279	10949	t
10952	INDIRECT	13	3285	\N	1278	10948	t
10955	INDIRECT	13	\N	3359	1278	10948	t
10954	INDIRECT	13	\N	3359	1279	10949	t
10957	INDIRECT	13	3286	\N	1279	10949	t
10956	INDIRECT	13	3286	\N	1278	10948	t
10319	INDIRECT	16	3249	\N	1278	10307	t
10320	INDIRECT	16	3249	\N	1279	10308	t
10321	DIRECT	16	\N	3213	1279	\N	\N
10322	DIRECT	16	\N	3213	1278	\N	\N
10324	INDIRECT	16	\N	3214	1279	10321	t
10323	INDIRECT	16	\N	3214	1278	10322	t
10326	INDIRECT	16	3250	\N	1279	10321	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
1736	3	2010-01-15 13:50:42.661	\N	f	1282	1337
1737	2	2010-01-15 13:51:12.305	\N	f	1284	1339
1738	2	2010-01-15 17:17:12.701	\N	f	1278	1341
1739	2	2010-01-15 17:17:12.037	\N	f	1279	1341
1740	2	2010-01-15 17:47:00.839	\N	f	1278	1343
1742	2	2010-01-15 18:03:14.494	\N	f	1278	1345
1741	2	2010-01-15 18:03:11.25	\N	f	1280	1345
1722	3	2009-01-15 00:00:00	\N	f	1278	1320
1723	3	2009-01-15 00:00:00	\N	f	1281	1320
1728	3	2009-01-15 00:00:00	\N	f	1279	1328
1729	3	2009-01-15 00:00:00	\N	f	1278	1328
1725	4	2009-01-15 00:00:00	\N	f	1279	1322
1724	4	2009-01-15 00:00:00	\N	f	1278	1322
1721	2	2009-01-15 00:00:00	\N	f	1279	1314
1717	4	2009-01-15 00:00:00	\N	f	1278	1314
1730	3	2009-01-15 00:00:00	\N	f	1279	1330
1731	3	2009-01-15 00:00:00	\N	f	1278	1330
1718	4	2009-01-15 00:00:00	\N	f	1278	1316
1719	2	2009-01-15 00:00:00	\N	f	1281	1316
1720	2	2009-01-15 00:00:00	\N	f	1280	1316
1727	3	2009-01-15 00:00:00	\N	f	1278	1326
1726	3	2009-01-15 00:00:00	\N	f	1279	1326
1733	2	2010-01-15 13:46:33.82	\N	f	1234	1333
1732	2	2010-01-15 13:46:48.578	\N	f	1121	1333
1735	2	2010-01-15 13:48:17.108	\N	f	1212	1335
1734	2	2010-01-15 13:49:06.382	\N	f	1227	1335
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
327682	1	Rol proyecto	\N	t	t	t	1
327683	1	Tipos de máquina	\N	t	f	t	0
1	15	LEAVE	Leave	f	f	t	1
2	11	CATEGORY	Professional category	t	t	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
4	7	JOB	Job	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
327681	1	Clasificación de traballo	Clasificación de traballo	t	t	t	1
327680	3	Tipo de traballo	Tipo de traballo	t	t	t	1
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id, derived_allocation_id) FROM stdin;
13589	SPECIFIC_DAY	1	2	2009-12-18	1316	11900	\N	\N
13561	SPECIFIC_DAY	1	0	2010-01-03	1316	11900	\N	\N
13574	SPECIFIC_DAY	1	2	2010-01-15	1316	11900	\N	\N
13593	SPECIFIC_DAY	1	2	2009-12-14	1316	11900	\N	\N
13505	SPECIFIC_DAY	1	0	2010-01-16	1345	11898	\N	\N
13492	SPECIFIC_DAY	1	0	2009-12-27	1345	11898	\N	\N
13496	SPECIFIC_DAY	1	2	2010-01-01	1345	11898	\N	\N
13465	SPECIFIC_DAY	1	2	2010-01-11	1345	11898	\N	\N
13482	SPECIFIC_DAY	1	2	2009-12-30	1345	11898	\N	\N
13502	SPECIFIC_DAY	1	2	2009-12-29	1345	11898	\N	\N
13484	SPECIFIC_DAY	1	0	2010-01-10	1345	11898	\N	\N
13490	SPECIFIC_DAY	1	2	2010-01-13	1345	11898	\N	\N
13464	SPECIFIC_DAY	1	2	2009-12-22	1345	11898	\N	\N
13503	SPECIFIC_DAY	1	2	2010-01-21	1345	11898	\N	\N
13501	SPECIFIC_DAY	1	2	2010-01-04	1345	11898	\N	\N
13469	SPECIFIC_DAY	1	2	2010-01-12	1345	11898	\N	\N
13498	SPECIFIC_DAY	1	2	2009-12-15	1345	11898	\N	\N
13487	SPECIFIC_DAY	1	2	2009-12-18	1345	11898	\N	\N
13472	SPECIFIC_DAY	1	2	2010-01-20	1345	11898	\N	\N
13477	SPECIFIC_DAY	1	2	2010-01-06	1345	11898	\N	\N
13481	SPECIFIC_DAY	1	2	2009-12-24	1345	11898	\N	\N
13476	SPECIFIC_DAY	1	0	2010-01-09	1345	11898	\N	\N
13470	SPECIFIC_DAY	1	0	2010-01-24	1345	11898	\N	\N
13471	SPECIFIC_DAY	1	2	2009-12-17	1345	11898	\N	\N
13478	SPECIFIC_DAY	1	2	2009-12-23	1345	11898	\N	\N
13488	SPECIFIC_DAY	1	2	2009-12-14	1345	11898	\N	\N
13506	SPECIFIC_DAY	1	2	2010-01-26	1345	11898	\N	\N
13475	SPECIFIC_DAY	1	2	2010-01-07	1345	11898	\N	\N
13499	SPECIFIC_DAY	1	0	2010-01-02	1345	11898	\N	\N
13466	SPECIFIC_DAY	1	0	2009-12-19	1345	11898	\N	\N
13495	SPECIFIC_DAY	1	2	2010-01-19	1345	11898	\N	\N
13494	SPECIFIC_DAY	1	0	2010-01-23	1345	11898	\N	\N
13493	SPECIFIC_DAY	1	0	2010-01-17	1345	11898	\N	\N
13489	SPECIFIC_DAY	1	2	2009-12-25	1345	11898	\N	\N
13467	SPECIFIC_DAY	1	2	2010-01-08	1345	11898	\N	\N
13485	SPECIFIC_DAY	1	0	2010-01-03	1345	11898	\N	\N
13479	SPECIFIC_DAY	1	2	2009-12-16	1345	11898	\N	\N
13497	SPECIFIC_DAY	1	0	2009-12-26	1345	11898	\N	\N
13491	SPECIFIC_DAY	1	2	2010-01-15	1345	11898	\N	\N
13486	SPECIFIC_DAY	1	2	2009-12-21	1345	11898	\N	\N
13473	SPECIFIC_DAY	1	0	2009-12-20	1345	11898	\N	\N
13474	SPECIFIC_DAY	1	2	2009-12-28	1345	11898	\N	\N
13480	SPECIFIC_DAY	1	2	2010-01-05	1345	11898	\N	\N
13504	SPECIFIC_DAY	1	2	2010-01-22	1345	11898	\N	\N
13500	SPECIFIC_DAY	1	2	2009-12-31	1345	11898	\N	\N
13507	SPECIFIC_DAY	1	2	2010-01-14	1345	11898	\N	\N
13468	SPECIFIC_DAY	1	2	2010-01-18	1345	11898	\N	\N
13483	SPECIFIC_DAY	1	2	2010-01-25	1345	11898	\N	\N
11614	SPECIFIC_DAY	8	8	2009-12-17	1328	10680	\N	\N
11608	SPECIFIC_DAY	8	8	2009-12-15	1328	10680	\N	\N
11611	SPECIFIC_DAY	8	0	2009-12-20	1328	10680	\N	\N
11607	SPECIFIC_DAY	8	8	2009-12-18	1328	10680	\N	\N
11609	SPECIFIC_DAY	8	8	2009-12-21	1328	10680	\N	\N
11613	SPECIFIC_DAY	8	8	2009-12-14	1328	10680	\N	\N
11610	SPECIFIC_DAY	8	0	2009-12-19	1328	10680	\N	\N
11612	SPECIFIC_DAY	8	8	2009-12-16	1328	10680	\N	\N
13684	SPECIFIC_DAY	1	8	2009-12-15	1326	11903	\N	\N
13685	SPECIFIC_DAY	1	8	2009-12-14	1326	11903	\N	\N
11340	SPECIFIC_DAY	11	8	2009-12-17	1341	10645	\N	\N
11341	SPECIFIC_DAY	11	8	2009-12-16	1341	10645	\N	\N
11339	SPECIFIC_DAY	11	8	2009-12-15	1341	10645	\N	\N
11343	SPECIFIC_DAY	11	8	2009-12-18	1341	10645	\N	\N
11342	SPECIFIC_DAY	11	8	2009-12-14	1341	10645	\N	\N
12706	SPECIFIC_DAY	4	2	2009-12-25	1345	11837	\N	\N
12700	SPECIFIC_DAY	4	2	2010-01-07	1345	11837	\N	\N
12714	SPECIFIC_DAY	4	0	2009-12-20	1345	11837	\N	\N
12686	SPECIFIC_DAY	4	2	2009-12-15	1345	11837	\N	\N
12705	SPECIFIC_DAY	4	0	2010-01-02	1345	11837	\N	\N
12710	SPECIFIC_DAY	4	0	2010-01-10	1345	11837	\N	\N
12688	SPECIFIC_DAY	4	0	2010-01-17	1345	11837	\N	\N
12715	SPECIFIC_DAY	4	2	2010-01-06	1345	11837	\N	\N
12704	SPECIFIC_DAY	4	2	2009-12-17	1345	11837	\N	\N
12699	SPECIFIC_DAY	4	2	2009-12-16	1345	11837	\N	\N
12713	SPECIFIC_DAY	4	2	2009-12-28	1345	11837	\N	\N
12696	SPECIFIC_DAY	4	2	2009-12-14	1345	11837	\N	\N
12691	SPECIFIC_DAY	4	2	2010-01-14	1345	11837	\N	\N
12687	SPECIFIC_DAY	4	2	2010-01-19	1345	11837	\N	\N
12724	SPECIFIC_DAY	4	2	2010-01-13	1345	11837	\N	\N
12694	SPECIFIC_DAY	4	2	2010-01-01	1345	11837	\N	\N
12722	SPECIFIC_DAY	4	0	2009-12-19	1345	11837	\N	\N
12721	SPECIFIC_DAY	4	2	2010-01-11	1345	11837	\N	\N
12697	SPECIFIC_DAY	4	2	2010-01-12	1345	11837	\N	\N
12703	SPECIFIC_DAY	4	0	2010-01-09	1345	11837	\N	\N
12717	SPECIFIC_DAY	4	0	2010-01-16	1345	11837	\N	\N
12692	SPECIFIC_DAY	4	2	2009-12-31	1345	11837	\N	\N
12718	SPECIFIC_DAY	4	0	2009-12-27	1345	11837	\N	\N
12695	SPECIFIC_DAY	4	2	2010-01-22	1345	11837	\N	\N
12690	SPECIFIC_DAY	4	2	2010-01-18	1345	11837	\N	\N
12709	SPECIFIC_DAY	4	2	2009-12-29	1345	11837	\N	\N
12723	SPECIFIC_DAY	4	2	2009-12-18	1345	11837	\N	\N
12707	SPECIFIC_DAY	4	2	2009-12-24	1345	11837	\N	\N
12708	SPECIFIC_DAY	4	2	2010-01-20	1345	11837	\N	\N
12719	SPECIFIC_DAY	4	2	2010-01-15	1345	11837	\N	\N
12720	SPECIFIC_DAY	4	2	2009-12-30	1345	11837	\N	\N
12698	SPECIFIC_DAY	4	2	2009-12-22	1345	11837	\N	\N
12725	SPECIFIC_DAY	4	0	2010-01-03	1345	11837	\N	\N
12716	SPECIFIC_DAY	4	2	2009-12-21	1345	11837	\N	\N
12711	SPECIFIC_DAY	4	0	2009-12-26	1345	11837	\N	\N
12693	SPECIFIC_DAY	4	2	2010-01-08	1345	11837	\N	\N
12689	SPECIFIC_DAY	4	2	2010-01-04	1345	11837	\N	\N
12702	SPECIFIC_DAY	4	2	2009-12-23	1345	11837	\N	\N
12712	SPECIFIC_DAY	4	2	2010-01-21	1345	11837	\N	\N
12742	SPECIFIC_DAY	4	2	2010-01-11	1316	11838	\N	\N
12731	SPECIFIC_DAY	4	2	2010-01-18	1316	11838	\N	\N
12764	SPECIFIC_DAY	4	2	2009-12-25	1316	11838	\N	\N
12728	SPECIFIC_DAY	4	2	2010-01-08	1316	11838	\N	\N
12744	SPECIFIC_DAY	4	0	2010-01-17	1316	11838	\N	\N
12754	SPECIFIC_DAY	4	2	2010-01-01	1316	11838	\N	\N
12732	SPECIFIC_DAY	4	2	2010-01-14	1316	11838	\N	\N
12741	SPECIFIC_DAY	4	2	2009-12-15	1316	11838	\N	\N
12755	SPECIFIC_DAY	4	2	2010-01-05	1316	11838	\N	\N
12726	SPECIFIC_DAY	4	2	2009-12-21	1316	11838	\N	\N
12736	SPECIFIC_DAY	4	2	2009-12-23	1316	11838	\N	\N
12749	SPECIFIC_DAY	4	2	2009-12-18	1316	11838	\N	\N
12745	SPECIFIC_DAY	4	0	2010-01-16	1316	11838	\N	\N
12729	SPECIFIC_DAY	4	2	2010-01-22	1316	11838	\N	\N
12757	SPECIFIC_DAY	4	2	2009-12-24	1316	11838	\N	\N
12734	SPECIFIC_DAY	4	2	2009-12-31	1316	11838	\N	\N
12730	SPECIFIC_DAY	4	2	2010-01-07	1316	11838	\N	\N
12762	SPECIFIC_DAY	4	0	2010-01-02	1316	11838	\N	\N
12743	SPECIFIC_DAY	4	0	2010-01-09	1316	11838	\N	\N
12765	SPECIFIC_DAY	4	2	2010-01-13	1316	11838	\N	\N
12727	SPECIFIC_DAY	4	2	2010-01-15	1316	11838	\N	\N
12735	SPECIFIC_DAY	4	2	2010-01-06	1316	11838	\N	\N
12746	SPECIFIC_DAY	4	2	2009-12-16	1316	11838	\N	\N
12763	SPECIFIC_DAY	4	2	2010-01-04	1316	11838	\N	\N
12738	SPECIFIC_DAY	4	2	2010-01-12	1316	11838	\N	\N
12750	SPECIFIC_DAY	4	2	2009-12-29	1316	11838	\N	\N
12739	SPECIFIC_DAY	4	2	2009-12-28	1316	11838	\N	\N
12737	SPECIFIC_DAY	4	2	2010-01-21	1316	11838	\N	\N
12752	SPECIFIC_DAY	4	2	2009-12-22	1316	11838	\N	\N
12759	SPECIFIC_DAY	4	2	2009-12-17	1316	11838	\N	\N
12751	SPECIFIC_DAY	4	2	2010-01-20	1316	11838	\N	\N
12756	SPECIFIC_DAY	4	0	2010-01-10	1316	11838	\N	\N
12760	SPECIFIC_DAY	4	0	2009-12-27	1316	11838	\N	\N
12733	SPECIFIC_DAY	4	0	2009-12-26	1316	11838	\N	\N
12758	SPECIFIC_DAY	4	2	2009-12-30	1316	11838	\N	\N
12761	SPECIFIC_DAY	4	2	2009-12-14	1316	11838	\N	\N
12753	SPECIFIC_DAY	4	2	2010-01-19	1316	11838	\N	\N
12740	SPECIFIC_DAY	4	0	2009-12-20	1316	11838	\N	\N
12748	SPECIFIC_DAY	4	0	2010-01-03	1316	11838	\N	\N
12747	SPECIFIC_DAY	4	0	2009-12-19	1316	11838	\N	\N
11696	SPECIFIC_DAY	7	8	2009-12-17	1322	10692	\N	\N
11694	SPECIFIC_DAY	7	8	2009-12-16	1322	10692	\N	\N
11697	SPECIFIC_DAY	7	8	2009-12-15	1322	10692	\N	\N
11698	SPECIFIC_DAY	7	0	2009-12-19	1322	10692	\N	\N
11693	SPECIFIC_DAY	7	8	2009-12-21	1322	10692	\N	\N
11692	SPECIFIC_DAY	7	0	2009-12-20	1322	10692	\N	\N
11695	SPECIFIC_DAY	7	8	2009-12-14	1322	10692	\N	\N
11699	SPECIFIC_DAY	7	8	2009-12-18	1322	10692	\N	\N
12787	SPECIFIC_DAY	4	2	2009-12-18	1343	11839	\N	\N
12779	SPECIFIC_DAY	4	0	2009-12-19	1343	11839	\N	\N
12775	SPECIFIC_DAY	4	2	2009-12-22	1343	11839	\N	\N
12774	SPECIFIC_DAY	4	0	2009-12-20	1343	11839	\N	\N
12777	SPECIFIC_DAY	4	2	2009-12-21	1343	11839	\N	\N
12786	SPECIFIC_DAY	4	2	2009-12-16	1343	11839	\N	\N
12778	SPECIFIC_DAY	4	2	2009-12-29	1343	11839	\N	\N
12784	SPECIFIC_DAY	4	0	2009-12-26	1343	11839	\N	\N
12781	SPECIFIC_DAY	4	2	2009-12-25	1343	11839	\N	\N
12780	SPECIFIC_DAY	4	2	2009-12-28	1343	11839	\N	\N
12783	SPECIFIC_DAY	4	2	2009-12-17	1343	11839	\N	\N
12773	SPECIFIC_DAY	4	2	2009-12-23	1343	11839	\N	\N
12785	SPECIFIC_DAY	4	2	2009-12-14	1343	11839	\N	\N
12776	SPECIFIC_DAY	4	2	2009-12-15	1343	11839	\N	\N
12782	SPECIFIC_DAY	4	2	2009-12-24	1343	11839	\N	\N
12788	SPECIFIC_DAY	4	0	2009-12-27	1343	11839	\N	\N
10730	SPECIFIC_DAY	18	8	2009-12-14	1330	10618	\N	\N
13618	SPECIFIC_DAY	1	4	2009-12-15	1316	11901	\N	\N
13636	SPECIFIC_DAY	1	4	2010-01-13	1316	11901	\N	\N
13631	SPECIFIC_DAY	1	0	2010-01-09	1316	11901	\N	\N
13629	SPECIFIC_DAY	1	4	2009-12-17	1316	11901	\N	\N
13619	SPECIFIC_DAY	1	4	2010-01-20	1316	11901	\N	\N
13620	SPECIFIC_DAY	1	4	2010-01-08	1316	11901	\N	\N
13599	SPECIFIC_DAY	1	4	2010-01-26	1316	11901	\N	\N
13634	SPECIFIC_DAY	1	4	2009-12-23	1316	11901	\N	\N
13605	SPECIFIC_DAY	1	0	2010-01-17	1316	11901	\N	\N
13632	SPECIFIC_DAY	1	4	2010-01-22	1316	11901	\N	\N
13601	SPECIFIC_DAY	1	0	2010-01-24	1316	11901	\N	\N
13627	SPECIFIC_DAY	1	4	2010-01-19	1316	11901	\N	\N
13603	SPECIFIC_DAY	1	0	2009-12-20	1316	11901	\N	\N
13626	SPECIFIC_DAY	1	4	2010-01-01	1316	11901	\N	\N
13638	SPECIFIC_DAY	1	0	2010-01-02	1316	11901	\N	\N
13622	SPECIFIC_DAY	1	0	2009-12-27	1316	11901	\N	\N
13606	SPECIFIC_DAY	1	0	2009-12-19	1316	11901	\N	\N
13602	SPECIFIC_DAY	1	4	2010-01-15	1316	11901	\N	\N
13615	SPECIFIC_DAY	1	4	2009-12-29	1316	11901	\N	\N
13639	SPECIFIC_DAY	1	0	2010-01-16	1316	11901	\N	\N
13624	SPECIFIC_DAY	1	4	2010-01-21	1316	11901	\N	\N
13610	SPECIFIC_DAY	1	4	2010-01-06	1316	11901	\N	\N
13612	SPECIFIC_DAY	1	4	2009-12-31	1316	11901	\N	\N
13637	SPECIFIC_DAY	1	4	2009-12-30	1316	11901	\N	\N
13609	SPECIFIC_DAY	1	4	2010-01-18	1316	11901	\N	\N
13614	SPECIFIC_DAY	1	4	2010-01-07	1316	11901	\N	\N
13600	SPECIFIC_DAY	1	4	2009-12-25	1316	11901	\N	\N
13598	SPECIFIC_DAY	1	4	2009-12-24	1316	11901	\N	\N
13628	SPECIFIC_DAY	1	4	2009-12-21	1316	11901	\N	\N
13621	SPECIFIC_DAY	1	4	2009-12-16	1316	11901	\N	\N
13608	SPECIFIC_DAY	1	0	2010-01-10	1316	11901	\N	\N
13611	SPECIFIC_DAY	1	4	2010-01-04	1316	11901	\N	\N
13625	SPECIFIC_DAY	1	4	2010-01-14	1316	11901	\N	\N
13613	SPECIFIC_DAY	1	4	2009-12-22	1316	11901	\N	\N
13630	SPECIFIC_DAY	1	4	2010-01-25	1316	11901	\N	\N
13617	SPECIFIC_DAY	1	4	2009-12-14	1316	11901	\N	\N
13607	SPECIFIC_DAY	1	4	2010-01-11	1316	11901	\N	\N
13596	SPECIFIC_DAY	1	0	2009-12-26	1316	11901	\N	\N
13635	SPECIFIC_DAY	1	4	2010-01-05	1316	11901	\N	\N
13597	SPECIFIC_DAY	1	0	2010-01-03	1316	11901	\N	\N
13616	SPECIFIC_DAY	1	4	2009-12-18	1316	11901	\N	\N
13633	SPECIFIC_DAY	1	0	2010-01-23	1316	11901	\N	\N
13623	SPECIFIC_DAY	1	4	2010-01-12	1316	11901	\N	\N
13604	SPECIFIC_DAY	1	4	2009-12-28	1316	11901	\N	\N
13675	SPECIFIC_DAY	1	0	2010-01-17	1345	11902	\N	\N
13653	SPECIFIC_DAY	1	4	2009-12-15	1345	11902	\N	\N
13646	SPECIFIC_DAY	1	4	2010-01-20	1345	11902	\N	\N
13666	SPECIFIC_DAY	1	4	2009-12-14	1345	11902	\N	\N
13644	SPECIFIC_DAY	1	4	2009-12-28	1345	11902	\N	\N
13658	SPECIFIC_DAY	1	4	2010-01-07	1345	11902	\N	\N
13651	SPECIFIC_DAY	1	0	2010-01-02	1345	11902	\N	\N
13681	SPECIFIC_DAY	1	0	2010-01-09	1345	11902	\N	\N
13667	SPECIFIC_DAY	1	0	2009-12-27	1345	11902	\N	\N
13683	SPECIFIC_DAY	1	4	2009-12-23	1345	11902	\N	\N
13660	SPECIFIC_DAY	1	4	2010-01-14	1345	11902	\N	\N
13655	SPECIFIC_DAY	1	4	2010-01-05	1345	11902	\N	\N
13679	SPECIFIC_DAY	1	0	2010-01-10	1345	11902	\N	\N
13676	SPECIFIC_DAY	1	4	2009-12-25	1345	11902	\N	\N
13662	SPECIFIC_DAY	1	4	2009-12-29	1345	11902	\N	\N
13680	SPECIFIC_DAY	1	4	2010-01-21	1345	11902	\N	\N
13672	SPECIFIC_DAY	1	4	2010-01-13	1345	11902	\N	\N
13674	SPECIFIC_DAY	1	4	2010-01-25	1345	11902	\N	\N
13640	SPECIFIC_DAY	1	4	2010-01-22	1345	11902	\N	\N
13677	SPECIFIC_DAY	1	4	2009-12-22	1345	11902	\N	\N
13648	SPECIFIC_DAY	1	4	2009-12-16	1345	11902	\N	\N
13643	SPECIFIC_DAY	1	4	2010-01-26	1345	11902	\N	\N
13682	SPECIFIC_DAY	1	0	2009-12-26	1345	11902	\N	\N
13671	SPECIFIC_DAY	1	4	2009-12-31	1345	11902	\N	\N
13642	SPECIFIC_DAY	1	4	2010-01-01	1345	11902	\N	\N
13673	SPECIFIC_DAY	1	0	2010-01-23	1345	11902	\N	\N
13668	SPECIFIC_DAY	1	4	2009-12-17	1345	11902	\N	\N
13641	SPECIFIC_DAY	1	4	2009-12-18	1345	11902	\N	\N
13645	SPECIFIC_DAY	1	4	2010-01-06	1345	11902	\N	\N
13663	SPECIFIC_DAY	1	4	2010-01-08	1345	11902	\N	\N
13650	SPECIFIC_DAY	1	4	2010-01-11	1345	11902	\N	\N
13661	SPECIFIC_DAY	1	0	2009-12-19	1345	11902	\N	\N
13669	SPECIFIC_DAY	1	0	2010-01-24	1345	11902	\N	\N
13678	SPECIFIC_DAY	1	0	2010-01-03	1345	11902	\N	\N
13670	SPECIFIC_DAY	1	4	2010-01-19	1345	11902	\N	\N
13652	SPECIFIC_DAY	1	0	2010-01-16	1345	11902	\N	\N
13647	SPECIFIC_DAY	1	0	2009-12-20	1345	11902	\N	\N
13649	SPECIFIC_DAY	1	4	2010-01-12	1345	11902	\N	\N
13659	SPECIFIC_DAY	1	4	2009-12-24	1345	11902	\N	\N
13665	SPECIFIC_DAY	1	4	2009-12-21	1345	11902	\N	\N
13654	SPECIFIC_DAY	1	4	2009-12-30	1345	11902	\N	\N
13664	SPECIFIC_DAY	1	4	2010-01-18	1345	11902	\N	\N
13656	SPECIFIC_DAY	1	4	2010-01-04	1345	11902	\N	\N
13657	SPECIFIC_DAY	1	4	2010-01-15	1345	11902	\N	\N
13028	SPECIFIC_DAY	3	0	2009-12-19	1316	11847	\N	\N
13026	SPECIFIC_DAY	3	2	2009-12-22	1316	11847	\N	\N
13044	SPECIFIC_DAY	3	2	2010-01-04	1316	11847	\N	\N
13032	SPECIFIC_DAY	3	2	2009-12-14	1316	11847	\N	\N
13025	SPECIFIC_DAY	3	2	2010-01-05	1316	11847	\N	\N
13043	SPECIFIC_DAY	3	2	2009-12-24	1316	11847	\N	\N
13049	SPECIFIC_DAY	3	0	2010-01-03	1316	11847	\N	\N
13038	SPECIFIC_DAY	3	2	2009-12-29	1316	11847	\N	\N
12701	SPECIFIC_DAY	4	2	2010-01-05	1345	11837	\N	\N
13031	SPECIFIC_DAY	3	2	2010-01-07	1316	11847	\N	\N
13034	SPECIFIC_DAY	3	2	2010-01-08	1316	11847	\N	\N
13027	SPECIFIC_DAY	3	0	2009-12-20	1316	11847	\N	\N
13029	SPECIFIC_DAY	3	2	2010-01-06	1316	11847	\N	\N
13040	SPECIFIC_DAY	3	0	2009-12-26	1316	11847	\N	\N
13041	SPECIFIC_DAY	3	2	2009-12-31	1316	11847	\N	\N
13042	SPECIFIC_DAY	3	2	2009-12-16	1316	11847	\N	\N
13050	SPECIFIC_DAY	3	2	2009-12-30	1316	11847	\N	\N
13030	SPECIFIC_DAY	3	2	2009-12-21	1316	11847	\N	\N
13036	SPECIFIC_DAY	3	2	2009-12-18	1316	11847	\N	\N
13033	SPECIFIC_DAY	3	2	2009-12-15	1316	11847	\N	\N
13048	SPECIFIC_DAY	3	2	2009-12-23	1316	11847	\N	\N
13037	SPECIFIC_DAY	3	2	2009-12-17	1316	11847	\N	\N
13046	SPECIFIC_DAY	3	2	2009-12-28	1316	11847	\N	\N
13047	SPECIFIC_DAY	3	0	2009-12-27	1316	11847	\N	\N
13035	SPECIFIC_DAY	3	2	2009-12-25	1316	11847	\N	\N
13039	SPECIFIC_DAY	3	2	2010-01-01	1316	11847	\N	\N
13045	SPECIFIC_DAY	3	0	2010-01-02	1316	11847	\N	\N
12968	SPECIFIC_DAY	3	2	2009-12-14	1320	11845	\N	\N
12973	SPECIFIC_DAY	3	2	2010-01-06	1320	11845	\N	\N
12975	SPECIFIC_DAY	3	2	2009-12-29	1320	11845	\N	\N
12979	SPECIFIC_DAY	3	2	2010-01-05	1320	11845	\N	\N
12962	SPECIFIC_DAY	3	2	2010-01-08	1320	11845	\N	\N
12967	SPECIFIC_DAY	3	2	2010-01-07	1320	11845	\N	\N
12970	SPECIFIC_DAY	3	2	2009-12-18	1320	11845	\N	\N
12972	SPECIFIC_DAY	3	0	2009-12-20	1320	11845	\N	\N
12963	SPECIFIC_DAY	3	2	2009-12-22	1320	11845	\N	\N
12978	SPECIFIC_DAY	3	2	2010-01-04	1320	11845	\N	\N
12971	SPECIFIC_DAY	3	2	2009-12-25	1320	11845	\N	\N
12976	SPECIFIC_DAY	3	2	2009-12-21	1320	11845	\N	\N
12974	SPECIFIC_DAY	3	0	2009-12-27	1320	11845	\N	\N
12966	SPECIFIC_DAY	3	0	2009-12-26	1320	11845	\N	\N
12969	SPECIFIC_DAY	3	0	2010-01-02	1320	11845	\N	\N
12965	SPECIFIC_DAY	3	2	2009-12-15	1320	11845	\N	\N
12964	SPECIFIC_DAY	3	0	2009-12-19	1320	11845	\N	\N
12977	SPECIFIC_DAY	3	2	2010-01-01	1320	11845	\N	\N
13002	SPECIFIC_DAY	3	1	2009-12-23	1345	11846	\N	\N
12988	SPECIFIC_DAY	3	0	2009-12-26	1345	11846	\N	\N
12985	SPECIFIC_DAY	3	1	2010-01-21	1345	11846	\N	\N
13009	SPECIFIC_DAY	3	1	2010-01-22	1345	11846	\N	\N
12992	SPECIFIC_DAY	3	0	2010-01-17	1345	11846	\N	\N
13001	SPECIFIC_DAY	3	0	2010-01-24	1345	11846	\N	\N
13024	SPECIFIC_DAY	3	1	2009-12-22	1345	11846	\N	\N
13020	SPECIFIC_DAY	3	1	2009-12-18	1345	11846	\N	\N
12995	SPECIFIC_DAY	3	1	2010-01-26	1345	11846	\N	\N
13023	SPECIFIC_DAY	3	1	2009-12-31	1345	11846	\N	\N
13011	SPECIFIC_DAY	3	1	2010-01-15	1345	11846	\N	\N
12997	SPECIFIC_DAY	3	1	2009-12-17	1345	11846	\N	\N
13010	SPECIFIC_DAY	3	0	2010-01-10	1345	11846	\N	\N
13007	SPECIFIC_DAY	3	1	2009-12-16	1345	11846	\N	\N
12956	SPECIFIC_DAY	3	0	2010-01-03	1320	11845	\N	\N
12957	SPECIFIC_DAY	3	2	2009-12-24	1320	11845	\N	\N
12959	SPECIFIC_DAY	3	2	2009-12-28	1320	11845	\N	\N
12960	SPECIFIC_DAY	3	2	2009-12-17	1320	11845	\N	\N
12980	SPECIFIC_DAY	3	2	2009-12-23	1320	11845	\N	\N
12955	SPECIFIC_DAY	3	2	2009-12-16	1320	11845	\N	\N
12961	SPECIFIC_DAY	3	2	2009-12-30	1320	11845	\N	\N
12958	SPECIFIC_DAY	3	2	2009-12-31	1320	11845	\N	\N
13015	SPECIFIC_DAY	3	1	2010-01-12	1345	11846	\N	\N
13006	SPECIFIC_DAY	3	1	2009-12-28	1345	11846	\N	\N
13014	SPECIFIC_DAY	3	1	2009-12-30	1345	11846	\N	\N
12982	SPECIFIC_DAY	3	1	2009-12-25	1345	11846	\N	\N
12990	SPECIFIC_DAY	3	0	2009-12-20	1345	11846	\N	\N
12998	SPECIFIC_DAY	3	1	2010-01-19	1345	11846	\N	\N
13008	SPECIFIC_DAY	3	1	2010-01-06	1345	11846	\N	\N
13004	SPECIFIC_DAY	3	0	2010-01-02	1345	11846	\N	\N
13017	SPECIFIC_DAY	3	1	2010-01-14	1345	11846	\N	\N
13000	SPECIFIC_DAY	3	1	2010-01-01	1345	11846	\N	\N
13019	SPECIFIC_DAY	3	1	2009-12-29	1345	11846	\N	\N
13018	SPECIFIC_DAY	3	1	2010-01-07	1345	11846	\N	\N
13005	SPECIFIC_DAY	3	0	2010-01-16	1345	11846	\N	\N
12981	SPECIFIC_DAY	3	1	2010-01-05	1345	11846	\N	\N
12999	SPECIFIC_DAY	3	0	2009-12-19	1345	11846	\N	\N
12989	SPECIFIC_DAY	3	1	2010-01-08	1345	11846	\N	\N
12987	SPECIFIC_DAY	3	1	2009-12-24	1345	11846	\N	\N
13021	SPECIFIC_DAY	3	1	2010-01-13	1345	11846	\N	\N
13012	SPECIFIC_DAY	3	0	2010-01-03	1345	11846	\N	\N
12983	SPECIFIC_DAY	3	1	2010-01-25	1345	11846	\N	\N
12996	SPECIFIC_DAY	3	1	2009-12-15	1345	11846	\N	\N
12984	SPECIFIC_DAY	3	1	2010-01-20	1345	11846	\N	\N
12986	SPECIFIC_DAY	3	1	2009-12-21	1345	11846	\N	\N
12991	SPECIFIC_DAY	3	0	2010-01-23	1345	11846	\N	\N
13003	SPECIFIC_DAY	3	0	2009-12-27	1345	11846	\N	\N
13022	SPECIFIC_DAY	3	0	2010-01-09	1345	11846	\N	\N
12993	SPECIFIC_DAY	3	1	2009-12-14	1345	11846	\N	\N
13013	SPECIFIC_DAY	3	1	2010-01-04	1345	11846	\N	\N
13016	SPECIFIC_DAY	3	1	2010-01-18	1345	11846	\N	\N
12994	SPECIFIC_DAY	3	1	2010-01-11	1345	11846	\N	\N
11108	SPECIFIC_DAY	15	8	2009-12-15	1314	10633	\N	\N
11109	SPECIFIC_DAY	15	8	2009-12-17	1314	10633	\N	\N
11107	SPECIFIC_DAY	15	8	2009-12-18	1314	10633	\N	\N
11106	SPECIFIC_DAY	15	8	2009-12-14	1314	10633	\N	\N
11110	SPECIFIC_DAY	15	8	2009-12-16	1314	10633	\N	\N
13520	SPECIFIC_DAY	1	0	2009-12-26	1320	11899	\N	\N
13513	SPECIFIC_DAY	1	0	2010-01-23	1320	11899	\N	\N
13542	SPECIFIC_DAY	1	4	2009-12-17	1320	11899	\N	\N
13508	SPECIFIC_DAY	1	4	2009-12-21	1320	11899	\N	\N
13533	SPECIFIC_DAY	1	4	2010-01-22	1320	11899	\N	\N
13511	SPECIFIC_DAY	1	4	2009-12-22	1320	11899	\N	\N
13509	SPECIFIC_DAY	1	4	2010-01-26	1320	11899	\N	\N
13547	SPECIFIC_DAY	1	0	2010-01-16	1320	11899	\N	\N
13522	SPECIFIC_DAY	1	0	2010-01-09	1320	11899	\N	\N
13544	SPECIFIC_DAY	1	0	2009-12-19	1320	11899	\N	\N
13525	SPECIFIC_DAY	1	0	2010-01-10	1320	11899	\N	\N
13518	SPECIFIC_DAY	1	4	2010-01-04	1320	11899	\N	\N
13532	SPECIFIC_DAY	1	4	2010-01-15	1320	11899	\N	\N
13514	SPECIFIC_DAY	1	4	2009-12-24	1320	11899	\N	\N
13510	SPECIFIC_DAY	1	0	2010-01-17	1320	11899	\N	\N
13512	SPECIFIC_DAY	1	4	2009-12-25	1320	11899	\N	\N
13517	SPECIFIC_DAY	1	4	2010-01-08	1320	11899	\N	\N
13536	SPECIFIC_DAY	1	4	2010-01-14	1320	11899	\N	\N
13523	SPECIFIC_DAY	1	4	2010-01-13	1320	11899	\N	\N
13526	SPECIFIC_DAY	1	4	2010-01-19	1320	11899	\N	\N
13549	SPECIFIC_DAY	1	4	2010-01-20	1320	11899	\N	\N
13521	SPECIFIC_DAY	1	4	2010-01-05	1320	11899	\N	\N
13527	SPECIFIC_DAY	1	4	2010-01-11	1320	11899	\N	\N
13529	SPECIFIC_DAY	1	4	2009-12-29	1320	11899	\N	\N
13531	SPECIFIC_DAY	1	4	2009-12-23	1320	11899	\N	\N
13541	SPECIFIC_DAY	1	4	2010-01-01	1320	11899	\N	\N
13540	SPECIFIC_DAY	1	4	2009-12-16	1320	11899	\N	\N
13535	SPECIFIC_DAY	1	4	2009-12-31	1320	11899	\N	\N
13515	SPECIFIC_DAY	1	4	2009-12-18	1320	11899	\N	\N
13516	SPECIFIC_DAY	1	0	2009-12-27	1320	11899	\N	\N
13524	SPECIFIC_DAY	1	0	2010-01-02	1320	11899	\N	\N
13528	SPECIFIC_DAY	1	4	2010-01-21	1320	11899	\N	\N
13546	SPECIFIC_DAY	1	0	2009-12-20	1320	11899	\N	\N
13550	SPECIFIC_DAY	1	4	2009-12-15	1320	11899	\N	\N
13534	SPECIFIC_DAY	1	4	2010-01-25	1320	11899	\N	\N
13545	SPECIFIC_DAY	1	4	2009-12-14	1320	11899	\N	\N
13519	SPECIFIC_DAY	1	0	2010-01-03	1320	11899	\N	\N
13530	SPECIFIC_DAY	1	4	2009-12-30	1320	11899	\N	\N
13539	SPECIFIC_DAY	1	4	2010-01-18	1320	11899	\N	\N
13537	SPECIFIC_DAY	1	4	2010-01-07	1320	11899	\N	\N
13551	SPECIFIC_DAY	1	0	2010-01-24	1320	11899	\N	\N
13548	SPECIFIC_DAY	1	4	2009-12-28	1320	11899	\N	\N
13543	SPECIFIC_DAY	1	4	2010-01-06	1320	11899	\N	\N
13538	SPECIFIC_DAY	1	4	2010-01-12	1320	11899	\N	\N
13559	SPECIFIC_DAY	1	2	2010-01-05	1316	11900	\N	\N
13571	SPECIFIC_DAY	1	0	2009-12-19	1316	11900	\N	\N
13590	SPECIFIC_DAY	1	2	2009-12-17	1316	11900	\N	\N
13562	SPECIFIC_DAY	1	2	2010-01-18	1316	11900	\N	\N
13579	SPECIFIC_DAY	1	2	2009-12-28	1316	11900	\N	\N
13563	SPECIFIC_DAY	1	2	2010-01-06	1316	11900	\N	\N
13570	SPECIFIC_DAY	1	0	2010-01-02	1316	11900	\N	\N
13556	SPECIFIC_DAY	1	2	2009-12-24	1316	11900	\N	\N
13558	SPECIFIC_DAY	1	2	2009-12-23	1316	11900	\N	\N
13591	SPECIFIC_DAY	1	0	2010-01-23	1316	11900	\N	\N
13575	SPECIFIC_DAY	1	0	2010-01-16	1316	11900	\N	\N
13576	SPECIFIC_DAY	1	2	2010-01-19	1316	11900	\N	\N
13583	SPECIFIC_DAY	1	2	2010-01-22	1316	11900	\N	\N
13552	SPECIFIC_DAY	1	2	2009-12-25	1316	11900	\N	\N
13588	SPECIFIC_DAY	1	2	2010-01-14	1316	11900	\N	\N
13567	SPECIFIC_DAY	1	2	2009-12-31	1316	11900	\N	\N
13594	SPECIFIC_DAY	1	2	2010-01-01	1316	11900	\N	\N
13555	SPECIFIC_DAY	1	0	2009-12-27	1316	11900	\N	\N
13595	SPECIFIC_DAY	1	2	2010-01-12	1316	11900	\N	\N
13584	SPECIFIC_DAY	1	2	2010-01-20	1316	11900	\N	\N
13582	SPECIFIC_DAY	1	0	2010-01-10	1316	11900	\N	\N
13553	SPECIFIC_DAY	1	0	2010-01-24	1316	11900	\N	\N
13585	SPECIFIC_DAY	1	0	2010-01-17	1316	11900	\N	\N
13568	SPECIFIC_DAY	1	2	2010-01-04	1316	11900	\N	\N
13592	SPECIFIC_DAY	1	2	2009-12-15	1316	11900	\N	\N
13560	SPECIFIC_DAY	1	2	2010-01-08	1316	11900	\N	\N
13573	SPECIFIC_DAY	1	2	2009-12-16	1316	11900	\N	\N
13566	SPECIFIC_DAY	1	2	2010-01-26	1316	11900	\N	\N
13564	SPECIFIC_DAY	1	0	2009-12-26	1316	11900	\N	\N
13580	SPECIFIC_DAY	1	0	2010-01-09	1316	11900	\N	\N
13577	SPECIFIC_DAY	1	2	2010-01-13	1316	11900	\N	\N
13587	SPECIFIC_DAY	1	2	2010-01-21	1316	11900	\N	\N
13572	SPECIFIC_DAY	1	2	2010-01-07	1316	11900	\N	\N
13565	SPECIFIC_DAY	1	2	2009-12-30	1316	11900	\N	\N
13581	SPECIFIC_DAY	1	0	2009-12-20	1316	11900	\N	\N
13554	SPECIFIC_DAY	1	2	2010-01-11	1316	11900	\N	\N
13557	SPECIFIC_DAY	1	2	2009-12-21	1316	11900	\N	\N
13586	SPECIFIC_DAY	1	2	2009-12-22	1316	11900	\N	\N
13569	SPECIFIC_DAY	1	2	2009-12-29	1316	11900	\N	\N
13578	SPECIFIC_DAY	1	2	2010-01-25	1316	11900	\N	\N
24846	SPECIFIC_DAY	0	8	2010-02-03	1341	10665	\N	\N
24847	SPECIFIC_DAY	0	0	2010-01-30	1341	10665	\N	\N
24848	SPECIFIC_DAY	0	0	2010-01-31	1341	10665	\N	\N
24849	SPECIFIC_DAY	0	8	2010-02-02	1341	10665	\N	\N
24850	SPECIFIC_DAY	0	8	2010-02-01	1341	10665	\N	\N
24851	SPECIFIC_DAY	0	8	2010-01-11	1341	10666	\N	\N
24852	SPECIFIC_DAY	0	0	2010-01-10	1341	10666	\N	\N
24853	SPECIFIC_DAY	0	8	2010-01-12	1341	10666	\N	\N
24854	SPECIFIC_DAY	0	8	2010-01-07	1341	10666	\N	\N
24855	SPECIFIC_DAY	0	8	2010-01-08	1341	10666	\N	\N
24856	SPECIFIC_DAY	0	8	2010-01-13	1341	10666	\N	\N
24857	SPECIFIC_DAY	0	0	2010-01-09	1341	10666	\N	\N
24858	SPECIFIC_DAY	0	8	2010-01-06	1341	10666	\N	\N
24859	SPECIFIC_DAY	0	8	2010-01-27	1341	10667	\N	\N
24860	SPECIFIC_DAY	0	8	2010-01-26	1341	10667	\N	\N
24861	SPECIFIC_DAY	0	0	2010-01-24	1341	10667	\N	\N
24862	SPECIFIC_DAY	0	8	2010-01-25	1341	10667	\N	\N
24863	SPECIFIC_DAY	0	4	2010-01-28	1341	10667	\N	\N
24864	SPECIFIC_DAY	0	0	2010-01-23	1341	10667	\N	\N
24865	SPECIFIC_DAY	0	0	2009-12-26	1341	10649	\N	\N
24866	SPECIFIC_DAY	0	8	2009-12-24	1341	10649	\N	\N
24867	SPECIFIC_DAY	0	8	2009-12-28	1341	10649	\N	\N
24868	SPECIFIC_DAY	0	8	2009-12-22	1341	10649	\N	\N
24869	SPECIFIC_DAY	0	8	2009-12-23	1341	10649	\N	\N
24870	SPECIFIC_DAY	0	0	2009-12-27	1341	10649	\N	\N
24871	SPECIFIC_DAY	0	8	2009-12-25	1341	10649	\N	\N
24872	SPECIFIC_DAY	0	8	2009-12-30	1341	10649	\N	\N
24873	SPECIFIC_DAY	0	8	2009-12-29	1341	10649	\N	\N
24874	SPECIFIC_DAY	0	8	2009-12-21	1341	10646	\N	\N
24875	SPECIFIC_DAY	0	0	2009-12-20	1341	10646	\N	\N
24876	SPECIFIC_DAY	0	0	2009-12-19	1341	10646	\N	\N
24877	SPECIFIC_DAY	0	8	2009-12-25	1328	10681	\N	\N
24878	SPECIFIC_DAY	0	8	2009-12-22	1328	10681	\N	\N
24879	SPECIFIC_DAY	0	8	2009-12-24	1328	10681	\N	\N
24880	SPECIFIC_DAY	0	8	2009-12-23	1328	10681	\N	\N
24881	SPECIFIC_DAY	0	0	2010-01-03	1341	10650	\N	\N
24882	SPECIFIC_DAY	0	8	2010-01-01	1341	10650	\N	\N
24883	SPECIFIC_DAY	0	8	2010-01-05	1341	10650	\N	\N
24884	SPECIFIC_DAY	0	8	2010-01-04	1341	10650	\N	\N
24885	SPECIFIC_DAY	0	8	2009-12-31	1341	10650	\N	\N
24886	SPECIFIC_DAY	0	0	2010-01-02	1341	10650	\N	\N
24887	SPECIFIC_DAY	0	6	2010-01-18	1326	11904	\N	\N
24888	SPECIFIC_DAY	0	6	2010-01-15	1326	11904	\N	\N
24889	SPECIFIC_DAY	0	0	2010-01-16	1326	11904	\N	\N
24890	SPECIFIC_DAY	0	6	2010-01-13	1326	11904	\N	\N
24891	SPECIFIC_DAY	0	0	2010-01-17	1326	11904	\N	\N
24892	SPECIFIC_DAY	0	6	2010-01-14	1326	11904	\N	\N
24893	SPECIFIC_DAY	0	6	2010-01-21	1326	11905	\N	\N
24894	SPECIFIC_DAY	0	6	2010-01-22	1326	11905	\N	\N
24895	SPECIFIC_DAY	0	6	2010-01-19	1326	11905	\N	\N
24896	SPECIFIC_DAY	0	6	2010-01-20	1326	11905	\N	\N
24897	SPECIFIC_DAY	0	0	2009-12-19	1326	11906	\N	\N
24898	SPECIFIC_DAY	0	6	2009-12-18	1326	11906	\N	\N
24899	SPECIFIC_DAY	0	6	2009-12-21	1326	11906	\N	\N
24900	SPECIFIC_DAY	0	0	2009-12-20	1326	11906	\N	\N
24901	SPECIFIC_DAY	0	6	2009-12-17	1326	11906	\N	\N
24902	SPECIFIC_DAY	0	6	2009-12-16	1326	11906	\N	\N
24903	SPECIFIC_DAY	0	6	2010-01-01	1326	11907	\N	\N
24904	SPECIFIC_DAY	0	0	2010-01-03	1326	11907	\N	\N
24905	SPECIFIC_DAY	0	6	2010-01-04	1326	11907	\N	\N
24906	SPECIFIC_DAY	0	6	2010-01-05	1326	11907	\N	\N
24907	SPECIFIC_DAY	0	0	2010-01-02	1326	11907	\N	\N
24908	SPECIFIC_DAY	0	6	2010-01-06	1326	11907	\N	\N
24909	SPECIFIC_DAY	0	6	2009-12-24	1326	11908	\N	\N
24910	SPECIFIC_DAY	0	6	2009-12-22	1326	11908	\N	\N
24911	SPECIFIC_DAY	0	6	2009-12-25	1326	11908	\N	\N
24912	SPECIFIC_DAY	0	6	2009-12-23	1326	11908	\N	\N
24913	SPECIFIC_DAY	0	6	2009-12-31	1326	11909	\N	\N
24914	SPECIFIC_DAY	0	6	2009-12-28	1326	11909	\N	\N
24915	SPECIFIC_DAY	0	0	2009-12-27	1326	11909	\N	\N
24916	SPECIFIC_DAY	0	0	2009-12-26	1326	11909	\N	\N
24917	SPECIFIC_DAY	0	6	2009-12-29	1326	11909	\N	\N
24918	SPECIFIC_DAY	0	6	2009-12-30	1326	11909	\N	\N
24919	SPECIFIC_DAY	0	6	2010-01-12	1326	11910	\N	\N
24920	SPECIFIC_DAY	0	0	2010-01-10	1326	11910	\N	\N
24921	SPECIFIC_DAY	0	0	2010-01-09	1326	11910	\N	\N
24922	SPECIFIC_DAY	0	6	2010-01-11	1326	11910	\N	\N
24923	SPECIFIC_DAY	0	6	2010-01-08	1326	11910	\N	\N
24924	SPECIFIC_DAY	0	6	2010-01-07	1326	11910	\N	\N
24925	SPECIFIC_DAY	0	0	2010-01-16	1314	10634	\N	\N
24926	SPECIFIC_DAY	0	2	2010-01-12	1314	10634	\N	\N
24927	SPECIFIC_DAY	0	0	2010-01-10	1314	10634	\N	\N
24928	SPECIFIC_DAY	0	2	2010-01-21	1314	10634	\N	\N
24929	SPECIFIC_DAY	0	0	2010-01-09	1314	10634	\N	\N
24930	SPECIFIC_DAY	0	2	2010-01-06	1314	10634	\N	\N
24931	SPECIFIC_DAY	0	2	2010-01-13	1314	10634	\N	\N
24932	SPECIFIC_DAY	0	2	2010-01-18	1314	10634	\N	\N
24933	SPECIFIC_DAY	0	2	2010-01-08	1314	10634	\N	\N
24934	SPECIFIC_DAY	0	2	2010-01-14	1314	10634	\N	\N
24935	SPECIFIC_DAY	0	2	2010-01-20	1314	10634	\N	\N
24936	SPECIFIC_DAY	0	0	2010-01-17	1314	10634	\N	\N
24937	SPECIFIC_DAY	0	2	2010-01-07	1314	10634	\N	\N
24938	SPECIFIC_DAY	0	2	2010-01-19	1314	10634	\N	\N
24939	SPECIFIC_DAY	0	2	2010-01-15	1314	10634	\N	\N
24940	SPECIFIC_DAY	0	2	2010-01-11	1314	10634	\N	\N
24941	SPECIFIC_DAY	0	2	2009-12-28	1314	10635	\N	\N
24942	SPECIFIC_DAY	0	2	2009-12-23	1314	10635	\N	\N
24943	SPECIFIC_DAY	0	0	2010-01-02	1314	10635	\N	\N
24944	SPECIFIC_DAY	0	2	2009-12-31	1314	10635	\N	\N
24945	SPECIFIC_DAY	0	2	2009-12-25	1314	10635	\N	\N
24946	SPECIFIC_DAY	0	2	2010-01-01	1314	10635	\N	\N
24947	SPECIFIC_DAY	0	0	2010-01-03	1314	10635	\N	\N
24948	SPECIFIC_DAY	0	2	2010-01-04	1314	10635	\N	\N
24949	SPECIFIC_DAY	0	2	2009-12-24	1314	10635	\N	\N
24950	SPECIFIC_DAY	0	0	2009-12-19	1314	10635	\N	\N
24951	SPECIFIC_DAY	0	2	2010-01-05	1314	10635	\N	\N
24952	SPECIFIC_DAY	0	2	2009-12-22	1314	10635	\N	\N
24953	SPECIFIC_DAY	0	0	2009-12-20	1314	10635	\N	\N
24954	SPECIFIC_DAY	0	2	2009-12-21	1314	10635	\N	\N
24955	SPECIFIC_DAY	0	0	2009-12-26	1314	10635	\N	\N
24956	SPECIFIC_DAY	0	2	2009-12-29	1314	10635	\N	\N
24957	SPECIFIC_DAY	0	0	2009-12-27	1314	10635	\N	\N
24958	SPECIFIC_DAY	0	2	2009-12-30	1314	10635	\N	\N
24959	SPECIFIC_DAY	0	8	2010-01-22	1341	10669	\N	\N
24960	SPECIFIC_DAY	0	8	2010-01-21	1341	10669	\N	\N
24961	SPECIFIC_DAY	0	8	2010-01-20	1341	10669	\N	\N
24962	SPECIFIC_DAY	0	8	2010-01-06	1330	10623	\N	\N
24963	SPECIFIC_DAY	0	8	2009-12-31	1330	10623	\N	\N
24964	SPECIFIC_DAY	0	8	2010-01-04	1330	10623	\N	\N
24965	SPECIFIC_DAY	0	8	2010-01-01	1330	10623	\N	\N
24966	SPECIFIC_DAY	0	0	2010-01-02	1330	10623	\N	\N
24967	SPECIFIC_DAY	0	8	2010-01-05	1330	10623	\N	\N
24968	SPECIFIC_DAY	0	0	2009-12-26	1330	10623	\N	\N
24969	SPECIFIC_DAY	0	8	2009-12-29	1330	10623	\N	\N
24970	SPECIFIC_DAY	0	0	2009-12-27	1330	10623	\N	\N
24971	SPECIFIC_DAY	0	8	2009-12-28	1330	10623	\N	\N
24972	SPECIFIC_DAY	0	8	2009-12-30	1330	10623	\N	\N
24973	SPECIFIC_DAY	0	0	2010-01-03	1330	10623	\N	\N
24974	SPECIFIC_DAY	0	0	2010-01-02	1322	11821	\N	\N
24975	SPECIFIC_DAY	0	0	2010-01-03	1322	11821	\N	\N
24976	SPECIFIC_DAY	0	8	2010-01-01	1322	11821	\N	\N
24977	SPECIFIC_DAY	0	8	2010-01-04	1322	11821	\N	\N
24978	SPECIFIC_DAY	0	8	2010-01-06	1322	11822	\N	\N
24979	SPECIFIC_DAY	0	8	2010-01-08	1322	11822	\N	\N
24980	SPECIFIC_DAY	0	8	2010-01-07	1322	11822	\N	\N
24981	SPECIFIC_DAY	0	8	2010-01-05	1322	11822	\N	\N
24982	SPECIFIC_DAY	0	8	2010-01-12	1322	11823	\N	\N
24983	SPECIFIC_DAY	0	0	2010-01-10	1322	11823	\N	\N
24984	SPECIFIC_DAY	0	8	2010-01-13	1322	11823	\N	\N
24985	SPECIFIC_DAY	0	0	2010-01-09	1322	11823	\N	\N
24986	SPECIFIC_DAY	0	8	2010-01-11	1322	11823	\N	\N
24987	SPECIFIC_DAY	0	8	2010-01-14	1322	11823	\N	\N
24988	SPECIFIC_DAY	0	8	2010-01-15	1322	11823	\N	\N
24989	SPECIFIC_DAY	0	0	2010-01-16	1322	11824	\N	\N
24990	SPECIFIC_DAY	0	0	2010-01-17	1322	11824	\N	\N
24991	SPECIFIC_DAY	0	8	2010-01-18	1322	11824	\N	\N
24992	SPECIFIC_DAY	0	8	2010-01-19	1322	11824	\N	\N
24993	SPECIFIC_DAY	0	0	2010-01-24	1322	11825	\N	\N
24994	SPECIFIC_DAY	0	8	2010-01-21	1322	11825	\N	\N
24995	SPECIFIC_DAY	0	8	2010-01-20	1322	11825	\N	\N
24996	SPECIFIC_DAY	0	8	2010-01-22	1322	11825	\N	\N
24997	SPECIFIC_DAY	0	8	2010-01-25	1322	11825	\N	\N
24998	SPECIFIC_DAY	0	0	2010-01-23	1322	11825	\N	\N
24999	SPECIFIC_DAY	0	8	2009-12-24	1322	10694	\N	\N
25000	SPECIFIC_DAY	0	8	2009-12-23	1322	10694	\N	\N
25001	SPECIFIC_DAY	0	8	2009-12-22	1322	10694	\N	\N
25002	SPECIFIC_DAY	0	0	2010-01-10	1328	10683	\N	\N
25003	SPECIFIC_DAY	0	8	2010-01-18	1328	10683	\N	\N
25004	SPECIFIC_DAY	0	8	2010-01-12	1328	10683	\N	\N
25005	SPECIFIC_DAY	0	8	2010-01-14	1328	10683	\N	\N
25006	SPECIFIC_DAY	0	0	2010-01-16	1328	10683	\N	\N
25007	SPECIFIC_DAY	0	0	2010-01-09	1328	10683	\N	\N
25008	SPECIFIC_DAY	0	8	2010-01-11	1328	10683	\N	\N
25009	SPECIFIC_DAY	0	8	2010-01-15	1328	10683	\N	\N
25010	SPECIFIC_DAY	0	8	2010-01-13	1328	10683	\N	\N
25011	SPECIFIC_DAY	0	8	2010-01-19	1328	10683	\N	\N
25012	SPECIFIC_DAY	0	0	2010-01-17	1328	10683	\N	\N
25013	SPECIFIC_DAY	0	8	2010-01-29	1341	10670	\N	\N
25014	SPECIFIC_DAY	0	0	2009-12-27	1322	10693	\N	\N
25015	SPECIFIC_DAY	0	8	2009-12-28	1322	10693	\N	\N
25016	SPECIFIC_DAY	0	8	2009-12-31	1322	10693	\N	\N
25017	SPECIFIC_DAY	0	8	2009-12-29	1322	10693	\N	\N
25018	SPECIFIC_DAY	0	0	2009-12-26	1322	10693	\N	\N
25019	SPECIFIC_DAY	0	8	2009-12-25	1322	10693	\N	\N
25020	SPECIFIC_DAY	0	8	2009-12-30	1322	10693	\N	\N
25021	SPECIFIC_DAY	0	2	2010-01-13	1343	11840	\N	\N
25022	SPECIFIC_DAY	0	2	2009-12-31	1343	11840	\N	\N
25023	SPECIFIC_DAY	0	0	2010-01-17	1343	11840	\N	\N
25024	SPECIFIC_DAY	0	2	2010-01-07	1343	11840	\N	\N
25025	SPECIFIC_DAY	0	2	2010-01-01	1343	11840	\N	\N
25026	SPECIFIC_DAY	0	2	2010-01-18	1343	11840	\N	\N
25027	SPECIFIC_DAY	0	2	2010-01-12	1343	11840	\N	\N
25028	SPECIFIC_DAY	0	2	2010-01-06	1343	11840	\N	\N
25029	SPECIFIC_DAY	0	0	2010-01-03	1343	11840	\N	\N
25030	SPECIFIC_DAY	0	2	2009-12-30	1343	11840	\N	\N
25031	SPECIFIC_DAY	0	2	2010-01-04	1343	11840	\N	\N
25032	SPECIFIC_DAY	0	2	2010-01-11	1343	11840	\N	\N
25033	SPECIFIC_DAY	0	2	2010-01-08	1343	11840	\N	\N
25034	SPECIFIC_DAY	0	2	2010-01-15	1343	11840	\N	\N
25035	SPECIFIC_DAY	0	0	2010-01-16	1343	11840	\N	\N
25036	SPECIFIC_DAY	0	2	2010-01-05	1343	11840	\N	\N
25037	SPECIFIC_DAY	0	0	2010-01-02	1343	11840	\N	\N
25038	SPECIFIC_DAY	0	0	2010-01-09	1343	11840	\N	\N
25039	SPECIFIC_DAY	0	0	2010-01-10	1343	11840	\N	\N
25040	SPECIFIC_DAY	0	2	2010-01-20	1343	11840	\N	\N
25041	SPECIFIC_DAY	0	2	2010-01-19	1343	11840	\N	\N
25042	SPECIFIC_DAY	0	2	2010-01-14	1343	11840	\N	\N
25043	SPECIFIC_DAY	0	0	2010-01-16	1341	10668	\N	\N
25044	SPECIFIC_DAY	0	8	2010-01-19	1341	10668	\N	\N
25045	SPECIFIC_DAY	0	8	2010-01-18	1341	10668	\N	\N
25046	SPECIFIC_DAY	0	0	2010-01-17	1341	10668	\N	\N
25047	SPECIFIC_DAY	0	8	2010-01-14	1341	10668	\N	\N
25048	SPECIFIC_DAY	0	8	2010-01-15	1341	10668	\N	\N
25049	SPECIFIC_DAY	0	8	2009-12-15	1330	10619	\N	\N
25050	SPECIFIC_DAY	0	8	2009-12-16	1330	10619	\N	\N
25051	SPECIFIC_DAY	0	8	2009-12-17	1330	10620	\N	\N
25052	SPECIFIC_DAY	0	8	2009-12-18	1330	10620	\N	\N
25053	SPECIFIC_DAY	0	8	2009-12-21	1330	10621	\N	\N
25054	SPECIFIC_DAY	0	8	2009-12-25	1330	10621	\N	\N
25055	SPECIFIC_DAY	0	0	2009-12-19	1330	10621	\N	\N
25056	SPECIFIC_DAY	0	8	2009-12-24	1330	10621	\N	\N
25057	SPECIFIC_DAY	0	8	2009-12-23	1330	10621	\N	\N
25058	SPECIFIC_DAY	0	0	2009-12-20	1330	10621	\N	\N
25059	SPECIFIC_DAY	0	8	2009-12-22	1330	10621	\N	\N
25060	SPECIFIC_DAY	0	3	2010-01-04	1314	10641	\N	\N
25061	SPECIFIC_DAY	0	3	2010-01-25	1314	10641	\N	\N
25062	SPECIFIC_DAY	0	3	2010-01-18	1314	10641	\N	\N
25063	SPECIFIC_DAY	0	3	2010-01-19	1314	10641	\N	\N
25064	SPECIFIC_DAY	0	3	2009-12-31	1314	10641	\N	\N
25065	SPECIFIC_DAY	0	3	2010-01-08	1314	10641	\N	\N
25066	SPECIFIC_DAY	0	0	2010-01-03	1314	10641	\N	\N
25067	SPECIFIC_DAY	0	3	2010-01-11	1314	10641	\N	\N
25068	SPECIFIC_DAY	0	3	2010-01-06	1314	10641	\N	\N
25069	SPECIFIC_DAY	0	3	2009-12-30	1314	10641	\N	\N
25070	SPECIFIC_DAY	0	3	2010-01-12	1314	10641	\N	\N
25071	SPECIFIC_DAY	0	0	2010-01-09	1314	10641	\N	\N
25072	SPECIFIC_DAY	0	3	2010-01-26	1314	10641	\N	\N
25073	SPECIFIC_DAY	0	0	2010-01-16	1314	10641	\N	\N
25074	SPECIFIC_DAY	0	3	2010-01-22	1314	10641	\N	\N
25075	SPECIFIC_DAY	0	3	2010-01-01	1314	10641	\N	\N
25076	SPECIFIC_DAY	0	0	2010-01-10	1314	10641	\N	\N
25077	SPECIFIC_DAY	0	3	2010-01-15	1314	10641	\N	\N
25078	SPECIFIC_DAY	0	3	2010-01-13	1314	10641	\N	\N
25079	SPECIFIC_DAY	0	0	2010-01-02	1314	10641	\N	\N
25080	SPECIFIC_DAY	0	1	2010-01-27	1314	10641	\N	\N
25081	SPECIFIC_DAY	0	3	2010-01-20	1314	10641	\N	\N
25082	SPECIFIC_DAY	0	3	2010-01-07	1314	10641	\N	\N
25083	SPECIFIC_DAY	0	0	2010-01-24	1314	10641	\N	\N
25084	SPECIFIC_DAY	0	0	2010-01-23	1314	10641	\N	\N
25085	SPECIFIC_DAY	0	3	2009-12-29	1314	10641	\N	\N
25086	SPECIFIC_DAY	0	3	2010-01-21	1314	10641	\N	\N
25087	SPECIFIC_DAY	0	0	2010-01-17	1314	10641	\N	\N
25088	SPECIFIC_DAY	0	3	2010-01-14	1314	10641	\N	\N
25089	SPECIFIC_DAY	0	3	2010-01-05	1314	10641	\N	\N
25090	SPECIFIC_DAY	0	6	2009-12-22	1314	10642	\N	\N
25091	SPECIFIC_DAY	0	6	2009-12-24	1314	10642	\N	\N
25092	SPECIFIC_DAY	0	2	2009-12-28	1314	10642	\N	\N
25093	SPECIFIC_DAY	0	0	2009-12-20	1314	10642	\N	\N
25094	SPECIFIC_DAY	0	0	2009-12-27	1314	10642	\N	\N
25095	SPECIFIC_DAY	0	0	2009-12-26	1314	10642	\N	\N
25096	SPECIFIC_DAY	0	0	2009-12-19	1314	10642	\N	\N
25097	SPECIFIC_DAY	0	6	2009-12-25	1314	10642	\N	\N
25098	SPECIFIC_DAY	0	6	2009-12-21	1314	10642	\N	\N
25099	SPECIFIC_DAY	0	6	2009-12-23	1314	10642	\N	\N
25100	SPECIFIC_DAY	0	0	2010-01-03	1328	10682	\N	\N
25101	SPECIFIC_DAY	0	0	2010-01-02	1328	10682	\N	\N
25102	SPECIFIC_DAY	0	8	2010-01-07	1328	10682	\N	\N
25103	SPECIFIC_DAY	0	8	2010-01-04	1328	10682	\N	\N
25104	SPECIFIC_DAY	0	8	2010-01-05	1328	10682	\N	\N
25105	SPECIFIC_DAY	0	8	2010-01-06	1328	10682	\N	\N
25106	SPECIFIC_DAY	0	8	2010-01-08	1328	10682	\N	\N
25107	SPECIFIC_DAY	0	8	2009-12-30	1328	10684	\N	\N
25108	SPECIFIC_DAY	0	8	2009-12-28	1328	10684	\N	\N
25109	SPECIFIC_DAY	0	8	2009-12-29	1328	10684	\N	\N
25110	SPECIFIC_DAY	0	8	2009-12-31	1328	10684	\N	\N
25111	SPECIFIC_DAY	0	8	2010-01-01	1328	10684	\N	\N
25112	SPECIFIC_DAY	0	0	2009-12-26	1328	10684	\N	\N
25113	SPECIFIC_DAY	0	0	2009-12-27	1328	10684	\N	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
3506379	8	10511	10516	0
3506346	8	10511	10516	0
3506347	8	10517	10546	0
3506380	8	10517	10546	0
3506348	8	10530	10517	0
3506381	8	10530	10517	0
3506349	8	10518	10511	0
3506382	8	10518	10511	0
3506350	8	10521	10518	0
3506383	8	10521	10518	0
3506281	8	10519	10530	0
3506351	8	10519	10530	0
3506384	8	10519	10530	0
3506385	8	10514	10519	0
3506282	8	10514	10519	0
3506352	8	10514	10519	0
3506252	14	10513	10539	0
3506261	14	10513	10539	0
3506253	14	10513	10557	0
3506266	14	10513	10539	0
3506262	14	10513	10557	0
3506221	14	10513	10557	0
3506267	14	10513	10557	0
3506391	8	10522	10514	0
3506274	8	10522	10514	0
3506283	8	10522	10514	0
3506354	8	10522	10514	0
3506386	8	10528	10529	0
3506387	8	10529	10524	0
3506652	3	10548	10551	0
3506653	3	10549	10550	0
3506654	3	10555	10549	0
3506655	3	10551	10553	0
3506223	14	10557	10556	0
3506264	14	10557	10556	0
3506255	14	10557	10556	0
3506269	14	10557	10556	0
3506353	8	10546	10521	0
3506390	8	10546	10521	0
3506206	14	10507	10562	0
3506222	14	10507	10562	0
3506254	14	10507	10562	0
3506268	14	10507	10562	0
3506263	14	10507	10562	0
3506388	8	10526	10510	0
3506520	3	10535	10536	0
3506198	20	10504	10505	0
3506199	20	10505	10506	0
3506200	20	10506	10507	0
3506256	14	10539	10538	0
3506270	14	10539	10538	0
3506265	14	10539	10538	0
3506389	8	10524	10526	0
3506499	8	10511	10516	0
3506436	8	10511	10516	0
3506437	8	10517	10546	0
3506500	8	10517	10546	0
3506438	8	10530	10517	0
3506501	8	10530	10517	0
3506439	8	10518	10511	0
3506502	8	10518	10511	0
3506503	8	10521	10518	0
3506440	8	10521	10518	0
3506441	8	10519	10530	0
3506504	8	10519	10530	0
3506442	8	10514	10519	0
3506505	8	10514	10519	0
3506450	8	10522	10514	0
3506513	8	10522	10514	0
3506443	8	10528	10529	0
3506506	8	10528	10529	0
3506444	8	10529	10524	0
3506507	8	10529	10524	0
3506551	3	10548	10551	0
3506552	3	10549	10550	0
3506553	3	10555	10549	0
3506554	3	10551	10553	0
3506656	3	10552	10555	0
3506555	3	10552	10555	0
3506556	3	10554	10552	0
3506657	3	10554	10552	0
3506557	3	10553	10554	0
3506658	3	10553	10554	0
3506449	8	10546	10521	0
3506512	8	10546	10521	0
3506431	8	10563	10564	0
3506494	8	10563	10564	0
3506495	8	10534	10563	0
3506432	8	10534	10563	0
3506433	8	10564	10565	0
3506496	8	10564	10565	0
3506497	8	10565	10566	0
3506434	8	10565	10566	0
3506498	8	10566	10567	0
3506435	8	10566	10567	0
3506446	8	10509	10534	0
3506509	8	10509	10534	0
3506445	8	10533	10509	0
3506508	8	10533	10509	0
3506510	8	10526	10510	0
3506447	8	10526	10510	0
3506524	3	10535	10536	0
3506558	3	10535	10536	0
3506659	3	10535	10536	0
3506511	8	10524	10526	0
3506448	8	10524	10526	0
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
24655	3204	100.00
24657	3206	100.00
24659	3208	100.00
24661	3210	100.00
24662	3211	100.00
24664	3214	100.00
24665	3215	100.00
24666	3216	100.00
24667	3217	100.00
24669	3221	100.00
24671	3223	100.00
24672	3224	100.00
24674	3230	100.00
24675	3334	100.00
24676	3335	100.00
24677	3336	100.00
24678	3337	100.00
24679	3338	100.00
24681	3341	100.00
24682	3342	100.00
24683	3358	100.00
24684	3360	100.00
17523	2298	100.00
17524	2299	100.00
17525	2300	100.00
17526	2301	100.00
17738	2303	100.00
17740	2307	100.00
17741	2308	100.00
17743	2313	100.00
\.


--
-- Data for Name: external_company; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY external_company (id, version, name, nif, client, subcontractor, interactswithapplications, appuri, ourcompanylogin, ourcompanypassword, companyuser) FROM stdin;
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, positionnumber) FROM stdin;
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
249
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
2828	2	10.00	2010-01-15	\N	2626	2727
2829	1	14.00	2010-01-15	\N	2627	2727
2830	1	12.00	2009-01-15	\N	2627	2728
2831	1	9.00	2009-01-15	\N	2626	2728
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, code, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line) FROM stdin;
3076	20	PREFIX-00002-00012-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	2307
3077	20	PREFIX-00002-00013-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	8	1.00	f	2308
3078	20	PREFIX-00002-00014-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	2310
3079	20	PREFIX-00002-00015-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	48	1.00	f	2311
3080	20	PREFIX-00002-00016-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	2312
3285	14	PREFIX-00002-00059-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	64	1.00	f	3358
3286	14	PREFIX-00002-00060-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	3359
3069	20	PREFIX-00002-00005-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	8	1.00	f	2298
3070	20	PREFIX-00002-00006-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	2299
3071	20	PREFIX-00002-00007-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	2300
3072	20	PREFIX-00002-00008-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	2301
3073	20	PREFIX-00002-00009-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	2303
3074	20	PREFIX-00002-00010-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	2304
3075	20	PREFIX-00002-00011-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	8	1.00	f	2305
3081	20	PREFIX-00002-00017-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	2313
3287	14	PREFIX-00002-00061-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3360
3288	14	PREFIX-00002-00062-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3361
3289	14	PREFIX-00002-00063-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	3362
3290	14	PREFIX-00002-00064-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3363
3250	19	PREFIX-00002-00037-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	120	1.00	f	3214
3251	19	PREFIX-00002-00038-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	48	1.00	f	3215
3252	19	PREFIX-00002-00039-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3216
3253	19	PREFIX-00002-00040-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3217
3254	19	PREFIX-00002-00041-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3218
3255	19	PREFIX-00002-00042-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	64	1.00	f	3220
3256	19	PREFIX-00002-00043-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3221
3243	19	PREFIX-00002-00030-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3203
3244	19	PREFIX-00002-00031-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3204
3245	19	PREFIX-00002-00032-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3206
3246	19	PREFIX-00002-00033-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3208
3247	19	PREFIX-00002-00034-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	48	1.00	f	3210
3248	19	PREFIX-00002-00035-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3211
3249	19	PREFIX-00002-00036-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3212
3260	19	PREFIX-00002-00047-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3228
3261	19	PREFIX-00002-00048-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	3230
3262	19	PREFIX-00002-00049-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3231
3263	19	PREFIX-00002-00050-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3333
3264	19	PREFIX-00002-00051-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3334
3265	19	PREFIX-00002-00052-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3335
3266	19	PREFIX-00002-00053-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3336
3267	19	PREFIX-00002-00054-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3337
3268	19	PREFIX-00002-00055-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3338
3269	19	PREFIX-00002-00056-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3339
3270	19	PREFIX-00002-00057-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	3340
3271	19	PREFIX-00002-00028-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	256	1.00	f	3341
3272	19	PREFIX-00002-00029-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	256	1.00	f	3342
3257	19	PREFIX-00002-00044-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3223
3258	19	PREFIX-00002-00045-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	32	1.00	f	3224
3259	19	PREFIX-00002-00046-00001	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	40	1.00	f	3226
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
404	8	0
404	8	1
404	8	2
404	8	3
404	8	4
404	0	5
404	0	6
1533	16	0
1533	16	1
1533	16	2
1533	16	3
1533	16	4
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
24656	3202
24658	3205
24660	3207
24663	3209
24668	3213
24670	3219
24673	3222
24680	3229
24685	3357
2356	2297
17527	2297
17739	2302
17742	2306
2357	2306
17744	2309
2358	2309
2379	3202
2380	3205
2381	3207
2382	3209
2383	3213
2384	3219
2385	3222
2386	3225
2387	3227
2388	3229
2391	3357
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
16874	10	Medio (2)	16766
17036	6	Alta (3)	16766
17107	5	Muy Alto (4)	16766
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
16766	1	Riesgo
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, positionnumber) FROM stdin;
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
1337	Torno1	Torno	Desc. Torno
1339	Galvanizadora1	Galvanizadora	Desc.
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
2424	3	440-TX-25X	1/4" DRIVE T-25 TORX BIT	1.00	2	f	202
2426	2	cod	3/4" 1.65mm	21.00	\N	f	2526
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, material_id, estimated_availability, status, order_element_id) FROM stdin;
\.


--
-- Data for Name: material_assigment_template; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment_template (id, version, units, unit_price, material_id, order_element_template_id) FROM stdin;
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
202	4	Tornillos	\N
2525	3	Tubos	\N
2526	2	Acero	2525
2528	2	Acero inoxidable	2526
2527	2	Cemento	2525
16665	1	Imported materials without category	\N
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled) FROM stdin;
909	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f
910	3	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f
911	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f
912	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f
\.


--
-- Data for Name: order_authorization; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_authorization (id, order_authorization_subclass, version, authorizationtype, order_id, user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
2297	16874
2309	17036
3202	17107
\.


--
-- Data for Name: order_element_template_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_label (order_element_template_id, label_id) FROM stdin;
\.


--
-- Data for Name: order_element_template_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_quality_form (order_element_template_id, quality_form_id) FROM stdin;
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, codeautogenerated, lastorderelementsequencecode, base_calendar_id) FROM stdin;
2245	Resp.	Navantia	t	t	64	1418
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, description, code, initdate, deadline, mandatoryinit, mandatoryend, schedulingstatetype, parent, positionincontainer) FROM stdin;
2245	23	4º release devenvolvemento aplicación xestión produción	Desc.	PREFIX-00002	2009-12-14 00:00:00	2010-01-29 00:00:00	f	f	3	\N	\N
2297	20	Módulo de Xestión de Usuarios	\N	PREFIX-00002-00001	\N	\N	f	f	3	2245	0
2298	20	Xestión de usuarios	\N	PREFIX-00002-00005	\N	\N	f	f	0	2297	0
2299	20	Xestión de roles	\N	PREFIX-00002-00006	\N	\N	f	f	0	2297	1
2300	20	Xestión de perfiles	\N	PREFIX-00002-00007	\N	\N	f	f	0	2297	2
2301	20	Xestión de roles e pedidos	\N	PREFIX-00002-00008	\N	\N	f	f	0	2297	3
2302	20	Módulo de organización do traballo	\N	PREFIX-00002-00002	\N	\N	f	f	3	2245	1
2303	20	Xestión de código único	\N	PREFIX-00002-00009	\N	\N	f	f	0	2302	0
2304	20	Revisión de formulario de pedidos	\N	PREFIX-00002-00010	\N	\N	f	f	0	2302	1
2305	20	Filtrado no listado de pedidos	\N	PREFIX-00002-00011	\N	\N	f	f	0	2302	2
2306	20	Módulo de recursos	\N	PREFIX-00002-00003	\N	\N	f	f	3	2245	2
2307	20	Recursos Virtuais	\N	PREFIX-00002-00012	\N	\N	f	f	0	2306	0
2308	20	Recursos Virtuais (Cont.)	\N	PREFIX-00002-00013	\N	\N	f	f	0	2306	1
2309	20	Módulo de planificación	\N	PREFIX-00002-00004	\N	\N	f	f	3	2245	3
3222	19	Módulo de arquitectura tecnolóxica	\N	PREFIX-00002-00024	\N	\N	f	f	3	2245	10
3223	19	Enlazar a axuda de usuario	\N	PREFIX-00002-00044	\N	\N	f	f	0	3222	0
3224	19	Desenvolvemento de paquetes Debian	\N	PREFIX-00002-00045	\N	\N	f	f	0	3222	1
3225	19	Módulo de Documentación de API	\N	PREFIX-00002-00025	\N	\N	f	f	3	2245	11
3226	19	Documentación das APIs públicas da aplicación	\N	PREFIX-00002-00046	\N	\N	f	f	0	3225	0
3227	19	Módulo de Arquivo Histórico	\N	PREFIX-00002-00026	\N	\N	f	f	3	2245	12
3228	19	Pasar pedidos a Histórico	\N	PREFIX-00002-00047	\N	\N	f	f	0	3227	0
3229	19	Módulo de Extracción de Informes	\N	PREFIX-00002-00027	\N	\N	f	f	3	2245	13
3230	19	Integración con Jasper Reports	\N	PREFIX-00002-00048	\N	\N	f	f	0	3229	0
3231	19	Informes sobre organizacións de traballo	\N	PREFIX-00002-00049	\N	\N	f	f	0	3229	1
3333	19	Informes sobre partes de traballo	\N	PREFIX-00002-00050	\N	\N	f	f	0	3229	2
3334	19	Informes de horas traballadas por un traballador	\N	PREFIX-00002-00051	\N	\N	f	f	0	3229	3
3335	19	Lista de avances de planificación da empresa	\N	PREFIX-00002-00052	\N	\N	f	f	0	3229	4
3336	19	Lista de avances de traballo da empresa	\N	PREFIX-00002-00053	\N	\N	f	f	0	3229	5
2310	20	Compartir estado entre pestañas de planificación	\N	PREFIX-00002-00014	\N	\N	f	f	0	2309	0
2311	20	Técnica de recálculo de asignacións	\N	PREFIX-00002-00015	\N	\N	f	f	0	2309	1
2312	20	Filtrado de pedidos e tarefas de un pedido	\N	PREFIX-00002-00016	\N	\N	f	f	0	2309	2
2313	20	Modelos de pedidos e planificación	\N	PREFIX-00002-00017	\N	\N	f	f	0	2309	3
3337	19	Informe de horas estimadas/horas realies	\N	PREFIX-00002-00054	\N	\N	f	f	0	3229	6
3338	19	Horas realizadas organizadas por tipo de traballo	\N	PREFIX-00002-00055	\N	\N	f	f	0	3229	7
3339	19	Horas estimadas/horas realizadas por tipo de traballo	\N	PREFIX-00002-00056	\N	\N	f	f	0	3229	8
3340	19	Informe de traballador indicando custos por hora	\N	PREFIX-00002-00057	\N	\N	f	f	0	3229	9
3341	19	Coordinación	\N	PREFIX-00002-00028	\N	\N	f	f	0	2245	14
3342	19	Análise	\N	PREFIX-00002-00029	\N	\N	f	f	0	2245	15
3357	14	Módulo de integración con subcontratas	\N	PREFIX-00002-00058	\N	\N	f	f	3	2245	16
3358	14	Administración das subcontratas	\N	PREFIX-00002-00059	\N	\N	f	f	0	3357	0
3359	14	Formato de intercambio	\N	PREFIX-00002-00060	\N	\N	f	f	0	3357	1
3360	14	Fluxo de importación/exportación	\N	PREFIX-00002-00061	\N	\N	f	f	0	3357	2
3361	14	Interfaz de xestión de subcontratas	\N	PREFIX-00002-00062	\N	\N	f	f	0	3357	3
3362	14	Convertir en fitos subcontratacións	\N	PREFIX-00002-00063	\N	\N	f	f	0	3357	4
3363	14	Avance e custo de subcontratas en Técnica VG	\N	PREFIX-00002-00064	\N	\N	f	f	0	3357	5
3216	19	Formato de intercambio de información de avances	\N	PREFIX-00002-00039	\N	\N	f	f	0	3213	2
3217	19	Formato de intercambio de recursos	\N	PREFIX-00002-00040	\N	\N	f	f	0	3213	3
3218	19	Formato de intercambio de materiais	\N	PREFIX-00002-00041	\N	\N	f	f	0	3213	4
3219	19	Módulo de Presentación	\N	PREFIX-00002-00023	\N	\N	f	f	3	2245	9
3220	19	Imprimir o diagrama de Gantt en varias páxinas	\N	PREFIX-00002-00042	\N	\N	f	f	0	3219	0
3221	19	Imprimir información pantalla do planificador	\N	PREFIX-00002-00043	\N	\N	f	f	0	3219	1
3202	19	Módulo de asignación de recursos	\N	PREFIX-00002-00018	\N	\N	f	f	3	2245	4
3203	19	Interpolación polinómica na asignación	\N	PREFIX-00002-00030	\N	\N	f	f	0	3202	0
3204	19	Asignación avanzada asignación automática	\N	PREFIX-00002-00031	\N	\N	f	f	0	3202	1
3205	19	Módulo de Partes de Traballo	\N	PREFIX-00002-00019	\N	\N	f	f	3	2245	5
3206	19	Procura de partes de traballo	\N	PREFIX-00002-00032	\N	\N	f	f	0	3205	0
3207	19	Módulo de materiais	\N	PREFIX-00002-00020	\N	\N	f	f	3	2245	6
3208	19	Informe de necesidades de materiais	\N	PREFIX-00002-00033	\N	\N	f	f	0	3207	0
3209	19	Módulo de xestión da calidade	\N	PREFIX-00002-00021	\N	\N	f	f	3	2245	7
3210	19	Administración de checklists	\N	PREFIX-00002-00034	\N	\N	f	f	0	3209	0
3211	19	Cubrir formularios de calidade en planificación	\N	PREFIX-00002-00035	\N	\N	f	f	0	3209	1
3212	19	Incorporar as listas de chequeo nos modelos de planificación	\N	PREFIX-00002-00036	\N	\N	f	f	0	3209	2
3213	19	Módulo de Importación-Exportación	\N	PREFIX-00002-00022	\N	\N	f	f	3	2245	8
3214	19	Definir workflow ERP pedidos	\N	PREFIX-00002-00037	\N	\N	f	f	0	3213	0
3215	19	Formato de intercambio de pedidos e elementos de pedidos	\N	PREFIX-00002-00038	\N	\N	f	f	0	3213	1
\.


--
-- Data for Name: orderelementtemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelementtemplate (id, version, name, description, code, startasdaysfrombeginning, deadlineasdaysfrombeginning, parent, positionincontainer) FROM stdin;
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid, lasthoursgroupsequencecode) FROM stdin;
3208	1
3210	1
3211	1
3212	1
3214	1
3215	1
3216	1
3217	1
3218	1
3220	1
3221	1
3223	1
3224	1
3226	1
3228	1
3230	1
3231	1
3333	1
3334	1
3335	1
3336	1
3337	1
3338	1
3339	1
3340	1
3341	1
3342	1
3358	1
3359	1
3360	1
3361	1
3362	1
3363	1
2298	1
2299	1
2300	1
2301	1
2303	1
2304	1
2305	1
2307	1
2308	1
2310	1
2311	1
2312	1
2313	1
3203	1
3204	1
3206	1
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
2245
2297
2302
2306
2309
3202
3205
3207
3209
3213
3219
3222
3225
3227
3229
3357
\.


--
-- Data for Name: orderlinegrouptemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegrouptemplate (group_template_id) FROM stdin;
\.


--
-- Data for Name: orderlinetemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinetemplate (order_line_template_id) FROM stdin;
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
606	3	PREFIX	2	5	t
\.


--
-- Data for Name: ordertemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordertemplate (order_template_id, base_calendar_id) FROM stdin;
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype) FROM stdin;
2929	1	Exemplo de formulario de calidade	Formulario de calidade de exemplo.	0
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
2929	¿Realizouse a primeira comprobación?	15.00	0	0
2929	¿Realizouse a segunda comprobación?	40.00	1	1
2929	¿Realizouse a terceira comprobación?	60.00	2	2
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, base_calendar_id) FROM stdin;
1320	3	1423
1328	3	1426
1322	4	1424
1314	5	1414
1330	3	1427
1316	4	1420
1326	3	1425
1333	2	1428
1335	2	1429
1337	4	1433
1339	2	1434
1341	2	1435
1343	2	1436
1345	2	1437
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
11903	1	1.00	10548	\N
11904	1	0.75	10549	\N
11905	1	0.75	10550	\N
11906	1	0.75	10551	\N
11907	1	0.75	10552	\N
11908	1	0.75	10553	\N
11909	1	0.75	10554	\N
11910	1	0.75	10555	\N
10634	15	0.25	10556	\N
10635	15	0.30	10557	\N
10669	9	1.00	10521	\N
10645	11	1.00	10522	\N
10623	16	1.00	10562	\N
11821	6	1.00	10563	\N
11822	6	1.00	10564	\N
11823	6	1.00	10565	\N
11824	6	1.00	10566	\N
11825	6	1.00	10567	\N
10694	7	1.00	10509	\N
10683	8	1.00	10510	\N
10670	9	1.00	10511	\N
11837	4	0.25	10532	\N
11838	4	0.25	10532	\N
11845	3	0.25	10541	\N
11846	3	0.15	10542	\N
10665	9	1.00	10516	\N
10666	9	1.00	10517	\N
10667	9	1.00	10518	\N
10649	10	1.00	10519	\N
10633	15	1.00	10513	\N
10646	11	1.00	10514	\N
11899	1	0.50	10559	\N
11900	1	0.25	10559	\N
11898	1	0.25	10559	\N
10692	7	1.00	10533	\N
10693	7	1.00	10534	\N
11839	4	0.25	10535	\N
11840	4	0.25	10536	\N
10668	9	1.00	10546	\N
10618	18	1.00	10504	\N
10619	18	1.00	10505	\N
10620	18	1.00	10506	\N
10621	18	1.00	10507	\N
10641	14	0.40	10538	\N
10642	14	0.70	10539	\N
11901	1	0.50	10560	\N
11902	1	0.50	10560	\N
11847	3	0.25	10544	\N
10682	8	1.00	10526	\N
10684	8	1.00	10524	\N
10680	8	1.00	10528	\N
10681	8	1.00	10529	\N
10650	10	1.00	10530	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
1423	1
1426	1
1424	1
1414	1
1427	1
1420	1
1425	1
1428	1
1429	1
1430	1
1431	1
1433	1
1434	1
1435	1
1436	1
1437	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, initdate, enddate, cost_category_id, resource_id) FROM stdin;
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
11845	1320
11846	1345
10665	1341
10666	1341
10667	1341
10649	1341
10633	1314
10646	1341
11899	1320
11900	1316
11898	1345
10680	1328
10681	1328
10650	1341
11903	1326
11904	1326
11905	1326
11906	1326
11907	1326
11908	1326
11909	1326
11910	1326
10634	1314
10635	1314
10669	1341
10645	1341
10623	1330
11821	1322
11822	1322
11823	1322
11824	1322
11825	1322
10694	1322
10683	1328
10670	1341
11837	1345
11838	1316
10692	1322
10693	1322
11839	1343
11840	1343
10668	1341
10618	1330
10619	1330
10620	1330
10621	1330
10641	1314
10642	1314
11901	1316
11902	1345
11847	1316
10682	1328
10684	1328
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
\.


--
-- Data for Name: subcontractedtaskdata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY subcontractedtaskdata (id, version, externalcompany, subcontratationdate, subcontractcommunicationdate, workdescription, subcontractprice, subcontractedcode, nodewithoutchildrenexported, labelsexported, materialassignmentsexported, hoursgroupsexported, criterionrequirementsexported) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate, subcontrated_task_data_id) FROM stdin;
10541	1	0	\N	\N
10542	1	0	\N	\N
10516	1	0	\N	\N
10517	1	0	\N	\N
10518	1	0	\N	\N
10519	1	0	\N	\N
10513	1	0	\N	\N
10514	1	0	\N	\N
10559	1	0	\N	\N
10528	1	0	\N	\N
10529	1	0	\N	\N
10530	1	0	\N	\N
10548	1	0	\N	\N
10549	1	0	\N	\N
10550	1	0	\N	\N
10551	1	0	\N	\N
10552	1	0	\N	\N
10553	1	0	\N	\N
10554	1	0	\N	\N
10555	1	0	\N	\N
10556	1	0	\N	\N
10557	1	0	\N	\N
10521	1	0	\N	\N
10522	1	0	\N	\N
10562	1	0	\N	\N
10563	1	0	\N	\N
10564	1	0	\N	\N
10565	1	0	\N	\N
10566	1	0	\N	\N
10567	1	0	\N	\N
10509	1	0	\N	\N
10510	1	0	\N	\N
10511	1	0	\N	\N
10532	1	0	\N	\N
10533	1	0	\N	\N
10534	1	0	\N	\N
10535	1	0	\N	\N
10536	1	0	\N	\N
10546	1	0	\N	\N
10504	1	0	\N	\N
10505	1	0	\N	\N
10506	1	0	\N	\N
10507	1	0	\N	\N
10538	1	0	\N	\N
10539	1	0	\N	\N
10560	1	0	\N	\N
10544	1	0	\N	\N
10526	1	0	\N	\N
10524	1	0	\N	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id) FROM stdin;
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
10504	3069
10505	3070
10506	3071
10507	3072
10509	3073
10510	3074
10511	3075
10513	3076
10514	3077
10516	3078
10517	3079
10518	3080
10519	3081
10521	3243
10522	3244
10524	3245
10526	3246
10528	3247
10529	3248
10530	3249
10532	3250
10533	3251
10534	3252
10535	3253
10536	3254
10538	3255
10539	3256
10541	3257
10542	3258
10544	3259
10546	3260
10548	3261
10549	3262
10550	3263
10551	3264
10552	3265
10553	3266
10554	3267
10555	3268
10556	3269
10557	3270
10559	3271
10560	3272
10562	3285
10563	3286
10564	3287
10565	3288
10566	3289
10567	3290
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
10543	46	Módulo de arquitectura tecnolóxica	\N	2009-12-14 00:00:00	2010-01-27 00:00:00	\N	10561	\N	10
10520	46	Módulo de planificación	\N	2009-12-14 00:00:00	2010-02-04 00:00:00	\N	10561	\N	3
10531	46	Módulo de xestión da calidade	\N	2009-12-14 00:00:00	2010-01-06 00:00:00	\N	10561	\N	7
10558	46	Módulo de Extracción de Informes	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	10561	\N	13
10523	46	Módulo de asignación de recursos	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	10561	\N	4
10537	46	Módulo de Importación-Exportación	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	10561	\N	8
10547	46	Módulo de Arquivo Histórico	\N	2009-12-14 00:00:00	2010-01-20 00:00:00	\N	10561	\N	12
10540	46	Módulo de Presentación	\N	2009-12-14 00:00:00	2010-01-28 00:00:00	\N	10561	\N	9
10545	46	Módulo de Documentación de API	\N	2009-12-14 00:00:00	2010-01-09 00:00:00	\N	10561	\N	11
10527	46	Módulo de materiais	\N	2009-12-14 00:00:00	2010-01-09 00:00:00	\N	10561	\N	6
10525	46	Módulo de Partes de Traballo	\N	2009-12-14 00:00:00	2010-01-02 00:00:00	\N	10561	\N	5
10519	33	Modelos de pedidos e planificación	\N	2009-12-22 00:00:00	2009-12-31 00:00:00	\N	10520	\N	3
10513	33	Recursos Virtuais	\N	2009-12-14 00:00:00	2009-12-19 00:00:00	\N	10515	\N	0
10514	33	Recursos Virtuais (Cont.)	\N	2009-12-19 00:00:00	2009-12-22 00:00:00	\N	10515	\N	1
10528	33	Administración de checklists	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	10531	\N	0
10529	33	Cubrir formularios de calidade en planificación	\N	2009-12-22 00:00:00	2009-12-26 00:00:00	\N	10531	\N	1
10530	33	Incorporar as listas de chequeo nos modelos de planificación	\N	2009-12-31 00:00:00	2010-01-06 00:00:00	\N	10531	\N	2
10521	33	Interpolación polinómica na asignación	\N	2010-01-20 00:00:00	2010-01-23 00:00:00	\N	10523	\N	0
10522	33	Asignación avanzada asignación automática	\N	2009-12-14 00:00:00	2009-12-19 00:00:00	\N	10523	\N	1
10509	33	Xestión de código único	\N	2009-12-22 00:00:00	2009-12-25 00:00:00	\N	10512	\N	0
10510	33	Revisión de formulario de pedidos	\N	2010-01-09 00:00:00	2010-01-20 00:00:00	\N	10512	\N	1
10511	33	Filtrado no listado de pedidos	\N	2010-01-29 00:00:00	2010-01-30 00:00:00	\N	10512	\N	2
10532	33	Definir workflow ERP pedidos	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	10537	\N	0
10533	33	Formato de intercambio de pedidos e elementos de pedidos	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	10537	\N	1
10534	33	Formato de intercambio de información de avances	\N	2009-12-25 00:00:00	2010-01-01 00:00:00	\N	10537	\N	2
10535	33	Formato de intercambio de recursos	\N	2009-12-14 00:00:00	2009-12-30 00:00:00	\N	10537	\N	3
10536	33	Formato de intercambio de materiais	\N	2009-12-30 00:00:00	2010-01-21 00:00:00	\N	10537	\N	4
10504	33	Xestión de usuarios	\N	2009-12-14 00:00:00	2009-12-15 00:00:00	\N	10508	\N	0
10505	33	Xestión de roles	\N	2009-12-15 00:00:00	2009-12-17 00:00:00	\N	10508	\N	1
10506	33	Xestión de perfiles	\N	2009-12-17 00:00:00	2009-12-19 00:00:00	\N	10508	\N	2
10507	33	Xestión de roles e pedidos	\N	2009-12-19 00:00:00	2009-12-26 00:00:00	\N	10508	\N	3
10538	33	Imprimir o diagrama de Gantt en varias páxinas	\N	2009-12-29 00:00:00	2010-01-28 00:00:00	\N	10540	\N	0
10526	33	Informe de necesidades de materiais	\N	2010-01-02 00:00:00	2010-01-09 00:00:00	\N	10527	\N	0
10524	33	Procura de partes de traballo	\N	2009-12-26 00:00:00	2010-01-02 00:00:00	\N	10525	\N	0
10561	46	4º release devenvolvemento aplicación xestión produción	\N	2009-12-14 00:00:00	2010-02-04 00:00:00	2010-01-29	\N	\N	\N
10516	33	Compartir estado entre pestañas de planificación	\N	2010-01-30 00:00:00	2010-02-04 00:00:00	\N	10520	\N	0
10517	33	Técnica de recálculo de asignacións	\N	2010-01-06 00:00:00	2010-01-14 00:00:00	\N	10520	\N	1
10518	33	Filtrado de pedidos e tarefas de un pedido	\N	2010-01-23 00:00:00	2010-01-29 00:00:00	\N	10520	\N	2
10541	33	Enlazar a axuda de usuario	\N	2009-12-14 00:00:00	2010-01-09 00:00:00	\N	10543	\N	0
10542	33	Desenvolvemento de paquetes Debian	\N	2009-12-14 00:00:00	2010-01-27 00:00:00	\N	10543	\N	1
10515	46	Módulo de recursos	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	10561	\N	2
10559	33	Coordinación	\N	2009-12-14 00:00:00	2010-01-27 00:00:00	\N	10561	\N	14
10548	33	Integración con Jasper Reports	\N	2009-12-14 00:00:00	2009-12-16 00:00:00	\N	10558	\N	0
10549	33	Informes sobre organizacións de traballo	\N	2010-01-13 00:00:00	2010-01-19 00:00:00	\N	10558	\N	1
10550	33	Informes sobre partes de traballo	\N	2010-01-19 00:00:00	2010-01-23 00:00:00	\N	10558	\N	2
10551	33	Informes de horas traballadas por un traballador	\N	2009-12-16 00:00:00	2009-12-22 00:00:00	\N	10558	\N	3
10552	33	Lista de avances de planificación da empresa	\N	2010-01-01 00:00:00	2010-01-07 00:00:00	\N	10558	\N	4
10553	33	Lista de avances de traballo da empresa	\N	2009-12-22 00:00:00	2009-12-26 00:00:00	\N	10558	\N	5
10554	33	Informe de horas estimadas/horas realies	\N	2009-12-26 00:00:00	2010-01-01 00:00:00	\N	10558	\N	6
10555	33	Horas realizadas organizadas por tipo de traballo	\N	2010-01-07 00:00:00	2010-01-13 00:00:00	\N	10558	\N	7
10556	33	Horas estimadas/horas realizadas por tipo de traballo	\N	2010-01-06 00:00:00	2010-01-22 00:00:00	\N	10558	\N	8
10557	33	Informe de traballador indicando custos por hora	\N	2009-12-19 00:00:00	2010-01-06 00:00:00	\N	10558	\N	9
10568	40	Módulo de integración con subcontratas	\N	2009-12-14 00:00:00	2010-01-26 00:00:00	\N	10561	\N	16
10562	29	Administración das subcontratas	\N	2009-12-26 00:00:00	2010-01-07 00:00:00	\N	10568	\N	0
10563	29	Formato de intercambio	\N	2010-01-01 00:00:00	2010-01-05 00:00:00	\N	10568	\N	1
10564	29	Fluxo de importación/exportación	\N	2010-01-05 00:00:00	2010-01-09 00:00:00	\N	10568	\N	2
10565	29	Interfaz de xestión de subcontratas	\N	2010-01-09 00:00:00	2010-01-16 00:00:00	\N	10568	\N	3
10566	29	Convertir en fitos subcontratacións	\N	2010-01-16 00:00:00	2010-01-20 00:00:00	\N	10568	\N	4
10567	29	Avance e custo de subcontratas en Técnica VG	\N	2010-01-20 00:00:00	2010-01-26 00:00:00	\N	10568	\N	5
10512	46	Módulo de organización do traballo	\N	2009-12-14 00:00:00	2010-01-30 00:00:00	\N	10561	\N	1
10546	33	Pasar pedidos a Histórico	\N	2010-01-14 00:00:00	2010-01-20 00:00:00	\N	10547	\N	0
10508	46	Módulo de Xestión de Usuarios	\N	2009-12-14 00:00:00	2009-12-26 00:00:00	\N	10561	\N	0
10539	33	Imprimir información pantalla do planificador	\N	2009-12-19 00:00:00	2009-12-29 00:00:00	\N	10540	\N	1
10560	33	Análise	\N	2009-12-14 00:00:00	2010-01-27 00:00:00	\N	10561	\N	15
10544	33	Documentación das APIs públicas da aplicación	\N	2009-12-14 00:00:00	2010-01-09 00:00:00	\N	10545	\N	0
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
10508
10512
10515
10520
10523
10525
10527
10531
10537
10540
10543
10545
10547
10558
10561
10568
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
10508	14	2297
10512	14	2302
10515	14	2306
10520	14	2309
10523	14	3202
10525	14	3205
10527	14	3207
10531	14	3209
10537	14	3213
10540	14	3219
10543	14	3222
10545	14	3225
10547	14	3227
10558	14	3229
10561	14	2245
10504	27	2298
10505	27	2299
10506	27	2300
10507	27	2301
10509	27	2303
10510	27	2304
10511	27	2305
10513	27	2307
10514	27	2308
10516	27	2310
10517	27	2311
10518	27	2312
10519	27	2313
10521	27	3203
10522	27	3204
10524	27	3206
10526	27	3208
10528	27	3210
10529	27	3211
10530	27	3212
10532	27	3214
10533	27	3215
10534	27	3216
10535	27	3217
10536	27	3218
10538	27	3220
10539	27	3221
10541	27	3223
10542	27	3224
10544	27	3226
10546	27	3228
10548	27	3230
10549	27	3231
10550	27	3333
10551	27	3334
10552	27	3335
10568	12	3357
10553	27	3336
10554	27	3337
10555	27	3338
10556	27	3339
10557	27	3340
10559	27	3341
10560	27	3342
10562	23	3358
10563	23	3359
10564	23	3360
10565	23	3361
10566	23	3362
10567	23	3363
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled) FROM stdin;
2626	1	NORMAL	1	9.00	t
2627	1	EXTRAORDINARIA	2	12.00	t
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
910	ROLE_ADMINISTRATION
911	ROLE_WS_READER
912	ROLE_WS_READER
912	ROLE_WS_WRITER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, work_report_type_id, resource_id, order_element_id) FROM stdin;
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, positionnumber, label_type_id, label_id, work_report_type_id) FROM stdin;
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1320	Xavier	Contra Gonzalez	33333333C
1328	Susana	Maneiro Garcia	66666666F
1322	Moncho	Ramirez Correa	44444444D
1314	Luis	Tome Alvarez	11111111A
1330	Jose	Armendariz Pino	77777777H
1316	Javier	Machado Romero	22222222B
1326	Daniel	Paz Gonzalez	55555555E
1333	Suso	Ramirez Ramirez	9999999R
1335	Santiago	Solla Sobrino	10000000V
1341	Oscar	Garcia Ferreira	11111111C
1343	Francisco	Baamonde	22222222G
1345	Chema	Castiñeira Castro	33333333T
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: external_company_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_name_key UNIQUE (name);


--
-- Name: external_company_nif_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_nif_key UNIQUE (nif);


--
-- Name: external_company_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_template_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT material_assigment_template_pkey PRIMARY KEY (id);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT order_authorization_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_element_template_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT order_element_template_label_pkey PRIMARY KEY (order_element_template_id, label_id);


--
-- Name: order_element_template_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT order_element_template_quality_form_pkey PRIMARY KEY (order_element_template_id, quality_form_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_code_key UNIQUE (code);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderelementtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT orderelementtemplate_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegrouptemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT orderlinegrouptemplate_pkey PRIMARY KEY (group_template_id);


--
-- Name: orderlinetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT orderlinetemplate_pkey PRIMARY KEY (order_line_template_id);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: ordertemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT ordertemplate_pkey PRIMARY KEY (order_template_id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_base_calendar_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_base_calendar_id_key UNIQUE (base_calendar_id);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: subcontractedtaskdata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT subcontractedtaskdata_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: task_subcontrated_task_data_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_subcontrated_task_data_id_key UNIQUE (subcontrated_task_data_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk1ccb0f7419b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f7419b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk1ccb0f74b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f74b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk27a9a55b595a0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a55b595a0 FOREIGN KEY (subcontrated_task_data_id) REFERENCES subcontractedtaskdata(id);


--
-- Name: fk29d0015519b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d0015519b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk29d001558b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d001558b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk4a1d42dc9fb7fc18; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT fk4a1d42dc9fb7fc18 FOREIGN KEY (order_line_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk4d68b9c89a4a7d90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c89a4a7d90 FOREIGN KEY (order_template_id) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fk4d68b9c8a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c8a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fk9bb0b28841638aab; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT fk9bb0b28841638aab FOREIGN KEY (parent) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fka87c31085567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c31085567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fka87c310887287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c310887287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fka87c3108edc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c3108edc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fka9542ec319b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec319b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fka9542ec3c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec3c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f501b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f501b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkd3056ef7ddc82952; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT fkd3056ef7ddc82952 FOREIGN KEY (group_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke562c7e93fee60cc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT fke562c7e93fee60cc FOREIGN KEY (companyuser) REFERENCES naval_user(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkecc6114019960f43; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT fkecc6114019960f43 FOREIGN KEY (externalcompany) REFERENCES external_company(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282edc874c20; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282edc874c20 FOREIGN KEY (base_calendar_id) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

