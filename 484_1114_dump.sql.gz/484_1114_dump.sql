--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advanceassignmenttemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignmenttemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    advance_type_id bigint,
    order_element_template_id bigint,
    reportglobaladvance boolean,
    maxvalue numeric(19,2)
);


ALTER TABLE public.advanceassignmenttemplate OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint,
    communicationdate timestamp without time zone
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean,
    qualityform boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date date,
    hours integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255),
    generatecodeforcriterion boolean NOT NULL,
    generatecodeforlabel boolean NOT NULL,
    generatecodeforworkreport boolean NOT NULL,
    generatecodeforresources boolean NOT NULL,
    generatecodefortypesofworkhours boolean NOT NULL,
    generatecodeformaterialcategories boolean NOT NULL,
    generatecodeforunittypes boolean NOT NULL,
    expandcompanyplanningviewcharts boolean NOT NULL,
    expandorderplanningviewcharts boolean NOT NULL,
    expandresourceloadviewcharts boolean
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: consolidatedvalue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidatedvalue (
    id bigint NOT NULL,
    consolidated_value_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    consolidation_id bigint,
    advance_measurement_id bigint,
    taskenddate date
);


ALTER TABLE public.consolidatedvalue OWNER TO naval;

--
-- Name: consolidation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE consolidation (
    id bigint NOT NULL,
    consolidation_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    dir_advance_assignment_id bigint,
    ind_advance_assignment_id bigint
);


ALTER TABLE public.consolidation OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    order_element_template_id bigint,
    criterion_id bigint,
    parent bigint,
    valid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    generatecode boolean NOT NULL,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    consolidated boolean,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint,
    derived_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer,
    queue_dependency bigint
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: external_company; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE external_company (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    nif character varying(255),
    client boolean,
    subcontractor boolean,
    interactswithapplications boolean,
    appuri character varying(255),
    ourcompanylogin character varying(255),
    ourcompanypassword character varying(255),
    companyuser bigint
);


ALTER TABLE public.external_company OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    resourcetype character varying(255),
    workinghours integer NOT NULL,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint,
    order_line_template bigint
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: limiting_resource_queue; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_id bigint
);


ALTER TABLE public.limiting_resource_queue OWNER TO naval;

--
-- Name: limiting_resource_queue_dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_dependency (
    id bigint NOT NULL,
    type integer,
    origin_queue_element_id bigint,
    destiny_queue_element_id bigint
);


ALTER TABLE public.limiting_resource_queue_dependency OWNER TO naval;

--
-- Name: limiting_resource_queue_element; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE limiting_resource_queue_element (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint,
    limiting_resource_queue_id bigint,
    earlier_start_date_because_of_gantt timestamp without time zone,
    creation_timestamp bigint,
    start_date date,
    start_hour integer,
    end_date date,
    end_hour integer,
    earliest_end_date_because_of_gantt timestamp without time zone
);


ALTER TABLE public.limiting_resource_queue_element OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type bigint,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_assigment_template; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment_template (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    material_id bigint,
    order_element_template_id bigint
);


ALTER TABLE public.material_assigment_template OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    generatecode boolean NOT NULL,
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_authorization; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_authorization (
    id bigint NOT NULL,
    order_authorization_subclass character varying(255) NOT NULL,
    version bigint NOT NULL,
    authorizationtype character varying(255) NOT NULL,
    order_id bigint,
    user_id bigint,
    profile_id bigint
);


ALTER TABLE public.order_authorization OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_element_template_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_label (
    order_element_template_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_label OWNER TO naval;

--
-- Name: order_element_template_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_template_quality_form (
    order_element_template_id bigint NOT NULL,
    quality_form_id bigint NOT NULL
);


ALTER TABLE public.order_element_template_quality_form OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    dependenciesconstraintshavepriority boolean,
    codeautogenerated boolean,
    lastorderelementsequencecode integer,
    workbudget numeric(19,2),
    materialsbudget numeric(19,2),
    totalhours integer,
    customerreference character varying(255),
    externalcode character varying(255),
    state integer,
    customer bigint,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    schedulingstatetype integer,
    parent bigint,
    template bigint,
    externalcode character varying(255),
    positionincontainer integer,
    lastadvancemeausurementforspreading numeric(19,2),
    dirtylastadvancemeasurementforspreading boolean
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderelementtemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelementtemplate (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    code character varying(255),
    startasdaysfrombeginning integer,
    deadlineasdaysfrombeginning integer,
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelementtemplate OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: orderlinegrouptemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegrouptemplate (
    group_template_id bigint NOT NULL
);


ALTER TABLE public.orderlinegrouptemplate OWNER TO naval;

--
-- Name: orderlinetemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinetemplate (
    order_line_template_id bigint NOT NULL,
    lasthoursgroupsequencecode integer
);


ALTER TABLE public.orderlinetemplate OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: ordertemplate; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordertemplate (
    order_template_id bigint NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.ordertemplate OWNER TO naval;

--
-- Name: pending_consolidated_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE pending_consolidated_hours (
    pending_hours_id bigint NOT NULL,
    pendingconsolidatedhours integer,
    resource_allocation_id bigint
);


ALTER TABLE public.pending_consolidated_hours OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer,
    reportadvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    generatecode boolean NOT NULL,
    limited_resource boolean NOT NULL,
    base_calendar_id bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    intended_total_hours integer,
    originaltotalassignment integer,
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL,
    type integer
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: subcontractedtaskdata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE subcontractedtaskdata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    externalcompany bigint,
    subcontratationdate timestamp without time zone,
    subcontractcommunicationdate timestamp without time zone,
    workdescription character varying(255),
    subcontractprice numeric(19,2),
    subcontractedcode character varying(255),
    nodewithoutchildrenexported boolean,
    labelsexported boolean,
    materialassignmentsexported boolean,
    hoursgroupsexported boolean,
    state integer
);


ALTER TABLE public.subcontractedtaskdata OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone,
    subcontrated_task_data_id bigint,
    priority integer
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint,
    reportadvance boolean
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone NOT NULL,
    enddate timestamp without time zone NOT NULL,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer,
    advancepercentage numeric(19,2)
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean,
    generatecode boolean NOT NULL
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: unit_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE unit_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    measure character varying(255),
    generatecode boolean NOT NULL
);


ALTER TABLE public.unit_type OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    date timestamp without time zone,
    generatecode boolean NOT NULL,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    positionnumber integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart integer,
    clockfinish integer,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
2496783	4	f	910
2496784	4	t	912
2496785	4	f	910
1925	6	t	909
2496786	4	t	912
2496787	4	t	912
2496740	5	t	909
2494921	2	t	910
2496788	4	f	910
2494922	2	t	910
2494923	2	f	910
2494924	2	t	910
2496789	4	f	912
2496739	4	t	909
2496791	3	f	912
2496790	3	f	910
2496736	3	t	910
2496737	3	t	910
2496738	3	t	910
3835563	3	t	910
49998	26	t	909
49999	26	t	909
50003	22	t	909
50005	19	t	909
3504322	3	t	909
3835564	3	t	910
3835565	3	t	910
3835482	2	t	910
3835483	2	t	910
13552	3	t	909
13553	3	t	909
13554	3	t	909
3835484	2	t	910
2494909	2	t	910
3835566	3	t	910
3504349	2	f	912
3504350	2	f	910
2494910	2	f	910
2494911	2	f	910
3835485	2	f	910
3835486	2	t	909
3835567	3	t	910
3835568	3	f	910
3835569	3	t	910
3835570	3	t	910
3504351	1	t	912
3504352	1	f	912
2496792	1	t	912
2496793	1	f	912
2496794	1	f	912
3504353	1	f	912
3504346	3	t	912
3504345	3	f	910
3504348	3	f	912
3504326	4	t	909
3504347	3	f	910
3835571	3	t	910
3835572	3	t	910
3835573	3	t	910
3835574	3	t	910
3835575	3	f	910
3839111	3	t	910
3839112	3	t	910
3504297	2	t	910
3839113	3	t	910
3839114	3	t	910
3839115	3	t	910
3839116	3	t	910
3839117	3	t	910
3839118	3	t	910
3839119	3	f	910
3839120	3	t	910
3839121	3	t	910
3839122	3	t	910
3839123	3	t	910
3839124	3	t	910
3839125	3	t	910
3839126	3	f	910
3839127	3	t	910
3839128	3	t	909
3504320	6	t	909
3504321	6	t	909
3504313	7	t	909
3839129	3	f	910
13547	10	t	910
2494902	8	t	910
2496797	5	t	3480461
13548	10	f	910
2496798	5	f	3480461
13541	12	t	909
3835475	2	t	910
3835476	7	t	910
3835477	7	t	910
3835478	7	t	910
3835479	7	t	910
3835480	7	f	910
3835481	7	t	909
3835506	3	t	910
3835507	3	t	910
3835508	3	t	910
3835509	3	t	910
3835510	3	t	910
3510765	40	t	909
3510763	42	t	909
3510764	41	t	909
3510767	38	t	909
3510768	38	t	909
3510769	37	t	909
3510770	36	t	909
3510772	34	t	909
3510766	39	t	909
3839130	3	t	910
3839131	3	t	910
3839132	3	t	912
3839134	3	t	909
3839133	3	f	910
3839135	3	f	910
3839136	3	t	909
3835511	3	t	910
3835512	3	t	910
3835513	3	f	910
3835514	3	t	910
3835515	3	t	910
3835516	3	t	910
3835517	3	t	910
3835518	3	t	910
3835519	3	t	910
3835520	3	t	910
3835521	3	t	909
3835522	3	f	910
3835523	3	t	910
3835524	3	t	910
3835525	3	t	910
3835526	3	t	910
3835527	3	t	910
3835528	3	f	910
3835529	3	t	910
3835530	3	t	910
3835531	3	t	910
3835532	3	t	910
3835533	3	t	910
3835534	3	f	910
3835535	3	t	910
3835536	3	t	910
3835537	3	t	910
3835538	3	t	910
3835539	3	t	910
3835540	3	f	910
3835541	3	t	910
3835542	3	t	910
3835543	3	t	910
3835544	3	t	910
3835545	3	t	910
3835546	3	t	910
3835547	3	t	910
3835548	3	t	910
3835549	3	t	910
3835550	3	t	910
3835551	3	t	910
3835552	3	t	910
3835553	3	t	910
3835554	3	t	910
3835555	3	f	910
3835556	3	t	910
3835557	3	t	910
3835558	3	t	910
3835559	3	t	910
3835560	3	t	910
3835561	3	t	910
3835562	3	t	910
\.


--
-- Data for Name: advanceassignmenttemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignmenttemplate (id, version, advance_type_id, order_element_template_id, reportglobaladvance, maxvalue) FROM stdin;
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id, communicationdate) FROM stdin;
3504399	2	2010-05-17	40.00	3504297	\N
3504400	2	2010-05-11	20.00	3504297	\N
2494814	2	2010-05-13	25.00	2494909	\N
2494818	2	2010-05-13	30.00	2494921	\N
2494819	2	2010-05-13	30.00	2494922	\N
3504407	2	2010-05-17	20.00	3504345	\N
3504409	1	2010-05-17	15.00	3504351	\N
2496830	3	2010-05-14	100.00	2496736	\N
2496831	3	2010-05-13	25.00	2496737	\N
3504408	3	2010-05-17	15.00	3504346	2010-05-17 18:29:22.318
2494802	9	2010-05-13	100.00	13547	\N
15658	10	2010-05-07	20.00	13547	\N
2494811	7	2010-05-13	50.00	2494902	\N
2494803	8	2010-05-11	25.00	2494902	\N
2496857	5	2010-05-17	20.00	2496797	\N
2496855	1	2010-05-14	38.32	2496792	\N
2496850	3	2010-05-14	60.00	2496783	\N
2496851	4	2010-05-14	50.00	2496784	2010-05-14 15:55:36.437
2496852	3	2010-05-14	50.00	2496785	\N
2496853	4	2010-05-14	40.00	2496786	2010-05-14 15:55:36.437
2496854	4	2010-05-14	25.00	2496787	2010-05-14 15:55:36.437
3836497	6	2010-05-20	50.00	3835476	\N
3836498	6	2010-05-18	20.00	3835476	\N
3836505	4	2010-05-28	20.00	3835478	\N
3836512	3	2010-06-07	30.00	3835479	\N
3836520	2	2010-04-07	50.00	3835477	\N
3836529	3	2010-06-08	60.00	3835514	\N
3836530	3	2010-03-07	10.00	3835514	\N
3836545	2	2010-06-07	50.00	3839132	\N
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage, qualityform) FROM stdin;
909	4	children	100.0000	f	0.0100	t	t	f
910	3	percentage	100.0000	f	0.0100	t	t	f
911	2	units	2147483647.0000	f	1.0000	t	f	f
912	1	subcontractor	100.0000	f	0.0100	t	t	f
913	1	Importe	10000000.0000	t	0.1000	t	f	f
914	1	Importe (pactado)	10000000.0000	t	1.0000	t	f	f
915	1	Toneladas	1000.0000	t	0.1000	t	f	f
3480460	1	Porcentage (pactado)	100.0000	t	0.1000	t	f	f
3480461	1	QF: Cuestionario calidade estandar	100.0000	f	0.0100	t	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
2679	108
2680	108
2681	108
2717	108
2718	124
2719	126
2720	108
2721	124
14142	124
14143	124
14146	124
14147	110
14148	124
14149	124
14150	110
14151	124
24071	108
24072	108
3505617	108
24074	108
27674	124
27675	105
39509	124
39510	109
39511	110
39518	108
39519	124
39520	108
57178	49793
57179	49798
57180	49797
3505622	105
3511787	3510560
3511789	3510560
3511790	3510560
3511791	3510560
3511792	3510560
3511793	3510560
3511795	3510558
3518347	3510558
3518348	3510558
3518349	3510558
3518350	3510558
3518351	3510559
3518352	3510559
3518353	3510559
3518354	3510559
3518355	3510559
3518356	3510559
3518380	3510559
3518381	3510559
3518382	3510559
3518383	3510559
3518384	3510559
3518385	3510559
3518386	3510559
3518387	3510559
3518388	3510559
3522858	3510559
3522859	3510559
3522860	3510559
3522861	3510559
3522862	3510559
3522863	3510559
3522864	3510559
3522865	3510559
3559792	3510559
3559793	3510559
3559794	3510559
3559795	3510559
3559796	3510559
3559797	3510559
3559799	3510559
3559800	3510559
3559802	3510559
3559803	3510559
3659355	3510559
3659356	3510559
3659364	3510559
3659365	3510559
3659366	3510559
3659367	3510559
3659387	3510559
3659389	3510559
3679794	3510559
3679795	3510559
3679796	3510559
3679797	3510559
3679798	3510559
3679799	3510559
3679800	3510559
3679801	3510559
3766823	3510564
3766824	3510565
2379862	49795
2494207	126
2494210	124
2494211	108
2494212	124
3766828	3510563
3766829	3510563
3766830	3510563
3766831	3510563
3766832	3510563
3766833	3510563
3766834	3510563
3766861	3510566
3819130	3510567
3819130	3510564
3819131	3510567
3819131	3510564
3819132	3510567
3819132	3510564
3819133	3510567
3819133	3510564
3819135	3510559
3836283	110
3836284	124
3836285	124
3836286	124
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
16363	4
3467028	3
3467029	3
3467030	3
3467032	4
3506317	4
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, code, name) FROM stdin;
422	3	5dbb608d-da47-4026-a618-e9cb6f5a8dbe	\N
404	6	0f51e60f-a149-4cfb-a29b-40f78bed683a	España
405	1	0cf16562-abf4-4f73-8988-ebe39f5b9006	Galicia
406	1	bb51856c-5d7d-43e8-884e-efdaa031265a	Ferrol
407	1	7391bb01-4a5c-4b92-89d0-b58e1bb0d2f1	Vigo
408	1	c8386ce2-dc7c-4584-b5ca-93d4bd461a0f	Maquinas 16h
409	1	d168e5c8-8c12-4c35-bd80-02cfb76e4ce8	Máquinas 24h
411	1	af089a6c-5b21-499a-925e-03c546be7889	\N
414	1	517148c4-06bd-41f2-911f-53ada393a02b	\N
39087	2	81f8e742-8d12-4398-8fef-bc4be2cb0fa8	\N
39091	3	39ba8411-0f68-4356-be49-73da7869d776	\N
415	37	cb406ea7-9b36-4dff-924b-c6a5b80a4f61	\N
3513286	18	8224ec33-f889-4492-af2f-a1c9d5524759	\N
3513285	2	7c2ee31c-a293-4c28-8fc8-8156fe0dcc9d	\N
39088	8	4486b746-229d-40bf-9389-3ad35ff0ab27	\N
3513288	4	f53f7892-d211-4288-98ef-229fbb12c67c	\N
3513291	1	950b7167-a564-4d2f-be99-c579290dbe39	\N
3513289	3	c18e4db9-1d52-401b-9bd0-9338ed477a30	\N
3513290	2	5df632c0-bdc8-461d-a5c9-7ce329911824	\N
417	31	c4d6b245-ac35-4559-8d63-49886b3052a9	\N
39094	2	27af426b-e05b-47a5-a8e2-9cc2968d10fa	\N
412	2	986e6a4e-3fae-490c-b3b1-e9f28839b591	\N
420	24	70c34204-582f-44f5-bf82-ecbae1344ea8	\N
39095	3	7d58a4df-359e-4b4d-89f7-50657c4425a1	\N
418	18	3fa62c2c-6f9e-4709-8d84-de168c0e6c8f	\N
14444	4	9128f4c3-09f3-4d97-8526-3a7f0ffa6c09	\N
39089	3	21e87161-9fd1-4a14-9121-af1f9d41e20a	\N
39101	2	42bffd02-29b3-4130-b117-00359ed41d61	\N
39103	2	9d012906-81dd-49a9-b18d-64cd79c4d1c9	\N
421	3	4d061406-6370-4523-9c06-295e6a1ab587	\N
39100	3	2520ae0d-1a72-458e-a6eb-56999890dda7	\N
413	2	3bf70e91-d50b-4303-a5d4-513a68f18a65	\N
410	2	3778986f-6fe9-4d49-ac41-7961ffc32476	\N
423	2	94161015-6159-4ff3-a383-75528fcaebd0	\N
39092	2	c153c0c2-72df-4a33-9083-f673667fce8f	\N
39102	2	3d19ee0a-9031-4208-88e6-771f5c2fb7b0	\N
3504599	4	8c28e8a7-0ab8-4d18-a6b4-710c685845f2	\N
39096	2	5ccab13f-76b3-4151-a29a-6973d4f1a26d	\N
26563	3	0f35407b-d046-47e1-b2d3-89bfe07b3a1f	\N
39098	2	3fd2ffd5-43e8-490d-9442-49bb84539ad0	\N
419	18	471ffbf4-e05b-4119-975a-74ab182055d0	\N
416	38	eae1d12f-5fed-4ae3-8fcd-cf21a507e6b5	\N
14443	3	bb97e91d-19e4-482a-843d-363fe819b48e	\N
39099	2	cff43092-e2f4-47a6-9c54-a125b9ae4bd0	\N
3513287	1	ecb28c06-3d13-4985-8567-2a6e1a7a4378	\N
39097	2	d257d90c-cacc-4bba-8a45-8da072c07f83	\N
39090	2	f9d25679-30f6-41f3-8589-868c58949a47	\N
39093	2	39f71b61-c0c4-4d30-907c-e3c087a5cc26	\N
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
1617	1	2010-05-04	\N	411	0
1620	1	2010-05-04	\N	414	0
3513489	1	2010-05-25	\N	3513287	0
3513488	18	2010-01-01	\N	3513286	0
3513487	2	2010-01-01	\N	3513285	0
39290	8	2010-01-01	\N	39088	0
3513490	4	2010-01-01	\N	3513288	0
1623	31	2010-05-04	\N	417	0
39296	2	2010-05-12	\N	39094	0
1618	2	2010-05-04	\N	412	0
1626	24	2010-05-04	\N	420	0
39297	3	2010-05-12	\N	39095	0
1624	18	2010-05-04	\N	418	0
14646	4	2010-05-06	\N	14444	0
39291	3	2010-05-12	\N	39089	0
39303	2	2010-05-12	\N	39101	0
39305	2	2010-05-12	\N	39103	0
1627	3	2010-05-04	\N	421	0
39302	3	2010-05-12	\N	39100	0
1619	2	2010-05-04	\N	413	0
1616	2	2010-05-04	\N	410	0
1629	2	2010-05-04	\N	423	0
39294	2	2010-05-12	\N	39092	0
39304	2	2010-05-12	\N	39102	0
3504801	4	2010-05-17	\N	3504599	0
39298	2	2010-05-12	\N	39096	0
26765	3	2010-05-12	\N	26563	0
3513493	1	2010-05-25	\N	3513291	0
39300	2	2010-05-12	\N	39098	0
3513491	3	2010-01-01	\N	3513289	0
3513492	2	2010-05-25	\N	3513290	0
1625	18	2010-05-04	\N	419	0
1622	38	2010-05-04	\N	416	0
14645	3	2010-05-06	\N	14443	0
39301	2	2010-05-12	\N	39099	0
39299	2	2010-05-12	\N	39097	0
39292	2	2010-05-12	\N	39090	0
39295	2	2010-05-12	\N	39093	0
1628	3	2010-05-04	\N	422	0
39289	2	2010-05-12	\N	39087	0
39293	3	2010-05-12	\N	39091	0
1621	37	2010-05-04	\N	415	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, code, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
3513390	3	914c88db-1c79-41e3-97f3-c823178b6a07	404	\N	3513289	0
39202	2	859526cd-e38d-4dba-b404-0973390382c1	404	\N	39101	0
505	6	c3862494-9d88-41b3-8ec7-ad1a05bd538b	\N	\N	404	0
506	1	55e4d7e1-fed7-45d1-9f02-8440a4502c02	404	\N	405	0
39204	2	30389927-6cbe-4326-9e3a-860f537ed58e	404	\N	39103	0
507	1	10a25ba1-109f-4ac1-a4b7-79d0269764e9	405	\N	406	0
3513391	2	e3a5a4a9-0592-42fa-8ceb-1a9f397e0207	404	\N	3513290	0
508	1	35ddb31b-2ae2-477d-a409-6288db1a6920	405	\N	407	0
509	1	8c548019-8af4-41b4-8a32-2cb5e23b34de	\N	\N	408	0
522	3	3e80454c-8bab-4d9d-8ef0-340946ac45df	407	\N	421	0
510	1	5c6853f2-8763-4935-91cc-397d68803a2f	\N	\N	409	0
39201	3	e1416b54-afe5-4e9b-b829-8bc60782992c	404	\N	39100	0
512	1	9baf6727-7875-4653-86ad-a80fd099be74	404	\N	411	0
515	1	78355e4b-cdb8-420e-ab6b-1a6941f568ca	404	\N	414	0
514	2	7ce3b321-eae1-46cf-a2d3-cbb627edc4c6	404	\N	413	0
511	2	d8d7ea87-4281-4734-afbb-3377b7e8d0a0	408	\N	410	0
524	2	b9b3855e-5385-4aa3-8d0c-aaac37b9948e	407	\N	423	0
39193	2	efb43d11-ee0e-4964-8635-b10a983241c3	404	\N	39092	0
3513388	1	1abd5acc-6298-43bf-9ef8-146d5597ed1f	404	\N	3513287	0
39203	2	ef74fb45-9bcd-416d-9f4a-e1a855f25562	404	\N	39102	0
3513387	18	572a8966-8ab5-463f-ae4f-2af71fc6ce57	404	\N	3513286	0
3504700	4	f19bc11a-596a-45c1-8233-6aef7e7369d3	407	\N	3504599	0
3513386	2	5b004290-1626-4c6a-9ec8-4cd2f0a2c746	404	\N	3513285	0
39197	2	d177636b-b5dc-45c5-9d60-d8806aef3ca8	404	\N	39096	0
39189	8	aceb7add-27df-4404-b279-f63df6ef6bf2	404	\N	39088	0
3513389	4	3c69a77a-c51d-4667-8a81-6877f3e1a298	404	\N	3513288	0
26664	3	d467c5c2-839a-438c-92da-8138b182530a	404	\N	26563	0
39199	2	490cded6-9269-4da8-84bc-bae8a628cb7b	404	\N	39098	0
520	18	d63564e3-835a-456f-8b71-6070b3e1f9fa	407	\N	419	0
3513392	1	c08dbb05-be70-4e8a-ac56-63952d5fce43	404	\N	3513291	0
518	31	2eab6f15-85e3-4638-9122-e0b9274a130a	407	\N	417	0
39195	2	fa59c42a-882b-44f7-9801-4d0694915445	404	\N	39094	0
513	2	bcf82fa5-f8d7-4003-975f-ee50eedf6a84	407	\N	412	0
521	24	b571dca1-4ae9-4852-8fef-8244128df644	407	\N	420	0
517	38	aa9bddff-807a-4a7d-aa31-ba3813089b70	406	\N	416	0
14544	3	a3438a7e-e378-48af-9259-de6679a522ad	404	\N	14443	0
39200	2	560e5691-e00c-4959-bdb1-233711d87d18	404	\N	39099	0
39196	3	50d847ec-a79b-406e-9a79-c3033dbe650b	404	\N	39095	0
519	18	b9bc7bc5-3d9d-4ae1-a637-2ac667fb3aec	407	\N	418	0
14545	4	47406021-c283-4241-81a5-11d2947aca0b	404	\N	14444	0
39190	3	26701598-4701-4f25-ab11-d78faf6c95d0	404	\N	39089	0
39198	2	d6c39db9-0df1-4ffe-a3b0-0fc4f2946f3c	404	\N	39097	0
39191	2	f0148e5a-99cf-4ea7-a525-b2af47eeb54b	404	\N	39090	0
39194	2	d2d15e77-183b-4726-977c-b166aad31c35	404	\N	39093	0
523	3	4419229e-9c87-4029-a8a3-3d29a7b13501	407	\N	422	0
39188	2	2b6bda6a-abf3-4f6a-96d2-d2b78fd8c78d	404	\N	39087	0
39192	3	ee00feeb-4930-40d3-bafd-36d81ba65e66	404	\N	39091	0
516	37	bbdc1fac-3f47-4301-89b4-645fc8bfaf66	406	\N	415	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, code, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
1212	1	8e045b85-1927-4bd7-ba47-3f49634d9f7d	2011-10-12	0	812	404
1213	1	0915b0f0-0488-4cf8-a1cc-17f2e31c9079	2011-12-06	0	812	404
1214	1	560b0126-ccf6-4b21-abc9-5ad06a92efb5	2010-12-06	0	812	404
1215	1	b82c80db-8a63-4c49-85c6-095dd655b46c	2011-01-06	0	812	404
1216	1	3ee65f0d-11bc-4b34-9c4d-93d8827d4d9f	2010-12-08	0	812	404
1217	1	c34e59e9-5aaf-4cdf-957e-4f743ba1dee8	2010-10-12	0	812	404
1218	1	36caa81f-b24c-4980-841a-89b16a298b84	2011-12-08	0	812	404
1219	1	a470c48c-a20c-4d7c-8646-341c93e317c0	2010-11-01	0	812	405
1220	1	269da39a-4414-4bb7-ba62-b66d2a21b0c2	2010-05-17	0	812	405
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, code, name, color, notassignable) FROM stdin;
808	6	HOLIDAY	HOLIDAY	red	t
809	5	SICK_LEAVE	SICK_LEAVE	red	t
810	4	LEAVE	LEAVE	red	t
811	3	STRIKE	STRIKE	red	t
812	2	BANK_HOLIDAY	BANK_HOLIDAY	red	t
813	1	WORKABLE_BANK_HOLIDAY	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode, generatecodeforcriterion, generatecodeforlabel, generatecodeforworkreport, generatecodeforresources, generatecodefortypesofworkhours, generatecodeformaterialcategories, generatecodeforunittypes, expandcompanyplanningviewcharts, expandorderplanningviewcharts, expandresourceloadviewcharts) FROM stdin;
606	6	404	B15804842	t	t	t	t	t	t	t	t	t	t
\.


--
-- Data for Name: consolidatedvalue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidatedvalue (id, consolidated_value_type, version, date, value, consolidation_id, advance_measurement_id, taskenddate) FROM stdin;
16262	NonCalculated	0	2010-05-07	20.00	13946	15658	\N
3835612	NonCalculated	1	2010-06-07	30.00	3835983	3836512	2010-06-03
3835606	NonCalculated	2	2010-05-28	20.00	3835982	3836505	2010-05-29
3835599	NonCalculated	4	2010-05-18	20.00	3835980	3836498	2010-05-22
3835600	NonCalculated	4	2010-05-20	50.00	3835980	3836497	2010-05-22
3835660	NonCalculated	1	2010-03-07	10.00	3511070	3836530	2010-09-30
3835661	NonCalculated	1	2010-06-08	60.00	3511070	3836529	2010-07-10
\.


--
-- Data for Name: consolidation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY consolidation (id, consolidation_type, version, dir_advance_assignment_id, ind_advance_assignment_id) FROM stdin;
13946	NonCalculated	10	13547	\N
3835980	NonCalculated	6	3835476	\N
3835982	NonCalculated	4	3835478	\N
3835983	NonCalculated	2	3835479	\N
3511070	NonCalculated	2	3835514	\N
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, code, name, enabled) FROM stdin;
3480561	1	dddd6ecc-59b1-4292-bb92-5a8e753e7a7a	Oficial	t
3480562	1	35b25191-ec87-4e5e-b434-43f2f1b3209a	Peón	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, code, name, active, id_criterion_type, parent) FROM stdin;
116	1	0589ee32-1be9-4261-8a8d-d8caaadf7252	A coruña	t	6	\N
117	1	a8030202-3421-4df5-9acb-9838a0c676fc	Vigo	t	6	\N
118	1	c89ce2c3-9061-4e88-a595-4492aa4704f3	Ferrol	t	6	\N
119	1	0527bba3-7c90-47c6-a029-2daf5d70359c	Rianxo	t	6	\N
120	1	034c910a-8159-4b85-bc58-d7a579923dcf	Cangas	t	6	\N
121	1	4585523a-d231-43fa-b251-5d29f95ee731	Ourense	t	6	\N
122	1	89dc0e70-e6e9-4726-b8e8-9cff01ca07b7	Sanxenxo	t	6	\N
123	1	f1bdaf91-8ba6-4958-abfe-bce67de3ec67	Pontevedra	t	6	\N
102	14	723726cd-fe06-4bdb-84a3-10a9538efca1	Baja por paternidad	t	1	\N
101	15	5470669e-eaff-4b1c-8e09-03e7625c9b7d	Baja por enfermedad	t	1	\N
124	1	529f27df-62e2-4311-885f-f888fc6148b6	Peón	t	2	\N
125	1	d4c08c6f-400d-42b3-9851-a3c68b48d7a8	Oficial de 3º	t	2	\N
126	1	54705705-c3ae-4380-b63b-19feb11e1811	Oficial de 1º	t	2	\N
127	1	557db93c-b856-4837-8b61-bbe322d96373	Ingeniero	t	2	\N
128	1	f6ea2e88-6950-45af-a868-6d003496460d	Oficlal de 2º	t	2	\N
129	1	33628d77-98ee-4664-bdc8-5166f96eb1fb	Torno	t	7	\N
130	1	46c2aaf5-654d-479c-98ce-6cf57a828ab5	Torno 8	t	7	\N
131	1	f5cdf3f7-43bb-4799-81bf-a2e19b820272	Torno 16	t	7	\N
132	1	8695759f-057e-4889-a2cf-89685048ba0b	Plegadora	t	7	\N
133	1	8ae84af1-2620-4ef2-a033-768d16bae913	Grúa	t	7	\N
110	2	8d895bef-5bf1-457a-b2f2-48d103295581	Pintor	t	4	\N
103	5	2563e713-5acf-4169-a8ff-9c49d4066f49	ContratadoFijo	t	5	\N
111	1	49ab6dae-49eb-4f3c-af13-8fae48de9d1d	ContratadoPorObra	t	5	\N
104	4	857ffe46-6ebc-4d42-97e5-d9d50091220a	Despedido	t	5	\N
112	1	c406d21e-ea23-4302-9506-6fad12820605	ContratadoTemporal	t	5	\N
113	1	977a6d69-8c7d-4952-83a8-76fe3e2a524b	Curso de riesgos laborales	t	3	\N
114	1	5de1beac-9a54-43f3-b2e4-1aaaf0dcaec5	Certificación de operador de grúa	t	3	\N
115	1	8f238d1f-6e47-4c35-8ed7-c7dcc05fcc4c	Curso básico de soldado	t	3	\N
106	2	5ba997e0-125c-4913-9077-eb5a2924be55	Tornero	t	4	\N
134	1	931a4622-a143-4596-b24c-9163d6d8862b	Lijador	t	4	\N
108	2	d8ce7296-fc52-4090-9da5-d57d51a95ec0	Soldador	t	4	\N
107	2	cfd531f4-d950-455b-8cd8-cb297c83b21a	Calderero	t	4	\N
105	2	61482488-cf45-4bc0-aaf6-693b4b928493	Andamiero	t	4	\N
109	2	9cc5241f-4453-4590-8539-b1aee394904e	Gruísta	t	4	\N
3510567	1	54930c90-7694-46cb-acd9-1990dcc2499d	Wireless Galicia	t	1234698240	\N
49794	7	4166cc7f-7d23-4b63-80c4-1c3b72d938ae	Administrador sistemas	t	16121856	\N
3510559	5	ba1676b6-fcfb-42ce-b2c0-9b81c9a3371f	Desarrollador Igalia	t	16121856	\N
49797	7	2f527c19-3e07-425a-b877-8b79dd98ce25	Analista	t	16121856	\N
3510560	5	d5d19cfe-974a-4332-8b64-622fd3f57cf0	Coordinador Igalia	t	16121856	\N
3510562	4	5e60f913-2524-45dd-8e9d-cb16bc80ab0e	Gestión Aclunaga	t	16121856	\N
3510558	5	f6459fb7-021c-4960-860e-667d16a4b1e6	Analista Igalia	t	16121856	\N
3510564	3	51ba9ae3-d235-40bd-9083-176de35b400d	Responsable implantaciones	t	16121856	\N
49795	7	b84f39df-2447-4a2d-8a91-fa85a7b9d634	Consultor	t	16121856	\N
13231	14	e610ce21-fb24-43d1-9ee9-385488e37b83	medicalLeave	t	4259840	\N
13232	13	bab312d2-c500-4e4c-9435-8256639004cf	paternityLeave	t	4259840	\N
13233	4	0c410a45-04ef-4af2-b08c-1415e40e0424	hiredResourceWorkingRelationship	t	4259844	\N
13234	3	61164200-d6b6-42a2-88b5-e27aeccea904	firedResourceWorkingRelationship	t	4259844	\N
49793	7	d5749edc-7d32-42f4-b9c3-cf350360eda3	Coordinador	t	16121856	\N
3510565	3	83852fb0-f581-4967-ac0f-4a0c912779a5	Probador Lider	t	16121856	\N
3510566	1	6ce0284a-a7f9-4438-ae29-ae89ebb2c508	Formador 	t	16121856	\N
49798	6	e1977ded-2a09-42c6-b581-fcf5d18221c8	Coordinador técnico	t	16121856	\N
49796	7	0931ea80-0d35-44d2-9aee-62a16f0434ea	Analista / Desarrollador	t	16121856	\N
3510561	4	54dffde1-4d87-44fb-8cf6-f164ef05a3a8	Relaciones institucionales	t	16121856	\N
3510563	4	6762a977-d8f2-434a-a984-40aae62e96a5	Coordinador Aclunaga	t	16121856	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, order_element_template_id, criterion_id, parent, valid) FROM stdin;
3513165	INDIRECT	14	\N	3713366	\N	3510563	3511466	t
3513166	INDIRECT	14	3511050	\N	\N	3510563	3511466	t
3513158	INDIRECT	15	3511000	\N	\N	3510564	3513148	t
13895	DIRECT	7	\N	13435	\N	124	\N	\N
13896	INDIRECT	7	13736	\N	\N	124	13895	t
13897	DIRECT	7	\N	13436	\N	124	\N	\N
13898	INDIRECT	7	13737	\N	\N	124	13897	t
13899	DIRECT	7	\N	13437	\N	110	\N	\N
13900	INDIRECT	7	13738	\N	\N	110	13899	t
13901	DIRECT	7	\N	13438	\N	124	\N	\N
13902	INDIRECT	7	13739	\N	\N	124	13901	t
14985	DIRECT	12	\N	13465	\N	124	\N	\N
14986	INDIRECT	12	13776	\N	\N	124	14985	t
16574	DIRECT	1	\N	\N	14907	108	\N	\N
16575	INDIRECT	1	\N	\N	14908	108	16574	t
16576	INDIRECT	1	13810	\N	\N	108	16574	t
13927	DIRECT	1	\N	\N	14863	124	\N	\N
13928	INDIRECT	1	13752	\N	\N	124	13927	t
13929	DIRECT	1	\N	\N	14864	124	\N	\N
13930	INDIRECT	1	13753	\N	\N	124	13929	t
13931	DIRECT	1	\N	\N	14865	110	\N	\N
13932	INDIRECT	1	13754	\N	\N	110	13931	t
13933	DIRECT	1	\N	\N	14866	124	\N	\N
13934	INDIRECT	1	13755	\N	\N	124	13933	t
16577	INDIRECT	1	\N	\N	14909	108	16574	t
16578	INDIRECT	1	13811	\N	\N	108	16574	t
16579	INDIRECT	1	\N	\N	14910	108	16574	t
16580	INDIRECT	1	13812	\N	\N	108	16574	t
14987	DIRECT	12	\N	13466	\N	124	\N	\N
14988	INDIRECT	12	13777	\N	\N	124	14987	t
14989	DIRECT	12	\N	13467	\N	110	\N	\N
14990	INDIRECT	12	13778	\N	\N	110	14989	t
16581	DIRECT	1	\N	\N	14911	108	\N	\N
16582	INDIRECT	1	13813	\N	\N	108	16581	t
16583	DIRECT	1	\N	\N	14912	108	\N	\N
14991	DIRECT	12	\N	13468	\N	124	\N	\N
14992	INDIRECT	12	13779	\N	\N	124	14991	t
2303	INDIRECT	5	2034	\N	\N	108	2297	t
16584	INDIRECT	1	13814	\N	\N	108	16583	t
16585	DIRECT	1	\N	\N	14913	124	\N	\N
16586	INDIRECT	1	13815	\N	\N	124	16585	t
16587	DIRECT	1	\N	\N	14914	124	\N	\N
16588	INDIRECT	1	13816	\N	\N	124	16587	t
16589	DIRECT	1	\N	\N	14915	134	\N	\N
16590	INDIRECT	1	\N	\N	14916	134	16589	t
16591	INDIRECT	1	13817	\N	\N	134	16589	t
2297	DIRECT	5	\N	1837	\N	108	\N	\N
2298	INDIRECT	5	\N	1838	\N	108	2297	t
2299	INDIRECT	5	2032	\N	\N	108	2297	t
2300	INDIRECT	5	\N	1839	\N	108	2297	t
2301	INDIRECT	5	2033	\N	\N	108	2297	t
2302	INDIRECT	5	\N	1840	\N	108	2297	t
2304	DIRECT	5	\N	1841	\N	108	\N	\N
2305	INDIRECT	5	2035	\N	\N	108	2304	t
2306	DIRECT	5	\N	1842	\N	108	\N	\N
2307	INDIRECT	5	2036	\N	\N	108	2306	t
2382	DIRECT	4	\N	1843	\N	124	\N	\N
2383	INDIRECT	4	2037	\N	\N	124	2382	t
2384	DIRECT	4	\N	1844	\N	124	\N	\N
2385	INDIRECT	4	2038	\N	\N	124	2384	t
2386	DIRECT	4	\N	1845	\N	134	\N	\N
2387	INDIRECT	4	\N	1846	\N	134	2386	t
2388	INDIRECT	4	2039	\N	\N	134	2386	t
2389	INDIRECT	4	\N	1847	\N	134	2386	t
2390	INDIRECT	4	2040	\N	\N	134	2386	t
2391	DIRECT	4	\N	1848	\N	126	\N	\N
2392	INDIRECT	4	2041	\N	\N	126	2391	t
16592	INDIRECT	1	\N	\N	14917	134	16589	t
16593	INDIRECT	1	13818	\N	\N	134	16589	t
16594	DIRECT	1	\N	\N	14918	126	\N	\N
16595	INDIRECT	1	13819	\N	\N	126	16594	t
27474	DIRECT	6	27279	\N	\N	105	\N	\N
27475	DIRECT	6	27270	\N	\N	124	\N	\N
27481	DIRECT	5	27271	\N	\N	109	\N	\N
27479	DIRECT	5	27282	\N	\N	110	\N	\N
27480	DIRECT	5	27283	\N	\N	124	\N	\N
47786	DIRECT	4	\N	26975	\N	108	\N	\N
47787	INDIRECT	4	27275	\N	\N	108	47786	t
47788	DIRECT	4	\N	26976	\N	108	\N	\N
47789	INDIRECT	4	27276	\N	\N	108	47788	t
47790	DIRECT	4	\N	26977	\N	124	\N	\N
47791	INDIRECT	4	27277	\N	\N	124	47790	t
54250	INDIRECT	12	50247	\N	\N	49796	54191	t
54252	INDIRECT	12	\N	49902	\N	49796	54251	t
54253	INDIRECT	12	50202	\N	\N	49796	54251	t
54254	INDIRECT	12	\N	49959	\N	49796	54251	t
54255	INDIRECT	12	50253	\N	\N	49796	54251	t
54256	INDIRECT	12	\N	49960	\N	49796	54251	t
54257	INDIRECT	12	50254	\N	\N	49796	54251	t
54258	INDIRECT	12	\N	49961	\N	49796	54251	t
54259	INDIRECT	12	50255	\N	\N	49796	54251	t
54260	INDIRECT	12	\N	49962	\N	49796	54251	t
3513167	INDIRECT	10	\N	3713367	\N	3510563	3511466	t
3513168	INDIRECT	10	3511051	\N	\N	3510563	3511466	t
3513169	INDIRECT	10	\N	3713368	\N	3510563	3511466	t
3513170	INDIRECT	10	3511052	\N	\N	3510563	3511466	t
3513171	INDIRECT	10	\N	3713369	\N	3510563	3511466	t
3513172	INDIRECT	10	3511053	\N	\N	3510563	3511466	t
3513173	INDIRECT	10	\N	3713370	\N	3510563	3511466	t
3513174	INDIRECT	10	3511054	\N	\N	3510563	3511466	t
3513175	INDIRECT	10	\N	3713371	\N	3510563	3511466	t
3513176	INDIRECT	10	3511055	\N	\N	3510563	3511466	t
54261	INDIRECT	12	50256	\N	\N	49796	54251	t
54262	INDIRECT	12	\N	49963	\N	49796	54251	t
54263	INDIRECT	12	50257	\N	\N	49796	54251	t
54264	INDIRECT	12	\N	49964	\N	49796	54251	t
54265	INDIRECT	12	50258	\N	\N	49796	54251	t
54266	INDIRECT	12	\N	49965	\N	49796	54251	t
54267	INDIRECT	12	50259	\N	\N	49796	54251	t
54268	DIRECT	12	\N	49966	\N	49796	\N	\N
54269	INDIRECT	12	50260	\N	\N	49796	54268	t
54270	DIRECT	12	\N	49967	\N	49796	\N	\N
54271	INDIRECT	12	\N	49968	\N	49796	54270	t
2394316	DIRECT	5	\N	2394116	\N	49796	\N	\N
2394317	INDIRECT	5	2394217	\N	\N	49796	2394316	t
2394318	DIRECT	5	\N	2394117	\N	49796	\N	\N
2394319	INDIRECT	5	2394218	\N	\N	49796	2394318	t
3513021	DIRECT	29	\N	3510706	\N	3510559	\N	\N
3513022	INDIRECT	29	\N	3510677	\N	3510559	3513021	t
3513023	INDIRECT	29	3510976	\N	\N	3510559	3513021	t
3513024	INDIRECT	29	\N	3510707	\N	3510559	3513021	t
3513025	INDIRECT	29	3511002	\N	\N	3510559	3513021	t
3513026	INDIRECT	29	\N	3510708	\N	3510559	3513021	t
3513032	DIRECT	29	\N	3510711	\N	3510559	\N	\N
3513179	DIRECT	8	\N	3713372	\N	3510566	\N	\N
3513180	INDIRECT	8	3511056	\N	\N	3510566	3513179	t
3513027	INDIRECT	29	3511003	\N	\N	3510559	3513021	t
3513028	INDIRECT	29	\N	3510709	\N	3510559	3513021	t
3513029	INDIRECT	29	3511004	\N	\N	3510559	3513021	t
3513030	INDIRECT	29	\N	3510710	\N	3510559	3513021	t
3513031	INDIRECT	29	3511005	\N	\N	3510559	3513021	t
3513033	INDIRECT	29	\N	3510678	\N	3510559	3513032	t
3513034	INDIRECT	29	3510977	\N	\N	3510559	3513032	t
3513035	INDIRECT	29	\N	3510712	\N	3510559	3513032	t
3513036	INDIRECT	29	3511006	\N	\N	3510559	3513032	t
3513037	INDIRECT	29	\N	3510713	\N	3510559	3513032	t
3513038	INDIRECT	29	3511007	\N	\N	3510559	3513032	t
3513039	INDIRECT	29	\N	3510714	\N	3510559	3513032	t
3513040	INDIRECT	29	3511008	\N	\N	3510559	3513032	t
3513041	INDIRECT	29	\N	3510715	\N	3510559	3513032	t
3513042	INDIRECT	29	3511009	\N	\N	3510559	3513032	t
3513043	DIRECT	29	\N	3510716	\N	3510559	\N	\N
3513044	INDIRECT	29	\N	3510679	\N	3510559	3513043	t
3513045	INDIRECT	29	3510978	\N	\N	3510559	3513043	t
3513046	INDIRECT	29	\N	3510717	\N	3510559	3513043	t
3513056	DIRECT	29	\N	3510722	\N	3510559	\N	\N
3805789	DIRECT	7	\N	3510699	\N	3510567	\N	\N
3805790	INDIRECT	7	\N	3510700	\N	3510567	3805789	t
3805791	INDIRECT	7	3510996	\N	\N	3510567	3805789	t
3805792	INDIRECT	7	\N	3510701	\N	3510567	3805789	t
3805793	INDIRECT	7	3510997	\N	\N	3510567	3805789	t
3805794	INDIRECT	7	\N	3510702	\N	3510567	3805789	t
3805795	INDIRECT	7	3510998	\N	\N	3510567	3805789	t
3805796	INDIRECT	7	\N	3510703	\N	3510567	3805789	t
3805797	INDIRECT	7	3510999	\N	\N	3510567	3805789	t
3805798	INDIRECT	7	\N	3510704	\N	3510567	3805789	t
3805799	INDIRECT	7	3511000	\N	\N	3510567	3805789	t
47795	DIRECT	13	50274	\N	\N	49793	\N	\N
47794	DIRECT	13	50197	\N	\N	49798	\N	\N
54152	DIRECT	12	\N	49908	\N	49795	\N	\N
54153	INDIRECT	12	50208	\N	\N	49795	54152	t
54154	DIRECT	12	\N	49909	\N	49797	\N	\N
54155	INDIRECT	12	50209	\N	\N	49797	54154	t
54156	DIRECT	12	\N	49910	\N	49796	\N	\N
54157	INDIRECT	12	\N	49911	\N	49796	54156	t
54158	INDIRECT	12	50210	\N	\N	49796	54156	t
54159	INDIRECT	12	\N	49898	\N	49796	54156	t
54160	INDIRECT	12	50199	\N	\N	49796	54156	t
54161	INDIRECT	12	\N	49912	\N	49796	54156	t
54162	INDIRECT	12	50211	\N	\N	49796	54156	t
54163	INDIRECT	12	\N	49913	\N	49796	54156	t
54164	INDIRECT	12	50212	\N	\N	49796	54156	t
54165	INDIRECT	12	\N	49914	\N	49796	54156	t
54166	INDIRECT	12	50213	\N	\N	49796	54156	t
54167	INDIRECT	12	\N	49915	\N	49796	54156	t
54168	INDIRECT	12	50214	\N	\N	49796	54156	t
54169	INDIRECT	12	\N	49916	\N	49796	54156	t
54170	INDIRECT	12	50215	\N	\N	49796	54156	t
54171	INDIRECT	12	\N	49917	\N	49796	54156	t
54172	INDIRECT	12	50216	\N	\N	49796	54156	t
16618	DIRECT	3	\N	13483	\N	108	\N	\N
16619	INDIRECT	3	\N	13484	\N	108	16618	t
16620	INDIRECT	3	13830	\N	\N	108	16618	t
16621	INDIRECT	3	\N	13485	\N	108	16618	t
16622	INDIRECT	3	13831	\N	\N	108	16618	t
16623	INDIRECT	3	\N	13486	\N	108	16618	t
16624	INDIRECT	3	13832	\N	\N	108	16618	t
16625	DIRECT	3	\N	13487	\N	108	\N	\N
16626	INDIRECT	3	13833	\N	\N	108	16625	t
16627	DIRECT	3	\N	13488	\N	108	\N	\N
16628	INDIRECT	3	13834	\N	\N	108	16627	t
16629	DIRECT	3	\N	13489	\N	124	\N	\N
16630	INDIRECT	3	13835	\N	\N	124	16629	t
16631	DIRECT	3	\N	13490	\N	124	\N	\N
16632	INDIRECT	3	13836	\N	\N	124	16631	t
16633	DIRECT	3	\N	13491	\N	134	\N	\N
16634	INDIRECT	3	\N	13492	\N	134	16633	t
16635	INDIRECT	3	16665	\N	\N	134	16633	t
16636	INDIRECT	3	\N	13493	\N	134	16633	t
16637	INDIRECT	3	16666	\N	\N	134	16633	t
16638	DIRECT	3	\N	13494	\N	126	\N	\N
16639	INDIRECT	3	16667	\N	\N	126	16638	t
3513084	INDIRECT	29	3511025	\N	\N	3510559	3513080	t
3513085	INDIRECT	29	\N	3510736	\N	3510559	3513080	t
3513086	INDIRECT	29	3511026	\N	\N	3510559	3513080	t
3513087	INDIRECT	29	\N	3510737	\N	3510559	3513080	t
3513088	INDIRECT	29	3511027	\N	\N	3510559	3513080	t
3513089	INDIRECT	29	\N	3510738	\N	3510559	3513080	t
3513090	INDIRECT	29	3511028	\N	\N	3510559	3513080	t
54173	INDIRECT	12	\N	49918	\N	49796	54156	t
54174	INDIRECT	12	50217	\N	\N	49796	54156	t
54175	INDIRECT	12	\N	49919	\N	49796	54156	t
54176	INDIRECT	12	50218	\N	\N	49796	54156	t
54177	INDIRECT	12	\N	49920	\N	49796	54156	t
54178	INDIRECT	12	50219	\N	\N	49796	54156	t
54179	INDIRECT	12	\N	49921	\N	49796	54156	t
3505456	DIRECT	3	\N	3505043	\N	108	\N	\N
3505457	INDIRECT	3	\N	3505044	\N	108	3505456	t
3505458	INDIRECT	3	3505223	\N	\N	108	3505456	t
3505459	INDIRECT	3	\N	3505045	\N	108	3505456	t
3505460	INDIRECT	3	3505224	\N	\N	108	3505456	t
3505461	INDIRECT	3	\N	3505046	\N	108	3505456	t
3505462	INDIRECT	3	3505225	\N	\N	108	3505456	t
54180	INDIRECT	12	50220	\N	\N	49796	54156	t
54181	INDIRECT	12	\N	49922	\N	49796	54156	t
54182	INDIRECT	12	50221	\N	\N	49796	54156	t
54183	INDIRECT	12	\N	49923	\N	49796	54156	t
54184	INDIRECT	12	50222	\N	\N	49796	54156	t
54185	INDIRECT	12	\N	49924	\N	49796	54156	t
54186	INDIRECT	12	50223	\N	\N	49796	54156	t
54272	INDIRECT	12	50261	\N	\N	49796	54270	t
54273	INDIRECT	12	\N	49969	\N	49796	54270	t
54274	INDIRECT	12	50262	\N	\N	49796	54270	t
54275	INDIRECT	12	\N	49903	\N	49796	54270	t
54276	INDIRECT	12	50203	\N	\N	49796	54270	t
54277	INDIRECT	12	\N	49970	\N	49796	54270	t
54278	INDIRECT	12	50263	\N	\N	49796	54270	t
54279	INDIRECT	12	\N	49971	\N	49796	54270	t
54280	INDIRECT	12	50264	\N	\N	49796	54270	t
54281	INDIRECT	12	\N	49972	\N	49796	54270	t
54282	INDIRECT	12	50265	\N	\N	49796	54270	t
54283	INDIRECT	12	\N	49973	\N	49796	54270	t
54284	INDIRECT	12	50266	\N	\N	49796	54270	t
3505489	DIRECT	2	\N	3505048	\N	107	\N	\N
3505490	INDIRECT	2	3505226	\N	\N	107	3505489	t
3505491	DIRECT	2	\N	3505049	\N	105	\N	\N
3505492	INDIRECT	2	3505227	\N	\N	105	3505491	t
3513047	INDIRECT	29	3511010	\N	\N	3510559	3513043	t
3513048	INDIRECT	29	\N	3510718	\N	3510559	3513043	t
3513049	INDIRECT	29	3511011	\N	\N	3510559	3513043	t
3513050	INDIRECT	29	\N	3510719	\N	3510559	3513043	t
3513051	INDIRECT	29	3511012	\N	\N	3510559	3513043	t
3513052	INDIRECT	29	\N	3510720	\N	3510559	3513043	t
3513053	INDIRECT	29	3511013	\N	\N	3510559	3513043	t
3513054	INDIRECT	29	\N	3510721	\N	3510559	3513043	t
3513055	INDIRECT	29	3511014	\N	\N	3510559	3513043	t
3513057	INDIRECT	29	\N	3510680	\N	3510559	3513056	t
3513058	INDIRECT	29	3510979	\N	\N	3510559	3513056	t
3513059	INDIRECT	29	\N	3510723	\N	3510559	3513056	t
3513060	INDIRECT	29	3511015	\N	\N	3510559	3513056	t
3513061	INDIRECT	29	\N	3510724	\N	3510559	3513056	t
3513062	INDIRECT	29	3511016	\N	\N	3510559	3513056	t
3513063	INDIRECT	29	\N	3510725	\N	3510559	3513056	t
3513064	INDIRECT	29	3511017	\N	\N	3510559	3513056	t
3513065	INDIRECT	29	\N	3510726	\N	3510559	3513056	t
3513066	INDIRECT	29	3511018	\N	\N	3510559	3513056	t
3513067	INDIRECT	29	\N	3510727	\N	3510559	3513056	t
3513068	INDIRECT	29	3511019	\N	\N	3510559	3513056	t
3513080	DIRECT	29	\N	3510734	\N	3510559	\N	\N
3513081	INDIRECT	29	\N	3510682	\N	3510559	3513080	t
3513082	INDIRECT	29	3510981	\N	\N	3510559	3513080	t
3513083	INDIRECT	29	\N	3510735	\N	3510559	3513080	t
3513091	INDIRECT	24	\N	3510739	\N	3510559	3513032	t
3513092	INDIRECT	24	3511029	\N	\N	3510559	3513032	t
3513093	INDIRECT	24	\N	3510740	\N	3510559	3513032	t
3513094	INDIRECT	24	3511030	\N	\N	3510559	3513032	t
3513095	INDIRECT	24	\N	3510741	\N	3510559	3513032	t
3513096	INDIRECT	24	3511031	\N	\N	3510559	3513032	t
3513097	INDIRECT	24	\N	3510742	\N	3510559	3513032	t
3513098	INDIRECT	24	3511032	\N	\N	3510559	3513032	t
3513099	INDIRECT	24	\N	3510743	\N	3510559	3513032	t
3513100	INDIRECT	24	3511033	\N	\N	3510559	3513032	t
54187	INDIRECT	12	\N	49925	\N	49796	54156	t
54188	INDIRECT	12	50224	\N	\N	49796	54156	t
54189	INDIRECT	12	\N	49926	\N	49796	54156	t
54190	INDIRECT	12	50225	\N	\N	49796	54156	t
54191	DIRECT	12	\N	49927	\N	49796	\N	\N
54192	INDIRECT	12	\N	49928	\N	49796	54191	t
54193	INDIRECT	12	\N	49929	\N	49796	54191	t
54194	INDIRECT	12	50226	\N	\N	49796	54191	t
3513101	INDIRECT	23	\N	3510744	\N	3510559	3513032	t
3513102	INDIRECT	23	3511034	\N	\N	3510559	3513032	t
3513103	INDIRECT	23	\N	3510745	\N	3510559	3513032	t
3513104	INDIRECT	23	3511035	\N	\N	3510559	3513032	t
3513105	INDIRECT	23	\N	3510746	\N	3510559	3513032	t
3513106	INDIRECT	23	3511036	\N	\N	3510559	3513032	t
3513107	INDIRECT	23	\N	3510747	\N	3510559	3513032	t
3513108	INDIRECT	23	3511037	\N	\N	3510559	3513032	t
54195	INDIRECT	12	\N	49899	\N	49796	54191	t
54196	INDIRECT	12	50200	\N	\N	49796	54191	t
54197	INDIRECT	12	\N	49930	\N	49796	54191	t
54198	INDIRECT	12	50227	\N	\N	49796	54191	t
54199	INDIRECT	12	\N	49931	\N	49796	54191	t
54200	INDIRECT	12	50228	\N	\N	49796	54191	t
54201	INDIRECT	12	\N	49932	\N	49796	54191	t
54202	INDIRECT	12	50229	\N	\N	49796	54191	t
54203	INDIRECT	12	\N	49933	\N	49796	54191	t
54204	INDIRECT	12	50230	\N	\N	49796	54191	t
54205	INDIRECT	12	\N	49934	\N	49796	54191	t
54206	INDIRECT	12	50231	\N	\N	49796	54191	t
54207	INDIRECT	12	\N	49935	\N	49796	54191	t
54208	INDIRECT	12	50232	\N	\N	49796	54191	t
54209	INDIRECT	12	\N	49936	\N	49796	54191	t
54210	INDIRECT	12	50233	\N	\N	49796	54191	t
54211	INDIRECT	12	\N	49937	\N	49796	54191	t
54212	INDIRECT	12	50234	\N	\N	49796	54191	t
54213	INDIRECT	12	\N	49943	\N	49796	54191	t
54214	INDIRECT	12	\N	49944	\N	49796	54191	t
54215	INDIRECT	12	50239	\N	\N	49796	54191	t
54216	INDIRECT	12	\N	49939	\N	49796	54191	t
54217	INDIRECT	12	50236	\N	\N	49796	54191	t
54218	INDIRECT	12	\N	49953	\N	49796	54191	t
54219	INDIRECT	12	50248	\N	\N	49796	54191	t
54220	INDIRECT	12	\N	49954	\N	49796	54191	t
54221	INDIRECT	12	50249	\N	\N	49796	54191	t
54222	INDIRECT	12	\N	49955	\N	49796	54191	t
3513109	INDIRECT	22	\N	3510748	\N	3510559	3513043	t
3513110	INDIRECT	22	3511038	\N	\N	3510559	3513043	t
3513111	INDIRECT	22	\N	3510749	\N	3510559	3513043	t
3513112	INDIRECT	22	3511039	\N	\N	3510559	3513043	t
3513113	INDIRECT	22	\N	3510750	\N	3510559	3513043	t
3513114	INDIRECT	22	3511040	\N	\N	3510559	3513043	t
3513115	INDIRECT	22	\N	3510751	\N	3510559	3513043	t
3513116	INDIRECT	22	3511041	\N	\N	3510559	3513043	t
3513117	INDIRECT	22	\N	3510752	\N	3510559	3513043	t
54223	INDIRECT	12	50250	\N	\N	49796	54191	t
54224	INDIRECT	12	\N	49956	\N	49796	54191	t
54225	INDIRECT	12	50251	\N	\N	49796	54191	t
3513118	INDIRECT	22	3511042	\N	\N	3510559	3513043	t
3513119	INDIRECT	22	\N	3510753	\N	3510559	3513043	t
3513120	INDIRECT	22	3511043	\N	\N	3510559	3513043	t
54226	INDIRECT	12	\N	49957	\N	49796	54191	t
54227	INDIRECT	12	50252	\N	\N	49796	54191	t
54228	INDIRECT	12	\N	49940	\N	49796	54191	t
54229	INDIRECT	12	\N	49941	\N	49796	54191	t
54230	INDIRECT	12	50237	\N	\N	49796	54191	t
54231	INDIRECT	12	\N	49942	\N	49796	54191	t
54232	INDIRECT	12	50238	\N	\N	49796	54191	t
54233	INDIRECT	12	\N	49938	\N	49796	54191	t
54234	INDIRECT	12	50235	\N	\N	49796	54191	t
3513121	INDIRECT	20	\N	3510754	\N	3510559	3513080	t
3513122	INDIRECT	20	3511044	\N	\N	3510559	3513080	t
3513123	INDIRECT	20	\N	3510755	\N	3510559	3513080	t
3513124	INDIRECT	20	3511045	\N	\N	3510559	3513080	t
3513125	INDIRECT	20	\N	3510756	\N	3510559	3513080	t
3513126	INDIRECT	20	3511046	\N	\N	3510559	3513080	t
54235	INDIRECT	12	\N	49945	\N	49796	54191	t
54236	INDIRECT	12	50240	\N	\N	49796	54191	t
54237	INDIRECT	12	\N	49946	\N	49796	54191	t
54238	INDIRECT	12	50241	\N	\N	49796	54191	t
54239	INDIRECT	12	\N	49947	\N	49796	54191	t
54240	INDIRECT	12	50242	\N	\N	49796	54191	t
54241	INDIRECT	12	\N	49948	\N	49796	54191	t
54242	INDIRECT	12	50243	\N	\N	49796	54191	t
54243	INDIRECT	12	\N	49949	\N	49796	54191	t
54244	INDIRECT	12	50244	\N	\N	49796	54191	t
54245	INDIRECT	12	\N	49950	\N	49796	54191	t
54246	INDIRECT	12	50245	\N	\N	49796	54191	t
54247	INDIRECT	12	\N	49951	\N	49796	54191	t
54248	INDIRECT	12	50246	\N	\N	49796	54191	t
54249	INDIRECT	12	\N	49952	\N	49796	54191	t
54251	DIRECT	12	\N	49958	\N	49796	\N	\N
3511466	DIRECT	31	\N	3510690	\N	3510563	\N	\N
3511467	INDIRECT	31	\N	3510692	\N	3510563	3511466	t
3511468	INDIRECT	31	3510989	\N	\N	3510563	3511466	t
3511469	INDIRECT	31	\N	3510693	\N	3510563	3511466	t
3511470	INDIRECT	31	3510990	\N	\N	3510563	3511466	t
3511471	INDIRECT	31	\N	3510694	\N	3510563	3511466	t
3511472	INDIRECT	31	3510991	\N	\N	3510563	3511466	t
3511473	INDIRECT	31	\N	3510695	\N	3510563	3511466	t
3511474	INDIRECT	31	3510992	\N	\N	3510563	3511466	t
3511475	INDIRECT	31	\N	3510696	\N	3510563	3511466	t
3511476	INDIRECT	31	3510993	\N	\N	3510563	3511466	t
3511477	INDIRECT	31	\N	3510697	\N	3510563	3511466	t
3511478	INDIRECT	31	3510994	\N	\N	3510563	3511466	t
3511479	DIRECT	31	\N	3510661	\N	3510560	\N	\N
3511480	INDIRECT	31	\N	3510662	\N	3510560	3511479	t
3511481	INDIRECT	31	3510962	\N	\N	3510560	3511479	t
3511482	INDIRECT	31	\N	3510663	\N	3510560	3511479	t
3511483	INDIRECT	31	3510963	\N	\N	3510560	3511479	t
3511484	INDIRECT	31	\N	3510664	\N	3510560	3511479	t
3511485	INDIRECT	31	3510964	\N	\N	3510560	3511479	t
3511486	INDIRECT	31	\N	3510665	\N	3510560	3511479	t
3511487	INDIRECT	31	3510965	\N	\N	3510560	3511479	t
3511488	INDIRECT	31	\N	3510666	\N	3510560	3511479	t
3511489	INDIRECT	31	3510966	\N	\N	3510560	3511479	t
3511490	INDIRECT	31	\N	3510667	\N	3510560	3511479	t
3511491	INDIRECT	31	3510967	\N	\N	3510560	3511479	t
3511492	INDIRECT	31	\N	3510668	\N	3510560	3511479	t
3511493	INDIRECT	31	3510968	\N	\N	3510560	3511479	t
3511494	DIRECT	31	\N	3510669	\N	3510558	\N	\N
3511495	INDIRECT	31	\N	3510670	\N	3510558	3511494	t
3511496	INDIRECT	31	3510969	\N	\N	3510558	3511494	t
3511497	INDIRECT	31	\N	3510671	\N	3510558	3511494	t
3511498	INDIRECT	31	3510970	\N	\N	3510558	3511494	t
3511499	INDIRECT	31	\N	3510672	\N	3510558	3511494	t
3511500	INDIRECT	31	3510971	\N	\N	3510558	3511494	t
3511501	INDIRECT	31	\N	3510673	\N	3510558	3511494	t
3511502	INDIRECT	31	3510972	\N	\N	3510558	3511494	t
3511503	INDIRECT	31	\N	3510674	\N	3510558	3511494	t
3511504	INDIRECT	31	3510973	\N	\N	3510558	3511494	t
3511507	DIRECT	31	\N	3510683	\N	3510559	\N	\N
3511508	INDIRECT	31	\N	3510676	\N	3510559	3511507	t
3511509	INDIRECT	31	3510975	\N	\N	3510559	3511507	t
3511510	INDIRECT	31	\N	3510684	\N	3510559	3511507	t
3511511	INDIRECT	31	3510982	\N	\N	3510559	3511507	t
3511512	INDIRECT	31	\N	3510685	\N	3510559	3511507	t
3511513	INDIRECT	31	3510983	\N	\N	3510559	3511507	t
3511514	INDIRECT	31	\N	3510686	\N	3510559	3511507	t
3511515	INDIRECT	31	3510984	\N	\N	3510559	3511507	t
3511520	INDIRECT	31	\N	3510689	\N	3510559	3511507	t
3511521	INDIRECT	31	3510987	\N	\N	3510559	3511507	t
3513146	DIRECT	15	\N	3510698	\N	3510565	\N	\N
3835802	DIRECT	7	\N	3835693	\N	124	\N	\N
3835803	INDIRECT	7	3835891	\N	\N	124	3835802	t
3835804	DIRECT	7	\N	3835694	\N	124	\N	\N
3835805	INDIRECT	7	3835892	\N	\N	124	3835804	t
3513147	INDIRECT	15	3510995	\N	\N	3510565	3513146	t
3835806	DIRECT	7	\N	3835695	\N	110	\N	\N
3835807	INDIRECT	7	3835893	\N	\N	110	3835806	t
3835808	DIRECT	7	\N	3835696	\N	124	\N	\N
3835809	INDIRECT	7	3835894	\N	\N	124	3835808	t
54285	INDIRECT	12	\N	49974	\N	49796	54270	t
54286	INDIRECT	12	50267	\N	\N	49796	54270	t
54287	INDIRECT	12	\N	49975	\N	49796	54270	t
54288	INDIRECT	12	50268	\N	\N	49796	54270	t
54289	DIRECT	12	\N	49904	\N	49796	\N	\N
54290	INDIRECT	12	50204	\N	\N	49796	54289	t
54291	DIRECT	12	\N	49905	\N	49796	\N	\N
3513148	DIRECT	15	\N	3510699	\N	3510564	\N	\N
3513149	INDIRECT	15	\N	3510700	\N	3510564	3513148	t
3513150	INDIRECT	15	3510996	\N	\N	3510564	3513148	t
3513151	INDIRECT	15	\N	3510701	\N	3510564	3513148	t
3513152	INDIRECT	15	3510997	\N	\N	3510564	3513148	t
3513153	INDIRECT	15	\N	3510702	\N	3510564	3513148	t
3513154	INDIRECT	15	3510998	\N	\N	3510564	3513148	t
3513155	INDIRECT	15	\N	3510703	\N	3510564	3513148	t
3513156	INDIRECT	15	3510999	\N	\N	3510564	3513148	t
3513157	INDIRECT	15	\N	3510704	\N	3510564	3513148	t
54292	INDIRECT	12	50205	\N	\N	49796	54291	t
54293	DIRECT	12	\N	49906	\N	49796	\N	\N
54294	INDIRECT	12	50206	\N	\N	49796	54293	t
54295	DIRECT	12	\N	49907	\N	49796	\N	\N
54296	INDIRECT	12	50207	\N	\N	49796	54295	t
54297	DIRECT	12	\N	49976	\N	49796	\N	\N
54298	INDIRECT	12	50269	\N	\N	49796	54297	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, code, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
1736	30	33feee7e-7fd4-4537-96cb-3bab60280934	2010-05-04 00:00:00	\N	f	108	1123
1735	30	b705feb4-e360-4458-97e0-bf07fdb79eed	2010-05-04 08:03:55.99	\N	f	117	1123
39397	2	8ce31719-73e9-4aac-9ff9-cf946151cea0	2010-05-12 00:00:00	\N	f	49796	39003
1718	3	b250c159-ebc5-495b-9f6b-243b5f95dccb	2010-05-04 07:53:46.183	\N	f	129	1115
1738	23	3b108db8-3e5f-49a0-8b3a-65efa67f9c7c	2010-05-04 08:04:26.693	\N	f	117	1130
1725	24	6d1812b2-bc4f-4f89-b6ce-f13105d6c564	2010-05-04 08:00:06.627	\N	f	124	1130
39398	2	fac82d36-5478-494d-9372-c4599e409780	2010-05-12 16:20:37.814	\N	f	49796	39005
1723	18	8026594d-618f-4bd6-b272-ec9de0dfc9de	2010-05-04 07:58:59.289	\N	f	124	1126
1739	17	72b43332-c29e-4c23-9b94-bc85f66de056	2010-05-04 08:04:36.966	\N	f	117	1126
14747	3	17d885e2-2c07-4c6b-9d5f-016f260076c0	2010-05-06 19:46:55.446	\N	f	110	14345
1737	2	cac19965-8102-4959-84e7-7e826764c702	2010-05-04 08:04:14.571	\N	f	117	1132
39392	3	245f0f57-f18b-484a-adfa-19371c7aaf41	2010-05-12 00:00:00	\N	f	49796	38993
65550	2	a4c60a02-4ded-47de-84af-730aaba011c6	2010-05-13 10:06:36.594	\N	f	49797	38993
39404	2	a9de14a7-8e44-4cbe-9fb2-06427832db3c	2010-05-12 16:23:59.038	\N	f	49793	39017
39406	2	49b7a39f-a601-4999-9d3f-e9cb7a81773a	2010-05-12 16:25:26.144	\N	f	49795	39022
1726	3	aed33466-a532-45a7-8d0c-a12f90ffd19e	2010-05-04 08:00:36.93	\N	f	105	1132
2417839	2	698b8ecc-a09b-4f9c-bd21-664225ca2e26	2010-05-13 17:12:02.444	\N	f	49795	39015
39403	3	d224b1de-c922-4627-ab8e-bb5cfb735d4c	2010-05-12 16:23:17.179	\N	f	49793	39015
1719	2	9f76efe5-97ca-42d2-ba54-51ba0e6444f9	2010-05-04 07:54:30.897	\N	f	130	1117
1720	2	8820c8ab-9eb8-4c72-b028-c9918c85eca4	2010-05-04 07:54:23.716	\N	f	129	1117
1717	2	8e175db2-b5b8-443b-851b-33a0e550bd35	2010-05-04 07:53:06.731	\N	f	133	1113
1728	2	7d8dbaea-881a-4bf1-acef-cf31a20abdee	2010-05-04 08:01:54.047	\N	f	105	1136
1729	2	00d707bc-e9b3-41f8-a91b-5f39c9218968	2010-05-04 08:02:04.647	\N	f	117	1136
39395	2	29b67a0b-e355-425b-b9d7-99478598a51e	2010-05-12 00:00:00	\N	f	49796	38999
39405	2	a485604a-6e38-48ac-b41d-b798142dab46	2010-05-12 16:25:09.441	\N	f	49798	39020
3504902	4	14d037c9-a10d-492a-863c-485a19faf705	2010-05-17 17:50:05.008	\N	f	108	3504499
39399	2	09909f8c-24ed-4652-85c9-fe0dcfe807d9	2010-05-12 00:00:00	\N	f	49796	39007
26866	3	dc660085-f43d-426f-9d95-ec457eb78a61	2010-05-12 12:28:32.257	\N	f	110	26463
39401	2	dffa3b60-7157-4ae9-b006-a9eb38df8ac6	2010-05-12 16:22:10.767	\N	f	49796	39011
1732	17	f3a945d2-b2bc-4103-909b-dfcb719595e9	2010-05-04 08:02:53.439	\N	f	118	1128
1724	18	44da098a-ea0d-4144-a16d-beb68dd1c337	2010-05-04 07:59:35.761	\N	f	124	1128
1734	36	709aa229-fe19-4b9b-be38-31cf6c1eafd1	2010-05-04 08:03:40.862	\N	f	108	1121
1733	37	1e87afbe-046a-401f-a284-164c49e540fd	2010-05-04 08:03:08.802	\N	f	118	1121
14746	3	78e8d9da-c7a3-407d-9c39-c8d77db15616	2010-05-06 19:46:10.187	\N	f	110	14343
39402	2	0e10580d-0a5a-4794-a4d2-d8fe70fe174f	2010-05-12 00:00:00	\N	f	49796	39013
39400	2	3e610261-d26b-4dde-a495-890507b5d3da	2010-05-12 16:21:42.651	\N	f	49796	39009
39393	2	1c9b0730-e12f-4d9c-b15d-74c6c4603cdc	2010-05-12 16:17:53.503	\N	f	49796	38995
39396	2	5e9ad98b-4239-4d6f-bd0d-4ef5a0b11a00	2010-05-12 16:19:41.032	\N	f	49796	39001
1727	3	5545f68e-caf1-48d1-991e-7b582ab28dd4	2010-05-04 08:01:20.408	\N	f	105	1134
1730	2	f1d90892-d79a-433e-8231-100009011d0d	2010-05-04 08:02:30.511	\N	f	117	1134
39390	2	493a4ee8-a6f0-4215-af64-b7b3b99d2fd9	2010-05-12 15:43:08.515	\N	f	109	38987
39394	3	fdc328a0-0121-4676-98f9-f5686323c82f	2010-05-12 00:00:00	\N	f	49796	38997
65549	2	8cf2a9b7-4fc3-404a-92a8-d5e3aefbb6ee	2010-05-13 10:05:29.008	\N	f	49797	38997
1721	38	0655cf74-58fe-45ba-9df1-2d65c422c957	2010-05-04 07:55:10.663	\N	f	108	1119
1722	38	07ae0d78-ecd1-47c8-9085-825de29c359f	2010-05-04 07:55:19.053	\N	f	126	1119
1731	36	ad802f34-3ae6-4d20-871f-f2fe5624fe08	2010-05-04 08:02:42.579	\N	f	117	1119
3511671	18	6c713b23-ebf7-4d25-bb4d-8d08836f685e	2010-01-01 00:00:00	\N	f	3510560	3513187
3511670	2	f701f09f-0e8f-4f3a-b8e0-f4e3b0aec3a6	2010-01-01 00:00:00	\N	f	3510558	3513185
3511669	6	b5157ff7-f831-4885-a947-accb43eaae47	2010-01-01 00:00:00	\N	f	3510559	38991
39391	8	42748cea-5102-4f16-a835-3e5e03d3ebbf	2010-05-12 16:16:51.929	\N	f	49796	38991
3511672	1	34ea1c52-9fa2-40e1-b519-db6eae9bed1d	2010-05-25 10:14:28.819	\N	f	3510559	3513189
3511673	4	e36e5ec8-af41-4108-b0d7-8f6a4f21f734	2010-01-01 00:00:00	\N	f	3510559	3513191
3511677	1	a3fde186-0320-4cba-a670-0bc2e90c9f45	2010-05-25 20:26:50.284	\N	f	3510563	3513197
3511678	1	57412507-bfa5-4750-b89a-79b31fda3091	2010-05-26 16:48:13.554	\N	f	3510566	3513193
3511674	3	3697b21e-2f39-41ce-80bb-ac10948b29a6	2010-05-25 17:56:14.484	\N	f	3510559	3513193
3511679	1	592654d0-72e4-4737-badf-d77a746fd03a	2010-05-26 23:42:48.287	\N	f	3510567	3513195
3511675	2	2c6e44b4-36bc-47b8-b94d-717a66c0d6b0	2010-05-25 20:18:34.008	\N	f	3510565	3513195
3511676	2	10420543-2901-438b-9e74-15a5ecc4c345	2010-05-25 20:18:27.386	\N	f	3510564	3513195
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, code, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, generatecode, resource) FROM stdin;
1	16	229611e4-4370-424a-a191-9f0f852e2ed3	Tipo de baja	Baja	f	f	t	f	1
2	12	de5e4cba-7663-4e01-a776-93fb19fb949c	Categoría	Categoría profesional	t	t	t	f	1
7	1	68bdbf68-3928-4f23-a18d-f45b9127e157	Tipo de máquina	\N	t	t	t	t	2
4	9	1df30019-35db-42ef-b018-51a761184d3e	Tipo de trabajo	Tipo de trabajo	t	t	t	f	1
16121856	7	4f07894c-5345-4c7d-ae9b-72c98a82f410	Perfil técnico	\N	t	t	t	t	0
1234698240	1	c4218d04-96a4-4594-9da0-0e29d46d669c	Empresa	\N	t	t	t	t	0
4259841	11	479d7b13-d3b3-47a8-a394-0d4face24ae3	CATEGORY	Professional category	t	t	t	f	1
4259842	9	37470b57-3421-4ec5-acf9-e5b58a6008da	TRAINING	Training courses and labor training	t	t	t	f	1
5	6	498ff6a4-c6b4-46fe-b806-766895ed6470	Relación contractual	Relación contractual del trabajador con la empresa.	f	f	t	f	1
3	10	8db6e365-fb8b-4452-89ce-8360965e79c8	Formación	Cursos o formación profesional	t	t	t	f	1
6	2	d6348b11-4d8b-4d0d-8909-2bffe2791291	Localización	Localización del recurso	t	f	t	f	0
4259840	15	35402175-3be1-4a4d-b65c-c15799638eb0	LEAVE	Leave	f	f	t	f	1
4259843	7	eea70829-8601-4799-bcbc-f81b17fde23a	JOB	Job	t	t	t	f	1
4259844	5	2ca10ea2-b0d7-4247-8d88-c19a5c72f4a7	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	f	1
4259845	1	bab0cc28-ea14-4dc0-a9ac-7c499d2afe7a	LOCATION_GROUP	Location where the resource work	t	f	t	f	0
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, consolidated, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id, derived_allocation_id) FROM stdin;
11866	GENERIC_DAY	1	3	\N	2010-07-13	1121	\N	2681	\N
11867	GENERIC_DAY	1	2	\N	2010-06-29	1123	\N	2681	\N
11868	GENERIC_DAY	1	3	\N	2010-07-06	1119	\N	2681	\N
11869	GENERIC_DAY	1	3	\N	2010-07-01	1121	\N	2681	\N
11870	GENERIC_DAY	1	3	\N	2010-07-19	1119	\N	2681	\N
11871	GENERIC_DAY	1	3	\N	2010-08-03	1121	\N	2681	\N
11872	GENERIC_DAY	1	0	\N	2010-06-20	1123	\N	2681	\N
11873	GENERIC_DAY	1	0	\N	2010-08-01	1119	\N	2681	\N
11874	GENERIC_DAY	1	3	\N	2010-07-02	1119	\N	2681	\N
11875	GENERIC_DAY	1	3	\N	2010-07-28	1119	\N	2681	\N
11876	GENERIC_DAY	1	3	\N	2010-07-27	1121	\N	2681	\N
11877	GENERIC_DAY	1	3	\N	2010-08-04	1119	\N	2681	\N
11878	GENERIC_DAY	1	2	\N	2010-07-14	1123	\N	2681	\N
11879	GENERIC_DAY	1	2	\N	2010-06-22	1121	\N	2681	\N
11880	GENERIC_DAY	1	0	\N	2010-06-19	1119	\N	2681	\N
11881	GENERIC_DAY	1	3	\N	2010-06-21	1123	\N	2681	\N
11882	GENERIC_DAY	1	1	\N	2010-08-05	1123	\N	2681	\N
11883	GENERIC_DAY	1	0	\N	2010-07-24	1121	\N	2681	\N
11884	GENERIC_DAY	1	3	\N	2010-08-02	1119	\N	2681	\N
11885	GENERIC_DAY	1	3	\N	2010-07-21	1119	\N	2681	\N
11886	GENERIC_DAY	1	2	\N	2010-06-21	1121	\N	2681	\N
11887	GENERIC_DAY	1	3	\N	2010-06-22	1119	\N	2681	\N
11888	GENERIC_DAY	1	3	\N	2010-06-29	1119	\N	2681	\N
11889	GENERIC_DAY	1	3	\N	2010-07-15	1119	\N	2681	\N
11890	GENERIC_DAY	1	3	\N	2010-07-12	1119	\N	2681	\N
11891	GENERIC_DAY	1	2	\N	2010-08-02	1123	\N	2681	\N
11892	GENERIC_DAY	1	2	\N	2010-06-23	1121	\N	2681	\N
11893	GENERIC_DAY	1	3	\N	2010-06-18	1119	\N	2681	\N
11894	GENERIC_DAY	1	0	\N	2010-07-03	1123	\N	2681	\N
11895	GENERIC_DAY	1	3	\N	2010-06-23	1123	\N	2681	\N
11896	GENERIC_DAY	1	3	\N	2010-07-07	1119	\N	2681	\N
11897	GENERIC_DAY	1	2	\N	2010-07-16	1123	\N	2681	\N
11898	GENERIC_DAY	1	0	\N	2010-07-31	1123	\N	2681	\N
11899	GENERIC_DAY	1	2	\N	2010-07-09	1123	\N	2681	\N
11900	GENERIC_DAY	1	2	\N	2010-07-19	1123	\N	2681	\N
11901	GENERIC_DAY	1	0	\N	2010-07-25	1123	\N	2681	\N
11902	GENERIC_DAY	1	0	\N	2010-07-18	1121	\N	2681	\N
11903	GENERIC_DAY	1	0	\N	2010-07-31	1119	\N	2681	\N
11904	GENERIC_DAY	1	2	\N	2010-07-29	1123	\N	2681	\N
11905	GENERIC_DAY	1	3	\N	2010-08-02	1121	\N	2681	\N
11906	GENERIC_DAY	1	2	\N	2010-07-08	1123	\N	2681	\N
11907	GENERIC_DAY	1	0	\N	2010-07-10	1121	\N	2681	\N
11908	GENERIC_DAY	1	3	\N	2010-07-02	1121	\N	2681	\N
11909	GENERIC_DAY	1	2	\N	2010-07-02	1123	\N	2681	\N
11910	GENERIC_DAY	1	0	\N	2010-06-26	1123	\N	2681	\N
11911	GENERIC_DAY	1	0	\N	2010-07-04	1121	\N	2681	\N
11912	GENERIC_DAY	1	2	\N	2010-06-18	1121	\N	2681	\N
11913	GENERIC_DAY	1	2	\N	2010-07-15	1123	\N	2681	\N
11914	GENERIC_DAY	1	2	\N	2010-07-28	1123	\N	2681	\N
11915	GENERIC_DAY	1	3	\N	2010-07-07	1121	\N	2681	\N
11916	GENERIC_DAY	1	3	\N	2010-07-29	1119	\N	2681	\N
11917	GENERIC_DAY	1	3	\N	2010-06-16	1123	\N	2681	\N
11918	GENERIC_DAY	1	0	\N	2010-08-01	1123	\N	2681	\N
11919	GENERIC_DAY	1	3	\N	2010-06-28	1119	\N	2681	\N
11920	GENERIC_DAY	1	3	\N	2010-06-15	1119	\N	2681	\N
11921	GENERIC_DAY	1	0	\N	2010-07-11	1121	\N	2681	\N
11922	GENERIC_DAY	1	2	\N	2010-06-17	1121	\N	2681	\N
11923	GENERIC_DAY	1	2	\N	2010-07-21	1123	\N	2681	\N
11924	GENERIC_DAY	1	3	\N	2010-07-26	1121	\N	2681	\N
11925	GENERIC_DAY	1	2	\N	2010-08-04	1123	\N	2681	\N
11926	GENERIC_DAY	1	2	\N	2010-07-06	1123	\N	2681	\N
11927	GENERIC_DAY	1	3	\N	2010-07-21	1121	\N	2681	\N
11928	GENERIC_DAY	1	3	\N	2010-06-30	1119	\N	2681	\N
11929	GENERIC_DAY	1	3	\N	2010-07-20	1121	\N	2681	\N
11930	GENERIC_DAY	1	0	\N	2010-07-11	1119	\N	2681	\N
11931	GENERIC_DAY	1	2	\N	2010-06-30	1123	\N	2681	\N
11932	GENERIC_DAY	1	3	\N	2010-07-09	1119	\N	2681	\N
11933	GENERIC_DAY	1	3	\N	2010-06-21	1119	\N	2681	\N
11934	GENERIC_DAY	1	0	\N	2010-07-10	1123	\N	2681	\N
11935	GENERIC_DAY	1	0	\N	2010-06-27	1121	\N	2681	\N
11936	GENERIC_DAY	1	3	\N	2010-08-04	1121	\N	2681	\N
11937	GENERIC_DAY	1	3	\N	2010-07-05	1121	\N	2681	\N
11938	GENERIC_DAY	1	3	\N	2010-07-15	1121	\N	2681	\N
11939	GENERIC_DAY	1	3	\N	2010-06-17	1123	\N	2681	\N
11940	GENERIC_DAY	1	3	\N	2010-06-25	1121	\N	2681	\N
11941	GENERIC_DAY	1	0	\N	2010-07-03	1119	\N	2681	\N
11942	GENERIC_DAY	1	2	\N	2010-06-24	1121	\N	2681	\N
11943	GENERIC_DAY	1	0	\N	2010-06-26	1121	\N	2681	\N
11944	GENERIC_DAY	1	3	\N	2010-07-14	1119	\N	2681	\N
11945	GENERIC_DAY	1	0	\N	2010-07-25	1119	\N	2681	\N
11946	GENERIC_DAY	1	3	\N	2010-07-09	1121	\N	2681	\N
11947	GENERIC_DAY	1	2	\N	2010-07-05	1123	\N	2681	\N
11948	GENERIC_DAY	1	3	\N	2010-06-30	1121	\N	2681	\N
11949	GENERIC_DAY	1	2	\N	2010-07-26	1123	\N	2681	\N
11950	GENERIC_DAY	1	0	\N	2010-08-01	1121	\N	2681	\N
11951	GENERIC_DAY	1	0	\N	2010-06-20	1121	\N	2681	\N
11952	GENERIC_DAY	1	2	\N	2010-06-16	1121	\N	2681	\N
11953	GENERIC_DAY	1	1	\N	2010-08-05	1121	\N	2681	\N
10017	GENERIC_DAY	2	5	\N	2010-05-24	1123	\N	2679	\N
10096	GENERIC_DAY	2	5	\N	2010-05-14	1121	\N	2679	\N
10116	GENERIC_DAY	2	6	\N	2010-05-05	1119	\N	2679	\N
10051	GENERIC_DAY	2	0	\N	2010-05-22	1121	\N	2679	\N
10067	GENERIC_DAY	2	0	\N	2010-05-23	1119	\N	2679	\N
10090	GENERIC_DAY	2	5	\N	2010-06-02	1121	\N	2679	\N
10088	GENERIC_DAY	2	5	\N	2010-05-14	1123	\N	2679	\N
10027	GENERIC_DAY	2	6	\N	2010-05-11	1119	\N	2679	\N
10025	GENERIC_DAY	2	0	\N	2010-06-05	1123	\N	2679	\N
10072	GENERIC_DAY	2	6	\N	2010-05-20	1119	\N	2679	\N
10081	GENERIC_DAY	2	5	\N	2010-06-04	1121	\N	2679	\N
10050	GENERIC_DAY	2	0	\N	2010-05-09	1121	\N	2679	\N
10042	GENERIC_DAY	2	0	\N	2010-05-29	1123	\N	2679	\N
10015	GENERIC_DAY	2	5	\N	2010-06-02	1123	\N	2679	\N
10062	GENERIC_DAY	2	0	\N	2010-06-12	1119	\N	2679	\N
10053	GENERIC_DAY	2	5	\N	2010-05-20	1123	\N	2679	\N
10030	GENERIC_DAY	2	5	\N	2010-05-20	1121	\N	2679	\N
10028	GENERIC_DAY	2	5	\N	2010-05-18	1123	\N	2679	\N
10085	GENERIC_DAY	2	6	\N	2010-06-01	1119	\N	2679	\N
10066	GENERIC_DAY	2	5	\N	2010-05-19	1123	\N	2679	\N
11954	GENERIC_DAY	1	2	\N	2010-06-28	1123	\N	2681	\N
11955	GENERIC_DAY	1	3	\N	2010-06-16	1119	\N	2681	\N
11956	GENERIC_DAY	1	3	\N	2010-07-16	1121	\N	2681	\N
11957	GENERIC_DAY	1	3	\N	2010-07-30	1121	\N	2681	\N
11958	GENERIC_DAY	1	2	\N	2010-08-05	1119	\N	2681	\N
11959	GENERIC_DAY	1	0	\N	2010-07-18	1119	\N	2681	\N
11960	GENERIC_DAY	1	0	\N	2010-07-03	1121	\N	2681	\N
11961	GENERIC_DAY	1	3	\N	2010-07-05	1119	\N	2681	\N
11962	GENERIC_DAY	1	2	\N	2010-07-12	1123	\N	2681	\N
11963	GENERIC_DAY	1	3	\N	2010-07-29	1121	\N	2681	\N
11964	GENERIC_DAY	1	0	\N	2010-06-26	1119	\N	2681	\N
11965	GENERIC_DAY	1	2	\N	2010-07-01	1123	\N	2681	\N
11966	GENERIC_DAY	1	2	\N	2010-07-30	1123	\N	2681	\N
11967	GENERIC_DAY	1	0	\N	2010-07-11	1123	\N	2681	\N
11968	GENERIC_DAY	1	3	\N	2010-07-13	1119	\N	2681	\N
11969	GENERIC_DAY	1	3	\N	2010-07-22	1119	\N	2681	\N
11970	GENERIC_DAY	1	0	\N	2010-07-24	1119	\N	2681	\N
11971	GENERIC_DAY	1	2	\N	2010-08-03	1123	\N	2681	\N
11972	GENERIC_DAY	1	0	\N	2010-06-27	1123	\N	2681	\N
11973	GENERIC_DAY	1	0	\N	2010-06-19	1121	\N	2681	\N
11974	GENERIC_DAY	1	2	\N	2010-06-25	1119	\N	2681	\N
11975	GENERIC_DAY	1	3	\N	2010-07-22	1121	\N	2681	\N
11976	GENERIC_DAY	1	2	\N	2010-07-13	1123	\N	2681	\N
11977	GENERIC_DAY	1	2	\N	2010-06-15	1121	\N	2681	\N
11978	GENERIC_DAY	1	3	\N	2010-06-22	1123	\N	2681	\N
11979	GENERIC_DAY	1	3	\N	2010-06-17	1119	\N	2681	\N
11980	GENERIC_DAY	1	3	\N	2010-07-23	1119	\N	2681	\N
11981	GENERIC_DAY	1	0	\N	2010-07-04	1123	\N	2681	\N
11982	GENERIC_DAY	1	3	\N	2010-07-28	1121	\N	2681	\N
11983	GENERIC_DAY	1	3	\N	2010-07-06	1121	\N	2681	\N
11984	GENERIC_DAY	1	3	\N	2010-06-24	1123	\N	2681	\N
11985	GENERIC_DAY	1	0	\N	2010-07-31	1121	\N	2681	\N
11986	GENERIC_DAY	1	0	\N	2010-07-17	1119	\N	2681	\N
12898	SPECIFIC_DAY	0	0	\N	2010-09-25	1132	2715	\N	\N
12899	SPECIFIC_DAY	0	8	\N	2010-09-29	1132	2715	\N	\N
12900	SPECIFIC_DAY	0	0	\N	2010-09-26	1132	2715	\N	\N
12901	SPECIFIC_DAY	0	0	\N	2010-10-03	1132	2715	\N	\N
12902	SPECIFIC_DAY	0	8	\N	2010-09-14	1132	2715	\N	\N
12903	SPECIFIC_DAY	0	8	\N	2010-09-28	1132	2715	\N	\N
12904	SPECIFIC_DAY	0	8	\N	2010-09-23	1132	2715	\N	\N
12905	SPECIFIC_DAY	0	8	\N	2010-09-22	1132	2715	\N	\N
12906	SPECIFIC_DAY	0	8	\N	2010-09-27	1132	2715	\N	\N
12907	SPECIFIC_DAY	0	4	\N	2010-10-06	1132	2715	\N	\N
12908	SPECIFIC_DAY	0	8	\N	2010-09-20	1132	2715	\N	\N
12909	SPECIFIC_DAY	0	8	\N	2010-09-15	1132	2715	\N	\N
12910	SPECIFIC_DAY	0	0	\N	2010-10-02	1132	2715	\N	\N
12911	SPECIFIC_DAY	0	8	\N	2010-10-01	1132	2715	\N	\N
12912	SPECIFIC_DAY	0	0	\N	2010-09-18	1132	2715	\N	\N
47112	GENERIC_DAY	2	10	\N	2010-09-15	1130	\N	39509	\N
47123	GENERIC_DAY	2	10	\N	2010-08-30	1128	\N	39509	\N
47098	GENERIC_DAY	2	11	\N	2010-09-14	1128	\N	39509	\N
47140	GENERIC_DAY	2	0	\N	2010-08-07	1126	\N	39509	\N
47204	GENERIC_DAY	2	11	\N	2010-07-08	1126	\N	39509	\N
47069	GENERIC_DAY	2	11	\N	2010-08-31	1130	\N	39509	\N
47205	GENERIC_DAY	2	0	\N	2010-07-17	1126	\N	39509	\N
46972	GENERIC_DAY	2	11	\N	2010-07-26	1128	\N	39509	\N
47066	GENERIC_DAY	2	11	\N	2010-07-16	1128	\N	39509	\N
47002	GENERIC_DAY	2	11	\N	2010-09-01	1126	\N	39509	\N
47094	GENERIC_DAY	2	11	\N	2010-08-05	1128	\N	39509	\N
47217	GENERIC_DAY	2	0	\N	2010-08-29	1130	\N	39509	\N
47096	GENERIC_DAY	2	10	\N	2010-08-04	1130	\N	39509	\N
47197	GENERIC_DAY	2	0	\N	2010-07-10	1130	\N	39509	\N
47000	GENERIC_DAY	2	0	\N	2010-08-01	1126	\N	39509	\N
47095	GENERIC_DAY	2	11	\N	2010-07-12	1126	\N	39509	\N
47087	GENERIC_DAY	2	11	\N	2010-07-06	1126	\N	39509	\N
47046	GENERIC_DAY	2	11	\N	2010-08-19	1130	\N	39509	\N
46988	GENERIC_DAY	2	10	\N	2010-08-06	1130	\N	39509	\N
47185	GENERIC_DAY	2	11	\N	2010-08-16	1128	\N	39509	\N
47057	GENERIC_DAY	2	11	\N	2010-06-30	1126	\N	39509	\N
47083	GENERIC_DAY	2	11	\N	2010-07-29	1126	\N	39509	\N
47119	GENERIC_DAY	2	0	\N	2010-07-18	1128	\N	39509	\N
47133	GENERIC_DAY	2	11	\N	2010-08-30	1126	\N	39509	\N
47142	GENERIC_DAY	2	11	\N	2010-09-10	1128	\N	39509	\N
47005	GENERIC_DAY	2	0	\N	2010-08-15	1126	\N	39509	\N
47122	GENERIC_DAY	2	11	\N	2010-07-21	1128	\N	39509	\N
47154	GENERIC_DAY	2	11	\N	2010-09-09	1130	\N	39509	\N
47196	GENERIC_DAY	2	10	\N	2010-09-21	1130	\N	39509	\N
47050	GENERIC_DAY	2	10	\N	2010-08-05	1130	\N	39509	\N
46971	GENERIC_DAY	2	10	\N	2010-08-02	1130	\N	39509	\N
47134	GENERIC_DAY	2	11	\N	2010-08-04	1126	\N	39509	\N
47085	GENERIC_DAY	2	0	\N	2010-07-24	1126	\N	39509	\N
47226	GENERIC_DAY	2	11	\N	2010-08-03	1128	\N	39509	\N
47174	GENERIC_DAY	2	11	\N	2010-07-30	1126	\N	39509	\N
47155	GENERIC_DAY	2	11	\N	2010-07-20	1126	\N	39509	\N
47056	GENERIC_DAY	2	0	\N	2010-07-11	1130	\N	39509	\N
47001	GENERIC_DAY	2	11	\N	2010-07-23	1126	\N	39509	\N
47114	GENERIC_DAY	2	10	\N	2010-07-30	1130	\N	39509	\N
46978	GENERIC_DAY	2	11	\N	2010-07-28	1128	\N	39509	\N
47032	GENERIC_DAY	2	10	\N	2010-08-17	1130	\N	39509	\N
47211	GENERIC_DAY	2	11	\N	2010-08-25	1126	\N	39509	\N
47170	GENERIC_DAY	2	11	\N	2010-09-02	1130	\N	39509	\N
46966	GENERIC_DAY	2	0	\N	2010-09-19	1130	\N	39509	\N
47051	GENERIC_DAY	2	10	\N	2010-07-08	1130	\N	39509	\N
47115	GENERIC_DAY	2	11	\N	2010-09-02	1126	\N	39509	\N
47214	GENERIC_DAY	2	11	\N	2010-09-15	1128	\N	39509	\N
47121	GENERIC_DAY	2	11	\N	2010-07-14	1126	\N	39509	\N
47006	GENERIC_DAY	2	11	\N	2010-09-03	1126	\N	39509	\N
47068	GENERIC_DAY	2	10	\N	2010-09-20	1130	\N	39509	\N
47183	GENERIC_DAY	2	10	\N	2010-07-14	1130	\N	39509	\N
46995	GENERIC_DAY	2	11	\N	2010-08-24	1126	\N	39509	\N
47212	GENERIC_DAY	2	10	\N	2010-08-27	1128	\N	39509	\N
47129	GENERIC_DAY	2	11	\N	2010-08-19	1126	\N	39509	\N
47084	GENERIC_DAY	2	10	\N	2010-08-09	1130	\N	39509	\N
47063	GENERIC_DAY	2	11	\N	2010-08-02	1128	\N	39509	\N
47107	GENERIC_DAY	2	11	\N	2010-09-08	1126	\N	39509	\N
46997	GENERIC_DAY	2	10	\N	2010-07-21	1130	\N	39509	\N
47158	GENERIC_DAY	2	11	\N	2010-07-29	1128	\N	39509	\N
47012	GENERIC_DAY	2	0	\N	2010-08-08	1126	\N	39509	\N
47161	GENERIC_DAY	2	11	\N	2010-07-14	1128	\N	39509	\N
47039	GENERIC_DAY	2	0	\N	2010-09-05	1130	\N	39509	\N
47193	GENERIC_DAY	2	11	\N	2010-08-26	1130	\N	39509	\N
47008	GENERIC_DAY	2	11	\N	2010-08-10	1126	\N	39509	\N
47136	GENERIC_DAY	2	0	\N	2010-08-07	1130	\N	39509	\N
47165	GENERIC_DAY	2	0	\N	2010-07-24	1128	\N	39509	\N
47071	GENERIC_DAY	2	0	\N	2010-07-24	1130	\N	39509	\N
47139	GENERIC_DAY	2	11	\N	2010-07-09	1128	\N	39509	\N
47054	GENERIC_DAY	2	10	\N	2010-09-07	1128	\N	39509	\N
47078	GENERIC_DAY	2	11	\N	2010-09-20	1126	\N	39509	\N
47065	GENERIC_DAY	2	11	\N	2010-07-05	1128	\N	39509	\N
47100	GENERIC_DAY	2	10	\N	2010-09-16	1130	\N	39509	\N
47108	GENERIC_DAY	2	11	\N	2010-08-09	1126	\N	39509	\N
47210	GENERIC_DAY	2	0	\N	2010-09-11	1126	\N	39509	\N
47173	GENERIC_DAY	2	0	\N	2010-08-14	1130	\N	39509	\N
46991	GENERIC_DAY	2	0	\N	2010-08-14	1126	\N	39509	\N
47163	GENERIC_DAY	2	6	\N	2010-09-23	1126	\N	39509	\N
47104	GENERIC_DAY	2	0	\N	2010-09-12	1128	\N	39509	\N
47105	GENERIC_DAY	2	10	\N	2010-09-14	1130	\N	39509	\N
47188	GENERIC_DAY	2	0	\N	2010-07-31	1128	\N	39509	\N
47153	GENERIC_DAY	2	0	\N	2010-07-25	1126	\N	39509	\N
47059	GENERIC_DAY	2	0	\N	2010-08-21	1130	\N	39509	\N
47067	GENERIC_DAY	2	11	\N	2010-07-19	1128	\N	39509	\N
47124	GENERIC_DAY	2	11	\N	2010-09-09	1126	\N	39509	\N
47044	GENERIC_DAY	2	11	\N	2010-08-23	1130	\N	39509	\N
47184	GENERIC_DAY	2	11	\N	2010-09-20	1128	\N	39509	\N
46970	GENERIC_DAY	2	11	\N	2010-07-08	1128	\N	39509	\N
47199	GENERIC_DAY	2	10	\N	2010-09-10	1126	\N	39509	\N
47076	GENERIC_DAY	2	11	\N	2010-08-31	1126	\N	39509	\N
47027	GENERIC_DAY	2	11	\N	2010-07-30	1128	\N	39509	\N
46973	GENERIC_DAY	2	0	\N	2010-07-25	1130	\N	39509	\N
47090	GENERIC_DAY	2	11	\N	2010-06-30	1128	\N	39509	\N
47186	GENERIC_DAY	2	11	\N	2010-08-05	1126	\N	39509	\N
47089	GENERIC_DAY	2	11	\N	2010-09-22	1126	\N	39509	\N
47216	GENERIC_DAY	2	11	\N	2010-09-01	1130	\N	39509	\N
47203	GENERIC_DAY	2	0	\N	2010-07-18	1130	\N	39509	\N
46996	GENERIC_DAY	2	11	\N	2010-08-26	1126	\N	39509	\N
47146	GENERIC_DAY	2	11	\N	2010-09-08	1130	\N	39509	\N
47167	GENERIC_DAY	2	11	\N	2010-08-02	1126	\N	39509	\N
47061	GENERIC_DAY	2	10	\N	2010-07-13	1130	\N	39509	\N
46980	GENERIC_DAY	2	0	\N	2010-08-15	1130	\N	39509	\N
47137	GENERIC_DAY	2	0	\N	2010-07-18	1126	\N	39509	\N
47168	GENERIC_DAY	2	11	\N	2010-07-15	1126	\N	39509	\N
47209	GENERIC_DAY	2	11	\N	2010-07-27	1126	\N	39509	\N
47111	GENERIC_DAY	2	0	\N	2010-07-04	1130	\N	39509	\N
47102	GENERIC_DAY	2	11	\N	2010-08-20	1126	\N	39509	\N
47024	GENERIC_DAY	2	0	\N	2010-07-04	1128	\N	39509	\N
47189	GENERIC_DAY	2	10	\N	2010-07-23	1130	\N	39509	\N
47149	GENERIC_DAY	2	11	\N	2010-07-07	1128	\N	39509	\N
47034	GENERIC_DAY	2	10	\N	2010-08-11	1130	\N	39509	\N
46977	GENERIC_DAY	2	11	\N	2010-07-13	1126	\N	39509	\N
46990	GENERIC_DAY	2	0	\N	2010-08-28	1128	\N	39509	\N
47106	GENERIC_DAY	2	10	\N	2010-07-09	1130	\N	39509	\N
46987	GENERIC_DAY	2	10	\N	2010-07-12	1130	\N	39509	\N
47118	GENERIC_DAY	2	11	\N	2010-08-13	1128	\N	39509	\N
47110	GENERIC_DAY	2	10	\N	2010-08-24	1128	\N	39509	\N
46967	GENERIC_DAY	2	10	\N	2010-07-06	1130	\N	39509	\N
47010	GENERIC_DAY	2	0	\N	2010-09-04	1130	\N	39509	\N
47147	GENERIC_DAY	2	11	\N	2010-07-12	1128	\N	39509	\N
47014	GENERIC_DAY	2	0	\N	2010-07-31	1130	\N	39509	\N
47120	GENERIC_DAY	2	10	\N	2010-07-26	1130	\N	39509	\N
47159	GENERIC_DAY	2	10	\N	2010-07-15	1130	\N	39509	\N
47037	GENERIC_DAY	2	0	\N	2010-08-29	1126	\N	39509	\N
47164	GENERIC_DAY	2	10	\N	2010-09-02	1128	\N	39509	\N
47125	GENERIC_DAY	2	11	\N	2010-09-13	1128	\N	39509	\N
47033	GENERIC_DAY	2	11	\N	2010-07-16	1126	\N	39509	\N
47053	GENERIC_DAY	2	11	\N	2010-07-07	1126	\N	39509	\N
46986	GENERIC_DAY	2	11	\N	2010-09-06	1126	\N	39509	\N
46981	GENERIC_DAY	2	0	\N	2010-07-10	1128	\N	39509	\N
47221	GENERIC_DAY	2	0	\N	2010-09-18	1128	\N	39509	\N
47160	GENERIC_DAY	2	0	\N	2010-08-08	1128	\N	39509	\N
47015	GENERIC_DAY	2	11	\N	2010-09-07	1130	\N	39509	\N
47043	GENERIC_DAY	2	10	\N	2010-08-10	1130	\N	39509	\N
47131	GENERIC_DAY	2	11	\N	2010-07-26	1126	\N	39509	\N
47213	GENERIC_DAY	2	11	\N	2010-08-18	1126	\N	39509	\N
47062	GENERIC_DAY	2	10	\N	2010-09-01	1128	\N	39509	\N
47172	GENERIC_DAY	2	0	\N	2010-07-17	1130	\N	39509	\N
47145	GENERIC_DAY	2	11	\N	2010-08-09	1128	\N	39509	\N
46985	GENERIC_DAY	2	11	\N	2010-08-30	1130	\N	39509	\N
47036	GENERIC_DAY	2	0	\N	2010-09-11	1130	\N	39509	\N
47018	GENERIC_DAY	2	10	\N	2010-06-29	1130	\N	39509	\N
47144	GENERIC_DAY	2	11	\N	2010-09-15	1126	\N	39509	\N
47192	GENERIC_DAY	2	11	\N	2010-07-02	1128	\N	39509	\N
47040	GENERIC_DAY	2	11	\N	2010-07-05	1126	\N	39509	\N
47023	GENERIC_DAY	2	10	\N	2010-08-20	1128	\N	39509	\N
47101	GENERIC_DAY	2	11	\N	2010-06-29	1128	\N	39509	\N
47126	GENERIC_DAY	2	11	\N	2010-08-10	1128	\N	39509	\N
47009	GENERIC_DAY	2	11	\N	2010-09-13	1126	\N	39509	\N
47138	GENERIC_DAY	2	11	\N	2010-09-16	1128	\N	39509	\N
47148	GENERIC_DAY	2	0	\N	2010-09-19	1128	\N	39509	\N
46992	GENERIC_DAY	2	11	\N	2010-08-13	1126	\N	39509	\N
46994	GENERIC_DAY	2	10	\N	2010-08-31	1128	\N	39509	\N
47202	GENERIC_DAY	2	0	\N	2010-07-11	1128	\N	39509	\N
47206	GENERIC_DAY	2	10	\N	2010-09-13	1130	\N	39509	\N
47191	GENERIC_DAY	2	0	\N	2010-07-03	1126	\N	39509	\N
47143	GENERIC_DAY	2	10	\N	2010-09-03	1128	\N	39509	\N
47176	GENERIC_DAY	2	10	\N	2010-07-05	1130	\N	39509	\N
47016	GENERIC_DAY	2	10	\N	2010-07-28	1130	\N	39509	\N
47080	GENERIC_DAY	2	0	\N	2010-07-04	1126	\N	39509	\N
47141	GENERIC_DAY	2	0	\N	2010-09-04	1128	\N	39509	\N
47195	GENERIC_DAY	2	10	\N	2010-07-27	1130	\N	39509	\N
47128	GENERIC_DAY	2	0	\N	2010-09-04	1126	\N	39509	\N
47219	GENERIC_DAY	2	0	\N	2010-09-05	1126	\N	39509	\N
46982	GENERIC_DAY	2	0	\N	2010-07-10	1126	\N	39509	\N
47116	GENERIC_DAY	2	0	\N	2010-08-21	1126	\N	39509	\N
47166	GENERIC_DAY	2	11	\N	2010-08-03	1126	\N	39509	\N
47042	GENERIC_DAY	2	11	\N	2010-09-07	1126	\N	39509	\N
47224	GENERIC_DAY	2	11	\N	2010-07-13	1128	\N	39509	\N
46976	GENERIC_DAY	2	11	\N	2010-07-22	1126	\N	39509	\N
47026	GENERIC_DAY	2	11	\N	2010-07-22	1128	\N	39509	\N
47047	GENERIC_DAY	2	11	\N	2010-08-17	1128	\N	39509	\N
47082	GENERIC_DAY	2	11	\N	2010-09-21	1126	\N	39509	\N
47048	GENERIC_DAY	2	11	\N	2010-07-01	1128	\N	39509	\N
46969	GENERIC_DAY	2	11	\N	2010-07-06	1128	\N	39509	\N
47207	GENERIC_DAY	2	0	\N	2010-08-01	1128	\N	39509	\N
47004	GENERIC_DAY	2	10	\N	2010-09-22	1130	\N	39509	\N
47190	GENERIC_DAY	2	11	\N	2010-07-20	1128	\N	39509	\N
47079	GENERIC_DAY	2	11	\N	2010-09-03	1130	\N	39509	\N
47052	GENERIC_DAY	2	10	\N	2010-08-13	1130	\N	39509	\N
47038	GENERIC_DAY	2	0	\N	2010-07-03	1128	\N	39509	\N
47028	GENERIC_DAY	2	11	\N	2010-06-29	1126	\N	39509	\N
47030	GENERIC_DAY	2	10	\N	2010-08-03	1130	\N	39509	\N
47179	GENERIC_DAY	2	10	\N	2010-09-17	1130	\N	39509	\N
47151	GENERIC_DAY	2	0	\N	2010-08-15	1128	\N	39509	\N
47029	GENERIC_DAY	2	0	\N	2010-09-11	1128	\N	39509	\N
47025	GENERIC_DAY	2	11	\N	2010-09-10	1130	\N	39509	\N
47064	GENERIC_DAY	2	10	\N	2010-07-29	1130	\N	39509	\N
47092	GENERIC_DAY	2	11	\N	2010-08-27	1126	\N	39509	\N
47017	GENERIC_DAY	2	11	\N	2010-08-12	1126	\N	39509	\N
47097	GENERIC_DAY	2	11	\N	2010-07-09	1126	\N	39509	\N
46968	GENERIC_DAY	2	11	\N	2010-08-16	1126	\N	39509	\N
47223	GENERIC_DAY	2	11	\N	2010-08-24	1130	\N	39509	\N
47169	GENERIC_DAY	2	0	\N	2010-08-28	1130	\N	39509	\N
47041	GENERIC_DAY	2	11	\N	2010-07-23	1128	\N	39509	\N
47013	GENERIC_DAY	2	11	\N	2010-07-19	1126	\N	39509	\N
47220	GENERIC_DAY	2	10	\N	2010-08-18	1128	\N	39509	\N
47020	GENERIC_DAY	2	10	\N	2010-09-06	1128	\N	39509	\N
47088	GENERIC_DAY	2	10	\N	2010-07-01	1130	\N	39509	\N
10004	GENERIC_DAY	2	0	\N	2010-06-12	1121	\N	2679	\N
10006	GENERIC_DAY	2	16	\N	2010-05-04	1123	\N	2679	\N
10002	GENERIC_DAY	2	6	\N	2010-06-10	1119	\N	2679	\N
10003	GENERIC_DAY	2	0	\N	2010-06-13	1123	\N	2679	\N
9998	GENERIC_DAY	2	5	\N	2010-05-21	1121	\N	2679	\N
9999	GENERIC_DAY	2	5	\N	2010-05-25	1121	\N	2679	\N
10005	GENERIC_DAY	2	5	\N	2010-05-13	1121	\N	2679	\N
10008	GENERIC_DAY	2	6	\N	2010-05-19	1119	\N	2679	\N
10000	GENERIC_DAY	2	0	\N	2010-05-15	1121	\N	2679	\N
10007	GENERIC_DAY	2	0	\N	2010-06-05	1121	\N	2679	\N
10001	GENERIC_DAY	2	5	\N	2010-06-08	1121	\N	2679	\N
47022	GENERIC_DAY	2	5	\N	2010-09-23	1130	\N	39509	\N
47162	GENERIC_DAY	2	11	\N	2010-09-14	1126	\N	39509	\N
47058	GENERIC_DAY	2	10	\N	2010-06-30	1130	\N	39509	\N
47187	GENERIC_DAY	2	11	\N	2010-07-15	1128	\N	39509	\N
47019	GENERIC_DAY	2	0	\N	2010-08-22	1126	\N	39509	\N
47077	GENERIC_DAY	2	11	\N	2010-08-06	1126	\N	39509	\N
47508	GENERIC_DAY	2	0	\N	2010-09-12	14343	\N	39511	\N
47560	GENERIC_DAY	2	11	\N	2010-07-06	14345	\N	39511	\N
47356	GENERIC_DAY	2	10	\N	2010-07-12	26463	\N	39511	\N
47444	GENERIC_DAY	2	11	\N	2010-07-28	14345	\N	39511	\N
47502	GENERIC_DAY	2	10	\N	2010-08-18	26463	\N	39511	\N
47394	GENERIC_DAY	2	11	\N	2010-08-31	14345	\N	39511	\N
47466	GENERIC_DAY	2	11	\N	2010-07-29	14343	\N	39511	\N
47395	GENERIC_DAY	2	0	\N	2010-09-18	26463	\N	39511	\N
47536	GENERIC_DAY	2	11	\N	2010-08-30	14345	\N	39511	\N
47493	GENERIC_DAY	2	11	\N	2010-09-14	14345	\N	39511	\N
47365	GENERIC_DAY	2	0	\N	2010-08-28	26463	\N	39511	\N
47357	GENERIC_DAY	2	11	\N	2010-07-02	14345	\N	39511	\N
47521	GENERIC_DAY	2	10	\N	2010-09-13	26463	\N	39511	\N
47573	GENERIC_DAY	2	0	\N	2010-07-11	26463	\N	39511	\N
47367	GENERIC_DAY	2	10	\N	2010-07-01	26463	\N	39511	\N
47526	GENERIC_DAY	2	11	\N	2010-08-06	14345	\N	39511	\N
47407	GENERIC_DAY	2	10	\N	2010-08-20	26463	\N	39511	\N
47319	GENERIC_DAY	2	10	\N	2010-08-09	26463	\N	39511	\N
12913	SPECIFIC_DAY	0	0	\N	2010-09-12	1132	2715	\N	\N
12914	SPECIFIC_DAY	0	8	\N	2010-09-30	1132	2715	\N	\N
12915	SPECIFIC_DAY	0	8	\N	2010-09-17	1132	2715	\N	\N
12916	SPECIFIC_DAY	0	0	\N	2010-09-19	1132	2715	\N	\N
12917	SPECIFIC_DAY	0	8	\N	2010-09-24	1132	2715	\N	\N
12918	SPECIFIC_DAY	0	8	\N	2010-09-21	1132	2715	\N	\N
12919	SPECIFIC_DAY	0	8	\N	2010-09-16	1132	2715	\N	\N
12920	SPECIFIC_DAY	0	8	\N	2010-10-04	1132	2715	\N	\N
12921	SPECIFIC_DAY	0	8	\N	2010-10-05	1132	2715	\N	\N
12922	SPECIFIC_DAY	0	8	\N	2010-09-13	1132	2715	\N	\N
12923	SPECIFIC_DAY	0	0	\N	2010-09-11	1132	2715	\N	\N
12924	SPECIFIC_DAY	0	2	\N	2010-10-13	1134	2716	\N	\N
12925	SPECIFIC_DAY	0	8	\N	2010-10-06	1134	2716	\N	\N
12926	SPECIFIC_DAY	0	8	\N	2010-09-20	1134	2716	\N	\N
12927	SPECIFIC_DAY	0	0	\N	2010-10-09	1134	2716	\N	\N
12928	SPECIFIC_DAY	0	8	\N	2010-09-16	1134	2716	\N	\N
12929	SPECIFIC_DAY	0	8	\N	2010-10-01	1134	2716	\N	\N
12930	SPECIFIC_DAY	0	0	\N	2010-09-18	1134	2716	\N	\N
12931	SPECIFIC_DAY	0	8	\N	2010-09-23	1134	2716	\N	\N
12932	SPECIFIC_DAY	0	8	\N	2010-09-24	1134	2716	\N	\N
12933	SPECIFIC_DAY	0	8	\N	2010-10-11	1134	2716	\N	\N
12934	SPECIFIC_DAY	0	8	\N	2010-09-22	1134	2716	\N	\N
12935	SPECIFIC_DAY	0	8	\N	2010-10-07	1134	2716	\N	\N
12936	SPECIFIC_DAY	0	8	\N	2010-10-04	1134	2716	\N	\N
12937	SPECIFIC_DAY	0	0	\N	2010-10-12	1134	2716	\N	\N
12938	SPECIFIC_DAY	0	8	\N	2010-09-27	1134	2716	\N	\N
12939	SPECIFIC_DAY	0	0	\N	2010-09-12	1134	2716	\N	\N
12940	SPECIFIC_DAY	0	8	\N	2010-10-08	1134	2716	\N	\N
12941	SPECIFIC_DAY	0	8	\N	2010-09-13	1134	2716	\N	\N
12942	SPECIFIC_DAY	0	8	\N	2010-09-17	1134	2716	\N	\N
12943	SPECIFIC_DAY	0	0	\N	2010-10-03	1134	2716	\N	\N
12944	SPECIFIC_DAY	0	8	\N	2010-09-21	1134	2716	\N	\N
12945	SPECIFIC_DAY	0	8	\N	2010-09-14	1134	2716	\N	\N
12946	SPECIFIC_DAY	0	0	\N	2010-09-26	1134	2716	\N	\N
12947	SPECIFIC_DAY	0	8	\N	2010-09-15	1134	2716	\N	\N
12948	SPECIFIC_DAY	0	0	\N	2010-09-25	1134	2716	\N	\N
12949	SPECIFIC_DAY	0	8	\N	2010-09-28	1134	2716	\N	\N
12950	SPECIFIC_DAY	0	0	\N	2010-09-19	1134	2716	\N	\N
12951	SPECIFIC_DAY	0	8	\N	2010-10-05	1134	2716	\N	\N
12952	SPECIFIC_DAY	0	8	\N	2010-09-30	1134	2716	\N	\N
12953	SPECIFIC_DAY	0	8	\N	2010-09-29	1134	2716	\N	\N
12954	SPECIFIC_DAY	0	0	\N	2010-09-11	1134	2716	\N	\N
12955	SPECIFIC_DAY	0	0	\N	2010-10-02	1134	2716	\N	\N
12956	SPECIFIC_DAY	0	0	\N	2010-10-10	1134	2716	\N	\N
12957	GENERIC_DAY	0	0	\N	2010-08-08	1121	\N	2717	\N
12958	GENERIC_DAY	0	3	\N	2010-08-10	1121	\N	2717	\N
12959	GENERIC_DAY	0	0	\N	2010-08-07	1123	\N	2717	\N
12960	GENERIC_DAY	0	3	\N	2010-08-10	1119	\N	2717	\N
12961	GENERIC_DAY	0	0	\N	2010-08-07	1121	\N	2717	\N
12962	GENERIC_DAY	0	0	\N	2010-08-08	1123	\N	2717	\N
12963	GENERIC_DAY	0	3	\N	2010-08-06	1121	\N	2717	\N
12964	GENERIC_DAY	0	2	\N	2010-08-10	1123	\N	2717	\N
12965	GENERIC_DAY	0	0	\N	2010-08-07	1119	\N	2717	\N
12966	GENERIC_DAY	0	2	\N	2010-08-06	1123	\N	2717	\N
12967	GENERIC_DAY	0	0	\N	2010-08-08	1119	\N	2717	\N
12968	GENERIC_DAY	0	3	\N	2010-08-09	1121	\N	2717	\N
12969	GENERIC_DAY	0	3	\N	2010-08-06	1119	\N	2717	\N
12970	GENERIC_DAY	0	2	\N	2010-08-09	1123	\N	2717	\N
12971	GENERIC_DAY	0	3	\N	2010-08-09	1119	\N	2717	\N
12972	GENERIC_DAY	0	3	\N	2010-09-01	1128	\N	2718	\N
12973	GENERIC_DAY	0	1	\N	2010-09-10	1128	\N	2718	\N
12974	GENERIC_DAY	0	1	\N	2010-09-10	1130	\N	2718	\N
12975	GENERIC_DAY	0	2	\N	2010-09-09	1130	\N	2718	\N
12976	GENERIC_DAY	0	3	\N	2010-09-08	1126	\N	2718	\N
12977	GENERIC_DAY	0	3	\N	2010-08-30	1126	\N	2718	\N
12978	GENERIC_DAY	0	2	\N	2010-09-06	1130	\N	2718	\N
12979	GENERIC_DAY	0	3	\N	2010-08-26	1126	\N	2718	\N
12980	GENERIC_DAY	0	0	\N	2010-09-05	1128	\N	2718	\N
12981	GENERIC_DAY	0	3	\N	2010-08-27	1128	\N	2718	\N
12982	GENERIC_DAY	0	3	\N	2010-09-09	1126	\N	2718	\N
12983	GENERIC_DAY	0	0	\N	2010-09-05	1126	\N	2718	\N
12984	GENERIC_DAY	0	0	\N	2010-08-28	1128	\N	2718	\N
12985	GENERIC_DAY	0	0	\N	2010-08-29	1128	\N	2718	\N
12986	GENERIC_DAY	0	3	\N	2010-09-03	1128	\N	2718	\N
12987	GENERIC_DAY	0	2	\N	2010-09-03	1130	\N	2718	\N
12988	GENERIC_DAY	0	2	\N	2010-08-26	1130	\N	2718	\N
12989	GENERIC_DAY	0	3	\N	2010-08-25	1128	\N	2718	\N
12990	GENERIC_DAY	0	2	\N	2010-09-10	1126	\N	2718	\N
12991	GENERIC_DAY	0	3	\N	2010-08-31	1128	\N	2718	\N
12992	GENERIC_DAY	0	2	\N	2010-08-25	1130	\N	2718	\N
12993	GENERIC_DAY	0	0	\N	2010-08-28	1130	\N	2718	\N
12994	GENERIC_DAY	0	3	\N	2010-09-09	1128	\N	2718	\N
12995	GENERIC_DAY	0	3	\N	2010-09-07	1126	\N	2718	\N
12996	GENERIC_DAY	0	3	\N	2010-09-02	1126	\N	2718	\N
12997	GENERIC_DAY	0	0	\N	2010-09-05	1130	\N	2718	\N
12998	GENERIC_DAY	0	3	\N	2010-09-01	1126	\N	2718	\N
12999	GENERIC_DAY	0	3	\N	2010-08-25	1126	\N	2718	\N
13000	GENERIC_DAY	0	3	\N	2010-09-06	1126	\N	2718	\N
13001	GENERIC_DAY	0	0	\N	2010-09-04	1128	\N	2718	\N
13002	GENERIC_DAY	0	3	\N	2010-08-31	1126	\N	2718	\N
13003	GENERIC_DAY	0	0	\N	2010-09-04	1126	\N	2718	\N
13004	GENERIC_DAY	0	2	\N	2010-08-30	1130	\N	2718	\N
13005	GENERIC_DAY	0	3	\N	2010-09-06	1128	\N	2718	\N
13006	GENERIC_DAY	0	0	\N	2010-08-28	1126	\N	2718	\N
13007	GENERIC_DAY	0	2	\N	2010-08-31	1130	\N	2718	\N
13008	GENERIC_DAY	0	0	\N	2010-08-29	1130	\N	2718	\N
13009	GENERIC_DAY	0	3	\N	2010-08-26	1128	\N	2718	\N
13010	GENERIC_DAY	0	2	\N	2010-08-27	1130	\N	2718	\N
13011	GENERIC_DAY	0	2	\N	2010-09-01	1130	\N	2718	\N
13012	GENERIC_DAY	0	3	\N	2010-08-30	1128	\N	2718	\N
13013	GENERIC_DAY	0	0	\N	2010-09-04	1130	\N	2718	\N
13014	GENERIC_DAY	0	3	\N	2010-09-08	1128	\N	2718	\N
13015	GENERIC_DAY	0	3	\N	2010-08-27	1126	\N	2718	\N
13016	GENERIC_DAY	0	2	\N	2010-09-08	1130	\N	2718	\N
13017	GENERIC_DAY	0	3	\N	2010-09-03	1126	\N	2718	\N
13018	GENERIC_DAY	0	3	\N	2010-09-02	1128	\N	2718	\N
13019	GENERIC_DAY	0	2	\N	2010-09-07	1130	\N	2718	\N
13020	GENERIC_DAY	0	2	\N	2010-09-02	1130	\N	2718	\N
13021	GENERIC_DAY	0	0	\N	2010-08-29	1126	\N	2718	\N
13022	GENERIC_DAY	0	3	\N	2010-09-07	1128	\N	2718	\N
13023	GENERIC_DAY	0	4	\N	2010-10-25	1119	\N	2719	\N
13024	GENERIC_DAY	0	8	\N	2010-10-22	1119	\N	2719	\N
13025	GENERIC_DAY	0	0	\N	2010-10-17	1119	\N	2719	\N
13026	GENERIC_DAY	0	8	\N	2010-10-15	1119	\N	2719	\N
13027	GENERIC_DAY	0	8	\N	2010-10-20	1119	\N	2719	\N
13028	GENERIC_DAY	0	0	\N	2010-10-16	1119	\N	2719	\N
13029	GENERIC_DAY	0	0	\N	2010-10-23	1119	\N	2719	\N
13030	GENERIC_DAY	0	0	\N	2010-10-24	1119	\N	2719	\N
13031	GENERIC_DAY	0	8	\N	2010-10-19	1119	\N	2719	\N
13032	GENERIC_DAY	0	8	\N	2010-10-18	1119	\N	2719	\N
13033	GENERIC_DAY	0	8	\N	2010-10-14	1119	\N	2719	\N
13034	GENERIC_DAY	0	8	\N	2010-10-21	1119	\N	2719	\N
13035	GENERIC_DAY	0	0	\N	2010-08-15	1121	\N	2720	\N
13036	GENERIC_DAY	0	0	\N	2010-08-14	1121	\N	2720	\N
13037	GENERIC_DAY	0	2	\N	2010-08-16	1123	\N	2720	\N
13038	GENERIC_DAY	0	0	\N	2010-08-14	1123	\N	2720	\N
13039	GENERIC_DAY	0	0	\N	2010-08-15	1119	\N	2720	\N
13040	GENERIC_DAY	0	3	\N	2010-08-12	1119	\N	2720	\N
13041	GENERIC_DAY	0	2	\N	2010-08-11	1123	\N	2720	\N
13042	GENERIC_DAY	0	3	\N	2010-08-13	1121	\N	2720	\N
13043	GENERIC_DAY	0	3	\N	2010-08-11	1121	\N	2720	\N
13044	GENERIC_DAY	0	3	\N	2010-08-12	1121	\N	2720	\N
13045	GENERIC_DAY	0	3	\N	2010-08-16	1121	\N	2720	\N
13046	GENERIC_DAY	0	0	\N	2010-08-15	1123	\N	2720	\N
13047	GENERIC_DAY	0	3	\N	2010-08-11	1119	\N	2720	\N
13048	GENERIC_DAY	0	3	\N	2010-08-13	1119	\N	2720	\N
13049	GENERIC_DAY	0	3	\N	2010-08-16	1119	\N	2720	\N
13050	GENERIC_DAY	0	0	\N	2010-08-14	1119	\N	2720	\N
13051	GENERIC_DAY	0	2	\N	2010-08-13	1123	\N	2720	\N
13052	GENERIC_DAY	0	3	\N	2010-08-17	1119	\N	2720	\N
13053	GENERIC_DAY	0	2	\N	2010-08-17	1123	\N	2720	\N
13054	GENERIC_DAY	0	3	\N	2010-08-17	1121	\N	2720	\N
13055	GENERIC_DAY	0	2	\N	2010-08-12	1123	\N	2720	\N
13056	GENERIC_DAY	0	3	\N	2010-08-24	1128	\N	2721	\N
13057	GENERIC_DAY	0	3	\N	2010-08-20	1128	\N	2721	\N
13058	GENERIC_DAY	0	3	\N	2010-08-20	1126	\N	2721	\N
13059	GENERIC_DAY	0	3	\N	2010-08-18	1128	\N	2721	\N
13060	GENERIC_DAY	0	0	\N	2010-08-21	1130	\N	2721	\N
13061	GENERIC_DAY	0	2	\N	2010-08-23	1130	\N	2721	\N
13062	GENERIC_DAY	0	2	\N	2010-08-20	1130	\N	2721	\N
13063	GENERIC_DAY	0	0	\N	2010-08-22	1130	\N	2721	\N
13064	GENERIC_DAY	0	0	\N	2010-08-21	1126	\N	2721	\N
13065	GENERIC_DAY	0	0	\N	2010-08-22	1126	\N	2721	\N
13066	GENERIC_DAY	0	3	\N	2010-08-18	1126	\N	2721	\N
13067	GENERIC_DAY	0	3	\N	2010-08-19	1128	\N	2721	\N
13068	GENERIC_DAY	0	2	\N	2010-08-24	1130	\N	2721	\N
13069	GENERIC_DAY	0	3	\N	2010-08-23	1126	\N	2721	\N
13070	GENERIC_DAY	0	2	\N	2010-08-19	1130	\N	2721	\N
13071	GENERIC_DAY	0	0	\N	2010-08-21	1128	\N	2721	\N
13072	GENERIC_DAY	0	3	\N	2010-08-19	1126	\N	2721	\N
13073	GENERIC_DAY	0	3	\N	2010-08-24	1126	\N	2721	\N
13074	GENERIC_DAY	0	2	\N	2010-08-18	1130	\N	2721	\N
13075	GENERIC_DAY	0	3	\N	2010-08-23	1128	\N	2721	\N
13076	GENERIC_DAY	0	0	\N	2010-08-22	1128	\N	2721	\N
47335	GENERIC_DAY	2	0	\N	2010-07-03	14345	\N	39511	\N
47472	GENERIC_DAY	2	11	\N	2010-09-16	14345	\N	39511	\N
47561	GENERIC_DAY	2	0	\N	2010-07-04	14343	\N	39511	\N
47548	GENERIC_DAY	2	11	\N	2010-07-27	14345	\N	39511	\N
47441	GENERIC_DAY	2	0	\N	2010-07-31	14345	\N	39511	\N
47375	GENERIC_DAY	2	0	\N	2010-08-28	14343	\N	39511	\N
47396	GENERIC_DAY	2	11	\N	2010-08-02	14345	\N	39511	\N
47492	GENERIC_DAY	2	10	\N	2010-08-11	26463	\N	39511	\N
47510	GENERIC_DAY	2	11	\N	2010-09-01	14343	\N	39511	\N
47501	GENERIC_DAY	2	11	\N	2010-08-05	14345	\N	39511	\N
47415	GENERIC_DAY	2	10	\N	2010-09-03	26463	\N	39511	\N
47439	GENERIC_DAY	2	0	\N	2010-08-21	14345	\N	39511	\N
47531	GENERIC_DAY	2	0	\N	2010-07-24	14343	\N	39511	\N
47369	GENERIC_DAY	2	0	\N	2010-07-31	14343	\N	39511	\N
47397	GENERIC_DAY	2	0	\N	2010-07-10	14345	\N	39511	\N
47467	GENERIC_DAY	2	11	\N	2010-08-18	14343	\N	39511	\N
47428	GENERIC_DAY	2	11	\N	2010-07-28	14343	\N	39511	\N
47542	GENERIC_DAY	2	10	\N	2010-09-14	26463	\N	39511	\N
47511	GENERIC_DAY	2	10	\N	2010-06-30	26463	\N	39511	\N
47419	GENERIC_DAY	2	11	\N	2010-09-20	14345	\N	39511	\N
47475	GENERIC_DAY	2	10	\N	2010-07-27	26463	\N	39511	\N
47505	GENERIC_DAY	2	0	\N	2010-09-05	14345	\N	39511	\N
47363	GENERIC_DAY	2	10	\N	2010-09-09	26463	\N	39511	\N
47535	GENERIC_DAY	2	10	\N	2010-09-10	26463	\N	39511	\N
47352	GENERIC_DAY	2	0	\N	2010-07-11	14345	\N	39511	\N
47509	GENERIC_DAY	2	10	\N	2010-09-22	26463	\N	39511	\N
47518	GENERIC_DAY	2	0	\N	2010-07-04	14345	\N	39511	\N
47339	GENERIC_DAY	2	10	\N	2010-07-15	26463	\N	39511	\N
47346	GENERIC_DAY	2	6	\N	2010-09-23	14343	\N	39511	\N
47541	GENERIC_DAY	2	0	\N	2010-08-01	14345	\N	39511	\N
47382	GENERIC_DAY	2	11	\N	2010-09-14	14343	\N	39511	\N
47343	GENERIC_DAY	2	11	\N	2010-07-23	14345	\N	39511	\N
47414	GENERIC_DAY	2	11	\N	2010-09-09	14343	\N	39511	\N
47418	GENERIC_DAY	2	10	\N	2010-08-25	26463	\N	39511	\N
47341	GENERIC_DAY	2	0	\N	2010-07-24	14345	\N	39511	\N
47522	GENERIC_DAY	2	11	\N	2010-08-17	14345	\N	39511	\N
47323	GENERIC_DAY	2	11	\N	2010-08-19	14345	\N	39511	\N
47406	GENERIC_DAY	2	10	\N	2010-08-31	26463	\N	39511	\N
47329	GENERIC_DAY	2	0	\N	2010-07-18	14345	\N	39511	\N
47452	GENERIC_DAY	2	11	\N	2010-08-10	14345	\N	39511	\N
47566	GENERIC_DAY	2	10	\N	2010-08-23	26463	\N	39511	\N
47491	GENERIC_DAY	2	0	\N	2010-08-08	26463	\N	39511	\N
47558	GENERIC_DAY	2	0	\N	2010-09-19	26463	\N	39511	\N
47539	GENERIC_DAY	2	0	\N	2010-07-31	26463	\N	39511	\N
47424	GENERIC_DAY	2	10	\N	2010-06-29	26463	\N	39511	\N
47477	GENERIC_DAY	2	11	\N	2010-07-08	14345	\N	39511	\N
47366	GENERIC_DAY	2	11	\N	2010-07-01	14343	\N	39511	\N
47556	GENERIC_DAY	2	11	\N	2010-08-26	14345	\N	39511	\N
47495	GENERIC_DAY	2	11	\N	2010-08-03	14343	\N	39511	\N
47351	GENERIC_DAY	2	11	\N	2010-07-05	14345	\N	39511	\N
47440	GENERIC_DAY	2	11	\N	2010-08-30	14343	\N	39511	\N
47355	GENERIC_DAY	2	0	\N	2010-07-24	26463	\N	39511	\N
47516	GENERIC_DAY	2	11	\N	2010-09-02	14343	\N	39511	\N
47411	GENERIC_DAY	2	11	\N	2010-08-27	14343	\N	39511	\N
47464	GENERIC_DAY	2	10	\N	2010-08-30	26463	\N	39511	\N
47520	GENERIC_DAY	2	10	\N	2010-07-05	26463	\N	39511	\N
47463	GENERIC_DAY	2	11	\N	2010-09-09	14345	\N	39511	\N
47499	GENERIC_DAY	2	11	\N	2010-06-30	14345	\N	39511	\N
47408	GENERIC_DAY	2	0	\N	2010-08-07	14343	\N	39511	\N
47562	GENERIC_DAY	2	0	\N	2010-09-04	14343	\N	39511	\N
47398	GENERIC_DAY	2	10	\N	2010-08-04	26463	\N	39511	\N
47315	GENERIC_DAY	2	11	\N	2010-08-11	14343	\N	39511	\N
47374	GENERIC_DAY	2	10	\N	2010-07-06	26463	\N	39511	\N
47401	GENERIC_DAY	2	0	\N	2010-08-01	14343	\N	39511	\N
47361	GENERIC_DAY	2	11	\N	2010-07-09	14343	\N	39511	\N
47571	GENERIC_DAY	2	11	\N	2010-07-07	14343	\N	39511	\N
47325	GENERIC_DAY	2	11	\N	2010-07-02	14343	\N	39511	\N
47376	GENERIC_DAY	2	11	\N	2010-07-13	14345	\N	39511	\N
47514	GENERIC_DAY	2	11	\N	2010-08-20	14343	\N	39511	\N
47559	GENERIC_DAY	2	11	\N	2010-07-16	14343	\N	39511	\N
47344	GENERIC_DAY	2	0	\N	2010-09-19	14343	\N	39511	\N
47427	GENERIC_DAY	2	0	\N	2010-07-17	26463	\N	39511	\N
47543	GENERIC_DAY	2	10	\N	2010-09-21	26463	\N	39511	\N
47353	GENERIC_DAY	2	10	\N	2010-07-20	26463	\N	39511	\N
47400	GENERIC_DAY	2	10	\N	2010-07-09	26463	\N	39511	\N
47433	GENERIC_DAY	2	11	\N	2010-08-24	14345	\N	39511	\N
47504	GENERIC_DAY	2	0	\N	2010-08-28	14345	\N	39511	\N
47330	GENERIC_DAY	2	10	\N	2010-09-17	26463	\N	39511	\N
47481	GENERIC_DAY	2	11	\N	2010-08-06	14343	\N	39511	\N
47485	GENERIC_DAY	2	11	\N	2010-09-07	14345	\N	39511	\N
47360	GENERIC_DAY	2	0	\N	2010-08-15	14345	\N	39511	\N
47384	GENERIC_DAY	2	11	\N	2010-08-13	14343	\N	39511	\N
47318	GENERIC_DAY	2	11	\N	2010-09-10	14345	\N	39511	\N
47423	GENERIC_DAY	2	10	\N	2010-07-19	26463	\N	39511	\N
47320	GENERIC_DAY	2	11	\N	2010-07-16	14345	\N	39511	\N
47487	GENERIC_DAY	2	11	\N	2010-08-09	14343	\N	39511	\N
47340	GENERIC_DAY	2	10	\N	2010-08-03	26463	\N	39511	\N
47373	GENERIC_DAY	2	0	\N	2010-08-14	14343	\N	39511	\N
47474	GENERIC_DAY	2	11	\N	2010-08-23	14345	\N	39511	\N
47387	GENERIC_DAY	2	10	\N	2010-08-06	26463	\N	39511	\N
47519	GENERIC_DAY	2	10	\N	2010-09-16	26463	\N	39511	\N
47451	GENERIC_DAY	2	10	\N	2010-09-20	26463	\N	39511	\N
47377	GENERIC_DAY	2	0	\N	2010-09-12	14345	\N	39511	\N
47555	GENERIC_DAY	2	11	\N	2010-07-20	14345	\N	39511	\N
47553	GENERIC_DAY	2	10	\N	2010-07-21	26463	\N	39511	\N
47469	GENERIC_DAY	2	10	\N	2010-08-27	26463	\N	39511	\N
47554	GENERIC_DAY	2	11	\N	2010-08-09	14345	\N	39511	\N
47529	GENERIC_DAY	2	11	\N	2010-08-25	14343	\N	39511	\N
47370	GENERIC_DAY	2	0	\N	2010-09-18	14345	\N	39511	\N
47498	GENERIC_DAY	2	10	\N	2010-09-15	26463	\N	39511	\N
47350	GENERIC_DAY	2	10	\N	2010-07-26	26463	\N	39511	\N
47405	GENERIC_DAY	2	5	\N	2010-09-23	26463	\N	39511	\N
47412	GENERIC_DAY	2	0	\N	2010-09-04	26463	\N	39511	\N
47483	GENERIC_DAY	2	11	\N	2010-09-20	14343	\N	39511	\N
47470	GENERIC_DAY	2	11	\N	2010-08-19	14343	\N	39511	\N
47347	GENERIC_DAY	2	0	\N	2010-08-07	26463	\N	39511	\N
47480	GENERIC_DAY	2	10	\N	2010-07-13	26463	\N	39511	\N
47494	GENERIC_DAY	2	11	\N	2010-09-17	14343	\N	39511	\N
47549	GENERIC_DAY	2	11	\N	2010-09-10	14343	\N	39511	\N
47523	GENERIC_DAY	2	11	\N	2010-08-13	14345	\N	39511	\N
47513	GENERIC_DAY	2	0	\N	2010-07-03	26463	\N	39511	\N
47378	GENERIC_DAY	2	10	\N	2010-07-23	26463	\N	39511	\N
47402	GENERIC_DAY	2	11	\N	2010-09-03	14345	\N	39511	\N
47364	GENERIC_DAY	2	0	\N	2010-07-25	26463	\N	39511	\N
47443	GENERIC_DAY	2	11	\N	2010-09-08	14345	\N	39511	\N
47453	GENERIC_DAY	2	10	\N	2010-08-24	26463	\N	39511	\N
47404	GENERIC_DAY	2	11	\N	2010-08-02	14343	\N	39511	\N
47416	GENERIC_DAY	2	11	\N	2010-09-22	14343	\N	39511	\N
47552	GENERIC_DAY	2	0	\N	2010-09-11	14345	\N	39511	\N
47471	GENERIC_DAY	2	11	\N	2010-08-23	14343	\N	39511	\N
47567	GENERIC_DAY	2	5	\N	2010-09-23	14345	\N	39511	\N
47517	GENERIC_DAY	2	10	\N	2010-09-06	26463	\N	39511	\N
47442	GENERIC_DAY	2	0	\N	2010-07-10	26463	\N	39511	\N
47528	GENERIC_DAY	2	11	\N	2010-07-21	14345	\N	39511	\N
47538	GENERIC_DAY	2	0	\N	2010-08-22	14345	\N	39511	\N
47390	GENERIC_DAY	2	0	\N	2010-07-04	26463	\N	39511	\N
47391	GENERIC_DAY	2	11	\N	2010-08-25	14345	\N	39511	\N
47409	GENERIC_DAY	2	11	\N	2010-09-01	14345	\N	39511	\N
47322	GENERIC_DAY	2	10	\N	2010-07-30	26463	\N	39511	\N
47447	GENERIC_DAY	2	11	\N	2010-07-22	14343	\N	39511	\N
47328	GENERIC_DAY	2	11	\N	2010-07-05	14343	\N	39511	\N
47445	GENERIC_DAY	2	11	\N	2010-08-10	14343	\N	39511	\N
47478	GENERIC_DAY	2	10	\N	2010-08-10	26463	\N	39511	\N
47465	GENERIC_DAY	2	11	\N	2010-08-20	14345	\N	39511	\N
47359	GENERIC_DAY	2	0	\N	2010-07-17	14343	\N	39511	\N
47482	GENERIC_DAY	2	11	\N	2010-07-29	14345	\N	39511	\N
47546	GENERIC_DAY	2	11	\N	2010-08-26	14343	\N	39511	\N
47479	GENERIC_DAY	2	0	\N	2010-08-29	26463	\N	39511	\N
47507	GENERIC_DAY	2	10	\N	2010-08-17	26463	\N	39511	\N
47488	GENERIC_DAY	2	11	\N	2010-08-24	14343	\N	39511	\N
47458	GENERIC_DAY	2	11	\N	2010-07-12	14343	\N	39511	\N
47462	GENERIC_DAY	2	0	\N	2010-07-18	26463	\N	39511	\N
47551	GENERIC_DAY	2	11	\N	2010-08-27	14345	\N	39511	\N
47533	GENERIC_DAY	2	11	\N	2010-07-09	14345	\N	39511	\N
47314	GENERIC_DAY	2	0	\N	2010-09-12	26463	\N	39511	\N
47455	GENERIC_DAY	2	11	\N	2010-07-14	14343	\N	39511	\N
47381	GENERIC_DAY	2	11	\N	2010-08-18	14345	\N	39511	\N
47568	GENERIC_DAY	2	10	\N	2010-07-16	26463	\N	39511	\N
47392	GENERIC_DAY	2	10	\N	2010-08-12	26463	\N	39511	\N
47420	GENERIC_DAY	2	11	\N	2010-08-04	14343	\N	39511	\N
47362	GENERIC_DAY	2	10	\N	2010-09-01	26463	\N	39511	\N
47425	GENERIC_DAY	2	10	\N	2010-08-19	26463	\N	39511	\N
47316	GENERIC_DAY	2	11	\N	2010-09-02	14345	\N	39511	\N
47446	GENERIC_DAY	2	11	\N	2010-07-14	14345	\N	39511	\N
47456	GENERIC_DAY	2	0	\N	2010-07-17	14345	\N	39511	\N
47557	GENERIC_DAY	2	11	\N	2010-09-13	14343	\N	39511	\N
47450	GENERIC_DAY	2	11	\N	2010-07-07	14345	\N	39511	\N
47547	GENERIC_DAY	2	11	\N	2010-09-21	14343	\N	39511	\N
47372	GENERIC_DAY	2	11	\N	2010-07-30	14345	\N	39511	\N
47386	GENERIC_DAY	2	11	\N	2010-07-30	14343	\N	39511	\N
47393	GENERIC_DAY	2	11	\N	2010-09-21	14345	\N	39511	\N
47527	GENERIC_DAY	2	11	\N	2010-09-03	14343	\N	39511	\N
47385	GENERIC_DAY	2	11	\N	2010-09-22	14345	\N	39511	\N
47496	GENERIC_DAY	2	0	\N	2010-08-01	26463	\N	39511	\N
47348	GENERIC_DAY	2	11	\N	2010-08-12	14345	\N	39511	\N
47550	GENERIC_DAY	2	11	\N	2010-09-07	14343	\N	39511	\N
47368	GENERIC_DAY	2	0	\N	2010-07-03	14343	\N	39511	\N
47331	GENERIC_DAY	2	11	\N	2010-07-21	14343	\N	39511	\N
47460	GENERIC_DAY	2	0	\N	2010-09-11	14343	\N	39511	\N
47399	GENERIC_DAY	2	11	\N	2010-09-15	14345	\N	39511	\N
47537	GENERIC_DAY	2	10	\N	2010-07-08	26463	\N	39511	\N
47417	GENERIC_DAY	2	11	\N	2010-07-12	14345	\N	39511	\N
47570	GENERIC_DAY	2	0	\N	2010-09-19	14345	\N	39511	\N
47413	GENERIC_DAY	2	11	\N	2010-07-06	14343	\N	39511	\N
47572	GENERIC_DAY	2	0	\N	2010-09-18	14343	\N	39511	\N
47429	GENERIC_DAY	2	11	\N	2010-08-16	14345	\N	39511	\N
47448	GENERIC_DAY	2	10	\N	2010-08-05	26463	\N	39511	\N
47486	GENERIC_DAY	2	11	\N	2010-09-15	14343	\N	39511	\N
47410	GENERIC_DAY	2	0	\N	2010-08-29	14343	\N	39511	\N
47388	GENERIC_DAY	2	0	\N	2010-08-21	14343	\N	39511	\N
47473	GENERIC_DAY	2	11	\N	2010-07-22	14345	\N	39511	\N
47432	GENERIC_DAY	2	0	\N	2010-08-15	14343	\N	39511	\N
47379	GENERIC_DAY	2	10	\N	2010-07-22	26463	\N	39511	\N
47468	GENERIC_DAY	2	0	\N	2010-09-04	14345	\N	39511	\N
47380	GENERIC_DAY	2	11	\N	2010-08-03	14345	\N	39511	\N
47332	GENERIC_DAY	2	11	\N	2010-07-01	14345	\N	39511	\N
47324	GENERIC_DAY	2	11	\N	2010-07-13	14343	\N	39511	\N
47532	GENERIC_DAY	2	0	\N	2010-09-05	14343	\N	39511	\N
47354	GENERIC_DAY	2	11	\N	2010-08-12	14343	\N	39511	\N
47565	GENERIC_DAY	2	10	\N	2010-07-07	26463	\N	39511	\N
47438	GENERIC_DAY	2	0	\N	2010-07-25	14343	\N	39511	\N
47383	GENERIC_DAY	2	0	\N	2010-08-22	14343	\N	39511	\N
47506	GENERIC_DAY	2	11	\N	2010-07-19	14343	\N	39511	\N
47545	GENERIC_DAY	2	0	\N	2010-09-11	26463	\N	39511	\N
47574	GENERIC_DAY	2	0	\N	2010-07-10	14343	\N	39511	\N
47430	GENERIC_DAY	2	0	\N	2010-07-18	14343	\N	39511	\N
47524	GENERIC_DAY	2	10	\N	2010-08-02	26463	\N	39511	\N
47484	GENERIC_DAY	2	11	\N	2010-07-23	14343	\N	39511	\N
47500	GENERIC_DAY	2	0	\N	2010-08-22	26463	\N	39511	\N
47437	GENERIC_DAY	2	11	\N	2010-07-26	14343	\N	39511	\N
47459	GENERIC_DAY	2	11	\N	2010-08-16	14343	\N	39511	\N
47434	GENERIC_DAY	2	11	\N	2010-07-27	14343	\N	39511	\N
47431	GENERIC_DAY	2	0	\N	2010-08-08	14345	\N	39511	\N
47515	GENERIC_DAY	2	10	\N	2010-08-26	26463	\N	39511	\N
10023	GENERIC_DAY	2	0	\N	2010-06-13	1121	\N	2679	\N
10077	GENERIC_DAY	2	6	\N	2010-05-10	1119	\N	2679	\N
10097	GENERIC_DAY	2	5	\N	2010-05-07	1123	\N	2679	\N
10036	GENERIC_DAY	2	5	\N	2010-05-06	1123	\N	2679	\N
10064	GENERIC_DAY	2	5	\N	2010-05-11	1121	\N	2679	\N
10110	GENERIC_DAY	2	1	\N	2010-06-14	1119	\N	2679	\N
10079	GENERIC_DAY	2	0	\N	2010-06-06	1123	\N	2679	\N
10105	GENERIC_DAY	2	5	\N	2010-06-08	1123	\N	2679	\N
10095	GENERIC_DAY	2	5	\N	2010-05-10	1123	\N	2679	\N
10099	GENERIC_DAY	2	5	\N	2010-05-31	1121	\N	2679	\N
10065	GENERIC_DAY	2	6	\N	2010-06-09	1119	\N	2679	\N
10032	GENERIC_DAY	2	5	\N	2010-06-04	1123	\N	2679	\N
10107	GENERIC_DAY	2	0	\N	2010-06-06	1119	\N	2679	\N
10010	GENERIC_DAY	2	5	\N	2010-05-18	1121	\N	2679	\N
10082	GENERIC_DAY	2	0	\N	2010-05-16	1123	\N	2679	\N
10033	GENERIC_DAY	2	5	\N	2010-06-10	1121	\N	2679	\N
10086	GENERIC_DAY	2	0	\N	2010-06-05	1119	\N	2679	\N
10021	GENERIC_DAY	2	5	\N	2010-05-21	1123	\N	2679	\N
10080	GENERIC_DAY	2	6	\N	2010-05-14	1119	\N	2679	\N
10070	GENERIC_DAY	2	6	\N	2010-06-02	1119	\N	2679	\N
10074	GENERIC_DAY	2	0	\N	2010-05-08	1119	\N	2679	\N
10104	GENERIC_DAY	2	0	\N	2010-05-22	1123	\N	2679	\N
10059	GENERIC_DAY	2	6	\N	2010-05-06	1119	\N	2679	\N
10020	GENERIC_DAY	2	0	\N	2010-05-30	1121	\N	2679	\N
10108	GENERIC_DAY	2	0	\N	2010-05-23	1123	\N	2679	\N
10037	GENERIC_DAY	2	5	\N	2010-05-12	1121	\N	2679	\N
10013	GENERIC_DAY	2	5	\N	2010-06-11	1121	\N	2679	\N
10083	GENERIC_DAY	2	5	\N	2010-05-26	1123	\N	2679	\N
10048	GENERIC_DAY	2	5	\N	2010-05-11	1123	\N	2679	\N
10112	GENERIC_DAY	2	0	\N	2010-06-06	1121	\N	2679	\N
10038	GENERIC_DAY	2	0	\N	2010-05-09	1123	\N	2679	\N
10094	GENERIC_DAY	2	0	\N	2010-06-13	1119	\N	2679	\N
10061	GENERIC_DAY	2	5	\N	2010-05-10	1121	\N	2679	\N
10098	GENERIC_DAY	2	0	\N	2010-05-15	1123	\N	2679	\N
10014	GENERIC_DAY	2	0	\N	2010-05-30	1123	\N	2679	\N
10087	GENERIC_DAY	2	0	\N	2010-05-22	1119	\N	2679	\N
10009	GENERIC_DAY	2	0	\N	2010-05-08	1123	\N	2679	\N
10063	GENERIC_DAY	2	5	\N	2010-06-03	1123	\N	2679	\N
10071	GENERIC_DAY	2	5	\N	2010-05-05	1121	\N	2679	\N
10047	GENERIC_DAY	2	1	\N	2010-06-14	1121	\N	2679	\N
10041	GENERIC_DAY	2	5	\N	2010-05-27	1121	\N	2679	\N
10069	GENERIC_DAY	2	0	\N	2010-05-09	1119	\N	2679	\N
10018	GENERIC_DAY	2	5	\N	2010-06-09	1123	\N	2679	\N
10113	GENERIC_DAY	2	5	\N	2010-05-24	1121	\N	2679	\N
10034	GENERIC_DAY	2	6	\N	2010-06-07	1119	\N	2679	\N
10100	GENERIC_DAY	2	5	\N	2010-05-05	1123	\N	2679	\N
10092	GENERIC_DAY	2	0	\N	2010-05-29	1119	\N	2679	\N
10073	GENERIC_DAY	2	5	\N	2010-05-13	1123	\N	2679	\N
10084	GENERIC_DAY	2	6	\N	2010-05-31	1119	\N	2679	\N
10076	GENERIC_DAY	2	0	\N	2010-05-16	1119	\N	2679	\N
10024	GENERIC_DAY	2	5	\N	2010-05-28	1121	\N	2679	\N
10043	GENERIC_DAY	2	6	\N	2010-05-13	1119	\N	2679	\N
10012	GENERIC_DAY	2	0	\N	2010-05-15	1119	\N	2679	\N
10058	GENERIC_DAY	2	5	\N	2010-06-03	1121	\N	2679	\N
10093	GENERIC_DAY	2	5	\N	2010-06-01	1123	\N	2679	\N
10016	GENERIC_DAY	2	0	\N	2010-05-29	1121	\N	2679	\N
10055	GENERIC_DAY	2	5	\N	2010-05-19	1121	\N	2679	\N
10115	GENERIC_DAY	2	5	\N	2010-06-07	1121	\N	2679	\N
10111	GENERIC_DAY	2	5	\N	2010-05-28	1123	\N	2679	\N
10057	GENERIC_DAY	2	5	\N	2010-06-11	1123	\N	2679	\N
10089	GENERIC_DAY	2	6	\N	2010-05-24	1119	\N	2679	\N
10054	GENERIC_DAY	2	6	\N	2010-06-11	1119	\N	2679	\N
10091	GENERIC_DAY	2	0	\N	2010-05-08	1121	\N	2679	\N
10044	GENERIC_DAY	2	5	\N	2010-06-01	1121	\N	2679	\N
10040	GENERIC_DAY	2	0	\N	2010-06-12	1123	\N	2679	\N
10049	GENERIC_DAY	2	6	\N	2010-06-08	1119	\N	2679	\N
10039	GENERIC_DAY	2	0	\N	2010-05-23	1121	\N	2679	\N
10026	GENERIC_DAY	2	6	\N	2010-06-04	1119	\N	2679	\N
10101	GENERIC_DAY	2	0	\N	2010-05-16	1121	\N	2679	\N
10035	GENERIC_DAY	2	5	\N	2010-05-26	1121	\N	2679	\N
10078	GENERIC_DAY	2	5	\N	2010-05-27	1123	\N	2679	\N
10011	GENERIC_DAY	2	6	\N	2010-05-07	1119	\N	2679	\N
10109	GENERIC_DAY	2	5	\N	2010-06-07	1123	\N	2679	\N
10052	GENERIC_DAY	2	6	\N	2010-05-18	1119	\N	2679	\N
10106	GENERIC_DAY	2	5	\N	2010-06-09	1121	\N	2679	\N
10022	GENERIC_DAY	2	5	\N	2010-05-06	1121	\N	2679	\N
10114	GENERIC_DAY	2	6	\N	2010-06-03	1119	\N	2679	\N
10075	GENERIC_DAY	2	5	\N	2010-05-25	1123	\N	2679	\N
10060	GENERIC_DAY	2	0	\N	2010-06-14	1123	\N	2679	\N
10102	GENERIC_DAY	2	5	\N	2010-06-10	1123	\N	2679	\N
10045	GENERIC_DAY	2	6	\N	2010-05-26	1119	\N	2679	\N
10103	GENERIC_DAY	2	5	\N	2010-05-07	1121	\N	2679	\N
10031	GENERIC_DAY	2	6	\N	2010-05-28	1119	\N	2679	\N
10056	GENERIC_DAY	2	0	\N	2010-05-30	1119	\N	2679	\N
10117	GENERIC_DAY	2	6	\N	2010-05-27	1119	\N	2679	\N
10029	GENERIC_DAY	2	6	\N	2010-05-12	1119	\N	2679	\N
10118	GENERIC_DAY	2	6	\N	2010-05-21	1119	\N	2679	\N
10019	GENERIC_DAY	2	5	\N	2010-05-12	1123	\N	2679	\N
10046	GENERIC_DAY	2	5	\N	2010-05-31	1123	\N	2679	\N
10068	GENERIC_DAY	2	6	\N	2010-05-25	1119	\N	2679	\N
10131	GENERIC_DAY	2	3	\N	2010-05-20	1121	\N	2680	\N
10247	GENERIC_DAY	2	3	\N	2010-05-11	1123	\N	2680	\N
10120	GENERIC_DAY	2	0	\N	2010-06-06	1119	\N	2680	\N
10267	GENERIC_DAY	2	2	\N	2010-05-06	1119	\N	2680	\N
10214	GENERIC_DAY	2	3	\N	2010-06-17	1121	\N	2680	\N
10124	GENERIC_DAY	2	3	\N	2010-05-19	1123	\N	2680	\N
10229	GENERIC_DAY	2	2	\N	2010-06-16	1123	\N	2680	\N
10145	GENERIC_DAY	2	0	\N	2010-05-23	1123	\N	2680	\N
10208	GENERIC_DAY	2	3	\N	2010-05-12	1121	\N	2680	\N
10135	GENERIC_DAY	2	3	\N	2010-06-11	1123	\N	2680	\N
10178	GENERIC_DAY	2	2	\N	2010-06-14	1121	\N	2680	\N
10253	GENERIC_DAY	2	3	\N	2010-06-24	1119	\N	2680	\N
10119	GENERIC_DAY	2	0	\N	2010-05-08	1119	\N	2680	\N
10245	GENERIC_DAY	2	0	\N	2010-05-09	1119	\N	2680	\N
10202	GENERIC_DAY	2	3	\N	2010-05-31	1121	\N	2680	\N
10180	GENERIC_DAY	2	0	\N	2010-05-15	1119	\N	2680	\N
10238	GENERIC_DAY	2	3	\N	2010-05-24	1123	\N	2680	\N
10167	GENERIC_DAY	2	3	\N	2010-06-11	1121	\N	2680	\N
10168	GENERIC_DAY	2	2	\N	2010-06-18	1123	\N	2680	\N
10134	GENERIC_DAY	2	3	\N	2010-06-23	1121	\N	2680	\N
10143	GENERIC_DAY	2	1	\N	2010-06-25	1121	\N	2680	\N
10235	GENERIC_DAY	2	2	\N	2010-05-27	1119	\N	2680	\N
10270	GENERIC_DAY	2	0	\N	2010-05-16	1121	\N	2680	\N
10244	GENERIC_DAY	2	2	\N	2010-05-20	1119	\N	2680	\N
10183	GENERIC_DAY	2	2	\N	2010-05-24	1119	\N	2680	\N
10242	GENERIC_DAY	2	3	\N	2010-05-14	1123	\N	2680	\N
10162	GENERIC_DAY	2	0	\N	2010-06-20	1121	\N	2680	\N
10200	GENERIC_DAY	2	3	\N	2010-06-16	1121	\N	2680	\N
10220	GENERIC_DAY	2	3	\N	2010-05-18	1123	\N	2680	\N
10155	GENERIC_DAY	2	3	\N	2010-06-07	1123	\N	2680	\N
10237	GENERIC_DAY	2	0	\N	2010-06-12	1123	\N	2680	\N
10201	GENERIC_DAY	2	2	\N	2010-06-11	1119	\N	2680	\N
10272	GENERIC_DAY	2	3	\N	2010-05-21	1121	\N	2680	\N
10191	GENERIC_DAY	2	0	\N	2010-05-22	1123	\N	2680	\N
10236	GENERIC_DAY	2	0	\N	2010-05-22	1121	\N	2680	\N
10151	GENERIC_DAY	2	3	\N	2010-06-02	1121	\N	2680	\N
10182	GENERIC_DAY	2	0	\N	2010-06-06	1123	\N	2680	\N
10141	GENERIC_DAY	2	2	\N	2010-06-17	1123	\N	2680	\N
10252	GENERIC_DAY	2	2	\N	2010-05-19	1119	\N	2680	\N
10239	GENERIC_DAY	2	0	\N	2010-05-09	1123	\N	2680	\N
10161	GENERIC_DAY	2	2	\N	2010-06-03	1119	\N	2680	\N
10144	GENERIC_DAY	2	3	\N	2010-06-16	1119	\N	2680	\N
10153	GENERIC_DAY	2	0	\N	2010-05-23	1121	\N	2680	\N
10126	GENERIC_DAY	2	3	\N	2010-06-14	1123	\N	2680	\N
10215	GENERIC_DAY	2	0	\N	2010-06-13	1121	\N	2680	\N
10173	GENERIC_DAY	2	3	\N	2010-05-31	1123	\N	2680	\N
10231	GENERIC_DAY	2	0	\N	2010-06-19	1121	\N	2680	\N
10209	GENERIC_DAY	2	1	\N	2010-06-25	1123	\N	2680	\N
10146	GENERIC_DAY	2	0	\N	2010-05-29	1123	\N	2680	\N
10132	GENERIC_DAY	2	0	\N	2010-05-30	1123	\N	2680	\N
10251	GENERIC_DAY	2	0	\N	2010-05-08	1123	\N	2680	\N
10175	GENERIC_DAY	2	3	\N	2010-05-25	1121	\N	2680	\N
10152	GENERIC_DAY	2	3	\N	2010-05-27	1121	\N	2680	\N
10258	GENERIC_DAY	2	3	\N	2010-06-15	1119	\N	2680	\N
10138	GENERIC_DAY	2	2	\N	2010-06-15	1123	\N	2680	\N
10212	GENERIC_DAY	2	3	\N	2010-06-15	1121	\N	2680	\N
10249	GENERIC_DAY	2	0	\N	2010-05-22	1119	\N	2680	\N
10262	GENERIC_DAY	2	3	\N	2010-05-28	1121	\N	2680	\N
10187	GENERIC_DAY	2	0	\N	2010-06-19	1123	\N	2680	\N
10255	GENERIC_DAY	2	0	\N	2010-05-09	1121	\N	2680	\N
10150	GENERIC_DAY	2	0	\N	2010-05-16	1123	\N	2680	\N
10172	GENERIC_DAY	2	2	\N	2010-05-05	1119	\N	2680	\N
10217	GENERIC_DAY	2	3	\N	2010-05-19	1121	\N	2680	\N
10198	GENERIC_DAY	2	0	\N	2010-05-29	1121	\N	2680	\N
10165	GENERIC_DAY	2	3	\N	2010-05-10	1123	\N	2680	\N
10233	GENERIC_DAY	2	3	\N	2010-05-11	1121	\N	2680	\N
10179	GENERIC_DAY	2	0	\N	2010-06-05	1123	\N	2680	\N
10199	GENERIC_DAY	2	3	\N	2010-06-09	1123	\N	2680	\N
10224	GENERIC_DAY	2	3	\N	2010-06-07	1121	\N	2680	\N
10154	GENERIC_DAY	2	2	\N	2010-06-23	1123	\N	2680	\N
10204	GENERIC_DAY	2	0	\N	2010-05-23	1119	\N	2680	\N
10174	GENERIC_DAY	2	0	\N	2010-06-20	1119	\N	2680	\N
10248	GENERIC_DAY	2	3	\N	2010-06-23	1119	\N	2680	\N
10185	GENERIC_DAY	2	2	\N	2010-05-07	1119	\N	2680	\N
10221	GENERIC_DAY	2	3	\N	2010-06-01	1121	\N	2680	\N
10125	GENERIC_DAY	2	3	\N	2010-05-24	1121	\N	2680	\N
10228	GENERIC_DAY	2	2	\N	2010-06-24	1123	\N	2680	\N
10157	GENERIC_DAY	2	0	\N	2010-06-06	1121	\N	2680	\N
10240	GENERIC_DAY	2	2	\N	2010-05-25	1119	\N	2680	\N
10184	GENERIC_DAY	2	3	\N	2010-05-25	1123	\N	2680	\N
10210	GENERIC_DAY	2	2	\N	2010-05-21	1119	\N	2680	\N
10128	GENERIC_DAY	2	3	\N	2010-05-05	1123	\N	2680	\N
10189	GENERIC_DAY	2	3	\N	2010-05-18	1121	\N	2680	\N
10129	GENERIC_DAY	2	3	\N	2010-05-10	1121	\N	2680	\N
10176	GENERIC_DAY	2	3	\N	2010-06-22	1121	\N	2680	\N
10188	GENERIC_DAY	2	3	\N	2010-06-03	1121	\N	2680	\N
10223	GENERIC_DAY	2	3	\N	2010-05-14	1121	\N	2680	\N
10261	GENERIC_DAY	2	0	\N	2010-06-05	1119	\N	2680	\N
10123	GENERIC_DAY	2	3	\N	2010-06-14	1119	\N	2680	\N
10269	GENERIC_DAY	2	2	\N	2010-05-18	1119	\N	2680	\N
10166	GENERIC_DAY	2	2	\N	2010-05-13	1119	\N	2680	\N
10160	GENERIC_DAY	2	2	\N	2010-06-01	1119	\N	2680	\N
10186	GENERIC_DAY	2	2	\N	2010-05-31	1119	\N	2680	\N
10142	GENERIC_DAY	2	0	\N	2010-05-16	1119	\N	2680	\N
10246	GENERIC_DAY	2	3	\N	2010-05-13	1123	\N	2680	\N
10254	GENERIC_DAY	2	3	\N	2010-06-01	1123	\N	2680	\N
10170	GENERIC_DAY	2	3	\N	2010-06-22	1119	\N	2680	\N
10196	GENERIC_DAY	2	0	\N	2010-05-30	1119	\N	2680	\N
10121	GENERIC_DAY	2	3	\N	2010-05-28	1123	\N	2680	\N
10260	GENERIC_DAY	2	3	\N	2010-05-12	1123	\N	2680	\N
10192	GENERIC_DAY	2	3	\N	2010-05-26	1123	\N	2680	\N
10158	GENERIC_DAY	2	2	\N	2010-05-28	1119	\N	2680	\N
10203	GENERIC_DAY	2	0	\N	2010-06-20	1123	\N	2680	\N
10147	GENERIC_DAY	2	2	\N	2010-05-14	1119	\N	2680	\N
10181	GENERIC_DAY	2	3	\N	2010-05-06	1123	\N	2680	\N
10159	GENERIC_DAY	2	3	\N	2010-05-27	1123	\N	2680	\N
10137	GENERIC_DAY	2	3	\N	2010-05-07	1121	\N	2680	\N
10177	GENERIC_DAY	2	3	\N	2010-05-06	1121	\N	2680	\N
10171	GENERIC_DAY	2	3	\N	2010-05-13	1121	\N	2680	\N
10264	GENERIC_DAY	2	3	\N	2010-06-09	1121	\N	2680	\N
10136	GENERIC_DAY	2	0	\N	2010-05-08	1121	\N	2680	\N
10265	GENERIC_DAY	2	2	\N	2010-05-10	1119	\N	2680	\N
10211	GENERIC_DAY	2	2	\N	2010-05-12	1119	\N	2680	\N
10243	GENERIC_DAY	2	2	\N	2010-06-22	1123	\N	2680	\N
10230	GENERIC_DAY	2	3	\N	2010-06-24	1121	\N	2680	\N
10218	GENERIC_DAY	2	0	\N	2010-05-15	1121	\N	2680	\N
10259	GENERIC_DAY	2	0	\N	2010-05-15	1123	\N	2680	\N
10139	GENERIC_DAY	2	0	\N	2010-06-12	1121	\N	2680	\N
10234	GENERIC_DAY	2	0	\N	2010-05-30	1121	\N	2680	\N
10241	GENERIC_DAY	2	3	\N	2010-06-08	1123	\N	2680	\N
10193	GENERIC_DAY	2	3	\N	2010-06-21	1121	\N	2680	\N
10156	GENERIC_DAY	2	3	\N	2010-05-26	1121	\N	2680	\N
10195	GENERIC_DAY	2	2	\N	2010-06-07	1119	\N	2680	\N
10271	GENERIC_DAY	2	0	\N	2010-06-12	1119	\N	2680	\N
10205	GENERIC_DAY	2	2	\N	2010-06-21	1123	\N	2680	\N
10127	GENERIC_DAY	2	3	\N	2010-06-08	1121	\N	2680	\N
10122	GENERIC_DAY	2	0	\N	2010-06-05	1121	\N	2680	\N
10226	GENERIC_DAY	2	3	\N	2010-05-05	1121	\N	2680	\N
10232	GENERIC_DAY	2	3	\N	2010-06-17	1119	\N	2680	\N
10169	GENERIC_DAY	2	0	\N	2010-05-29	1119	\N	2680	\N
10266	GENERIC_DAY	2	2	\N	2010-06-10	1119	\N	2680	\N
10257	GENERIC_DAY	2	3	\N	2010-06-18	1119	\N	2680	\N
10164	GENERIC_DAY	2	3	\N	2010-05-07	1123	\N	2680	\N
10133	GENERIC_DAY	2	2	\N	2010-05-11	1119	\N	2680	\N
10225	GENERIC_DAY	2	2	\N	2010-05-26	1119	\N	2680	\N
10219	GENERIC_DAY	2	3	\N	2010-06-04	1123	\N	2680	\N
10163	GENERIC_DAY	2	0	\N	2010-06-13	1119	\N	2680	\N
10149	GENERIC_DAY	2	3	\N	2010-05-21	1123	\N	2680	\N
10194	GENERIC_DAY	2	2	\N	2010-06-08	1119	\N	2680	\N
10268	GENERIC_DAY	2	3	\N	2010-06-10	1123	\N	2680	\N
10256	GENERIC_DAY	2	2	\N	2010-06-04	1119	\N	2680	\N
10206	GENERIC_DAY	2	3	\N	2010-06-18	1121	\N	2680	\N
10227	GENERIC_DAY	2	8	\N	2010-05-04	1123	\N	2680	\N
10216	GENERIC_DAY	2	3	\N	2010-06-21	1119	\N	2680	\N
10190	GENERIC_DAY	2	0	\N	2010-06-13	1123	\N	2680	\N
10213	GENERIC_DAY	2	2	\N	2010-06-25	1119	\N	2680	\N
10140	GENERIC_DAY	2	3	\N	2010-06-03	1123	\N	2680	\N
10197	GENERIC_DAY	2	3	\N	2010-06-04	1121	\N	2680	\N
10207	GENERIC_DAY	2	0	\N	2010-06-19	1119	\N	2680	\N
10263	GENERIC_DAY	2	2	\N	2010-06-09	1119	\N	2680	\N
10222	GENERIC_DAY	2	2	\N	2010-06-02	1119	\N	2680	\N
10148	GENERIC_DAY	2	3	\N	2010-06-02	1123	\N	2680	\N
10130	GENERIC_DAY	2	3	\N	2010-05-20	1123	\N	2680	\N
10250	GENERIC_DAY	2	3	\N	2010-06-10	1121	\N	2680	\N
11831	GENERIC_DAY	1	3	\N	2010-07-16	1119	\N	2681	\N
11832	GENERIC_DAY	1	3	\N	2010-07-27	1119	\N	2681	\N
11833	GENERIC_DAY	1	0	\N	2010-07-04	1119	\N	2681	\N
11834	GENERIC_DAY	1	3	\N	2010-07-20	1119	\N	2681	\N
11835	GENERIC_DAY	1	2	\N	2010-07-22	1123	\N	2681	\N
11836	GENERIC_DAY	1	3	\N	2010-06-25	1123	\N	2681	\N
11837	GENERIC_DAY	1	3	\N	2010-06-18	1123	\N	2681	\N
11838	GENERIC_DAY	1	2	\N	2010-07-07	1123	\N	2681	\N
11839	GENERIC_DAY	1	0	\N	2010-06-27	1119	\N	2681	\N
11840	GENERIC_DAY	1	0	\N	2010-07-10	1119	\N	2681	\N
11841	GENERIC_DAY	1	3	\N	2010-07-14	1121	\N	2681	\N
11842	GENERIC_DAY	1	0	\N	2010-07-17	1121	\N	2681	\N
11843	GENERIC_DAY	1	0	\N	2010-06-20	1119	\N	2681	\N
47403	GENERIC_DAY	2	11	\N	2010-06-29	14343	\N	39511	\N
47497	GENERIC_DAY	2	10	\N	2010-07-28	26463	\N	39511	\N
27841	GENERIC_DAY	3	0	\N	2010-06-20	1134	\N	27675	\N
27859	GENERIC_DAY	3	0	\N	2010-06-12	1134	\N	27675	\N
27865	GENERIC_DAY	3	3	\N	2010-06-16	1132	\N	27675	\N
27848	GENERIC_DAY	3	2	\N	2010-06-23	1136	\N	27675	\N
27879	GENERIC_DAY	3	0	\N	2010-06-20	1136	\N	27675	\N
27842	GENERIC_DAY	3	3	\N	2010-06-21	1134	\N	27675	\N
27869	GENERIC_DAY	3	3	\N	2010-06-24	1132	\N	27675	\N
27846	GENERIC_DAY	3	2	\N	2010-06-15	1136	\N	27675	\N
27873	GENERIC_DAY	3	3	\N	2010-06-15	1132	\N	27675	\N
27878	GENERIC_DAY	3	3	\N	2010-06-16	1134	\N	27675	\N
27849	GENERIC_DAY	3	2	\N	2010-06-24	1136	\N	27675	\N
27886	GENERIC_DAY	3	3	\N	2010-06-17	1134	\N	27675	\N
27864	GENERIC_DAY	3	0	\N	2010-06-13	1132	\N	27675	\N
27887	GENERIC_DAY	3	0	\N	2010-06-27	1136	\N	27675	\N
27863	GENERIC_DAY	3	0	\N	2010-06-26	1134	\N	27675	\N
27860	GENERIC_DAY	3	1	\N	2010-06-28	1134	\N	27675	\N
27881	GENERIC_DAY	3	3	\N	2010-06-18	1132	\N	27675	\N
27854	GENERIC_DAY	3	3	\N	2010-06-24	1134	\N	27675	\N
27883	GENERIC_DAY	3	3	\N	2010-06-11	1132	\N	27675	\N
27844	GENERIC_DAY	3	0	\N	2010-06-19	1134	\N	27675	\N
27843	GENERIC_DAY	3	3	\N	2010-06-11	1134	\N	27675	\N
27870	GENERIC_DAY	3	0	\N	2010-06-12	1132	\N	27675	\N
27888	GENERIC_DAY	3	3	\N	2010-06-23	1132	\N	27675	\N
47564	GENERIC_DAY	2	0	\N	2010-09-05	26463	\N	39511	\N
47449	GENERIC_DAY	2	11	\N	2010-08-17	14343	\N	39511	\N
47336	GENERIC_DAY	2	11	\N	2010-09-13	14345	\N	39511	\N
47435	GENERIC_DAY	2	11	\N	2010-09-08	14343	\N	39511	\N
47326	GENERIC_DAY	2	11	\N	2010-09-06	14343	\N	39511	\N
47534	GENERIC_DAY	2	10	\N	2010-07-14	26463	\N	39511	\N
47426	GENERIC_DAY	2	11	\N	2010-07-15	14343	\N	39511	\N
47358	GENERIC_DAY	2	0	\N	2010-08-14	14345	\N	39511	\N
47530	GENERIC_DAY	2	10	\N	2010-09-08	26463	\N	39511	\N
47345	GENERIC_DAY	2	11	\N	2010-08-04	14345	\N	39511	\N
47421	GENERIC_DAY	2	0	\N	2010-07-11	14343	\N	39511	\N
47422	GENERIC_DAY	2	11	\N	2010-07-20	14343	\N	39511	\N
47512	GENERIC_DAY	2	11	\N	2010-06-30	14343	\N	39511	\N
47436	GENERIC_DAY	2	10	\N	2010-09-02	26463	\N	39511	\N
47569	GENERIC_DAY	2	10	\N	2010-08-13	26463	\N	39511	\N
47389	GENERIC_DAY	2	11	\N	2010-08-11	14345	\N	39511	\N
47338	GENERIC_DAY	2	10	\N	2010-07-02	26463	\N	39511	\N
47317	GENERIC_DAY	2	10	\N	2010-09-07	26463	\N	39511	\N
47454	GENERIC_DAY	2	11	\N	2010-08-05	14343	\N	39511	\N
47457	GENERIC_DAY	2	0	\N	2010-08-29	14345	\N	39511	\N
47321	GENERIC_DAY	2	10	\N	2010-08-16	26463	\N	39511	\N
47476	GENERIC_DAY	2	0	\N	2010-08-21	26463	\N	39511	\N
47461	GENERIC_DAY	2	0	\N	2010-08-07	14345	\N	39511	\N
47490	GENERIC_DAY	2	0	\N	2010-07-25	14345	\N	39511	\N
47327	GENERIC_DAY	2	11	\N	2010-09-06	14345	\N	39511	\N
47544	GENERIC_DAY	2	11	\N	2010-08-31	14343	\N	39511	\N
47371	GENERIC_DAY	2	11	\N	2010-06-29	14345	\N	39511	\N
47333	GENERIC_DAY	2	0	\N	2010-08-15	26463	\N	39511	\N
47489	GENERIC_DAY	2	11	\N	2010-07-08	14343	\N	39511	\N
47525	GENERIC_DAY	2	11	\N	2010-07-19	14345	\N	39511	\N
47337	GENERIC_DAY	2	0	\N	2010-08-08	14343	\N	39511	\N
47349	GENERIC_DAY	2	11	\N	2010-09-17	14345	\N	39511	\N
47540	GENERIC_DAY	2	10	\N	2010-07-29	26463	\N	39511	\N
47563	GENERIC_DAY	2	11	\N	2010-07-26	14345	\N	39511	\N
47342	GENERIC_DAY	2	0	\N	2010-08-14	26463	\N	39511	\N
47503	GENERIC_DAY	2	11	\N	2010-09-16	14343	\N	39511	\N
47334	GENERIC_DAY	2	11	\N	2010-07-15	14345	\N	39511	\N
47249	GENERIC_DAY	2	16	\N	2010-08-19	38987	\N	39510	\N
47309	GENERIC_DAY	2	0	\N	2010-08-21	38987	\N	39510	\N
47305	GENERIC_DAY	2	16	\N	2010-07-12	38987	\N	39510	\N
47235	GENERIC_DAY	2	0	\N	2010-08-28	38987	\N	39510	\N
27836	GENERIC_DAY	3	3	\N	2010-06-14	1132	\N	27675	\N
27851	GENERIC_DAY	3	2	\N	2010-06-28	1132	\N	27675	\N
27867	GENERIC_DAY	3	2	\N	2010-06-16	1136	\N	27675	\N
27847	GENERIC_DAY	3	2	\N	2010-06-17	1136	\N	27675	\N
27874	GENERIC_DAY	3	0	\N	2010-06-27	1132	\N	27675	\N
27852	GENERIC_DAY	3	0	\N	2010-06-12	1136	\N	27675	\N
27837	GENERIC_DAY	3	3	\N	2010-06-17	1132	\N	27675	\N
27862	GENERIC_DAY	3	2	\N	2010-06-22	1136	\N	27675	\N
27838	GENERIC_DAY	3	3	\N	2010-06-10	1134	\N	27675	\N
27835	GENERIC_DAY	3	0	\N	2010-06-13	1134	\N	27675	\N
27884	GENERIC_DAY	3	3	\N	2010-06-22	1134	\N	27675	\N
27839	GENERIC_DAY	3	0	\N	2010-06-26	1132	\N	27675	\N
27877	GENERIC_DAY	3	3	\N	2010-06-25	1134	\N	27675	\N
27840	GENERIC_DAY	3	2	\N	2010-06-14	1136	\N	27675	\N
27876	GENERIC_DAY	3	3	\N	2010-06-21	1132	\N	27675	\N
27872	GENERIC_DAY	3	3	\N	2010-06-10	1132	\N	27675	\N
27861	GENERIC_DAY	3	0	\N	2010-06-20	1132	\N	27675	\N
27871	GENERIC_DAY	3	2	\N	2010-06-18	1136	\N	27675	\N
11844	GENERIC_DAY	1	3	\N	2010-07-08	1119	\N	2681	\N
11845	GENERIC_DAY	1	2	\N	2010-07-27	1123	\N	2681	\N
11846	GENERIC_DAY	1	3	\N	2010-06-24	1119	\N	2681	\N
11847	GENERIC_DAY	1	3	\N	2010-06-15	1123	\N	2681	\N
11848	GENERIC_DAY	1	0	\N	2010-07-25	1121	\N	2681	\N
11849	GENERIC_DAY	1	0	\N	2010-07-24	1123	\N	2681	\N
11850	GENERIC_DAY	1	3	\N	2010-07-12	1121	\N	2681	\N
11851	GENERIC_DAY	1	0	\N	2010-07-17	1123	\N	2681	\N
11852	GENERIC_DAY	1	2	\N	2010-07-23	1123	\N	2681	\N
11853	GENERIC_DAY	1	3	\N	2010-06-28	1121	\N	2681	\N
11854	GENERIC_DAY	1	0	\N	2010-07-18	1123	\N	2681	\N
11855	GENERIC_DAY	1	3	\N	2010-07-23	1121	\N	2681	\N
11856	GENERIC_DAY	1	3	\N	2010-07-30	1119	\N	2681	\N
11857	GENERIC_DAY	1	3	\N	2010-06-23	1119	\N	2681	\N
11858	GENERIC_DAY	1	3	\N	2010-06-29	1121	\N	2681	\N
11859	GENERIC_DAY	1	3	\N	2010-07-08	1121	\N	2681	\N
11860	GENERIC_DAY	1	3	\N	2010-08-03	1119	\N	2681	\N
11861	GENERIC_DAY	1	3	\N	2010-07-26	1119	\N	2681	\N
11862	GENERIC_DAY	1	3	\N	2010-07-19	1121	\N	2681	\N
11863	GENERIC_DAY	1	3	\N	2010-07-01	1119	\N	2681	\N
11864	GENERIC_DAY	1	2	\N	2010-07-20	1123	\N	2681	\N
11865	GENERIC_DAY	1	0	\N	2010-06-19	1123	\N	2681	\N
14291	GENERIC_DAY	1	3	\N	2010-05-06	1128	\N	14143	\N
14280	GENERIC_DAY	1	0	\N	2010-05-09	1128	\N	14143	\N
14294	GENERIC_DAY	1	3	\N	2010-05-07	1126	\N	14143	\N
14286	GENERIC_DAY	1	3	\N	2010-05-06	1126	\N	14143	\N
14277	GENERIC_DAY	1	0	\N	2010-05-09	1130	\N	14143	\N
14279	GENERIC_DAY	1	0	\N	2010-05-09	1126	\N	14143	\N
14287	GENERIC_DAY	1	2	\N	2010-05-10	1130	\N	14143	\N
14282	GENERIC_DAY	1	2	\N	2010-05-11	1128	\N	14143	\N
14281	GENERIC_DAY	1	2	\N	2010-05-06	1130	\N	14143	\N
14292	GENERIC_DAY	1	3	\N	2010-05-07	1128	\N	14143	\N
14290	GENERIC_DAY	1	0	\N	2010-05-08	1130	\N	14143	\N
14284	GENERIC_DAY	1	2	\N	2010-05-11	1130	\N	14143	\N
14285	GENERIC_DAY	1	2	\N	2010-05-07	1130	\N	14143	\N
14278	GENERIC_DAY	1	2	\N	2010-05-11	1126	\N	14143	\N
14288	GENERIC_DAY	1	0	\N	2010-05-08	1126	\N	14143	\N
14289	GENERIC_DAY	1	3	\N	2010-05-10	1126	\N	14143	\N
14293	GENERIC_DAY	1	0	\N	2010-05-08	1128	\N	14143	\N
14283	GENERIC_DAY	1	3	\N	2010-05-10	1128	\N	14143	\N
14275	GENERIC_DAY	1	1	\N	2010-05-14	1130	\N	14142	\N
14272	GENERIC_DAY	1	3	\N	2010-05-13	1128	\N	14142	\N
14276	GENERIC_DAY	1	3	\N	2010-05-13	1126	\N	14142	\N
14270	GENERIC_DAY	1	1	\N	2010-05-14	1128	\N	14142	\N
14274	GENERIC_DAY	1	2	\N	2010-05-12	1130	\N	14142	\N
14273	GENERIC_DAY	1	3	\N	2010-05-12	1126	\N	14142	\N
14271	GENERIC_DAY	1	2	\N	2010-05-14	1126	\N	14142	\N
14268	GENERIC_DAY	1	2	\N	2010-05-13	1130	\N	14142	\N
14269	GENERIC_DAY	1	3	\N	2010-05-12	1128	\N	14142	\N
14312	GENERIC_DAY	0	3	\N	2010-05-20	1128	\N	14146	\N
14313	GENERIC_DAY	0	3	\N	2010-05-19	1126	\N	14146	\N
14314	GENERIC_DAY	0	3	\N	2010-05-19	1128	\N	14146	\N
14315	GENERIC_DAY	0	1	\N	2010-05-21	1130	\N	14146	\N
14316	GENERIC_DAY	0	2	\N	2010-05-20	1130	\N	14146	\N
14317	GENERIC_DAY	0	3	\N	2010-05-20	1126	\N	14146	\N
14318	GENERIC_DAY	0	2	\N	2010-05-21	1126	\N	14146	\N
14319	GENERIC_DAY	0	1	\N	2010-05-21	1128	\N	14146	\N
14320	GENERIC_DAY	0	2	\N	2010-05-19	1130	\N	14146	\N
14321	GENERIC_DAY	0	0	\N	2010-05-15	14345	\N	14147	\N
14322	GENERIC_DAY	0	4	\N	2010-05-17	14345	\N	14147	\N
14323	GENERIC_DAY	0	4	\N	2010-05-17	14343	\N	14147	\N
14324	GENERIC_DAY	0	0	\N	2010-05-16	14345	\N	14147	\N
14325	GENERIC_DAY	0	1	\N	2010-05-18	14345	\N	14147	\N
14326	GENERIC_DAY	0	0	\N	2010-05-15	14343	\N	14147	\N
14327	GENERIC_DAY	0	1	\N	2010-05-18	14343	\N	14147	\N
14328	GENERIC_DAY	0	0	\N	2010-05-16	14343	\N	14147	\N
47298	GENERIC_DAY	2	16	\N	2010-07-19	38987	\N	39510	\N
47280	GENERIC_DAY	2	16	\N	2010-09-15	38987	\N	39510	\N
47234	GENERIC_DAY	2	16	\N	2010-07-27	38987	\N	39510	\N
47275	GENERIC_DAY	2	16	\N	2010-08-30	38987	\N	39510	\N
47303	GENERIC_DAY	2	0	\N	2010-07-25	38987	\N	39510	\N
47306	GENERIC_DAY	2	16	\N	2010-09-08	38987	\N	39510	\N
47236	GENERIC_DAY	2	16	\N	2010-08-20	38987	\N	39510	\N
47247	GENERIC_DAY	2	16	\N	2010-08-18	38987	\N	39510	\N
47263	GENERIC_DAY	2	16	\N	2010-09-22	38987	\N	39510	\N
47293	GENERIC_DAY	2	16	\N	2010-08-12	38987	\N	39510	\N
47255	GENERIC_DAY	2	0	\N	2010-09-05	38987	\N	39510	\N
47266	GENERIC_DAY	2	0	\N	2010-09-19	38987	\N	39510	\N
47273	GENERIC_DAY	2	16	\N	2010-07-20	38987	\N	39510	\N
47304	GENERIC_DAY	2	16	\N	2010-08-23	38987	\N	39510	\N
47289	GENERIC_DAY	2	16	\N	2010-07-21	38987	\N	39510	\N
47242	GENERIC_DAY	2	16	\N	2010-07-13	38987	\N	39510	\N
47308	GENERIC_DAY	2	16	\N	2010-07-01	38987	\N	39510	\N
47296	GENERIC_DAY	2	0	\N	2010-07-24	38987	\N	39510	\N
47288	GENERIC_DAY	2	16	\N	2010-09-13	38987	\N	39510	\N
47251	GENERIC_DAY	2	0	\N	2010-08-15	38987	\N	39510	\N
47310	GENERIC_DAY	2	16	\N	2010-08-24	38987	\N	39510	\N
47279	GENERIC_DAY	2	16	\N	2010-09-02	38987	\N	39510	\N
47240	GENERIC_DAY	2	16	\N	2010-08-25	38987	\N	39510	\N
47243	GENERIC_DAY	2	0	\N	2010-08-07	38987	\N	39510	\N
47250	GENERIC_DAY	2	16	\N	2010-08-27	38987	\N	39510	\N
47282	GENERIC_DAY	2	16	\N	2010-08-05	38987	\N	39510	\N
47278	GENERIC_DAY	2	0	\N	2010-09-18	38987	\N	39510	\N
47252	GENERIC_DAY	2	16	\N	2010-07-22	38987	\N	39510	\N
47267	GENERIC_DAY	2	0	\N	2010-07-18	38987	\N	39510	\N
47230	GENERIC_DAY	2	16	\N	2010-07-26	38987	\N	39510	\N
47231	GENERIC_DAY	2	0	\N	2010-07-17	38987	\N	39510	\N
47256	GENERIC_DAY	2	16	\N	2010-08-03	38987	\N	39510	\N
47294	GENERIC_DAY	2	16	\N	2010-09-17	38987	\N	39510	\N
47248	GENERIC_DAY	2	16	\N	2010-09-14	38987	\N	39510	\N
47299	GENERIC_DAY	2	16	\N	2010-09-06	38987	\N	39510	\N
47290	GENERIC_DAY	2	16	\N	2010-07-05	38987	\N	39510	\N
47257	GENERIC_DAY	2	0	\N	2010-09-11	38987	\N	39510	\N
47285	GENERIC_DAY	2	16	\N	2010-08-31	38987	\N	39510	\N
47269	GENERIC_DAY	2	16	\N	2010-09-07	38987	\N	39510	\N
47228	GENERIC_DAY	2	0	\N	2010-08-08	38987	\N	39510	\N
47276	GENERIC_DAY	2	0	\N	2010-07-03	38987	\N	39510	\N
47295	GENERIC_DAY	2	16	\N	2010-07-29	38987	\N	39510	\N
47232	GENERIC_DAY	2	16	\N	2010-09-09	38987	\N	39510	\N
47270	GENERIC_DAY	2	16	\N	2010-09-01	38987	\N	39510	\N
47227	GENERIC_DAY	2	0	\N	2010-08-01	38987	\N	39510	\N
47253	GENERIC_DAY	2	16	\N	2010-08-10	38987	\N	39510	\N
47237	GENERIC_DAY	2	16	\N	2010-07-06	38987	\N	39510	\N
47271	GENERIC_DAY	2	16	\N	2010-06-29	38987	\N	39510	\N
47300	GENERIC_DAY	2	16	\N	2010-07-30	38987	\N	39510	\N
47260	GENERIC_DAY	2	16	\N	2010-07-07	38987	\N	39510	\N
47265	GENERIC_DAY	2	16	\N	2010-08-16	38987	\N	39510	\N
47284	GENERIC_DAY	2	8	\N	2010-09-23	38987	\N	39510	\N
47238	GENERIC_DAY	2	16	\N	2010-07-14	38987	\N	39510	\N
47301	GENERIC_DAY	2	16	\N	2010-08-13	38987	\N	39510	\N
47229	GENERIC_DAY	2	16	\N	2010-09-10	38987	\N	39510	\N
47233	GENERIC_DAY	2	16	\N	2010-08-11	38987	\N	39510	\N
47307	GENERIC_DAY	2	16	\N	2010-08-04	38987	\N	39510	\N
47291	GENERIC_DAY	2	16	\N	2010-07-23	38987	\N	39510	\N
47311	GENERIC_DAY	2	16	\N	2010-08-02	38987	\N	39510	\N
47268	GENERIC_DAY	2	16	\N	2010-07-09	38987	\N	39510	\N
47312	GENERIC_DAY	2	16	\N	2010-08-06	38987	\N	39510	\N
47245	GENERIC_DAY	2	16	\N	2010-08-26	38987	\N	39510	\N
47297	GENERIC_DAY	2	0	\N	2010-09-04	38987	\N	39510	\N
47274	GENERIC_DAY	2	16	\N	2010-09-21	38987	\N	39510	\N
47246	GENERIC_DAY	2	0	\N	2010-07-31	38987	\N	39510	\N
47244	GENERIC_DAY	2	16	\N	2010-08-09	38987	\N	39510	\N
47313	GENERIC_DAY	2	0	\N	2010-08-22	38987	\N	39510	\N
47292	GENERIC_DAY	2	16	\N	2010-06-30	38987	\N	39510	\N
47254	GENERIC_DAY	2	0	\N	2010-08-14	38987	\N	39510	\N
47287	GENERIC_DAY	2	16	\N	2010-07-02	38987	\N	39510	\N
47261	GENERIC_DAY	2	0	\N	2010-08-29	38987	\N	39510	\N
47277	GENERIC_DAY	2	16	\N	2010-08-17	38987	\N	39510	\N
47281	GENERIC_DAY	2	0	\N	2010-09-12	38987	\N	39510	\N
47259	GENERIC_DAY	2	16	\N	2010-07-16	38987	\N	39510	\N
47239	GENERIC_DAY	2	16	\N	2010-07-28	38987	\N	39510	\N
47264	GENERIC_DAY	2	0	\N	2010-07-10	38987	\N	39510	\N
47262	GENERIC_DAY	2	16	\N	2010-09-03	38987	\N	39510	\N
47241	GENERIC_DAY	2	16	\N	2010-07-08	38987	\N	39510	\N
47258	GENERIC_DAY	2	16	\N	2010-09-20	38987	\N	39510	\N
47272	GENERIC_DAY	2	16	\N	2010-09-16	38987	\N	39510	\N
47286	GENERIC_DAY	2	16	\N	2010-07-15	38987	\N	39510	\N
47283	GENERIC_DAY	2	0	\N	2010-07-11	38987	\N	39510	\N
47302	GENERIC_DAY	2	0	\N	2010-07-04	38987	\N	39510	\N
49478	GENERIC_DAY	1	0	\N	2010-07-24	1123	\N	39520	\N
49479	GENERIC_DAY	1	0	\N	2010-07-18	1121	\N	39520	\N
49480	GENERIC_DAY	1	0	\N	2010-06-26	1123	\N	39520	\N
49481	GENERIC_DAY	1	8	\N	2010-07-01	1121	\N	39520	\N
49482	GENERIC_DAY	1	8	\N	2010-06-16	1119	\N	39520	\N
49483	GENERIC_DAY	1	8	\N	2010-07-15	1123	\N	39520	\N
49484	GENERIC_DAY	1	0	\N	2010-08-01	1119	\N	39520	\N
49485	GENERIC_DAY	1	8	\N	2010-07-13	1119	\N	39520	\N
49486	GENERIC_DAY	1	8	\N	2010-07-07	1121	\N	39520	\N
49487	GENERIC_DAY	1	8	\N	2010-06-24	1123	\N	39520	\N
49488	GENERIC_DAY	1	8	\N	2010-06-29	1119	\N	39520	\N
49489	GENERIC_DAY	1	8	\N	2010-07-26	1123	\N	39520	\N
49490	GENERIC_DAY	1	8	\N	2010-06-18	1121	\N	39520	\N
49491	GENERIC_DAY	1	8	\N	2010-06-11	1119	\N	39520	\N
49492	GENERIC_DAY	1	8	\N	2010-06-24	1119	\N	39520	\N
49493	GENERIC_DAY	1	8	\N	2010-07-23	1119	\N	39520	\N
49494	GENERIC_DAY	1	0	\N	2010-08-01	1121	\N	39520	\N
49495	GENERIC_DAY	1	0	\N	2010-06-13	1121	\N	39520	\N
49496	GENERIC_DAY	1	8	\N	2010-07-19	1119	\N	39520	\N
49497	GENERIC_DAY	1	0	\N	2010-06-13	1119	\N	39520	\N
49498	GENERIC_DAY	1	0	\N	2010-06-27	1123	\N	39520	\N
49499	GENERIC_DAY	1	8	\N	2010-07-20	1123	\N	39520	\N
49500	GENERIC_DAY	1	8	\N	2010-07-16	1123	\N	39520	\N
49501	GENERIC_DAY	1	8	\N	2010-08-02	1119	\N	39520	\N
49502	GENERIC_DAY	1	0	\N	2010-06-20	1119	\N	39520	\N
49503	GENERIC_DAY	1	8	\N	2010-07-01	1119	\N	39520	\N
49504	GENERIC_DAY	1	8	\N	2010-07-14	1123	\N	39520	\N
49505	GENERIC_DAY	1	0	\N	2010-07-24	1121	\N	39520	\N
49506	GENERIC_DAY	1	0	\N	2010-06-20	1121	\N	39520	\N
49507	GENERIC_DAY	1	8	\N	2010-07-12	1119	\N	39520	\N
49508	GENERIC_DAY	1	0	\N	2010-06-12	1123	\N	39520	\N
49509	GENERIC_DAY	1	0	\N	2010-08-01	1123	\N	39520	\N
49510	GENERIC_DAY	1	8	\N	2010-07-30	1119	\N	39520	\N
49511	GENERIC_DAY	1	8	\N	2010-06-30	1123	\N	39520	\N
49512	GENERIC_DAY	1	0	\N	2010-07-04	1119	\N	39520	\N
49513	GENERIC_DAY	1	0	\N	2010-07-25	1121	\N	39520	\N
49514	GENERIC_DAY	1	8	\N	2010-06-23	1119	\N	39520	\N
49515	GENERIC_DAY	1	8	\N	2010-07-27	1121	\N	39520	\N
49516	GENERIC_DAY	1	8	\N	2010-07-22	1121	\N	39520	\N
49517	GENERIC_DAY	1	8	\N	2010-06-23	1123	\N	39520	\N
49518	GENERIC_DAY	1	8	\N	2010-07-07	1123	\N	39520	\N
49519	GENERIC_DAY	1	8	\N	2010-07-12	1123	\N	39520	\N
49520	GENERIC_DAY	1	0	\N	2010-07-17	1121	\N	39520	\N
49521	GENERIC_DAY	1	0	\N	2010-07-10	1119	\N	39520	\N
49522	GENERIC_DAY	1	8	\N	2010-07-16	1119	\N	39520	\N
49523	GENERIC_DAY	1	0	\N	2010-06-27	1121	\N	39520	\N
49524	GENERIC_DAY	1	8	\N	2010-07-14	1121	\N	39520	\N
49525	GENERIC_DAY	1	8	\N	2010-06-28	1121	\N	39520	\N
49526	GENERIC_DAY	1	8	\N	2010-07-08	1121	\N	39520	\N
49527	GENERIC_DAY	1	8	\N	2010-07-15	1121	\N	39520	\N
49528	GENERIC_DAY	1	8	\N	2010-06-25	1123	\N	39520	\N
49529	GENERIC_DAY	1	8	\N	2010-06-18	1119	\N	39520	\N
49530	GENERIC_DAY	1	8	\N	2010-07-28	1123	\N	39520	\N
49531	GENERIC_DAY	1	8	\N	2010-07-05	1123	\N	39520	\N
49532	GENERIC_DAY	1	8	\N	2010-07-23	1121	\N	39520	\N
49533	GENERIC_DAY	1	8	\N	2010-07-02	1123	\N	39520	\N
49534	GENERIC_DAY	1	0	\N	2010-07-03	1123	\N	39520	\N
49535	GENERIC_DAY	1	8	\N	2010-06-30	1119	\N	39520	\N
49536	GENERIC_DAY	1	0	\N	2010-07-24	1119	\N	39520	\N
49537	GENERIC_DAY	1	8	\N	2010-07-19	1123	\N	39520	\N
49538	GENERIC_DAY	1	8	\N	2010-07-02	1119	\N	39520	\N
49539	GENERIC_DAY	1	8	\N	2010-07-26	1121	\N	39520	\N
49540	GENERIC_DAY	1	0	\N	2010-06-12	1121	\N	39520	\N
49541	GENERIC_DAY	1	0	\N	2010-07-31	1123	\N	39520	\N
49542	GENERIC_DAY	1	6	\N	2010-08-06	1123	\N	39520	\N
49543	GENERIC_DAY	1	0	\N	2010-06-12	1119	\N	39520	\N
49544	GENERIC_DAY	1	0	\N	2010-07-04	1121	\N	39520	\N
49545	GENERIC_DAY	1	8	\N	2010-06-24	1121	\N	39520	\N
49546	GENERIC_DAY	1	8	\N	2010-07-09	1121	\N	39520	\N
49547	GENERIC_DAY	1	8	\N	2010-08-03	1121	\N	39520	\N
49548	GENERIC_DAY	1	0	\N	2010-07-11	1119	\N	39520	\N
49549	GENERIC_DAY	1	8	\N	2010-06-10	1119	\N	39520	\N
49550	GENERIC_DAY	1	8	\N	2010-07-16	1121	\N	39520	\N
49551	GENERIC_DAY	1	0	\N	2010-07-25	1119	\N	39520	\N
49552	GENERIC_DAY	1	8	\N	2010-07-12	1121	\N	39520	\N
49553	GENERIC_DAY	1	8	\N	2010-07-05	1121	\N	39520	\N
49554	GENERIC_DAY	1	8	\N	2010-08-05	1119	\N	39520	\N
49555	GENERIC_DAY	1	8	\N	2010-08-03	1119	\N	39520	\N
49556	GENERIC_DAY	1	8	\N	2010-07-15	1119	\N	39520	\N
49557	GENERIC_DAY	1	8	\N	2010-06-17	1123	\N	39520	\N
49558	GENERIC_DAY	1	8	\N	2010-07-02	1121	\N	39520	\N
49559	GENERIC_DAY	1	0	\N	2010-06-19	1121	\N	39520	\N
49560	GENERIC_DAY	1	8	\N	2010-06-10	1123	\N	39520	\N
49561	GENERIC_DAY	1	8	\N	2010-06-25	1121	\N	39520	\N
49562	GENERIC_DAY	1	8	\N	2010-06-17	1121	\N	39520	\N
49563	GENERIC_DAY	1	0	\N	2010-07-04	1123	\N	39520	\N
49564	GENERIC_DAY	1	0	\N	2010-06-26	1119	\N	39520	\N
49565	GENERIC_DAY	1	8	\N	2010-06-28	1123	\N	39520	\N
49566	GENERIC_DAY	1	0	\N	2010-07-11	1123	\N	39520	\N
49567	GENERIC_DAY	1	8	\N	2010-07-30	1123	\N	39520	\N
49568	GENERIC_DAY	1	8	\N	2010-06-14	1121	\N	39520	\N
49569	GENERIC_DAY	1	8	\N	2010-06-15	1121	\N	39520	\N
49570	GENERIC_DAY	1	8	\N	2010-06-29	1123	\N	39520	\N
49571	GENERIC_DAY	1	8	\N	2010-07-29	1121	\N	39520	\N
49572	GENERIC_DAY	1	8	\N	2010-06-29	1121	\N	39520	\N
49573	GENERIC_DAY	1	8	\N	2010-07-28	1121	\N	39520	\N
49574	GENERIC_DAY	1	8	\N	2010-07-27	1119	\N	39520	\N
49575	GENERIC_DAY	1	8	\N	2010-06-23	1121	\N	39520	\N
49576	GENERIC_DAY	1	8	\N	2010-07-29	1123	\N	39520	\N
49577	GENERIC_DAY	1	8	\N	2010-07-21	1119	\N	39520	\N
49578	GENERIC_DAY	1	8	\N	2010-06-15	1119	\N	39520	\N
49579	GENERIC_DAY	1	8	\N	2010-06-28	1119	\N	39520	\N
49580	GENERIC_DAY	1	0	\N	2010-06-26	1121	\N	39520	\N
49581	GENERIC_DAY	1	8	\N	2010-07-19	1121	\N	39520	\N
49582	GENERIC_DAY	1	0	\N	2010-06-27	1119	\N	39520	\N
49583	GENERIC_DAY	1	5	\N	2010-08-06	1119	\N	39520	\N
49584	GENERIC_DAY	1	8	\N	2010-07-29	1119	\N	39520	\N
49585	GENERIC_DAY	1	8	\N	2010-08-02	1123	\N	39520	\N
49586	GENERIC_DAY	1	8	\N	2010-06-22	1119	\N	39520	\N
49587	GENERIC_DAY	1	8	\N	2010-06-22	1121	\N	39520	\N
49588	GENERIC_DAY	1	8	\N	2010-06-30	1121	\N	39520	\N
49589	GENERIC_DAY	1	8	\N	2010-07-06	1123	\N	39520	\N
49590	GENERIC_DAY	1	8	\N	2010-07-13	1121	\N	39520	\N
49591	GENERIC_DAY	1	0	\N	2010-07-03	1121	\N	39520	\N
49592	GENERIC_DAY	1	0	\N	2010-07-25	1123	\N	39520	\N
49593	GENERIC_DAY	1	0	\N	2010-07-10	1123	\N	39520	\N
49594	GENERIC_DAY	1	8	\N	2010-07-09	1119	\N	39520	\N
49595	GENERIC_DAY	1	8	\N	2010-06-15	1123	\N	39520	\N
49596	GENERIC_DAY	1	8	\N	2010-07-13	1123	\N	39520	\N
49597	GENERIC_DAY	1	8	\N	2010-07-28	1119	\N	39520	\N
49598	GENERIC_DAY	1	0	\N	2010-06-13	1123	\N	39520	\N
49599	GENERIC_DAY	1	8	\N	2010-08-02	1121	\N	39520	\N
49600	GENERIC_DAY	1	8	\N	2010-08-04	1119	\N	39520	\N
49601	GENERIC_DAY	1	8	\N	2010-06-21	1123	\N	39520	\N
49602	GENERIC_DAY	1	8	\N	2010-06-10	1121	\N	39520	\N
49603	GENERIC_DAY	1	8	\N	2010-07-27	1123	\N	39520	\N
49604	GENERIC_DAY	1	8	\N	2010-07-30	1121	\N	39520	\N
49605	GENERIC_DAY	1	8	\N	2010-07-08	1123	\N	39520	\N
49606	GENERIC_DAY	1	8	\N	2010-08-05	1121	\N	39520	\N
49607	GENERIC_DAY	1	8	\N	2010-06-16	1121	\N	39520	\N
49608	GENERIC_DAY	1	8	\N	2010-07-06	1121	\N	39520	\N
49609	GENERIC_DAY	1	8	\N	2010-07-21	1121	\N	39520	\N
49610	GENERIC_DAY	1	8	\N	2010-06-16	1123	\N	39520	\N
49611	GENERIC_DAY	1	8	\N	2010-07-05	1119	\N	39520	\N
49612	GENERIC_DAY	1	8	\N	2010-07-08	1119	\N	39520	\N
49613	GENERIC_DAY	1	8	\N	2010-07-21	1123	\N	39520	\N
49614	GENERIC_DAY	1	8	\N	2010-06-22	1123	\N	39520	\N
49615	GENERIC_DAY	1	0	\N	2010-07-03	1119	\N	39520	\N
49616	GENERIC_DAY	1	8	\N	2010-07-23	1123	\N	39520	\N
49617	GENERIC_DAY	1	0	\N	2010-07-11	1121	\N	39520	\N
49618	GENERIC_DAY	1	8	\N	2010-07-07	1119	\N	39520	\N
49619	GENERIC_DAY	1	0	\N	2010-07-31	1119	\N	39520	\N
49620	GENERIC_DAY	1	0	\N	2010-06-19	1119	\N	39520	\N
49621	GENERIC_DAY	1	8	\N	2010-06-21	1119	\N	39520	\N
49622	GENERIC_DAY	1	0	\N	2010-06-20	1123	\N	39520	\N
49623	GENERIC_DAY	1	8	\N	2010-06-11	1123	\N	39520	\N
49624	GENERIC_DAY	1	8	\N	2010-08-05	1123	\N	39520	\N
49625	GENERIC_DAY	1	0	\N	2010-07-31	1121	\N	39520	\N
49626	GENERIC_DAY	1	8	\N	2010-06-17	1119	\N	39520	\N
49627	GENERIC_DAY	1	0	\N	2010-06-19	1123	\N	39520	\N
49628	GENERIC_DAY	1	8	\N	2010-06-11	1121	\N	39520	\N
49629	GENERIC_DAY	1	0	\N	2010-07-18	1123	\N	39520	\N
49630	GENERIC_DAY	1	8	\N	2010-06-14	1119	\N	39520	\N
49631	GENERIC_DAY	1	8	\N	2010-07-01	1123	\N	39520	\N
49632	GENERIC_DAY	1	8	\N	2010-07-22	1123	\N	39520	\N
49633	GENERIC_DAY	1	8	\N	2010-06-18	1123	\N	39520	\N
49634	GENERIC_DAY	1	8	\N	2010-06-14	1123	\N	39520	\N
49635	GENERIC_DAY	1	0	\N	2010-07-18	1119	\N	39520	\N
49636	GENERIC_DAY	1	8	\N	2010-07-14	1119	\N	39520	\N
49637	GENERIC_DAY	1	8	\N	2010-07-09	1123	\N	39520	\N
49638	GENERIC_DAY	1	5	\N	2010-08-06	1121	\N	39520	\N
49639	GENERIC_DAY	1	8	\N	2010-07-22	1119	\N	39520	\N
49640	GENERIC_DAY	1	8	\N	2010-07-26	1119	\N	39520	\N
49641	GENERIC_DAY	1	8	\N	2010-08-03	1123	\N	39520	\N
49642	GENERIC_DAY	1	0	\N	2010-07-10	1121	\N	39520	\N
49643	GENERIC_DAY	1	8	\N	2010-07-06	1119	\N	39520	\N
49644	GENERIC_DAY	1	0	\N	2010-07-17	1123	\N	39520	\N
49645	GENERIC_DAY	1	8	\N	2010-08-04	1121	\N	39520	\N
49646	GENERIC_DAY	1	8	\N	2010-07-20	1121	\N	39520	\N
49647	GENERIC_DAY	1	0	\N	2010-07-17	1119	\N	39520	\N
49648	GENERIC_DAY	1	8	\N	2010-08-04	1123	\N	39520	\N
49649	GENERIC_DAY	1	8	\N	2010-07-20	1119	\N	39520	\N
49650	GENERIC_DAY	1	8	\N	2010-06-21	1121	\N	39520	\N
49651	GENERIC_DAY	1	8	\N	2010-06-25	1119	\N	39520	\N
49073	GENERIC_DAY	1	5	\N	2010-08-17	1119	\N	39518	\N
49074	GENERIC_DAY	1	0	\N	2010-09-19	1121	\N	39518	\N
49075	GENERIC_DAY	1	5	\N	2010-09-13	1123	\N	39518	\N
49076	GENERIC_DAY	1	6	\N	2010-08-23	1119	\N	39518	\N
49077	GENERIC_DAY	1	0	\N	2010-08-29	1121	\N	39518	\N
49078	GENERIC_DAY	1	5	\N	2010-08-16	1119	\N	39518	\N
49079	GENERIC_DAY	1	6	\N	2010-09-02	1119	\N	39518	\N
49080	GENERIC_DAY	1	6	\N	2010-09-10	1119	\N	39518	\N
49081	GENERIC_DAY	1	6	\N	2010-09-06	1119	\N	39518	\N
49082	GENERIC_DAY	1	6	\N	2010-08-10	1123	\N	39518	\N
49083	GENERIC_DAY	1	6	\N	2010-09-14	1119	\N	39518	\N
49084	GENERIC_DAY	1	0	\N	2010-08-08	1119	\N	39518	\N
49085	GENERIC_DAY	1	6	\N	2010-08-18	1119	\N	39518	\N
49086	GENERIC_DAY	1	6	\N	2010-08-17	1123	\N	39518	\N
49087	GENERIC_DAY	1	0	\N	2010-08-08	1121	\N	39518	\N
49088	GENERIC_DAY	1	5	\N	2010-09-07	1123	\N	39518	\N
49089	GENERIC_DAY	1	5	\N	2010-08-18	1123	\N	39518	\N
49090	GENERIC_DAY	1	5	\N	2010-08-11	1119	\N	39518	\N
49091	GENERIC_DAY	1	6	\N	2010-09-13	1119	\N	39518	\N
49092	GENERIC_DAY	1	6	\N	2010-09-08	1119	\N	39518	\N
49093	GENERIC_DAY	1	0	\N	2010-08-22	1121	\N	39518	\N
49094	GENERIC_DAY	1	5	\N	2010-08-23	1121	\N	39518	\N
49095	GENERIC_DAY	1	0	\N	2010-09-18	1119	\N	39518	\N
49096	GENERIC_DAY	1	6	\N	2010-09-01	1119	\N	39518	\N
49097	GENERIC_DAY	1	6	\N	2010-09-03	1119	\N	39518	\N
49098	GENERIC_DAY	1	6	\N	2010-08-13	1123	\N	39518	\N
49099	GENERIC_DAY	1	0	\N	2010-08-14	1121	\N	39518	\N
49100	GENERIC_DAY	1	6	\N	2010-08-20	1119	\N	39518	\N
49101	GENERIC_DAY	1	6	\N	2010-09-20	1119	\N	39518	\N
49102	GENERIC_DAY	1	6	\N	2010-08-26	1119	\N	39518	\N
49103	GENERIC_DAY	1	0	\N	2010-08-22	1119	\N	39518	\N
49104	GENERIC_DAY	1	5	\N	2010-08-10	1119	\N	39518	\N
49105	GENERIC_DAY	1	5	\N	2010-09-14	1123	\N	39518	\N
49106	GENERIC_DAY	1	5	\N	2010-08-27	1123	\N	39518	\N
49107	GENERIC_DAY	1	5	\N	2010-09-15	1121	\N	39518	\N
49108	GENERIC_DAY	1	0	\N	2010-08-21	1119	\N	39518	\N
49109	GENERIC_DAY	1	0	\N	2010-08-22	1123	\N	39518	\N
49110	GENERIC_DAY	1	5	\N	2010-08-17	1121	\N	39518	\N
49111	GENERIC_DAY	1	5	\N	2010-08-25	1121	\N	39518	\N
49112	GENERIC_DAY	1	1	\N	2010-09-21	1123	\N	39518	\N
49113	GENERIC_DAY	1	0	\N	2010-09-05	1119	\N	39518	\N
49114	GENERIC_DAY	1	5	\N	2010-08-24	1121	\N	39518	\N
49115	GENERIC_DAY	1	5	\N	2010-08-19	1123	\N	39518	\N
49116	GENERIC_DAY	1	5	\N	2010-09-17	1121	\N	39518	\N
49117	GENERIC_DAY	1	0	\N	2010-08-28	1119	\N	39518	\N
49118	GENERIC_DAY	1	5	\N	2010-08-20	1121	\N	39518	\N
49119	GENERIC_DAY	1	0	\N	2010-08-14	1119	\N	39518	\N
49120	GENERIC_DAY	1	5	\N	2010-08-23	1123	\N	39518	\N
49121	GENERIC_DAY	1	0	\N	2010-09-18	1121	\N	39518	\N
49122	GENERIC_DAY	1	5	\N	2010-09-10	1121	\N	39518	\N
49123	GENERIC_DAY	1	0	\N	2010-09-11	1123	\N	39518	\N
49124	GENERIC_DAY	1	5	\N	2010-08-26	1123	\N	39518	\N
49125	GENERIC_DAY	1	6	\N	2010-09-07	1119	\N	39518	\N
49126	GENERIC_DAY	1	6	\N	2010-08-27	1119	\N	39518	\N
49127	GENERIC_DAY	1	5	\N	2010-09-15	1123	\N	39518	\N
49128	GENERIC_DAY	1	5	\N	2010-08-24	1123	\N	39518	\N
49129	GENERIC_DAY	1	5	\N	2010-09-02	1121	\N	39518	\N
49130	GENERIC_DAY	1	5	\N	2010-09-03	1121	\N	39518	\N
49131	GENERIC_DAY	1	0	\N	2010-08-21	1123	\N	39518	\N
49132	GENERIC_DAY	1	0	\N	2010-08-28	1123	\N	39518	\N
49133	GENERIC_DAY	1	5	\N	2010-09-20	1121	\N	39518	\N
49134	GENERIC_DAY	1	0	\N	2010-09-19	1123	\N	39518	\N
49135	GENERIC_DAY	1	5	\N	2010-08-13	1121	\N	39518	\N
49136	GENERIC_DAY	1	5	\N	2010-09-01	1121	\N	39518	\N
49137	GENERIC_DAY	1	5	\N	2010-09-06	1121	\N	39518	\N
49138	GENERIC_DAY	1	0	\N	2010-08-14	1123	\N	39518	\N
49139	GENERIC_DAY	1	5	\N	2010-08-09	1121	\N	39518	\N
49140	GENERIC_DAY	1	6	\N	2010-08-09	1123	\N	39518	\N
49141	GENERIC_DAY	1	0	\N	2010-09-04	1119	\N	39518	\N
49142	GENERIC_DAY	1	0	\N	2010-09-04	1121	\N	39518	\N
49143	GENERIC_DAY	1	5	\N	2010-08-18	1121	\N	39518	\N
49144	GENERIC_DAY	1	6	\N	2010-08-25	1119	\N	39518	\N
49145	GENERIC_DAY	1	5	\N	2010-09-07	1121	\N	39518	\N
49146	GENERIC_DAY	1	5	\N	2010-09-01	1123	\N	39518	\N
49147	GENERIC_DAY	1	5	\N	2010-08-31	1123	\N	39518	\N
49148	GENERIC_DAY	1	5	\N	2010-09-17	1123	\N	39518	\N
49149	GENERIC_DAY	1	5	\N	2010-09-16	1121	\N	39518	\N
49150	GENERIC_DAY	1	0	\N	2010-08-08	1123	\N	39518	\N
49151	GENERIC_DAY	1	5	\N	2010-09-20	1123	\N	39518	\N
49152	GENERIC_DAY	1	6	\N	2010-08-30	1119	\N	39518	\N
49153	GENERIC_DAY	1	6	\N	2010-09-16	1119	\N	39518	\N
49154	GENERIC_DAY	1	5	\N	2010-08-16	1121	\N	39518	\N
49155	GENERIC_DAY	1	6	\N	2010-08-16	1123	\N	39518	\N
49156	GENERIC_DAY	1	0	\N	2010-08-07	1121	\N	39518	\N
49157	GENERIC_DAY	1	0	\N	2010-08-15	1121	\N	39518	\N
49158	GENERIC_DAY	1	5	\N	2010-08-12	1119	\N	39518	\N
49159	GENERIC_DAY	1	0	\N	2010-08-15	1119	\N	39518	\N
49160	GENERIC_DAY	1	1	\N	2010-09-21	1121	\N	39518	\N
49161	GENERIC_DAY	1	6	\N	2010-08-31	1119	\N	39518	\N
49162	GENERIC_DAY	1	6	\N	2010-08-12	1123	\N	39518	\N
49163	GENERIC_DAY	1	5	\N	2010-08-20	1123	\N	39518	\N
49164	GENERIC_DAY	1	5	\N	2010-08-10	1121	\N	39518	\N
49165	GENERIC_DAY	1	5	\N	2010-09-02	1123	\N	39518	\N
49166	GENERIC_DAY	1	6	\N	2010-09-17	1119	\N	39518	\N
49167	GENERIC_DAY	1	5	\N	2010-08-19	1121	\N	39518	\N
49168	GENERIC_DAY	1	0	\N	2010-09-04	1123	\N	39518	\N
49169	GENERIC_DAY	1	6	\N	2010-08-19	1119	\N	39518	\N
49170	GENERIC_DAY	1	5	\N	2010-09-16	1123	\N	39518	\N
49171	GENERIC_DAY	1	5	\N	2010-08-13	1119	\N	39518	\N
49172	GENERIC_DAY	1	0	\N	2010-08-28	1121	\N	39518	\N
49173	GENERIC_DAY	1	5	\N	2010-08-31	1121	\N	39518	\N
49174	GENERIC_DAY	1	0	\N	2010-08-07	1119	\N	39518	\N
49175	GENERIC_DAY	1	5	\N	2010-08-27	1121	\N	39518	\N
49176	GENERIC_DAY	1	0	\N	2010-09-19	1119	\N	39518	\N
49177	GENERIC_DAY	1	5	\N	2010-09-13	1121	\N	39518	\N
49178	GENERIC_DAY	1	5	\N	2010-08-25	1123	\N	39518	\N
49179	GENERIC_DAY	1	0	\N	2010-09-12	1123	\N	39518	\N
49180	GENERIC_DAY	1	5	\N	2010-09-03	1123	\N	39518	\N
49181	GENERIC_DAY	1	5	\N	2010-09-08	1121	\N	39518	\N
49182	GENERIC_DAY	1	5	\N	2010-09-10	1123	\N	39518	\N
49183	GENERIC_DAY	1	0	\N	2010-08-15	1123	\N	39518	\N
49184	GENERIC_DAY	1	2	\N	2010-09-21	1119	\N	39518	\N
49185	GENERIC_DAY	1	5	\N	2010-08-11	1121	\N	39518	\N
49186	GENERIC_DAY	1	5	\N	2010-08-12	1121	\N	39518	\N
49187	GENERIC_DAY	1	0	\N	2010-09-18	1123	\N	39518	\N
49188	GENERIC_DAY	1	0	\N	2010-09-05	1123	\N	39518	\N
49189	GENERIC_DAY	1	6	\N	2010-09-09	1119	\N	39518	\N
49190	GENERIC_DAY	1	0	\N	2010-08-29	1119	\N	39518	\N
49191	GENERIC_DAY	1	5	\N	2010-08-30	1121	\N	39518	\N
49192	GENERIC_DAY	1	0	\N	2010-09-05	1121	\N	39518	\N
49193	GENERIC_DAY	1	0	\N	2010-09-12	1121	\N	39518	\N
49194	GENERIC_DAY	1	0	\N	2010-08-29	1123	\N	39518	\N
49195	GENERIC_DAY	1	5	\N	2010-08-30	1123	\N	39518	\N
49196	GENERIC_DAY	1	5	\N	2010-09-09	1123	\N	39518	\N
49197	GENERIC_DAY	1	5	\N	2010-09-08	1123	\N	39518	\N
49198	GENERIC_DAY	1	5	\N	2010-09-14	1121	\N	39518	\N
49199	GENERIC_DAY	1	6	\N	2010-09-15	1119	\N	39518	\N
49200	GENERIC_DAY	1	0	\N	2010-08-07	1123	\N	39518	\N
49201	GENERIC_DAY	1	6	\N	2010-08-11	1123	\N	39518	\N
49202	GENERIC_DAY	1	5	\N	2010-08-09	1119	\N	39518	\N
49203	GENERIC_DAY	1	5	\N	2010-08-26	1121	\N	39518	\N
49204	GENERIC_DAY	1	6	\N	2010-08-24	1119	\N	39518	\N
49205	GENERIC_DAY	1	0	\N	2010-09-11	1119	\N	39518	\N
49206	GENERIC_DAY	1	5	\N	2010-09-06	1123	\N	39518	\N
49207	GENERIC_DAY	1	0	\N	2010-09-11	1121	\N	39518	\N
49208	GENERIC_DAY	1	0	\N	2010-08-21	1121	\N	39518	\N
49209	GENERIC_DAY	1	0	\N	2010-09-12	1119	\N	39518	\N
49210	GENERIC_DAY	1	5	\N	2010-09-09	1121	\N	39518	\N
49211	GENERIC_DAY	1	0	\N	2010-09-25	1126	\N	39519	\N
49212	GENERIC_DAY	1	0	\N	2010-09-19	1126	\N	39519	\N
49213	GENERIC_DAY	1	0	\N	2010-09-05	1130	\N	39519	\N
49214	GENERIC_DAY	1	11	\N	2010-08-13	1130	\N	39519	\N
49215	GENERIC_DAY	1	0	\N	2010-10-17	1128	\N	39519	\N
49216	GENERIC_DAY	1	11	\N	2010-10-27	1126	\N	39519	\N
49217	GENERIC_DAY	1	0	\N	2010-10-03	1130	\N	39519	\N
49218	GENERIC_DAY	1	0	\N	2010-09-25	1130	\N	39519	\N
49219	GENERIC_DAY	1	11	\N	2010-08-27	1128	\N	39519	\N
49220	GENERIC_DAY	1	10	\N	2010-09-02	1126	\N	39519	\N
49221	GENERIC_DAY	1	0	\N	2010-09-18	1126	\N	39519	\N
49222	GENERIC_DAY	1	10	\N	2010-09-16	1128	\N	39519	\N
49223	GENERIC_DAY	1	0	\N	2010-09-26	1126	\N	39519	\N
49224	GENERIC_DAY	1	0	\N	2010-10-23	1128	\N	39519	\N
49225	GENERIC_DAY	1	11	\N	2010-10-15	1126	\N	39519	\N
49226	GENERIC_DAY	1	11	\N	2010-10-01	1126	\N	39519	\N
49227	GENERIC_DAY	1	0	\N	2010-10-10	1128	\N	39519	\N
49228	GENERIC_DAY	1	10	\N	2010-09-14	1128	\N	39519	\N
49229	GENERIC_DAY	1	10	\N	2010-09-24	1130	\N	39519	\N
49230	GENERIC_DAY	1	10	\N	2010-10-27	1130	\N	39519	\N
49231	GENERIC_DAY	1	10	\N	2010-10-04	1130	\N	39519	\N
49232	GENERIC_DAY	1	0	\N	2010-10-23	1126	\N	39519	\N
49233	GENERIC_DAY	1	11	\N	2010-08-30	1128	\N	39519	\N
49234	GENERIC_DAY	1	0	\N	2010-08-14	1130	\N	39519	\N
49235	GENERIC_DAY	1	11	\N	2010-10-15	1128	\N	39519	\N
49236	GENERIC_DAY	1	11	\N	2010-10-04	1126	\N	39519	\N
49237	GENERIC_DAY	1	0	\N	2010-09-11	1130	\N	39519	\N
49238	GENERIC_DAY	1	11	\N	2010-08-17	1126	\N	39519	\N
49239	GENERIC_DAY	1	10	\N	2010-10-06	1130	\N	39519	\N
49240	GENERIC_DAY	1	0	\N	2010-10-10	1126	\N	39519	\N
49241	GENERIC_DAY	1	10	\N	2010-08-12	1128	\N	39519	\N
49242	GENERIC_DAY	1	0	\N	2010-08-22	1126	\N	39519	\N
49243	GENERIC_DAY	1	10	\N	2010-08-20	1126	\N	39519	\N
49244	GENERIC_DAY	1	11	\N	2010-08-16	1130	\N	39519	\N
49245	GENERIC_DAY	1	10	\N	2010-09-15	1128	\N	39519	\N
49246	GENERIC_DAY	1	11	\N	2010-08-09	1126	\N	39519	\N
49247	GENERIC_DAY	1	0	\N	2010-08-28	1130	\N	39519	\N
49248	GENERIC_DAY	1	0	\N	2010-10-16	1130	\N	39519	\N
49249	GENERIC_DAY	1	11	\N	2010-08-27	1130	\N	39519	\N
49250	GENERIC_DAY	1	11	\N	2010-09-09	1130	\N	39519	\N
49251	GENERIC_DAY	1	11	\N	2010-10-08	1126	\N	39519	\N
49252	GENERIC_DAY	1	10	\N	2010-09-23	1126	\N	39519	\N
49253	GENERIC_DAY	1	0	\N	2010-09-18	1130	\N	39519	\N
49254	GENERIC_DAY	1	0	\N	2010-10-09	1130	\N	39519	\N
49255	GENERIC_DAY	1	0	\N	2010-10-23	1130	\N	39519	\N
49256	GENERIC_DAY	1	0	\N	2010-08-14	1126	\N	39519	\N
49257	GENERIC_DAY	1	11	\N	2010-10-28	1126	\N	39519	\N
49258	GENERIC_DAY	1	10	\N	2010-08-25	1126	\N	39519	\N
49259	GENERIC_DAY	1	11	\N	2010-09-30	1126	\N	39519	\N
49260	GENERIC_DAY	1	10	\N	2010-08-23	1126	\N	39519	\N
49261	GENERIC_DAY	1	11	\N	2010-09-14	1130	\N	39519	\N
49262	GENERIC_DAY	1	0	\N	2010-08-21	1128	\N	39519	\N
49263	GENERIC_DAY	1	0	\N	2010-10-02	1130	\N	39519	\N
49264	GENERIC_DAY	1	10	\N	2010-10-21	1130	\N	39519	\N
49265	GENERIC_DAY	1	0	\N	2010-08-07	1130	\N	39519	\N
49266	GENERIC_DAY	1	10	\N	2010-09-07	1126	\N	39519	\N
49267	GENERIC_DAY	1	11	\N	2010-09-23	1130	\N	39519	\N
49268	GENERIC_DAY	1	0	\N	2010-10-09	1128	\N	39519	\N
49269	GENERIC_DAY	1	0	\N	2010-09-18	1128	\N	39519	\N
49270	GENERIC_DAY	1	10	\N	2010-09-27	1130	\N	39519	\N
49271	GENERIC_DAY	1	10	\N	2010-09-30	1130	\N	39519	\N
49272	GENERIC_DAY	1	11	\N	2010-08-17	1130	\N	39519	\N
49273	GENERIC_DAY	1	0	\N	2010-08-28	1128	\N	39519	\N
49274	GENERIC_DAY	1	10	\N	2010-08-31	1126	\N	39519	\N
49275	GENERIC_DAY	1	11	\N	2010-08-30	1130	\N	39519	\N
49276	GENERIC_DAY	1	10	\N	2010-10-28	1130	\N	39519	\N
49277	GENERIC_DAY	1	11	\N	2010-08-10	1130	\N	39519	\N
49278	GENERIC_DAY	1	11	\N	2010-09-10	1128	\N	39519	\N
49279	GENERIC_DAY	1	11	\N	2010-09-09	1128	\N	39519	\N
49280	GENERIC_DAY	1	11	\N	2010-10-26	1128	\N	39519	\N
49281	GENERIC_DAY	1	11	\N	2010-10-29	1128	\N	39519	\N
49282	GENERIC_DAY	1	11	\N	2010-10-01	1128	\N	39519	\N
49283	GENERIC_DAY	1	11	\N	2010-08-26	1128	\N	39519	\N
49284	GENERIC_DAY	1	11	\N	2010-09-03	1128	\N	39519	\N
49285	GENERIC_DAY	1	0	\N	2010-09-11	1126	\N	39519	\N
49286	GENERIC_DAY	1	0	\N	2010-08-15	1130	\N	39519	\N
49287	GENERIC_DAY	1	0	\N	2010-09-12	1128	\N	39519	\N
49288	GENERIC_DAY	1	11	\N	2010-09-28	1128	\N	39519	\N
49289	GENERIC_DAY	1	11	\N	2010-10-27	1128	\N	39519	\N
49290	GENERIC_DAY	1	11	\N	2010-09-08	1128	\N	39519	\N
49291	GENERIC_DAY	1	11	\N	2010-10-07	1126	\N	39519	\N
49292	GENERIC_DAY	1	11	\N	2010-09-17	1130	\N	39519	\N
49293	GENERIC_DAY	1	10	\N	2010-10-14	1130	\N	39519	\N
49294	GENERIC_DAY	1	0	\N	2010-08-08	1128	\N	39519	\N
49295	GENERIC_DAY	1	11	\N	2010-08-18	1128	\N	39519	\N
49296	GENERIC_DAY	1	10	\N	2010-08-30	1126	\N	39519	\N
49297	GENERIC_DAY	1	0	\N	2010-09-12	1126	\N	39519	\N
49298	GENERIC_DAY	1	11	\N	2010-09-06	1128	\N	39519	\N
49299	GENERIC_DAY	1	10	\N	2010-09-13	1128	\N	39519	\N
49300	GENERIC_DAY	1	11	\N	2010-08-25	1128	\N	39519	\N
49301	GENERIC_DAY	1	10	\N	2010-08-10	1128	\N	39519	\N
49302	GENERIC_DAY	1	0	\N	2010-08-29	1126	\N	39519	\N
49303	GENERIC_DAY	1	11	\N	2010-09-21	1130	\N	39519	\N
49304	GENERIC_DAY	1	11	\N	2010-10-14	1128	\N	39519	\N
49305	GENERIC_DAY	1	10	\N	2010-08-18	1126	\N	39519	\N
49306	GENERIC_DAY	1	11	\N	2010-08-20	1128	\N	39519	\N
49307	GENERIC_DAY	1	0	\N	2010-09-11	1128	\N	39519	\N
49308	GENERIC_DAY	1	11	\N	2010-09-13	1130	\N	39519	\N
49309	GENERIC_DAY	1	11	\N	2010-10-08	1128	\N	39519	\N
49310	GENERIC_DAY	1	0	\N	2010-08-08	1130	\N	39519	\N
49311	GENERIC_DAY	1	10	\N	2010-08-19	1126	\N	39519	\N
49312	GENERIC_DAY	1	11	\N	2010-08-18	1130	\N	39519	\N
49313	GENERIC_DAY	1	11	\N	2010-10-05	1128	\N	39519	\N
49314	GENERIC_DAY	1	11	\N	2010-10-25	1126	\N	39519	\N
49315	GENERIC_DAY	1	0	\N	2010-08-29	1130	\N	39519	\N
49316	GENERIC_DAY	1	11	\N	2010-09-06	1130	\N	39519	\N
49317	GENERIC_DAY	1	11	\N	2010-11-04	1128	\N	39519	\N
49318	GENERIC_DAY	1	10	\N	2010-09-06	1126	\N	39519	\N
49319	GENERIC_DAY	1	11	\N	2010-11-03	1128	\N	39519	\N
49320	GENERIC_DAY	1	11	\N	2010-10-07	1128	\N	39519	\N
49321	GENERIC_DAY	1	10	\N	2010-08-17	1128	\N	39519	\N
49322	GENERIC_DAY	1	11	\N	2010-09-22	1126	\N	39519	\N
49323	GENERIC_DAY	1	0	\N	2010-10-24	1126	\N	39519	\N
49324	GENERIC_DAY	1	0	\N	2010-08-22	1130	\N	39519	\N
49325	GENERIC_DAY	1	11	\N	2010-09-08	1130	\N	39519	\N
49326	GENERIC_DAY	1	0	\N	2010-10-31	1126	\N	39519	\N
49327	GENERIC_DAY	1	11	\N	2010-10-05	1126	\N	39519	\N
49328	GENERIC_DAY	1	11	\N	2010-09-22	1130	\N	39519	\N
49329	GENERIC_DAY	1	0	\N	2010-09-19	1130	\N	39519	\N
49330	GENERIC_DAY	1	10	\N	2010-09-10	1130	\N	39519	\N
49331	GENERIC_DAY	1	10	\N	2010-09-09	1126	\N	39519	\N
49332	GENERIC_DAY	1	11	\N	2010-08-31	1130	\N	39519	\N
49333	GENERIC_DAY	1	11	\N	2010-09-21	1126	\N	39519	\N
49334	GENERIC_DAY	1	11	\N	2010-09-15	1130	\N	39519	\N
49335	GENERIC_DAY	1	11	\N	2010-08-19	1130	\N	39519	\N
49336	GENERIC_DAY	1	0	\N	2010-10-30	1130	\N	39519	\N
49337	GENERIC_DAY	1	11	\N	2010-08-23	1128	\N	39519	\N
49338	GENERIC_DAY	1	10	\N	2010-08-09	1128	\N	39519	\N
49339	GENERIC_DAY	1	0	\N	2010-10-17	1130	\N	39519	\N
49340	GENERIC_DAY	1	11	\N	2010-08-24	1128	\N	39519	\N
49341	GENERIC_DAY	1	0	\N	2010-08-15	1126	\N	39519	\N
49342	GENERIC_DAY	1	5	\N	2010-11-05	1130	\N	39519	\N
49343	GENERIC_DAY	1	11	\N	2010-09-27	1128	\N	39519	\N
49344	GENERIC_DAY	1	0	\N	2010-10-30	1128	\N	39519	\N
49345	GENERIC_DAY	1	10	\N	2010-09-29	1130	\N	39519	\N
49346	GENERIC_DAY	1	11	\N	2010-10-22	1126	\N	39519	\N
49347	GENERIC_DAY	1	10	\N	2010-11-02	1130	\N	39519	\N
49348	GENERIC_DAY	1	0	\N	2010-09-04	1130	\N	39519	\N
49349	GENERIC_DAY	1	11	\N	2010-10-28	1128	\N	39519	\N
49350	GENERIC_DAY	1	11	\N	2010-09-07	1128	\N	39519	\N
49351	GENERIC_DAY	1	10	\N	2010-10-18	1130	\N	39519	\N
49352	GENERIC_DAY	1	10	\N	2010-09-22	1128	\N	39519	\N
49353	GENERIC_DAY	1	10	\N	2010-10-25	1130	\N	39519	\N
49354	GENERIC_DAY	1	11	\N	2010-09-14	1126	\N	39519	\N
49355	GENERIC_DAY	1	11	\N	2010-10-06	1128	\N	39519	\N
49356	GENERIC_DAY	1	11	\N	2010-09-23	1128	\N	39519	\N
49357	GENERIC_DAY	1	10	\N	2010-10-07	1130	\N	39519	\N
49358	GENERIC_DAY	1	0	\N	2010-08-21	1130	\N	39519	\N
49359	GENERIC_DAY	1	11	\N	2010-08-20	1130	\N	39519	\N
49360	GENERIC_DAY	1	0	\N	2010-08-07	1128	\N	39519	\N
49361	GENERIC_DAY	1	10	\N	2010-10-05	1130	\N	39519	\N
49362	GENERIC_DAY	1	0	\N	2010-08-15	1128	\N	39519	\N
49363	GENERIC_DAY	1	11	\N	2010-09-01	1128	\N	39519	\N
49364	GENERIC_DAY	1	11	\N	2010-09-02	1128	\N	39519	\N
49365	GENERIC_DAY	1	10	\N	2010-10-26	1130	\N	39519	\N
49366	GENERIC_DAY	1	11	\N	2010-10-20	1126	\N	39519	\N
49367	GENERIC_DAY	1	0	\N	2010-08-22	1128	\N	39519	\N
49368	GENERIC_DAY	1	0	\N	2010-08-07	1126	\N	39519	\N
49369	GENERIC_DAY	1	10	\N	2010-09-21	1128	\N	39519	\N
49370	GENERIC_DAY	1	10	\N	2010-10-22	1130	\N	39519	\N
49371	GENERIC_DAY	1	11	\N	2010-08-31	1128	\N	39519	\N
49372	GENERIC_DAY	1	11	\N	2010-10-11	1128	\N	39519	\N
49373	GENERIC_DAY	1	11	\N	2010-09-27	1126	\N	39519	\N
49374	GENERIC_DAY	1	10	\N	2010-11-04	1130	\N	39519	\N
49375	GENERIC_DAY	1	11	\N	2010-11-02	1128	\N	39519	\N
49376	GENERIC_DAY	1	0	\N	2010-10-09	1126	\N	39519	\N
49377	GENERIC_DAY	1	10	\N	2010-10-19	1130	\N	39519	\N
49378	GENERIC_DAY	1	11	\N	2010-10-18	1128	\N	39519	\N
49379	GENERIC_DAY	1	0	\N	2010-09-04	1128	\N	39519	\N
49380	GENERIC_DAY	1	11	\N	2010-10-13	1128	\N	39519	\N
49381	GENERIC_DAY	1	11	\N	2010-11-04	1126	\N	39519	\N
49382	GENERIC_DAY	1	10	\N	2010-09-08	1126	\N	39519	\N
49383	GENERIC_DAY	1	11	\N	2010-09-24	1128	\N	39519	\N
49384	GENERIC_DAY	1	11	\N	2010-09-17	1126	\N	39519	\N
49385	GENERIC_DAY	1	11	\N	2010-09-29	1128	\N	39519	\N
49386	GENERIC_DAY	1	11	\N	2010-08-13	1126	\N	39519	\N
49387	GENERIC_DAY	1	10	\N	2010-08-13	1128	\N	39519	\N
49388	GENERIC_DAY	1	0	\N	2010-10-03	1128	\N	39519	\N
49389	GENERIC_DAY	1	0	\N	2010-10-24	1130	\N	39519	\N
49390	GENERIC_DAY	1	0	\N	2010-10-02	1126	\N	39519	\N
49391	GENERIC_DAY	1	11	\N	2010-09-16	1130	\N	39519	\N
49392	GENERIC_DAY	1	11	\N	2010-10-18	1126	\N	39519	\N
49393	GENERIC_DAY	1	0	\N	2010-09-19	1128	\N	39519	\N
49394	GENERIC_DAY	1	11	\N	2010-10-26	1126	\N	39519	\N
49395	GENERIC_DAY	1	10	\N	2010-09-17	1128	\N	39519	\N
49396	GENERIC_DAY	1	11	\N	2010-10-13	1126	\N	39519	\N
49397	GENERIC_DAY	1	11	\N	2010-08-09	1130	\N	39519	\N
49398	GENERIC_DAY	1	0	\N	2010-10-03	1126	\N	39519	\N
49399	GENERIC_DAY	1	10	\N	2010-08-11	1128	\N	39519	\N
49400	GENERIC_DAY	1	0	\N	2010-08-28	1126	\N	39519	\N
49401	GENERIC_DAY	1	11	\N	2010-09-10	1126	\N	39519	\N
49402	GENERIC_DAY	1	10	\N	2010-09-20	1128	\N	39519	\N
49403	GENERIC_DAY	1	11	\N	2010-10-04	1128	\N	39519	\N
49404	GENERIC_DAY	1	11	\N	2010-10-29	1126	\N	39519	\N
49405	GENERIC_DAY	1	11	\N	2010-10-20	1128	\N	39519	\N
49406	GENERIC_DAY	1	11	\N	2010-09-24	1126	\N	39519	\N
49407	GENERIC_DAY	1	11	\N	2010-09-20	1126	\N	39519	\N
49408	GENERIC_DAY	1	0	\N	2010-10-02	1128	\N	39519	\N
49409	GENERIC_DAY	1	10	\N	2010-11-03	1130	\N	39519	\N
49410	GENERIC_DAY	1	11	\N	2010-10-14	1126	\N	39519	\N
49411	GENERIC_DAY	1	11	\N	2010-09-07	1130	\N	39519	\N
49412	GENERIC_DAY	1	11	\N	2010-09-13	1126	\N	39519	\N
49413	GENERIC_DAY	1	0	\N	2010-09-25	1128	\N	39519	\N
49414	GENERIC_DAY	1	11	\N	2010-10-22	1128	\N	39519	\N
49415	GENERIC_DAY	1	0	\N	2010-09-26	1128	\N	39519	\N
49416	GENERIC_DAY	1	0	\N	2010-10-31	1130	\N	39519	\N
49417	GENERIC_DAY	1	0	\N	2010-09-26	1130	\N	39519	\N
49418	GENERIC_DAY	1	11	\N	2010-09-28	1126	\N	39519	\N
49419	GENERIC_DAY	1	11	\N	2010-09-20	1130	\N	39519	\N
49420	GENERIC_DAY	1	10	\N	2010-09-01	1126	\N	39519	\N
49421	GENERIC_DAY	1	11	\N	2010-09-03	1130	\N	39519	\N
49422	GENERIC_DAY	1	11	\N	2010-08-19	1128	\N	39519	\N
49423	GENERIC_DAY	1	11	\N	2010-08-11	1126	\N	39519	\N
49424	GENERIC_DAY	1	11	\N	2010-08-11	1130	\N	39519	\N
49425	GENERIC_DAY	1	11	\N	2010-09-30	1128	\N	39519	\N
49426	GENERIC_DAY	1	11	\N	2010-08-12	1126	\N	39519	\N
49427	GENERIC_DAY	1	0	\N	2010-08-29	1128	\N	39519	\N
49428	GENERIC_DAY	1	11	\N	2010-11-02	1126	\N	39519	\N
49429	GENERIC_DAY	1	11	\N	2010-09-15	1126	\N	39519	\N
49430	GENERIC_DAY	1	11	\N	2010-10-19	1128	\N	39519	\N
49431	GENERIC_DAY	1	10	\N	2010-09-03	1126	\N	39519	\N
49432	GENERIC_DAY	1	0	\N	2010-10-31	1128	\N	39519	\N
49433	GENERIC_DAY	1	11	\N	2010-08-24	1130	\N	39519	\N
49434	GENERIC_DAY	1	11	\N	2010-10-06	1126	\N	39519	\N
49435	GENERIC_DAY	1	10	\N	2010-10-11	1130	\N	39519	\N
49436	GENERIC_DAY	1	0	\N	2010-09-05	1126	\N	39519	\N
49437	GENERIC_DAY	1	0	\N	2010-10-24	1128	\N	39519	\N
49438	GENERIC_DAY	1	11	\N	2010-09-29	1126	\N	39519	\N
49439	GENERIC_DAY	1	10	\N	2010-09-28	1130	\N	39519	\N
49440	GENERIC_DAY	1	11	\N	2010-10-11	1126	\N	39519	\N
49441	GENERIC_DAY	1	11	\N	2010-10-21	1126	\N	39519	\N
49442	GENERIC_DAY	1	10	\N	2010-08-16	1128	\N	39519	\N
49443	GENERIC_DAY	1	10	\N	2010-10-29	1130	\N	39519	\N
49444	GENERIC_DAY	1	0	\N	2010-08-21	1126	\N	39519	\N
49445	GENERIC_DAY	1	11	\N	2010-08-23	1130	\N	39519	\N
49446	GENERIC_DAY	1	10	\N	2010-10-15	1130	\N	39519	\N
49447	GENERIC_DAY	1	10	\N	2010-08-26	1126	\N	39519	\N
49448	GENERIC_DAY	1	11	\N	2010-10-25	1128	\N	39519	\N
49449	GENERIC_DAY	1	10	\N	2010-10-20	1130	\N	39519	\N
49450	GENERIC_DAY	1	11	\N	2010-08-16	1126	\N	39519	\N
49451	GENERIC_DAY	1	0	\N	2010-10-10	1130	\N	39519	\N
49452	GENERIC_DAY	1	0	\N	2010-08-08	1126	\N	39519	\N
49453	GENERIC_DAY	1	10	\N	2010-10-08	1130	\N	39519	\N
49454	GENERIC_DAY	1	6	\N	2010-11-05	1126	\N	39519	\N
49455	GENERIC_DAY	1	0	\N	2010-10-30	1126	\N	39519	\N
49456	GENERIC_DAY	1	5	\N	2010-11-05	1128	\N	39519	\N
49457	GENERIC_DAY	1	11	\N	2010-08-26	1130	\N	39519	\N
49458	GENERIC_DAY	1	10	\N	2010-08-27	1126	\N	39519	\N
49459	GENERIC_DAY	1	10	\N	2010-08-24	1126	\N	39519	\N
49460	GENERIC_DAY	1	10	\N	2010-10-01	1130	\N	39519	\N
49461	GENERIC_DAY	1	11	\N	2010-10-19	1126	\N	39519	\N
49462	GENERIC_DAY	1	0	\N	2010-09-04	1126	\N	39519	\N
49463	GENERIC_DAY	1	11	\N	2010-09-01	1130	\N	39519	\N
49464	GENERIC_DAY	1	0	\N	2010-10-16	1128	\N	39519	\N
49465	GENERIC_DAY	1	0	\N	2010-08-14	1128	\N	39519	\N
49466	GENERIC_DAY	1	11	\N	2010-09-16	1126	\N	39519	\N
49467	GENERIC_DAY	1	11	\N	2010-11-03	1126	\N	39519	\N
49468	GENERIC_DAY	1	0	\N	2010-09-12	1130	\N	39519	\N
49469	GENERIC_DAY	1	11	\N	2010-08-12	1130	\N	39519	\N
49470	GENERIC_DAY	1	0	\N	2010-10-16	1126	\N	39519	\N
49471	GENERIC_DAY	1	11	\N	2010-08-25	1130	\N	39519	\N
49472	GENERIC_DAY	1	10	\N	2010-10-13	1130	\N	39519	\N
49473	GENERIC_DAY	1	0	\N	2010-10-17	1126	\N	39519	\N
49474	GENERIC_DAY	1	11	\N	2010-10-21	1128	\N	39519	\N
49475	GENERIC_DAY	1	11	\N	2010-09-02	1130	\N	39519	\N
49476	GENERIC_DAY	1	11	\N	2010-08-10	1126	\N	39519	\N
49477	GENERIC_DAY	1	0	\N	2010-09-05	1128	\N	39519	\N
27850	GENERIC_DAY	3	3	\N	2010-06-18	1134	\N	27675	\N
27875	GENERIC_DAY	3	0	\N	2010-06-19	1132	\N	27675	\N
27880	GENERIC_DAY	3	2	\N	2010-06-10	1136	\N	27675	\N
27834	GENERIC_DAY	3	3	\N	2010-06-25	1132	\N	27675	\N
27833	GENERIC_DAY	3	3	\N	2010-06-15	1134	\N	27675	\N
27857	GENERIC_DAY	3	0	\N	2010-06-26	1136	\N	27675	\N
27832	GENERIC_DAY	3	3	\N	2010-06-23	1134	\N	27675	\N
27856	GENERIC_DAY	3	2	\N	2010-06-21	1136	\N	27675	\N
27868	GENERIC_DAY	3	3	\N	2010-06-14	1134	\N	27675	\N
27853	GENERIC_DAY	3	3	\N	2010-06-22	1132	\N	27675	\N
27866	GENERIC_DAY	3	2	\N	2010-06-25	1136	\N	27675	\N
27882	GENERIC_DAY	3	0	\N	2010-06-13	1136	\N	27675	\N
27885	GENERIC_DAY	3	2	\N	2010-06-11	1136	\N	27675	\N
27855	GENERIC_DAY	3	1	\N	2010-06-28	1136	\N	27675	\N
27858	GENERIC_DAY	3	0	\N	2010-06-27	1134	\N	27675	\N
27845	GENERIC_DAY	3	0	\N	2010-06-19	1136	\N	27675	\N
27778	GENERIC_DAY	3	2	\N	2010-06-25	1130	\N	27674	\N
27804	GENERIC_DAY	3	1	\N	2010-06-28	1130	\N	27674	\N
27788	GENERIC_DAY	3	2	\N	2010-06-22	1130	\N	27674	\N
27825	GENERIC_DAY	3	2	\N	2010-06-18	1130	\N	27674	\N
27784	GENERIC_DAY	3	3	\N	2010-06-23	1128	\N	27674	\N
27808	GENERIC_DAY	3	3	\N	2010-06-25	1128	\N	27674	\N
27795	GENERIC_DAY	3	3	\N	2010-06-11	1128	\N	27674	\N
27811	GENERIC_DAY	3	3	\N	2010-06-16	1126	\N	27674	\N
27827	GENERIC_DAY	3	0	\N	2010-06-20	1126	\N	27674	\N
27822	GENERIC_DAY	3	0	\N	2010-06-12	1128	\N	27674	\N
27798	GENERIC_DAY	3	0	\N	2010-06-20	1130	\N	27674	\N
27802	GENERIC_DAY	3	2	\N	2010-06-23	1130	\N	27674	\N
27819	GENERIC_DAY	3	2	\N	2010-06-14	1130	\N	27674	\N
27777	GENERIC_DAY	3	3	\N	2010-06-17	1128	\N	27674	\N
27809	GENERIC_DAY	3	2	\N	2010-06-16	1130	\N	27674	\N
27829	GENERIC_DAY	3	0	\N	2010-06-19	1128	\N	27674	\N
27826	GENERIC_DAY	3	2	\N	2010-06-15	1130	\N	27674	\N
27831	GENERIC_DAY	3	3	\N	2010-06-24	1126	\N	27674	\N
27794	GENERIC_DAY	3	3	\N	2010-06-15	1126	\N	27674	\N
27799	GENERIC_DAY	3	0	\N	2010-06-12	1126	\N	27674	\N
27813	GENERIC_DAY	3	2	\N	2010-06-11	1130	\N	27674	\N
27821	GENERIC_DAY	3	1	\N	2010-06-28	1128	\N	27674	\N
27779	GENERIC_DAY	3	0	\N	2010-06-13	1128	\N	27674	\N
27781	GENERIC_DAY	3	0	\N	2010-06-26	1130	\N	27674	\N
27803	GENERIC_DAY	3	2	\N	2010-06-21	1130	\N	27674	\N
27776	GENERIC_DAY	3	0	\N	2010-06-19	1130	\N	27674	\N
27830	GENERIC_DAY	3	3	\N	2010-06-14	1128	\N	27674	\N
27787	GENERIC_DAY	3	0	\N	2010-06-13	1126	\N	27674	\N
27796	GENERIC_DAY	3	3	\N	2010-06-22	1126	\N	27674	\N
27786	GENERIC_DAY	3	2	\N	2010-06-28	1126	\N	27674	\N
27812	GENERIC_DAY	3	3	\N	2010-06-24	1128	\N	27674	\N
27824	GENERIC_DAY	3	0	\N	2010-06-12	1130	\N	27674	\N
27782	GENERIC_DAY	3	3	\N	2010-06-18	1128	\N	27674	\N
27818	GENERIC_DAY	3	3	\N	2010-06-21	1128	\N	27674	\N
27791	GENERIC_DAY	3	3	\N	2010-06-10	1128	\N	27674	\N
27806	GENERIC_DAY	3	3	\N	2010-06-10	1126	\N	27674	\N
27815	GENERIC_DAY	3	3	\N	2010-06-11	1126	\N	27674	\N
27823	GENERIC_DAY	3	2	\N	2010-06-24	1130	\N	27674	\N
27797	GENERIC_DAY	3	3	\N	2010-06-18	1126	\N	27674	\N
27775	GENERIC_DAY	3	0	\N	2010-06-26	1128	\N	27674	\N
27816	GENERIC_DAY	3	0	\N	2010-06-20	1128	\N	27674	\N
27820	GENERIC_DAY	3	0	\N	2010-06-19	1126	\N	27674	\N
27807	GENERIC_DAY	3	0	\N	2010-06-27	1130	\N	27674	\N
27801	GENERIC_DAY	3	2	\N	2010-06-17	1130	\N	27674	\N
27783	GENERIC_DAY	3	3	\N	2010-06-23	1126	\N	27674	\N
27785	GENERIC_DAY	3	3	\N	2010-06-17	1126	\N	27674	\N
27789	GENERIC_DAY	3	3	\N	2010-06-16	1128	\N	27674	\N
27790	GENERIC_DAY	3	0	\N	2010-06-26	1126	\N	27674	\N
27810	GENERIC_DAY	3	3	\N	2010-06-14	1126	\N	27674	\N
27792	GENERIC_DAY	3	0	\N	2010-06-27	1126	\N	27674	\N
27780	GENERIC_DAY	3	0	\N	2010-06-13	1130	\N	27674	\N
27805	GENERIC_DAY	3	0	\N	2010-06-27	1128	\N	27674	\N
27814	GENERIC_DAY	3	3	\N	2010-06-15	1128	\N	27674	\N
27828	GENERIC_DAY	3	3	\N	2010-06-21	1126	\N	27674	\N
27817	GENERIC_DAY	3	3	\N	2010-06-25	1126	\N	27674	\N
27800	GENERIC_DAY	3	3	\N	2010-06-22	1128	\N	27674	\N
27793	GENERIC_DAY	3	2	\N	2010-06-10	1130	\N	27674	\N
47055	GENERIC_DAY	2	11	\N	2010-08-20	1130	\N	39509	\N
46979	GENERIC_DAY	2	11	\N	2010-08-23	1126	\N	39509	\N
47194	GENERIC_DAY	2	0	\N	2010-08-14	1128	\N	39509	\N
47060	GENERIC_DAY	2	11	\N	2010-07-21	1126	\N	39509	\N
47021	GENERIC_DAY	2	0	\N	2010-07-03	1130	\N	39509	\N
47127	GENERIC_DAY	2	11	\N	2010-08-04	1128	\N	39509	\N
47171	GENERIC_DAY	2	0	\N	2010-07-31	1126	\N	39509	\N
47157	GENERIC_DAY	2	0	\N	2010-08-21	1128	\N	39509	\N
47007	GENERIC_DAY	2	0	\N	2010-08-28	1126	\N	39509	\N
47150	GENERIC_DAY	2	0	\N	2010-08-22	1128	\N	39509	\N
46974	GENERIC_DAY	2	10	\N	2010-08-23	1128	\N	39509	\N
47218	GENERIC_DAY	2	11	\N	2010-08-17	1126	\N	39509	\N
47109	GENERIC_DAY	2	10	\N	2010-07-07	1130	\N	39509	\N
47180	GENERIC_DAY	2	0	\N	2010-08-01	1130	\N	39509	\N
47208	GENERIC_DAY	2	5	\N	2010-09-23	1128	\N	39509	\N
46983	GENERIC_DAY	2	0	\N	2010-08-08	1130	\N	39509	\N
47074	GENERIC_DAY	2	10	\N	2010-07-19	1130	\N	39509	\N
47201	GENERIC_DAY	2	11	\N	2010-08-18	1130	\N	39509	\N
47099	GENERIC_DAY	2	0	\N	2010-08-29	1128	\N	39509	\N
47011	GENERIC_DAY	2	0	\N	2010-09-18	1130	\N	39509	\N
47200	GENERIC_DAY	2	11	\N	2010-08-12	1128	\N	39509	\N
46993	GENERIC_DAY	2	11	\N	2010-09-22	1128	\N	39509	\N
47156	GENERIC_DAY	2	11	\N	2010-09-16	1126	\N	39509	\N
47181	GENERIC_DAY	2	11	\N	2010-08-25	1130	\N	39509	\N
47175	GENERIC_DAY	2	10	\N	2010-08-25	1128	\N	39509	\N
47070	GENERIC_DAY	2	11	\N	2010-09-21	1128	\N	39509	\N
47182	GENERIC_DAY	2	10	\N	2010-07-02	1130	\N	39509	\N
46999	GENERIC_DAY	2	0	\N	2010-08-07	1128	\N	39509	\N
47113	GENERIC_DAY	2	0	\N	2010-07-11	1126	\N	39509	\N
47049	GENERIC_DAY	2	10	\N	2010-08-26	1128	\N	39509	\N
47135	GENERIC_DAY	2	10	\N	2010-08-12	1130	\N	39509	\N
47075	GENERIC_DAY	2	10	\N	2010-09-09	1128	\N	39509	\N
46984	GENERIC_DAY	2	11	\N	2010-08-06	1128	\N	39509	\N
47117	GENERIC_DAY	2	11	\N	2010-09-17	1126	\N	39509	\N
47222	GENERIC_DAY	2	0	\N	2010-09-12	1126	\N	39509	\N
47003	GENERIC_DAY	2	0	\N	2010-07-17	1128	\N	39509	\N
47225	GENERIC_DAY	2	11	\N	2010-08-27	1130	\N	39509	\N
47130	GENERIC_DAY	2	10	\N	2010-09-08	1128	\N	39509	\N
47152	GENERIC_DAY	2	0	\N	2010-09-05	1128	\N	39509	\N
46989	GENERIC_DAY	2	0	\N	2010-09-18	1126	\N	39509	\N
47178	GENERIC_DAY	2	10	\N	2010-08-16	1130	\N	39509	\N
47081	GENERIC_DAY	2	11	\N	2010-08-11	1128	\N	39509	\N
47198	GENERIC_DAY	2	0	\N	2010-09-12	1130	\N	39509	\N
47132	GENERIC_DAY	2	11	\N	2010-07-02	1126	\N	39509	\N
47035	GENERIC_DAY	2	0	\N	2010-08-22	1130	\N	39509	\N
47093	GENERIC_DAY	2	11	\N	2010-09-17	1128	\N	39509	\N
47072	GENERIC_DAY	2	11	\N	2010-07-01	1126	\N	39509	\N
47045	GENERIC_DAY	2	11	\N	2010-07-28	1126	\N	39509	\N
47086	GENERIC_DAY	2	0	\N	2010-09-19	1126	\N	39509	\N
47031	GENERIC_DAY	2	11	\N	2010-07-27	1128	\N	39509	\N
46998	GENERIC_DAY	2	10	\N	2010-07-20	1130	\N	39509	\N
47177	GENERIC_DAY	2	10	\N	2010-07-16	1130	\N	39509	\N
47103	GENERIC_DAY	2	11	\N	2010-09-06	1130	\N	39509	\N
47073	GENERIC_DAY	2	0	\N	2010-07-25	1128	\N	39509	\N
47091	GENERIC_DAY	2	10	\N	2010-07-22	1130	\N	39509	\N
46975	GENERIC_DAY	2	11	\N	2010-08-11	1126	\N	39509	\N
47215	GENERIC_DAY	2	10	\N	2010-08-19	1128	\N	39509	\N
3848009	GENERIC_DAY	1	1	t	2010-03-24	3513187	\N	3511787	\N
3847985	GENERIC_DAY	1	1	t	2010-03-30	3513187	\N	3511787	\N
3847976	GENERIC_DAY	1	1	t	2010-04-16	3513187	\N	3511787	\N
3847928	GENERIC_DAY	1	1	t	2010-03-08	3513187	\N	3511787	\N
3847992	GENERIC_DAY	1	1	t	2010-05-17	3513187	\N	3511787	\N
3847998	GENERIC_DAY	1	1	t	2010-04-12	3513187	\N	3511787	\N
3848008	GENERIC_DAY	1	2	f	2010-06-10	3513187	\N	3511787	\N
3847969	GENERIC_DAY	1	1	t	2010-05-20	3513187	\N	3511787	\N
3847966	GENERIC_DAY	1	1	t	2010-04-28	3513187	\N	3511787	\N
3847972	GENERIC_DAY	1	1	t	2010-03-16	3513187	\N	3511787	\N
3848004	GENERIC_DAY	1	1	t	2010-04-01	3513187	\N	3511787	\N
3847993	GENERIC_DAY	1	1	t	2010-05-04	3513187	\N	3511787	\N
3847990	GENERIC_DAY	1	1	t	2010-04-19	3513187	\N	3511787	\N
3847977	GENERIC_DAY	1	1	t	2010-04-07	3513187	\N	3511787	\N
3847952	GENERIC_DAY	1	1	t	2010-04-27	3513187	\N	3511787	\N
3848013	GENERIC_DAY	1	1	f	2010-07-05	3513187	\N	3511787	\N
3847930	GENERIC_DAY	1	2	f	2010-06-29	3513187	\N	3511787	\N
3847954	GENERIC_DAY	1	1	t	2010-05-10	3513187	\N	3511787	\N
3847983	GENERIC_DAY	1	1	t	2010-05-26	3513187	\N	3511787	\N
3847944	GENERIC_DAY	1	1	f	2010-07-09	3513187	\N	3511787	\N
3847926	GENERIC_DAY	1	1	t	2010-03-19	3513187	\N	3511787	\N
3847932	GENERIC_DAY	1	1	f	2010-07-07	3513187	\N	3511787	\N
3847957	GENERIC_DAY	1	1	t	2010-03-12	3513187	\N	3511787	\N
3848011	GENERIC_DAY	1	2	f	2010-06-24	3513187	\N	3511787	\N
3847999	GENERIC_DAY	1	1	t	2010-05-06	3513187	\N	3511787	\N
3847945	GENERIC_DAY	1	1	t	2010-04-14	3513187	\N	3511787	\N
3847987	GENERIC_DAY	1	1	t	2010-03-11	3513187	\N	3511787	\N
3847946	GENERIC_DAY	1	2	f	2010-06-21	3513187	\N	3511787	\N
3847988	GENERIC_DAY	1	2	f	2010-06-23	3513187	\N	3511787	\N
3848007	GENERIC_DAY	1	1	t	2010-03-10	3513187	\N	3511787	\N
3847947	GENERIC_DAY	1	1	t	2010-05-13	3513187	\N	3511787	\N
3847937	GENERIC_DAY	1	1	t	2010-04-21	3513187	\N	3511787	\N
3847935	GENERIC_DAY	1	1	t	2010-04-02	3513187	\N	3511787	\N
3847936	GENERIC_DAY	1	1	t	2010-05-25	3513187	\N	3511787	\N
3847961	GENERIC_DAY	1	1	t	2010-04-05	3513187	\N	3511787	\N
3848001	GENERIC_DAY	1	1	t	2010-05-19	3513187	\N	3511787	\N
3847938	GENERIC_DAY	1	1	t	2010-03-18	3513187	\N	3511787	\N
3847939	GENERIC_DAY	1	1	t	2010-05-12	3513187	\N	3511787	\N
3847979	GENERIC_DAY	1	1	t	2010-04-29	3513187	\N	3511787	\N
3847963	GENERIC_DAY	1	1	t	2010-05-28	3513187	\N	3511787	\N
3847981	GENERIC_DAY	1	1	t	2010-04-15	3513187	\N	3511787	\N
3847951	GENERIC_DAY	1	1	f	2010-07-08	3513187	\N	3511787	\N
3847997	GENERIC_DAY	1	1	t	2010-04-13	3513187	\N	3511787	\N
3847927	GENERIC_DAY	1	2	f	2010-06-11	3513187	\N	3511787	\N
3847986	GENERIC_DAY	1	1	t	2010-03-29	3513187	\N	3511787	\N
3847955	GENERIC_DAY	1	1	t	2010-05-27	3513187	\N	3511787	\N
3848000	GENERIC_DAY	1	2	f	2010-06-17	3513187	\N	3511787	\N
3847950	GENERIC_DAY	1	1	t	2010-06-07	3513187	\N	3511787	\N
3847959	GENERIC_DAY	1	1	t	2010-04-30	3513187	\N	3511787	\N
3847974	GENERIC_DAY	1	1	t	2010-06-02	3513187	\N	3511787	\N
3847980	GENERIC_DAY	1	2	f	2010-06-30	3513187	\N	3511787	\N
3847975	GENERIC_DAY	1	2	f	2010-06-18	3513187	\N	3511787	\N
3847941	GENERIC_DAY	1	1	t	2010-05-14	3513187	\N	3511787	\N
3847931	GENERIC_DAY	1	1	t	2010-04-26	3513187	\N	3511787	\N
3847962	GENERIC_DAY	1	1	t	2010-05-03	3513187	\N	3511787	\N
3848002	GENERIC_DAY	1	1	t	2010-04-22	3513187	\N	3511787	\N
3847948	GENERIC_DAY	1	1	t	2010-04-20	3513187	\N	3511787	\N
3847933	GENERIC_DAY	1	1	t	2010-04-09	3513187	\N	3511787	\N
3848005	GENERIC_DAY	1	1	t	2010-04-23	3513187	\N	3511787	\N
3848003	GENERIC_DAY	1	1	t	2010-03-23	3513187	\N	3511787	\N
3847973	GENERIC_DAY	1	1	t	2010-05-05	3513187	\N	3511787	\N
3847995	GENERIC_DAY	1	1	t	2010-03-17	3513187	\N	3511787	\N
3847956	GENERIC_DAY	1	2	f	2010-06-09	3513187	\N	3511787	\N
3847964	GENERIC_DAY	1	1	t	2010-05-07	3513187	\N	3511787	\N
3848014	GENERIC_DAY	1	1	t	2010-03-25	3513187	\N	3511787	\N
3847949	GENERIC_DAY	1	1	t	2010-05-31	3513187	\N	3511787	\N
3847996	GENERIC_DAY	1	1	t	2010-05-21	3513187	\N	3511787	\N
3847960	GENERIC_DAY	1	1	f	2010-07-06	3513187	\N	3511787	\N
3847967	GENERIC_DAY	1	2	f	2010-06-28	3513187	\N	3511787	\N
3847958	GENERIC_DAY	1	1	t	2010-03-31	3513187	\N	3511787	\N
3848010	GENERIC_DAY	1	1	t	2010-05-11	3513187	\N	3511787	\N
3847994	GENERIC_DAY	1	1	t	2010-06-04	3513187	\N	3511787	\N
3847984	GENERIC_DAY	1	1	t	2010-04-06	3513187	\N	3511787	\N
3847978	GENERIC_DAY	1	1	t	2010-04-08	3513187	\N	3511787	\N
3847943	GENERIC_DAY	1	1	t	2010-06-01	3513187	\N	3511787	\N
3848006	GENERIC_DAY	1	2	f	2010-06-15	3513187	\N	3511787	\N
3847942	GENERIC_DAY	1	1	t	2010-06-03	3513187	\N	3511787	\N
3847940	GENERIC_DAY	1	2	f	2010-06-16	3513187	\N	3511787	\N
3847968	GENERIC_DAY	1	2	f	2010-06-25	3513187	\N	3511787	\N
3847991	GENERIC_DAY	1	1	t	2010-03-22	3513187	\N	3511787	\N
3847953	GENERIC_DAY	1	1	t	2010-03-15	3513187	\N	3511787	\N
3847989	GENERIC_DAY	1	2	f	2010-07-01	3513187	\N	3511787	\N
3848012	GENERIC_DAY	1	1	t	2010-05-18	3513187	\N	3511787	\N
3847965	GENERIC_DAY	1	1	t	2010-03-09	3513187	\N	3511787	\N
3847934	GENERIC_DAY	1	1	t	2010-03-26	3513187	\N	3511787	\N
3847925	GENERIC_DAY	1	1	t	2010-05-24	3513187	\N	3511787	\N
3847929	GENERIC_DAY	1	1	t	2010-06-08	3513187	\N	3511787	\N
3847982	GENERIC_DAY	1	2	f	2010-06-14	3513187	\N	3511787	\N
3847971	GENERIC_DAY	1	2	f	2010-06-22	3513187	\N	3511787	\N
3847970	GENERIC_DAY	1	1	f	2010-07-02	3513187	\N	3511787	\N
3515162	GENERIC_DAY	29	1	\N	2010-09-24	3513187	\N	3511790	\N
3515105	GENERIC_DAY	29	1	\N	2010-05-26	3513187	\N	3511790	\N
3515136	GENERIC_DAY	29	1	\N	2010-07-29	3513187	\N	3511790	\N
3515166	GENERIC_DAY	29	1	\N	2010-05-28	3513187	\N	3511790	\N
3774295	GENERIC_DAY	7	2	\N	2010-06-14	3513197	\N	3766828	\N
3774309	GENERIC_DAY	7	2	\N	2010-06-01	3513197	\N	3766828	\N
3774289	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766828	\N
3774341	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766828	\N
3774298	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766828	\N
3774287	GENERIC_DAY	7	1	\N	2010-06-23	3513197	\N	3766828	\N
3774344	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766828	\N
3774302	GENERIC_DAY	7	2	\N	2010-06-09	3513197	\N	3766828	\N
3774357	GENERIC_DAY	7	1	\N	2010-06-24	3513197	\N	3766828	\N
3774374	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766829	\N
3774403	GENERIC_DAY	7	1	\N	2010-06-11	3513197	\N	3766829	\N
3774417	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766829	\N
3774425	GENERIC_DAY	7	2	\N	2010-05-27	3513197	\N	3766829	\N
3774443	GENERIC_DAY	7	2	\N	2010-05-26	3513197	\N	3766829	\N
3774382	GENERIC_DAY	7	1	\N	2010-06-14	3513197	\N	3766829	\N
3774391	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766829	\N
3774377	GENERIC_DAY	7	1	\N	2010-06-09	3513197	\N	3766829	\N
3774399	GENERIC_DAY	7	1	\N	2010-09-17	3513197	\N	3766829	\N
3774390	GENERIC_DAY	7	1	\N	2010-06-24	3513197	\N	3766829	\N
3774427	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766829	\N
3774371	GENERIC_DAY	7	1	\N	2010-06-29	3513197	\N	3766829	\N
3774438	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766829	\N
3774436	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766829	\N
3774440	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766829	\N
3774365	GENERIC_DAY	7	1	\N	2010-09-21	3513197	\N	3766829	\N
3774452	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766829	\N
3774451	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766829	\N
3774370	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766829	\N
3774362	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766829	\N
3774383	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766829	\N
3774385	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766829	\N
3774400	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766829	\N
3774429	GENERIC_DAY	7	1	\N	2010-09-24	3513197	\N	3766829	\N
3774423	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766829	\N
3774409	GENERIC_DAY	7	1	\N	2010-06-28	3513197	\N	3766829	\N
3774364	GENERIC_DAY	7	1	\N	2010-09-13	3513197	\N	3766829	\N
3774394	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766829	\N
3774415	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766829	\N
3774437	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766829	\N
3774448	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766829	\N
3774446	GENERIC_DAY	7	1	\N	2010-06-18	3513197	\N	3766829	\N
3774428	GENERIC_DAY	7	2	\N	2010-05-28	3513197	\N	3766829	\N
3774416	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766829	\N
3774418	GENERIC_DAY	7	1	\N	2010-09-22	3513197	\N	3766829	\N
3774419	GENERIC_DAY	7	1	\N	2010-06-23	3513197	\N	3766829	\N
3774389	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766829	\N
3774380	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766829	\N
3774432	GENERIC_DAY	7	1	\N	2010-06-03	3513197	\N	3766829	\N
3774442	GENERIC_DAY	7	2	\N	2010-05-31	3513197	\N	3766829	\N
3774397	GENERIC_DAY	7	1	\N	2010-06-17	3513197	\N	3766829	\N
3774373	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766829	\N
3774404	GENERIC_DAY	7	1	\N	2010-06-15	3513197	\N	3766829	\N
3774445	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766829	\N
3774414	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766829	\N
3774405	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766829	\N
3774379	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766829	\N
3774381	GENERIC_DAY	7	1	\N	2010-06-16	3513197	\N	3766829	\N
3774420	GENERIC_DAY	7	1	\N	2010-06-07	3513197	\N	3766829	\N
3774384	GENERIC_DAY	7	1	\N	2010-09-23	3513197	\N	3766829	\N
3774430	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766829	\N
3774421	GENERIC_DAY	7	1	\N	2010-06-02	3513197	\N	3766829	\N
3774402	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766829	\N
3774375	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766829	\N
3774367	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766829	\N
3774441	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766829	\N
3774450	GENERIC_DAY	7	2	\N	2010-06-01	3513197	\N	3766829	\N
3774386	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766829	\N
3774426	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766829	\N
3774447	GENERIC_DAY	7	1	\N	2010-09-29	3513197	\N	3766829	\N
3774434	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766829	\N
3774424	GENERIC_DAY	7	1	\N	2010-09-16	3513197	\N	3766829	\N
3774378	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766829	\N
3774435	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766829	\N
3774368	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766829	\N
3774408	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766829	\N
3774388	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766829	\N
3774398	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766829	\N
3774422	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766829	\N
3774433	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766829	\N
3774439	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766829	\N
3774406	GENERIC_DAY	7	1	\N	2010-09-20	3513197	\N	3766829	\N
3774363	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766829	\N
3774396	GENERIC_DAY	7	1	\N	2010-06-25	3513197	\N	3766829	\N
3774431	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766829	\N
3774401	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766829	\N
3774376	GENERIC_DAY	7	1	\N	2010-09-27	3513197	\N	3766829	\N
3774387	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766829	\N
3774449	GENERIC_DAY	7	1	\N	2010-09-15	3513197	\N	3766829	\N
3774392	GENERIC_DAY	7	1	\N	2010-06-04	3513197	\N	3766829	\N
3774372	GENERIC_DAY	7	1	\N	2010-06-10	3513197	\N	3766829	\N
3774393	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766829	\N
3774413	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766829	\N
3774407	GENERIC_DAY	7	1	\N	2010-06-08	3513197	\N	3766829	\N
3774410	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766829	\N
3774366	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766829	\N
3774412	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766829	\N
3774369	GENERIC_DAY	7	1	\N	2010-06-22	3513197	\N	3766829	\N
3774411	GENERIC_DAY	7	1	\N	2010-09-28	3513197	\N	3766829	\N
3774395	GENERIC_DAY	7	1	\N	2010-09-14	3513197	\N	3766829	\N
3774444	GENERIC_DAY	7	1	\N	2010-06-21	3513197	\N	3766829	\N
3774530	GENERIC_DAY	7	1	\N	2010-06-04	3513197	\N	3766830	\N
3774507	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766830	\N
3774498	GENERIC_DAY	7	1	\N	2010-06-29	3513197	\N	3766830	\N
3774466	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766830	\N
3774515	GENERIC_DAY	7	1	\N	2010-06-18	3513197	\N	3766830	\N
3774523	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766830	\N
3774504	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766830	\N
3774506	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766830	\N
3774477	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766830	\N
3774500	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766830	\N
3774497	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766830	\N
3774514	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766830	\N
3774488	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766830	\N
3774461	GENERIC_DAY	7	1	\N	2010-05-27	3513197	\N	3766830	\N
3774489	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766830	\N
3774518	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766830	\N
3774460	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766830	\N
3774493	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766830	\N
3774491	GENERIC_DAY	7	1	\N	2010-06-28	3513197	\N	3766830	\N
3774473	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766830	\N
3774513	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766830	\N
3774474	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766830	\N
3774529	GENERIC_DAY	7	1	\N	2010-05-28	3513197	\N	3766830	\N
3774483	GENERIC_DAY	7	1	\N	2010-05-26	3513197	\N	3766830	\N
3774455	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766830	\N
3774459	GENERIC_DAY	7	1	\N	2010-06-15	3513197	\N	3766830	\N
3774496	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766830	\N
3774487	GENERIC_DAY	7	1	\N	2010-05-31	3513197	\N	3766830	\N
3774516	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766830	\N
3774527	GENERIC_DAY	7	1	\N	2010-06-21	3513197	\N	3766830	\N
3774476	GENERIC_DAY	7	1	\N	2010-06-17	3513197	\N	3766830	\N
3774511	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766830	\N
3774469	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766830	\N
3774465	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766830	\N
3774457	GENERIC_DAY	7	1	\N	2010-06-25	3513197	\N	3766830	\N
3774526	GENERIC_DAY	7	1	\N	2010-06-02	3513197	\N	3766830	\N
3774517	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766830	\N
3774521	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766830	\N
3774478	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766830	\N
3774480	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766830	\N
3774490	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766830	\N
3774520	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766830	\N
3774502	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766830	\N
3774528	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766830	\N
3774468	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766830	\N
3774467	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766830	\N
3774492	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766830	\N
3774505	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766830	\N
3774522	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766830	\N
3774456	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766830	\N
3774485	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766830	\N
3774454	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766830	\N
3774495	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766830	\N
3774494	GENERIC_DAY	7	1	\N	2010-06-07	3513197	\N	3766830	\N
3774510	GENERIC_DAY	7	1	\N	2010-06-08	3513197	\N	3766830	\N
3774525	GENERIC_DAY	7	1	\N	2010-06-11	3513197	\N	3766830	\N
3774458	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766830	\N
3774482	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766830	\N
3774512	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766830	\N
3774472	GENERIC_DAY	7	1	\N	2010-06-01	3513197	\N	3766830	\N
3774519	GENERIC_DAY	7	1	\N	2010-06-03	3513197	\N	3766830	\N
3774464	GENERIC_DAY	7	1	\N	2010-06-09	3513197	\N	3766830	\N
3774499	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766830	\N
3774484	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766830	\N
3774470	GENERIC_DAY	7	1	\N	2010-06-10	3513197	\N	3766830	\N
3774503	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766830	\N
3774462	GENERIC_DAY	7	1	\N	2010-06-23	3513197	\N	3766830	\N
3774524	GENERIC_DAY	7	1	\N	2010-06-22	3513197	\N	3766830	\N
3774501	GENERIC_DAY	7	1	\N	2010-06-14	3513197	\N	3766830	\N
3774475	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766830	\N
3774453	GENERIC_DAY	7	1	\N	2010-06-24	3513197	\N	3766830	\N
3774508	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766830	\N
3774463	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766830	\N
3774481	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766830	\N
3774486	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766830	\N
3774471	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766830	\N
3774479	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766830	\N
3774509	GENERIC_DAY	7	1	\N	2010-06-16	3513197	\N	3766830	\N
3774557	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766831	\N
3774582	GENERIC_DAY	7	1	\N	2010-06-28	3513197	\N	3766831	\N
3774598	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766831	\N
3774561	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766831	\N
3774587	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766831	\N
3774617	GENERIC_DAY	7	1	\N	2010-06-29	3513197	\N	3766831	\N
3774531	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766831	\N
3774586	GENERIC_DAY	7	1	\N	2010-06-09	3513197	\N	3766831	\N
3774570	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766831	\N
3774610	GENERIC_DAY	7	1	\N	2010-06-07	3513197	\N	3766831	\N
3774555	GENERIC_DAY	7	1	\N	2010-09-27	3513197	\N	3766831	\N
3774611	GENERIC_DAY	7	1	\N	2010-09-23	3513197	\N	3766831	\N
3774578	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766831	\N
3774532	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766831	\N
3774550	GENERIC_DAY	7	1	\N	2010-06-16	3513197	\N	3766831	\N
3774565	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766831	\N
3774601	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766831	\N
3774554	GENERIC_DAY	7	1	\N	2010-06-15	3513197	\N	3766831	\N
3774556	GENERIC_DAY	7	1	\N	2010-09-17	3513197	\N	3766831	\N
3774568	GENERIC_DAY	7	1	\N	2010-09-14	3513197	\N	3766831	\N
3774581	GENERIC_DAY	7	1	\N	2010-09-22	3513197	\N	3766831	\N
3774583	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766831	\N
3774559	GENERIC_DAY	7	1	\N	2010-09-28	3513197	\N	3766831	\N
3774579	GENERIC_DAY	7	1	\N	2010-06-18	3513197	\N	3766831	\N
3774595	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766831	\N
3774534	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766831	\N
3774538	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766831	\N
3774594	GENERIC_DAY	7	1	\N	2010-06-25	3513197	\N	3766831	\N
3774543	GENERIC_DAY	7	1	\N	2010-06-04	3513197	\N	3766831	\N
3774566	GENERIC_DAY	7	1	\N	2010-09-15	3513197	\N	3766831	\N
3774590	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766831	\N
3774562	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766831	\N
3774605	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766831	\N
3774542	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766831	\N
3774571	GENERIC_DAY	7	2	\N	2010-05-28	3513197	\N	3766831	\N
3774612	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766831	\N
3774548	GENERIC_DAY	7	1	\N	2010-06-23	3513197	\N	3766831	\N
3774564	GENERIC_DAY	7	1	\N	2010-06-21	3513197	\N	3766831	\N
3774615	GENERIC_DAY	7	1	\N	2010-09-24	3513197	\N	3766831	\N
3774541	GENERIC_DAY	7	1	\N	2010-09-21	3513197	\N	3766831	\N
3774580	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766831	\N
3774592	GENERIC_DAY	7	1	\N	2010-09-16	3513197	\N	3766831	\N
3774618	GENERIC_DAY	7	2	\N	2010-05-26	3513197	\N	3766831	\N
3774558	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766831	\N
3774574	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766831	\N
3774540	GENERIC_DAY	7	1	\N	2010-06-17	3513197	\N	3766831	\N
3774600	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766831	\N
3774599	GENERIC_DAY	7	1	\N	2010-06-03	3513197	\N	3766831	\N
3774603	GENERIC_DAY	7	1	\N	2010-06-14	3513197	\N	3766831	\N
3774608	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766831	\N
3774544	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766831	\N
3774567	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766831	\N
3774613	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766831	\N
3774560	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766831	\N
3774585	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766831	\N
3774588	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766831	\N
3774535	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766831	\N
3774575	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766831	\N
3774572	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766831	\N
3774604	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766831	\N
3774547	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766831	\N
3774606	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766831	\N
3774616	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766831	\N
3774536	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766831	\N
3774620	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766831	\N
3774589	GENERIC_DAY	7	2	\N	2010-06-01	3513197	\N	3766831	\N
3774619	GENERIC_DAY	7	1	\N	2010-09-20	3513197	\N	3766831	\N
3774602	GENERIC_DAY	7	1	\N	2010-09-13	3513197	\N	3766831	\N
3774539	GENERIC_DAY	7	1	\N	2010-06-10	3513197	\N	3766831	\N
3774597	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766831	\N
3774584	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766831	\N
3774621	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766831	\N
3774551	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766831	\N
3774553	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766831	\N
3774593	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766831	\N
3774577	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766831	\N
3774591	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766831	\N
3774607	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766831	\N
3774549	GENERIC_DAY	7	1	\N	2010-06-24	3513197	\N	3766831	\N
3774563	GENERIC_DAY	7	1	\N	2010-06-22	3513197	\N	3766831	\N
3774537	GENERIC_DAY	7	1	\N	2010-09-29	3513197	\N	3766831	\N
3774545	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766831	\N
3774533	GENERIC_DAY	7	1	\N	2010-06-11	3513197	\N	3766831	\N
3774569	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766831	\N
3774576	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766831	\N
3774552	GENERIC_DAY	7	1	\N	2010-06-02	3513197	\N	3766831	\N
3774614	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766831	\N
3774596	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766831	\N
3774546	GENERIC_DAY	7	1	\N	2010-06-08	3513197	\N	3766831	\N
3774609	GENERIC_DAY	7	2	\N	2010-05-27	3513197	\N	3766831	\N
3774573	GENERIC_DAY	7	2	\N	2010-05-31	3513197	\N	3766831	\N
3774626	GENERIC_DAY	7	1	\N	2010-09-29	3513197	\N	3766832	\N
3774685	GENERIC_DAY	7	2	\N	2010-08-18	3513197	\N	3766832	\N
3774687	GENERIC_DAY	7	1	\N	2010-09-23	3513197	\N	3766832	\N
3774625	GENERIC_DAY	7	2	\N	2010-09-14	3513197	\N	3766832	\N
3774676	GENERIC_DAY	7	2	\N	2010-06-01	3513197	\N	3766832	\N
3774664	GENERIC_DAY	7	2	\N	2010-08-02	3513197	\N	3766832	\N
3774670	GENERIC_DAY	7	2	\N	2010-08-30	3513197	\N	3766832	\N
3774666	GENERIC_DAY	7	2	\N	2010-08-04	3513197	\N	3766832	\N
3774663	GENERIC_DAY	7	2	\N	2010-07-21	3513197	\N	3766832	\N
3774709	GENERIC_DAY	7	2	\N	2010-08-24	3513197	\N	3766832	\N
3774704	GENERIC_DAY	7	2	\N	2010-09-07	3513197	\N	3766832	\N
3774683	GENERIC_DAY	7	2	\N	2010-08-03	3513197	\N	3766832	\N
3774698	GENERIC_DAY	7	2	\N	2010-06-15	3513197	\N	3766832	\N
3774710	GENERIC_DAY	7	2	\N	2010-06-23	3513197	\N	3766832	\N
3774640	GENERIC_DAY	7	2	\N	2010-08-31	3513197	\N	3766832	\N
3774651	GENERIC_DAY	7	2	\N	2010-07-23	3513197	\N	3766832	\N
3774706	GENERIC_DAY	7	2	\N	2010-07-13	3513197	\N	3766832	\N
3774662	GENERIC_DAY	7	2	\N	2010-06-24	3513197	\N	3766832	\N
3774677	GENERIC_DAY	7	2	\N	2010-06-30	3513197	\N	3766832	\N
3774623	GENERIC_DAY	7	2	\N	2010-08-11	3513197	\N	3766832	\N
3774696	GENERIC_DAY	7	2	\N	2010-06-21	3513197	\N	3766832	\N
3774702	GENERIC_DAY	7	2	\N	2010-08-16	3513197	\N	3766832	\N
3774705	GENERIC_DAY	7	2	\N	2010-09-16	3513197	\N	3766832	\N
3774678	GENERIC_DAY	7	2	\N	2010-07-02	3513197	\N	3766832	\N
3774691	GENERIC_DAY	7	2	\N	2010-09-02	3513197	\N	3766832	\N
3774629	GENERIC_DAY	7	2	\N	2010-09-15	3513197	\N	3766832	\N
3774653	GENERIC_DAY	7	2	\N	2010-05-31	3513197	\N	3766832	\N
3774694	GENERIC_DAY	7	2	\N	2010-09-10	3513197	\N	3766832	\N
3774692	GENERIC_DAY	7	2	\N	2010-06-28	3513197	\N	3766832	\N
3774669	GENERIC_DAY	7	1	\N	2010-09-28	3513197	\N	3766832	\N
3774628	GENERIC_DAY	7	2	\N	2010-08-26	3513197	\N	3766832	\N
3774661	GENERIC_DAY	7	2	\N	2010-09-08	3513197	\N	3766832	\N
3774672	GENERIC_DAY	7	2	\N	2010-07-07	3513197	\N	3766832	\N
3774689	GENERIC_DAY	7	2	\N	2010-07-28	3513197	\N	3766832	\N
3774647	GENERIC_DAY	7	2	\N	2010-08-06	3513197	\N	3766832	\N
3774682	GENERIC_DAY	7	2	\N	2010-07-27	3513197	\N	3766832	\N
3774707	GENERIC_DAY	7	2	\N	2010-06-22	3513197	\N	3766832	\N
3774643	GENERIC_DAY	7	2	\N	2010-06-17	3513197	\N	3766832	\N
3774667	GENERIC_DAY	7	2	\N	2010-07-19	3513197	\N	3766832	\N
3774634	GENERIC_DAY	7	2	\N	2010-08-20	3513197	\N	3766832	\N
3774632	GENERIC_DAY	7	2	\N	2010-09-17	3513197	\N	3766832	\N
3774654	GENERIC_DAY	7	1	\N	2010-09-27	3513197	\N	3766832	\N
3774631	GENERIC_DAY	7	2	\N	2010-07-08	3513197	\N	3766832	\N
3774686	GENERIC_DAY	7	2	\N	2010-08-13	3513197	\N	3766832	\N
3774636	GENERIC_DAY	7	2	\N	2010-07-20	3513197	\N	3766832	\N
3774635	GENERIC_DAY	7	2	\N	2010-07-01	3513197	\N	3766832	\N
3774644	GENERIC_DAY	7	2	\N	2010-09-06	3513197	\N	3766832	\N
3774630	GENERIC_DAY	7	2	\N	2010-06-08	3513197	\N	3766832	\N
3774637	GENERIC_DAY	7	2	\N	2010-06-18	3513197	\N	3766832	\N
3774650	GENERIC_DAY	7	2	\N	2010-07-22	3513197	\N	3766832	\N
3774675	GENERIC_DAY	7	2	\N	2010-09-03	3513197	\N	3766832	\N
3774642	GENERIC_DAY	7	2	\N	2010-06-14	3513197	\N	3766832	\N
3774701	GENERIC_DAY	7	2	\N	2010-09-01	3513197	\N	3766832	\N
3774695	GENERIC_DAY	7	2	\N	2010-07-05	3513197	\N	3766832	\N
3774657	GENERIC_DAY	7	2	\N	2010-07-15	3513197	\N	3766832	\N
3774680	GENERIC_DAY	7	2	\N	2010-08-17	3513197	\N	3766832	\N
3774708	GENERIC_DAY	7	2	\N	2010-09-21	3513197	\N	3766832	\N
3774703	GENERIC_DAY	7	2	\N	2010-07-06	3513197	\N	3766832	\N
3774649	GENERIC_DAY	7	2	\N	2010-06-10	3513197	\N	3766832	\N
3774674	GENERIC_DAY	7	1	\N	2010-09-22	3513197	\N	3766832	\N
3774699	GENERIC_DAY	7	2	\N	2010-08-19	3513197	\N	3766832	\N
3774638	GENERIC_DAY	7	2	\N	2010-08-27	3513197	\N	3766832	\N
3774711	GENERIC_DAY	7	2	\N	2010-07-29	3513197	\N	3766832	\N
3774693	GENERIC_DAY	7	2	\N	2010-07-09	3513197	\N	3766832	\N
3774671	GENERIC_DAY	7	2	\N	2010-05-27	3513197	\N	3766832	\N
3774688	GENERIC_DAY	7	2	\N	2010-06-03	3513197	\N	3766832	\N
3774690	GENERIC_DAY	7	2	\N	2010-08-12	3513197	\N	3766832	\N
3774639	GENERIC_DAY	7	2	\N	2010-09-20	3513197	\N	3766832	\N
3774679	GENERIC_DAY	7	2	\N	2010-07-14	3513197	\N	3766832	\N
3774697	GENERIC_DAY	7	2	\N	2010-06-09	3513197	\N	3766832	\N
3774700	GENERIC_DAY	7	2	\N	2010-07-12	3513197	\N	3766832	\N
3774712	GENERIC_DAY	7	2	\N	2010-06-07	3513197	\N	3766832	\N
3774624	GENERIC_DAY	7	2	\N	2010-08-23	3513197	\N	3766832	\N
3774659	GENERIC_DAY	7	2	\N	2010-09-09	3513197	\N	3766832	\N
3774641	GENERIC_DAY	7	2	\N	2010-08-25	3513197	\N	3766832	\N
3774668	GENERIC_DAY	7	2	\N	2010-07-26	3513197	\N	3766832	\N
3774660	GENERIC_DAY	7	2	\N	2010-06-25	3513197	\N	3766832	\N
3774622	GENERIC_DAY	7	2	\N	2010-09-13	3513197	\N	3766832	\N
3774645	GENERIC_DAY	7	2	\N	2010-06-29	3513197	\N	3766832	\N
3774684	GENERIC_DAY	7	2	\N	2010-07-30	3513197	\N	3766832	\N
3774646	GENERIC_DAY	7	2	\N	2010-08-05	3513197	\N	3766832	\N
3774652	GENERIC_DAY	7	2	\N	2010-06-04	3513197	\N	3766832	\N
3774655	GENERIC_DAY	7	2	\N	2010-08-09	3513197	\N	3766832	\N
3774665	GENERIC_DAY	7	2	\N	2010-08-10	3513197	\N	3766832	\N
3774658	GENERIC_DAY	7	1	\N	2010-09-24	3513197	\N	3766832	\N
3774681	GENERIC_DAY	7	2	\N	2010-07-16	3513197	\N	3766832	\N
3774656	GENERIC_DAY	7	2	\N	2010-06-11	3513197	\N	3766832	\N
3774633	GENERIC_DAY	7	2	\N	2010-05-28	3513197	\N	3766832	\N
3774648	GENERIC_DAY	7	2	\N	2010-06-02	3513197	\N	3766832	\N
3774673	GENERIC_DAY	7	2	\N	2010-05-26	3513197	\N	3766832	\N
3774627	GENERIC_DAY	7	2	\N	2010-06-16	3513197	\N	3766832	\N
3774746	GENERIC_DAY	7	1	\N	2010-06-03	3513197	\N	3766833	\N
3774745	GENERIC_DAY	7	1	\N	2010-06-14	3513197	\N	3766833	\N
3774742	GENERIC_DAY	7	1	\N	2010-06-18	3513197	\N	3766833	\N
3774752	GENERIC_DAY	7	1	\N	2010-05-26	3513197	\N	3766833	\N
3774771	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766833	\N
3774725	GENERIC_DAY	7	1	\N	2010-06-10	3513197	\N	3766833	\N
3774763	GENERIC_DAY	7	1	\N	2010-06-21	3513197	\N	3766833	\N
3774772	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766833	\N
3774779	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766833	\N
3774717	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766833	\N
3774756	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766833	\N
3774751	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766833	\N
3774774	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766833	\N
3774720	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766833	\N
3774730	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766833	\N
3774733	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766833	\N
3774777	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766833	\N
3774754	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766833	\N
3774782	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766833	\N
3774759	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766833	\N
3774780	GENERIC_DAY	7	1	\N	2010-06-28	3513197	\N	3766833	\N
3774741	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766833	\N
3774749	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766833	\N
3774736	GENERIC_DAY	7	1	\N	2010-06-04	3513197	\N	3766833	\N
3774770	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766833	\N
3774765	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766833	\N
3774767	GENERIC_DAY	7	1	\N	2010-06-15	3513197	\N	3766833	\N
3774739	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766833	\N
3774764	GENERIC_DAY	7	1	\N	2010-06-09	3513197	\N	3766833	\N
3774713	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766833	\N
3774727	GENERIC_DAY	7	1	\N	2010-06-08	3513197	\N	3766833	\N
3774724	GENERIC_DAY	7	1	\N	2010-06-02	3513197	\N	3766833	\N
3774735	GENERIC_DAY	7	1	\N	2010-06-24	3513197	\N	3766833	\N
3774726	GENERIC_DAY	7	1	\N	2010-05-31	3513197	\N	3766833	\N
3774758	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766833	\N
3774787	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766833	\N
3774728	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766833	\N
3774729	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766833	\N
3774803	GENERIC_DAY	7	2	\N	2010-06-01	3513197	\N	3766834	\N
3774810	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766834	\N
3774864	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766834	\N
3774859	GENERIC_DAY	7	2	\N	2010-06-10	3513197	\N	3766834	\N
3774861	GENERIC_DAY	7	2	\N	2010-06-21	3513197	\N	3766834	\N
3774847	GENERIC_DAY	7	2	\N	2010-05-26	3513197	\N	3766834	\N
3774811	GENERIC_DAY	7	2	\N	2010-06-16	3513197	\N	3766834	\N
3774829	GENERIC_DAY	7	2	\N	2010-06-14	3513197	\N	3766834	\N
3774820	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766834	\N
3774850	GENERIC_DAY	7	2	\N	2010-06-18	3513197	\N	3766834	\N
3774876	GENERIC_DAY	7	1	\N	2010-09-16	3513197	\N	3766834	\N
3774856	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766834	\N
3774871	GENERIC_DAY	7	1	\N	2010-09-28	3513197	\N	3766834	\N
3774845	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766834	\N
3774807	GENERIC_DAY	7	2	\N	2010-06-08	3513197	\N	3766834	\N
3774846	GENERIC_DAY	7	2	\N	2010-06-29	3513197	\N	3766834	\N
3774818	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766834	\N
3774813	GENERIC_DAY	7	1	\N	2010-09-17	3513197	\N	3766834	\N
3774819	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766834	\N
3774817	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766834	\N
3774809	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766834	\N
3774795	GENERIC_DAY	7	1	\N	2010-09-21	3513197	\N	3766834	\N
3774839	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766834	\N
3774865	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766834	\N
3774804	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766834	\N
3774858	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766834	\N
3774866	GENERIC_DAY	7	2	\N	2010-06-24	3513197	\N	3766834	\N
3774799	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766834	\N
3774842	GENERIC_DAY	7	1	\N	2010-09-20	3513197	\N	3766834	\N
3774860	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766834	\N
3774830	GENERIC_DAY	7	1	\N	2010-09-14	3513197	\N	3766834	\N
3774802	GENERIC_DAY	7	2	\N	2010-06-11	3513197	\N	3766834	\N
3774857	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766834	\N
3774831	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766834	\N
3774812	GENERIC_DAY	7	2	\N	2010-05-27	3513197	\N	3766834	\N
3774797	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766834	\N
3774843	GENERIC_DAY	7	1	\N	2010-09-23	3513197	\N	3766834	\N
3774880	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766834	\N
3774808	GENERIC_DAY	7	2	\N	2010-06-09	3513197	\N	3766834	\N
3774801	GENERIC_DAY	7	1	\N	2010-09-13	3513197	\N	3766834	\N
3774878	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766834	\N
3774868	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766834	\N
3774870	GENERIC_DAY	7	1	\N	2010-09-24	3513197	\N	3766834	\N
3774796	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766834	\N
3519199	GENERIC_DAY	24	4	\N	2010-01-06	3513185	\N	3511795	\N
3519196	GENERIC_DAY	24	0	\N	2010-01-02	3513185	\N	3511795	\N
3519197	GENERIC_DAY	24	4	\N	2010-01-01	3513185	\N	3511795	\N
3519198	GENERIC_DAY	24	4	\N	2010-01-07	3513185	\N	3511795	\N
3519194	GENERIC_DAY	24	4	\N	2010-01-05	3513185	\N	3511795	\N
3519193	GENERIC_DAY	24	4	\N	2010-01-04	3513185	\N	3511795	\N
3519195	GENERIC_DAY	24	0	\N	2010-01-03	3513185	\N	3511795	\N
3442473	GENERIC_DAY	2	4	\N	2010-08-25	38997	\N	57180	\N
3442574	GENERIC_DAY	2	3	\N	2010-11-04	38997	\N	57180	\N
3442370	GENERIC_DAY	2	4	\N	2010-12-02	38993	\N	57180	\N
3442471	GENERIC_DAY	2	5	\N	2010-07-21	38993	\N	57180	\N
3442547	GENERIC_DAY	2	4	\N	2010-08-19	38997	\N	57180	\N
3442350	GENERIC_DAY	2	4	\N	2010-06-10	38997	\N	57180	\N
3442649	GENERIC_DAY	2	1	\N	2010-10-10	38993	\N	57180	\N
3442392	GENERIC_DAY	2	5	\N	2010-08-11	38993	\N	57180	\N
3442407	GENERIC_DAY	2	4	\N	2010-12-21	38993	\N	57180	\N
3442352	GENERIC_DAY	2	5	\N	2010-09-22	38993	\N	57180	\N
3442669	GENERIC_DAY	2	6	\N	2010-09-16	38993	\N	57180	\N
3442663	GENERIC_DAY	2	1	\N	2010-08-15	38993	\N	57180	\N
3442513	GENERIC_DAY	2	3	\N	2010-09-21	38997	\N	57180	\N
3442660	GENERIC_DAY	2	5	\N	2010-07-12	38993	\N	57180	\N
3442651	GENERIC_DAY	2	4	\N	2010-07-21	38997	\N	57180	\N
3442361	GENERIC_DAY	2	4	\N	2010-06-24	38997	\N	57180	\N
3442501	GENERIC_DAY	2	1	\N	2010-07-03	38993	\N	57180	\N
3442521	GENERIC_DAY	2	4	\N	2010-10-18	38997	\N	57180	\N
3442595	GENERIC_DAY	2	4	\N	2010-09-01	38997	\N	57180	\N
3442393	GENERIC_DAY	2	5	\N	2010-07-15	38993	\N	57180	\N
3442430	GENERIC_DAY	2	3	\N	2010-11-16	38997	\N	57180	\N
3442455	GENERIC_DAY	2	5	\N	2010-06-16	38993	\N	57180	\N
3442697	GENERIC_DAY	2	4	\N	2011-01-04	38997	\N	57180	\N
3442690	GENERIC_DAY	2	4	\N	2011-01-07	38993	\N	57180	\N
3442650	GENERIC_DAY	2	4	\N	2010-07-23	38997	\N	57180	\N
3442362	GENERIC_DAY	2	5	\N	2010-07-22	38993	\N	57180	\N
3442643	GENERIC_DAY	2	4	\N	2010-11-18	38997	\N	57180	\N
3442458	GENERIC_DAY	2	6	\N	2010-09-20	38993	\N	57180	\N
3442553	GENERIC_DAY	2	4	\N	2010-10-14	38993	\N	57180	\N
3442570	GENERIC_DAY	2	4	\N	2011-01-19	38993	\N	57180	\N
3442689	GENERIC_DAY	2	5	\N	2010-09-01	38993	\N	57180	\N
3442633	GENERIC_DAY	2	4	\N	2010-10-25	38997	\N	57180	\N
3442481	GENERIC_DAY	2	4	\N	2010-10-22	38997	\N	57180	\N
3442397	GENERIC_DAY	2	3	\N	2010-11-29	38997	\N	57180	\N
3442632	GENERIC_DAY	2	4	\N	2010-07-08	38997	\N	57180	\N
3442487	GENERIC_DAY	2	5	\N	2010-10-27	38993	\N	57180	\N
3442588	GENERIC_DAY	2	4	\N	2010-12-29	38993	\N	57180	\N
3442453	GENERIC_DAY	2	4	\N	2010-12-28	38997	\N	57180	\N
3515128	GENERIC_DAY	29	1	\N	2010-09-01	3513187	\N	3511790	\N
3515146	GENERIC_DAY	29	1	\N	2010-07-13	3513187	\N	3511790	\N
3515155	GENERIC_DAY	29	1	\N	2010-07-12	3513187	\N	3511790	\N
3515144	GENERIC_DAY	29	1	\N	2010-05-31	3513187	\N	3511790	\N
3515106	GENERIC_DAY	29	1	\N	2010-06-30	3513187	\N	3511790	\N
3515163	GENERIC_DAY	29	1	\N	2010-08-02	3513187	\N	3511790	\N
3852577	GENERIC_DAY	0	0	f	2010-03-21	38991	\N	3679794	\N
3852578	GENERIC_DAY	0	4	f	2010-04-07	3513191	\N	3679794	\N
3852579	GENERIC_DAY	0	4	f	2010-03-31	3513191	\N	3679794	\N
3852580	GENERIC_DAY	0	4	f	2010-03-29	38991	\N	3679794	\N
3852581	GENERIC_DAY	0	4	f	2010-03-24	38991	\N	3679794	\N
3852582	GENERIC_DAY	0	4	f	2010-03-16	38991	\N	3679794	\N
3852583	GENERIC_DAY	0	4	f	2010-04-05	38991	\N	3679794	\N
3852584	GENERIC_DAY	0	4	f	2010-04-01	3513191	\N	3679794	\N
3852585	GENERIC_DAY	0	4	f	2010-03-18	38991	\N	3679794	\N
3852586	GENERIC_DAY	0	0	f	2010-03-20	38991	\N	3679794	\N
3852587	GENERIC_DAY	0	0	f	2010-03-21	3513191	\N	3679794	\N
3852588	GENERIC_DAY	0	4	f	2010-03-25	38991	\N	3679794	\N
3852589	GENERIC_DAY	0	0	f	2010-03-20	3513191	\N	3679794	\N
3852590	GENERIC_DAY	0	4	f	2010-03-23	3513191	\N	3679794	\N
3852591	GENERIC_DAY	0	4	f	2010-04-02	3513191	\N	3679794	\N
3852592	GENERIC_DAY	0	0	f	2010-04-04	3513191	\N	3679794	\N
3852593	GENERIC_DAY	0	4	f	2010-03-29	3513191	\N	3679794	\N
3852594	GENERIC_DAY	0	0	f	2010-03-27	38991	\N	3679794	\N
3852595	GENERIC_DAY	0	0	f	2010-04-03	38991	\N	3679794	\N
3852596	GENERIC_DAY	0	4	f	2010-03-26	38991	\N	3679794	\N
3852597	GENERIC_DAY	0	4	f	2010-04-01	38991	\N	3679794	\N
3852598	GENERIC_DAY	0	4	f	2010-03-19	3513191	\N	3679794	\N
3852599	GENERIC_DAY	0	4	f	2010-03-19	38991	\N	3679794	\N
3852600	GENERIC_DAY	0	0	f	2010-04-04	38991	\N	3679794	\N
3852601	GENERIC_DAY	0	0	f	2010-03-27	3513191	\N	3679794	\N
3852602	GENERIC_DAY	0	4	f	2010-04-07	38991	\N	3679794	\N
3852603	GENERIC_DAY	0	4	f	2010-03-16	3513191	\N	3679794	\N
3852604	GENERIC_DAY	0	0	f	2010-03-13	38991	\N	3679794	\N
3852605	GENERIC_DAY	0	4	f	2010-03-18	3513191	\N	3679794	\N
3852606	GENERIC_DAY	0	4	f	2010-03-26	3513191	\N	3679794	\N
3852607	GENERIC_DAY	0	0	f	2010-04-03	3513191	\N	3679794	\N
3852608	GENERIC_DAY	0	4	f	2010-03-30	3513191	\N	3679794	\N
3852609	GENERIC_DAY	0	4	f	2010-03-15	38991	\N	3679794	\N
3852610	GENERIC_DAY	0	4	f	2010-03-17	38991	\N	3679794	\N
3852611	GENERIC_DAY	0	4	f	2010-03-31	38991	\N	3679794	\N
3852612	GENERIC_DAY	0	4	f	2010-03-23	38991	\N	3679794	\N
3852613	GENERIC_DAY	0	0	f	2010-03-28	38991	\N	3679794	\N
3852614	GENERIC_DAY	0	4	f	2010-03-22	38991	\N	3679794	\N
3852615	GENERIC_DAY	0	4	f	2010-03-15	3513191	\N	3679794	\N
3852616	GENERIC_DAY	0	4	f	2010-04-06	38991	\N	3679794	\N
3852617	GENERIC_DAY	0	4	f	2010-03-24	3513191	\N	3679794	\N
3852618	GENERIC_DAY	0	4	f	2010-03-22	3513191	\N	3679794	\N
3852619	GENERIC_DAY	0	4	f	2010-03-25	3513191	\N	3679794	\N
3852620	GENERIC_DAY	0	4	f	2010-03-30	38991	\N	3679794	\N
3852621	GENERIC_DAY	0	4	f	2010-04-05	3513191	\N	3679794	\N
3852622	GENERIC_DAY	0	4	f	2010-04-06	3513191	\N	3679794	\N
3852623	GENERIC_DAY	0	0	f	2010-03-14	3513191	\N	3679794	\N
3852624	GENERIC_DAY	0	0	f	2010-03-13	3513191	\N	3679794	\N
3852625	GENERIC_DAY	0	0	f	2010-03-14	38991	\N	3679794	\N
3852626	GENERIC_DAY	0	0	f	2010-03-28	3513191	\N	3679794	\N
3852627	GENERIC_DAY	0	4	f	2010-04-02	38991	\N	3679794	\N
3852628	GENERIC_DAY	0	4	f	2010-03-17	3513191	\N	3679794	\N
3852629	GENERIC_DAY	0	4	f	2010-05-07	3513191	\N	3679795	\N
3852630	GENERIC_DAY	0	0	f	2010-05-01	3513191	\N	3679795	\N
3852631	GENERIC_DAY	0	4	f	2010-04-26	38991	\N	3679795	\N
3852632	GENERIC_DAY	0	4	f	2010-04-09	38991	\N	3679795	\N
3852633	GENERIC_DAY	0	4	f	2010-05-05	38991	\N	3679795	\N
3852634	GENERIC_DAY	0	4	f	2010-05-07	38991	\N	3679795	\N
3852635	GENERIC_DAY	0	4	f	2010-04-27	3513191	\N	3679795	\N
3852636	GENERIC_DAY	0	4	f	2010-04-16	38991	\N	3679795	\N
3852637	GENERIC_DAY	0	4	f	2010-04-19	38991	\N	3679795	\N
3852638	GENERIC_DAY	0	0	f	2010-04-10	38991	\N	3679795	\N
3852639	GENERIC_DAY	0	4	f	2010-04-29	3513191	\N	3679795	\N
3852640	GENERIC_DAY	0	4	f	2010-04-22	38991	\N	3679795	\N
3852641	GENERIC_DAY	0	4	f	2010-05-06	38991	\N	3679795	\N
3852642	GENERIC_DAY	0	4	f	2010-04-08	38991	\N	3679795	\N
3852643	GENERIC_DAY	0	4	f	2010-04-30	38991	\N	3679795	\N
3852644	GENERIC_DAY	0	4	f	2010-04-13	3513191	\N	3679795	\N
3852746	GENERIC_DAY	0	4	f	2010-04-23	38991	\N	3679795	\N
3852747	GENERIC_DAY	0	4	f	2010-04-30	3513191	\N	3679795	\N
3852748	GENERIC_DAY	0	4	f	2010-05-04	38991	\N	3679795	\N
3852749	GENERIC_DAY	0	0	f	2010-04-18	3513191	\N	3679795	\N
3852750	GENERIC_DAY	0	4	f	2010-05-03	38991	\N	3679795	\N
3852751	GENERIC_DAY	0	0	f	2010-04-11	38991	\N	3679795	\N
3852752	GENERIC_DAY	0	0	f	2010-04-18	38991	\N	3679795	\N
3852753	GENERIC_DAY	0	0	f	2010-04-10	3513191	\N	3679795	\N
3852754	GENERIC_DAY	0	0	f	2010-05-01	38991	\N	3679795	\N
3852755	GENERIC_DAY	0	4	f	2010-04-23	3513191	\N	3679795	\N
3852756	GENERIC_DAY	0	4	f	2010-05-03	3513191	\N	3679795	\N
3852757	GENERIC_DAY	0	4	f	2010-04-29	38991	\N	3679795	\N
3852758	GENERIC_DAY	0	0	f	2010-04-25	38991	\N	3679795	\N
3852759	GENERIC_DAY	0	0	f	2010-04-17	3513191	\N	3679795	\N
3852760	GENERIC_DAY	0	4	f	2010-04-16	3513191	\N	3679795	\N
3852761	GENERIC_DAY	0	4	f	2010-04-19	3513191	\N	3679795	\N
3852762	GENERIC_DAY	0	4	f	2010-04-13	38991	\N	3679795	\N
3852763	GENERIC_DAY	0	0	f	2010-04-24	38991	\N	3679795	\N
3852764	GENERIC_DAY	0	4	f	2010-04-14	38991	\N	3679795	\N
3852765	GENERIC_DAY	0	4	f	2010-04-15	3513191	\N	3679795	\N
3852766	GENERIC_DAY	0	0	f	2010-04-25	3513191	\N	3679795	\N
3852767	GENERIC_DAY	0	4	f	2010-04-12	38991	\N	3679795	\N
3852768	GENERIC_DAY	0	4	f	2010-04-22	3513191	\N	3679795	\N
3852769	GENERIC_DAY	0	4	f	2010-04-14	3513191	\N	3679795	\N
3852770	GENERIC_DAY	0	4	f	2010-05-04	3513191	\N	3679795	\N
3852771	GENERIC_DAY	0	4	f	2010-04-21	38991	\N	3679795	\N
3852772	GENERIC_DAY	0	4	f	2010-04-20	3513191	\N	3679795	\N
3852773	GENERIC_DAY	0	0	f	2010-05-02	3513191	\N	3679795	\N
3852774	GENERIC_DAY	0	0	f	2010-04-17	38991	\N	3679795	\N
3852775	GENERIC_DAY	0	4	f	2010-04-20	38991	\N	3679795	\N
3852776	GENERIC_DAY	0	0	f	2010-05-02	38991	\N	3679795	\N
3852777	GENERIC_DAY	0	4	f	2010-05-05	3513191	\N	3679795	\N
3852778	GENERIC_DAY	0	4	f	2010-04-28	3513191	\N	3679795	\N
3852779	GENERIC_DAY	0	0	f	2010-04-24	3513191	\N	3679795	\N
3852780	GENERIC_DAY	0	4	f	2010-04-28	38991	\N	3679795	\N
3852781	GENERIC_DAY	0	4	f	2010-04-08	3513191	\N	3679795	\N
3852782	GENERIC_DAY	0	4	f	2010-04-09	3513191	\N	3679795	\N
3852783	GENERIC_DAY	0	4	f	2010-04-15	38991	\N	3679795	\N
3852784	GENERIC_DAY	0	4	f	2010-04-27	38991	\N	3679795	\N
3852785	GENERIC_DAY	0	4	f	2010-04-26	3513191	\N	3679795	\N
3852786	GENERIC_DAY	0	4	f	2010-04-12	3513191	\N	3679795	\N
3852787	GENERIC_DAY	0	0	f	2010-04-11	3513191	\N	3679795	\N
3852788	GENERIC_DAY	0	4	f	2010-04-21	3513191	\N	3679795	\N
3852789	GENERIC_DAY	0	4	f	2010-05-06	3513191	\N	3679795	\N
3852790	GENERIC_DAY	0	0	f	2010-05-08	38991	\N	3679796	\N
3852791	GENERIC_DAY	0	4	f	2010-05-13	3513191	\N	3679796	\N
3852792	GENERIC_DAY	0	4	f	2010-05-14	3513191	\N	3679796	\N
3852793	GENERIC_DAY	0	4	f	2010-05-17	38991	\N	3679796	\N
3852794	GENERIC_DAY	0	4	f	2010-05-11	38991	\N	3679796	\N
3852795	GENERIC_DAY	0	0	f	2010-05-15	3513191	\N	3679796	\N
3852796	GENERIC_DAY	0	4	f	2010-05-11	3513191	\N	3679796	\N
3852797	GENERIC_DAY	0	4	f	2010-05-20	3513191	\N	3679796	\N
3852798	GENERIC_DAY	0	4	f	2010-05-18	38991	\N	3679796	\N
3852799	GENERIC_DAY	0	0	f	2010-05-08	3513191	\N	3679796	\N
3852800	GENERIC_DAY	0	4	f	2010-05-20	38991	\N	3679796	\N
3852801	GENERIC_DAY	0	4	f	2010-05-12	38991	\N	3679796	\N
3852802	GENERIC_DAY	0	4	f	2010-05-13	38991	\N	3679796	\N
3852803	GENERIC_DAY	0	4	f	2010-05-19	38991	\N	3679796	\N
3852804	GENERIC_DAY	0	0	f	2010-05-16	38991	\N	3679796	\N
3852805	GENERIC_DAY	0	4	f	2010-05-10	3513191	\N	3679796	\N
3852806	GENERIC_DAY	0	4	f	2010-05-19	3513191	\N	3679796	\N
3852807	GENERIC_DAY	0	0	f	2010-05-09	38991	\N	3679796	\N
3852808	GENERIC_DAY	0	0	f	2010-05-09	3513191	\N	3679796	\N
3852809	GENERIC_DAY	0	4	f	2010-05-17	3513191	\N	3679796	\N
3852810	GENERIC_DAY	0	0	f	2010-05-16	3513191	\N	3679796	\N
3852811	GENERIC_DAY	0	4	f	2010-05-14	38991	\N	3679796	\N
3852812	GENERIC_DAY	0	4	f	2010-05-18	3513191	\N	3679796	\N
3852813	GENERIC_DAY	0	0	f	2010-05-15	38991	\N	3679796	\N
3852814	GENERIC_DAY	0	4	f	2010-05-10	38991	\N	3679796	\N
3852815	GENERIC_DAY	0	4	f	2010-05-12	3513191	\N	3679796	\N
3852816	GENERIC_DAY	0	0	f	2010-05-23	38991	\N	3679797	\N
3852817	GENERIC_DAY	0	4	f	2010-05-24	3513191	\N	3679797	\N
3852818	GENERIC_DAY	0	0	f	2010-05-30	3513191	\N	3679797	\N
3852819	GENERIC_DAY	0	0	f	2010-05-29	38991	\N	3679797	\N
3852820	GENERIC_DAY	0	4	f	2010-05-28	38991	\N	3679797	\N
3852821	GENERIC_DAY	0	4	f	2010-05-27	38991	\N	3679797	\N
3852822	GENERIC_DAY	0	4	f	2010-05-21	3513191	\N	3679797	\N
3852823	GENERIC_DAY	0	4	f	2010-05-24	38991	\N	3679797	\N
3852824	GENERIC_DAY	0	0	f	2010-05-22	38991	\N	3679797	\N
3852825	GENERIC_DAY	0	4	f	2010-06-02	38991	\N	3679797	\N
3852826	GENERIC_DAY	0	0	f	2010-05-22	3513191	\N	3679797	\N
3852827	GENERIC_DAY	0	4	f	2010-05-25	3513191	\N	3679797	\N
3852828	GENERIC_DAY	0	0	f	2010-05-30	38991	\N	3679797	\N
3852829	GENERIC_DAY	0	4	f	2010-05-21	38991	\N	3679797	\N
3852830	GENERIC_DAY	0	4	f	2010-05-27	3513191	\N	3679797	\N
3852831	GENERIC_DAY	0	4	f	2010-05-31	3513191	\N	3679797	\N
3852832	GENERIC_DAY	0	0	f	2010-05-23	3513191	\N	3679797	\N
3852833	GENERIC_DAY	0	0	f	2010-05-29	3513191	\N	3679797	\N
3852834	GENERIC_DAY	0	4	f	2010-05-25	38991	\N	3679797	\N
3852835	GENERIC_DAY	0	4	f	2010-05-26	3513191	\N	3679797	\N
3852836	GENERIC_DAY	0	4	f	2010-05-26	38991	\N	3679797	\N
3852837	GENERIC_DAY	0	4	f	2010-06-02	3513191	\N	3679797	\N
3852838	GENERIC_DAY	0	4	f	2010-05-31	38991	\N	3679797	\N
3852839	GENERIC_DAY	0	4	f	2010-06-01	38991	\N	3679797	\N
3852840	GENERIC_DAY	0	4	f	2010-05-28	3513191	\N	3679797	\N
3852841	GENERIC_DAY	0	4	f	2010-06-01	3513191	\N	3679797	\N
3852842	GENERIC_DAY	0	0	f	2010-06-13	38991	\N	3679798	\N
3852843	GENERIC_DAY	0	0	f	2010-06-06	3513191	\N	3679798	\N
3852844	GENERIC_DAY	0	4	f	2010-06-14	3513191	\N	3679798	\N
3852845	GENERIC_DAY	0	4	f	2010-06-07	38991	\N	3679798	\N
3852846	GENERIC_DAY	0	4	f	2010-06-11	3513191	\N	3679798	\N
3852847	GENERIC_DAY	0	0	f	2010-06-05	38991	\N	3679798	\N
3852848	GENERIC_DAY	0	0	f	2010-06-13	3513191	\N	3679798	\N
3852849	GENERIC_DAY	0	0	f	2010-06-12	3513191	\N	3679798	\N
3852850	GENERIC_DAY	0	4	f	2010-06-09	38991	\N	3679798	\N
3852851	GENERIC_DAY	0	4	f	2010-06-08	38991	\N	3679798	\N
3852852	GENERIC_DAY	0	4	f	2010-06-03	3513191	\N	3679798	\N
3852853	GENERIC_DAY	0	4	f	2010-06-03	38991	\N	3679798	\N
3852854	GENERIC_DAY	0	0	f	2010-06-06	38991	\N	3679798	\N
3852855	GENERIC_DAY	0	4	f	2010-06-10	3513191	\N	3679798	\N
3852856	GENERIC_DAY	0	4	f	2010-06-04	3513191	\N	3679798	\N
3852857	GENERIC_DAY	0	4	f	2010-06-08	3513191	\N	3679798	\N
3852858	GENERIC_DAY	0	0	f	2010-06-12	38991	\N	3679798	\N
3852859	GENERIC_DAY	0	0	f	2010-06-05	3513191	\N	3679798	\N
3852860	GENERIC_DAY	0	4	f	2010-06-11	38991	\N	3679798	\N
3852861	GENERIC_DAY	0	4	f	2010-06-15	3513191	\N	3679798	\N
3852862	GENERIC_DAY	0	4	f	2010-06-07	3513191	\N	3679798	\N
3852863	GENERIC_DAY	0	4	f	2010-06-14	38991	\N	3679798	\N
3852864	GENERIC_DAY	0	4	f	2010-06-15	38991	\N	3679798	\N
3852865	GENERIC_DAY	0	4	f	2010-06-09	3513191	\N	3679798	\N
3852866	GENERIC_DAY	0	4	f	2010-06-04	38991	\N	3679798	\N
3852867	GENERIC_DAY	0	4	f	2010-06-10	38991	\N	3679798	\N
3852868	GENERIC_DAY	0	0	f	2010-06-20	3513191	\N	3679799	\N
3852869	GENERIC_DAY	0	4	f	2010-06-24	3513191	\N	3679799	\N
3852870	GENERIC_DAY	0	0	f	2010-06-26	38991	\N	3679799	\N
3852871	GENERIC_DAY	0	4	f	2010-06-25	3513191	\N	3679799	\N
3852872	GENERIC_DAY	0	0	f	2010-06-26	3513191	\N	3679799	\N
3852873	GENERIC_DAY	0	4	f	2010-06-22	3513191	\N	3679799	\N
3852874	GENERIC_DAY	0	0	f	2010-06-27	38991	\N	3679799	\N
3852875	GENERIC_DAY	0	4	f	2010-06-21	3513191	\N	3679799	\N
3852876	GENERIC_DAY	0	4	f	2010-06-17	38991	\N	3679799	\N
3852877	GENERIC_DAY	0	4	f	2010-06-18	38991	\N	3679799	\N
3852878	GENERIC_DAY	0	4	f	2010-06-28	3513191	\N	3679799	\N
3852879	GENERIC_DAY	0	0	f	2010-06-20	38991	\N	3679799	\N
3852880	GENERIC_DAY	0	0	f	2010-06-19	3513191	\N	3679799	\N
3852881	GENERIC_DAY	0	4	f	2010-06-24	38991	\N	3679799	\N
3852882	GENERIC_DAY	0	4	f	2010-06-25	38991	\N	3679799	\N
3852883	GENERIC_DAY	0	4	f	2010-06-16	3513191	\N	3679799	\N
3852884	GENERIC_DAY	0	4	f	2010-06-22	38991	\N	3679799	\N
3852885	GENERIC_DAY	0	4	f	2010-06-18	3513191	\N	3679799	\N
3852886	GENERIC_DAY	0	4	f	2010-06-28	38991	\N	3679799	\N
3852887	GENERIC_DAY	0	4	f	2010-06-16	38991	\N	3679799	\N
3852888	GENERIC_DAY	0	4	f	2010-06-21	38991	\N	3679799	\N
3852889	GENERIC_DAY	0	4	f	2010-06-23	38991	\N	3679799	\N
3852890	GENERIC_DAY	0	0	f	2010-06-19	38991	\N	3679799	\N
3852891	GENERIC_DAY	0	0	f	2010-06-27	3513191	\N	3679799	\N
3852892	GENERIC_DAY	0	4	f	2010-06-17	3513191	\N	3679799	\N
3852893	GENERIC_DAY	0	4	f	2010-06-23	3513191	\N	3679799	\N
3852894	GENERIC_DAY	0	4	f	2010-07-15	38991	\N	3679800	\N
3852895	GENERIC_DAY	0	0	f	2010-07-10	3513191	\N	3679800	\N
3852896	GENERIC_DAY	0	4	f	2010-07-06	38991	\N	3679800	\N
3852897	GENERIC_DAY	0	0	f	2010-07-18	38991	\N	3679800	\N
3852898	GENERIC_DAY	0	4	f	2010-06-29	3513191	\N	3679800	\N
3852899	GENERIC_DAY	0	4	f	2010-07-09	38991	\N	3679800	\N
3852900	GENERIC_DAY	0	4	f	2010-07-08	3513191	\N	3679800	\N
3852901	GENERIC_DAY	0	0	f	2010-07-04	38991	\N	3679800	\N
3852902	GENERIC_DAY	0	0	f	2010-07-18	3513191	\N	3679800	\N
3852903	GENERIC_DAY	0	4	f	2010-07-05	3513191	\N	3679800	\N
3852904	GENERIC_DAY	0	4	f	2010-07-22	38991	\N	3679800	\N
3852905	GENERIC_DAY	0	4	f	2010-07-07	3513191	\N	3679800	\N
3852906	GENERIC_DAY	0	4	f	2010-07-16	3513191	\N	3679800	\N
3852907	GENERIC_DAY	0	4	f	2010-07-02	3513191	\N	3679800	\N
3852908	GENERIC_DAY	0	0	f	2010-07-17	3513191	\N	3679800	\N
3852909	GENERIC_DAY	0	4	f	2010-07-05	38991	\N	3679800	\N
3852910	GENERIC_DAY	0	4	f	2010-07-22	3513191	\N	3679800	\N
3852911	GENERIC_DAY	0	4	f	2010-07-21	38991	\N	3679800	\N
3852912	GENERIC_DAY	0	4	f	2010-07-01	3513191	\N	3679800	\N
3852913	GENERIC_DAY	0	4	f	2010-07-01	38991	\N	3679800	\N
3852914	GENERIC_DAY	0	0	f	2010-07-17	38991	\N	3679800	\N
3852915	GENERIC_DAY	0	4	f	2010-07-12	3513191	\N	3679800	\N
3852916	GENERIC_DAY	0	4	f	2010-07-12	38991	\N	3679800	\N
3852917	GENERIC_DAY	0	4	f	2010-06-29	38991	\N	3679800	\N
3852918	GENERIC_DAY	0	4	f	2010-07-14	3513191	\N	3679800	\N
3852919	GENERIC_DAY	0	4	f	2010-07-19	38991	\N	3679800	\N
3852920	GENERIC_DAY	0	4	f	2010-07-16	38991	\N	3679800	\N
3852921	GENERIC_DAY	0	4	f	2010-06-30	3513191	\N	3679800	\N
3852922	GENERIC_DAY	0	4	f	2010-07-19	3513191	\N	3679800	\N
3852923	GENERIC_DAY	0	4	f	2010-07-21	3513191	\N	3679800	\N
3852924	GENERIC_DAY	0	4	f	2010-07-15	3513191	\N	3679800	\N
3852925	GENERIC_DAY	0	4	f	2010-07-06	3513191	\N	3679800	\N
3852926	GENERIC_DAY	0	0	f	2010-07-03	3513191	\N	3679800	\N
3852927	GENERIC_DAY	0	0	f	2010-07-11	3513191	\N	3679800	\N
3852928	GENERIC_DAY	0	4	f	2010-07-20	3513191	\N	3679800	\N
3852929	GENERIC_DAY	0	0	f	2010-07-04	3513191	\N	3679800	\N
3852930	GENERIC_DAY	0	0	f	2010-07-10	38991	\N	3679800	\N
3852931	GENERIC_DAY	0	4	f	2010-07-13	3513191	\N	3679800	\N
3852932	GENERIC_DAY	0	0	f	2010-07-11	38991	\N	3679800	\N
3852933	GENERIC_DAY	0	4	f	2010-07-20	38991	\N	3679800	\N
3852934	GENERIC_DAY	0	4	f	2010-06-30	38991	\N	3679800	\N
3852935	GENERIC_DAY	0	4	f	2010-07-14	38991	\N	3679800	\N
3852936	GENERIC_DAY	0	4	f	2010-07-09	3513191	\N	3679800	\N
3852937	GENERIC_DAY	0	0	f	2010-07-03	38991	\N	3679800	\N
3852938	GENERIC_DAY	0	4	f	2010-07-13	38991	\N	3679800	\N
3852939	GENERIC_DAY	0	4	f	2010-07-08	38991	\N	3679800	\N
3852940	GENERIC_DAY	0	4	f	2010-07-02	38991	\N	3679800	\N
3852941	GENERIC_DAY	0	4	f	2010-07-07	38991	\N	3679800	\N
3852942	GENERIC_DAY	0	4	f	2010-08-05	38991	\N	3679801	\N
3852943	GENERIC_DAY	0	4	f	2010-08-06	3513191	\N	3679801	\N
3852944	GENERIC_DAY	0	0	f	2010-07-24	38991	\N	3679801	\N
3852945	GENERIC_DAY	0	4	f	2010-08-09	3513191	\N	3679801	\N
3852946	GENERIC_DAY	0	4	f	2010-08-10	3513191	\N	3679801	\N
3852947	GENERIC_DAY	0	4	f	2010-08-09	38991	\N	3679801	\N
3852948	GENERIC_DAY	0	4	f	2010-07-30	3513191	\N	3679801	\N
3852949	GENERIC_DAY	0	0	f	2010-08-08	38991	\N	3679801	\N
3852950	GENERIC_DAY	0	4	f	2010-08-11	38991	\N	3679801	\N
3852951	GENERIC_DAY	0	4	f	2010-07-27	3513191	\N	3679801	\N
3852952	GENERIC_DAY	0	4	f	2010-07-26	3513191	\N	3679801	\N
3852953	GENERIC_DAY	0	0	f	2010-07-31	3513191	\N	3679801	\N
3852954	GENERIC_DAY	0	4	f	2010-07-27	38991	\N	3679801	\N
3852955	GENERIC_DAY	0	0	f	2010-08-07	3513191	\N	3679801	\N
3852956	GENERIC_DAY	0	4	f	2010-07-28	38991	\N	3679801	\N
3852957	GENERIC_DAY	0	4	f	2010-08-05	3513191	\N	3679801	\N
3852958	GENERIC_DAY	0	4	f	2010-08-03	3513191	\N	3679801	\N
3852959	GENERIC_DAY	0	4	f	2010-07-29	38991	\N	3679801	\N
3852960	GENERIC_DAY	0	0	f	2010-07-25	3513191	\N	3679801	\N
3852961	GENERIC_DAY	0	4	f	2010-08-02	3513191	\N	3679801	\N
3852962	GENERIC_DAY	0	0	f	2010-08-07	38991	\N	3679801	\N
3852963	GENERIC_DAY	0	4	f	2010-08-04	3513191	\N	3679801	\N
3852964	GENERIC_DAY	0	4	f	2010-08-10	38991	\N	3679801	\N
3852965	GENERIC_DAY	0	4	f	2010-07-29	3513191	\N	3679801	\N
3852966	GENERIC_DAY	0	4	f	2010-08-11	3513191	\N	3679801	\N
3852967	GENERIC_DAY	0	0	f	2010-07-31	38991	\N	3679801	\N
3852968	GENERIC_DAY	0	4	f	2010-08-12	38991	\N	3679801	\N
3852969	GENERIC_DAY	0	4	f	2010-08-04	38991	\N	3679801	\N
3852970	GENERIC_DAY	0	4	f	2010-07-23	3513191	\N	3679801	\N
3852971	GENERIC_DAY	0	0	f	2010-07-24	3513191	\N	3679801	\N
3852972	GENERIC_DAY	0	4	f	2010-07-23	38991	\N	3679801	\N
3852973	GENERIC_DAY	0	4	f	2010-07-30	38991	\N	3679801	\N
3852974	GENERIC_DAY	0	4	f	2010-07-26	38991	\N	3679801	\N
3852975	GENERIC_DAY	0	0	f	2010-08-01	3513191	\N	3679801	\N
3852976	GENERIC_DAY	0	4	f	2010-08-06	38991	\N	3679801	\N
3852977	GENERIC_DAY	0	4	f	2010-08-12	3513191	\N	3679801	\N
3852978	GENERIC_DAY	0	0	f	2010-08-01	38991	\N	3679801	\N
3852979	GENERIC_DAY	0	0	f	2010-07-25	38991	\N	3679801	\N
3852980	GENERIC_DAY	0	4	f	2010-07-28	3513191	\N	3679801	\N
3852981	GENERIC_DAY	0	0	f	2010-08-08	3513191	\N	3679801	\N
3852982	GENERIC_DAY	0	4	f	2010-08-03	38991	\N	3679801	\N
3852983	GENERIC_DAY	0	4	f	2010-08-02	38991	\N	3679801	\N
3852984	GENERIC_DAY	0	0	f	2010-03-13	38991	\N	3559792	\N
3852985	GENERIC_DAY	0	6	f	2010-03-19	3513191	\N	3559792	\N
3852986	GENERIC_DAY	0	0	f	2010-03-13	3513191	\N	3559792	\N
3852987	GENERIC_DAY	0	0	f	2010-03-14	38991	\N	3559792	\N
3852988	GENERIC_DAY	0	6	f	2010-03-17	3513191	\N	3559792	\N
3852989	GENERIC_DAY	0	0	f	2010-03-21	38991	\N	3559792	\N
3852990	GENERIC_DAY	0	6	f	2010-03-16	3513191	\N	3559792	\N
3852991	GENERIC_DAY	0	6	f	2010-03-15	38991	\N	3559792	\N
3852992	GENERIC_DAY	0	6	f	2010-03-16	38991	\N	3559792	\N
3852993	GENERIC_DAY	0	6	f	2010-03-18	38991	\N	3559792	\N
3852994	GENERIC_DAY	0	0	f	2010-03-20	38991	\N	3559792	\N
3852995	GENERIC_DAY	0	6	f	2010-03-18	3513191	\N	3559792	\N
3852996	GENERIC_DAY	0	0	f	2010-03-21	3513191	\N	3559792	\N
3852997	GENERIC_DAY	0	2	f	2010-03-22	3513191	\N	3559792	\N
3852998	GENERIC_DAY	0	6	f	2010-03-15	3513191	\N	3559792	\N
3852999	GENERIC_DAY	0	0	f	2010-03-14	3513191	\N	3559792	\N
3853000	GENERIC_DAY	0	2	f	2010-03-22	38991	\N	3559792	\N
3853001	GENERIC_DAY	0	0	f	2010-03-20	3513191	\N	3559792	\N
3853002	GENERIC_DAY	0	6	f	2010-03-19	38991	\N	3559792	\N
3853003	GENERIC_DAY	0	6	f	2010-03-17	38991	\N	3559792	\N
3853004	GENERIC_DAY	0	6	f	2010-03-26	3513191	\N	3559793	\N
3853005	GENERIC_DAY	0	0	f	2010-03-28	3513191	\N	3559793	\N
3853006	GENERIC_DAY	0	0	f	2010-03-28	38991	\N	3559793	\N
3853007	GENERIC_DAY	0	0	f	2010-03-27	3513191	\N	3559793	\N
3853008	GENERIC_DAY	0	6	f	2010-03-23	3513191	\N	3559793	\N
3853009	GENERIC_DAY	0	6	f	2010-03-25	38991	\N	3559793	\N
3853010	GENERIC_DAY	0	6	f	2010-03-25	3513191	\N	3559793	\N
3853011	GENERIC_DAY	0	0	f	2010-03-27	38991	\N	3559793	\N
3853012	GENERIC_DAY	0	4	f	2010-03-29	3513191	\N	3559793	\N
3853013	GENERIC_DAY	0	6	f	2010-03-24	3513191	\N	3559793	\N
3853014	GENERIC_DAY	0	4	f	2010-03-29	38991	\N	3559793	\N
3853015	GENERIC_DAY	0	6	f	2010-03-24	38991	\N	3559793	\N
3853016	GENERIC_DAY	0	6	f	2010-03-23	38991	\N	3559793	\N
3853017	GENERIC_DAY	0	6	f	2010-03-26	38991	\N	3559793	\N
3853018	GENERIC_DAY	0	6	f	2010-04-02	3513191	\N	3559794	\N
3853019	GENERIC_DAY	0	6	f	2010-04-02	38991	\N	3559794	\N
3853020	GENERIC_DAY	0	6	f	2010-04-01	38991	\N	3559794	\N
3853021	GENERIC_DAY	0	6	f	2010-03-30	3513191	\N	3559794	\N
3853022	GENERIC_DAY	0	6	f	2010-03-31	38991	\N	3559794	\N
3853023	GENERIC_DAY	0	6	f	2010-04-01	3513191	\N	3559794	\N
3853024	GENERIC_DAY	0	6	f	2010-03-31	3513191	\N	3559794	\N
3853025	GENERIC_DAY	0	6	f	2010-03-30	38991	\N	3559794	\N
3853026	GENERIC_DAY	0	6	f	2010-04-20	38991	\N	3559795	\N
3853027	GENERIC_DAY	0	6	f	2010-04-08	38991	\N	3559795	\N
3853028	GENERIC_DAY	0	6	f	2010-04-21	38991	\N	3559795	\N
3853029	GENERIC_DAY	0	0	f	2010-04-04	38991	\N	3559795	\N
3853030	GENERIC_DAY	0	0	f	2010-04-17	38991	\N	3559795	\N
3853031	GENERIC_DAY	0	6	f	2010-04-16	38991	\N	3559795	\N
3853032	GENERIC_DAY	0	6	f	2010-04-12	3513191	\N	3559795	\N
3853033	GENERIC_DAY	0	6	f	2010-04-13	38991	\N	3559795	\N
3853034	GENERIC_DAY	0	6	f	2010-04-19	3513191	\N	3559795	\N
3853035	GENERIC_DAY	0	6	f	2010-04-05	38991	\N	3559795	\N
3853036	GENERIC_DAY	0	0	f	2010-04-03	38991	\N	3559795	\N
3853037	GENERIC_DAY	0	6	f	2010-04-21	3513191	\N	3559795	\N
3853038	GENERIC_DAY	0	0	f	2010-04-18	38991	\N	3559795	\N
3853039	GENERIC_DAY	0	0	f	2010-04-03	3513191	\N	3559795	\N
3853040	GENERIC_DAY	0	4	f	2010-04-23	3513191	\N	3559795	\N
3853041	GENERIC_DAY	0	6	f	2010-04-22	38991	\N	3559795	\N
3853042	GENERIC_DAY	0	6	f	2010-04-16	3513191	\N	3559795	\N
3853043	GENERIC_DAY	0	6	f	2010-04-05	3513191	\N	3559795	\N
3853044	GENERIC_DAY	0	6	f	2010-04-07	38991	\N	3559795	\N
3853045	GENERIC_DAY	0	6	f	2010-04-12	38991	\N	3559795	\N
3853046	GENERIC_DAY	0	6	f	2010-04-06	3513191	\N	3559795	\N
3853047	GENERIC_DAY	0	0	f	2010-04-17	3513191	\N	3559795	\N
3853048	GENERIC_DAY	0	0	f	2010-04-04	3513191	\N	3559795	\N
3853049	GENERIC_DAY	0	0	f	2010-04-10	38991	\N	3559795	\N
3853050	GENERIC_DAY	0	4	f	2010-04-23	38991	\N	3559795	\N
3853051	GENERIC_DAY	0	6	f	2010-04-20	3513191	\N	3559795	\N
3853052	GENERIC_DAY	0	6	f	2010-04-06	38991	\N	3559795	\N
3853053	GENERIC_DAY	0	6	f	2010-04-08	3513191	\N	3559795	\N
3768857	GENERIC_DAY	9	0	\N	2010-08-29	3513195	\N	3766824	\N
3768871	GENERIC_DAY	9	8	\N	2010-09-14	3513195	\N	3766824	\N
3768856	GENERIC_DAY	9	8	\N	2010-08-27	3513195	\N	3766824	\N
3768864	GENERIC_DAY	9	0	\N	2010-08-28	3513195	\N	3766824	\N
3774874	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766834	\N
3774824	GENERIC_DAY	7	1	\N	2010-09-15	3513197	\N	3766834	\N
3774816	GENERIC_DAY	7	2	\N	2010-06-04	3513197	\N	3766834	\N
3774873	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766834	\N
3774791	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766834	\N
3774875	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766834	\N
3774877	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766834	\N
3853054	GENERIC_DAY	0	6	f	2010-04-15	38991	\N	3559795	\N
3853055	GENERIC_DAY	0	0	f	2010-04-10	3513191	\N	3559795	\N
3853056	GENERIC_DAY	0	0	f	2010-04-11	38991	\N	3559795	\N
3853057	GENERIC_DAY	0	6	f	2010-04-13	3513191	\N	3559795	\N
3853058	GENERIC_DAY	0	6	f	2010-04-09	3513191	\N	3559795	\N
3853059	GENERIC_DAY	0	6	f	2010-04-22	3513191	\N	3559795	\N
3853060	GENERIC_DAY	0	6	f	2010-04-14	3513191	\N	3559795	\N
3853061	GENERIC_DAY	0	6	f	2010-04-15	3513191	\N	3559795	\N
3853062	GENERIC_DAY	0	6	f	2010-04-09	38991	\N	3559795	\N
3853063	GENERIC_DAY	0	0	f	2010-04-11	3513191	\N	3559795	\N
3853064	GENERIC_DAY	0	6	f	2010-04-07	3513191	\N	3559795	\N
3853065	GENERIC_DAY	0	0	f	2010-04-18	3513191	\N	3559795	\N
3853066	GENERIC_DAY	0	6	f	2010-04-19	38991	\N	3559795	\N
3853067	GENERIC_DAY	0	6	f	2010-04-14	38991	\N	3559795	\N
3853068	GENERIC_DAY	0	6	f	2010-04-27	3513191	\N	3559796	\N
3853069	GENERIC_DAY	0	6	f	2010-04-26	3513191	\N	3559796	\N
3853070	GENERIC_DAY	0	6	f	2010-05-04	38991	\N	3559796	\N
3853071	GENERIC_DAY	0	6	f	2010-04-26	38991	\N	3559796	\N
3853072	GENERIC_DAY	0	6	f	2010-05-07	3513191	\N	3559796	\N
3853073	GENERIC_DAY	0	6	f	2010-05-03	38991	\N	3559796	\N
3853074	GENERIC_DAY	0	0	f	2010-04-25	38991	\N	3559796	\N
3853075	GENERIC_DAY	0	6	f	2010-05-10	38991	\N	3559796	\N
3853076	GENERIC_DAY	0	6	f	2010-04-29	38991	\N	3559796	\N
3853077	GENERIC_DAY	0	6	f	2010-05-06	3513191	\N	3559796	\N
3853078	GENERIC_DAY	0	0	f	2010-04-25	3513191	\N	3559796	\N
3853079	GENERIC_DAY	0	6	f	2010-04-29	3513191	\N	3559796	\N
3853080	GENERIC_DAY	0	0	f	2010-04-24	3513191	\N	3559796	\N
3853081	GENERIC_DAY	0	6	f	2010-05-05	38991	\N	3559796	\N
3853082	GENERIC_DAY	0	0	f	2010-05-01	3513191	\N	3559796	\N
3853083	GENERIC_DAY	0	6	f	2010-05-05	3513191	\N	3559796	\N
3853084	GENERIC_DAY	0	6	f	2010-05-07	38991	\N	3559796	\N
3853085	GENERIC_DAY	0	0	f	2010-04-24	38991	\N	3559796	\N
3853086	GENERIC_DAY	0	0	f	2010-05-02	38991	\N	3559796	\N
3853087	GENERIC_DAY	0	6	f	2010-05-06	38991	\N	3559796	\N
3853088	GENERIC_DAY	0	6	f	2010-04-30	3513191	\N	3559796	\N
3853089	GENERIC_DAY	0	6	f	2010-05-11	3513191	\N	3559796	\N
3853090	GENERIC_DAY	0	0	f	2010-05-08	3513191	\N	3559796	\N
3853091	GENERIC_DAY	0	0	f	2010-05-01	38991	\N	3559796	\N
3853092	GENERIC_DAY	0	6	f	2010-04-28	38991	\N	3559796	\N
3853093	GENERIC_DAY	0	6	f	2010-04-30	38991	\N	3559796	\N
3853094	GENERIC_DAY	0	0	f	2010-05-09	3513191	\N	3559796	\N
3853095	GENERIC_DAY	0	6	f	2010-05-11	38991	\N	3559796	\N
3853096	GENERIC_DAY	0	6	f	2010-05-04	3513191	\N	3559796	\N
3853097	GENERIC_DAY	0	6	f	2010-04-28	3513191	\N	3559796	\N
3853098	GENERIC_DAY	0	6	f	2010-04-27	38991	\N	3559796	\N
3853099	GENERIC_DAY	0	0	f	2010-05-09	38991	\N	3559796	\N
3853100	GENERIC_DAY	0	0	f	2010-05-02	3513191	\N	3559796	\N
3853101	GENERIC_DAY	0	0	f	2010-05-08	38991	\N	3559796	\N
3853102	GENERIC_DAY	0	6	f	2010-05-03	3513191	\N	3559796	\N
3853103	GENERIC_DAY	0	6	f	2010-05-10	3513191	\N	3559796	\N
3853104	GENERIC_DAY	0	6	f	2010-05-12	3513191	\N	3559797	\N
3853105	GENERIC_DAY	0	6	f	2010-05-17	3513191	\N	3559797	\N
3853106	GENERIC_DAY	0	6	f	2010-05-14	3513191	\N	3559797	\N
3853107	GENERIC_DAY	0	6	f	2010-05-19	38991	\N	3559797	\N
3853108	GENERIC_DAY	0	0	f	2010-05-15	3513191	\N	3559797	\N
3853109	GENERIC_DAY	0	6	f	2010-05-24	38991	\N	3559797	\N
3853110	GENERIC_DAY	0	6	f	2010-05-26	38991	\N	3559797	\N
3853111	GENERIC_DAY	0	4	f	2010-05-28	38991	\N	3559797	\N
3853112	GENERIC_DAY	0	6	f	2010-05-18	38991	\N	3559797	\N
3853113	GENERIC_DAY	0	0	f	2010-05-16	38991	\N	3559797	\N
3515160	GENERIC_DAY	29	1	\N	2010-09-29	3513187	\N	3511790	\N
3515119	GENERIC_DAY	29	1	\N	2010-09-20	3513187	\N	3511790	\N
3515121	GENERIC_DAY	29	1	\N	2010-06-29	3513187	\N	3511790	\N
3515150	GENERIC_DAY	29	1	\N	2010-09-27	3513187	\N	3511790	\N
3515170	GENERIC_DAY	29	1	\N	2010-09-15	3513187	\N	3511790	\N
3515154	GENERIC_DAY	29	1	\N	2010-06-02	3513187	\N	3511790	\N
3515122	GENERIC_DAY	29	1	\N	2010-06-25	3513187	\N	3511790	\N
3515120	GENERIC_DAY	29	1	\N	2010-07-07	3513187	\N	3511790	\N
3515114	GENERIC_DAY	29	1	\N	2010-06-14	3513187	\N	3511790	\N
3515149	GENERIC_DAY	29	1	\N	2010-07-26	3513187	\N	3511790	\N
3515156	GENERIC_DAY	29	1	\N	2010-09-21	3513187	\N	3511790	\N
3515102	GENERIC_DAY	29	1	\N	2010-07-08	3513187	\N	3511790	\N
3515123	GENERIC_DAY	29	1	\N	2010-06-10	3513187	\N	3511790	\N
3515124	GENERIC_DAY	29	1	\N	2010-07-05	3513187	\N	3511790	\N
3515125	GENERIC_DAY	29	1	\N	2010-06-07	3513187	\N	3511790	\N
3515142	GENERIC_DAY	29	1	\N	2010-09-09	3513187	\N	3511790	\N
3515134	GENERIC_DAY	29	1	\N	2010-09-16	3513187	\N	3511790	\N
3515159	GENERIC_DAY	29	1	\N	2010-07-23	3513187	\N	3511790	\N
3515157	GENERIC_DAY	29	1	\N	2010-05-27	3513187	\N	3511790	\N
3515126	GENERIC_DAY	29	1	\N	2010-07-27	3513187	\N	3511790	\N
3853114	GENERIC_DAY	0	6	f	2010-05-20	3513191	\N	3559797	\N
3853115	GENERIC_DAY	0	6	f	2010-05-21	3513191	\N	3559797	\N
3853116	GENERIC_DAY	0	0	f	2010-05-23	3513191	\N	3559797	\N
3853117	GENERIC_DAY	0	6	f	2010-05-25	38991	\N	3559797	\N
3853118	GENERIC_DAY	0	6	f	2010-05-20	38991	\N	3559797	\N
3853119	GENERIC_DAY	0	6	f	2010-05-21	38991	\N	3559797	\N
3853120	GENERIC_DAY	0	0	f	2010-05-23	38991	\N	3559797	\N
3853121	GENERIC_DAY	0	4	f	2010-05-28	3513191	\N	3559797	\N
3853122	GENERIC_DAY	0	6	f	2010-05-27	3513191	\N	3559797	\N
3853123	GENERIC_DAY	0	0	f	2010-05-16	3513191	\N	3559797	\N
3853124	GENERIC_DAY	0	6	f	2010-05-12	38991	\N	3559797	\N
3853125	GENERIC_DAY	0	6	f	2010-05-14	38991	\N	3559797	\N
3853126	GENERIC_DAY	0	6	f	2010-05-25	3513191	\N	3559797	\N
3853127	GENERIC_DAY	0	6	f	2010-05-19	3513191	\N	3559797	\N
3853128	GENERIC_DAY	0	0	f	2010-05-22	38991	\N	3559797	\N
3853129	GENERIC_DAY	0	6	f	2010-05-18	3513191	\N	3559797	\N
3853130	GENERIC_DAY	0	0	f	2010-05-22	3513191	\N	3559797	\N
3853131	GENERIC_DAY	0	6	f	2010-05-13	3513191	\N	3559797	\N
3853132	GENERIC_DAY	0	6	f	2010-05-17	38991	\N	3559797	\N
3853133	GENERIC_DAY	0	6	f	2010-05-24	3513191	\N	3559797	\N
3853134	GENERIC_DAY	0	6	f	2010-05-27	38991	\N	3559797	\N
3853135	GENERIC_DAY	0	6	f	2010-05-26	3513191	\N	3559797	\N
3853136	GENERIC_DAY	0	6	f	2010-05-13	38991	\N	3559797	\N
3853137	GENERIC_DAY	0	0	f	2010-05-15	38991	\N	3559797	\N
3853138	GENERIC_DAY	0	0	f	2010-05-29	3513191	\N	3659355	\N
3853139	GENERIC_DAY	0	0	f	2010-06-06	3513191	\N	3659355	\N
3853140	GENERIC_DAY	0	6	f	2010-06-04	38991	\N	3659355	\N
3853141	GENERIC_DAY	0	6	f	2010-06-01	38991	\N	3659355	\N
3853142	GENERIC_DAY	0	6	f	2010-05-31	3513191	\N	3659355	\N
3853143	GENERIC_DAY	0	0	f	2010-05-29	38991	\N	3659355	\N
3853144	GENERIC_DAY	0	6	f	2010-06-01	3513191	\N	3659355	\N
3853145	GENERIC_DAY	0	0	f	2010-06-05	38991	\N	3659355	\N
3853146	GENERIC_DAY	0	0	f	2010-05-30	38991	\N	3659355	\N
3853147	GENERIC_DAY	0	0	f	2010-05-30	3513191	\N	3659355	\N
3853148	GENERIC_DAY	0	6	f	2010-06-07	3513191	\N	3659355	\N
3853149	GENERIC_DAY	0	6	f	2010-06-04	3513191	\N	3659355	\N
3853150	GENERIC_DAY	0	6	f	2010-06-02	38991	\N	3659355	\N
3853151	GENERIC_DAY	0	6	f	2010-06-03	3513191	\N	3659355	\N
3853152	GENERIC_DAY	0	6	f	2010-06-03	38991	\N	3659355	\N
3853153	GENERIC_DAY	0	6	f	2010-06-07	38991	\N	3659355	\N
3853154	GENERIC_DAY	0	0	f	2010-06-06	38991	\N	3659355	\N
3853155	GENERIC_DAY	0	6	f	2010-05-31	38991	\N	3659355	\N
3853156	GENERIC_DAY	0	0	f	2010-06-05	3513191	\N	3659355	\N
3853157	GENERIC_DAY	0	6	f	2010-06-02	3513191	\N	3659355	\N
3853158	GENERIC_DAY	0	6	f	2010-06-10	38991	\N	3559799	\N
3853159	GENERIC_DAY	0	6	f	2010-06-09	38991	\N	3559799	\N
3853160	GENERIC_DAY	0	6	f	2010-06-10	3513191	\N	3559799	\N
3853161	GENERIC_DAY	0	6	f	2010-06-08	3513191	\N	3559799	\N
3853162	GENERIC_DAY	0	6	f	2010-06-11	38991	\N	3559799	\N
3853163	GENERIC_DAY	0	6	f	2010-06-09	3513191	\N	3559799	\N
3853164	GENERIC_DAY	0	6	f	2010-06-11	3513191	\N	3559799	\N
3853165	GENERIC_DAY	0	6	f	2010-06-08	38991	\N	3559799	\N
3853166	GENERIC_DAY	0	0	f	2010-06-20	3513191	\N	3559800	\N
3853167	GENERIC_DAY	0	0	f	2010-06-13	3513191	\N	3559800	\N
3853168	GENERIC_DAY	0	6	f	2010-06-24	3513191	\N	3559800	\N
3853169	GENERIC_DAY	0	0	f	2010-06-19	38991	\N	3559800	\N
3853170	GENERIC_DAY	0	0	f	2010-06-12	38991	\N	3559800	\N
3853171	GENERIC_DAY	0	6	f	2010-06-16	38991	\N	3559800	\N
3853172	GENERIC_DAY	0	6	f	2010-06-14	3513191	\N	3559800	\N
3853173	GENERIC_DAY	0	6	f	2010-06-23	38991	\N	3559800	\N
3853174	GENERIC_DAY	0	6	f	2010-06-25	3513191	\N	3559800	\N
3853175	GENERIC_DAY	0	6	f	2010-06-18	3513191	\N	3559800	\N
3853176	GENERIC_DAY	0	6	f	2010-06-24	38991	\N	3559800	\N
3853177	GENERIC_DAY	0	6	f	2010-06-22	38991	\N	3559800	\N
3853178	GENERIC_DAY	0	6	f	2010-06-23	3513191	\N	3559800	\N
3853179	GENERIC_DAY	0	6	f	2010-06-22	3513191	\N	3559800	\N
3853180	GENERIC_DAY	0	6	f	2010-06-14	38991	\N	3559800	\N
3853181	GENERIC_DAY	0	6	f	2010-06-17	38991	\N	3559800	\N
3853182	GENERIC_DAY	0	6	f	2010-06-16	3513191	\N	3559800	\N
3853183	GENERIC_DAY	0	0	f	2010-06-13	38991	\N	3559800	\N
3853184	GENERIC_DAY	0	6	f	2010-06-15	38991	\N	3559800	\N
3853185	GENERIC_DAY	0	6	f	2010-06-15	3513191	\N	3559800	\N
3853186	GENERIC_DAY	0	0	f	2010-06-12	3513191	\N	3559800	\N
3853187	GENERIC_DAY	0	6	f	2010-06-17	3513191	\N	3559800	\N
3853188	GENERIC_DAY	0	6	f	2010-06-18	38991	\N	3559800	\N
3853189	GENERIC_DAY	0	0	f	2010-06-19	3513191	\N	3559800	\N
3853190	GENERIC_DAY	0	6	f	2010-06-21	3513191	\N	3559800	\N
3853191	GENERIC_DAY	0	6	f	2010-06-25	38991	\N	3559800	\N
3853192	GENERIC_DAY	0	6	f	2010-06-21	38991	\N	3559800	\N
3853193	GENERIC_DAY	0	0	f	2010-06-20	38991	\N	3559800	\N
3853194	GENERIC_DAY	0	6	f	2010-07-15	3513191	\N	3659356	\N
3853195	GENERIC_DAY	0	0	f	2010-07-10	3513191	\N	3659356	\N
3853196	GENERIC_DAY	0	6	f	2010-07-08	3513191	\N	3659356	\N
3853197	GENERIC_DAY	0	6	f	2010-06-29	3513191	\N	3659356	\N
3853198	GENERIC_DAY	0	6	f	2010-07-07	38991	\N	3659356	\N
3853199	GENERIC_DAY	0	6	f	2010-07-02	38991	\N	3659356	\N
3853200	GENERIC_DAY	0	0	f	2010-07-03	38991	\N	3659356	\N
3853201	GENERIC_DAY	0	0	f	2010-07-11	38991	\N	3659356	\N
3853202	GENERIC_DAY	0	6	f	2010-07-09	38991	\N	3659356	\N
3853203	GENERIC_DAY	0	0	f	2010-06-26	3513191	\N	3659356	\N
3853204	GENERIC_DAY	0	6	f	2010-06-30	3513191	\N	3659356	\N
3853205	GENERIC_DAY	0	6	f	2010-07-13	38991	\N	3659356	\N
3853206	GENERIC_DAY	0	6	f	2010-07-07	3513191	\N	3659356	\N
3853207	GENERIC_DAY	0	6	f	2010-06-29	38991	\N	3659356	\N
3853208	GENERIC_DAY	0	6	f	2010-07-02	3513191	\N	3659356	\N
3853209	GENERIC_DAY	0	0	f	2010-07-10	38991	\N	3659356	\N
3853210	GENERIC_DAY	0	0	f	2010-06-27	38991	\N	3659356	\N
3853211	GENERIC_DAY	0	6	f	2010-07-12	3513191	\N	3659356	\N
3853212	GENERIC_DAY	0	6	f	2010-07-08	38991	\N	3659356	\N
3853213	GENERIC_DAY	0	6	f	2010-07-13	3513191	\N	3659356	\N
3853214	GENERIC_DAY	0	6	f	2010-06-30	38991	\N	3659356	\N
3853215	GENERIC_DAY	0	6	f	2010-07-12	38991	\N	3659356	\N
3853216	GENERIC_DAY	0	0	f	2010-07-03	3513191	\N	3659356	\N
3853217	GENERIC_DAY	0	0	f	2010-07-04	3513191	\N	3659356	\N
3853218	GENERIC_DAY	0	0	f	2010-06-27	3513191	\N	3659356	\N
3853219	GENERIC_DAY	0	6	f	2010-07-05	38991	\N	3659356	\N
3853220	GENERIC_DAY	0	0	f	2010-07-11	3513191	\N	3659356	\N
3853221	GENERIC_DAY	0	6	f	2010-06-28	38991	\N	3659356	\N
3853222	GENERIC_DAY	0	0	f	2010-07-04	38991	\N	3659356	\N
3853223	GENERIC_DAY	0	6	f	2010-07-14	38991	\N	3659356	\N
3853224	GENERIC_DAY	0	6	f	2010-07-05	3513191	\N	3659356	\N
3853225	GENERIC_DAY	0	6	f	2010-07-01	38991	\N	3659356	\N
3853226	GENERIC_DAY	0	6	f	2010-07-09	3513191	\N	3659356	\N
3853227	GENERIC_DAY	0	6	f	2010-07-06	38991	\N	3659356	\N
3853228	GENERIC_DAY	0	6	f	2010-07-14	3513191	\N	3659356	\N
3853229	GENERIC_DAY	0	6	f	2010-07-06	3513191	\N	3659356	\N
3853230	GENERIC_DAY	0	6	f	2010-07-15	38991	\N	3659356	\N
3853231	GENERIC_DAY	0	6	f	2010-07-01	3513191	\N	3659356	\N
3853232	GENERIC_DAY	0	0	f	2010-06-26	38991	\N	3659356	\N
3853233	GENERIC_DAY	0	6	f	2010-06-28	3513191	\N	3659356	\N
3853234	GENERIC_DAY	0	6	f	2010-07-20	3513191	\N	3559802	\N
3853235	GENERIC_DAY	0	6	f	2010-07-21	3513191	\N	3559802	\N
3853236	GENERIC_DAY	0	6	f	2010-07-22	38991	\N	3559802	\N
3853237	GENERIC_DAY	0	6	f	2010-07-22	3513191	\N	3559802	\N
3853238	GENERIC_DAY	0	0	f	2010-07-17	38991	\N	3559802	\N
3853239	GENERIC_DAY	0	6	f	2010-07-26	38991	\N	3559802	\N
3853240	GENERIC_DAY	0	4	f	2010-07-28	38991	\N	3559802	\N
3853241	GENERIC_DAY	0	6	f	2010-07-19	3513191	\N	3559802	\N
3853242	GENERIC_DAY	0	6	f	2010-07-20	38991	\N	3559802	\N
3853243	GENERIC_DAY	0	0	f	2010-07-24	3513191	\N	3559802	\N
3853244	GENERIC_DAY	0	6	f	2010-07-23	38991	\N	3559802	\N
3853245	GENERIC_DAY	0	0	f	2010-07-17	3513191	\N	3559802	\N
3853246	GENERIC_DAY	0	6	f	2010-07-19	38991	\N	3559802	\N
3853247	GENERIC_DAY	0	0	f	2010-07-18	3513191	\N	3559802	\N
3853248	GENERIC_DAY	0	6	f	2010-07-26	3513191	\N	3559802	\N
3853249	GENERIC_DAY	0	6	f	2010-07-27	3513191	\N	3559802	\N
3853250	GENERIC_DAY	0	0	f	2010-07-18	38991	\N	3559802	\N
3853251	GENERIC_DAY	0	6	f	2010-07-21	38991	\N	3559802	\N
3853252	GENERIC_DAY	0	6	f	2010-07-23	3513191	\N	3559802	\N
3853253	GENERIC_DAY	0	6	f	2010-07-16	38991	\N	3559802	\N
3853254	GENERIC_DAY	0	0	f	2010-07-24	38991	\N	3559802	\N
3853255	GENERIC_DAY	0	6	f	2010-07-16	3513191	\N	3559802	\N
3853256	GENERIC_DAY	0	4	f	2010-07-28	3513191	\N	3559802	\N
3853257	GENERIC_DAY	0	0	f	2010-07-25	3513191	\N	3559802	\N
3853258	GENERIC_DAY	0	6	f	2010-07-27	38991	\N	3559802	\N
3853259	GENERIC_DAY	0	0	f	2010-07-25	38991	\N	3559802	\N
3853260	GENERIC_DAY	0	6	f	2010-07-29	38991	\N	3559803	\N
3853261	GENERIC_DAY	0	6	f	2010-08-02	38991	\N	3559803	\N
3853262	GENERIC_DAY	0	0	f	2010-08-01	38991	\N	3559803	\N
3853263	GENERIC_DAY	0	0	f	2010-08-01	3513191	\N	3559803	\N
3853264	GENERIC_DAY	0	0	f	2010-07-31	3513191	\N	3559803	\N
3853265	GENERIC_DAY	0	0	f	2010-07-31	38991	\N	3559803	\N
3853266	GENERIC_DAY	0	4	f	2010-08-04	38991	\N	3559803	\N
3853267	GENERIC_DAY	0	4	f	2010-08-04	3513191	\N	3559803	\N
3853268	GENERIC_DAY	0	6	f	2010-07-30	3513191	\N	3559803	\N
3853269	GENERIC_DAY	0	6	f	2010-08-03	3513191	\N	3559803	\N
3853270	GENERIC_DAY	0	6	f	2010-08-03	38991	\N	3559803	\N
3853271	GENERIC_DAY	0	6	f	2010-07-30	38991	\N	3559803	\N
3853272	GENERIC_DAY	0	6	f	2010-08-02	3513191	\N	3559803	\N
3853273	GENERIC_DAY	0	6	f	2010-07-29	3513191	\N	3559803	\N
3853274	GENERIC_DAY	0	4	f	2010-01-15	3513191	\N	3518385	\N
3853275	GENERIC_DAY	0	0	f	2010-01-17	38991	\N	3518385	\N
3853276	GENERIC_DAY	0	4	f	2010-01-13	3513191	\N	3518385	\N
3853277	GENERIC_DAY	0	0	f	2010-01-16	3513191	\N	3518385	\N
3853278	GENERIC_DAY	0	4	f	2010-01-13	38991	\N	3518385	\N
3853279	GENERIC_DAY	0	4	f	2010-01-19	38991	\N	3518385	\N
3853280	GENERIC_DAY	0	4	f	2010-01-19	3513191	\N	3518385	\N
3853281	GENERIC_DAY	0	4	f	2010-01-15	38991	\N	3518385	\N
3853282	GENERIC_DAY	0	4	f	2010-01-14	3513191	\N	3518385	\N
3853283	GENERIC_DAY	0	4	f	2010-01-18	3513191	\N	3518385	\N
3853284	GENERIC_DAY	0	4	f	2010-01-14	38991	\N	3518385	\N
3853285	GENERIC_DAY	0	0	f	2010-01-17	3513191	\N	3518385	\N
3853286	GENERIC_DAY	0	4	f	2010-01-12	3513191	\N	3518385	\N
3853287	GENERIC_DAY	0	4	f	2010-01-12	38991	\N	3518385	\N
3853288	GENERIC_DAY	0	0	f	2010-01-16	38991	\N	3518385	\N
3853289	GENERIC_DAY	0	4	f	2010-01-18	38991	\N	3518385	\N
3853290	GENERIC_DAY	0	4	f	2010-01-22	38991	\N	3518386	\N
3853291	GENERIC_DAY	0	0	f	2010-01-23	38991	\N	3518386	\N
3853292	GENERIC_DAY	0	0	f	2010-01-24	3513191	\N	3518386	\N
3853293	GENERIC_DAY	0	4	f	2010-01-26	3513191	\N	3518386	\N
3853294	GENERIC_DAY	0	4	f	2010-01-21	3513191	\N	3518386	\N
3853295	GENERIC_DAY	0	0	f	2010-01-23	3513191	\N	3518386	\N
3853296	GENERIC_DAY	0	4	f	2010-01-26	38991	\N	3518386	\N
3853297	GENERIC_DAY	0	4	f	2010-01-25	38991	\N	3518386	\N
3853298	GENERIC_DAY	0	4	f	2010-01-22	3513191	\N	3518386	\N
3853299	GENERIC_DAY	0	4	f	2010-01-20	3513191	\N	3518386	\N
3853300	GENERIC_DAY	0	4	f	2010-01-25	3513191	\N	3518386	\N
3853301	GENERIC_DAY	0	0	f	2010-01-24	38991	\N	3518386	\N
3853302	GENERIC_DAY	0	4	f	2010-01-21	38991	\N	3518386	\N
3853303	GENERIC_DAY	0	4	f	2010-01-20	38991	\N	3518386	\N
3853304	GENERIC_DAY	0	4	f	2010-02-01	38991	\N	3518387	\N
3853305	GENERIC_DAY	0	4	f	2010-01-29	38991	\N	3518387	\N
3853306	GENERIC_DAY	0	4	f	2010-01-28	3513191	\N	3518387	\N
3853307	GENERIC_DAY	0	4	f	2010-02-01	3513191	\N	3518387	\N
3853308	GENERIC_DAY	0	4	f	2010-02-04	3513191	\N	3518387	\N
3853309	GENERIC_DAY	0	4	f	2010-02-03	38991	\N	3518387	\N
3853310	GENERIC_DAY	0	4	f	2010-01-27	3513191	\N	3518387	\N
3853311	GENERIC_DAY	0	0	f	2010-01-31	38991	\N	3518387	\N
3853312	GENERIC_DAY	0	4	f	2010-02-03	3513191	\N	3518387	\N
3853313	GENERIC_DAY	0	0	f	2010-01-30	38991	\N	3518387	\N
3853314	GENERIC_DAY	0	4	f	2010-02-02	38991	\N	3518387	\N
3853315	GENERIC_DAY	0	0	f	2010-01-31	3513191	\N	3518387	\N
3853316	GENERIC_DAY	0	4	f	2010-01-27	38991	\N	3518387	\N
3853317	GENERIC_DAY	0	0	f	2010-01-30	3513191	\N	3518387	\N
3853318	GENERIC_DAY	0	4	f	2010-02-02	3513191	\N	3518387	\N
3853319	GENERIC_DAY	0	4	f	2010-01-29	3513191	\N	3518387	\N
3853320	GENERIC_DAY	0	4	f	2010-02-04	38991	\N	3518387	\N
3853321	GENERIC_DAY	0	4	f	2010-01-28	38991	\N	3518387	\N
3853322	GENERIC_DAY	0	4	f	2010-02-22	38991	\N	3518388	\N
3853323	GENERIC_DAY	0	4	f	2010-02-12	38991	\N	3518388	\N
3853324	GENERIC_DAY	0	0	f	2010-02-14	38991	\N	3518388	\N
3853325	GENERIC_DAY	0	4	f	2010-02-09	38991	\N	3518388	\N
3853326	GENERIC_DAY	0	4	f	2010-02-15	38991	\N	3518388	\N
3853327	GENERIC_DAY	0	4	f	2010-02-19	3513191	\N	3518388	\N
3853328	GENERIC_DAY	0	4	f	2010-02-08	3513191	\N	3518388	\N
3853329	GENERIC_DAY	0	0	f	2010-02-20	38991	\N	3518388	\N
3853330	GENERIC_DAY	0	0	f	2010-02-20	3513191	\N	3518388	\N
3853331	GENERIC_DAY	0	4	f	2010-02-08	38991	\N	3518388	\N
3853332	GENERIC_DAY	0	4	f	2010-02-16	38991	\N	3518388	\N
3853333	GENERIC_DAY	0	4	f	2010-02-11	38991	\N	3518388	\N
3853334	GENERIC_DAY	0	0	f	2010-02-06	38991	\N	3518388	\N
3853335	GENERIC_DAY	0	4	f	2010-02-18	3513191	\N	3518388	\N
3853336	GENERIC_DAY	0	0	f	2010-02-13	38991	\N	3518388	\N
3853337	GENERIC_DAY	0	0	f	2010-02-06	3513191	\N	3518388	\N
3853338	GENERIC_DAY	0	0	f	2010-02-07	3513191	\N	3518388	\N
3853339	GENERIC_DAY	0	0	f	2010-02-13	3513191	\N	3518388	\N
3853340	GENERIC_DAY	0	4	f	2010-02-22	3513191	\N	3518388	\N
3853341	GENERIC_DAY	0	0	f	2010-02-14	3513191	\N	3518388	\N
3853342	GENERIC_DAY	0	0	f	2010-02-21	38991	\N	3518388	\N
3853343	GENERIC_DAY	0	4	f	2010-02-17	38991	\N	3518388	\N
3853344	GENERIC_DAY	0	4	f	2010-02-11	3513191	\N	3518388	\N
3853345	GENERIC_DAY	0	4	f	2010-02-16	3513191	\N	3518388	\N
3853346	GENERIC_DAY	0	4	f	2010-02-17	3513191	\N	3518388	\N
3853347	GENERIC_DAY	0	4	f	2010-02-10	38991	\N	3518388	\N
3853348	GENERIC_DAY	0	4	f	2010-02-15	3513191	\N	3518388	\N
3853349	GENERIC_DAY	0	0	f	2010-02-21	3513191	\N	3518388	\N
3853350	GENERIC_DAY	0	4	f	2010-02-12	3513191	\N	3518388	\N
3853351	GENERIC_DAY	0	4	f	2010-02-05	38991	\N	3518388	\N
3853352	GENERIC_DAY	0	4	f	2010-02-19	38991	\N	3518388	\N
3853353	GENERIC_DAY	0	4	f	2010-02-09	3513191	\N	3518388	\N
3853354	GENERIC_DAY	0	4	f	2010-02-05	3513191	\N	3518388	\N
3853355	GENERIC_DAY	0	4	f	2010-02-18	38991	\N	3518388	\N
3853356	GENERIC_DAY	0	4	f	2010-02-10	3513191	\N	3518388	\N
3853357	GENERIC_DAY	0	0	f	2010-02-07	38991	\N	3518388	\N
3853358	GENERIC_DAY	0	0	f	2010-02-28	38991	\N	3819135	\N
3853359	GENERIC_DAY	0	4	f	2010-03-03	38991	\N	3819135	\N
3853360	GENERIC_DAY	0	0	f	2010-02-28	3513191	\N	3819135	\N
3853361	GENERIC_DAY	0	4	f	2010-02-24	38991	\N	3819135	\N
3853362	GENERIC_DAY	0	4	f	2010-03-05	3513191	\N	3819135	\N
3853363	GENERIC_DAY	0	4	f	2010-03-05	38991	\N	3819135	\N
3853364	GENERIC_DAY	0	0	f	2010-02-27	38991	\N	3819135	\N
3853365	GENERIC_DAY	0	4	f	2010-03-01	38991	\N	3819135	\N
3853366	GENERIC_DAY	0	0	f	2010-03-07	38991	\N	3819135	\N
3853367	GENERIC_DAY	0	4	f	2010-03-02	3513191	\N	3819135	\N
3853368	GENERIC_DAY	0	4	f	2010-03-02	38991	\N	3819135	\N
3853369	GENERIC_DAY	0	4	f	2010-02-23	38991	\N	3819135	\N
3853370	GENERIC_DAY	0	4	f	2010-02-26	38991	\N	3819135	\N
3853371	GENERIC_DAY	0	0	f	2010-03-06	38991	\N	3819135	\N
3853372	GENERIC_DAY	0	4	f	2010-02-26	3513191	\N	3819135	\N
3853373	GENERIC_DAY	0	0	f	2010-03-07	3513191	\N	3819135	\N
3853374	GENERIC_DAY	0	4	f	2010-03-09	38991	\N	3819135	\N
3853375	GENERIC_DAY	0	4	f	2010-03-09	3513191	\N	3819135	\N
3853376	GENERIC_DAY	0	4	f	2010-03-03	3513191	\N	3819135	\N
3853377	GENERIC_DAY	0	4	f	2010-03-10	38991	\N	3819135	\N
3853378	GENERIC_DAY	0	4	f	2010-03-04	38991	\N	3819135	\N
3853379	GENERIC_DAY	0	4	f	2010-03-08	38991	\N	3819135	\N
3853380	GENERIC_DAY	0	4	f	2010-03-04	3513191	\N	3819135	\N
3853381	GENERIC_DAY	0	4	f	2010-03-08	3513191	\N	3819135	\N
3853382	GENERIC_DAY	0	0	f	2010-03-06	3513191	\N	3819135	\N
3853383	GENERIC_DAY	0	4	f	2010-02-23	3513191	\N	3819135	\N
3853384	GENERIC_DAY	0	4	f	2010-02-24	3513191	\N	3819135	\N
3853385	GENERIC_DAY	0	0	f	2010-02-27	3513191	\N	3819135	\N
3853386	GENERIC_DAY	0	4	f	2010-03-10	3513191	\N	3819135	\N
3853387	GENERIC_DAY	0	4	f	2010-02-25	38991	\N	3819135	\N
3853388	GENERIC_DAY	0	4	f	2010-03-01	3513191	\N	3819135	\N
3853389	GENERIC_DAY	0	4	f	2010-02-25	3513191	\N	3819135	\N
3853390	GENERIC_DAY	0	4	f	2010-03-23	38991	\N	3522858	\N
3853391	GENERIC_DAY	0	4	f	2010-03-17	38991	\N	3522858	\N
3853392	GENERIC_DAY	0	4	f	2010-03-12	38991	\N	3522858	\N
3853393	GENERIC_DAY	0	0	f	2010-03-20	3513191	\N	3522858	\N
3853394	GENERIC_DAY	0	0	f	2010-03-14	3513191	\N	3522858	\N
3853395	GENERIC_DAY	0	4	f	2010-03-15	38991	\N	3522858	\N
3853396	GENERIC_DAY	0	4	f	2010-03-18	3513191	\N	3522858	\N
3853397	GENERIC_DAY	0	4	f	2010-03-22	3513191	\N	3522858	\N
3853398	GENERIC_DAY	0	0	f	2010-03-20	38991	\N	3522858	\N
3853399	GENERIC_DAY	0	4	f	2010-03-16	3513191	\N	3522858	\N
3853400	GENERIC_DAY	0	4	f	2010-03-19	38991	\N	3522858	\N
3853401	GENERIC_DAY	0	0	f	2010-03-14	38991	\N	3522858	\N
3853402	GENERIC_DAY	0	0	f	2010-03-21	38991	\N	3522858	\N
3853403	GENERIC_DAY	0	4	f	2010-03-12	3513191	\N	3522858	\N
3853404	GENERIC_DAY	0	0	f	2010-03-13	38991	\N	3522858	\N
3853405	GENERIC_DAY	0	4	f	2010-03-15	3513191	\N	3522858	\N
3853406	GENERIC_DAY	0	4	f	2010-03-22	38991	\N	3522858	\N
3853407	GENERIC_DAY	0	0	f	2010-03-21	3513191	\N	3522858	\N
3853408	GENERIC_DAY	0	0	f	2010-03-13	3513191	\N	3522858	\N
3853409	GENERIC_DAY	0	4	f	2010-03-18	38991	\N	3522858	\N
3853410	GENERIC_DAY	0	4	f	2010-03-11	38991	\N	3522858	\N
3853411	GENERIC_DAY	0	4	f	2010-03-17	3513191	\N	3522858	\N
3853412	GENERIC_DAY	0	4	f	2010-03-11	3513191	\N	3522858	\N
3853413	GENERIC_DAY	0	4	f	2010-03-23	3513191	\N	3522858	\N
3853414	GENERIC_DAY	0	4	f	2010-03-16	38991	\N	3522858	\N
3853415	GENERIC_DAY	0	4	f	2010-03-19	3513191	\N	3522858	\N
3853416	GENERIC_DAY	0	4	f	2010-03-30	3513191	\N	3522859	\N
3853417	GENERIC_DAY	0	0	f	2010-03-27	38991	\N	3522859	\N
3853418	GENERIC_DAY	0	0	f	2010-03-27	3513191	\N	3522859	\N
3853419	GENERIC_DAY	0	0	f	2010-03-28	38991	\N	3522859	\N
3853420	GENERIC_DAY	0	4	f	2010-03-26	38991	\N	3522859	\N
3853421	GENERIC_DAY	0	4	f	2010-03-25	38991	\N	3522859	\N
3853422	GENERIC_DAY	0	4	f	2010-03-24	3513191	\N	3522859	\N
3853423	GENERIC_DAY	0	4	f	2010-03-29	38991	\N	3522859	\N
3853424	GENERIC_DAY	0	0	f	2010-03-28	3513191	\N	3522859	\N
3853425	GENERIC_DAY	0	4	f	2010-03-26	3513191	\N	3522859	\N
3853426	GENERIC_DAY	0	4	f	2010-03-31	38991	\N	3522859	\N
3853427	GENERIC_DAY	0	4	f	2010-03-30	38991	\N	3522859	\N
3853428	GENERIC_DAY	0	4	f	2010-03-24	38991	\N	3522859	\N
3853429	GENERIC_DAY	0	4	f	2010-03-25	3513191	\N	3522859	\N
3853430	GENERIC_DAY	0	4	f	2010-03-29	3513191	\N	3522859	\N
3853431	GENERIC_DAY	0	4	f	2010-03-31	3513191	\N	3522859	\N
3853432	GENERIC_DAY	0	4	f	2010-04-09	3513191	\N	3522860	\N
3853433	GENERIC_DAY	0	4	f	2010-04-12	38991	\N	3522860	\N
3853434	GENERIC_DAY	0	0	f	2010-04-03	3513191	\N	3522860	\N
3853435	GENERIC_DAY	0	0	f	2010-04-10	38991	\N	3522860	\N
3853436	GENERIC_DAY	0	0	f	2010-04-11	38991	\N	3522860	\N
3853437	GENERIC_DAY	0	4	f	2010-04-06	38991	\N	3522860	\N
3853438	GENERIC_DAY	0	4	f	2010-04-05	38991	\N	3522860	\N
3853439	GENERIC_DAY	0	0	f	2010-04-10	3513191	\N	3522860	\N
3853440	GENERIC_DAY	0	4	f	2010-04-07	38991	\N	3522860	\N
3853441	GENERIC_DAY	0	0	f	2010-04-04	38991	\N	3522860	\N
3853442	GENERIC_DAY	0	4	f	2010-04-01	3513191	\N	3522860	\N
3853443	GENERIC_DAY	0	4	f	2010-04-02	3513191	\N	3522860	\N
3853444	GENERIC_DAY	0	4	f	2010-04-01	38991	\N	3522860	\N
3853445	GENERIC_DAY	0	4	f	2010-04-08	38991	\N	3522860	\N
3853446	GENERIC_DAY	0	4	f	2010-04-05	3513191	\N	3522860	\N
3853447	GENERIC_DAY	0	4	f	2010-04-09	38991	\N	3522860	\N
3853448	GENERIC_DAY	0	4	f	2010-04-08	3513191	\N	3522860	\N
3853449	GENERIC_DAY	0	4	f	2010-04-06	3513191	\N	3522860	\N
3853450	GENERIC_DAY	0	4	f	2010-04-12	3513191	\N	3522860	\N
3853451	GENERIC_DAY	0	0	f	2010-04-11	3513191	\N	3522860	\N
3853452	GENERIC_DAY	0	4	f	2010-04-07	3513191	\N	3522860	\N
3853453	GENERIC_DAY	0	0	f	2010-04-04	3513191	\N	3522860	\N
3853454	GENERIC_DAY	0	0	f	2010-04-03	38991	\N	3522860	\N
3853455	GENERIC_DAY	0	4	f	2010-04-02	38991	\N	3522860	\N
3853456	GENERIC_DAY	0	4	f	2010-04-14	38991	\N	3522861	\N
3853457	GENERIC_DAY	0	4	f	2010-04-14	3513191	\N	3522861	\N
3853458	GENERIC_DAY	0	4	f	2010-04-16	38991	\N	3522861	\N
3853459	GENERIC_DAY	0	4	f	2010-04-15	3513191	\N	3522861	\N
3853460	GENERIC_DAY	0	4	f	2010-04-15	38991	\N	3522861	\N
3853461	GENERIC_DAY	0	4	f	2010-04-13	3513191	\N	3522861	\N
3853462	GENERIC_DAY	0	4	f	2010-04-13	38991	\N	3522861	\N
3853463	GENERIC_DAY	0	4	f	2010-04-16	3513191	\N	3522861	\N
3853464	GENERIC_DAY	0	4	f	2010-04-23	38991	\N	3522862	\N
3853465	GENERIC_DAY	0	4	f	2010-04-20	38991	\N	3522862	\N
3853466	GENERIC_DAY	0	0	f	2010-04-18	38991	\N	3522862	\N
3853467	GENERIC_DAY	0	4	f	2010-04-19	38991	\N	3522862	\N
3853468	GENERIC_DAY	0	4	f	2010-04-20	3513191	\N	3522862	\N
3853469	GENERIC_DAY	0	4	f	2010-04-22	3513191	\N	3522862	\N
3853470	GENERIC_DAY	0	4	f	2010-04-22	38991	\N	3522862	\N
3853471	GENERIC_DAY	0	4	f	2010-04-21	3513191	\N	3522862	\N
3853472	GENERIC_DAY	0	0	f	2010-04-17	3513191	\N	3522862	\N
3853473	GENERIC_DAY	0	0	f	2010-04-18	3513191	\N	3522862	\N
3853474	GENERIC_DAY	0	4	f	2010-04-19	3513191	\N	3522862	\N
3853475	GENERIC_DAY	0	0	f	2010-04-17	38991	\N	3522862	\N
3853476	GENERIC_DAY	0	4	f	2010-04-21	38991	\N	3522862	\N
3853477	GENERIC_DAY	0	4	f	2010-04-23	3513191	\N	3522862	\N
3853478	GENERIC_DAY	0	4	f	2010-05-03	3513191	\N	3522863	\N
3853479	GENERIC_DAY	0	4	f	2010-04-28	3513191	\N	3522863	\N
3853480	GENERIC_DAY	0	4	f	2010-04-27	3513191	\N	3522863	\N
3853481	GENERIC_DAY	0	0	f	2010-05-02	3513191	\N	3522863	\N
3853482	GENERIC_DAY	0	4	f	2010-05-05	3513191	\N	3522863	\N
3853483	GENERIC_DAY	0	0	f	2010-05-01	38991	\N	3522863	\N
3853484	GENERIC_DAY	0	4	f	2010-04-26	38991	\N	3522863	\N
3853485	GENERIC_DAY	0	4	f	2010-04-30	3513191	\N	3522863	\N
3853486	GENERIC_DAY	0	0	f	2010-05-01	3513191	\N	3522863	\N
3853487	GENERIC_DAY	0	0	f	2010-04-25	38991	\N	3522863	\N
3853488	GENERIC_DAY	0	4	f	2010-04-29	3513191	\N	3522863	\N
3853489	GENERIC_DAY	0	4	f	2010-05-04	3513191	\N	3522863	\N
3853490	GENERIC_DAY	0	4	f	2010-04-26	3513191	\N	3522863	\N
3853491	GENERIC_DAY	0	4	f	2010-04-30	38991	\N	3522863	\N
3853492	GENERIC_DAY	0	4	f	2010-05-03	38991	\N	3522863	\N
3853493	GENERIC_DAY	0	4	f	2010-04-28	38991	\N	3522863	\N
3853494	GENERIC_DAY	0	0	f	2010-04-24	3513191	\N	3522863	\N
3853495	GENERIC_DAY	0	4	f	2010-05-04	38991	\N	3522863	\N
3853496	GENERIC_DAY	0	0	f	2010-04-24	38991	\N	3522863	\N
3853497	GENERIC_DAY	0	4	f	2010-04-29	38991	\N	3522863	\N
3853498	GENERIC_DAY	0	0	f	2010-05-02	38991	\N	3522863	\N
3853499	GENERIC_DAY	0	0	f	2010-04-25	3513191	\N	3522863	\N
3853500	GENERIC_DAY	0	4	f	2010-05-05	38991	\N	3522863	\N
3853501	GENERIC_DAY	0	4	f	2010-04-27	38991	\N	3522863	\N
3853502	GENERIC_DAY	0	4	f	2010-05-18	38991	\N	3522864	\N
3853503	GENERIC_DAY	0	4	f	2010-05-21	38991	\N	3522864	\N
3853504	GENERIC_DAY	0	0	f	2010-05-16	38991	\N	3522864	\N
3853505	GENERIC_DAY	0	4	f	2010-05-10	38991	\N	3522864	\N
3853506	GENERIC_DAY	0	4	f	2010-05-10	3513191	\N	3522864	\N
3853507	GENERIC_DAY	0	4	f	2010-05-20	38991	\N	3522864	\N
3853508	GENERIC_DAY	0	0	f	2010-05-16	3513191	\N	3522864	\N
3853509	GENERIC_DAY	0	4	f	2010-05-06	3513191	\N	3522864	\N
3853510	GENERIC_DAY	0	0	f	2010-05-09	3513191	\N	3522864	\N
3853511	GENERIC_DAY	0	4	f	2010-05-07	3513191	\N	3522864	\N
3853512	GENERIC_DAY	0	4	f	2010-05-13	38991	\N	3522864	\N
3853513	GENERIC_DAY	0	0	f	2010-05-23	3513191	\N	3522864	\N
3853514	GENERIC_DAY	0	4	f	2010-05-11	3513191	\N	3522864	\N
3853515	GENERIC_DAY	0	4	f	2010-05-25	3513191	\N	3522864	\N
3853516	GENERIC_DAY	0	0	f	2010-05-15	3513191	\N	3522864	\N
3853517	GENERIC_DAY	0	4	f	2010-05-19	3513191	\N	3522864	\N
3853518	GENERIC_DAY	0	4	f	2010-05-07	38991	\N	3522864	\N
3853519	GENERIC_DAY	0	4	f	2010-05-11	38991	\N	3522864	\N
3853520	GENERIC_DAY	0	4	f	2010-05-24	3513191	\N	3522864	\N
3853521	GENERIC_DAY	0	0	f	2010-05-22	3513191	\N	3522864	\N
3853522	GENERIC_DAY	0	4	f	2010-05-06	38991	\N	3522864	\N
3853523	GENERIC_DAY	0	4	f	2010-05-24	38991	\N	3522864	\N
3853524	GENERIC_DAY	0	0	f	2010-05-08	3513191	\N	3522864	\N
3853525	GENERIC_DAY	0	4	f	2010-05-13	3513191	\N	3522864	\N
3853526	GENERIC_DAY	0	4	f	2010-05-14	38991	\N	3522864	\N
3853527	GENERIC_DAY	0	4	f	2010-05-25	38991	\N	3522864	\N
3853528	GENERIC_DAY	0	0	f	2010-05-08	38991	\N	3522864	\N
3853529	GENERIC_DAY	0	4	f	2010-05-19	38991	\N	3522864	\N
3853530	GENERIC_DAY	0	0	f	2010-05-22	38991	\N	3522864	\N
3853531	GENERIC_DAY	0	4	f	2010-05-21	3513191	\N	3522864	\N
3853532	GENERIC_DAY	0	4	f	2010-05-20	3513191	\N	3522864	\N
3853533	GENERIC_DAY	0	4	f	2010-05-14	3513191	\N	3522864	\N
3853534	GENERIC_DAY	0	4	f	2010-05-12	3513191	\N	3522864	\N
3853535	GENERIC_DAY	0	4	f	2010-05-18	3513191	\N	3522864	\N
3853536	GENERIC_DAY	0	0	f	2010-05-09	38991	\N	3522864	\N
3853537	GENERIC_DAY	0	0	f	2010-05-23	38991	\N	3522864	\N
3853538	GENERIC_DAY	0	4	f	2010-05-17	38991	\N	3522864	\N
3853539	GENERIC_DAY	0	4	f	2010-05-17	3513191	\N	3522864	\N
3853540	GENERIC_DAY	0	4	f	2010-05-12	38991	\N	3522864	\N
3853541	GENERIC_DAY	0	0	f	2010-05-15	38991	\N	3522864	\N
3853542	GENERIC_DAY	0	4	f	2010-06-08	3513191	\N	3522865	\N
3853543	GENERIC_DAY	0	4	f	2010-06-01	3513191	\N	3522865	\N
3853544	GENERIC_DAY	0	4	f	2010-06-11	3513191	\N	3522865	\N
3853545	GENERIC_DAY	0	4	f	2010-06-08	38991	\N	3522865	\N
3853546	GENERIC_DAY	0	4	f	2010-06-02	3513191	\N	3522865	\N
3853547	GENERIC_DAY	0	0	f	2010-05-30	38991	\N	3522865	\N
3853548	GENERIC_DAY	0	4	f	2010-06-18	3513191	\N	3522865	\N
3853549	GENERIC_DAY	0	0	f	2010-06-13	38991	\N	3522865	\N
3853550	GENERIC_DAY	0	4	f	2010-06-04	38991	\N	3522865	\N
3853551	GENERIC_DAY	0	0	f	2010-05-29	3513191	\N	3522865	\N
3853552	GENERIC_DAY	0	4	f	2010-05-26	3513191	\N	3522865	\N
3853553	GENERIC_DAY	0	4	f	2010-06-14	38991	\N	3522865	\N
3853554	GENERIC_DAY	0	0	f	2010-06-05	38991	\N	3522865	\N
3853555	GENERIC_DAY	0	4	f	2010-05-31	38991	\N	3522865	\N
3853556	GENERIC_DAY	0	4	f	2010-06-04	3513191	\N	3522865	\N
3853557	GENERIC_DAY	0	4	f	2010-06-10	38991	\N	3522865	\N
3853558	GENERIC_DAY	0	4	f	2010-06-02	38991	\N	3522865	\N
3853559	GENERIC_DAY	0	4	f	2010-06-03	38991	\N	3522865	\N
3853560	GENERIC_DAY	0	4	f	2010-05-28	38991	\N	3522865	\N
3853561	GENERIC_DAY	0	0	f	2010-05-30	3513191	\N	3522865	\N
3853562	GENERIC_DAY	0	0	f	2010-06-06	3513191	\N	3522865	\N
3853563	GENERIC_DAY	0	4	f	2010-06-09	38991	\N	3522865	\N
3853564	GENERIC_DAY	0	4	f	2010-05-26	38991	\N	3522865	\N
3853565	GENERIC_DAY	0	0	f	2010-06-12	38991	\N	3522865	\N
3853566	GENERIC_DAY	0	4	f	2010-06-15	38991	\N	3522865	\N
3853567	GENERIC_DAY	0	4	f	2010-05-31	3513191	\N	3522865	\N
3853568	GENERIC_DAY	0	4	f	2010-06-09	3513191	\N	3522865	\N
3853569	GENERIC_DAY	0	0	f	2010-06-05	3513191	\N	3522865	\N
3853570	GENERIC_DAY	0	4	f	2010-06-15	3513191	\N	3522865	\N
3853571	GENERIC_DAY	0	0	f	2010-06-06	38991	\N	3522865	\N
3853572	GENERIC_DAY	0	4	f	2010-06-18	38991	\N	3522865	\N
3853573	GENERIC_DAY	0	4	f	2010-06-01	38991	\N	3522865	\N
3853574	GENERIC_DAY	0	4	f	2010-05-27	38991	\N	3522865	\N
3853575	GENERIC_DAY	0	4	f	2010-06-17	3513191	\N	3522865	\N
3853576	GENERIC_DAY	0	4	f	2010-06-11	38991	\N	3522865	\N
3853577	GENERIC_DAY	0	0	f	2010-05-29	38991	\N	3522865	\N
3853578	GENERIC_DAY	0	4	f	2010-05-27	3513191	\N	3522865	\N
3853579	GENERIC_DAY	0	0	f	2010-06-12	3513191	\N	3522865	\N
3853580	GENERIC_DAY	0	4	f	2010-06-07	38991	\N	3522865	\N
3853581	GENERIC_DAY	0	4	f	2010-06-10	3513191	\N	3522865	\N
3853582	GENERIC_DAY	0	4	f	2010-06-07	3513191	\N	3522865	\N
3853583	GENERIC_DAY	0	4	f	2010-06-14	3513191	\N	3522865	\N
3853584	GENERIC_DAY	0	4	f	2010-06-16	3513191	\N	3522865	\N
3853585	GENERIC_DAY	0	4	f	2010-06-03	3513191	\N	3522865	\N
3853586	GENERIC_DAY	0	4	f	2010-06-16	38991	\N	3522865	\N
3853587	GENERIC_DAY	0	4	f	2010-05-28	3513191	\N	3522865	\N
3853588	GENERIC_DAY	0	0	f	2010-06-13	3513191	\N	3522865	\N
3853589	GENERIC_DAY	0	4	f	2010-06-17	38991	\N	3522865	\N
3853590	GENERIC_DAY	0	1	f	2010-04-09	38991	\N	3518353	\N
3853591	GENERIC_DAY	0	0	f	2010-03-13	38991	\N	3518353	\N
3853592	GENERIC_DAY	0	1	f	2010-03-26	3513191	\N	3518353	\N
3853593	GENERIC_DAY	0	1	f	2010-03-19	38991	\N	3518353	\N
3853594	GENERIC_DAY	0	1	f	2010-04-08	38991	\N	3518353	\N
3853595	GENERIC_DAY	0	0	f	2010-03-20	3513191	\N	3518353	\N
3853596	GENERIC_DAY	0	0	f	2010-03-14	38991	\N	3518353	\N
3853597	GENERIC_DAY	0	1	f	2010-03-29	38991	\N	3518353	\N
3853598	GENERIC_DAY	0	1	f	2010-04-07	3513191	\N	3518353	\N
3853599	GENERIC_DAY	0	0	f	2010-03-13	3513191	\N	3518353	\N
3853600	GENERIC_DAY	0	1	f	2010-03-15	3513191	\N	3518353	\N
3853601	GENERIC_DAY	0	1	f	2010-03-24	38991	\N	3518353	\N
3853602	GENERIC_DAY	0	1	f	2010-03-22	3513191	\N	3518353	\N
3853603	GENERIC_DAY	0	1	f	2010-03-31	38991	\N	3518353	\N
3853604	GENERIC_DAY	0	0	f	2010-04-04	3513191	\N	3518353	\N
3853605	GENERIC_DAY	0	0	f	2010-03-27	38991	\N	3518353	\N
3853606	GENERIC_DAY	0	1	f	2010-04-08	3513191	\N	3518353	\N
3853607	GENERIC_DAY	0	1	f	2010-03-16	38991	\N	3518353	\N
3853608	GENERIC_DAY	0	1	f	2010-04-05	3513191	\N	3518353	\N
3853609	GENERIC_DAY	0	0	f	2010-03-27	3513191	\N	3518353	\N
3853610	GENERIC_DAY	0	1	f	2010-04-06	38991	\N	3518353	\N
3853611	GENERIC_DAY	0	1	f	2010-04-09	3513191	\N	3518353	\N
3853612	GENERIC_DAY	0	0	f	2010-03-21	38991	\N	3518353	\N
3853613	GENERIC_DAY	0	1	f	2010-03-18	3513191	\N	3518353	\N
3853614	GENERIC_DAY	0	1	f	2010-04-07	38991	\N	3518353	\N
3853615	GENERIC_DAY	0	0	f	2010-03-28	38991	\N	3518353	\N
3853616	GENERIC_DAY	0	1	f	2010-03-26	38991	\N	3518353	\N
3853617	GENERIC_DAY	0	1	f	2010-03-18	38991	\N	3518353	\N
3853618	GENERIC_DAY	0	0	f	2010-03-28	3513191	\N	3518353	\N
3853619	GENERIC_DAY	0	0	f	2010-03-20	38991	\N	3518353	\N
3853620	GENERIC_DAY	0	1	f	2010-03-30	3513191	\N	3518353	\N
3853621	GENERIC_DAY	0	1	f	2010-03-24	3513191	\N	3518353	\N
3853622	GENERIC_DAY	0	1	f	2010-03-22	38991	\N	3518353	\N
3853623	GENERIC_DAY	0	0	f	2010-04-04	38991	\N	3518353	\N
3853624	GENERIC_DAY	0	1	f	2010-03-29	3513191	\N	3518353	\N
3853625	GENERIC_DAY	0	1	f	2010-03-25	3513191	\N	3518353	\N
3853626	GENERIC_DAY	0	1	f	2010-04-05	38991	\N	3518353	\N
3853627	GENERIC_DAY	0	1	f	2010-03-23	38991	\N	3518353	\N
3853628	GENERIC_DAY	0	0	f	2010-03-21	3513191	\N	3518353	\N
3853629	GENERIC_DAY	0	1	f	2010-03-31	3513191	\N	3518353	\N
3853630	GENERIC_DAY	0	0	f	2010-04-03	3513191	\N	3518353	\N
3853631	GENERIC_DAY	0	1	f	2010-04-01	38991	\N	3518353	\N
3853632	GENERIC_DAY	0	1	f	2010-03-25	38991	\N	3518353	\N
3853633	GENERIC_DAY	0	1	f	2010-04-02	3513191	\N	3518353	\N
3853634	GENERIC_DAY	0	1	f	2010-03-19	3513191	\N	3518353	\N
3853635	GENERIC_DAY	0	1	f	2010-04-06	3513191	\N	3518353	\N
3853636	GENERIC_DAY	0	1	f	2010-03-17	3513191	\N	3518353	\N
3853637	GENERIC_DAY	0	1	f	2010-03-17	38991	\N	3518353	\N
3853638	GENERIC_DAY	0	1	f	2010-03-15	38991	\N	3518353	\N
3853639	GENERIC_DAY	0	1	f	2010-03-23	3513191	\N	3518353	\N
3853640	GENERIC_DAY	0	1	f	2010-03-30	38991	\N	3518353	\N
3853641	GENERIC_DAY	0	1	f	2010-04-02	38991	\N	3518353	\N
3853642	GENERIC_DAY	0	1	f	2010-04-01	3513191	\N	3518353	\N
3853643	GENERIC_DAY	0	0	f	2010-03-14	3513191	\N	3518353	\N
3853644	GENERIC_DAY	0	1	f	2010-03-16	3513191	\N	3518353	\N
3853645	GENERIC_DAY	0	0	f	2010-04-03	38991	\N	3518353	\N
3853646	GENERIC_DAY	0	1	f	2010-07-08	38991	\N	3518354	\N
3853647	GENERIC_DAY	0	1	f	2010-08-11	38991	\N	3518354	\N
3853648	GENERIC_DAY	0	1	f	2010-08-18	3513191	\N	3518354	\N
3853649	GENERIC_DAY	0	1	f	2010-08-17	3513191	\N	3518354	\N
3853650	GENERIC_DAY	0	1	f	2010-08-05	3513191	\N	3518354	\N
3853651	GENERIC_DAY	0	1	f	2010-08-09	38991	\N	3518354	\N
3853652	GENERIC_DAY	0	0	f	2010-07-04	3513191	\N	3518354	\N
3853653	GENERIC_DAY	0	1	f	2010-08-20	38991	\N	3518354	\N
3853654	GENERIC_DAY	0	1	f	2010-08-16	3513191	\N	3518354	\N
3853655	GENERIC_DAY	0	1	f	2010-07-29	3513191	\N	3518354	\N
3853656	GENERIC_DAY	0	0	f	2010-06-20	3513191	\N	3518354	\N
3853657	GENERIC_DAY	0	0	f	2010-08-07	38991	\N	3518354	\N
3853658	GENERIC_DAY	0	0	f	2010-06-20	38991	\N	3518354	\N
3853659	GENERIC_DAY	0	1	f	2010-07-02	38991	\N	3518354	\N
3853660	GENERIC_DAY	0	1	f	2010-07-06	3513191	\N	3518354	\N
3853661	GENERIC_DAY	0	1	f	2010-08-17	38991	\N	3518354	\N
3853662	GENERIC_DAY	0	1	f	2010-07-01	38991	\N	3518354	\N
3853663	GENERIC_DAY	0	0	f	2010-08-22	38991	\N	3518354	\N
3853664	GENERIC_DAY	0	1	f	2010-07-20	3513191	\N	3518354	\N
3853665	GENERIC_DAY	0	0	f	2010-07-03	38991	\N	3518354	\N
3853666	GENERIC_DAY	0	0	f	2010-08-07	3513191	\N	3518354	\N
3853667	GENERIC_DAY	0	0	f	2010-08-14	38991	\N	3518354	\N
3853668	GENERIC_DAY	0	1	f	2010-06-23	38991	\N	3518354	\N
3853669	GENERIC_DAY	0	1	f	2010-06-22	3513191	\N	3518354	\N
3853670	GENERIC_DAY	0	1	f	2010-07-23	3513191	\N	3518354	\N
3853671	GENERIC_DAY	0	0	f	2010-06-19	38991	\N	3518354	\N
3853672	GENERIC_DAY	0	1	f	2010-08-12	3513191	\N	3518354	\N
3853673	GENERIC_DAY	0	1	f	2010-07-09	3513191	\N	3518354	\N
3853674	GENERIC_DAY	0	1	f	2010-07-29	38991	\N	3518354	\N
3853675	GENERIC_DAY	0	0	f	2010-07-11	3513191	\N	3518354	\N
3853676	GENERIC_DAY	0	0	f	2010-07-31	38991	\N	3518354	\N
3853677	GENERIC_DAY	0	1	f	2010-07-14	3513191	\N	3518354	\N
3853678	GENERIC_DAY	0	1	f	2010-08-06	3513191	\N	3518354	\N
3853679	GENERIC_DAY	0	0	f	2010-07-10	38991	\N	3518354	\N
3853680	GENERIC_DAY	0	1	f	2010-07-26	38991	\N	3518354	\N
3853681	GENERIC_DAY	0	0	f	2010-06-26	3513191	\N	3518354	\N
3853682	GENERIC_DAY	0	1	f	2010-07-21	3513191	\N	3518354	\N
3853683	GENERIC_DAY	0	0	f	2010-08-01	38991	\N	3518354	\N
3853684	GENERIC_DAY	0	1	f	2010-07-14	38991	\N	3518354	\N
3853685	GENERIC_DAY	0	1	f	2010-08-18	38991	\N	3518354	\N
3853686	GENERIC_DAY	0	0	f	2010-07-18	38991	\N	3518354	\N
3853687	GENERIC_DAY	0	0	f	2010-07-11	38991	\N	3518354	\N
3853688	GENERIC_DAY	0	1	f	2010-07-28	3513191	\N	3518354	\N
3853689	GENERIC_DAY	0	0	f	2010-08-15	38991	\N	3518354	\N
3853690	GENERIC_DAY	0	1	f	2010-08-03	3513191	\N	3518354	\N
3853691	GENERIC_DAY	0	0	f	2010-08-08	38991	\N	3518354	\N
3853692	GENERIC_DAY	0	1	f	2010-08-02	38991	\N	3518354	\N
3853693	GENERIC_DAY	0	1	f	2010-06-24	38991	\N	3518354	\N
3853694	GENERIC_DAY	0	1	f	2010-07-02	3513191	\N	3518354	\N
3853695	GENERIC_DAY	0	1	f	2010-08-09	3513191	\N	3518354	\N
3853696	GENERIC_DAY	0	1	f	2010-07-27	38991	\N	3518354	\N
3853697	GENERIC_DAY	0	0	f	2010-07-10	3513191	\N	3518354	\N
3853698	GENERIC_DAY	0	1	f	2010-07-05	38991	\N	3518354	\N
3853699	GENERIC_DAY	0	1	f	2010-07-27	3513191	\N	3518354	\N
3853700	GENERIC_DAY	0	1	f	2010-08-11	3513191	\N	3518354	\N
3853701	GENERIC_DAY	0	1	f	2010-08-20	3513191	\N	3518354	\N
3853702	GENERIC_DAY	0	0	f	2010-07-03	3513191	\N	3518354	\N
3853703	GENERIC_DAY	0	0	f	2010-08-08	3513191	\N	3518354	\N
3853704	GENERIC_DAY	0	1	f	2010-08-24	3513191	\N	3518354	\N
3853705	GENERIC_DAY	0	1	f	2010-06-28	38991	\N	3518354	\N
3853706	GENERIC_DAY	0	1	f	2010-08-19	38991	\N	3518354	\N
3853707	GENERIC_DAY	0	1	f	2010-06-28	3513191	\N	3518354	\N
3853708	GENERIC_DAY	0	1	f	2010-07-15	38991	\N	3518354	\N
3853709	GENERIC_DAY	0	1	f	2010-06-24	3513191	\N	3518354	\N
3853710	GENERIC_DAY	0	1	f	2010-07-23	38991	\N	3518354	\N
3853711	GENERIC_DAY	0	1	f	2010-08-19	3513191	\N	3518354	\N
3853712	GENERIC_DAY	0	1	f	2010-07-30	38991	\N	3518354	\N
3853713	GENERIC_DAY	0	1	f	2010-08-03	38991	\N	3518354	\N
3853714	GENERIC_DAY	0	0	f	2010-08-21	38991	\N	3518354	\N
3853715	GENERIC_DAY	0	1	f	2010-06-21	38991	\N	3518354	\N
3853716	GENERIC_DAY	0	1	f	2010-08-02	3513191	\N	3518354	\N
3853717	GENERIC_DAY	0	0	f	2010-07-25	38991	\N	3518354	\N
3853718	GENERIC_DAY	0	1	f	2010-08-16	38991	\N	3518354	\N
3853719	GENERIC_DAY	0	1	f	2010-06-29	38991	\N	3518354	\N
3853720	GENERIC_DAY	0	1	f	2010-07-07	38991	\N	3518354	\N
3853721	GENERIC_DAY	0	1	f	2010-07-16	38991	\N	3518354	\N
3853722	GENERIC_DAY	0	1	f	2010-08-13	3513191	\N	3518354	\N
3853723	GENERIC_DAY	0	1	f	2010-07-13	38991	\N	3518354	\N
3853724	GENERIC_DAY	0	1	f	2010-06-30	3513191	\N	3518354	\N
3853725	GENERIC_DAY	0	1	f	2010-08-25	3513191	\N	3518354	\N
3853726	GENERIC_DAY	0	1	f	2010-07-12	38991	\N	3518354	\N
3853727	GENERIC_DAY	0	1	f	2010-08-23	3513191	\N	3518354	\N
3853728	GENERIC_DAY	0	1	f	2010-08-10	38991	\N	3518354	\N
3853729	GENERIC_DAY	0	0	f	2010-06-27	38991	\N	3518354	\N
3853730	GENERIC_DAY	0	0	f	2010-06-26	38991	\N	3518354	\N
3853731	GENERIC_DAY	0	0	f	2010-08-14	3513191	\N	3518354	\N
3853732	GENERIC_DAY	0	1	f	2010-07-20	38991	\N	3518354	\N
3853733	GENERIC_DAY	0	0	f	2010-07-24	3513191	\N	3518354	\N
3853734	GENERIC_DAY	0	0	f	2010-08-21	3513191	\N	3518354	\N
3853735	GENERIC_DAY	0	1	f	2010-07-05	3513191	\N	3518354	\N
3853736	GENERIC_DAY	0	1	f	2010-07-16	3513191	\N	3518354	\N
3853737	GENERIC_DAY	0	1	f	2010-07-19	3513191	\N	3518354	\N
3853738	GENERIC_DAY	0	1	f	2010-07-07	3513191	\N	3518354	\N
3853739	GENERIC_DAY	0	0	f	2010-07-18	3513191	\N	3518354	\N
3853740	GENERIC_DAY	0	1	f	2010-07-08	3513191	\N	3518354	\N
3853741	GENERIC_DAY	0	1	f	2010-06-25	38991	\N	3518354	\N
3853742	GENERIC_DAY	0	0	f	2010-08-01	3513191	\N	3518354	\N
3853743	GENERIC_DAY	0	1	f	2010-07-30	3513191	\N	3518354	\N
3853744	GENERIC_DAY	0	0	f	2010-07-04	38991	\N	3518354	\N
3853745	GENERIC_DAY	0	1	f	2010-07-26	3513191	\N	3518354	\N
3853746	GENERIC_DAY	0	1	f	2010-06-29	3513191	\N	3518354	\N
3853747	GENERIC_DAY	0	1	f	2010-07-12	3513191	\N	3518354	\N
3853748	GENERIC_DAY	0	1	f	2010-06-25	3513191	\N	3518354	\N
3853749	GENERIC_DAY	0	0	f	2010-07-31	3513191	\N	3518354	\N
3853750	GENERIC_DAY	0	0	f	2010-07-17	3513191	\N	3518354	\N
3853751	GENERIC_DAY	0	1	f	2010-06-23	3513191	\N	3518354	\N
3853752	GENERIC_DAY	0	1	f	2010-07-19	38991	\N	3518354	\N
3853753	GENERIC_DAY	0	0	f	2010-07-17	38991	\N	3518354	\N
3853754	GENERIC_DAY	0	0	f	2010-07-24	38991	\N	3518354	\N
3853755	GENERIC_DAY	0	0	f	2010-07-25	3513191	\N	3518354	\N
3853756	GENERIC_DAY	0	1	f	2010-07-22	38991	\N	3518354	\N
3853757	GENERIC_DAY	0	0	f	2010-06-27	3513191	\N	3518354	\N
3853758	GENERIC_DAY	0	1	f	2010-08-04	3513191	\N	3518354	\N
3853759	GENERIC_DAY	0	1	f	2010-07-28	38991	\N	3518354	\N
3853760	GENERIC_DAY	0	1	f	2010-07-13	3513191	\N	3518354	\N
3853761	GENERIC_DAY	0	1	f	2010-08-23	38991	\N	3518354	\N
3853762	GENERIC_DAY	0	1	f	2010-08-10	3513191	\N	3518354	\N
3853763	GENERIC_DAY	0	0	f	2010-08-22	3513191	\N	3518354	\N
3853764	GENERIC_DAY	0	0	f	2010-08-15	3513191	\N	3518354	\N
3853765	GENERIC_DAY	0	1	f	2010-08-04	38991	\N	3518354	\N
3853766	GENERIC_DAY	0	1	f	2010-07-21	38991	\N	3518354	\N
3853767	GENERIC_DAY	0	1	f	2010-06-30	38991	\N	3518354	\N
3853768	GENERIC_DAY	0	1	f	2010-08-12	38991	\N	3518354	\N
3853769	GENERIC_DAY	0	1	f	2010-08-13	38991	\N	3518354	\N
3853770	GENERIC_DAY	0	0	f	2010-06-19	3513191	\N	3518354	\N
3853771	GENERIC_DAY	0	1	f	2010-07-01	3513191	\N	3518354	\N
3853772	GENERIC_DAY	0	1	f	2010-07-09	38991	\N	3518354	\N
3853773	GENERIC_DAY	0	1	f	2010-06-22	38991	\N	3518354	\N
3853774	GENERIC_DAY	0	1	f	2010-08-05	38991	\N	3518354	\N
3853775	GENERIC_DAY	0	1	f	2010-07-15	3513191	\N	3518354	\N
3853776	GENERIC_DAY	0	1	f	2010-08-06	38991	\N	3518354	\N
3853777	GENERIC_DAY	0	1	f	2010-07-22	3513191	\N	3518354	\N
3853778	GENERIC_DAY	0	1	f	2010-08-25	38991	\N	3518354	\N
3853779	GENERIC_DAY	0	1	f	2010-06-21	3513191	\N	3518354	\N
3853780	GENERIC_DAY	0	1	f	2010-07-06	38991	\N	3518354	\N
3853781	GENERIC_DAY	0	1	f	2010-08-24	38991	\N	3518354	\N
3853782	GENERIC_DAY	0	0	f	2010-08-28	3513191	\N	3518355	\N
3853783	GENERIC_DAY	0	2	f	2010-08-26	3513191	\N	3518355	\N
3853784	GENERIC_DAY	0	2	f	2010-08-25	38991	\N	3518355	\N
3853785	GENERIC_DAY	0	2	f	2010-08-06	3513191	\N	3518355	\N
3853786	GENERIC_DAY	0	2	f	2010-08-16	3513191	\N	3518355	\N
3853787	GENERIC_DAY	0	2	f	2010-08-31	38991	\N	3518355	\N
3853788	GENERIC_DAY	0	2	f	2010-09-08	3513191	\N	3518355	\N
3853789	GENERIC_DAY	0	2	f	2010-08-24	38991	\N	3518355	\N
3853790	GENERIC_DAY	0	0	f	2010-09-12	38991	\N	3518355	\N
3853791	GENERIC_DAY	0	2	f	2010-09-13	38991	\N	3518355	\N
3853792	GENERIC_DAY	0	2	f	2010-08-26	38991	\N	3518355	\N
3853793	GENERIC_DAY	0	0	f	2010-09-11	38991	\N	3518355	\N
3853794	GENERIC_DAY	0	0	f	2010-08-07	3513191	\N	3518355	\N
3853795	GENERIC_DAY	0	2	f	2010-08-10	3513191	\N	3518355	\N
3853796	GENERIC_DAY	0	2	f	2010-08-16	38991	\N	3518355	\N
3853797	GENERIC_DAY	0	0	f	2010-08-14	3513191	\N	3518355	\N
3853798	GENERIC_DAY	0	0	f	2010-08-29	38991	\N	3518355	\N
3853799	GENERIC_DAY	0	2	f	2010-08-12	38991	\N	3518355	\N
3853800	GENERIC_DAY	0	2	f	2010-08-13	3513191	\N	3518355	\N
3853801	GENERIC_DAY	0	2	f	2010-09-07	38991	\N	3518355	\N
3853802	GENERIC_DAY	0	0	f	2010-08-15	38991	\N	3518355	\N
3853803	GENERIC_DAY	0	2	f	2010-08-10	38991	\N	3518355	\N
3853804	GENERIC_DAY	0	0	f	2010-08-14	38991	\N	3518355	\N
3853805	GENERIC_DAY	0	2	f	2010-08-09	38991	\N	3518355	\N
3853806	GENERIC_DAY	0	2	f	2010-08-23	38991	\N	3518355	\N
3853807	GENERIC_DAY	0	2	f	2010-09-01	38991	\N	3518355	\N
3853808	GENERIC_DAY	0	0	f	2010-08-08	3513191	\N	3518355	\N
3853809	GENERIC_DAY	0	2	f	2010-09-08	38991	\N	3518355	\N
3853810	GENERIC_DAY	0	0	f	2010-09-05	3513191	\N	3518355	\N
3853811	GENERIC_DAY	0	2	f	2010-09-01	3513191	\N	3518355	\N
3853812	GENERIC_DAY	0	2	f	2010-09-09	38991	\N	3518355	\N
3853813	GENERIC_DAY	0	2	f	2010-08-09	3513191	\N	3518355	\N
3853814	GENERIC_DAY	0	0	f	2010-09-04	3513191	\N	3518355	\N
3853815	GENERIC_DAY	0	2	f	2010-08-12	3513191	\N	3518355	\N
3853816	GENERIC_DAY	0	0	f	2010-08-21	3513191	\N	3518355	\N
3853817	GENERIC_DAY	0	2	f	2010-08-20	38991	\N	3518355	\N
3853818	GENERIC_DAY	0	2	f	2010-09-10	3513191	\N	3518355	\N
3853819	GENERIC_DAY	0	2	f	2010-08-11	38991	\N	3518355	\N
3853820	GENERIC_DAY	0	2	f	2010-09-10	38991	\N	3518355	\N
3853821	GENERIC_DAY	0	2	f	2010-09-03	38991	\N	3518355	\N
3853822	GENERIC_DAY	0	2	f	2010-08-13	38991	\N	3518355	\N
3853823	GENERIC_DAY	0	0	f	2010-09-04	38991	\N	3518355	\N
3853824	GENERIC_DAY	0	0	f	2010-08-21	38991	\N	3518355	\N
3853825	GENERIC_DAY	0	2	f	2010-09-07	3513191	\N	3518355	\N
3853826	GENERIC_DAY	0	0	f	2010-08-28	38991	\N	3518355	\N
3853827	GENERIC_DAY	0	0	f	2010-08-29	3513191	\N	3518355	\N
3853828	GENERIC_DAY	0	0	f	2010-08-07	38991	\N	3518355	\N
3853829	GENERIC_DAY	0	0	f	2010-08-15	3513191	\N	3518355	\N
3853830	GENERIC_DAY	0	2	f	2010-09-03	3513191	\N	3518355	\N
3853831	GENERIC_DAY	0	2	f	2010-08-25	3513191	\N	3518355	\N
3853832	GENERIC_DAY	0	2	f	2010-08-19	38991	\N	3518355	\N
3853833	GENERIC_DAY	0	2	f	2010-08-05	38991	\N	3518355	\N
3853834	GENERIC_DAY	0	0	f	2010-08-22	3513191	\N	3518355	\N
3853835	GENERIC_DAY	0	2	f	2010-09-09	3513191	\N	3518355	\N
3853836	GENERIC_DAY	0	2	f	2010-09-06	38991	\N	3518355	\N
3853837	GENERIC_DAY	0	2	f	2010-08-23	3513191	\N	3518355	\N
3853838	GENERIC_DAY	0	2	f	2010-09-06	3513191	\N	3518355	\N
3853839	GENERIC_DAY	0	2	f	2010-08-06	38991	\N	3518355	\N
3853840	GENERIC_DAY	0	0	f	2010-09-05	38991	\N	3518355	\N
3853841	GENERIC_DAY	0	2	f	2010-08-05	3513191	\N	3518355	\N
3853842	GENERIC_DAY	0	2	f	2010-08-18	38991	\N	3518355	\N
3853843	GENERIC_DAY	0	2	f	2010-08-17	38991	\N	3518355	\N
3853844	GENERIC_DAY	0	2	f	2010-09-02	3513191	\N	3518355	\N
3853845	GENERIC_DAY	0	0	f	2010-08-22	38991	\N	3518355	\N
3853846	GENERIC_DAY	0	2	f	2010-08-17	3513191	\N	3518355	\N
3853847	GENERIC_DAY	0	2	f	2010-09-14	3513191	\N	3518355	\N
3853848	GENERIC_DAY	0	2	f	2010-09-13	3513191	\N	3518355	\N
3853849	GENERIC_DAY	0	2	f	2010-09-02	38991	\N	3518355	\N
3853850	GENERIC_DAY	0	2	f	2010-08-30	38991	\N	3518355	\N
3853851	GENERIC_DAY	0	2	f	2010-08-27	3513191	\N	3518355	\N
3853852	GENERIC_DAY	0	2	f	2010-08-27	38991	\N	3518355	\N
3853853	GENERIC_DAY	0	2	f	2010-08-19	3513191	\N	3518355	\N
3853854	GENERIC_DAY	0	2	f	2010-08-18	3513191	\N	3518355	\N
3853855	GENERIC_DAY	0	0	f	2010-09-11	3513191	\N	3518355	\N
3853856	GENERIC_DAY	0	2	f	2010-08-20	3513191	\N	3518355	\N
3853857	GENERIC_DAY	0	0	f	2010-08-08	38991	\N	3518355	\N
3853858	GENERIC_DAY	0	2	f	2010-08-24	3513191	\N	3518355	\N
3853859	GENERIC_DAY	0	2	f	2010-08-11	3513191	\N	3518355	\N
3853860	GENERIC_DAY	0	0	f	2010-09-12	3513191	\N	3518355	\N
3853861	GENERIC_DAY	0	2	f	2010-09-14	38991	\N	3518355	\N
3853862	GENERIC_DAY	0	2	f	2010-08-31	3513191	\N	3518355	\N
3853863	GENERIC_DAY	0	2	f	2010-08-30	3513191	\N	3518355	\N
3853864	GENERIC_DAY	0	0	f	2010-09-18	3513191	\N	3518356	\N
3853865	GENERIC_DAY	0	1	f	2010-09-13	3513191	\N	3518356	\N
3853866	GENERIC_DAY	0	1	f	2010-09-10	3513191	\N	3518356	\N
3853867	GENERIC_DAY	0	1	f	2010-09-10	38991	\N	3518356	\N
3853868	GENERIC_DAY	0	1	f	2010-07-26	38991	\N	3518356	\N
3853869	GENERIC_DAY	0	1	f	2010-08-18	38991	\N	3518356	\N
3853870	GENERIC_DAY	0	0	f	2010-09-12	3513191	\N	3518356	\N
3853871	GENERIC_DAY	0	1	f	2010-09-16	38991	\N	3518356	\N
3853872	GENERIC_DAY	0	0	f	2010-09-11	38991	\N	3518356	\N
3853873	GENERIC_DAY	0	1	f	2010-08-26	38991	\N	3518356	\N
3853874	GENERIC_DAY	0	1	f	2010-09-20	3513191	\N	3518356	\N
3853875	GENERIC_DAY	0	1	f	2010-08-16	3513191	\N	3518356	\N
3853876	GENERIC_DAY	0	1	f	2010-08-17	3513191	\N	3518356	\N
3853877	GENERIC_DAY	0	0	f	2010-09-11	3513191	\N	3518356	\N
3853878	GENERIC_DAY	0	1	f	2010-08-24	3513191	\N	3518356	\N
3853879	GENERIC_DAY	0	0	f	2010-09-04	3513191	\N	3518356	\N
3853880	GENERIC_DAY	0	1	f	2010-08-03	38991	\N	3518356	\N
3853881	GENERIC_DAY	0	1	f	2010-08-03	3513191	\N	3518356	\N
3853882	GENERIC_DAY	0	1	f	2010-09-14	3513191	\N	3518356	\N
3853883	GENERIC_DAY	0	0	f	2010-08-29	38991	\N	3518356	\N
3853884	GENERIC_DAY	0	0	f	2010-08-07	38991	\N	3518356	\N
3853885	GENERIC_DAY	0	1	f	2010-08-20	3513191	\N	3518356	\N
3853886	GENERIC_DAY	0	1	f	2010-07-27	3513191	\N	3518356	\N
3853887	GENERIC_DAY	0	1	f	2010-08-19	3513191	\N	3518356	\N
3853888	GENERIC_DAY	0	0	f	2010-08-01	38991	\N	3518356	\N
3853889	GENERIC_DAY	0	1	f	2010-09-17	3513191	\N	3518356	\N
3853890	GENERIC_DAY	0	1	f	2010-08-06	38991	\N	3518356	\N
3853891	GENERIC_DAY	0	1	f	2010-09-20	38991	\N	3518356	\N
3853892	GENERIC_DAY	0	0	f	2010-08-21	3513191	\N	3518356	\N
3853893	GENERIC_DAY	0	1	f	2010-09-15	38991	\N	3518356	\N
3853894	GENERIC_DAY	0	0	f	2010-08-14	3513191	\N	3518356	\N
3853895	GENERIC_DAY	0	0	f	2010-09-05	3513191	\N	3518356	\N
3853896	GENERIC_DAY	0	0	f	2010-08-22	38991	\N	3518356	\N
3853897	GENERIC_DAY	0	1	f	2010-09-03	38991	\N	3518356	\N
3853898	GENERIC_DAY	0	1	f	2010-08-13	3513191	\N	3518356	\N
3853899	GENERIC_DAY	0	1	f	2010-09-02	38991	\N	3518356	\N
3853900	GENERIC_DAY	0	0	f	2010-08-14	38991	\N	3518356	\N
3853901	GENERIC_DAY	0	1	f	2010-09-09	3513191	\N	3518356	\N
3853902	GENERIC_DAY	0	0	f	2010-09-19	38991	\N	3518356	\N
3853903	GENERIC_DAY	0	1	f	2010-09-01	38991	\N	3518356	\N
3853904	GENERIC_DAY	0	1	f	2010-09-07	3513191	\N	3518356	\N
3853905	GENERIC_DAY	0	1	f	2010-09-16	3513191	\N	3518356	\N
3853906	GENERIC_DAY	0	0	f	2010-08-08	3513191	\N	3518356	\N
3853907	GENERIC_DAY	0	1	f	2010-08-04	38991	\N	3518356	\N
3853908	GENERIC_DAY	0	0	f	2010-07-31	3513191	\N	3518356	\N
3853909	GENERIC_DAY	0	0	f	2010-08-28	3513191	\N	3518356	\N
3853910	GENERIC_DAY	0	1	f	2010-08-31	38991	\N	3518356	\N
3853911	GENERIC_DAY	0	1	f	2010-08-02	3513191	\N	3518356	\N
3853912	GENERIC_DAY	0	0	f	2010-09-05	38991	\N	3518356	\N
3853913	GENERIC_DAY	0	1	f	2010-07-28	3513191	\N	3518356	\N
3853914	GENERIC_DAY	0	0	f	2010-07-25	38991	\N	3518356	\N
3853915	GENERIC_DAY	0	1	f	2010-09-21	3513191	\N	3518356	\N
3853916	GENERIC_DAY	0	1	f	2010-08-27	3513191	\N	3518356	\N
3853917	GENERIC_DAY	0	1	f	2010-08-04	3513191	\N	3518356	\N
3853918	GENERIC_DAY	0	1	f	2010-08-19	38991	\N	3518356	\N
3853919	GENERIC_DAY	0	1	f	2010-09-01	3513191	\N	3518356	\N
3853920	GENERIC_DAY	0	0	f	2010-07-24	38991	\N	3518356	\N
3853921	GENERIC_DAY	0	1	f	2010-09-02	3513191	\N	3518356	\N
3853922	GENERIC_DAY	0	0	f	2010-07-31	38991	\N	3518356	\N
3853923	GENERIC_DAY	0	1	f	2010-09-17	38991	\N	3518356	\N
3853924	GENERIC_DAY	0	1	f	2010-08-30	38991	\N	3518356	\N
3853925	GENERIC_DAY	0	0	f	2010-07-24	3513191	\N	3518356	\N
3853926	GENERIC_DAY	0	1	f	2010-09-22	3513191	\N	3518356	\N
3853927	GENERIC_DAY	0	0	f	2010-08-28	38991	\N	3518356	\N
3853928	GENERIC_DAY	0	1	f	2010-09-06	3513191	\N	3518356	\N
3853929	GENERIC_DAY	0	1	f	2010-08-11	3513191	\N	3518356	\N
3853930	GENERIC_DAY	0	1	f	2010-08-11	38991	\N	3518356	\N
3853931	GENERIC_DAY	0	1	f	2010-08-26	3513191	\N	3518356	\N
3853932	GENERIC_DAY	0	1	f	2010-07-26	3513191	\N	3518356	\N
3853933	GENERIC_DAY	0	1	f	2010-08-09	3513191	\N	3518356	\N
3853934	GENERIC_DAY	0	0	f	2010-08-22	3513191	\N	3518356	\N
3853935	GENERIC_DAY	0	1	f	2010-08-13	38991	\N	3518356	\N
3853936	GENERIC_DAY	0	0	f	2010-08-08	38991	\N	3518356	\N
3853937	GENERIC_DAY	0	1	f	2010-08-20	38991	\N	3518356	\N
3853938	GENERIC_DAY	0	1	f	2010-08-18	3513191	\N	3518356	\N
3853939	GENERIC_DAY	0	1	f	2010-08-25	3513191	\N	3518356	\N
3853940	GENERIC_DAY	0	1	f	2010-07-28	38991	\N	3518356	\N
3853941	GENERIC_DAY	0	1	f	2010-08-12	3513191	\N	3518356	\N
3853942	GENERIC_DAY	0	1	f	2010-08-25	38991	\N	3518356	\N
3853943	GENERIC_DAY	0	1	f	2010-09-03	3513191	\N	3518356	\N
3853944	GENERIC_DAY	0	1	f	2010-08-10	38991	\N	3518356	\N
3853945	GENERIC_DAY	0	1	f	2010-09-15	3513191	\N	3518356	\N
3853946	GENERIC_DAY	0	1	f	2010-08-23	3513191	\N	3518356	\N
3853947	GENERIC_DAY	0	1	f	2010-08-10	3513191	\N	3518356	\N
3853948	GENERIC_DAY	0	1	f	2010-07-30	38991	\N	3518356	\N
3853949	GENERIC_DAY	0	1	f	2010-08-12	38991	\N	3518356	\N
3853950	GENERIC_DAY	0	1	f	2010-07-23	3513191	\N	3518356	\N
3853951	GENERIC_DAY	0	1	f	2010-09-22	38991	\N	3518356	\N
3853952	GENERIC_DAY	0	1	f	2010-09-21	38991	\N	3518356	\N
3853953	GENERIC_DAY	0	1	f	2010-08-17	38991	\N	3518356	\N
3853954	GENERIC_DAY	0	1	f	2010-07-29	38991	\N	3518356	\N
3853955	GENERIC_DAY	0	1	f	2010-08-27	38991	\N	3518356	\N
3853956	GENERIC_DAY	0	1	f	2010-09-07	38991	\N	3518356	\N
3853957	GENERIC_DAY	0	0	f	2010-08-21	38991	\N	3518356	\N
3853958	GENERIC_DAY	0	1	f	2010-08-05	38991	\N	3518356	\N
3853959	GENERIC_DAY	0	0	f	2010-07-25	3513191	\N	3518356	\N
3853960	GENERIC_DAY	0	1	f	2010-09-08	38991	\N	3518356	\N
3853961	GENERIC_DAY	0	1	f	2010-08-16	38991	\N	3518356	\N
3853962	GENERIC_DAY	0	0	f	2010-09-19	3513191	\N	3518356	\N
3853963	GENERIC_DAY	0	0	f	2010-09-04	38991	\N	3518356	\N
3853964	GENERIC_DAY	0	1	f	2010-08-06	3513191	\N	3518356	\N
3853965	GENERIC_DAY	0	0	f	2010-08-15	3513191	\N	3518356	\N
3853966	GENERIC_DAY	0	1	f	2010-08-02	38991	\N	3518356	\N
3853967	GENERIC_DAY	0	1	f	2010-07-27	38991	\N	3518356	\N
3853968	GENERIC_DAY	0	0	f	2010-09-12	38991	\N	3518356	\N
3853969	GENERIC_DAY	0	1	f	2010-09-06	38991	\N	3518356	\N
3853970	GENERIC_DAY	0	1	f	2010-08-30	3513191	\N	3518356	\N
3853971	GENERIC_DAY	0	0	f	2010-08-15	38991	\N	3518356	\N
3853972	GENERIC_DAY	0	1	f	2010-09-08	3513191	\N	3518356	\N
3853973	GENERIC_DAY	0	1	f	2010-07-23	38991	\N	3518356	\N
3853974	GENERIC_DAY	0	1	f	2010-08-24	38991	\N	3518356	\N
3853975	GENERIC_DAY	0	1	f	2010-09-14	38991	\N	3518356	\N
3853976	GENERIC_DAY	0	1	f	2010-09-09	38991	\N	3518356	\N
3853977	GENERIC_DAY	0	1	f	2010-08-09	38991	\N	3518356	\N
3853978	GENERIC_DAY	0	1	f	2010-08-05	3513191	\N	3518356	\N
3853979	GENERIC_DAY	0	1	f	2010-07-29	3513191	\N	3518356	\N
3853980	GENERIC_DAY	0	1	f	2010-07-30	3513191	\N	3518356	\N
3853981	GENERIC_DAY	0	1	f	2010-08-23	38991	\N	3518356	\N
3853982	GENERIC_DAY	0	1	f	2010-09-13	38991	\N	3518356	\N
3853983	GENERIC_DAY	0	1	f	2010-08-31	3513191	\N	3518356	\N
3853984	GENERIC_DAY	0	0	f	2010-08-07	3513191	\N	3518356	\N
3853985	GENERIC_DAY	0	0	f	2010-08-29	3513191	\N	3518356	\N
3853986	GENERIC_DAY	0	0	f	2010-09-18	38991	\N	3518356	\N
3853987	GENERIC_DAY	0	0	f	2010-08-01	3513191	\N	3518356	\N
3853988	GENERIC_DAY	0	8	f	2010-08-30	3513195	\N	3819131	\N
3853989	GENERIC_DAY	0	8	f	2010-08-10	3513195	\N	3819131	\N
3853990	GENERIC_DAY	0	8	f	2010-09-06	3513195	\N	3819131	\N
3853991	GENERIC_DAY	0	8	f	2010-08-12	3513195	\N	3819131	\N
3853992	GENERIC_DAY	0	8	f	2010-08-11	3513195	\N	3819131	\N
3853993	GENERIC_DAY	0	8	f	2010-08-19	3513195	\N	3819131	\N
3853994	GENERIC_DAY	0	8	f	2010-08-20	3513195	\N	3819131	\N
3853995	GENERIC_DAY	0	8	f	2010-09-07	3513195	\N	3819131	\N
3853996	GENERIC_DAY	0	0	f	2010-08-22	3513195	\N	3819131	\N
3853997	GENERIC_DAY	0	0	f	2010-09-04	3513195	\N	3819131	\N
3853998	GENERIC_DAY	0	8	f	2010-08-09	3513195	\N	3819131	\N
3853999	GENERIC_DAY	0	0	f	2010-08-07	3513195	\N	3819131	\N
3854000	GENERIC_DAY	0	8	f	2010-08-24	3513195	\N	3819131	\N
3854001	GENERIC_DAY	0	8	f	2010-08-16	3513195	\N	3819131	\N
3854002	GENERIC_DAY	0	8	f	2010-09-03	3513195	\N	3819131	\N
3854003	GENERIC_DAY	0	8	f	2010-09-01	3513195	\N	3819131	\N
3854004	GENERIC_DAY	0	0	f	2010-08-14	3513195	\N	3819131	\N
3854005	GENERIC_DAY	0	8	f	2010-08-27	3513195	\N	3819131	\N
3854006	GENERIC_DAY	0	8	f	2010-08-17	3513195	\N	3819131	\N
3854007	GENERIC_DAY	0	0	f	2010-08-21	3513195	\N	3819131	\N
3854008	GENERIC_DAY	0	0	f	2010-08-29	3513195	\N	3819131	\N
3854009	GENERIC_DAY	0	0	f	2010-08-08	3513195	\N	3819131	\N
3854010	GENERIC_DAY	0	0	f	2010-09-05	3513195	\N	3819131	\N
3854011	GENERIC_DAY	0	8	f	2010-08-26	3513195	\N	3819131	\N
3854012	GENERIC_DAY	0	8	f	2010-09-02	3513195	\N	3819131	\N
3854013	GENERIC_DAY	0	0	f	2010-08-28	3513195	\N	3819131	\N
3854014	GENERIC_DAY	0	8	f	2010-08-23	3513195	\N	3819131	\N
3854015	GENERIC_DAY	0	8	f	2010-09-09	3513195	\N	3819131	\N
3854016	GENERIC_DAY	0	8	f	2010-08-31	3513195	\N	3819131	\N
3854017	GENERIC_DAY	0	0	f	2010-08-15	3513195	\N	3819131	\N
3854018	GENERIC_DAY	0	8	f	2010-08-18	3513195	\N	3819131	\N
3854019	GENERIC_DAY	0	8	f	2010-08-13	3513195	\N	3819131	\N
3854020	GENERIC_DAY	0	8	f	2010-09-08	3513195	\N	3819131	\N
3854021	GENERIC_DAY	0	8	f	2010-08-25	3513195	\N	3819131	\N
3854022	GENERIC_DAY	0	8	f	2010-08-06	3513195	\N	3819131	\N
3854023	GENERIC_DAY	0	8	f	2010-08-10	3513195	\N	3819132	\N
3854024	GENERIC_DAY	0	8	f	2010-08-18	3513195	\N	3819132	\N
3854025	GENERIC_DAY	0	8	f	2010-09-09	3513195	\N	3819132	\N
3854026	GENERIC_DAY	0	8	f	2010-08-25	3513195	\N	3819132	\N
3854027	GENERIC_DAY	0	8	f	2010-08-12	3513195	\N	3819132	\N
3854028	GENERIC_DAY	0	8	f	2010-08-30	3513195	\N	3819132	\N
3854029	GENERIC_DAY	0	8	f	2010-08-16	3513195	\N	3819132	\N
3854030	GENERIC_DAY	0	0	f	2010-08-07	3513195	\N	3819132	\N
3854031	GENERIC_DAY	0	8	f	2010-08-26	3513195	\N	3819132	\N
3854032	GENERIC_DAY	0	0	f	2010-08-22	3513195	\N	3819132	\N
3854033	GENERIC_DAY	0	8	f	2010-08-27	3513195	\N	3819132	\N
3854034	GENERIC_DAY	0	0	f	2010-08-14	3513195	\N	3819132	\N
3854035	GENERIC_DAY	0	8	f	2010-08-09	3513195	\N	3819132	\N
3854036	GENERIC_DAY	0	8	f	2010-09-03	3513195	\N	3819132	\N
3854037	GENERIC_DAY	0	0	f	2010-09-05	3513195	\N	3819132	\N
3854038	GENERIC_DAY	0	8	f	2010-09-01	3513195	\N	3819132	\N
3854039	GENERIC_DAY	0	0	f	2010-08-28	3513195	\N	3819132	\N
3854040	GENERIC_DAY	0	8	f	2010-08-23	3513195	\N	3819132	\N
3854041	GENERIC_DAY	0	8	f	2010-09-08	3513195	\N	3819132	\N
3854042	GENERIC_DAY	0	8	f	2010-08-06	3513195	\N	3819132	\N
3854043	GENERIC_DAY	0	0	f	2010-08-15	3513195	\N	3819132	\N
3854044	GENERIC_DAY	0	0	f	2010-09-04	3513195	\N	3819132	\N
3854045	GENERIC_DAY	0	0	f	2010-08-29	3513195	\N	3819132	\N
3854046	GENERIC_DAY	0	0	f	2010-08-08	3513195	\N	3819132	\N
3854047	GENERIC_DAY	0	8	f	2010-08-24	3513195	\N	3819132	\N
3854048	GENERIC_DAY	0	8	f	2010-08-11	3513195	\N	3819132	\N
3854049	GENERIC_DAY	0	8	f	2010-08-17	3513195	\N	3819132	\N
3854050	GENERIC_DAY	0	8	f	2010-08-13	3513195	\N	3819132	\N
3854051	GENERIC_DAY	0	8	f	2010-09-07	3513195	\N	3819132	\N
3854052	GENERIC_DAY	0	8	f	2010-08-20	3513195	\N	3819132	\N
3854053	GENERIC_DAY	0	0	f	2010-08-21	3513195	\N	3819132	\N
3854054	GENERIC_DAY	0	8	f	2010-08-19	3513195	\N	3819132	\N
3854055	GENERIC_DAY	0	8	f	2010-08-31	3513195	\N	3819132	\N
3854056	GENERIC_DAY	0	8	f	2010-09-06	3513195	\N	3819132	\N
3854057	GENERIC_DAY	0	8	f	2010-09-02	3513195	\N	3819132	\N
3854058	GENERIC_DAY	0	8	f	2010-09-17	3513195	\N	3819133	\N
3854059	GENERIC_DAY	0	8	f	2010-09-14	3513195	\N	3819133	\N
3854060	GENERIC_DAY	0	8	f	2010-09-20	3513195	\N	3819133	\N
3854061	GENERIC_DAY	0	0	f	2010-09-18	3513195	\N	3819133	\N
3854062	GENERIC_DAY	0	0	f	2010-09-19	3513195	\N	3819133	\N
3854063	GENERIC_DAY	0	8	f	2010-09-22	3513195	\N	3819133	\N
3854064	GENERIC_DAY	0	0	f	2010-09-26	3513195	\N	3819133	\N
3854065	GENERIC_DAY	0	8	f	2010-09-27	3513195	\N	3819133	\N
3854066	GENERIC_DAY	0	8	f	2010-09-23	3513195	\N	3819133	\N
3854067	GENERIC_DAY	0	8	f	2010-09-24	3513195	\N	3819133	\N
3854068	GENERIC_DAY	0	4	f	2010-09-28	3513195	\N	3819133	\N
3854069	GENERIC_DAY	0	0	f	2010-09-25	3513195	\N	3819133	\N
3854070	GENERIC_DAY	0	0	f	2010-09-12	3513195	\N	3819133	\N
3854071	GENERIC_DAY	0	8	f	2010-09-13	3513195	\N	3819133	\N
3854072	GENERIC_DAY	0	8	f	2010-09-21	3513195	\N	3819133	\N
3854073	GENERIC_DAY	0	8	f	2010-09-16	3513195	\N	3819133	\N
3854074	GENERIC_DAY	0	0	f	2010-09-11	3513195	\N	3819133	\N
3854075	GENERIC_DAY	0	8	f	2010-09-10	3513195	\N	3819133	\N
3854076	GENERIC_DAY	0	8	f	2010-09-15	3513195	\N	3819133	\N
3854077	GENERIC_DAY	0	16	f	2010-09-06	3513195	\N	3766823	\N
3854078	GENERIC_DAY	0	16	f	2010-09-01	3513195	\N	3766823	\N
3854079	GENERIC_DAY	0	0	f	2010-08-29	3513195	\N	3766823	\N
3854080	GENERIC_DAY	0	16	f	2010-08-20	3513195	\N	3766823	\N
3854081	GENERIC_DAY	0	16	f	2010-08-18	3513195	\N	3766823	\N
3854082	GENERIC_DAY	0	16	f	2010-08-31	3513195	\N	3766823	\N
3854083	GENERIC_DAY	0	16	f	2010-08-06	3513195	\N	3766823	\N
3854084	GENERIC_DAY	0	16	f	2010-09-07	3513195	\N	3766823	\N
3854085	GENERIC_DAY	0	0	f	2010-08-08	3513195	\N	3766823	\N
3854086	GENERIC_DAY	0	0	f	2010-08-21	3513195	\N	3766823	\N
3854087	GENERIC_DAY	0	16	f	2010-08-25	3513195	\N	3766823	\N
3854088	GENERIC_DAY	0	16	f	2010-08-10	3513195	\N	3766823	\N
3854089	GENERIC_DAY	0	16	f	2010-08-16	3513195	\N	3766823	\N
3854090	GENERIC_DAY	0	16	f	2010-08-26	3513195	\N	3766823	\N
3854091	GENERIC_DAY	0	16	f	2010-08-27	3513195	\N	3766823	\N
3854092	GENERIC_DAY	0	0	f	2010-09-05	3513195	\N	3766823	\N
3854093	GENERIC_DAY	0	16	f	2010-09-03	3513195	\N	3766823	\N
3854094	GENERIC_DAY	0	0	f	2010-08-15	3513195	\N	3766823	\N
3854095	GENERIC_DAY	0	0	f	2010-08-14	3513195	\N	3766823	\N
3854096	GENERIC_DAY	0	16	f	2010-08-24	3513195	\N	3766823	\N
3854097	GENERIC_DAY	0	16	f	2010-09-02	3513195	\N	3766823	\N
3854098	GENERIC_DAY	0	16	f	2010-08-09	3513195	\N	3766823	\N
3854099	GENERIC_DAY	0	16	f	2010-08-12	3513195	\N	3766823	\N
3854100	GENERIC_DAY	0	16	f	2010-08-17	3513195	\N	3766823	\N
3854101	GENERIC_DAY	0	0	f	2010-08-07	3513195	\N	3766823	\N
3854102	GENERIC_DAY	0	16	f	2010-08-19	3513195	\N	3766823	\N
3854103	GENERIC_DAY	0	0	f	2010-08-28	3513195	\N	3766823	\N
3854104	GENERIC_DAY	0	16	f	2010-08-13	3513195	\N	3766823	\N
3854105	GENERIC_DAY	0	16	f	2010-09-08	3513195	\N	3766823	\N
3854106	GENERIC_DAY	0	16	f	2010-08-23	3513195	\N	3766823	\N
3854107	GENERIC_DAY	0	16	f	2010-08-30	3513195	\N	3766823	\N
3854108	GENERIC_DAY	0	0	f	2010-08-22	3513195	\N	3766823	\N
3854109	GENERIC_DAY	0	0	f	2010-09-04	3513195	\N	3766823	\N
3854110	GENERIC_DAY	0	16	f	2010-08-11	3513195	\N	3766823	\N
3854111	GENERIC_DAY	0	16	f	2010-09-09	3513195	\N	3766823	\N
3854112	GENERIC_DAY	0	4	f	2010-01-19	38991	\N	3518380	\N
3854113	GENERIC_DAY	0	4	f	2010-01-20	3513191	\N	3518380	\N
3854114	GENERIC_DAY	0	4	f	2010-01-18	38991	\N	3518380	\N
3854115	GENERIC_DAY	0	4	f	2010-01-15	3513191	\N	3518380	\N
3854116	GENERIC_DAY	0	4	f	2010-01-15	38991	\N	3518380	\N
3854117	GENERIC_DAY	0	4	f	2010-01-14	3513191	\N	3518380	\N
3854118	GENERIC_DAY	0	0	f	2010-01-17	38991	\N	3518380	\N
3854119	GENERIC_DAY	0	0	f	2010-01-16	38991	\N	3518380	\N
3854120	GENERIC_DAY	0	4	f	2010-01-14	38991	\N	3518380	\N
3854121	GENERIC_DAY	0	4	f	2010-01-21	38991	\N	3518380	\N
3854122	GENERIC_DAY	0	4	f	2010-01-20	38991	\N	3518380	\N
3854123	GENERIC_DAY	0	0	f	2010-01-17	3513191	\N	3518380	\N
3854124	GENERIC_DAY	0	4	f	2010-01-19	3513191	\N	3518380	\N
3854125	GENERIC_DAY	0	4	f	2010-01-21	3513191	\N	3518380	\N
3854126	GENERIC_DAY	0	4	f	2010-01-13	3513191	\N	3518380	\N
3854127	GENERIC_DAY	0	4	f	2010-01-13	38991	\N	3518380	\N
3854128	GENERIC_DAY	0	4	f	2010-01-18	3513191	\N	3518380	\N
3854129	GENERIC_DAY	0	0	f	2010-01-16	3513191	\N	3518380	\N
3854130	GENERIC_DAY	0	4	f	2010-01-29	38991	\N	3518381	\N
3854131	GENERIC_DAY	0	0	f	2010-01-24	38991	\N	3518381	\N
3854132	GENERIC_DAY	0	4	f	2010-01-29	3513191	\N	3518381	\N
3854133	GENERIC_DAY	0	4	f	2010-01-26	38991	\N	3518381	\N
3854134	GENERIC_DAY	0	4	f	2010-01-25	38991	\N	3518381	\N
3854135	GENERIC_DAY	0	4	f	2010-01-27	38991	\N	3518381	\N
3854136	GENERIC_DAY	0	4	f	2010-01-28	3513191	\N	3518381	\N
3854137	GENERIC_DAY	0	4	f	2010-01-28	38991	\N	3518381	\N
3854138	GENERIC_DAY	0	4	f	2010-01-22	3513191	\N	3518381	\N
3854139	GENERIC_DAY	0	0	f	2010-01-24	3513191	\N	3518381	\N
3854140	GENERIC_DAY	0	0	f	2010-01-23	38991	\N	3518381	\N
3854141	GENERIC_DAY	0	0	f	2010-01-23	3513191	\N	3518381	\N
3854142	GENERIC_DAY	0	4	f	2010-01-22	38991	\N	3518381	\N
3854143	GENERIC_DAY	0	4	f	2010-01-27	3513191	\N	3518381	\N
3854144	GENERIC_DAY	0	4	f	2010-01-25	3513191	\N	3518381	\N
3854145	GENERIC_DAY	0	4	f	2010-01-26	3513191	\N	3518381	\N
3854146	GENERIC_DAY	0	4	f	2010-02-05	3513191	\N	3518382	\N
3854147	GENERIC_DAY	0	0	f	2010-02-06	38991	\N	3518382	\N
3854148	GENERIC_DAY	0	4	f	2010-02-10	38991	\N	3518382	\N
3854149	GENERIC_DAY	0	0	f	2010-01-31	3513191	\N	3518382	\N
3854150	GENERIC_DAY	0	4	f	2010-02-02	3513191	\N	3518382	\N
3854151	GENERIC_DAY	0	4	f	2010-02-01	3513191	\N	3518382	\N
3854152	GENERIC_DAY	0	0	f	2010-01-31	38991	\N	3518382	\N
3854153	GENERIC_DAY	0	4	f	2010-02-16	38991	\N	3518382	\N
3854154	GENERIC_DAY	0	4	f	2010-02-01	38991	\N	3518382	\N
3854155	GENERIC_DAY	0	4	f	2010-02-03	38991	\N	3518382	\N
3854156	GENERIC_DAY	0	4	f	2010-02-12	3513191	\N	3518382	\N
3854157	GENERIC_DAY	0	0	f	2010-02-06	3513191	\N	3518382	\N
3854158	GENERIC_DAY	0	0	f	2010-01-30	3513191	\N	3518382	\N
3854159	GENERIC_DAY	0	4	f	2010-02-09	38991	\N	3518382	\N
3854160	GENERIC_DAY	0	4	f	2010-02-11	38991	\N	3518382	\N
3854161	GENERIC_DAY	0	0	f	2010-01-30	38991	\N	3518382	\N
3854162	GENERIC_DAY	0	4	f	2010-02-15	38991	\N	3518382	\N
3854163	GENERIC_DAY	0	4	f	2010-02-08	38991	\N	3518382	\N
3854164	GENERIC_DAY	0	4	f	2010-02-05	38991	\N	3518382	\N
3854165	GENERIC_DAY	0	0	f	2010-02-13	38991	\N	3518382	\N
3854166	GENERIC_DAY	0	4	f	2010-02-16	3513191	\N	3518382	\N
3854167	GENERIC_DAY	0	0	f	2010-02-07	3513191	\N	3518382	\N
3854168	GENERIC_DAY	0	4	f	2010-02-04	3513191	\N	3518382	\N
3854169	GENERIC_DAY	0	0	f	2010-02-14	3513191	\N	3518382	\N
3854170	GENERIC_DAY	0	4	f	2010-02-03	3513191	\N	3518382	\N
3854171	GENERIC_DAY	0	4	f	2010-02-11	3513191	\N	3518382	\N
3854172	GENERIC_DAY	0	4	f	2010-02-12	38991	\N	3518382	\N
3854173	GENERIC_DAY	0	4	f	2010-02-09	3513191	\N	3518382	\N
3854174	GENERIC_DAY	0	0	f	2010-02-13	3513191	\N	3518382	\N
3854175	GENERIC_DAY	0	4	f	2010-02-02	38991	\N	3518382	\N
3854176	GENERIC_DAY	0	0	f	2010-02-14	38991	\N	3518382	\N
3854177	GENERIC_DAY	0	4	f	2010-02-15	3513191	\N	3518382	\N
3854178	GENERIC_DAY	0	4	f	2010-02-08	3513191	\N	3518382	\N
3854179	GENERIC_DAY	0	0	f	2010-02-07	38991	\N	3518382	\N
3854180	GENERIC_DAY	0	4	f	2010-02-10	3513191	\N	3518382	\N
3854181	GENERIC_DAY	0	4	f	2010-02-04	38991	\N	3518382	\N
3854182	GENERIC_DAY	0	0	f	2010-02-27	38991	\N	3518383	\N
3854183	GENERIC_DAY	0	4	f	2010-03-05	38991	\N	3518383	\N
3854184	GENERIC_DAY	0	4	f	2010-02-17	38991	\N	3518383	\N
3854185	GENERIC_DAY	0	4	f	2010-03-03	38991	\N	3518383	\N
3854186	GENERIC_DAY	0	4	f	2010-03-05	3513191	\N	3518383	\N
3854187	GENERIC_DAY	0	0	f	2010-02-28	38991	\N	3518383	\N
3854188	GENERIC_DAY	0	4	f	2010-03-08	38991	\N	3518383	\N
3854189	GENERIC_DAY	0	4	f	2010-03-08	3513191	\N	3518383	\N
3854190	GENERIC_DAY	0	4	f	2010-02-23	3513191	\N	3518383	\N
3854191	GENERIC_DAY	0	4	f	2010-02-24	38991	\N	3518383	\N
3854192	GENERIC_DAY	0	4	f	2010-03-02	3513191	\N	3518383	\N
3854193	GENERIC_DAY	0	4	f	2010-02-22	3513191	\N	3518383	\N
3854194	GENERIC_DAY	0	4	f	2010-02-18	3513191	\N	3518383	\N
3854195	GENERIC_DAY	0	0	f	2010-02-21	3513191	\N	3518383	\N
3854196	GENERIC_DAY	0	4	f	2010-03-01	3513191	\N	3518383	\N
3854197	GENERIC_DAY	0	4	f	2010-03-12	38991	\N	3518383	\N
3854198	GENERIC_DAY	0	4	f	2010-03-11	38991	\N	3518383	\N
3854199	GENERIC_DAY	0	4	f	2010-02-19	3513191	\N	3518383	\N
3854200	GENERIC_DAY	0	0	f	2010-03-07	3513191	\N	3518383	\N
3854201	GENERIC_DAY	0	0	f	2010-02-28	3513191	\N	3518383	\N
3854202	GENERIC_DAY	0	0	f	2010-02-20	3513191	\N	3518383	\N
3854203	GENERIC_DAY	0	4	f	2010-02-25	38991	\N	3518383	\N
3854204	GENERIC_DAY	0	4	f	2010-03-10	38991	\N	3518383	\N
3854205	GENERIC_DAY	0	4	f	2010-03-09	38991	\N	3518383	\N
3854206	GENERIC_DAY	0	0	f	2010-02-27	3513191	\N	3518383	\N
3854207	GENERIC_DAY	0	4	f	2010-03-02	38991	\N	3518383	\N
3854208	GENERIC_DAY	0	4	f	2010-03-12	3513191	\N	3518383	\N
3854209	GENERIC_DAY	0	4	f	2010-02-17	3513191	\N	3518383	\N
3854210	GENERIC_DAY	0	4	f	2010-03-10	3513191	\N	3518383	\N
3854211	GENERIC_DAY	0	4	f	2010-03-04	3513191	\N	3518383	\N
3854212	GENERIC_DAY	0	4	f	2010-02-19	38991	\N	3518383	\N
3854213	GENERIC_DAY	0	4	f	2010-02-22	38991	\N	3518383	\N
3854214	GENERIC_DAY	0	4	f	2010-02-25	3513191	\N	3518383	\N
3854215	GENERIC_DAY	0	4	f	2010-02-23	38991	\N	3518383	\N
3854216	GENERIC_DAY	0	4	f	2010-02-26	3513191	\N	3518383	\N
3854217	GENERIC_DAY	0	4	f	2010-02-24	3513191	\N	3518383	\N
3854218	GENERIC_DAY	0	0	f	2010-02-21	38991	\N	3518383	\N
3854219	GENERIC_DAY	0	4	f	2010-02-26	38991	\N	3518383	\N
3854220	GENERIC_DAY	0	4	f	2010-02-18	38991	\N	3518383	\N
3854221	GENERIC_DAY	0	4	f	2010-03-09	3513191	\N	3518383	\N
3854222	GENERIC_DAY	0	4	f	2010-03-01	38991	\N	3518383	\N
3854223	GENERIC_DAY	0	0	f	2010-02-20	38991	\N	3518383	\N
3854224	GENERIC_DAY	0	4	f	2010-03-11	3513191	\N	3518383	\N
3854225	GENERIC_DAY	0	4	f	2010-03-04	38991	\N	3518383	\N
3854226	GENERIC_DAY	0	0	f	2010-03-06	3513191	\N	3518383	\N
3854227	GENERIC_DAY	0	0	f	2010-03-07	38991	\N	3518383	\N
3854228	GENERIC_DAY	0	0	f	2010-03-06	38991	\N	3518383	\N
3854229	GENERIC_DAY	0	4	f	2010-03-03	3513191	\N	3518383	\N
3854230	GENERIC_DAY	0	0	f	2010-03-21	38991	\N	3659364	\N
3854231	GENERIC_DAY	0	4	f	2010-03-15	3513191	\N	3659364	\N
3854232	GENERIC_DAY	0	4	f	2010-03-22	38991	\N	3659364	\N
3854233	GENERIC_DAY	0	0	f	2010-03-20	3513191	\N	3659364	\N
3854234	GENERIC_DAY	0	0	f	2010-03-13	3513191	\N	3659364	\N
3854235	GENERIC_DAY	0	4	f	2010-03-17	38991	\N	3659364	\N
3854236	GENERIC_DAY	0	4	f	2010-03-23	3513191	\N	3659364	\N
3854237	GENERIC_DAY	0	4	f	2010-03-25	3513191	\N	3659364	\N
3854238	GENERIC_DAY	0	4	f	2010-03-15	38991	\N	3659364	\N
3854239	GENERIC_DAY	0	4	f	2010-03-16	3513191	\N	3659364	\N
3854240	GENERIC_DAY	0	4	f	2010-03-19	3513191	\N	3659364	\N
3854241	GENERIC_DAY	0	4	f	2010-03-19	38991	\N	3659364	\N
3854242	GENERIC_DAY	0	0	f	2010-03-13	38991	\N	3659364	\N
3854243	GENERIC_DAY	0	0	f	2010-03-21	3513191	\N	3659364	\N
3854244	GENERIC_DAY	0	4	f	2010-03-22	3513191	\N	3659364	\N
3854245	GENERIC_DAY	0	4	f	2010-03-17	3513191	\N	3659364	\N
3854246	GENERIC_DAY	0	0	f	2010-03-20	38991	\N	3659364	\N
3854247	GENERIC_DAY	0	4	f	2010-03-18	38991	\N	3659364	\N
3854248	GENERIC_DAY	0	4	f	2010-03-24	3513191	\N	3659364	\N
3854249	GENERIC_DAY	0	4	f	2010-03-16	38991	\N	3659364	\N
3854250	GENERIC_DAY	0	4	f	2010-03-25	38991	\N	3659364	\N
3854251	GENERIC_DAY	0	4	f	2010-03-18	3513191	\N	3659364	\N
3854252	GENERIC_DAY	0	0	f	2010-03-14	38991	\N	3659364	\N
3854253	GENERIC_DAY	0	0	f	2010-03-14	3513191	\N	3659364	\N
3854254	GENERIC_DAY	0	4	f	2010-03-23	38991	\N	3659364	\N
3854255	GENERIC_DAY	0	4	f	2010-03-24	38991	\N	3659364	\N
3854256	GENERIC_DAY	0	4	f	2010-04-01	38991	\N	3659365	\N
3854257	GENERIC_DAY	0	4	f	2010-04-02	38991	\N	3659365	\N
3854258	GENERIC_DAY	0	0	f	2010-04-10	3513191	\N	3659365	\N
3854259	GENERIC_DAY	0	4	f	2010-04-08	38991	\N	3659365	\N
3854260	GENERIC_DAY	0	4	f	2010-04-16	38991	\N	3659365	\N
3854261	GENERIC_DAY	0	4	f	2010-04-01	3513191	\N	3659365	\N
3854262	GENERIC_DAY	0	4	f	2010-04-14	38991	\N	3659365	\N
3854263	GENERIC_DAY	0	0	f	2010-04-17	38991	\N	3659365	\N
3854264	GENERIC_DAY	0	4	f	2010-04-15	3513191	\N	3659365	\N
3854265	GENERIC_DAY	0	0	f	2010-04-18	38991	\N	3659365	\N
3854266	GENERIC_DAY	0	4	f	2010-04-19	3513191	\N	3659365	\N
3854267	GENERIC_DAY	0	0	f	2010-04-03	3513191	\N	3659365	\N
3854268	GENERIC_DAY	0	0	f	2010-04-17	3513191	\N	3659365	\N
3854269	GENERIC_DAY	0	0	f	2010-04-18	3513191	\N	3659365	\N
3854270	GENERIC_DAY	0	0	f	2010-04-04	3513191	\N	3659365	\N
3854271	GENERIC_DAY	0	4	f	2010-04-08	3513191	\N	3659365	\N
3854272	GENERIC_DAY	0	4	f	2010-03-30	38991	\N	3659365	\N
3854273	GENERIC_DAY	0	4	f	2010-04-12	38991	\N	3659365	\N
3854274	GENERIC_DAY	0	0	f	2010-03-27	38991	\N	3659365	\N
3854275	GENERIC_DAY	0	4	f	2010-04-07	3513191	\N	3659365	\N
3854276	GENERIC_DAY	0	0	f	2010-03-28	38991	\N	3659365	\N
3854277	GENERIC_DAY	0	0	f	2010-04-11	3513191	\N	3659365	\N
3854278	GENERIC_DAY	0	4	f	2010-03-31	3513191	\N	3659365	\N
3854279	GENERIC_DAY	0	0	f	2010-03-27	3513191	\N	3659365	\N
3854280	GENERIC_DAY	0	4	f	2010-03-26	3513191	\N	3659365	\N
3854281	GENERIC_DAY	0	0	f	2010-04-11	38991	\N	3659365	\N
3854282	GENERIC_DAY	0	4	f	2010-03-29	38991	\N	3659365	\N
3854283	GENERIC_DAY	0	4	f	2010-04-09	3513191	\N	3659365	\N
3854284	GENERIC_DAY	0	4	f	2010-04-13	38991	\N	3659365	\N
3854285	GENERIC_DAY	0	4	f	2010-04-19	38991	\N	3659365	\N
3854286	GENERIC_DAY	0	4	f	2010-04-05	3513191	\N	3659365	\N
3854287	GENERIC_DAY	0	4	f	2010-04-20	38991	\N	3659365	\N
3854288	GENERIC_DAY	0	4	f	2010-03-29	3513191	\N	3659365	\N
3854289	GENERIC_DAY	0	4	f	2010-04-06	3513191	\N	3659365	\N
3854290	GENERIC_DAY	0	4	f	2010-04-20	3513191	\N	3659365	\N
3854291	GENERIC_DAY	0	4	f	2010-04-15	38991	\N	3659365	\N
3854292	GENERIC_DAY	0	4	f	2010-04-09	38991	\N	3659365	\N
3854293	GENERIC_DAY	0	0	f	2010-03-28	3513191	\N	3659365	\N
3854294	GENERIC_DAY	0	4	f	2010-04-13	3513191	\N	3659365	\N
3854295	GENERIC_DAY	0	0	f	2010-04-03	38991	\N	3659365	\N
3854296	GENERIC_DAY	0	4	f	2010-04-06	38991	\N	3659365	\N
3854297	GENERIC_DAY	0	0	f	2010-04-04	38991	\N	3659365	\N
3854298	GENERIC_DAY	0	4	f	2010-03-26	38991	\N	3659365	\N
3854299	GENERIC_DAY	0	4	f	2010-03-30	3513191	\N	3659365	\N
3854300	GENERIC_DAY	0	4	f	2010-04-16	3513191	\N	3659365	\N
3854301	GENERIC_DAY	0	4	f	2010-04-02	3513191	\N	3659365	\N
3854302	GENERIC_DAY	0	4	f	2010-04-05	38991	\N	3659365	\N
3854303	GENERIC_DAY	0	0	f	2010-04-10	38991	\N	3659365	\N
3854304	GENERIC_DAY	0	4	f	2010-04-12	3513191	\N	3659365	\N
3854305	GENERIC_DAY	0	4	f	2010-03-31	38991	\N	3659365	\N
3854306	GENERIC_DAY	0	4	f	2010-04-07	38991	\N	3659365	\N
3854307	GENERIC_DAY	0	4	f	2010-04-14	3513191	\N	3659365	\N
3854308	GENERIC_DAY	0	4	f	2010-04-23	3513191	\N	3659366	\N
3854309	GENERIC_DAY	0	4	f	2010-04-21	3513191	\N	3659366	\N
3854310	GENERIC_DAY	0	4	f	2010-04-22	3513191	\N	3659366	\N
3854311	GENERIC_DAY	0	0	f	2010-04-25	38991	\N	3659366	\N
3854312	GENERIC_DAY	0	4	f	2010-04-21	38991	\N	3659366	\N
3854313	GENERIC_DAY	0	0	f	2010-04-25	3513191	\N	3659366	\N
3854314	GENERIC_DAY	0	4	f	2010-04-23	38991	\N	3659366	\N
3854315	GENERIC_DAY	0	0	f	2010-04-24	38991	\N	3659366	\N
3854316	GENERIC_DAY	0	0	f	2010-04-24	3513191	\N	3659366	\N
3854317	GENERIC_DAY	0	4	f	2010-04-26	38991	\N	3659366	\N
3854318	GENERIC_DAY	0	4	f	2010-04-26	3513191	\N	3659366	\N
3854319	GENERIC_DAY	0	4	f	2010-04-22	38991	\N	3659366	\N
3854320	GENERIC_DAY	0	4	f	2010-04-28	3513191	\N	3659367	\N
3854321	GENERIC_DAY	0	4	f	2010-05-05	3513191	\N	3659367	\N
3854322	GENERIC_DAY	0	0	f	2010-05-22	3513191	\N	3659367	\N
3854323	GENERIC_DAY	0	0	f	2010-05-01	38991	\N	3659367	\N
3854324	GENERIC_DAY	0	4	f	2010-05-06	3513191	\N	3659367	\N
3854325	GENERIC_DAY	0	4	f	2010-05-25	38991	\N	3659367	\N
3854326	GENERIC_DAY	0	4	f	2010-05-20	3513191	\N	3659367	\N
3854327	GENERIC_DAY	0	0	f	2010-05-22	38991	\N	3659367	\N
3854328	GENERIC_DAY	0	4	f	2010-05-11	3513191	\N	3659367	\N
3854329	GENERIC_DAY	0	4	f	2010-05-17	38991	\N	3659367	\N
3854330	GENERIC_DAY	0	4	f	2010-05-12	38991	\N	3659367	\N
3854331	GENERIC_DAY	0	4	f	2010-05-19	38991	\N	3659367	\N
3854332	GENERIC_DAY	0	4	f	2010-05-14	38991	\N	3659367	\N
3854333	GENERIC_DAY	0	4	f	2010-05-20	38991	\N	3659367	\N
3854334	GENERIC_DAY	0	4	f	2010-05-14	3513191	\N	3659367	\N
3854335	GENERIC_DAY	0	4	f	2010-05-03	38991	\N	3659367	\N
3854336	GENERIC_DAY	0	4	f	2010-05-12	3513191	\N	3659367	\N
3854337	GENERIC_DAY	0	4	f	2010-05-17	3513191	\N	3659367	\N
3854338	GENERIC_DAY	0	0	f	2010-05-08	38991	\N	3659367	\N
3854339	GENERIC_DAY	0	0	f	2010-05-16	38991	\N	3659367	\N
3854340	GENERIC_DAY	0	0	f	2010-05-02	38991	\N	3659367	\N
3854341	GENERIC_DAY	0	4	f	2010-05-04	38991	\N	3659367	\N
3854342	GENERIC_DAY	0	0	f	2010-05-15	38991	\N	3659367	\N
3854343	GENERIC_DAY	0	0	f	2010-05-02	3513191	\N	3659367	\N
3854344	GENERIC_DAY	0	4	f	2010-05-13	3513191	\N	3659367	\N
3854345	GENERIC_DAY	0	4	f	2010-05-24	3513191	\N	3659367	\N
3854346	GENERIC_DAY	0	4	f	2010-05-18	3513191	\N	3659367	\N
3854347	GENERIC_DAY	0	4	f	2010-05-04	3513191	\N	3659367	\N
3854348	GENERIC_DAY	0	4	f	2010-05-18	38991	\N	3659367	\N
3854349	GENERIC_DAY	0	4	f	2010-04-30	38991	\N	3659367	\N
3854350	GENERIC_DAY	0	0	f	2010-05-09	38991	\N	3659367	\N
3854351	GENERIC_DAY	0	4	f	2010-04-27	38991	\N	3659367	\N
3854352	GENERIC_DAY	0	4	f	2010-05-07	38991	\N	3659367	\N
3854353	GENERIC_DAY	0	4	f	2010-04-29	3513191	\N	3659367	\N
3854354	GENERIC_DAY	0	4	f	2010-05-24	38991	\N	3659367	\N
3854355	GENERIC_DAY	0	4	f	2010-04-30	3513191	\N	3659367	\N
3854356	GENERIC_DAY	0	4	f	2010-04-29	38991	\N	3659367	\N
3854357	GENERIC_DAY	0	4	f	2010-05-07	3513191	\N	3659367	\N
3854358	GENERIC_DAY	0	0	f	2010-05-16	3513191	\N	3659367	\N
3854359	GENERIC_DAY	0	4	f	2010-05-13	38991	\N	3659367	\N
3854360	GENERIC_DAY	0	0	f	2010-05-23	38991	\N	3659367	\N
3854361	GENERIC_DAY	0	0	f	2010-05-15	3513191	\N	3659367	\N
3854362	GENERIC_DAY	0	4	f	2010-05-21	3513191	\N	3659367	\N
3854363	GENERIC_DAY	0	4	f	2010-05-11	38991	\N	3659367	\N
3854364	GENERIC_DAY	0	4	f	2010-04-28	38991	\N	3659367	\N
3854365	GENERIC_DAY	0	4	f	2010-05-10	38991	\N	3659367	\N
3854366	GENERIC_DAY	0	4	f	2010-05-06	38991	\N	3659367	\N
3854367	GENERIC_DAY	0	4	f	2010-05-10	3513191	\N	3659367	\N
3854368	GENERIC_DAY	0	4	f	2010-05-19	3513191	\N	3659367	\N
3854369	GENERIC_DAY	0	4	f	2010-05-03	3513191	\N	3659367	\N
3854370	GENERIC_DAY	0	0	f	2010-05-01	3513191	\N	3659367	\N
3854371	GENERIC_DAY	0	4	f	2010-05-05	38991	\N	3659367	\N
3854372	GENERIC_DAY	0	0	f	2010-05-09	3513191	\N	3659367	\N
3854373	GENERIC_DAY	0	4	f	2010-04-27	3513191	\N	3659367	\N
3854374	GENERIC_DAY	0	4	f	2010-05-21	38991	\N	3659367	\N
3854375	GENERIC_DAY	0	0	f	2010-05-23	3513191	\N	3659367	\N
3854376	GENERIC_DAY	0	0	f	2010-05-08	3513191	\N	3659367	\N
3854377	GENERIC_DAY	0	4	f	2010-05-25	3513191	\N	3659367	\N
3854378	GENERIC_DAY	0	4	f	2010-05-27	38991	\N	3659387	\N
3854379	GENERIC_DAY	0	0	f	2010-06-20	3513191	\N	3659387	\N
3854380	GENERIC_DAY	0	0	f	2010-06-12	38991	\N	3659387	\N
3854381	GENERIC_DAY	0	0	f	2010-06-06	3513191	\N	3659387	\N
3854382	GENERIC_DAY	0	4	f	2010-06-23	38991	\N	3659387	\N
3854383	GENERIC_DAY	0	4	f	2010-07-02	38991	\N	3659387	\N
3854384	GENERIC_DAY	0	4	f	2010-06-11	3513191	\N	3659387	\N
3854385	GENERIC_DAY	0	0	f	2010-07-04	3513191	\N	3659387	\N
3854386	GENERIC_DAY	0	4	f	2010-06-10	38991	\N	3659387	\N
3854387	GENERIC_DAY	0	4	f	2010-07-01	38991	\N	3659387	\N
3854388	GENERIC_DAY	0	4	f	2010-06-17	3513191	\N	3659387	\N
3854389	GENERIC_DAY	0	4	f	2010-06-24	3513191	\N	3659387	\N
3854390	GENERIC_DAY	0	4	f	2010-06-29	3513191	\N	3659387	\N
3854391	GENERIC_DAY	0	0	f	2010-05-30	3513191	\N	3659387	\N
3854392	GENERIC_DAY	0	4	f	2010-05-28	38991	\N	3659387	\N
3854393	GENERIC_DAY	0	4	f	2010-06-25	38991	\N	3659387	\N
3854394	GENERIC_DAY	0	4	f	2010-06-16	3513191	\N	3659387	\N
3854395	GENERIC_DAY	0	4	f	2010-06-01	3513191	\N	3659387	\N
3854396	GENERIC_DAY	0	4	f	2010-06-21	3513191	\N	3659387	\N
3854397	GENERIC_DAY	0	4	f	2010-06-18	38991	\N	3659387	\N
3854398	GENERIC_DAY	0	4	f	2010-06-22	3513191	\N	3659387	\N
3854399	GENERIC_DAY	0	4	f	2010-06-14	3513191	\N	3659387	\N
3854400	GENERIC_DAY	0	4	f	2010-06-15	38991	\N	3659387	\N
3854401	GENERIC_DAY	0	0	f	2010-07-03	38991	\N	3659387	\N
3854402	GENERIC_DAY	0	4	f	2010-06-03	38991	\N	3659387	\N
3854403	GENERIC_DAY	0	4	f	2010-06-28	38991	\N	3659387	\N
3854404	GENERIC_DAY	0	0	f	2010-06-06	38991	\N	3659387	\N
3854405	GENERIC_DAY	0	4	f	2010-06-04	3513191	\N	3659387	\N
3854406	GENERIC_DAY	0	4	f	2010-06-14	38991	\N	3659387	\N
3854407	GENERIC_DAY	0	0	f	2010-06-20	38991	\N	3659387	\N
3854408	GENERIC_DAY	0	0	f	2010-06-19	3513191	\N	3659387	\N
3854409	GENERIC_DAY	0	0	f	2010-06-12	3513191	\N	3659387	\N
3854410	GENERIC_DAY	0	4	f	2010-06-28	3513191	\N	3659387	\N
3854411	GENERIC_DAY	0	4	f	2010-06-11	38991	\N	3659387	\N
3854412	GENERIC_DAY	0	4	f	2010-05-27	3513191	\N	3659387	\N
3854413	GENERIC_DAY	0	4	f	2010-07-02	3513191	\N	3659387	\N
3854414	GENERIC_DAY	0	0	f	2010-05-29	38991	\N	3659387	\N
3854415	GENERIC_DAY	0	4	f	2010-06-09	38991	\N	3659387	\N
3854416	GENERIC_DAY	0	4	f	2010-06-09	3513191	\N	3659387	\N
3854417	GENERIC_DAY	0	4	f	2010-06-03	3513191	\N	3659387	\N
3854418	GENERIC_DAY	0	4	f	2010-07-06	3513191	\N	3659387	\N
3854419	GENERIC_DAY	0	0	f	2010-07-03	3513191	\N	3659387	\N
3854420	GENERIC_DAY	0	0	f	2010-06-27	38991	\N	3659387	\N
3854421	GENERIC_DAY	0	4	f	2010-06-17	38991	\N	3659387	\N
3854422	GENERIC_DAY	0	4	f	2010-06-21	38991	\N	3659387	\N
3854423	GENERIC_DAY	0	4	f	2010-06-02	38991	\N	3659387	\N
3854424	GENERIC_DAY	0	4	f	2010-06-15	3513191	\N	3659387	\N
3854425	GENERIC_DAY	0	4	f	2010-07-01	3513191	\N	3659387	\N
3854426	GENERIC_DAY	0	4	f	2010-06-30	38991	\N	3659387	\N
3854427	GENERIC_DAY	0	0	f	2010-06-05	38991	\N	3659387	\N
3854428	GENERIC_DAY	0	4	f	2010-06-04	38991	\N	3659387	\N
3854429	GENERIC_DAY	0	4	f	2010-06-16	38991	\N	3659387	\N
3854430	GENERIC_DAY	0	0	f	2010-07-04	38991	\N	3659387	\N
3854431	GENERIC_DAY	0	4	f	2010-06-25	3513191	\N	3659387	\N
3854432	GENERIC_DAY	0	4	f	2010-06-29	38991	\N	3659387	\N
3854433	GENERIC_DAY	0	4	f	2010-06-24	38991	\N	3659387	\N
3854434	GENERIC_DAY	0	4	f	2010-07-05	38991	\N	3659387	\N
3854435	GENERIC_DAY	0	4	f	2010-07-06	38991	\N	3659387	\N
3854436	GENERIC_DAY	0	0	f	2010-05-29	3513191	\N	3659387	\N
3854437	GENERIC_DAY	0	0	f	2010-06-26	38991	\N	3659387	\N
3854438	GENERIC_DAY	0	4	f	2010-06-08	3513191	\N	3659387	\N
3854439	GENERIC_DAY	0	4	f	2010-06-22	38991	\N	3659387	\N
3854440	GENERIC_DAY	0	4	f	2010-05-26	38991	\N	3659387	\N
3854441	GENERIC_DAY	0	4	f	2010-07-05	3513191	\N	3659387	\N
3854442	GENERIC_DAY	0	0	f	2010-05-30	38991	\N	3659387	\N
3854443	GENERIC_DAY	0	0	f	2010-06-13	38991	\N	3659387	\N
3854444	GENERIC_DAY	0	0	f	2010-06-13	3513191	\N	3659387	\N
3854445	GENERIC_DAY	0	0	f	2010-06-19	38991	\N	3659387	\N
3854446	GENERIC_DAY	0	0	f	2010-06-26	3513191	\N	3659387	\N
3854447	GENERIC_DAY	0	4	f	2010-06-18	3513191	\N	3659387	\N
3854448	GENERIC_DAY	0	4	f	2010-06-01	38991	\N	3659387	\N
3854449	GENERIC_DAY	0	4	f	2010-06-10	3513191	\N	3659387	\N
3854450	GENERIC_DAY	0	4	f	2010-05-31	38991	\N	3659387	\N
3854451	GENERIC_DAY	0	0	f	2010-06-27	3513191	\N	3659387	\N
3854452	GENERIC_DAY	0	4	f	2010-06-02	3513191	\N	3659387	\N
3854453	GENERIC_DAY	0	4	f	2010-05-31	3513191	\N	3659387	\N
3854454	GENERIC_DAY	0	4	f	2010-06-07	38991	\N	3659387	\N
3854455	GENERIC_DAY	0	4	f	2010-06-23	3513191	\N	3659387	\N
3854456	GENERIC_DAY	0	4	f	2010-05-26	3513191	\N	3659387	\N
3854457	GENERIC_DAY	0	4	f	2010-06-30	3513191	\N	3659387	\N
3854458	GENERIC_DAY	0	4	f	2010-06-08	38991	\N	3659387	\N
3854459	GENERIC_DAY	0	4	f	2010-05-28	3513191	\N	3659387	\N
3854460	GENERIC_DAY	0	0	f	2010-06-05	3513191	\N	3659387	\N
3854461	GENERIC_DAY	0	4	f	2010-06-07	3513191	\N	3659387	\N
3854462	GENERIC_DAY	0	4	f	2010-07-21	3513191	\N	3659389	\N
3854463	GENERIC_DAY	0	0	f	2010-07-10	3513191	\N	3659389	\N
3854464	GENERIC_DAY	0	4	f	2010-07-16	38991	\N	3659389	\N
3854465	GENERIC_DAY	0	4	f	2010-07-20	38991	\N	3659389	\N
3854466	GENERIC_DAY	0	4	f	2010-07-22	38991	\N	3659389	\N
3854467	GENERIC_DAY	0	4	f	2010-07-15	38991	\N	3659389	\N
3854468	GENERIC_DAY	0	4	f	2010-07-09	38991	\N	3659389	\N
3854469	GENERIC_DAY	0	0	f	2010-07-18	3513191	\N	3659389	\N
3854470	GENERIC_DAY	0	0	f	2010-07-11	38991	\N	3659389	\N
3854471	GENERIC_DAY	0	0	f	2010-07-17	3513191	\N	3659389	\N
3854472	GENERIC_DAY	0	4	f	2010-07-09	3513191	\N	3659389	\N
3854473	GENERIC_DAY	0	4	f	2010-07-21	38991	\N	3659389	\N
3854474	GENERIC_DAY	0	0	f	2010-07-11	3513191	\N	3659389	\N
3854475	GENERIC_DAY	0	4	f	2010-07-20	3513191	\N	3659389	\N
3854476	GENERIC_DAY	0	4	f	2010-07-14	38991	\N	3659389	\N
3854477	GENERIC_DAY	0	4	f	2010-07-16	3513191	\N	3659389	\N
3854478	GENERIC_DAY	0	4	f	2010-07-13	38991	\N	3659389	\N
3854479	GENERIC_DAY	0	4	f	2010-07-07	38991	\N	3659389	\N
3854480	GENERIC_DAY	0	4	f	2010-07-12	38991	\N	3659389	\N
3854481	GENERIC_DAY	0	0	f	2010-07-10	38991	\N	3659389	\N
3854482	GENERIC_DAY	0	4	f	2010-07-07	3513191	\N	3659389	\N
3854483	GENERIC_DAY	0	4	f	2010-07-13	3513191	\N	3659389	\N
3854484	GENERIC_DAY	0	4	f	2010-07-14	3513191	\N	3659389	\N
3854485	GENERIC_DAY	0	4	f	2010-07-12	3513191	\N	3659389	\N
3854486	GENERIC_DAY	0	4	f	2010-07-19	38991	\N	3659389	\N
3854487	GENERIC_DAY	0	4	f	2010-07-19	3513191	\N	3659389	\N
3854488	GENERIC_DAY	0	4	f	2010-07-15	3513191	\N	3659389	\N
3854489	GENERIC_DAY	0	0	f	2010-07-18	38991	\N	3659389	\N
3854490	GENERIC_DAY	0	0	f	2010-07-17	38991	\N	3659389	\N
3854491	GENERIC_DAY	0	4	f	2010-07-08	3513191	\N	3659389	\N
3854492	GENERIC_DAY	0	4	f	2010-07-08	38991	\N	3659389	\N
3854493	GENERIC_DAY	0	4	f	2010-07-22	3513191	\N	3659389	\N
3854494	GENERIC_DAY	0	0	f	2010-01-31	3513185	\N	3518347	\N
3854495	GENERIC_DAY	0	0	f	2010-01-23	3513185	\N	3518347	\N
3854496	GENERIC_DAY	0	0	f	2010-01-10	3513185	\N	3518347	\N
3854497	GENERIC_DAY	0	4	f	2010-01-27	3513185	\N	3518347	\N
3854498	GENERIC_DAY	0	4	f	2010-01-12	3513185	\N	3518347	\N
3854499	GENERIC_DAY	0	4	f	2010-01-08	3513185	\N	3518347	\N
3854500	GENERIC_DAY	0	4	f	2010-01-15	3513185	\N	3518347	\N
3854501	GENERIC_DAY	0	4	f	2010-01-11	3513185	\N	3518347	\N
3854502	GENERIC_DAY	0	4	f	2010-01-26	3513185	\N	3518347	\N
3854503	GENERIC_DAY	0	0	f	2010-01-30	3513185	\N	3518347	\N
3854504	GENERIC_DAY	0	4	f	2010-01-22	3513185	\N	3518347	\N
3854505	GENERIC_DAY	0	4	f	2010-01-20	3513185	\N	3518347	\N
3854506	GENERIC_DAY	0	4	f	2010-01-14	3513185	\N	3518347	\N
3854507	GENERIC_DAY	0	4	f	2010-01-28	3513185	\N	3518347	\N
3854508	GENERIC_DAY	0	4	f	2010-01-13	3513185	\N	3518347	\N
3854509	GENERIC_DAY	0	0	f	2010-01-16	3513185	\N	3518347	\N
3854510	GENERIC_DAY	0	4	f	2010-01-25	3513185	\N	3518347	\N
3854511	GENERIC_DAY	0	4	f	2010-01-29	3513185	\N	3518347	\N
3854512	GENERIC_DAY	0	4	f	2010-01-21	3513185	\N	3518347	\N
3854513	GENERIC_DAY	0	4	f	2010-02-01	3513185	\N	3518347	\N
3854514	GENERIC_DAY	0	4	f	2010-01-18	3513185	\N	3518347	\N
3854515	GENERIC_DAY	0	4	f	2010-01-19	3513185	\N	3518347	\N
3854516	GENERIC_DAY	0	0	f	2010-01-09	3513185	\N	3518347	\N
3854517	GENERIC_DAY	0	0	f	2010-01-17	3513185	\N	3518347	\N
3854518	GENERIC_DAY	0	0	f	2010-01-24	3513185	\N	3518347	\N
3854519	GENERIC_DAY	0	4	f	2010-03-25	3513185	\N	3518348	\N
3854520	GENERIC_DAY	0	4	f	2010-03-03	3513185	\N	3518348	\N
3854521	GENERIC_DAY	0	4	f	2010-02-25	3513185	\N	3518348	\N
3854522	GENERIC_DAY	0	4	f	2010-02-26	3513185	\N	3518348	\N
3854523	GENERIC_DAY	0	4	f	2010-02-23	3513185	\N	3518348	\N
3854524	GENERIC_DAY	0	4	f	2010-02-03	3513185	\N	3518348	\N
3854525	GENERIC_DAY	0	0	f	2010-03-06	3513185	\N	3518348	\N
3854526	GENERIC_DAY	0	4	f	2010-03-11	3513185	\N	3518348	\N
3854527	GENERIC_DAY	0	0	f	2010-03-14	3513185	\N	3518348	\N
3854528	GENERIC_DAY	0	0	f	2010-03-28	3513185	\N	3518348	\N
3854529	GENERIC_DAY	0	4	f	2010-03-05	3513185	\N	3518348	\N
3854530	GENERIC_DAY	0	4	f	2010-03-23	3513185	\N	3518348	\N
3854531	GENERIC_DAY	0	0	f	2010-03-20	3513185	\N	3518348	\N
3854532	GENERIC_DAY	0	4	f	2010-02-04	3513185	\N	3518348	\N
3854533	GENERIC_DAY	0	4	f	2010-03-08	3513185	\N	3518348	\N
3854534	GENERIC_DAY	0	4	f	2010-02-19	3513185	\N	3518348	\N
3854535	GENERIC_DAY	0	4	f	2010-03-02	3513185	\N	3518348	\N
3854536	GENERIC_DAY	0	4	f	2010-02-16	3513185	\N	3518348	\N
3854537	GENERIC_DAY	0	0	f	2010-03-21	3513185	\N	3518348	\N
3854538	GENERIC_DAY	0	4	f	2010-03-16	3513185	\N	3518348	\N
3854539	GENERIC_DAY	0	4	f	2010-03-31	3513185	\N	3518348	\N
3854540	GENERIC_DAY	0	4	f	2010-03-01	3513185	\N	3518348	\N
3854541	GENERIC_DAY	0	4	f	2010-03-26	3513185	\N	3518348	\N
3854542	GENERIC_DAY	0	4	f	2010-03-22	3513185	\N	3518348	\N
3854543	GENERIC_DAY	0	4	f	2010-03-04	3513185	\N	3518348	\N
3854544	GENERIC_DAY	0	4	f	2010-04-02	3513185	\N	3518348	\N
3854545	GENERIC_DAY	0	4	f	2010-02-17	3513185	\N	3518348	\N
3854546	GENERIC_DAY	0	0	f	2010-02-07	3513185	\N	3518348	\N
3854547	GENERIC_DAY	0	4	f	2010-02-02	3513185	\N	3518348	\N
3854548	GENERIC_DAY	0	4	f	2010-03-29	3513185	\N	3518348	\N
3854549	GENERIC_DAY	0	4	f	2010-02-05	3513185	\N	3518348	\N
3854550	GENERIC_DAY	0	4	f	2010-02-24	3513185	\N	3518348	\N
3854551	GENERIC_DAY	0	0	f	2010-03-13	3513185	\N	3518348	\N
3854552	GENERIC_DAY	0	4	f	2010-03-30	3513185	\N	3518348	\N
3854553	GENERIC_DAY	0	4	f	2010-03-17	3513185	\N	3518348	\N
3854554	GENERIC_DAY	0	4	f	2010-03-19	3513185	\N	3518348	\N
3854555	GENERIC_DAY	0	4	f	2010-03-18	3513185	\N	3518348	\N
3854556	GENERIC_DAY	0	4	f	2010-02-18	3513185	\N	3518348	\N
3854557	GENERIC_DAY	0	4	f	2010-02-08	3513185	\N	3518348	\N
3854558	GENERIC_DAY	0	0	f	2010-02-21	3513185	\N	3518348	\N
3854559	GENERIC_DAY	0	0	f	2010-02-27	3513185	\N	3518348	\N
3854560	GENERIC_DAY	0	0	f	2010-03-07	3513185	\N	3518348	\N
3854561	GENERIC_DAY	0	4	f	2010-03-09	3513185	\N	3518348	\N
3854562	GENERIC_DAY	0	4	f	2010-04-01	3513185	\N	3518348	\N
3854563	GENERIC_DAY	0	0	f	2010-03-27	3513185	\N	3518348	\N
3854564	GENERIC_DAY	0	4	f	2010-02-10	3513185	\N	3518348	\N
3854565	GENERIC_DAY	0	4	f	2010-02-09	3513185	\N	3518348	\N
3854566	GENERIC_DAY	0	0	f	2010-02-13	3513185	\N	3518348	\N
3854567	GENERIC_DAY	0	0	f	2010-02-20	3513185	\N	3518348	\N
3854568	GENERIC_DAY	0	4	f	2010-03-10	3513185	\N	3518348	\N
3854569	GENERIC_DAY	0	0	f	2010-02-28	3513185	\N	3518348	\N
3854570	GENERIC_DAY	0	4	f	2010-02-15	3513185	\N	3518348	\N
3854571	GENERIC_DAY	0	4	f	2010-02-12	3513185	\N	3518348	\N
3854572	GENERIC_DAY	0	0	f	2010-02-14	3513185	\N	3518348	\N
3854573	GENERIC_DAY	0	4	f	2010-03-24	3513185	\N	3518348	\N
3854574	GENERIC_DAY	0	4	f	2010-03-15	3513185	\N	3518348	\N
3854575	GENERIC_DAY	0	4	f	2010-03-12	3513185	\N	3518348	\N
3854576	GENERIC_DAY	0	4	f	2010-02-11	3513185	\N	3518348	\N
3854577	GENERIC_DAY	0	0	f	2010-02-06	3513185	\N	3518348	\N
3854578	GENERIC_DAY	0	4	f	2010-02-22	3513185	\N	3518348	\N
3854579	GENERIC_DAY	0	4	f	2010-06-08	3513185	\N	3518349	\N
3854580	GENERIC_DAY	0	4	f	2010-04-23	3513185	\N	3518349	\N
3854581	GENERIC_DAY	0	4	f	2010-06-24	3513185	\N	3518349	\N
3854582	GENERIC_DAY	0	4	f	2010-05-31	3513185	\N	3518349	\N
3854583	GENERIC_DAY	0	0	f	2010-04-03	3513185	\N	3518349	\N
3854584	GENERIC_DAY	0	0	f	2010-04-17	3513185	\N	3518349	\N
3854585	GENERIC_DAY	0	0	f	2010-05-23	3513185	\N	3518349	\N
3854586	GENERIC_DAY	0	4	f	2010-07-02	3513185	\N	3518349	\N
3854587	GENERIC_DAY	0	4	f	2010-05-04	3513185	\N	3518349	\N
3854588	GENERIC_DAY	0	4	f	2010-05-19	3513185	\N	3518349	\N
3854589	GENERIC_DAY	0	0	f	2010-06-26	3513185	\N	3518349	\N
3854590	GENERIC_DAY	0	4	f	2010-07-09	3513185	\N	3518349	\N
3854591	GENERIC_DAY	0	4	f	2010-05-05	3513185	\N	3518349	\N
3854592	GENERIC_DAY	0	0	f	2010-04-10	3513185	\N	3518349	\N
3854593	GENERIC_DAY	0	0	f	2010-05-08	3513185	\N	3518349	\N
3854594	GENERIC_DAY	0	0	f	2010-05-29	3513185	\N	3518349	\N
3854595	GENERIC_DAY	0	4	f	2010-06-28	3513185	\N	3518349	\N
3854596	GENERIC_DAY	0	0	f	2010-05-01	3513185	\N	3518349	\N
3854597	GENERIC_DAY	0	4	f	2010-04-26	3513185	\N	3518349	\N
3854598	GENERIC_DAY	0	4	f	2010-07-08	3513185	\N	3518349	\N
3854599	GENERIC_DAY	0	0	f	2010-06-27	3513185	\N	3518349	\N
3854600	GENERIC_DAY	0	4	f	2010-04-20	3513185	\N	3518349	\N
3854601	GENERIC_DAY	0	0	f	2010-05-30	3513185	\N	3518349	\N
3854602	GENERIC_DAY	0	4	f	2010-05-25	3513185	\N	3518349	\N
3854603	GENERIC_DAY	0	0	f	2010-04-11	3513185	\N	3518349	\N
3854604	GENERIC_DAY	0	4	f	2010-05-10	3513185	\N	3518349	\N
3854605	GENERIC_DAY	0	4	f	2010-05-20	3513185	\N	3518349	\N
3854606	GENERIC_DAY	0	4	f	2010-06-16	3513185	\N	3518349	\N
3854607	GENERIC_DAY	0	4	f	2010-04-29	3513185	\N	3518349	\N
3854608	GENERIC_DAY	0	4	f	2010-05-26	3513185	\N	3518349	\N
3854609	GENERIC_DAY	0	4	f	2010-06-30	3513185	\N	3518349	\N
3854610	GENERIC_DAY	0	0	f	2010-05-09	3513185	\N	3518349	\N
3854611	GENERIC_DAY	0	4	f	2010-04-07	3513185	\N	3518349	\N
3854612	GENERIC_DAY	0	4	f	2010-04-16	3513185	\N	3518349	\N
3854613	GENERIC_DAY	0	4	f	2010-07-07	3513185	\N	3518349	\N
3854614	GENERIC_DAY	0	4	f	2010-05-12	3513185	\N	3518349	\N
3854615	GENERIC_DAY	0	0	f	2010-06-12	3513185	\N	3518349	\N
3854616	GENERIC_DAY	0	4	f	2010-04-12	3513185	\N	3518349	\N
3854617	GENERIC_DAY	0	0	f	2010-05-22	3513185	\N	3518349	\N
3854618	GENERIC_DAY	0	4	f	2010-04-21	3513185	\N	3518349	\N
3854619	GENERIC_DAY	0	4	f	2010-06-23	3513185	\N	3518349	\N
3854620	GENERIC_DAY	0	4	f	2010-04-30	3513185	\N	3518349	\N
3854621	GENERIC_DAY	0	4	f	2010-06-07	3513185	\N	3518349	\N
3854622	GENERIC_DAY	0	0	f	2010-04-18	3513185	\N	3518349	\N
3854623	GENERIC_DAY	0	4	f	2010-04-14	3513185	\N	3518349	\N
3854624	GENERIC_DAY	0	4	f	2010-07-05	3513185	\N	3518349	\N
3854625	GENERIC_DAY	0	4	f	2010-04-27	3513185	\N	3518349	\N
3854626	GENERIC_DAY	0	4	f	2010-04-19	3513185	\N	3518349	\N
3854627	GENERIC_DAY	0	4	f	2010-04-22	3513185	\N	3518349	\N
3854628	GENERIC_DAY	0	4	f	2010-05-24	3513185	\N	3518349	\N
3854629	GENERIC_DAY	0	4	f	2010-06-14	3513185	\N	3518349	\N
3854630	GENERIC_DAY	0	4	f	2010-05-13	3513185	\N	3518349	\N
3854631	GENERIC_DAY	0	4	f	2010-07-01	3513185	\N	3518349	\N
3854632	GENERIC_DAY	0	4	f	2010-04-08	3513185	\N	3518349	\N
3854633	GENERIC_DAY	0	4	f	2010-04-28	3513185	\N	3518349	\N
3854634	GENERIC_DAY	0	4	f	2010-06-04	3513185	\N	3518349	\N
3854635	GENERIC_DAY	0	4	f	2010-06-29	3513185	\N	3518349	\N
3854636	GENERIC_DAY	0	0	f	2010-06-20	3513185	\N	3518349	\N
3854637	GENERIC_DAY	0	4	f	2010-05-07	3513185	\N	3518349	\N
3854638	GENERIC_DAY	0	4	f	2010-06-11	3513185	\N	3518349	\N
3854639	GENERIC_DAY	0	4	f	2010-05-03	3513185	\N	3518349	\N
3854640	GENERIC_DAY	0	0	f	2010-06-05	3513185	\N	3518349	\N
3854641	GENERIC_DAY	0	0	f	2010-04-24	3513185	\N	3518349	\N
3854642	GENERIC_DAY	0	4	f	2010-06-09	3513185	\N	3518349	\N
3854643	GENERIC_DAY	0	4	f	2010-04-09	3513185	\N	3518349	\N
3854644	GENERIC_DAY	0	4	f	2010-05-27	3513185	\N	3518349	\N
3854645	GENERIC_DAY	0	4	f	2010-04-15	3513185	\N	3518349	\N
3854646	GENERIC_DAY	0	4	f	2010-05-06	3513185	\N	3518349	\N
3854647	GENERIC_DAY	0	0	f	2010-06-19	3513185	\N	3518349	\N
3854648	GENERIC_DAY	0	4	f	2010-06-02	3513185	\N	3518349	\N
3854649	GENERIC_DAY	0	4	f	2010-04-13	3513185	\N	3518349	\N
3854650	GENERIC_DAY	0	4	f	2010-06-17	3513185	\N	3518349	\N
3854651	GENERIC_DAY	0	4	f	2010-05-18	3513185	\N	3518349	\N
3854652	GENERIC_DAY	0	4	f	2010-05-11	3513185	\N	3518349	\N
3854653	GENERIC_DAY	0	4	f	2010-06-25	3513185	\N	3518349	\N
3854654	GENERIC_DAY	0	0	f	2010-05-02	3513185	\N	3518349	\N
3854655	GENERIC_DAY	0	0	f	2010-06-06	3513185	\N	3518349	\N
3854656	GENERIC_DAY	0	0	f	2010-07-03	3513185	\N	3518349	\N
3854657	GENERIC_DAY	0	4	f	2010-05-14	3513185	\N	3518349	\N
3854658	GENERIC_DAY	0	0	f	2010-04-04	3513185	\N	3518349	\N
3854659	GENERIC_DAY	0	4	f	2010-06-21	3513185	\N	3518349	\N
3854660	GENERIC_DAY	0	4	f	2010-06-22	3513185	\N	3518349	\N
3854661	GENERIC_DAY	0	4	f	2010-06-15	3513185	\N	3518349	\N
3854662	GENERIC_DAY	0	0	f	2010-05-16	3513185	\N	3518349	\N
3854663	GENERIC_DAY	0	4	f	2010-04-06	3513185	\N	3518349	\N
3854664	GENERIC_DAY	0	4	f	2010-06-10	3513185	\N	3518349	\N
3854665	GENERIC_DAY	0	4	f	2010-05-21	3513185	\N	3518349	\N
3854666	GENERIC_DAY	0	4	f	2010-06-18	3513185	\N	3518349	\N
3854667	GENERIC_DAY	0	4	f	2010-05-28	3513185	\N	3518349	\N
3854668	GENERIC_DAY	0	4	f	2010-07-06	3513185	\N	3518349	\N
3854669	GENERIC_DAY	0	4	f	2010-05-17	3513185	\N	3518349	\N
3854670	GENERIC_DAY	0	0	f	2010-05-15	3513185	\N	3518349	\N
3854671	GENERIC_DAY	0	4	f	2010-06-01	3513185	\N	3518349	\N
3854672	GENERIC_DAY	0	4	f	2010-06-03	3513185	\N	3518349	\N
3854673	GENERIC_DAY	0	0	f	2010-04-25	3513185	\N	3518349	\N
3854674	GENERIC_DAY	0	4	f	2010-04-05	3513185	\N	3518349	\N
3854675	GENERIC_DAY	0	0	f	2010-06-13	3513185	\N	3518349	\N
3854676	GENERIC_DAY	0	0	f	2010-07-04	3513185	\N	3518349	\N
3854677	GENERIC_DAY	0	4	f	2010-08-31	3513185	\N	3518350	\N
3854678	GENERIC_DAY	0	0	f	2010-09-04	3513185	\N	3518350	\N
3854679	GENERIC_DAY	0	4	f	2010-07-15	3513185	\N	3518350	\N
3854680	GENERIC_DAY	0	0	f	2010-08-21	3513185	\N	3518350	\N
3854681	GENERIC_DAY	0	4	f	2010-09-01	3513185	\N	3518350	\N
3854682	GENERIC_DAY	0	4	f	2010-08-03	3513185	\N	3518350	\N
3854683	GENERIC_DAY	0	4	f	2010-08-16	3513185	\N	3518350	\N
3854684	GENERIC_DAY	0	4	f	2010-08-13	3513185	\N	3518350	\N
3854685	GENERIC_DAY	0	4	f	2010-09-02	3513185	\N	3518350	\N
3854686	GENERIC_DAY	0	0	f	2010-08-29	3513185	\N	3518350	\N
3854687	GENERIC_DAY	0	0	f	2010-09-05	3513185	\N	3518350	\N
3854688	GENERIC_DAY	0	4	f	2010-07-16	3513185	\N	3518350	\N
3854689	GENERIC_DAY	0	4	f	2010-07-27	3513185	\N	3518350	\N
3854690	GENERIC_DAY	0	4	f	2010-08-17	3513185	\N	3518350	\N
3854691	GENERIC_DAY	0	4	f	2010-07-23	3513185	\N	3518350	\N
3854692	GENERIC_DAY	0	4	f	2010-08-04	3513185	\N	3518350	\N
3854693	GENERIC_DAY	0	0	f	2010-07-31	3513185	\N	3518350	\N
3854694	GENERIC_DAY	0	4	f	2010-08-11	3513185	\N	3518350	\N
3854695	GENERIC_DAY	0	4	f	2010-07-20	3513185	\N	3518350	\N
3854696	GENERIC_DAY	0	0	f	2010-08-07	3513185	\N	3518350	\N
3854697	GENERIC_DAY	0	0	f	2010-08-14	3513185	\N	3518350	\N
3854698	GENERIC_DAY	0	4	f	2010-07-30	3513185	\N	3518350	\N
3854699	GENERIC_DAY	0	0	f	2010-07-10	3513185	\N	3518350	\N
3854700	GENERIC_DAY	0	4	f	2010-08-19	3513185	\N	3518350	\N
3854701	GENERIC_DAY	0	4	f	2010-09-08	3513185	\N	3518350	\N
3854702	GENERIC_DAY	0	4	f	2010-07-14	3513185	\N	3518350	\N
3854703	GENERIC_DAY	0	0	f	2010-08-28	3513185	\N	3518350	\N
3854704	GENERIC_DAY	0	4	f	2010-09-03	3513185	\N	3518350	\N
3854705	GENERIC_DAY	0	4	f	2010-09-07	3513185	\N	3518350	\N
3854706	GENERIC_DAY	0	4	f	2010-09-06	3513185	\N	3518350	\N
3854707	GENERIC_DAY	0	0	f	2010-07-24	3513185	\N	3518350	\N
3854708	GENERIC_DAY	0	4	f	2010-08-05	3513185	\N	3518350	\N
3854709	GENERIC_DAY	0	0	f	2010-07-18	3513185	\N	3518350	\N
3854710	GENERIC_DAY	0	4	f	2010-08-27	3513185	\N	3518350	\N
3854711	GENERIC_DAY	0	0	f	2010-08-01	3513185	\N	3518350	\N
3854712	GENERIC_DAY	0	4	f	2010-07-19	3513185	\N	3518350	\N
3854713	GENERIC_DAY	0	4	f	2010-07-12	3513185	\N	3518350	\N
3854714	GENERIC_DAY	0	0	f	2010-08-08	3513185	\N	3518350	\N
3854715	GENERIC_DAY	0	4	f	2010-08-23	3513185	\N	3518350	\N
3854716	GENERIC_DAY	0	0	f	2010-08-15	3513185	\N	3518350	\N
3854717	GENERIC_DAY	0	4	f	2010-07-29	3513185	\N	3518350	\N
3854718	GENERIC_DAY	0	4	f	2010-09-09	3513185	\N	3518350	\N
3854719	GENERIC_DAY	0	4	f	2010-08-09	3513185	\N	3518350	\N
3854720	GENERIC_DAY	0	4	f	2010-08-24	3513185	\N	3518350	\N
3854721	GENERIC_DAY	0	4	f	2010-07-26	3513185	\N	3518350	\N
3854722	GENERIC_DAY	0	4	f	2010-07-28	3513185	\N	3518350	\N
3854723	GENERIC_DAY	0	0	f	2010-07-25	3513185	\N	3518350	\N
3854724	GENERIC_DAY	0	4	f	2010-08-10	3513185	\N	3518350	\N
3854725	GENERIC_DAY	0	4	f	2010-08-02	3513185	\N	3518350	\N
3854726	GENERIC_DAY	0	0	f	2010-07-11	3513185	\N	3518350	\N
3854727	GENERIC_DAY	0	4	f	2010-07-13	3513185	\N	3518350	\N
3854728	GENERIC_DAY	0	0	f	2010-07-17	3513185	\N	3518350	\N
3854729	GENERIC_DAY	0	4	f	2010-08-25	3513185	\N	3518350	\N
3854730	GENERIC_DAY	0	0	f	2010-08-22	3513185	\N	3518350	\N
3854731	GENERIC_DAY	0	4	f	2010-08-30	3513185	\N	3518350	\N
3854732	GENERIC_DAY	0	4	f	2010-08-18	3513185	\N	3518350	\N
3854733	GENERIC_DAY	0	4	f	2010-08-26	3513185	\N	3518350	\N
3854734	GENERIC_DAY	0	4	f	2010-08-06	3513185	\N	3518350	\N
3854735	GENERIC_DAY	0	4	f	2010-08-12	3513185	\N	3518350	\N
3854736	GENERIC_DAY	0	4	f	2010-07-21	3513185	\N	3518350	\N
3854737	GENERIC_DAY	0	4	f	2010-08-20	3513185	\N	3518350	\N
3854738	GENERIC_DAY	0	4	f	2010-07-22	3513185	\N	3518350	\N
3443265	GENERIC_DAY	2	8	\N	2010-06-01	39022	\N	2379862	\N
3443266	GENERIC_DAY	2	8	\N	2010-06-01	39015	\N	2379862	\N
3443272	GENERIC_DAY	2	8	\N	2010-06-21	39022	\N	2379862	\N
3443273	GENERIC_DAY	2	8	\N	2010-06-23	39015	\N	2379862	\N
3443283	GENERIC_DAY	2	8	\N	2010-06-11	39022	\N	2379862	\N
3443311	GENERIC_DAY	2	0	\N	2010-06-05	39022	\N	2379862	\N
3443314	GENERIC_DAY	2	8	\N	2010-06-17	39015	\N	2379862	\N
3443301	GENERIC_DAY	2	8	\N	2010-06-07	39015	\N	2379862	\N
3443284	GENERIC_DAY	2	8	\N	2010-06-17	39022	\N	2379862	\N
3443267	GENERIC_DAY	2	0	\N	2010-06-13	39015	\N	2379862	\N
3774333	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766828	\N
3774335	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766828	\N
3774352	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766828	\N
3774301	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766828	\N
3774349	GENERIC_DAY	7	1	\N	2010-06-17	3513197	\N	3766828	\N
3774323	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766828	\N
3774337	GENERIC_DAY	7	1	\N	2010-08-16	3513197	\N	3766828	\N
3774308	GENERIC_DAY	7	1	\N	2010-07-13	3513197	\N	3766828	\N
3774324	GENERIC_DAY	7	2	\N	2010-06-03	3513197	\N	3766828	\N
3774336	GENERIC_DAY	7	1	\N	2010-09-09	3513197	\N	3766828	\N
3774351	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766828	\N
3774304	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766828	\N
3774288	GENERIC_DAY	7	1	\N	2010-06-18	3513197	\N	3766828	\N
3774328	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766828	\N
3774342	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766828	\N
3774316	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766828	\N
3774334	GENERIC_DAY	7	1	\N	2010-06-21	3513197	\N	3766828	\N
3774353	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766828	\N
3774361	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766828	\N
3515167	GENERIC_DAY	29	1	\N	2010-06-21	3513187	\N	3511790	\N
3515130	GENERIC_DAY	29	1	\N	2010-07-16	3513187	\N	3511790	\N
3515161	GENERIC_DAY	29	1	\N	2010-07-28	3513187	\N	3511790	\N
3515152	GENERIC_DAY	29	1	\N	2010-06-08	3513187	\N	3511790	\N
3468748	GENERIC_DAY	3	5	\N	2010-05-12	1123	\N	24072	\N
3468749	GENERIC_DAY	3	15	\N	2010-05-19	1121	\N	24072	\N
3468750	GENERIC_DAY	3	6	\N	2010-05-10	1121	\N	24072	\N
3468751	GENERIC_DAY	3	9	\N	2010-05-08	1119	\N	24072	\N
3468752	GENERIC_DAY	3	4	\N	2010-05-11	1121	\N	24072	\N
3468753	GENERIC_DAY	3	15	\N	2010-05-19	1123	\N	24072	\N
3468754	GENERIC_DAY	3	14	\N	2010-05-21	1123	\N	24072	\N
3468755	GENERIC_DAY	3	5	\N	2010-05-12	1119	\N	24072	\N
3468756	GENERIC_DAY	3	10	\N	2010-05-07	1123	\N	24072	\N
3468757	GENERIC_DAY	3	15	\N	2010-05-18	1121	\N	24072	\N
3468758	GENERIC_DAY	3	10	\N	2010-05-07	1121	\N	24072	\N
3468759	GENERIC_DAY	3	11	\N	2010-05-14	1119	\N	24072	\N
3468760	GENERIC_DAY	3	11	\N	2010-05-14	1123	\N	24072	\N
3468761	GENERIC_DAY	3	9	\N	2010-05-07	1119	\N	24072	\N
3468762	GENERIC_DAY	3	16	\N	2010-05-16	1123	\N	24072	\N
3468763	GENERIC_DAY	3	16	\N	2010-05-16	1121	\N	24072	\N
3468764	GENERIC_DAY	3	16	\N	2010-05-18	1119	\N	24072	\N
3468765	GENERIC_DAY	3	14	\N	2010-05-20	1121	\N	24072	\N
3468766	GENERIC_DAY	3	8	\N	2010-05-09	1121	\N	24072	\N
3468767	GENERIC_DAY	3	9	\N	2010-05-08	1121	\N	24072	\N
3468768	GENERIC_DAY	3	4	\N	2010-05-11	1123	\N	24072	\N
3468769	GENERIC_DAY	3	5	\N	2010-05-12	1121	\N	24072	\N
3468770	GENERIC_DAY	3	11	\N	2010-05-14	1121	\N	24072	\N
3468771	GENERIC_DAY	3	7	\N	2010-05-13	1119	\N	24072	\N
3468772	GENERIC_DAY	3	7	\N	2010-05-10	1119	\N	24072	\N
3468773	GENERIC_DAY	3	7	\N	2010-05-13	1123	\N	24072	\N
3468774	GENERIC_DAY	3	9	\N	2010-05-09	1119	\N	24072	\N
3468775	GENERIC_DAY	3	15	\N	2010-05-15	1119	\N	24072	\N
3468776	GENERIC_DAY	3	14	\N	2010-05-15	1121	\N	24072	\N
3468777	GENERIC_DAY	3	9	\N	2010-05-08	1123	\N	24072	\N
3468778	GENERIC_DAY	3	14	\N	2010-05-15	1123	\N	24072	\N
3468779	GENERIC_DAY	3	14	\N	2010-05-21	1121	\N	24072	\N
3468780	GENERIC_DAY	3	7	\N	2010-05-10	1123	\N	24072	\N
3468781	GENERIC_DAY	3	14	\N	2010-05-21	1119	\N	24072	\N
3468782	GENERIC_DAY	3	5	\N	2010-05-11	1119	\N	24072	\N
3468783	GENERIC_DAY	3	14	\N	2010-05-20	1123	\N	24072	\N
3468784	GENERIC_DAY	3	8	\N	2010-05-13	1121	\N	24072	\N
3468785	GENERIC_DAY	3	15	\N	2010-05-18	1123	\N	24072	\N
3468786	GENERIC_DAY	3	14	\N	2010-05-20	1119	\N	24072	\N
3468787	GENERIC_DAY	3	8	\N	2010-05-09	1123	\N	24072	\N
3468788	GENERIC_DAY	3	16	\N	2010-05-16	1119	\N	24072	\N
3468789	GENERIC_DAY	3	15	\N	2010-05-19	1119	\N	24072	\N
3468790	GENERIC_DAY	3	0	\N	2010-05-16	1119	\N	24074	\N
3468791	GENERIC_DAY	3	0	\N	2010-05-15	1119	\N	24074	\N
3468792	GENERIC_DAY	3	14	\N	2010-05-10	1119	\N	24074	\N
3468793	GENERIC_DAY	3	14	\N	2010-05-18	1119	\N	24074	\N
3468794	GENERIC_DAY	3	15	\N	2010-05-12	1119	\N	24074	\N
3468795	GENERIC_DAY	3	14	\N	2010-05-13	1123	\N	24074	\N
3468796	GENERIC_DAY	3	0	\N	2010-05-08	1121	\N	24074	\N
3468797	GENERIC_DAY	3	0	\N	2010-05-15	1123	\N	24074	\N
3468798	GENERIC_DAY	3	0	\N	2010-05-16	1121	\N	24074	\N
3468799	GENERIC_DAY	3	14	\N	2010-05-11	1123	\N	24074	\N
3468800	GENERIC_DAY	3	0	\N	2010-05-15	1121	\N	24074	\N
3468801	GENERIC_DAY	3	14	\N	2010-05-18	1123	\N	24074	\N
3468802	GENERIC_DAY	3	0	\N	2010-05-09	1119	\N	24074	\N
3468803	GENERIC_DAY	3	15	\N	2010-05-10	1121	\N	24074	\N
3468804	GENERIC_DAY	3	14	\N	2010-05-11	1119	\N	24074	\N
3468805	GENERIC_DAY	3	14	\N	2010-05-18	1121	\N	24074	\N
3468806	GENERIC_DAY	3	0	\N	2010-05-08	1119	\N	24074	\N
3468807	GENERIC_DAY	3	0	\N	2010-05-09	1121	\N	24074	\N
3468808	GENERIC_DAY	3	15	\N	2010-05-13	1119	\N	24074	\N
3468809	GENERIC_DAY	3	15	\N	2010-05-11	1121	\N	24074	\N
3468810	GENERIC_DAY	3	14	\N	2010-05-07	1123	\N	24074	\N
3468811	GENERIC_DAY	3	14	\N	2010-05-12	1121	\N	24074	\N
3468812	GENERIC_DAY	3	15	\N	2010-05-14	1119	\N	24074	\N
3468813	GENERIC_DAY	3	15	\N	2010-05-07	1119	\N	24074	\N
3468814	GENERIC_DAY	3	14	\N	2010-05-14	1123	\N	24074	\N
3468815	GENERIC_DAY	3	0	\N	2010-05-08	1123	\N	24074	\N
3468816	GENERIC_DAY	3	14	\N	2010-05-14	1121	\N	24074	\N
3468817	GENERIC_DAY	3	14	\N	2010-05-07	1121	\N	24074	\N
3468818	GENERIC_DAY	3	0	\N	2010-05-09	1123	\N	24074	\N
3468819	GENERIC_DAY	3	14	\N	2010-05-12	1123	\N	24074	\N
3468820	GENERIC_DAY	3	14	\N	2010-05-10	1123	\N	24074	\N
3468821	GENERIC_DAY	3	0	\N	2010-05-16	1123	\N	24074	\N
3468822	GENERIC_DAY	3	14	\N	2010-05-13	1121	\N	24074	\N
3468823	GENERIC_DAY	3	0	\N	2010-05-23	1121	\N	24071	\N
3468824	GENERIC_DAY	3	0	\N	2010-05-23	1123	\N	24071	\N
3468825	GENERIC_DAY	3	8	\N	2010-05-24	1123	\N	24071	\N
3468826	GENERIC_DAY	3	8	\N	2010-05-24	1121	\N	24071	\N
3468827	GENERIC_DAY	3	0	\N	2010-05-22	1119	\N	24071	\N
3468828	GENERIC_DAY	3	0	\N	2010-05-23	1119	\N	24071	\N
3468829	GENERIC_DAY	3	8	\N	2010-05-24	1119	\N	24071	\N
3468830	GENERIC_DAY	3	0	\N	2010-05-22	1123	\N	24071	\N
3468831	GENERIC_DAY	3	0	\N	2010-05-22	1121	\N	24071	\N
3468832	GENERIC_DAY	3	1	\N	2010-05-27	1121	\N	2494211	\N
3468833	GENERIC_DAY	3	1	\N	2010-05-27	1123	\N	2494211	\N
3468834	GENERIC_DAY	3	3	\N	2010-05-31	1119	\N	2494211	\N
3468835	GENERIC_DAY	3	4	\N	2010-06-01	1121	\N	2494211	\N
3468836	GENERIC_DAY	3	2	\N	2010-05-25	1123	\N	2494211	\N
3468837	GENERIC_DAY	3	3	\N	2010-06-01	1123	\N	2494211	\N
3468838	GENERIC_DAY	3	4	\N	2010-05-31	1123	\N	2494211	\N
3468839	GENERIC_DAY	3	1	\N	2010-05-27	1119	\N	2494211	\N
3468840	GENERIC_DAY	3	1	\N	2010-05-25	1121	\N	2494211	\N
3468841	GENERIC_DAY	3	1	\N	2010-05-26	1121	\N	2494211	\N
3468842	GENERIC_DAY	3	3	\N	2010-05-28	1123	\N	2494211	\N
3468843	GENERIC_DAY	3	3	\N	2010-06-01	1119	\N	2494211	\N
3468844	GENERIC_DAY	3	3	\N	2010-05-31	1121	\N	2494211	\N
3468845	GENERIC_DAY	3	1	\N	2010-05-26	1123	\N	2494211	\N
3468846	GENERIC_DAY	3	3	\N	2010-05-28	1119	\N	2494211	\N
3468847	GENERIC_DAY	3	1	\N	2010-05-26	1119	\N	2494211	\N
3468848	GENERIC_DAY	3	1	\N	2010-05-25	1119	\N	2494211	\N
3468849	GENERIC_DAY	3	4	\N	2010-05-28	1121	\N	2494211	\N
3468850	GENERIC_DAY	3	0	\N	2010-06-06	1126	\N	2494212	\N
3468851	GENERIC_DAY	3	4	\N	2010-06-07	1126	\N	2494212	\N
3468852	GENERIC_DAY	3	2	\N	2010-06-04	1128	\N	2494212	\N
3468853	GENERIC_DAY	3	4	\N	2010-06-07	1130	\N	2494212	\N
3468854	GENERIC_DAY	3	0	\N	2010-06-05	1128	\N	2494212	\N
3468855	GENERIC_DAY	3	2	\N	2010-06-03	1128	\N	2494212	\N
3468856	GENERIC_DAY	3	4	\N	2010-06-07	1128	\N	2494212	\N
3468857	GENERIC_DAY	3	2	\N	2010-06-03	1130	\N	2494212	\N
3468858	GENERIC_DAY	3	2	\N	2010-06-02	1130	\N	2494212	\N
3468859	GENERIC_DAY	3	0	\N	2010-06-06	1128	\N	2494212	\N
3468860	GENERIC_DAY	3	0	\N	2010-06-05	1126	\N	2494212	\N
3468861	GENERIC_DAY	3	2	\N	2010-06-02	1128	\N	2494212	\N
3468862	GENERIC_DAY	3	2	\N	2010-06-04	1130	\N	2494212	\N
3468863	GENERIC_DAY	3	2	\N	2010-06-03	1126	\N	2494212	\N
3468864	GENERIC_DAY	3	2	\N	2010-06-04	1126	\N	2494212	\N
3468865	GENERIC_DAY	3	2	\N	2010-06-02	1126	\N	2494212	\N
3468866	GENERIC_DAY	3	0	\N	2010-06-06	1130	\N	2494212	\N
3468867	GENERIC_DAY	3	3	\N	2010-06-01	1126	\N	2494212	\N
3468868	GENERIC_DAY	3	4	\N	2010-06-01	1130	\N	2494212	\N
3468869	GENERIC_DAY	3	0	\N	2010-06-05	1130	\N	2494212	\N
3468870	GENERIC_DAY	3	3	\N	2010-06-01	1128	\N	2494212	\N
3468871	GENERIC_DAY	3	0	\N	2010-06-12	1130	\N	2494210	\N
3468872	GENERIC_DAY	3	3	\N	2010-06-14	1126	\N	2494210	\N
3468873	GENERIC_DAY	3	3	\N	2010-06-11	1130	\N	2494210	\N
3468874	GENERIC_DAY	3	2	\N	2010-06-11	1128	\N	2494210	\N
3468875	GENERIC_DAY	3	0	\N	2010-06-19	1128	\N	2494210	\N
3468876	GENERIC_DAY	3	2	\N	2010-06-15	1128	\N	2494210	\N
3468877	GENERIC_DAY	3	3	\N	2010-06-22	1130	\N	2494210	\N
3468878	GENERIC_DAY	3	3	\N	2010-06-15	1126	\N	2494210	\N
3468879	GENERIC_DAY	3	3	\N	2010-06-08	1128	\N	2494210	\N
3468880	GENERIC_DAY	3	2	\N	2010-06-16	1128	\N	2494210	\N
3468881	GENERIC_DAY	3	0	\N	2010-06-12	1126	\N	2494210	\N
3468882	GENERIC_DAY	3	2	\N	2010-06-10	1128	\N	2494210	\N
3468883	GENERIC_DAY	3	3	\N	2010-06-21	1130	\N	2494210	\N
3468884	GENERIC_DAY	3	3	\N	2010-06-17	1126	\N	2494210	\N
3468885	GENERIC_DAY	3	2	\N	2010-06-22	1128	\N	2494210	\N
3468886	GENERIC_DAY	3	3	\N	2010-06-15	1130	\N	2494210	\N
3468887	GENERIC_DAY	3	0	\N	2010-06-20	1130	\N	2494210	\N
3468888	GENERIC_DAY	3	0	\N	2010-06-13	1128	\N	2494210	\N
3468889	GENERIC_DAY	3	3	\N	2010-06-17	1130	\N	2494210	\N
3468890	GENERIC_DAY	3	3	\N	2010-06-16	1126	\N	2494210	\N
3468891	GENERIC_DAY	3	0	\N	2010-06-19	1126	\N	2494210	\N
3468892	GENERIC_DAY	3	3	\N	2010-06-11	1126	\N	2494210	\N
3468893	GENERIC_DAY	3	0	\N	2010-06-13	1130	\N	2494210	\N
3468894	GENERIC_DAY	3	3	\N	2010-06-14	1130	\N	2494210	\N
3468895	GENERIC_DAY	3	3	\N	2010-06-10	1130	\N	2494210	\N
3468896	GENERIC_DAY	3	2	\N	2010-06-09	1130	\N	2494210	\N
3468897	GENERIC_DAY	3	1	\N	2010-06-24	1126	\N	2494210	\N
3468898	GENERIC_DAY	3	0	\N	2010-06-19	1130	\N	2494210	\N
3468899	GENERIC_DAY	3	2	\N	2010-06-18	1128	\N	2494210	\N
3468900	GENERIC_DAY	3	3	\N	2010-06-22	1126	\N	2494210	\N
3468901	GENERIC_DAY	3	0	\N	2010-06-20	1128	\N	2494210	\N
3468902	GENERIC_DAY	3	0	\N	2010-06-12	1128	\N	2494210	\N
3468903	GENERIC_DAY	3	3	\N	2010-06-23	1126	\N	2494210	\N
3468904	GENERIC_DAY	3	1	\N	2010-06-24	1128	\N	2494210	\N
3468905	GENERIC_DAY	3	3	\N	2010-06-18	1126	\N	2494210	\N
3468906	GENERIC_DAY	3	2	\N	2010-06-24	1130	\N	2494210	\N
3468907	GENERIC_DAY	3	0	\N	2010-06-20	1126	\N	2494210	\N
3468908	GENERIC_DAY	3	3	\N	2010-06-18	1130	\N	2494210	\N
3468909	GENERIC_DAY	3	3	\N	2010-06-10	1126	\N	2494210	\N
3468910	GENERIC_DAY	3	3	\N	2010-06-21	1126	\N	2494210	\N
3468911	GENERIC_DAY	3	3	\N	2010-06-09	1128	\N	2494210	\N
3468912	GENERIC_DAY	3	0	\N	2010-06-13	1126	\N	2494210	\N
3468913	GENERIC_DAY	3	3	\N	2010-06-09	1126	\N	2494210	\N
3468914	GENERIC_DAY	3	3	\N	2010-06-16	1130	\N	2494210	\N
3468915	GENERIC_DAY	3	3	\N	2010-06-08	1126	\N	2494210	\N
3468916	GENERIC_DAY	3	2	\N	2010-06-17	1128	\N	2494210	\N
3468917	GENERIC_DAY	3	2	\N	2010-06-21	1128	\N	2494210	\N
3468918	GENERIC_DAY	3	2	\N	2010-06-08	1130	\N	2494210	\N
3468919	GENERIC_DAY	3	2	\N	2010-06-23	1128	\N	2494210	\N
3468920	GENERIC_DAY	3	3	\N	2010-06-23	1130	\N	2494210	\N
3468921	GENERIC_DAY	3	2	\N	2010-06-14	1128	\N	2494210	\N
3468922	SPECIFIC_DAY	3	8	\N	2010-06-28	1130	2494208	\N	\N
3468923	SPECIFIC_DAY	3	0	\N	2010-07-11	1130	2494208	\N	\N
3468924	SPECIFIC_DAY	3	8	\N	2010-07-15	1130	2494208	\N	\N
3468925	SPECIFIC_DAY	3	0	\N	2010-07-04	1130	2494208	\N	\N
3468926	SPECIFIC_DAY	3	4	\N	2010-07-20	1130	2494208	\N	\N
3468927	SPECIFIC_DAY	3	8	\N	2010-06-29	1130	2494208	\N	\N
3468928	SPECIFIC_DAY	3	8	\N	2010-07-08	1130	2494208	\N	\N
3468929	SPECIFIC_DAY	3	8	\N	2010-07-13	1130	2494208	\N	\N
3468930	SPECIFIC_DAY	3	8	\N	2010-07-19	1130	2494208	\N	\N
3468931	SPECIFIC_DAY	3	0	\N	2010-07-03	1130	2494208	\N	\N
3468932	SPECIFIC_DAY	3	8	\N	2010-06-30	1130	2494208	\N	\N
3468933	SPECIFIC_DAY	3	8	\N	2010-07-02	1130	2494208	\N	\N
3468934	SPECIFIC_DAY	3	8	\N	2010-07-06	1130	2494208	\N	\N
3468935	SPECIFIC_DAY	3	0	\N	2010-07-18	1130	2494208	\N	\N
3468936	SPECIFIC_DAY	3	8	\N	2010-07-14	1130	2494208	\N	\N
3468937	SPECIFIC_DAY	3	0	\N	2010-07-17	1130	2494208	\N	\N
3468938	SPECIFIC_DAY	3	8	\N	2010-07-05	1130	2494208	\N	\N
3468939	SPECIFIC_DAY	3	0	\N	2010-06-27	1130	2494208	\N	\N
3468940	SPECIFIC_DAY	3	8	\N	2010-07-01	1130	2494208	\N	\N
3468941	SPECIFIC_DAY	3	8	\N	2010-07-07	1130	2494208	\N	\N
3468942	SPECIFIC_DAY	3	8	\N	2010-07-16	1130	2494208	\N	\N
3468943	SPECIFIC_DAY	3	8	\N	2010-07-09	1130	2494208	\N	\N
3468944	SPECIFIC_DAY	3	8	\N	2010-06-25	1130	2494208	\N	\N
3468945	SPECIFIC_DAY	3	8	\N	2010-07-12	1130	2494208	\N	\N
3468946	SPECIFIC_DAY	3	0	\N	2010-06-26	1130	2494208	\N	\N
3468947	SPECIFIC_DAY	3	0	\N	2010-07-10	1130	2494208	\N	\N
3468948	SPECIFIC_DAY	3	8	\N	2010-07-20	1121	2494209	\N	\N
3468949	SPECIFIC_DAY	3	8	\N	2010-07-07	1121	2494209	\N	\N
3468950	SPECIFIC_DAY	3	8	\N	2010-06-25	1121	2494209	\N	\N
3468951	SPECIFIC_DAY	3	8	\N	2010-07-08	1121	2494209	\N	\N
3468952	SPECIFIC_DAY	3	8	\N	2010-07-22	1121	2494209	\N	\N
3468953	SPECIFIC_DAY	3	8	\N	2010-07-15	1121	2494209	\N	\N
3468954	SPECIFIC_DAY	3	8	\N	2010-06-28	1121	2494209	\N	\N
3468955	SPECIFIC_DAY	3	0	\N	2010-07-10	1121	2494209	\N	\N
3468956	SPECIFIC_DAY	3	8	\N	2010-07-01	1121	2494209	\N	\N
3468957	SPECIFIC_DAY	3	8	\N	2010-07-05	1121	2494209	\N	\N
3468958	SPECIFIC_DAY	3	8	\N	2010-07-16	1121	2494209	\N	\N
3468959	SPECIFIC_DAY	3	0	\N	2010-07-25	1121	2494209	\N	\N
3468960	SPECIFIC_DAY	3	8	\N	2010-07-21	1121	2494209	\N	\N
3468961	SPECIFIC_DAY	3	8	\N	2010-07-09	1121	2494209	\N	\N
3468962	SPECIFIC_DAY	3	8	\N	2010-07-06	1121	2494209	\N	\N
3468963	SPECIFIC_DAY	3	8	\N	2010-07-14	1121	2494209	\N	\N
3468964	SPECIFIC_DAY	3	0	\N	2010-07-24	1121	2494209	\N	\N
3468965	SPECIFIC_DAY	3	0	\N	2010-07-04	1121	2494209	\N	\N
3468966	SPECIFIC_DAY	3	0	\N	2010-06-27	1121	2494209	\N	\N
3468967	SPECIFIC_DAY	3	8	\N	2010-07-13	1121	2494209	\N	\N
3468968	SPECIFIC_DAY	3	8	\N	2010-07-12	1121	2494209	\N	\N
3468969	SPECIFIC_DAY	3	0	\N	2010-07-18	1121	2494209	\N	\N
3468970	SPECIFIC_DAY	3	0	\N	2010-07-03	1121	2494209	\N	\N
3468971	SPECIFIC_DAY	3	8	\N	2010-06-30	1121	2494209	\N	\N
3468972	SPECIFIC_DAY	3	2	\N	2010-07-26	1121	2494209	\N	\N
3468973	SPECIFIC_DAY	3	0	\N	2010-07-17	1121	2494209	\N	\N
3468974	SPECIFIC_DAY	3	8	\N	2010-07-19	1121	2494209	\N	\N
3468975	SPECIFIC_DAY	3	0	\N	2010-06-26	1121	2494209	\N	\N
3468976	SPECIFIC_DAY	3	8	\N	2010-07-23	1121	2494209	\N	\N
3468977	SPECIFIC_DAY	3	8	\N	2010-07-02	1121	2494209	\N	\N
3468978	SPECIFIC_DAY	3	8	\N	2010-06-29	1121	2494209	\N	\N
3468979	SPECIFIC_DAY	3	0	\N	2010-07-11	1121	2494209	\N	\N
3468980	GENERIC_DAY	3	0	\N	2010-07-31	1119	\N	2494207	\N
3468981	GENERIC_DAY	3	4	\N	2010-08-05	1119	\N	2494207	\N
3468982	GENERIC_DAY	3	0	\N	2010-08-01	1119	\N	2494207	\N
3468983	GENERIC_DAY	3	8	\N	2010-08-02	1119	\N	2494207	\N
3468984	GENERIC_DAY	3	8	\N	2010-07-27	1119	\N	2494207	\N
3468985	GENERIC_DAY	3	8	\N	2010-07-28	1119	\N	2494207	\N
3468986	GENERIC_DAY	3	8	\N	2010-07-30	1119	\N	2494207	\N
3468987	GENERIC_DAY	3	8	\N	2010-07-29	1119	\N	2494207	\N
3468988	GENERIC_DAY	3	8	\N	2010-08-03	1119	\N	2494207	\N
3468989	GENERIC_DAY	3	8	\N	2010-08-04	1119	\N	2494207	\N
3515104	GENERIC_DAY	29	1	\N	2010-06-18	3513187	\N	3511790	\N
3515151	GENERIC_DAY	29	1	\N	2010-09-22	3513187	\N	3511790	\N
3515165	GENERIC_DAY	29	1	\N	2010-07-09	3513187	\N	3511790	\N
3515111	GENERIC_DAY	29	1	\N	2010-09-02	3513187	\N	3511790	\N
3515131	GENERIC_DAY	29	1	\N	2010-06-15	3513187	\N	3511790	\N
3515113	GENERIC_DAY	29	1	\N	2010-06-01	3513187	\N	3511790	\N
3515153	GENERIC_DAY	29	1	\N	2010-06-04	3513187	\N	3511790	\N
3515108	GENERIC_DAY	29	1	\N	2010-07-01	3513187	\N	3511790	\N
3515107	GENERIC_DAY	29	1	\N	2010-07-21	3513187	\N	3511790	\N
3515116	GENERIC_DAY	29	1	\N	2010-06-28	3513187	\N	3511790	\N
3515145	GENERIC_DAY	29	1	\N	2010-06-24	3513187	\N	3511790	\N
3515138	GENERIC_DAY	29	1	\N	2010-06-17	3513187	\N	3511790	\N
3515164	GENERIC_DAY	29	1	\N	2010-07-20	3513187	\N	3511790	\N
3515158	GENERIC_DAY	29	1	\N	2010-06-23	3513187	\N	3511790	\N
3515147	GENERIC_DAY	29	1	\N	2010-07-14	3513187	\N	3511790	\N
3515115	GENERIC_DAY	29	1	\N	2010-06-03	3513187	\N	3511790	\N
3804943	GENERIC_DAY	4	8	\N	2010-09-17	3513193	\N	3766861	\N
3804948	GENERIC_DAY	4	8	\N	2010-09-21	3513193	\N	3766861	\N
3804957	GENERIC_DAY	4	8	\N	2010-09-08	3513193	\N	3766861	\N
3804950	GENERIC_DAY	4	8	\N	2010-09-23	3513193	\N	3766861	\N
3804961	GENERIC_DAY	4	8	\N	2010-09-20	3513193	\N	3766861	\N
3804945	GENERIC_DAY	4	8	\N	2010-09-22	3513193	\N	3766861	\N
3804962	GENERIC_DAY	4	0	\N	2010-09-25	3513193	\N	3766861	\N
3804951	GENERIC_DAY	4	8	\N	2010-09-09	3513193	\N	3766861	\N
3804944	GENERIC_DAY	4	0	\N	2010-09-26	3513193	\N	3766861	\N
3804952	GENERIC_DAY	4	8	\N	2010-09-24	3513193	\N	3766861	\N
3804954	GENERIC_DAY	4	8	\N	2010-09-27	3513193	\N	3766861	\N
3804947	GENERIC_DAY	4	0	\N	2010-09-11	3513193	\N	3766861	\N
3804949	GENERIC_DAY	4	0	\N	2010-09-12	3513193	\N	3766861	\N
3804959	GENERIC_DAY	4	0	\N	2010-09-18	3513193	\N	3766861	\N
3804958	GENERIC_DAY	4	8	\N	2010-09-13	3513193	\N	3766861	\N
3804960	GENERIC_DAY	4	8	\N	2010-09-15	3513193	\N	3766861	\N
3804956	GENERIC_DAY	4	8	\N	2010-09-07	3513193	\N	3766861	\N
3804953	GENERIC_DAY	4	8	\N	2010-09-10	3513193	\N	3766861	\N
3804946	GENERIC_DAY	4	0	\N	2010-09-19	3513193	\N	3766861	\N
3804955	GENERIC_DAY	4	8	\N	2010-09-14	3513193	\N	3766861	\N
3804963	GENERIC_DAY	4	8	\N	2010-09-16	3513193	\N	3766861	\N
3774833	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766834	\N
3774792	GENERIC_DAY	7	2	\N	2010-05-28	3513197	\N	3766834	\N
3774823	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766834	\N
3774879	GENERIC_DAY	7	2	\N	2010-06-28	3513197	\N	3766834	\N
3774863	GENERIC_DAY	7	2	\N	2010-06-03	3513197	\N	3766834	\N
3774838	GENERIC_DAY	7	2	\N	2010-06-07	3513197	\N	3766834	\N
3774814	GENERIC_DAY	7	2	\N	2010-06-02	3513197	\N	3766834	\N
3774841	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766834	\N
3774862	GENERIC_DAY	7	2	\N	2010-06-22	3513197	\N	3766834	\N
3774855	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766834	\N
3774822	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766834	\N
3774849	GENERIC_DAY	7	1	\N	2010-09-29	3513197	\N	3766834	\N
3774848	GENERIC_DAY	7	1	\N	2010-07-29	3513197	\N	3766834	\N
3774840	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766834	\N
3774851	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766834	\N
3774836	GENERIC_DAY	7	1	\N	2010-09-27	3513197	\N	3766834	\N
3774825	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766834	\N
3774806	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766834	\N
3774869	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766834	\N
3774826	GENERIC_DAY	7	1	\N	2010-09-10	3513197	\N	3766834	\N
3774835	GENERIC_DAY	7	2	\N	2010-06-17	3513197	\N	3766834	\N
3774798	GENERIC_DAY	7	2	\N	2010-06-15	3513197	\N	3766834	\N
3774872	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766834	\N
3774867	GENERIC_DAY	7	1	\N	2010-09-22	3513197	\N	3766834	\N
3774852	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766834	\N
3774815	GENERIC_DAY	7	2	\N	2010-05-31	3513197	\N	3766834	\N
3774805	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766834	\N
3774827	GENERIC_DAY	7	1	\N	2010-08-31	3513197	\N	3766834	\N
3774853	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766834	\N
3774854	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766834	\N
3774834	GENERIC_DAY	7	2	\N	2010-06-25	3513197	\N	3766834	\N
3774837	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766834	\N
3774794	GENERIC_DAY	7	2	\N	2010-06-23	3513197	\N	3766834	\N
3774821	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766834	\N
3774793	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766834	\N
3774800	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766834	\N
3774881	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766834	\N
3774844	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766834	\N
3774828	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766834	\N
3774832	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766834	\N
3520968	GENERIC_DAY	21	0	\N	2010-01-09	3513191	\N	3518384	\N
3520964	GENERIC_DAY	21	4	\N	2010-01-01	38991	\N	3518384	\N
3520969	GENERIC_DAY	21	0	\N	2010-01-03	38991	\N	3518384	\N
3520954	GENERIC_DAY	21	4	\N	2010-01-04	3513191	\N	3518384	\N
3520953	GENERIC_DAY	21	4	\N	2010-01-07	3513191	\N	3518384	\N
3520955	GENERIC_DAY	21	4	\N	2010-01-01	3513191	\N	3518384	\N
3520971	GENERIC_DAY	21	4	\N	2010-01-07	38991	\N	3518384	\N
3520951	GENERIC_DAY	21	0	\N	2010-01-03	3513191	\N	3518384	\N
3520966	GENERIC_DAY	21	4	\N	2010-01-11	38991	\N	3518384	\N
3520956	GENERIC_DAY	21	0	\N	2010-01-10	38991	\N	3518384	\N
3520958	GENERIC_DAY	21	4	\N	2010-01-05	38991	\N	3518384	\N
3520961	GENERIC_DAY	21	4	\N	2010-01-04	38991	\N	3518384	\N
3520957	GENERIC_DAY	21	4	\N	2010-01-11	3513191	\N	3518384	\N
3520962	GENERIC_DAY	21	0	\N	2010-01-10	3513191	\N	3518384	\N
3520959	GENERIC_DAY	21	4	\N	2010-01-05	3513191	\N	3518384	\N
3520963	GENERIC_DAY	21	4	\N	2010-01-08	3513191	\N	3518384	\N
3520967	GENERIC_DAY	21	0	\N	2010-01-09	38991	\N	3518384	\N
3520970	GENERIC_DAY	21	0	\N	2010-01-02	38991	\N	3518384	\N
3520965	GENERIC_DAY	21	0	\N	2010-01-02	3513191	\N	3518384	\N
3520972	GENERIC_DAY	21	4	\N	2010-01-08	38991	\N	3518384	\N
3520960	GENERIC_DAY	21	4	\N	2010-01-06	3513191	\N	3518384	\N
3520952	GENERIC_DAY	21	4	\N	2010-01-06	38991	\N	3518384	\N
3519480	GENERIC_DAY	24	2	\N	2010-01-06	38991	\N	3518352	\N
3519471	GENERIC_DAY	24	0	\N	2010-01-09	3513191	\N	3518352	\N
3519487	GENERIC_DAY	24	2	\N	2010-01-12	38991	\N	3518352	\N
3519486	GENERIC_DAY	24	2	\N	2010-01-07	3513191	\N	3518352	\N
3519491	GENERIC_DAY	24	2	\N	2010-01-07	38991	\N	3518352	\N
3519474	GENERIC_DAY	24	2	\N	2010-01-04	3513191	\N	3518352	\N
3519482	GENERIC_DAY	24	2	\N	2010-01-14	38991	\N	3518352	\N
3519470	GENERIC_DAY	24	0	\N	2010-01-03	3513191	\N	3518352	\N
3519472	GENERIC_DAY	24	2	\N	2010-01-04	38991	\N	3518352	\N
3519481	GENERIC_DAY	24	2	\N	2010-01-05	3513191	\N	3518352	\N
3519483	GENERIC_DAY	24	0	\N	2010-01-02	3513191	\N	3518352	\N
3519477	GENERIC_DAY	24	2	\N	2010-01-11	38991	\N	3518352	\N
3519479	GENERIC_DAY	24	2	\N	2010-01-11	3513191	\N	3518352	\N
3519492	GENERIC_DAY	24	0	\N	2010-01-10	3513191	\N	3518352	\N
3506298	GENERIC_DAY	4	10	\N	2010-05-19	3504499	\N	3505617	\N
3506295	GENERIC_DAY	4	2	\N	2010-05-18	3504499	\N	3505617	\N
3506294	GENERIC_DAY	4	4	\N	2010-05-22	3504499	\N	3505617	\N
3506297	GENERIC_DAY	4	4	\N	2010-05-21	3504499	\N	3505617	\N
3506296	GENERIC_DAY	4	9	\N	2010-05-20	3504499	\N	3505617	\N
3515141	GENERIC_DAY	29	1	\N	2010-07-15	3513187	\N	3511790	\N
3515132	GENERIC_DAY	29	1	\N	2010-07-30	3513187	\N	3511790	\N
3774355	GENERIC_DAY	7	2	\N	2010-06-04	3513197	\N	3766828	\N
3774292	GENERIC_DAY	7	1	\N	2010-09-13	3513197	\N	3766828	\N
3774326	GENERIC_DAY	7	1	\N	2010-08-25	3513197	\N	3766828	\N
3774320	GENERIC_DAY	7	2	\N	2010-06-15	3513197	\N	3766828	\N
3774360	GENERIC_DAY	7	1	\N	2010-09-07	3513197	\N	3766828	\N
3774346	GENERIC_DAY	7	2	\N	2010-05-27	3513197	\N	3766828	\N
3774305	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766828	\N
3774312	GENERIC_DAY	7	2	\N	2010-06-02	3513197	\N	3766828	\N
3774359	GENERIC_DAY	7	1	\N	2010-09-06	3513197	\N	3766828	\N
3774299	GENERIC_DAY	7	1	\N	2010-08-18	3513197	\N	3766828	\N
3774313	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766828	\N
3774283	GENERIC_DAY	7	2	\N	2010-06-10	3513197	\N	3766828	\N
3774329	GENERIC_DAY	7	1	\N	2010-07-30	3513197	\N	3766828	\N
3774300	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766828	\N
3774315	GENERIC_DAY	7	1	\N	2010-08-30	3513197	\N	3766828	\N
3774331	GENERIC_DAY	7	2	\N	2010-05-26	3513197	\N	3766828	\N
3774347	GENERIC_DAY	7	1	\N	2010-07-21	3513197	\N	3766828	\N
3774284	GENERIC_DAY	7	2	\N	2010-05-31	3513197	\N	3766828	\N
3774307	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766828	\N
3774350	GENERIC_DAY	7	1	\N	2010-06-30	3513197	\N	3766828	\N
3774293	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766828	\N
3774285	GENERIC_DAY	7	1	\N	2010-08-19	3513197	\N	3766828	\N
3774327	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766828	\N
3774348	GENERIC_DAY	7	1	\N	2010-08-17	3513197	\N	3766828	\N
3774317	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766828	\N
3774332	GENERIC_DAY	7	1	\N	2010-07-09	3513197	\N	3766828	\N
3774282	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766828	\N
3821715	GENERIC_DAY	3	8	\N	2010-08-02	3513195	\N	3819130	\N
3821716	GENERIC_DAY	3	8	\N	2010-07-26	3513195	\N	3819130	\N
3821720	GENERIC_DAY	3	8	\N	2010-08-03	3513195	\N	3819130	\N
3821722	GENERIC_DAY	3	0	\N	2010-07-24	3513195	\N	3819130	\N
3821726	GENERIC_DAY	3	8	\N	2010-08-05	3513195	\N	3819130	\N
3821723	GENERIC_DAY	3	8	\N	2010-07-28	3513195	\N	3819130	\N
3821719	GENERIC_DAY	3	8	\N	2010-07-27	3513195	\N	3819130	\N
3821721	GENERIC_DAY	3	0	\N	2010-07-31	3513195	\N	3819130	\N
3821718	GENERIC_DAY	3	8	\N	2010-07-30	3513195	\N	3819130	\N
3821725	GENERIC_DAY	3	8	\N	2010-08-04	3513195	\N	3819130	\N
3821727	GENERIC_DAY	3	0	\N	2010-07-25	3513195	\N	3819130	\N
3821714	GENERIC_DAY	3	8	\N	2010-07-29	3513195	\N	3819130	\N
3821717	GENERIC_DAY	3	8	\N	2010-07-23	3513195	\N	3819130	\N
3821724	GENERIC_DAY	3	0	\N	2010-08-01	3513195	\N	3819130	\N
3774716	GENERIC_DAY	7	1	\N	2010-08-27	3513197	\N	3766833	\N
3774743	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766833	\N
3774766	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766833	\N
3774744	GENERIC_DAY	7	1	\N	2010-07-23	3513197	\N	3766833	\N
3774755	GENERIC_DAY	7	1	\N	2010-06-25	3513197	\N	3766833	\N
3774784	GENERIC_DAY	7	1	\N	2010-07-27	3513197	\N	3766833	\N
3774786	GENERIC_DAY	7	1	\N	2010-07-08	3513197	\N	3766833	\N
3774738	GENERIC_DAY	7	1	\N	2010-06-29	3513197	\N	3766833	\N
3774768	GENERIC_DAY	7	1	\N	2010-07-07	3513197	\N	3766833	\N
3774750	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766833	\N
3774753	GENERIC_DAY	7	1	\N	2010-05-27	3513197	\N	3766833	\N
3774785	GENERIC_DAY	7	1	\N	2010-07-01	3513197	\N	3766833	\N
3774737	GENERIC_DAY	7	1	\N	2010-08-13	3513197	\N	3766833	\N
3774719	GENERIC_DAY	7	1	\N	2010-08-03	3513197	\N	3766833	\N
3774760	GENERIC_DAY	7	1	\N	2010-07-19	3513197	\N	3766833	\N
3774762	GENERIC_DAY	7	1	\N	2010-08-04	3513197	\N	3766833	\N
3774715	GENERIC_DAY	7	1	\N	2010-06-07	3513197	\N	3766833	\N
3774731	GENERIC_DAY	7	1	\N	2010-06-23	3513197	\N	3766833	\N
3774788	GENERIC_DAY	7	1	\N	2010-06-01	3513197	\N	3766833	\N
3774732	GENERIC_DAY	7	1	\N	2010-07-26	3513197	\N	3766833	\N
3774775	GENERIC_DAY	7	1	\N	2010-06-16	3513197	\N	3766833	\N
3774718	GENERIC_DAY	7	1	\N	2010-08-09	3513197	\N	3766833	\N
3507035	SPECIFIC_DAY	0	8	\N	2010-06-24	14343	3505621	\N	\N
3507036	SPECIFIC_DAY	0	0	\N	2010-06-27	14343	3505621	\N	\N
3507037	SPECIFIC_DAY	0	8	\N	2010-06-29	14343	3505621	\N	\N
3507038	SPECIFIC_DAY	0	0	\N	2010-06-26	14343	3505621	\N	\N
3507039	SPECIFIC_DAY	0	8	\N	2010-06-28	14343	3505621	\N	\N
3507040	SPECIFIC_DAY	0	8	\N	2010-06-25	14343	3505621	\N	\N
3507041	SPECIFIC_DAY	0	8	\N	2010-06-23	14343	3505621	\N	\N
3507042	GENERIC_DAY	0	0	\N	2010-06-27	39017	\N	3505623	\N
3507043	GENERIC_DAY	0	0	\N	2010-06-25	14345	\N	3505623	\N
3507044	GENERIC_DAY	0	0	\N	2010-06-29	39009	\N	3505623	\N
3507045	GENERIC_DAY	0	0	\N	2010-06-29	1132	\N	3505623	\N
3507046	GENERIC_DAY	0	0	\N	2010-06-23	38993	\N	3505623	\N
3507047	GENERIC_DAY	0	0	\N	2010-06-25	39015	\N	3505623	\N
3507048	GENERIC_DAY	0	0	\N	2010-06-24	38997	\N	3505623	\N
3507049	GENERIC_DAY	0	0	\N	2010-06-24	39009	\N	3505623	\N
3507050	GENERIC_DAY	0	0	\N	2010-06-26	39011	\N	3505623	\N
3507051	GENERIC_DAY	0	0	\N	2010-06-25	38993	\N	3505623	\N
3507052	GENERIC_DAY	0	0	\N	2010-06-24	1115	\N	3505623	\N
3507053	GENERIC_DAY	0	0	\N	2010-06-29	39001	\N	3505623	\N
3507054	GENERIC_DAY	0	0	\N	2010-06-27	1126	\N	3505623	\N
3507055	GENERIC_DAY	0	0	\N	2010-06-24	39020	\N	3505623	\N
3507056	GENERIC_DAY	0	0	\N	2010-06-26	1126	\N	3505623	\N
3507057	GENERIC_DAY	0	0	\N	2010-06-23	14343	\N	3505623	\N
3507058	GENERIC_DAY	0	0	\N	2010-06-24	38995	\N	3505623	\N
3507059	GENERIC_DAY	0	0	\N	2010-06-27	38999	\N	3505623	\N
3507060	GENERIC_DAY	0	0	\N	2010-06-26	39001	\N	3505623	\N
3507061	GENERIC_DAY	0	0	\N	2010-06-27	38991	\N	3505623	\N
3507062	GENERIC_DAY	0	0	\N	2010-06-23	39020	\N	3505623	\N
3507063	GENERIC_DAY	0	0	\N	2010-06-25	39013	\N	3505623	\N
3507064	GENERIC_DAY	0	0	\N	2010-06-27	38993	\N	3505623	\N
3507065	GENERIC_DAY	0	0	\N	2010-06-26	1136	\N	3505623	\N
3507066	GENERIC_DAY	0	0	\N	2010-06-29	1130	\N	3505623	\N
3507067	GENERIC_DAY	0	0	\N	2010-06-29	1134	\N	3505623	\N
3507068	GENERIC_DAY	0	0	\N	2010-06-28	38991	\N	3505623	\N
3507069	GENERIC_DAY	0	0	\N	2010-06-25	39022	\N	3505623	\N
3507070	GENERIC_DAY	0	0	\N	2010-06-28	38999	\N	3505623	\N
3507071	GENERIC_DAY	0	0	\N	2010-06-28	39020	\N	3505623	\N
3507072	GENERIC_DAY	0	0	\N	2010-06-25	39005	\N	3505623	\N
3507073	GENERIC_DAY	0	0	\N	2010-06-23	38999	\N	3505623	\N
3507074	GENERIC_DAY	0	0	\N	2010-06-25	1115	\N	3505623	\N
3507075	GENERIC_DAY	0	0	\N	2010-06-29	1119	\N	3505623	\N
3507076	GENERIC_DAY	0	0	\N	2010-06-25	38995	\N	3505623	\N
3507077	GENERIC_DAY	0	0	\N	2010-06-28	26463	\N	3505623	\N
3507078	GENERIC_DAY	0	0	\N	2010-06-23	1123	\N	3505623	\N
3507079	GENERIC_DAY	0	0	\N	2010-06-29	39015	\N	3505623	\N
3507080	GENERIC_DAY	0	0	\N	2010-06-23	1130	\N	3505623	\N
3507081	GENERIC_DAY	0	0	\N	2010-06-26	1130	\N	3505623	\N
3507082	GENERIC_DAY	0	0	\N	2010-06-24	1119	\N	3505623	\N
3507083	GENERIC_DAY	0	0	\N	2010-06-28	1126	\N	3505623	\N
3507084	GENERIC_DAY	0	0	\N	2010-06-28	1115	\N	3505623	\N
3507085	GENERIC_DAY	0	0	\N	2010-06-27	26463	\N	3505623	\N
3507086	GENERIC_DAY	0	0	\N	2010-06-25	1123	\N	3505623	\N
3507087	GENERIC_DAY	0	0	\N	2010-06-27	1134	\N	3505623	\N
3507088	GENERIC_DAY	0	0	\N	2010-06-27	39009	\N	3505623	\N
3507089	GENERIC_DAY	0	0	\N	2010-06-27	39001	\N	3505623	\N
3507090	GENERIC_DAY	0	0	\N	2010-06-23	14345	\N	3505623	\N
3507091	GENERIC_DAY	0	0	\N	2010-06-29	14343	\N	3505623	\N
3507092	GENERIC_DAY	0	0	\N	2010-06-27	39020	\N	3505623	\N
3507093	GENERIC_DAY	0	0	\N	2010-06-24	38999	\N	3505623	\N
3507094	GENERIC_DAY	0	0	\N	2010-06-24	39001	\N	3505623	\N
3507095	GENERIC_DAY	0	0	\N	2010-06-29	1123	\N	3505623	\N
3507096	GENERIC_DAY	0	0	\N	2010-06-25	39009	\N	3505623	\N
3507097	GENERIC_DAY	0	0	\N	2010-06-26	1113	\N	3505623	\N
3507098	GENERIC_DAY	0	0	\N	2010-06-24	39003	\N	3505623	\N
3507099	GENERIC_DAY	0	0	\N	2010-06-29	38987	\N	3505623	\N
3507100	GENERIC_DAY	0	0	\N	2010-06-29	38997	\N	3505623	\N
3507101	GENERIC_DAY	0	0	\N	2010-06-24	39022	\N	3505623	\N
3507102	GENERIC_DAY	0	0	\N	2010-06-26	1121	\N	3505623	\N
3507103	GENERIC_DAY	0	0	\N	2010-06-25	1119	\N	3505623	\N
3507104	GENERIC_DAY	0	0	\N	2010-06-29	1136	\N	3505623	\N
3507105	GENERIC_DAY	0	0	\N	2010-06-29	39003	\N	3505623	\N
3507106	GENERIC_DAY	0	0	\N	2010-06-24	1117	\N	3505623	\N
3507107	GENERIC_DAY	0	0	\N	2010-06-27	1119	\N	3505623	\N
3507108	GENERIC_DAY	0	0	\N	2010-06-26	38993	\N	3505623	\N
3507109	GENERIC_DAY	0	0	\N	2010-06-28	39013	\N	3505623	\N
3507110	GENERIC_DAY	0	0	\N	2010-06-27	39011	\N	3505623	\N
3507111	GENERIC_DAY	0	0	\N	2010-06-25	39001	\N	3505623	\N
3507112	GENERIC_DAY	0	0	\N	2010-06-26	39007	\N	3505623	\N
3507113	GENERIC_DAY	0	0	\N	2010-06-27	38995	\N	3505623	\N
3507114	GENERIC_DAY	0	0	\N	2010-06-23	38997	\N	3505623	\N
3507115	GENERIC_DAY	0	0	\N	2010-06-25	39020	\N	3505623	\N
3507116	GENERIC_DAY	0	0	\N	2010-06-23	39005	\N	3505623	\N
3507117	GENERIC_DAY	0	0	\N	2010-06-24	38993	\N	3505623	\N
3507118	GENERIC_DAY	0	0	\N	2010-06-24	1136	\N	3505623	\N
3507119	GENERIC_DAY	0	0	\N	2010-06-29	3504499	\N	3505623	\N
3507120	GENERIC_DAY	0	8	\N	2010-06-24	1113	\N	3505623	\N
3507121	GENERIC_DAY	0	0	\N	2010-06-23	1126	\N	3505623	\N
3507122	GENERIC_DAY	0	0	\N	2010-06-23	1115	\N	3505623	\N
3507123	GENERIC_DAY	0	0	\N	2010-06-28	1123	\N	3505623	\N
3507124	GENERIC_DAY	0	8	\N	2010-06-29	1113	\N	3505623	\N
3507125	GENERIC_DAY	0	0	\N	2010-06-24	38991	\N	3505623	\N
3507126	GENERIC_DAY	0	0	\N	2010-06-23	39015	\N	3505623	\N
3507127	GENERIC_DAY	0	0	\N	2010-06-23	38995	\N	3505623	\N
3507128	GENERIC_DAY	0	0	\N	2010-06-23	39009	\N	3505623	\N
3507129	GENERIC_DAY	0	0	\N	2010-06-26	39015	\N	3505623	\N
3507130	GENERIC_DAY	0	0	\N	2010-06-27	39007	\N	3505623	\N
3507131	GENERIC_DAY	0	0	\N	2010-06-25	38991	\N	3505623	\N
3507132	GENERIC_DAY	0	0	\N	2010-06-26	1115	\N	3505623	\N
3507133	GENERIC_DAY	0	0	\N	2010-06-27	39022	\N	3505623	\N
3507134	GENERIC_DAY	0	0	\N	2010-06-26	1117	\N	3505623	\N
3507135	GENERIC_DAY	0	0	\N	2010-06-26	39009	\N	3505623	\N
3507136	GENERIC_DAY	0	0	\N	2010-06-24	38987	\N	3505623	\N
3507137	GENERIC_DAY	0	0	\N	2010-06-23	39003	\N	3505623	\N
3507138	GENERIC_DAY	0	0	\N	2010-06-28	1134	\N	3505623	\N
3507139	GENERIC_DAY	0	0	\N	2010-06-25	39007	\N	3505623	\N
3507140	GENERIC_DAY	0	0	\N	2010-06-24	39013	\N	3505623	\N
3507141	GENERIC_DAY	0	0	\N	2010-06-26	38987	\N	3505623	\N
3507142	GENERIC_DAY	0	0	\N	2010-06-23	1119	\N	3505623	\N
3507143	GENERIC_DAY	0	0	\N	2010-06-28	39015	\N	3505623	\N
3507144	GENERIC_DAY	0	0	\N	2010-06-28	38987	\N	3505623	\N
3507145	GENERIC_DAY	0	0	\N	2010-06-25	1121	\N	3505623	\N
3507146	GENERIC_DAY	0	0	\N	2010-06-23	39001	\N	3505623	\N
3507147	GENERIC_DAY	0	0	\N	2010-06-29	39011	\N	3505623	\N
3507148	GENERIC_DAY	0	0	\N	2010-06-27	1123	\N	3505623	\N
3507149	GENERIC_DAY	0	0	\N	2010-06-28	39003	\N	3505623	\N
3507150	GENERIC_DAY	0	0	\N	2010-06-27	14345	\N	3505623	\N
3507151	GENERIC_DAY	0	0	\N	2010-06-23	39022	\N	3505623	\N
3507152	GENERIC_DAY	0	0	\N	2010-06-27	3504499	\N	3505623	\N
3507153	GENERIC_DAY	0	0	\N	2010-06-27	1113	\N	3505623	\N
3507154	GENERIC_DAY	0	0	\N	2010-06-28	1119	\N	3505623	\N
3507155	GENERIC_DAY	0	0	\N	2010-06-26	1134	\N	3505623	\N
3507156	GENERIC_DAY	0	0	\N	2010-06-23	1134	\N	3505623	\N
3507157	GENERIC_DAY	0	0	\N	2010-06-23	39013	\N	3505623	\N
3507158	GENERIC_DAY	0	0	\N	2010-06-29	26463	\N	3505623	\N
3507159	GENERIC_DAY	0	0	\N	2010-06-27	14343	\N	3505623	\N
3507160	GENERIC_DAY	0	0	\N	2010-06-27	39005	\N	3505623	\N
3507161	GENERIC_DAY	0	0	\N	2010-06-29	39022	\N	3505623	\N
3507162	GENERIC_DAY	0	0	\N	2010-06-23	38987	\N	3505623	\N
3507163	GENERIC_DAY	0	0	\N	2010-06-27	1136	\N	3505623	\N
3507164	GENERIC_DAY	0	0	\N	2010-06-24	26463	\N	3505623	\N
3507165	GENERIC_DAY	0	0	\N	2010-06-26	1119	\N	3505623	\N
3507166	GENERIC_DAY	0	0	\N	2010-06-25	1134	\N	3505623	\N
3507167	GENERIC_DAY	0	0	\N	2010-06-24	1134	\N	3505623	\N
3507168	GENERIC_DAY	0	0	\N	2010-06-29	14345	\N	3505623	\N
3507169	GENERIC_DAY	0	0	\N	2010-06-26	3504499	\N	3505623	\N
3507170	GENERIC_DAY	0	0	\N	2010-06-23	26463	\N	3505623	\N
3507171	GENERIC_DAY	0	0	\N	2010-06-26	39020	\N	3505623	\N
3507172	GENERIC_DAY	0	0	\N	2010-06-26	38995	\N	3505623	\N
3507173	GENERIC_DAY	0	0	\N	2010-06-24	1128	\N	3505623	\N
3507174	GENERIC_DAY	0	0	\N	2010-06-24	14345	\N	3505623	\N
3507175	GENERIC_DAY	0	0	\N	2010-06-28	1130	\N	3505623	\N
3507176	GENERIC_DAY	0	0	\N	2010-06-27	1117	\N	3505623	\N
3507177	GENERIC_DAY	0	0	\N	2010-06-29	1128	\N	3505623	\N
3507178	GENERIC_DAY	0	0	\N	2010-06-24	14343	\N	3505623	\N
3507179	GENERIC_DAY	0	0	\N	2010-06-27	39003	\N	3505623	\N
3507180	GENERIC_DAY	0	0	\N	2010-06-25	39011	\N	3505623	\N
3507181	GENERIC_DAY	0	0	\N	2010-06-25	1117	\N	3505623	\N
3507182	GENERIC_DAY	0	0	\N	2010-06-24	1130	\N	3505623	\N
3507183	GENERIC_DAY	0	0	\N	2010-06-25	39003	\N	3505623	\N
3507184	GENERIC_DAY	0	0	\N	2010-06-25	26463	\N	3505623	\N
3507185	GENERIC_DAY	0	8	\N	2010-06-23	1113	\N	3505623	\N
3507186	GENERIC_DAY	0	0	\N	2010-06-29	39017	\N	3505623	\N
3507187	GENERIC_DAY	0	0	\N	2010-06-29	38995	\N	3505623	\N
3507188	GENERIC_DAY	0	0	\N	2010-06-26	14343	\N	3505623	\N
3507189	GENERIC_DAY	0	0	\N	2010-06-28	1121	\N	3505623	\N
3507190	GENERIC_DAY	0	0	\N	2010-06-28	1117	\N	3505623	\N
3507191	GENERIC_DAY	0	0	\N	2010-06-28	38995	\N	3505623	\N
3507192	GENERIC_DAY	0	0	\N	2010-06-23	38991	\N	3505623	\N
3507193	GENERIC_DAY	0	0	\N	2010-06-27	39013	\N	3505623	\N
3507194	GENERIC_DAY	0	0	\N	2010-06-28	39017	\N	3505623	\N
3507195	GENERIC_DAY	0	0	\N	2010-06-28	39009	\N	3505623	\N
3507196	GENERIC_DAY	0	0	\N	2010-06-25	38999	\N	3505623	\N
3507197	GENERIC_DAY	0	0	\N	2010-06-28	39007	\N	3505623	\N
3507198	GENERIC_DAY	0	0	\N	2010-06-23	1128	\N	3505623	\N
3507199	GENERIC_DAY	0	0	\N	2010-06-24	39017	\N	3505623	\N
3507200	GENERIC_DAY	0	0	\N	2010-06-24	39015	\N	3505623	\N
3507201	GENERIC_DAY	0	0	\N	2010-06-25	1136	\N	3505623	\N
3507202	GENERIC_DAY	0	0	\N	2010-06-26	26463	\N	3505623	\N
3507203	GENERIC_DAY	0	0	\N	2010-06-28	3504499	\N	3505623	\N
3507204	GENERIC_DAY	0	0	\N	2010-06-27	1128	\N	3505623	\N
3507205	GENERIC_DAY	0	0	\N	2010-06-23	39007	\N	3505623	\N
3507206	GENERIC_DAY	0	0	\N	2010-06-25	1128	\N	3505623	\N
3507207	GENERIC_DAY	0	0	\N	2010-06-24	3504499	\N	3505623	\N
3507208	GENERIC_DAY	0	0	\N	2010-06-28	1132	\N	3505623	\N
3507209	GENERIC_DAY	0	0	\N	2010-06-29	38999	\N	3505623	\N
3507210	GENERIC_DAY	0	0	\N	2010-06-26	1123	\N	3505623	\N
3507211	GENERIC_DAY	0	0	\N	2010-06-28	38997	\N	3505623	\N
3507212	GENERIC_DAY	0	0	\N	2010-06-24	39007	\N	3505623	\N
3507213	GENERIC_DAY	0	0	\N	2010-06-29	1126	\N	3505623	\N
3507214	GENERIC_DAY	0	0	\N	2010-06-26	39013	\N	3505623	\N
3507215	GENERIC_DAY	0	0	\N	2010-06-28	39022	\N	3505623	\N
3507216	GENERIC_DAY	0	0	\N	2010-06-26	1128	\N	3505623	\N
3507217	GENERIC_DAY	0	0	\N	2010-06-28	14345	\N	3505623	\N
3507218	GENERIC_DAY	0	0	\N	2010-06-24	39011	\N	3505623	\N
3507219	GENERIC_DAY	0	0	\N	2010-06-23	39017	\N	3505623	\N
3507220	GENERIC_DAY	0	0	\N	2010-06-25	1130	\N	3505623	\N
3507221	GENERIC_DAY	0	0	\N	2010-06-28	1136	\N	3505623	\N
3507222	GENERIC_DAY	0	0	\N	2010-06-27	1121	\N	3505623	\N
3507223	GENERIC_DAY	0	0	\N	2010-06-28	38993	\N	3505623	\N
3507224	GENERIC_DAY	0	0	\N	2010-06-23	1117	\N	3505623	\N
3507225	GENERIC_DAY	0	0	\N	2010-06-27	1132	\N	3505623	\N
3507226	GENERIC_DAY	0	0	\N	2010-06-26	1132	\N	3505623	\N
3507227	GENERIC_DAY	0	0	\N	2010-06-29	1115	\N	3505623	\N
3507228	GENERIC_DAY	0	0	\N	2010-06-29	38993	\N	3505623	\N
3507229	GENERIC_DAY	0	8	\N	2010-06-28	1113	\N	3505623	\N
3507230	GENERIC_DAY	0	0	\N	2010-06-28	39005	\N	3505623	\N
3507231	GENERIC_DAY	0	0	\N	2010-06-25	39017	\N	3505623	\N
3507232	GENERIC_DAY	0	0	\N	2010-06-24	39005	\N	3505623	\N
3507233	GENERIC_DAY	0	0	\N	2010-06-25	1132	\N	3505623	\N
3507234	GENERIC_DAY	0	0	\N	2010-06-23	39011	\N	3505623	\N
3507235	GENERIC_DAY	0	0	\N	2010-06-26	39005	\N	3505623	\N
3507236	GENERIC_DAY	0	0	\N	2010-06-26	39003	\N	3505623	\N
3507237	GENERIC_DAY	0	0	\N	2010-06-29	39007	\N	3505623	\N
3507238	GENERIC_DAY	0	0	\N	2010-06-26	38991	\N	3505623	\N
3507239	GENERIC_DAY	0	0	\N	2010-06-25	3504499	\N	3505623	\N
3507240	GENERIC_DAY	0	0	\N	2010-06-26	14345	\N	3505623	\N
3507241	GENERIC_DAY	0	0	\N	2010-06-29	39013	\N	3505623	\N
3507242	GENERIC_DAY	0	0	\N	2010-06-24	1121	\N	3505623	\N
3507243	GENERIC_DAY	0	0	\N	2010-06-23	1136	\N	3505623	\N
3507244	GENERIC_DAY	0	0	\N	2010-06-29	39005	\N	3505623	\N
3507245	GENERIC_DAY	0	0	\N	2010-06-25	1126	\N	3505623	\N
3507246	GENERIC_DAY	0	0	\N	2010-06-24	1123	\N	3505623	\N
3507247	GENERIC_DAY	0	0	\N	2010-06-29	1121	\N	3505623	\N
3507248	GENERIC_DAY	0	0	\N	2010-06-26	38999	\N	3505623	\N
3507249	GENERIC_DAY	0	0	\N	2010-06-29	1117	\N	3505623	\N
3507250	GENERIC_DAY	0	0	\N	2010-06-27	1115	\N	3505623	\N
3507251	GENERIC_DAY	0	0	\N	2010-06-28	14343	\N	3505623	\N
3507252	GENERIC_DAY	0	0	\N	2010-06-24	1126	\N	3505623	\N
3507253	GENERIC_DAY	0	0	\N	2010-06-29	39020	\N	3505623	\N
3507254	GENERIC_DAY	0	0	\N	2010-06-27	39015	\N	3505623	\N
3507255	GENERIC_DAY	0	0	\N	2010-06-29	38991	\N	3505623	\N
3507256	GENERIC_DAY	0	0	\N	2010-06-25	38997	\N	3505623	\N
3507257	GENERIC_DAY	0	0	\N	2010-06-23	1132	\N	3505623	\N
3507258	GENERIC_DAY	0	0	\N	2010-06-28	39001	\N	3505623	\N
3507259	GENERIC_DAY	0	0	\N	2010-06-26	39017	\N	3505623	\N
3507260	GENERIC_DAY	0	0	\N	2010-06-23	3504499	\N	3505623	\N
3507261	GENERIC_DAY	0	0	\N	2010-06-27	38987	\N	3505623	\N
3507262	GENERIC_DAY	0	0	\N	2010-06-25	14343	\N	3505623	\N
3507263	GENERIC_DAY	0	0	\N	2010-06-28	1128	\N	3505623	\N
3507264	GENERIC_DAY	0	0	\N	2010-06-27	1130	\N	3505623	\N
3507265	GENERIC_DAY	0	0	\N	2010-06-26	38997	\N	3505623	\N
3507266	GENERIC_DAY	0	0	\N	2010-06-28	39011	\N	3505623	\N
3507267	GENERIC_DAY	0	0	\N	2010-06-24	1132	\N	3505623	\N
3507268	GENERIC_DAY	0	0	\N	2010-06-23	1121	\N	3505623	\N
3507269	GENERIC_DAY	0	0	\N	2010-06-26	39022	\N	3505623	\N
3507270	GENERIC_DAY	0	0	\N	2010-06-25	38987	\N	3505623	\N
3507271	GENERIC_DAY	0	0	\N	2010-06-27	38997	\N	3505623	\N
3507272	GENERIC_DAY	0	8	\N	2010-06-25	1113	\N	3505623	\N
3507273	GENERIC_DAY	0	3	\N	2010-06-23	1136	\N	3505622	\N
3507274	GENERIC_DAY	0	2	\N	2010-06-25	1132	\N	3505622	\N
3507275	GENERIC_DAY	0	2	\N	2010-06-29	1136	\N	3505622	\N
3507276	GENERIC_DAY	0	3	\N	2010-06-29	1132	\N	3505622	\N
3507277	GENERIC_DAY	0	3	\N	2010-06-28	1136	\N	3505622	\N
3507278	GENERIC_DAY	0	0	\N	2010-06-26	1136	\N	3505622	\N
3507279	GENERIC_DAY	0	3	\N	2010-06-29	1134	\N	3505622	\N
3507280	GENERIC_DAY	0	0	\N	2010-06-27	1134	\N	3505622	\N
3507281	GENERIC_DAY	0	2	\N	2010-06-28	1132	\N	3505622	\N
3507282	GENERIC_DAY	0	3	\N	2010-06-25	1136	\N	3505622	\N
3507283	GENERIC_DAY	0	2	\N	2010-06-23	1132	\N	3505622	\N
3507284	GENERIC_DAY	0	0	\N	2010-06-26	1132	\N	3505622	\N
3507285	GENERIC_DAY	0	0	\N	2010-06-27	1136	\N	3505622	\N
3507286	GENERIC_DAY	0	0	\N	2010-06-27	1132	\N	3505622	\N
3507287	GENERIC_DAY	0	3	\N	2010-06-28	1134	\N	3505622	\N
3507288	GENERIC_DAY	0	0	\N	2010-06-26	1134	\N	3505622	\N
3507289	GENERIC_DAY	0	3	\N	2010-06-24	1134	\N	3505622	\N
3507290	GENERIC_DAY	0	3	\N	2010-06-24	1136	\N	3505622	\N
3507291	GENERIC_DAY	0	2	\N	2010-06-24	1132	\N	3505622	\N
3507292	GENERIC_DAY	0	3	\N	2010-06-23	1134	\N	3505622	\N
3507293	GENERIC_DAY	0	3	\N	2010-06-25	1134	\N	3505622	\N
3519490	GENERIC_DAY	24	0	\N	2010-01-10	38991	\N	3518352	\N
3519485	GENERIC_DAY	24	0	\N	2010-01-02	38991	\N	3518352	\N
3519493	GENERIC_DAY	24	0	\N	2010-01-03	38991	\N	3518352	\N
3519496	GENERIC_DAY	24	2	\N	2010-01-01	3513191	\N	3518352	\N
3519473	GENERIC_DAY	24	2	\N	2010-01-01	38991	\N	3518352	\N
3519475	GENERIC_DAY	24	2	\N	2010-01-12	3513191	\N	3518352	\N
3519494	GENERIC_DAY	24	2	\N	2010-01-13	3513191	\N	3518352	\N
3519484	GENERIC_DAY	24	2	\N	2010-01-05	38991	\N	3518352	\N
3519478	GENERIC_DAY	24	0	\N	2010-01-09	38991	\N	3518352	\N
3519488	GENERIC_DAY	24	2	\N	2010-01-06	3513191	\N	3518352	\N
3519489	GENERIC_DAY	24	2	\N	2010-01-08	38991	\N	3518352	\N
3519469	GENERIC_DAY	24	2	\N	2010-01-13	38991	\N	3518352	\N
3519495	GENERIC_DAY	24	2	\N	2010-01-14	3513191	\N	3518352	\N
3519476	GENERIC_DAY	24	2	\N	2010-01-08	3513191	\N	3518352	\N
3442522	GENERIC_DAY	2	4	\N	2010-10-15	38997	\N	57180	\N
3442335	GENERIC_DAY	2	4	\N	2011-01-20	38997	\N	57180	\N
3442537	GENERIC_DAY	2	3	\N	2010-10-05	38997	\N	57180	\N
3442446	GENERIC_DAY	2	5	\N	2010-08-13	38993	\N	57180	\N
3442461	GENERIC_DAY	2	1	\N	2010-07-25	38993	\N	57180	\N
3442654	GENERIC_DAY	2	5	\N	2010-07-07	38993	\N	57180	\N
3442389	GENERIC_DAY	2	4	\N	2010-08-11	38997	\N	57180	\N
3442695	GENERIC_DAY	2	5	\N	2010-08-04	38993	\N	57180	\N
3442526	GENERIC_DAY	2	5	\N	2010-06-21	38993	\N	57180	\N
3442494	GENERIC_DAY	2	4	\N	2010-10-28	38993	\N	57180	\N
3442500	GENERIC_DAY	2	5	\N	2010-06-22	38993	\N	57180	\N
3442363	GENERIC_DAY	2	4	\N	2010-08-06	38997	\N	57180	\N
3442610	GENERIC_DAY	2	5	\N	2010-06-07	38993	\N	57180	\N
3442492	GENERIC_DAY	2	1	\N	2010-06-27	38993	\N	57180	\N
3442448	GENERIC_DAY	2	1	\N	2010-07-31	38993	\N	57180	\N
3442449	GENERIC_DAY	2	4	\N	2010-06-21	38997	\N	57180	\N
3442652	GENERIC_DAY	2	5	\N	2010-06-30	38993	\N	57180	\N
3442602	GENERIC_DAY	2	4	\N	2010-08-04	38997	\N	57180	\N
3442460	GENERIC_DAY	2	6	\N	2010-09-07	38993	\N	57180	\N
3442535	GENERIC_DAY	2	5	\N	2010-06-28	38993	\N	57180	\N
3442347	GENERIC_DAY	2	1	\N	2010-09-05	38993	\N	57180	\N
3442402	GENERIC_DAY	2	4	\N	2010-06-22	38997	\N	57180	\N
3442462	GENERIC_DAY	2	1	\N	2010-07-17	38993	\N	57180	\N
3442467	GENERIC_DAY	2	5	\N	2010-06-10	38993	\N	57180	\N
3442698	GENERIC_DAY	2	4	\N	2010-08-09	38997	\N	57180	\N
3442656	GENERIC_DAY	2	5	\N	2010-11-05	38993	\N	57180	\N
3442683	GENERIC_DAY	2	6	\N	2010-09-30	38993	\N	57180	\N
3442668	GENERIC_DAY	2	4	\N	2011-01-18	38997	\N	57180	\N
3442359	GENERIC_DAY	2	4	\N	2011-01-24	38993	\N	57180	\N
3442431	GENERIC_DAY	2	5	\N	2010-08-31	38993	\N	57180	\N
3442640	GENERIC_DAY	2	5	\N	2010-10-18	38993	\N	57180	\N
3442577	GENERIC_DAY	2	5	\N	2010-08-27	38993	\N	57180	\N
3442604	GENERIC_DAY	2	3	\N	2010-09-10	38997	\N	57180	\N
3442581	GENERIC_DAY	2	1	\N	2010-08-01	38993	\N	57180	\N
3442476	GENERIC_DAY	2	5	\N	2010-06-08	38993	\N	57180	\N
3442634	GENERIC_DAY	2	4	\N	2010-06-30	38997	\N	57180	\N
3442548	GENERIC_DAY	2	5	\N	2010-07-01	38993	\N	57180	\N
3442406	GENERIC_DAY	2	4	\N	2010-08-13	38997	\N	57180	\N
3442408	GENERIC_DAY	2	4	\N	2010-10-08	38997	\N	57180	\N
3442686	GENERIC_DAY	2	4	\N	2010-12-24	38993	\N	57180	\N
3442575	GENERIC_DAY	2	5	\N	2010-07-09	38993	\N	57180	\N
3442518	GENERIC_DAY	2	5	\N	2010-09-13	38993	\N	57180	\N
3442592	GENERIC_DAY	2	5	\N	2010-11-29	38993	\N	57180	\N
3442438	GENERIC_DAY	2	4	\N	2010-06-18	38997	\N	57180	\N
3442658	GENERIC_DAY	2	6	\N	2010-10-05	38993	\N	57180	\N
3442414	GENERIC_DAY	2	6	\N	2010-07-02	38993	\N	57180	\N
3442608	GENERIC_DAY	2	5	\N	2010-10-07	38993	\N	57180	\N
3442338	GENERIC_DAY	2	3	\N	2010-12-01	38997	\N	57180	\N
3442400	GENERIC_DAY	2	1	\N	2010-06-05	38993	\N	57180	\N
3442615	GENERIC_DAY	2	5	\N	2010-08-12	38993	\N	57180	\N
3442536	GENERIC_DAY	2	4	\N	2011-01-20	38993	\N	57180	\N
3442603	GENERIC_DAY	2	3	\N	2010-09-14	38997	\N	57180	\N
3442375	GENERIC_DAY	2	4	\N	2010-07-01	38997	\N	57180	\N
3442464	GENERIC_DAY	2	4	\N	2010-07-14	38997	\N	57180	\N
3442387	GENERIC_DAY	2	4	\N	2010-07-27	38997	\N	57180	\N
3442611	GENERIC_DAY	2	1	\N	2010-06-06	38993	\N	57180	\N
3442442	GENERIC_DAY	2	5	\N	2010-08-09	38993	\N	57180	\N
3442691	GENERIC_DAY	2	4	\N	2010-06-03	38997	\N	57180	\N
3442597	GENERIC_DAY	2	5	\N	2010-12-14	38993	\N	57180	\N
3442328	GENERIC_DAY	2	4	\N	2011-01-10	38997	\N	57180	\N
3442567	GENERIC_DAY	2	4	\N	2010-08-16	38997	\N	57180	\N
3442367	GENERIC_DAY	2	4	\N	2010-06-16	38997	\N	57180	\N
3442424	GENERIC_DAY	2	3	\N	2010-07-19	38997	\N	57180	\N
3442682	GENERIC_DAY	2	4	\N	2011-01-14	38997	\N	57180	\N
3442444	GENERIC_DAY	2	4	\N	2011-01-19	38997	\N	57180	\N
3442351	GENERIC_DAY	2	1	\N	2010-09-19	38993	\N	57180	\N
3442379	GENERIC_DAY	2	4	\N	2010-11-02	38997	\N	57180	\N
3442620	GENERIC_DAY	2	4	\N	2010-11-03	38993	\N	57180	\N
3442416	GENERIC_DAY	2	4	\N	2010-06-29	38997	\N	57180	\N
3442678	GENERIC_DAY	2	4	\N	2010-08-03	38997	\N	57180	\N
3442472	GENERIC_DAY	2	4	\N	2010-08-17	38997	\N	57180	\N
3442532	GENERIC_DAY	2	4	\N	2011-01-17	38997	\N	57180	\N
3442433	GENERIC_DAY	2	6	\N	2010-10-01	38993	\N	57180	\N
3442505	GENERIC_DAY	2	5	\N	2010-11-15	38993	\N	57180	\N
3442519	GENERIC_DAY	2	4	\N	2010-12-22	38993	\N	57180	\N
3442525	GENERIC_DAY	2	5	\N	2010-09-24	38993	\N	57180	\N
3442451	GENERIC_DAY	2	4	\N	2010-09-23	38997	\N	57180	\N
3442418	GENERIC_DAY	2	3	\N	2010-11-22	38997	\N	57180	\N
3442626	GENERIC_DAY	2	4	\N	2010-07-15	38997	\N	57180	\N
3442396	GENERIC_DAY	2	5	\N	2010-11-22	38993	\N	57180	\N
3442688	GENERIC_DAY	2	5	\N	2010-08-06	38993	\N	57180	\N
3442550	GENERIC_DAY	2	4	\N	2010-12-02	38997	\N	57180	\N
3442598	GENERIC_DAY	2	5	\N	2010-12-01	38993	\N	57180	\N
3442474	GENERIC_DAY	2	5	\N	2010-10-13	38993	\N	57180	\N
3442600	GENERIC_DAY	2	4	\N	2010-10-20	38997	\N	57180	\N
3442515	GENERIC_DAY	2	5	\N	2010-09-23	38993	\N	57180	\N
3442671	GENERIC_DAY	2	4	\N	2010-07-30	38997	\N	57180	\N
3442508	GENERIC_DAY	2	3	\N	2010-11-05	38997	\N	57180	\N
3442490	GENERIC_DAY	2	4	\N	2011-01-10	38993	\N	57180	\N
3442578	GENERIC_DAY	2	4	\N	2010-06-23	38997	\N	57180	\N
3442409	GENERIC_DAY	2	4	\N	2010-08-18	38997	\N	57180	\N
3442369	GENERIC_DAY	2	3	\N	2010-12-10	38997	\N	57180	\N
3442459	GENERIC_DAY	2	4	\N	2011-01-12	38993	\N	57180	\N
3442524	GENERIC_DAY	2	4	\N	2010-11-03	38997	\N	57180	\N
3442498	GENERIC_DAY	2	5	\N	2010-08-23	38993	\N	57180	\N
3442520	GENERIC_DAY	2	5	\N	2010-09-03	38993	\N	57180	\N
3442549	GENERIC_DAY	2	5	\N	2010-08-26	38993	\N	57180	\N
3442349	GENERIC_DAY	2	4	\N	2010-12-20	38997	\N	57180	\N
3442674	GENERIC_DAY	2	4	\N	2011-01-27	38997	\N	57180	\N
3442614	GENERIC_DAY	2	1	\N	2010-08-07	38993	\N	57180	\N
3442585	GENERIC_DAY	2	5	\N	2010-06-29	38993	\N	57180	\N
3442506	GENERIC_DAY	2	1	\N	2010-10-17	38993	\N	57180	\N
3442622	GENERIC_DAY	2	4	\N	2010-08-10	38997	\N	57180	\N
3442618	GENERIC_DAY	2	6	\N	2010-07-06	38993	\N	57180	\N
3442440	GENERIC_DAY	2	3	\N	2010-11-09	38997	\N	57180	\N
3442423	GENERIC_DAY	2	6	\N	2010-09-17	38993	\N	57180	\N
3442450	GENERIC_DAY	2	3	\N	2010-09-30	38997	\N	57180	\N
3442566	GENERIC_DAY	2	3	\N	2010-09-17	38997	\N	57180	\N
3442373	GENERIC_DAY	2	6	\N	2010-09-15	38993	\N	57180	\N
3442628	GENERIC_DAY	2	5	\N	2010-08-02	38993	\N	57180	\N
3442607	GENERIC_DAY	2	3	\N	2010-11-10	38997	\N	57180	\N
3442391	GENERIC_DAY	2	4	\N	2011-01-28	38997	\N	57180	\N
3442647	GENERIC_DAY	2	4	\N	2010-07-13	38997	\N	57180	\N
3442645	GENERIC_DAY	2	6	\N	2010-07-28	38993	\N	57180	\N
3442484	GENERIC_DAY	2	3	\N	2010-11-30	38997	\N	57180	\N
3442625	GENERIC_DAY	2	5	\N	2010-11-04	38993	\N	57180	\N
3442470	GENERIC_DAY	2	4	\N	2011-01-24	38997	\N	57180	\N
3442390	GENERIC_DAY	2	4	\N	2010-11-24	38997	\N	57180	\N
3442346	GENERIC_DAY	2	3	\N	2010-09-16	38997	\N	57180	\N
3442411	GENERIC_DAY	2	4	\N	2010-06-07	38997	\N	57180	\N
3442443	GENERIC_DAY	2	1	\N	2010-08-22	38993	\N	57180	\N
3442591	GENERIC_DAY	2	4	\N	2010-12-20	38993	\N	57180	\N
3442572	GENERIC_DAY	2	4	\N	2010-07-22	38997	\N	57180	\N
3442527	GENERIC_DAY	2	1	\N	2010-09-04	38993	\N	57180	\N
3442648	GENERIC_DAY	2	5	\N	2010-11-26	38993	\N	57180	\N
3442395	GENERIC_DAY	2	6	\N	2010-10-04	38993	\N	57180	\N
3442504	GENERIC_DAY	2	6	\N	2010-09-21	38993	\N	57180	\N
3442394	GENERIC_DAY	2	3	\N	2010-10-01	38997	\N	57180	\N
3442619	GENERIC_DAY	2	4	\N	2010-10-11	38997	\N	57180	\N
3442596	GENERIC_DAY	2	4	\N	2011-01-17	38993	\N	57180	\N
3442340	GENERIC_DAY	2	5	\N	2010-08-17	38993	\N	57180	\N
3442589	GENERIC_DAY	2	1	\N	2010-08-28	38993	\N	57180	\N
3442545	GENERIC_DAY	2	4	\N	2010-12-13	38997	\N	57180	\N
3442339	GENERIC_DAY	2	1	\N	2010-07-04	38993	\N	57180	\N
3442454	GENERIC_DAY	2	4	\N	2010-08-27	38997	\N	57180	\N
3442432	GENERIC_DAY	2	4	\N	2010-06-28	38997	\N	57180	\N
3442573	GENERIC_DAY	2	1	\N	2010-10-09	38993	\N	57180	\N
3442365	GENERIC_DAY	2	6	\N	2010-09-29	38993	\N	57180	\N
3442439	GENERIC_DAY	2	4	\N	2011-01-25	38997	\N	57180	\N
3442344	GENERIC_DAY	2	4	\N	2010-10-26	38993	\N	57180	\N
3442466	GENERIC_DAY	2	5	\N	2010-07-30	38993	\N	57180	\N
3442539	GENERIC_DAY	2	4	\N	2010-06-15	38997	\N	57180	\N
3442491	GENERIC_DAY	2	5	\N	2010-07-26	38993	\N	57180	\N
3442587	GENERIC_DAY	2	4	\N	2010-10-21	38993	\N	57180	\N
3442528	GENERIC_DAY	2	5	\N	2010-09-09	38993	\N	57180	\N
3442579	GENERIC_DAY	2	1	\N	2010-06-13	38993	\N	57180	\N
3442546	GENERIC_DAY	2	3	\N	2010-12-30	38997	\N	57180	\N
3442637	GENERIC_DAY	2	5	\N	2010-11-12	38993	\N	57180	\N
3442616	GENERIC_DAY	2	4	\N	2010-11-11	38993	\N	57180	\N
3442368	GENERIC_DAY	2	1	\N	2010-10-16	38993	\N	57180	\N
3442538	GENERIC_DAY	2	4	\N	2010-12-22	38997	\N	57180	\N
3442341	GENERIC_DAY	2	4	\N	2010-11-08	38993	\N	57180	\N
3442692	GENERIC_DAY	2	1	\N	2010-08-29	38993	\N	57180	\N
3442495	GENERIC_DAY	2	3	\N	2010-12-09	38997	\N	57180	\N
3442653	GENERIC_DAY	2	4	\N	2011-01-14	38993	\N	57180	\N
3442659	GENERIC_DAY	2	5	\N	2010-11-16	38993	\N	57180	\N
3442676	GENERIC_DAY	2	6	\N	2010-07-19	38993	\N	57180	\N
3442696	GENERIC_DAY	2	3	\N	2010-07-06	38997	\N	57180	\N
3442594	GENERIC_DAY	2	5	\N	2010-06-15	38993	\N	57180	\N
3442332	GENERIC_DAY	2	5	\N	2010-11-25	38993	\N	57180	\N
3442399	GENERIC_DAY	2	4	\N	2010-07-12	38997	\N	57180	\N
3442514	GENERIC_DAY	2	5	\N	2010-06-24	38993	\N	57180	\N
3442398	GENERIC_DAY	2	5	\N	2010-08-19	38993	\N	57180	\N
3442489	GENERIC_DAY	2	1	\N	2010-07-11	38993	\N	57180	\N
3442447	GENERIC_DAY	2	4	\N	2010-12-13	38993	\N	57180	\N
3442576	GENERIC_DAY	2	5	\N	2010-07-16	38997	\N	57180	\N
3442383	GENERIC_DAY	2	5	\N	2010-09-27	38993	\N	57180	\N
3442672	GENERIC_DAY	2	4	\N	2010-06-04	38997	\N	57180	\N
3442426	GENERIC_DAY	2	4	\N	2010-09-09	38997	\N	57180	\N
3442480	GENERIC_DAY	2	4	\N	2010-12-15	38993	\N	57180	\N
3442552	GENERIC_DAY	2	4	\N	2010-11-19	38997	\N	57180	\N
3442533	GENERIC_DAY	2	4	\N	2011-01-11	38997	\N	57180	\N
3442385	GENERIC_DAY	2	4	\N	2010-10-25	38993	\N	57180	\N
3442583	GENERIC_DAY	2	4	\N	2010-06-01	38997	\N	57180	\N
3442452	GENERIC_DAY	2	5	\N	2010-08-25	38993	\N	57180	\N
3442631	GENERIC_DAY	2	3	\N	2010-09-29	38997	\N	57180	\N
3442635	GENERIC_DAY	2	6	\N	2010-09-14	38993	\N	57180	\N
3442326	GENERIC_DAY	2	4	\N	2010-12-23	38997	\N	57180	\N
3442509	GENERIC_DAY	2	4	\N	2010-09-27	38997	\N	57180	\N
3442565	GENERIC_DAY	2	3	\N	2010-09-15	38997	\N	57180	\N
3442388	GENERIC_DAY	2	5	\N	2010-07-14	38993	\N	57180	\N
3442419	GENERIC_DAY	2	5	\N	2010-11-17	38993	\N	57180	\N
3442664	GENERIC_DAY	2	4	\N	2011-01-05	38993	\N	57180	\N
3442636	GENERIC_DAY	2	3	\N	2010-07-20	38997	\N	57180	\N
3442630	GENERIC_DAY	2	4	\N	2011-01-05	38997	\N	57180	\N
3442475	GENERIC_DAY	2	3	\N	2010-12-16	38997	\N	57180	\N
3442617	GENERIC_DAY	2	6	\N	2010-07-05	38993	\N	57180	\N
3442378	GENERIC_DAY	2	3	\N	2010-11-25	38997	\N	57180	\N
3442415	GENERIC_DAY	2	5	\N	2010-11-09	38993	\N	57180	\N
3442374	GENERIC_DAY	2	3	\N	2010-10-27	38997	\N	57180	\N
3442605	GENERIC_DAY	2	3	\N	2010-11-17	38997	\N	57180	\N
3442680	GENERIC_DAY	2	5	\N	2010-10-11	38993	\N	57180	\N
3442694	GENERIC_DAY	2	4	\N	2010-08-30	38997	\N	57180	\N
3442327	GENERIC_DAY	2	4	\N	2010-12-23	38993	\N	57180	\N
3442642	GENERIC_DAY	2	4	\N	2010-06-17	38997	\N	57180	\N
3442435	GENERIC_DAY	2	1	\N	2010-09-25	38993	\N	57180	\N
3442483	GENERIC_DAY	2	6	\N	2010-07-20	38993	\N	57180	\N
3442497	GENERIC_DAY	2	5	\N	2010-08-10	38993	\N	57180	\N
3442529	GENERIC_DAY	2	5	\N	2010-12-10	38993	\N	57180	\N
3442670	GENERIC_DAY	2	3	\N	2010-07-05	38997	\N	57180	\N
3442541	GENERIC_DAY	2	5	\N	2010-06-14	38993	\N	57180	\N
3442677	GENERIC_DAY	2	4	\N	2010-06-02	38997	\N	57180	\N
3442412	GENERIC_DAY	2	5	\N	2010-12-07	38993	\N	57180	\N
3442345	GENERIC_DAY	2	5	\N	2010-12-03	38993	\N	57180	\N
3442479	GENERIC_DAY	2	5	\N	2010-11-30	38993	\N	57180	\N
3442496	GENERIC_DAY	2	3	\N	2010-12-03	38997	\N	57180	\N
3442427	GENERIC_DAY	2	5	\N	2010-08-05	38993	\N	57180	\N
3442551	GENERIC_DAY	2	3	\N	2010-12-07	38997	\N	57180	\N
3442348	GENERIC_DAY	2	4	\N	2010-08-02	38997	\N	57180	\N
3442661	GENERIC_DAY	2	4	\N	2011-01-13	38993	\N	57180	\N
3442623	GENERIC_DAY	2	5	\N	2010-12-17	38993	\N	57180	\N
3442342	GENERIC_DAY	2	4	\N	2011-01-26	38997	\N	57180	\N
3442510	GENERIC_DAY	2	4	\N	2010-11-08	38997	\N	57180	\N
3442325	GENERIC_DAY	2	3	\N	2010-10-06	38997	\N	57180	\N
3442353	GENERIC_DAY	2	3	\N	2010-09-20	38997	\N	57180	\N
3442356	GENERIC_DAY	2	4	\N	2010-08-20	38997	\N	57180	\N
3442482	GENERIC_DAY	2	5	\N	2010-10-29	38993	\N	57180	\N
3442372	GENERIC_DAY	2	4	\N	2010-09-02	38997	\N	57180	\N
3442666	GENERIC_DAY	2	1	\N	2010-07-24	38993	\N	57180	\N
3442333	GENERIC_DAY	2	3	\N	2010-10-04	38997	\N	57180	\N
3442679	GENERIC_DAY	2	4	\N	2010-11-18	38993	\N	57180	\N
3442564	GENERIC_DAY	2	4	\N	2010-08-12	38997	\N	57180	\N
3442629	GENERIC_DAY	2	4	\N	2010-06-25	38997	\N	57180	\N
3442463	GENERIC_DAY	2	4	\N	2011-01-03	38993	\N	57180	\N
3442511	GENERIC_DAY	2	4	\N	2011-01-27	38993	\N	57180	\N
3442436	GENERIC_DAY	2	5	\N	2010-06-18	38993	\N	57180	\N
3442486	GENERIC_DAY	2	4	\N	2010-07-29	38997	\N	57180	\N
3442606	GENERIC_DAY	2	5	\N	2010-07-08	38993	\N	57180	\N
3442358	GENERIC_DAY	2	5	\N	2010-08-03	38993	\N	57180	\N
3442646	GENERIC_DAY	2	4	\N	2010-11-02	38993	\N	57180	\N
3442586	GENERIC_DAY	2	5	\N	2010-07-29	38993	\N	57180	\N
3442639	GENERIC_DAY	2	4	\N	2010-12-15	38997	\N	57180	\N
3442364	GENERIC_DAY	2	5	\N	2010-08-16	38993	\N	57180	\N
3442457	GENERIC_DAY	2	4	\N	2010-08-23	38997	\N	57180	\N
3442413	GENERIC_DAY	2	4	\N	2011-01-26	38993	\N	57180	\N
3442540	GENERIC_DAY	2	4	\N	2010-11-11	38997	\N	57180	\N
3442376	GENERIC_DAY	2	4	\N	2010-12-24	38997	\N	57180	\N
3442507	GENERIC_DAY	2	5	\N	2010-06-09	38993	\N	57180	\N
3442675	GENERIC_DAY	2	5	\N	2010-06-25	38993	\N	57180	\N
3442544	GENERIC_DAY	2	1	\N	2010-09-26	38993	\N	57180	\N
3442644	GENERIC_DAY	2	4	\N	2010-07-26	38997	\N	57180	\N
3442569	GENERIC_DAY	2	5	\N	2010-07-23	38993	\N	57180	\N
3442324	GENERIC_DAY	2	5	\N	2010-10-14	38997	\N	57180	\N
3442621	GENERIC_DAY	2	4	\N	2010-09-06	38997	\N	57180	\N
3442516	GENERIC_DAY	2	5	\N	2010-10-20	38993	\N	57180	\N
3442380	GENERIC_DAY	2	5	\N	2010-10-08	38993	\N	57180	\N
3442377	GENERIC_DAY	2	4	\N	2011-01-07	38997	\N	57180	\N
3442355	GENERIC_DAY	2	5	\N	2010-10-15	38993	\N	57180	\N
3442485	GENERIC_DAY	2	1	\N	2010-06-26	38993	\N	57180	\N
3442612	GENERIC_DAY	2	4	\N	2010-09-03	38997	\N	57180	\N
3442638	GENERIC_DAY	2	5	\N	2010-09-02	38993	\N	57180	\N
3442429	GENERIC_DAY	2	4	\N	2011-01-21	38993	\N	57180	\N
3442693	GENERIC_DAY	2	4	\N	2011-01-04	38993	\N	57180	\N
3442531	GENERIC_DAY	2	4	\N	2011-01-11	38993	\N	57180	\N
3442323	GENERIC_DAY	2	5	\N	2010-08-20	38993	\N	57180	\N
3442437	GENERIC_DAY	2	4	\N	2010-10-28	38997	\N	57180	\N
3442366	GENERIC_DAY	2	3	\N	2010-09-07	38997	\N	57180	\N
3442665	GENERIC_DAY	2	3	\N	2010-11-15	38997	\N	57180	\N
3442477	GENERIC_DAY	2	5	\N	2010-12-16	38993	\N	57180	\N
3442530	GENERIC_DAY	2	4	\N	2010-10-07	38997	\N	57180	\N
3442523	GENERIC_DAY	2	5	\N	2010-09-06	38993	\N	57180	\N
3442384	GENERIC_DAY	2	1	\N	2010-09-18	38993	\N	57180	\N
3442386	GENERIC_DAY	2	6	\N	2010-09-28	38993	\N	57180	\N
3442401	GENERIC_DAY	2	4	\N	2010-10-21	38997	\N	57180	\N
3442503	GENERIC_DAY	2	5	\N	2010-06-03	38993	\N	57180	\N
3442382	GENERIC_DAY	2	4	\N	2010-12-29	38997	\N	57180	\N
3442428	GENERIC_DAY	2	5	\N	2010-06-17	38993	\N	57180	\N
3442627	GENERIC_DAY	2	5	\N	2010-11-10	38993	\N	57180	\N
3442681	GENERIC_DAY	2	4	\N	2010-12-28	38993	\N	57180	\N
3442601	GENERIC_DAY	2	4	\N	2010-08-31	38997	\N	57180	\N
3442343	GENERIC_DAY	2	5	\N	2010-06-01	38993	\N	57180	\N
3442360	GENERIC_DAY	2	3	\N	2010-12-14	38997	\N	57180	\N
3442582	GENERIC_DAY	2	1	\N	2010-08-08	38993	\N	57180	\N
3442422	GENERIC_DAY	2	6	\N	2010-10-06	38993	\N	57180	\N
3442403	GENERIC_DAY	2	4	\N	2010-12-31	38993	\N	57180	\N
3442445	GENERIC_DAY	2	5	\N	2010-07-27	38993	\N	57180	\N
3442488	GENERIC_DAY	2	3	\N	2010-07-02	38997	\N	57180	\N
3442543	GENERIC_DAY	2	5	\N	2010-06-11	38993	\N	57180	\N
3442465	GENERIC_DAY	2	4	\N	2010-08-24	38997	\N	57180	\N
3442613	GENERIC_DAY	2	5	\N	2010-06-23	38993	\N	57180	\N
3442493	GENERIC_DAY	2	3	\N	2010-09-28	38997	\N	57180	\N
3442404	GENERIC_DAY	2	4	\N	2010-11-24	38993	\N	57180	\N
3442381	GENERIC_DAY	2	3	\N	2010-10-29	38997	\N	57180	\N
3442685	GENERIC_DAY	2	4	\N	2010-07-07	38997	\N	57180	\N
3442599	GENERIC_DAY	2	1	\N	2010-09-12	38993	\N	57180	\N
3442410	GENERIC_DAY	2	1	\N	2010-07-10	38993	\N	57180	\N
3442584	GENERIC_DAY	2	5	\N	2010-10-19	38993	\N	57180	\N
3442330	GENERIC_DAY	2	5	\N	2010-08-30	38993	\N	57180	\N
3442354	GENERIC_DAY	2	5	\N	2010-12-30	38993	\N	57180	\N
3442662	GENERIC_DAY	2	1	\N	2010-09-11	38993	\N	57180	\N
3442571	GENERIC_DAY	2	4	\N	2010-07-16	38993	\N	57180	\N
3442334	GENERIC_DAY	2	4	\N	2011-01-21	38997	\N	57180	\N
3442425	GENERIC_DAY	2	4	\N	2010-06-08	38997	\N	57180	\N
3442331	GENERIC_DAY	2	4	\N	2010-10-22	38993	\N	57180	\N
3442657	GENERIC_DAY	2	3	\N	2010-11-12	38997	\N	57180	\N
3442357	GENERIC_DAY	2	4	\N	2010-12-31	38997	\N	57180	\N
3442655	GENERIC_DAY	2	4	\N	2010-10-26	38997	\N	57180	\N
3442502	GENERIC_DAY	2	4	\N	2011-01-25	38993	\N	57180	\N
3442512	GENERIC_DAY	2	5	\N	2010-06-04	38993	\N	57180	\N
3442687	GENERIC_DAY	2	4	\N	2010-10-13	38997	\N	57180	\N
3442336	GENERIC_DAY	2	4	\N	2010-09-13	38997	\N	57180	\N
3442580	GENERIC_DAY	2	4	\N	2010-08-05	38997	\N	57180	\N
3442542	GENERIC_DAY	2	1	\N	2010-06-19	38993	\N	57180	\N
3442434	GENERIC_DAY	2	6	\N	2010-09-08	38993	\N	57180	\N
3442417	GENERIC_DAY	2	4	\N	2010-06-14	38997	\N	57180	\N
3442441	GENERIC_DAY	2	4	\N	2010-07-09	38997	\N	57180	\N
3442700	GENERIC_DAY	2	4	\N	2010-12-21	38997	\N	57180	\N
3442684	GENERIC_DAY	2	3	\N	2010-09-08	38997	\N	57180	\N
3442568	GENERIC_DAY	2	4	\N	2011-01-13	38997	\N	57180	\N
3442421	GENERIC_DAY	2	5	\N	2010-08-24	38993	\N	57180	\N
3442699	GENERIC_DAY	2	4	\N	2010-11-19	38993	\N	57180	\N
3442534	GENERIC_DAY	2	3	\N	2010-12-17	38997	\N	57180	\N
3442405	GENERIC_DAY	2	1	\N	2010-08-21	38993	\N	57180	\N
3442624	GENERIC_DAY	2	4	\N	2010-11-23	38993	\N	57180	\N
3442329	GENERIC_DAY	2	4	\N	2011-01-12	38997	\N	57180	\N
3442456	GENERIC_DAY	2	4	\N	2010-09-24	38997	\N	57180	\N
3442667	GENERIC_DAY	2	3	\N	2010-11-26	38997	\N	57180	\N
3442593	GENERIC_DAY	2	4	\N	2010-06-11	38997	\N	57180	\N
3442590	GENERIC_DAY	2	4	\N	2010-12-27	38997	\N	57180	\N
3442517	GENERIC_DAY	2	1	\N	2010-06-12	38993	\N	57180	\N
3442371	GENERIC_DAY	2	1	\N	2010-07-18	38993	\N	57180	\N
3442469	GENERIC_DAY	2	1	\N	2010-08-14	38993	\N	57180	\N
3442609	GENERIC_DAY	2	4	\N	2011-01-03	38997	\N	57180	\N
3442420	GENERIC_DAY	2	1	\N	2010-06-20	38993	\N	57180	\N
3442673	GENERIC_DAY	2	5	\N	2010-06-02	38993	\N	57180	\N
3442478	GENERIC_DAY	2	1	\N	2010-10-02	38993	\N	57180	\N
3442337	GENERIC_DAY	2	5	\N	2010-08-18	38993	\N	57180	\N
3442468	GENERIC_DAY	2	4	\N	2010-12-27	38993	\N	57180	\N
3442499	GENERIC_DAY	2	4	\N	2011-01-28	38993	\N	57180	\N
3442641	GENERIC_DAY	2	5	\N	2010-12-09	38993	\N	57180	\N
3519448	GENERIC_DAY	24	4	\N	2010-01-06	38991	\N	3518351	\N
3519462	GENERIC_DAY	24	0	\N	2010-01-09	38991	\N	3518351	\N
3519459	GENERIC_DAY	24	4	\N	2010-01-01	38991	\N	3518351	\N
3519457	GENERIC_DAY	24	0	\N	2010-01-09	3513191	\N	3518351	\N
3519463	GENERIC_DAY	24	4	\N	2010-01-08	3513191	\N	3518351	\N
3519455	GENERIC_DAY	24	0	\N	2010-01-10	38991	\N	3518351	\N
3519456	GENERIC_DAY	24	0	\N	2010-01-03	38991	\N	3518351	\N
3519465	GENERIC_DAY	24	4	\N	2010-01-11	38991	\N	3518351	\N
3519445	GENERIC_DAY	24	4	\N	2010-01-07	38991	\N	3518351	\N
3519452	GENERIC_DAY	24	4	\N	2010-01-08	38991	\N	3518351	\N
3519460	GENERIC_DAY	24	4	\N	2010-01-01	3513191	\N	3518351	\N
3519450	GENERIC_DAY	24	4	\N	2010-01-05	38991	\N	3518351	\N
3519454	GENERIC_DAY	24	0	\N	2010-01-10	3513191	\N	3518351	\N
3519449	GENERIC_DAY	24	0	\N	2010-01-03	3513191	\N	3518351	\N
3519458	GENERIC_DAY	24	4	\N	2010-01-11	3513191	\N	3518351	\N
3519467	GENERIC_DAY	24	4	\N	2010-01-04	3513191	\N	3518351	\N
3519468	GENERIC_DAY	24	0	\N	2010-01-02	3513191	\N	3518351	\N
3519461	GENERIC_DAY	24	4	\N	2010-01-04	38991	\N	3518351	\N
3519451	GENERIC_DAY	24	4	\N	2010-01-12	3513191	\N	3518351	\N
3519453	GENERIC_DAY	24	4	\N	2010-01-12	38991	\N	3518351	\N
3442555	GENERIC_DAY	2	4	\N	2010-09-22	38997	\N	57180	\N
3442558	GENERIC_DAY	2	4	\N	2010-11-23	38997	\N	57180	\N
3442560	GENERIC_DAY	2	4	\N	2011-01-18	38993	\N	57180	\N
3442557	GENERIC_DAY	2	3	\N	2010-07-28	38997	\N	57180	\N
3442562	GENERIC_DAY	2	1	\N	2010-10-03	38993	\N	57180	\N
3442561	GENERIC_DAY	2	5	\N	2010-07-13	38993	\N	57180	\N
3442554	GENERIC_DAY	2	4	\N	2010-08-26	38997	\N	57180	\N
3442559	GENERIC_DAY	2	4	\N	2010-06-09	38997	\N	57180	\N
3442556	GENERIC_DAY	2	4	\N	2010-10-19	38997	\N	57180	\N
3442563	GENERIC_DAY	2	6	\N	2010-09-10	38993	\N	57180	\N
3432787	GENERIC_DAY	2	3	\N	2010-12-14	39017	\N	57178	\N
3432539	GENERIC_DAY	2	3	\N	2010-10-01	39015	\N	57178	\N
3432845	GENERIC_DAY	2	3	\N	2010-07-06	39017	\N	57178	\N
3432543	GENERIC_DAY	2	3	\N	2010-08-19	39017	\N	57178	\N
3432635	GENERIC_DAY	2	3	\N	2011-01-26	39015	\N	57178	\N
3432626	GENERIC_DAY	2	3	\N	2010-08-04	39017	\N	57178	\N
3432773	GENERIC_DAY	2	3	\N	2010-09-14	39017	\N	57178	\N
3432737	GENERIC_DAY	2	3	\N	2010-10-25	39015	\N	57178	\N
3432753	GENERIC_DAY	2	3	\N	2010-07-28	39017	\N	57178	\N
3432550	GENERIC_DAY	2	3	\N	2010-07-21	39015	\N	57178	\N
3432812	GENERIC_DAY	2	3	\N	2010-12-03	39015	\N	57178	\N
3432613	GENERIC_DAY	2	3	\N	2010-12-27	39015	\N	57178	\N
3432637	GENERIC_DAY	2	1	\N	2010-06-25	39015	\N	57178	\N
3432601	GENERIC_DAY	2	3	\N	2010-10-19	39015	\N	57178	\N
3432618	GENERIC_DAY	2	3	\N	2010-09-20	39017	\N	57178	\N
3432709	GENERIC_DAY	2	3	\N	2010-12-30	39015	\N	57178	\N
3432634	GENERIC_DAY	2	3	\N	2010-09-07	39015	\N	57178	\N
3432856	GENERIC_DAY	2	3	\N	2010-07-09	39017	\N	57178	\N
3432619	GENERIC_DAY	2	2	\N	2011-01-20	39017	\N	57178	\N
3432538	GENERIC_DAY	2	3	\N	2010-07-13	39015	\N	57178	\N
3432655	GENERIC_DAY	2	3	\N	2010-10-21	39017	\N	57178	\N
3432727	GENERIC_DAY	2	3	\N	2011-01-25	39015	\N	57178	\N
3432843	GENERIC_DAY	2	3	\N	2010-07-20	39017	\N	57178	\N
3432611	GENERIC_DAY	2	3	\N	2010-07-30	39015	\N	57178	\N
3432598	GENERIC_DAY	2	3	\N	2010-09-06	39015	\N	57178	\N
3432817	GENERIC_DAY	2	3	\N	2010-08-20	39017	\N	57178	\N
3432752	GENERIC_DAY	2	3	\N	2010-07-06	39015	\N	57178	\N
3432757	GENERIC_DAY	2	3	\N	2010-09-06	39017	\N	57178	\N
3432579	GENERIC_DAY	2	3	\N	2010-11-03	39017	\N	57178	\N
3432769	GENERIC_DAY	2	3	\N	2010-09-07	39017	\N	57178	\N
3432667	GENERIC_DAY	2	3	\N	2010-07-15	39017	\N	57178	\N
3432805	GENERIC_DAY	2	2	\N	2011-01-26	39017	\N	57178	\N
3432784	GENERIC_DAY	2	3	\N	2011-01-11	39015	\N	57178	\N
3432759	GENERIC_DAY	2	3	\N	2010-09-03	39017	\N	57178	\N
3432852	GENERIC_DAY	2	2	\N	2011-01-21	39017	\N	57178	\N
3432840	GENERIC_DAY	2	3	\N	2010-07-21	39017	\N	57178	\N
3432640	GENERIC_DAY	2	3	\N	2011-01-19	39015	\N	57178	\N
3432676	GENERIC_DAY	2	3	\N	2010-11-22	39015	\N	57178	\N
3432623	GENERIC_DAY	2	3	\N	2010-07-28	39015	\N	57178	\N
3432777	GENERIC_DAY	2	3	\N	2010-06-29	39017	\N	57178	\N
3432664	GENERIC_DAY	2	3	\N	2010-07-26	39015	\N	57178	\N
3432720	GENERIC_DAY	2	3	\N	2010-10-14	39017	\N	57178	\N
3432555	GENERIC_DAY	2	3	\N	2010-11-19	39017	\N	57178	\N
3432636	GENERIC_DAY	2	3	\N	2010-11-26	39015	\N	57178	\N
3432839	GENERIC_DAY	2	6	\N	2010-06-24	39017	\N	57178	\N
3432589	GENERIC_DAY	2	3	\N	2010-06-30	39017	\N	57178	\N
3432600	GENERIC_DAY	2	6	\N	2010-06-17	39017	\N	57178	\N
3432848	GENERIC_DAY	2	3	\N	2010-12-16	39017	\N	57178	\N
3432832	GENERIC_DAY	2	3	\N	2011-01-10	39017	\N	57178	\N
3432690	GENERIC_DAY	2	3	\N	2010-07-07	39015	\N	57178	\N
3432562	GENERIC_DAY	2	3	\N	2010-08-27	39017	\N	57178	\N
3432617	GENERIC_DAY	2	3	\N	2010-09-29	39017	\N	57178	\N
3432697	GENERIC_DAY	2	3	\N	2010-11-11	39017	\N	57178	\N
3432837	GENERIC_DAY	2	3	\N	2011-01-05	39015	\N	57178	\N
3432644	GENERIC_DAY	2	3	\N	2010-06-29	39015	\N	57178	\N
3432768	GENERIC_DAY	2	3	\N	2010-10-25	39017	\N	57178	\N
3432681	GENERIC_DAY	2	3	\N	2011-01-24	39015	\N	57178	\N
3432725	GENERIC_DAY	2	3	\N	2010-08-03	39015	\N	57178	\N
3432793	GENERIC_DAY	2	3	\N	2010-09-21	39015	\N	57178	\N
3432607	GENERIC_DAY	2	3	\N	2010-09-17	39017	\N	57178	\N
3432668	GENERIC_DAY	2	3	\N	2010-10-14	39015	\N	57178	\N
3432672	GENERIC_DAY	2	3	\N	2010-12-10	39015	\N	57178	\N
3432764	GENERIC_DAY	2	3	\N	2010-11-22	39017	\N	57178	\N
3432614	GENERIC_DAY	2	3	\N	2010-10-01	39017	\N	57178	\N
3432669	GENERIC_DAY	2	3	\N	2010-07-13	39017	\N	57178	\N
3432810	GENERIC_DAY	2	3	\N	2010-07-01	39015	\N	57178	\N
3432682	GENERIC_DAY	2	3	\N	2010-08-24	39015	\N	57178	\N
3432762	GENERIC_DAY	2	3	\N	2010-08-25	39017	\N	57178	\N
3432609	GENERIC_DAY	2	2	\N	2011-01-18	39017	\N	57178	\N
3432540	GENERIC_DAY	2	3	\N	2010-11-23	39017	\N	57178	\N
3432750	GENERIC_DAY	2	3	\N	2010-11-09	39017	\N	57178	\N
3432545	GENERIC_DAY	2	3	\N	2010-07-29	39015	\N	57178	\N
3432675	GENERIC_DAY	2	3	\N	2010-10-26	39017	\N	57178	\N
3432552	GENERIC_DAY	2	3	\N	2011-01-04	39015	\N	57178	\N
3432692	GENERIC_DAY	2	3	\N	2010-08-12	39015	\N	57178	\N
3432591	GENERIC_DAY	2	3	\N	2010-08-06	39015	\N	57178	\N
3432573	GENERIC_DAY	2	3	\N	2011-01-28	39015	\N	57178	\N
3432542	GENERIC_DAY	2	3	\N	2010-11-23	39015	\N	57178	\N
3432648	GENERIC_DAY	2	3	\N	2010-09-24	39017	\N	57178	\N
3432734	GENERIC_DAY	2	3	\N	2010-08-16	39017	\N	57178	\N
3432561	GENERIC_DAY	2	3	\N	2010-08-13	39017	\N	57178	\N
3432820	GENERIC_DAY	2	3	\N	2010-12-07	39017	\N	57178	\N
3432828	GENERIC_DAY	2	3	\N	2010-07-01	39017	\N	57178	\N
3432541	GENERIC_DAY	2	3	\N	2010-08-05	39015	\N	57178	\N
3432696	GENERIC_DAY	2	3	\N	2010-08-10	39017	\N	57178	\N
3432596	GENERIC_DAY	2	3	\N	2010-08-23	39015	\N	57178	\N
3432711	GENERIC_DAY	2	3	\N	2010-07-19	39017	\N	57178	\N
3432716	GENERIC_DAY	2	3	\N	2010-09-16	39017	\N	57178	\N
3432743	GENERIC_DAY	2	3	\N	2010-11-08	39015	\N	57178	\N
3432621	GENERIC_DAY	2	3	\N	2010-12-31	39015	\N	57178	\N
3432706	GENERIC_DAY	2	3	\N	2010-08-17	39015	\N	57178	\N
3432729	GENERIC_DAY	2	3	\N	2010-08-11	39015	\N	57178	\N
3432774	GENERIC_DAY	2	3	\N	2011-01-04	39017	\N	57178	\N
3432719	GENERIC_DAY	2	2	\N	2011-01-12	39017	\N	57178	\N
3432808	GENERIC_DAY	2	3	\N	2010-12-21	39015	\N	57178	\N
3432578	GENERIC_DAY	2	3	\N	2010-07-20	39015	\N	57178	\N
3432620	GENERIC_DAY	2	3	\N	2010-08-02	39015	\N	57178	\N
3432707	GENERIC_DAY	2	3	\N	2010-10-29	39015	\N	57178	\N
3432645	GENERIC_DAY	2	3	\N	2010-12-24	39017	\N	57178	\N
3432701	GENERIC_DAY	2	6	\N	2010-06-10	39017	\N	57178	\N
3432835	GENERIC_DAY	2	3	\N	2010-07-08	39017	\N	57178	\N
3432595	GENERIC_DAY	2	3	\N	2010-09-27	39017	\N	57178	\N
3432570	GENERIC_DAY	2	3	\N	2010-12-01	39015	\N	57178	\N
3432728	GENERIC_DAY	2	3	\N	2010-07-12	39017	\N	57178	\N
3432605	GENERIC_DAY	2	6	\N	2010-06-23	39017	\N	57178	\N
3432638	GENERIC_DAY	2	3	\N	2010-08-17	39017	\N	57178	\N
3432829	GENERIC_DAY	2	3	\N	2010-10-04	39017	\N	57178	\N
3432813	GENERIC_DAY	2	3	\N	2010-09-03	39015	\N	57178	\N
3432714	GENERIC_DAY	2	3	\N	2010-09-24	39015	\N	57178	\N
3432612	GENERIC_DAY	2	3	\N	2011-01-21	39015	\N	57178	\N
3432568	GENERIC_DAY	2	3	\N	2010-07-30	39017	\N	57178	\N
3432723	GENERIC_DAY	2	3	\N	2010-12-22	39015	\N	57178	\N
3432782	GENERIC_DAY	2	3	\N	2010-12-28	39017	\N	57178	\N
3432754	GENERIC_DAY	2	3	\N	2010-10-27	39017	\N	57178	\N
3432802	GENERIC_DAY	2	6	\N	2010-06-11	39017	\N	57178	\N
3432658	GENERIC_DAY	2	3	\N	2010-09-22	39015	\N	57178	\N
3432602	GENERIC_DAY	2	3	\N	2010-12-02	39015	\N	57178	\N
3432571	GENERIC_DAY	2	3	\N	2010-12-17	39015	\N	57178	\N
3432563	GENERIC_DAY	2	3	\N	2010-10-13	39017	\N	57178	\N
3432653	GENERIC_DAY	2	3	\N	2010-07-22	39015	\N	57178	\N
3432557	GENERIC_DAY	2	3	\N	2010-11-04	39015	\N	57178	\N
3432684	GENERIC_DAY	2	3	\N	2010-09-10	39017	\N	57178	\N
3432800	GENERIC_DAY	2	3	\N	2010-09-23	39015	\N	57178	\N
3432657	GENERIC_DAY	2	3	\N	2010-09-22	39017	\N	57178	\N
3432740	GENERIC_DAY	2	3	\N	2010-06-30	39015	\N	57178	\N
3432733	GENERIC_DAY	2	3	\N	2010-08-05	39017	\N	57178	\N
3432760	GENERIC_DAY	2	3	\N	2010-12-20	39015	\N	57178	\N
3432632	GENERIC_DAY	2	3	\N	2010-08-26	39015	\N	57178	\N
3432665	GENERIC_DAY	2	3	\N	2010-09-30	39015	\N	57178	\N
3432702	GENERIC_DAY	2	6	\N	2010-06-01	39017	\N	57178	\N
3432592	GENERIC_DAY	2	3	\N	2011-01-07	39017	\N	57178	\N
3432670	GENERIC_DAY	2	3	\N	2010-08-02	39017	\N	57178	\N
3432730	GENERIC_DAY	2	3	\N	2010-12-23	39015	\N	57178	\N
3432811	GENERIC_DAY	2	3	\N	2010-10-15	39015	\N	57178	\N
3432593	GENERIC_DAY	2	3	\N	2010-11-05	39017	\N	57178	\N
3432587	GENERIC_DAY	2	6	\N	2010-06-09	39017	\N	57178	\N
3432560	GENERIC_DAY	2	3	\N	2010-12-03	39017	\N	57178	\N
3432577	GENERIC_DAY	2	3	\N	2010-10-22	39017	\N	57178	\N
3432625	GENERIC_DAY	2	3	\N	2010-10-04	39015	\N	57178	\N
3432715	GENERIC_DAY	2	3	\N	2010-08-16	39015	\N	57178	\N
3432608	GENERIC_DAY	2	3	\N	2010-08-20	39015	\N	57178	\N
3432651	GENERIC_DAY	2	3	\N	2010-08-09	39017	\N	57178	\N
3432650	GENERIC_DAY	2	3	\N	2010-10-19	39017	\N	57178	\N
3432789	GENERIC_DAY	2	6	\N	2010-06-02	39017	\N	57178	\N
3432678	GENERIC_DAY	2	3	\N	2010-08-18	39017	\N	57178	\N
3432771	GENERIC_DAY	2	3	\N	2010-09-01	39017	\N	57178	\N
3432649	GENERIC_DAY	2	3	\N	2010-08-27	39015	\N	57178	\N
3432628	GENERIC_DAY	2	3	\N	2010-08-04	39015	\N	57178	\N
3432798	GENERIC_DAY	2	3	\N	2010-09-29	39015	\N	57178	\N
3432666	GENERIC_DAY	2	3	\N	2010-09-09	39017	\N	57178	\N
3432606	GENERIC_DAY	2	3	\N	2010-08-13	39015	\N	57178	\N
3432778	GENERIC_DAY	2	3	\N	2011-01-10	39015	\N	57178	\N
3432824	GENERIC_DAY	2	3	\N	2010-12-15	39017	\N	57178	\N
3432801	GENERIC_DAY	2	2	\N	2011-01-25	39017	\N	57178	\N
3432594	GENERIC_DAY	2	3	\N	2010-07-02	39015	\N	57178	\N
3432549	GENERIC_DAY	2	3	\N	2010-10-11	39015	\N	57178	\N
3432842	GENERIC_DAY	2	3	\N	2010-08-03	39017	\N	57178	\N
3432703	GENERIC_DAY	2	3	\N	2010-09-08	39015	\N	57178	\N
3432603	GENERIC_DAY	2	3	\N	2010-11-25	39017	\N	57178	\N
3432726	GENERIC_DAY	2	3	\N	2010-11-16	39015	\N	57178	\N
3432766	GENERIC_DAY	2	2	\N	2011-01-24	39017	\N	57178	\N
3432850	GENERIC_DAY	2	3	\N	2010-09-27	39015	\N	57178	\N
3432772	GENERIC_DAY	2	3	\N	2010-09-13	39015	\N	57178	\N
3432751	GENERIC_DAY	2	3	\N	2010-07-05	39017	\N	57178	\N
3432654	GENERIC_DAY	2	3	\N	2010-12-28	39015	\N	57178	\N
3432814	GENERIC_DAY	2	3	\N	2010-10-26	39015	\N	57178	\N
3432663	GENERIC_DAY	2	3	\N	2010-08-12	39017	\N	57178	\N
3432585	GENERIC_DAY	2	3	\N	2010-11-03	39015	\N	57178	\N
3432641	GENERIC_DAY	2	3	\N	2010-12-17	39017	\N	57178	\N
3432830	GENERIC_DAY	2	3	\N	2010-10-20	39017	\N	57178	\N
3432627	GENERIC_DAY	2	3	\N	2010-11-18	39017	\N	57178	\N
3432584	GENERIC_DAY	2	3	\N	2010-12-01	39017	\N	57178	\N
3432700	GENERIC_DAY	2	3	\N	2011-01-20	39015	\N	57178	\N
3432705	GENERIC_DAY	2	3	\N	2010-12-23	39017	\N	57178	\N
3432799	GENERIC_DAY	2	3	\N	2010-08-06	39017	\N	57178	\N
3432747	GENERIC_DAY	2	3	\N	2011-01-13	39015	\N	57178	\N
3432731	GENERIC_DAY	2	3	\N	2010-09-28	39015	\N	57178	\N
3432849	GENERIC_DAY	2	3	\N	2010-06-28	39015	\N	57178	\N
3432718	GENERIC_DAY	2	3	\N	2010-11-12	39015	\N	57178	\N
3432677	GENERIC_DAY	2	2	\N	2011-01-28	39017	\N	57178	\N
3432763	GENERIC_DAY	2	3	\N	2010-11-16	39017	\N	57178	\N
3432685	GENERIC_DAY	2	3	\N	2010-08-10	39015	\N	57178	\N
3432826	GENERIC_DAY	2	6	\N	2010-06-04	39017	\N	57178	\N
3432717	GENERIC_DAY	2	3	\N	2010-08-31	39015	\N	57178	\N
3432816	GENERIC_DAY	2	3	\N	2010-09-01	39015	\N	57178	\N
3432547	GENERIC_DAY	2	3	\N	2010-09-23	39017	\N	57178	\N
3432776	GENERIC_DAY	2	2	\N	2011-01-17	39017	\N	57178	\N
3432646	GENERIC_DAY	2	6	\N	2010-06-16	39017	\N	57178	\N
3432785	GENERIC_DAY	2	5	\N	2010-06-25	39017	\N	57178	\N
3432566	GENERIC_DAY	2	3	\N	2010-09-02	39015	\N	57178	\N
3432673	GENERIC_DAY	2	3	\N	2010-09-13	39017	\N	57178	\N
3432775	GENERIC_DAY	2	3	\N	2010-10-29	39017	\N	57178	\N
3432544	GENERIC_DAY	2	3	\N	2010-12-13	39017	\N	57178	\N
3432631	GENERIC_DAY	2	3	\N	2010-09-02	39017	\N	57178	\N
3432551	GENERIC_DAY	2	3	\N	2010-10-18	39015	\N	57178	\N
3432674	GENERIC_DAY	2	3	\N	2010-11-25	39015	\N	57178	\N
3432597	GENERIC_DAY	2	6	\N	2010-06-03	39017	\N	57178	\N
3432807	GENERIC_DAY	2	6	\N	2010-06-07	39017	\N	57178	\N
3432558	GENERIC_DAY	2	3	\N	2010-12-07	39015	\N	57178	\N
3432662	GENERIC_DAY	2	3	\N	2010-12-30	39017	\N	57178	\N
3432687	GENERIC_DAY	2	3	\N	2010-07-09	39015	\N	57178	\N
3432857	GENERIC_DAY	2	2	\N	2011-01-19	39017	\N	57178	\N
3432721	GENERIC_DAY	2	3	\N	2010-09-16	39015	\N	57178	\N
3432821	GENERIC_DAY	2	3	\N	2010-10-28	39015	\N	57178	\N
3432809	GENERIC_DAY	2	3	\N	2010-12-13	39015	\N	57178	\N
3432693	GENERIC_DAY	2	3	\N	2010-10-13	39015	\N	57178	\N
3432704	GENERIC_DAY	2	3	\N	2010-10-06	39015	\N	57178	\N
3432790	GENERIC_DAY	2	2	\N	2011-01-11	39017	\N	57178	\N
3432804	GENERIC_DAY	2	3	\N	2010-11-17	39017	\N	57178	\N
3432736	GENERIC_DAY	2	3	\N	2010-07-19	39015	\N	57178	\N
3432851	GENERIC_DAY	2	3	\N	2011-01-03	39015	\N	57178	\N
3432823	GENERIC_DAY	2	3	\N	2010-11-18	39015	\N	57178	\N
3432741	GENERIC_DAY	2	3	\N	2011-01-27	39015	\N	57178	\N
3432735	GENERIC_DAY	2	3	\N	2011-01-05	39017	\N	57178	\N
3432574	GENERIC_DAY	2	3	\N	2011-01-12	39015	\N	57178	\N
3432622	GENERIC_DAY	2	3	\N	2010-09-15	39015	\N	57178	\N
3432818	GENERIC_DAY	2	3	\N	2010-09-30	39017	\N	57178	\N
3432770	GENERIC_DAY	2	3	\N	2010-12-16	39015	\N	57178	\N
3432710	GENERIC_DAY	2	3	\N	2010-08-31	39017	\N	57178	\N
3432761	GENERIC_DAY	2	3	\N	2010-10-27	39015	\N	57178	\N
3432791	GENERIC_DAY	2	2	\N	2011-01-13	39017	\N	57178	\N
3432831	GENERIC_DAY	2	3	\N	2010-11-04	39017	\N	57178	\N
3432656	GENERIC_DAY	2	3	\N	2010-07-26	39017	\N	57178	\N
3432546	GENERIC_DAY	2	3	\N	2010-11-30	39017	\N	57178	\N
3432806	GENERIC_DAY	2	3	\N	2010-08-19	39015	\N	57178	\N
3432647	GENERIC_DAY	2	3	\N	2011-01-03	39017	\N	57178	\N
3432688	GENERIC_DAY	2	2	\N	2011-01-14	39017	\N	57178	\N
3432586	GENERIC_DAY	2	3	\N	2010-07-12	39015	\N	57178	\N
3432699	GENERIC_DAY	2	3	\N	2010-10-08	39017	\N	57178	\N
3432581	GENERIC_DAY	2	3	\N	2010-09-20	39015	\N	57178	\N
3432756	GENERIC_DAY	2	3	\N	2010-12-21	39017	\N	57178	\N
3432724	GENERIC_DAY	2	3	\N	2010-11-26	39017	\N	57178	\N
3432780	GENERIC_DAY	2	3	\N	2010-10-05	39017	\N	57178	\N
3432836	GENERIC_DAY	2	3	\N	2010-07-15	39015	\N	57178	\N
3432712	GENERIC_DAY	2	3	\N	2010-08-18	39015	\N	57178	\N
3432767	GENERIC_DAY	2	3	\N	2010-10-06	39017	\N	57178	\N
3432783	GENERIC_DAY	2	3	\N	2010-12-27	39017	\N	57178	\N
3432588	GENERIC_DAY	2	3	\N	2010-10-18	39017	\N	57178	\N
3432844	GENERIC_DAY	2	3	\N	2010-07-29	39017	\N	57178	\N
3432765	GENERIC_DAY	2	3	\N	2010-11-30	39015	\N	57178	\N
3432629	GENERIC_DAY	2	3	\N	2010-10-05	39015	\N	57178	\N
3432680	GENERIC_DAY	2	6	\N	2010-06-18	39017	\N	57178	\N
3432686	GENERIC_DAY	2	3	\N	2010-09-08	39017	\N	57178	\N
3432689	GENERIC_DAY	2	3	\N	2010-12-29	39017	\N	57178	\N
3432834	GENERIC_DAY	2	3	\N	2010-12-29	39015	\N	57178	\N
3432792	GENERIC_DAY	2	3	\N	2010-07-16	39017	\N	57178	\N
3432683	GENERIC_DAY	2	3	\N	2010-09-28	39017	\N	57178	\N
3432746	GENERIC_DAY	2	3	\N	2010-09-09	39015	\N	57178	\N
3432630	GENERIC_DAY	2	3	\N	2010-10-07	39017	\N	57178	\N
3432846	GENERIC_DAY	2	3	\N	2010-10-20	39015	\N	57178	\N
3432738	GENERIC_DAY	2	3	\N	2010-11-11	39015	\N	57178	\N
3432713	GENERIC_DAY	2	3	\N	2010-11-02	39017	\N	57178	\N
3432838	GENERIC_DAY	2	3	\N	2010-08-11	39017	\N	57178	\N
3432659	GENERIC_DAY	2	3	\N	2010-11-19	39015	\N	57178	\N
3432815	GENERIC_DAY	2	3	\N	2010-09-21	39017	\N	57178	\N
3432583	GENERIC_DAY	2	3	\N	2010-07-02	39017	\N	57178	\N
3432755	GENERIC_DAY	2	3	\N	2010-08-24	39017	\N	57178	\N
3432652	GENERIC_DAY	2	3	\N	2010-09-10	39015	\N	57178	\N
3432819	GENERIC_DAY	2	3	\N	2010-11-10	39017	\N	57178	\N
3432847	GENERIC_DAY	2	3	\N	2010-08-25	39015	\N	57178	\N
3432779	GENERIC_DAY	2	3	\N	2010-11-09	39015	\N	57178	\N
3432854	GENERIC_DAY	2	3	\N	2011-01-14	39015	\N	57178	\N
3432788	GENERIC_DAY	2	3	\N	2010-12-24	39015	\N	57178	\N
3432732	GENERIC_DAY	2	3	\N	2010-07-22	39017	\N	57178	\N
3432556	GENERIC_DAY	2	3	\N	2010-11-08	39017	\N	57178	\N
3432744	GENERIC_DAY	2	3	\N	2010-11-15	39017	\N	57178	\N
3432565	GENERIC_DAY	2	3	\N	2010-07-27	39017	\N	57178	\N
3432691	GENERIC_DAY	2	6	\N	2010-06-21	39017	\N	57178	\N
3432803	GENERIC_DAY	2	3	\N	2010-12-20	39017	\N	57178	\N
3432708	GENERIC_DAY	2	3	\N	2010-09-15	39017	\N	57178	\N
3432739	GENERIC_DAY	2	3	\N	2010-11-15	39015	\N	57178	\N
3432671	GENERIC_DAY	2	3	\N	2010-07-27	39015	\N	57178	\N
3432624	GENERIC_DAY	2	3	\N	2010-10-15	39017	\N	57178	\N
3432795	GENERIC_DAY	2	3	\N	2010-11-17	39015	\N	57178	\N
3432575	GENERIC_DAY	2	3	\N	2010-08-09	39015	\N	57178	\N
3432661	GENERIC_DAY	2	3	\N	2010-10-08	39015	\N	57178	\N
3432827	GENERIC_DAY	2	3	\N	2010-08-30	39015	\N	57178	\N
3432559	GENERIC_DAY	2	3	\N	2010-07-14	39015	\N	57178	\N
3432853	GENERIC_DAY	2	3	\N	2010-11-10	39015	\N	57178	\N
3432822	GENERIC_DAY	2	6	\N	2010-06-14	39017	\N	57178	\N
3432794	GENERIC_DAY	2	3	\N	2010-10-28	39017	\N	57178	\N
3432567	GENERIC_DAY	2	3	\N	2010-10-21	39015	\N	57178	\N
3432599	GENERIC_DAY	2	3	\N	2010-08-30	39017	\N	57178	\N
3432694	GENERIC_DAY	2	3	\N	2010-07-23	39015	\N	57178	\N
3432722	GENERIC_DAY	2	3	\N	2010-09-17	39015	\N	57178	\N
3432642	GENERIC_DAY	2	3	\N	2010-07-23	39017	\N	57178	\N
3432643	GENERIC_DAY	2	3	\N	2010-12-09	39017	\N	57178	\N
3432615	GENERIC_DAY	2	6	\N	2010-06-08	39017	\N	57178	\N
3432576	GENERIC_DAY	2	3	\N	2010-10-11	39017	\N	57178	\N
3432825	GENERIC_DAY	2	3	\N	2010-11-05	39015	\N	57178	\N
3432796	GENERIC_DAY	2	3	\N	2010-07-16	39015	\N	57178	\N
3432748	GENERIC_DAY	2	3	\N	2010-12-14	39015	\N	57178	\N
3432580	GENERIC_DAY	2	3	\N	2011-01-07	39015	\N	57178	\N
3432786	GENERIC_DAY	2	6	\N	2010-06-22	39017	\N	57178	\N
3432841	GENERIC_DAY	2	3	\N	2010-07-14	39017	\N	57178	\N
3432745	GENERIC_DAY	2	3	\N	2010-07-05	39015	\N	57178	\N
3432833	GENERIC_DAY	2	2	\N	2011-01-27	39017	\N	57178	\N
3432855	GENERIC_DAY	2	3	\N	2010-11-12	39017	\N	57178	\N
3432633	GENERIC_DAY	2	3	\N	2010-10-22	39015	\N	57178	\N
3432749	GENERIC_DAY	2	3	\N	2010-11-24	39017	\N	57178	\N
3432742	GENERIC_DAY	2	3	\N	2010-08-26	39017	\N	57178	\N
3432564	GENERIC_DAY	2	3	\N	2010-11-29	39017	\N	57178	\N
3432610	GENERIC_DAY	2	3	\N	2010-07-08	39015	\N	57178	\N
3432639	GENERIC_DAY	2	3	\N	2010-11-29	39015	\N	57178	\N
3432604	GENERIC_DAY	2	3	\N	2010-07-07	39017	\N	57178	\N
3432569	GENERIC_DAY	2	3	\N	2010-08-23	39017	\N	57178	\N
3432572	GENERIC_DAY	2	3	\N	2010-12-10	39017	\N	57178	\N
3432698	GENERIC_DAY	2	3	\N	2010-06-28	39017	\N	57178	\N
3432553	GENERIC_DAY	2	3	\N	2010-12-22	39017	\N	57178	\N
3432797	GENERIC_DAY	2	3	\N	2010-12-09	39015	\N	57178	\N
3432679	GENERIC_DAY	2	3	\N	2011-01-17	39015	\N	57178	\N
3432660	GENERIC_DAY	2	3	\N	2010-12-02	39017	\N	57178	\N
3432616	GENERIC_DAY	2	3	\N	2010-10-07	39015	\N	57178	\N
3432582	GENERIC_DAY	2	3	\N	2010-12-15	39015	\N	57178	\N
3432695	GENERIC_DAY	2	6	\N	2010-06-15	39017	\N	57178	\N
3432590	GENERIC_DAY	2	3	\N	2011-01-18	39015	\N	57178	\N
3432554	GENERIC_DAY	2	3	\N	2010-09-14	39015	\N	57178	\N
3432758	GENERIC_DAY	2	3	\N	2010-12-31	39017	\N	57178	\N
3432781	GENERIC_DAY	2	3	\N	2010-11-02	39015	\N	57178	\N
3432548	GENERIC_DAY	2	3	\N	2010-11-24	39015	\N	57178	\N
3432531	GENERIC_DAY	2	8	\N	2010-08-04	39020	\N	57179	\N
3432527	GENERIC_DAY	2	8	\N	2010-09-07	39020	\N	57179	\N
3432493	GENERIC_DAY	2	8	\N	2010-10-15	39020	\N	57179	\N
3432476	GENERIC_DAY	2	8	\N	2010-09-14	39020	\N	57179	\N
3432457	GENERIC_DAY	2	7	\N	2011-01-12	39020	\N	57179	\N
3432504	GENERIC_DAY	2	7	\N	2010-12-23	39020	\N	57179	\N
3432519	GENERIC_DAY	2	8	\N	2010-11-09	39020	\N	57179	\N
3432474	GENERIC_DAY	2	7	\N	2011-01-03	39020	\N	57179	\N
3432501	GENERIC_DAY	2	8	\N	2010-06-10	39020	\N	57179	\N
3432426	GENERIC_DAY	2	8	\N	2010-07-09	39020	\N	57179	\N
3432385	GENERIC_DAY	2	7	\N	2011-01-07	39020	\N	57179	\N
3432442	GENERIC_DAY	2	8	\N	2010-10-27	39020	\N	57179	\N
3432533	GENERIC_DAY	2	8	\N	2010-10-21	39020	\N	57179	\N
3432460	GENERIC_DAY	2	7	\N	2011-01-28	39020	\N	57179	\N
3432529	GENERIC_DAY	2	8	\N	2010-09-15	39020	\N	57179	\N
3432486	GENERIC_DAY	2	8	\N	2010-07-06	39020	\N	57179	\N
3432499	GENERIC_DAY	2	8	\N	2010-09-30	39020	\N	57179	\N
3432494	GENERIC_DAY	2	8	\N	2010-06-09	39020	\N	57179	\N
3432447	GENERIC_DAY	2	7	\N	2010-11-24	39020	\N	57179	\N
3432451	GENERIC_DAY	2	7	\N	2010-12-03	39020	\N	57179	\N
3432537	GENERIC_DAY	2	8	\N	2010-08-13	39020	\N	57179	\N
3432536	GENERIC_DAY	2	8	\N	2010-10-22	39020	\N	57179	\N
3432444	GENERIC_DAY	2	7	\N	2010-11-17	39020	\N	57179	\N
3432445	GENERIC_DAY	2	8	\N	2010-10-11	39020	\N	57179	\N
3432477	GENERIC_DAY	2	8	\N	2010-07-02	39020	\N	57179	\N
3432511	GENERIC_DAY	2	8	\N	2010-08-09	39020	\N	57179	\N
3432420	GENERIC_DAY	2	8	\N	2010-09-21	39020	\N	57179	\N
3432526	GENERIC_DAY	2	7	\N	2010-12-14	39020	\N	57179	\N
3432485	GENERIC_DAY	2	8	\N	2010-07-08	39020	\N	57179	\N
3432454	GENERIC_DAY	2	8	\N	2010-11-02	39020	\N	57179	\N
3432509	GENERIC_DAY	2	8	\N	2010-08-11	39020	\N	57179	\N
3432381	GENERIC_DAY	2	7	\N	2010-11-19	39020	\N	57179	\N
3432369	GENERIC_DAY	2	8	\N	2010-06-02	39020	\N	57179	\N
3432525	GENERIC_DAY	2	8	\N	2010-08-03	39020	\N	57179	\N
3432417	GENERIC_DAY	2	8	\N	2010-10-05	39020	\N	57179	\N
3432373	GENERIC_DAY	2	7	\N	2010-11-30	39020	\N	57179	\N
3432448	GENERIC_DAY	2	7	\N	2010-12-10	39020	\N	57179	\N
3432452	GENERIC_DAY	2	8	\N	2010-06-04	39020	\N	57179	\N
3432466	GENERIC_DAY	2	8	\N	2010-06-14	39020	\N	57179	\N
3432392	GENERIC_DAY	2	7	\N	2010-12-02	39020	\N	57179	\N
3432462	GENERIC_DAY	2	8	\N	2010-09-17	39020	\N	57179	\N
3432506	GENERIC_DAY	2	8	\N	2010-09-02	39020	\N	57179	\N
3432414	GENERIC_DAY	2	7	\N	2010-11-15	39020	\N	57179	\N
3432521	GENERIC_DAY	2	8	\N	2010-06-16	39020	\N	57179	\N
3432430	GENERIC_DAY	2	7	\N	2010-12-15	39020	\N	57179	\N
3432402	GENERIC_DAY	2	7	\N	2010-11-23	39020	\N	57179	\N
3432421	GENERIC_DAY	2	8	\N	2010-09-16	39020	\N	57179	\N
3432478	GENERIC_DAY	2	7	\N	2011-01-24	39020	\N	57179	\N
3432428	GENERIC_DAY	2	8	\N	2010-09-06	39020	\N	57179	\N
3432490	GENERIC_DAY	2	7	\N	2010-12-20	39020	\N	57179	\N
3432374	GENERIC_DAY	2	8	\N	2010-11-08	39020	\N	57179	\N
3432397	GENERIC_DAY	2	8	\N	2010-07-23	39020	\N	57179	\N
3432514	GENERIC_DAY	2	7	\N	2011-01-14	39020	\N	57179	\N
3432446	GENERIC_DAY	2	8	\N	2010-11-05	39020	\N	57179	\N
3432371	GENERIC_DAY	2	8	\N	2010-08-06	39020	\N	57179	\N
3432424	GENERIC_DAY	2	7	\N	2010-11-16	39020	\N	57179	\N
3432415	GENERIC_DAY	2	7	\N	2011-01-18	39020	\N	57179	\N
3432429	GENERIC_DAY	2	8	\N	2010-07-26	39020	\N	57179	\N
3432517	GENERIC_DAY	2	8	\N	2010-10-04	39020	\N	57179	\N
3432471	GENERIC_DAY	2	8	\N	2010-07-14	39020	\N	57179	\N
3432450	GENERIC_DAY	2	8	\N	2010-10-06	39020	\N	57179	\N
3432465	GENERIC_DAY	2	7	\N	2010-12-27	39020	\N	57179	\N
3432384	GENERIC_DAY	2	8	\N	2010-09-20	39020	\N	57179	\N
3432458	GENERIC_DAY	2	8	\N	2010-08-23	39020	\N	57179	\N
3432520	GENERIC_DAY	2	8	\N	2010-06-29	39020	\N	57179	\N
3432475	GENERIC_DAY	2	7	\N	2011-01-20	39020	\N	57179	\N
3432482	GENERIC_DAY	2	8	\N	2010-10-19	39020	\N	57179	\N
3432443	GENERIC_DAY	2	7	\N	2011-01-26	39020	\N	57179	\N
3432391	GENERIC_DAY	2	8	\N	2010-06-23	39020	\N	57179	\N
3432472	GENERIC_DAY	2	8	\N	2010-08-12	39020	\N	57179	\N
3432378	GENERIC_DAY	2	8	\N	2010-07-19	39020	\N	57179	\N
3432393	GENERIC_DAY	2	8	\N	2010-07-12	39020	\N	57179	\N
3432427	GENERIC_DAY	2	8	\N	2010-08-18	39020	\N	57179	\N
3432432	GENERIC_DAY	2	8	\N	2010-07-01	39020	\N	57179	\N
3432390	GENERIC_DAY	2	7	\N	2011-01-19	39020	\N	57179	\N
3432407	GENERIC_DAY	2	7	\N	2010-12-30	39020	\N	57179	\N
3432436	GENERIC_DAY	2	8	\N	2010-11-03	39020	\N	57179	\N
3432463	GENERIC_DAY	2	7	\N	2010-12-28	39020	\N	57179	\N
3432523	GENERIC_DAY	2	8	\N	2010-11-11	39020	\N	57179	\N
3432496	GENERIC_DAY	2	7	\N	2010-11-25	39020	\N	57179	\N
3432470	GENERIC_DAY	2	7	\N	2010-12-09	39020	\N	57179	\N
3432419	GENERIC_DAY	2	7	\N	2010-12-13	39020	\N	57179	\N
3432518	GENERIC_DAY	2	8	\N	2010-07-20	39020	\N	57179	\N
3432396	GENERIC_DAY	2	8	\N	2010-10-18	39020	\N	57179	\N
3432382	GENERIC_DAY	2	8	\N	2010-08-31	39020	\N	57179	\N
3432464	GENERIC_DAY	2	8	\N	2010-11-04	39020	\N	57179	\N
3432491	GENERIC_DAY	2	8	\N	2010-07-16	39020	\N	57179	\N
3432406	GENERIC_DAY	2	8	\N	2010-06-24	39020	\N	57179	\N
3432399	GENERIC_DAY	2	7	\N	2010-12-31	39020	\N	57179	\N
3432439	GENERIC_DAY	2	8	\N	2010-06-15	39020	\N	57179	\N
3432515	GENERIC_DAY	2	7	\N	2011-01-27	39020	\N	57179	\N
3432512	GENERIC_DAY	2	8	\N	2010-08-05	39020	\N	57179	\N
3432508	GENERIC_DAY	2	8	\N	2010-07-07	39020	\N	57179	\N
3432492	GENERIC_DAY	2	7	\N	2010-12-17	39020	\N	57179	\N
3432479	GENERIC_DAY	2	8	\N	2010-07-29	39020	\N	57179	\N
3432380	GENERIC_DAY	2	8	\N	2010-09-24	39020	\N	57179	\N
3432495	GENERIC_DAY	2	8	\N	2010-09-27	39020	\N	57179	\N
3432370	GENERIC_DAY	2	7	\N	2010-12-01	39020	\N	57179	\N
3432425	GENERIC_DAY	2	7	\N	2011-01-13	39020	\N	57179	\N
3432507	GENERIC_DAY	2	7	\N	2010-12-24	39020	\N	57179	\N
3432469	GENERIC_DAY	2	8	\N	2010-07-13	39020	\N	57179	\N
3432449	GENERIC_DAY	2	8	\N	2010-10-20	39020	\N	57179	\N
3432528	GENERIC_DAY	2	8	\N	2010-11-12	39020	\N	57179	\N
3432484	GENERIC_DAY	2	8	\N	2010-07-15	39020	\N	57179	\N
3432467	GENERIC_DAY	2	8	\N	2010-06-08	39020	\N	57179	\N
3432379	GENERIC_DAY	2	8	\N	2010-09-13	39020	\N	57179	\N
3432383	GENERIC_DAY	2	8	\N	2010-09-08	39020	\N	57179	\N
3432530	GENERIC_DAY	2	8	\N	2010-09-01	39020	\N	57179	\N
3432481	GENERIC_DAY	2	8	\N	2010-10-26	39020	\N	57179	\N
3432401	GENERIC_DAY	2	7	\N	2010-12-07	39020	\N	57179	\N
3432498	GENERIC_DAY	2	8	\N	2010-09-23	39020	\N	57179	\N
3432503	GENERIC_DAY	2	8	\N	2010-08-02	39020	\N	57179	\N
3432489	GENERIC_DAY	2	7	\N	2011-01-05	39020	\N	57179	\N
3432416	GENERIC_DAY	2	8	\N	2010-08-24	39020	\N	57179	\N
3432418	GENERIC_DAY	2	8	\N	2010-09-10	39020	\N	57179	\N
3432438	GENERIC_DAY	2	8	\N	2010-07-22	39020	\N	57179	\N
3432456	GENERIC_DAY	2	8	\N	2010-06-28	39020	\N	57179	\N
3432473	GENERIC_DAY	2	7	\N	2011-01-25	39020	\N	57179	\N
3432375	GENERIC_DAY	2	7	\N	2010-12-29	39020	\N	57179	\N
3432405	GENERIC_DAY	2	8	\N	2010-08-20	39020	\N	57179	\N
3432441	GENERIC_DAY	2	8	\N	2010-10-14	39020	\N	57179	\N
3432500	GENERIC_DAY	2	8	\N	2010-06-22	39020	\N	57179	\N
3432437	GENERIC_DAY	2	7	\N	2010-11-18	39020	\N	57179	\N
3432408	GENERIC_DAY	2	8	\N	2010-10-01	39020	\N	57179	\N
3432487	GENERIC_DAY	2	8	\N	2010-06-11	39020	\N	57179	\N
3432468	GENERIC_DAY	2	7	\N	2011-01-11	39020	\N	57179	\N
3432388	GENERIC_DAY	2	7	\N	2010-12-21	39020	\N	57179	\N
3432412	GENERIC_DAY	2	8	\N	2010-09-22	39020	\N	57179	\N
3432453	GENERIC_DAY	2	8	\N	2010-08-17	39020	\N	57179	\N
3432497	GENERIC_DAY	2	7	\N	2010-12-16	39020	\N	57179	\N
3432403	GENERIC_DAY	2	7	\N	2010-11-29	39020	\N	57179	\N
3432488	GENERIC_DAY	2	8	\N	2010-07-28	39020	\N	57179	\N
3432435	GENERIC_DAY	2	8	\N	2010-10-25	39020	\N	57179	\N
3432513	GENERIC_DAY	2	8	\N	2010-08-27	39020	\N	57179	\N
3432480	GENERIC_DAY	2	8	\N	2010-06-01	39020	\N	57179	\N
3432431	GENERIC_DAY	2	7	\N	2010-12-22	39020	\N	57179	\N
3432516	GENERIC_DAY	2	8	\N	2010-09-28	39020	\N	57179	\N
3432376	GENERIC_DAY	2	7	\N	2011-01-21	39020	\N	57179	\N
3432502	GENERIC_DAY	2	8	\N	2010-08-19	39020	\N	57179	\N
3432413	GENERIC_DAY	2	8	\N	2010-10-28	39020	\N	57179	\N
3432455	GENERIC_DAY	2	8	\N	2010-06-25	39020	\N	57179	\N
3432505	GENERIC_DAY	2	8	\N	2010-08-10	39020	\N	57179	\N
3432389	GENERIC_DAY	2	8	\N	2010-09-29	39020	\N	57179	\N
3432522	GENERIC_DAY	2	8	\N	2010-09-09	39020	\N	57179	\N
3432386	GENERIC_DAY	2	8	\N	2010-06-07	39020	\N	57179	\N
3432422	GENERIC_DAY	2	8	\N	2010-11-10	39020	\N	57179	\N
3432459	GENERIC_DAY	2	8	\N	2010-06-18	39020	\N	57179	\N
3432404	GENERIC_DAY	2	8	\N	2010-06-30	39020	\N	57179	\N
3432395	GENERIC_DAY	2	8	\N	2010-08-30	39020	\N	57179	\N
3432377	GENERIC_DAY	2	8	\N	2010-07-30	39020	\N	57179	\N
3432372	GENERIC_DAY	2	7	\N	2011-01-17	39020	\N	57179	\N
3432510	GENERIC_DAY	2	8	\N	2010-06-17	39020	\N	57179	\N
3432433	GENERIC_DAY	2	8	\N	2010-10-29	39020	\N	57179	\N
3432532	GENERIC_DAY	2	8	\N	2010-08-16	39020	\N	57179	\N
3432434	GENERIC_DAY	2	7	\N	2010-11-22	39020	\N	57179	\N
3432483	GENERIC_DAY	2	8	\N	2010-08-25	39020	\N	57179	\N
3432400	GENERIC_DAY	2	8	\N	2010-06-03	39020	\N	57179	\N
3432440	GENERIC_DAY	2	7	\N	2011-01-04	39020	\N	57179	\N
3432409	GENERIC_DAY	2	7	\N	2011-01-10	39020	\N	57179	\N
3432423	GENERIC_DAY	2	8	\N	2010-10-13	39020	\N	57179	\N
3432398	GENERIC_DAY	2	8	\N	2010-10-08	39020	\N	57179	\N
3432534	GENERIC_DAY	2	8	\N	2010-07-05	39020	\N	57179	\N
3432411	GENERIC_DAY	2	8	\N	2010-10-07	39020	\N	57179	\N
3432410	GENERIC_DAY	2	8	\N	2010-07-27	39020	\N	57179	\N
3432461	GENERIC_DAY	2	8	\N	2010-06-21	39020	\N	57179	\N
3432394	GENERIC_DAY	2	7	\N	2010-11-26	39020	\N	57179	\N
3432524	GENERIC_DAY	2	8	\N	2010-09-03	39020	\N	57179	\N
3432535	GENERIC_DAY	2	8	\N	2010-08-26	39020	\N	57179	\N
3432387	GENERIC_DAY	2	8	\N	2010-07-21	39020	\N	57179	\N
3443275	GENERIC_DAY	2	8	\N	2010-06-14	39022	\N	2379862	\N
3443296	GENERIC_DAY	2	6	\N	2010-06-25	39015	\N	2379862	\N
3443274	GENERIC_DAY	2	0	\N	2010-06-20	39015	\N	2379862	\N
3443280	GENERIC_DAY	2	8	\N	2010-06-15	39015	\N	2379862	\N
3443270	GENERIC_DAY	2	8	\N	2010-06-14	39015	\N	2379862	\N
3443290	GENERIC_DAY	2	8	\N	2010-06-24	39015	\N	2379862	\N
3443299	GENERIC_DAY	2	0	\N	2010-06-13	39022	\N	2379862	\N
3443278	GENERIC_DAY	2	8	\N	2010-06-16	39022	\N	2379862	\N
3443287	GENERIC_DAY	2	8	\N	2010-06-11	39015	\N	2379862	\N
3443297	GENERIC_DAY	2	8	\N	2010-06-23	39022	\N	2379862	\N
3443294	GENERIC_DAY	2	0	\N	2010-06-12	39022	\N	2379862	\N
3443310	GENERIC_DAY	2	8	\N	2010-06-04	39022	\N	2379862	\N
3443292	GENERIC_DAY	2	8	\N	2010-06-09	39015	\N	2379862	\N
3443300	GENERIC_DAY	2	8	\N	2010-06-04	39015	\N	2379862	\N
3443285	GENERIC_DAY	2	0	\N	2010-06-12	39015	\N	2379862	\N
3443277	GENERIC_DAY	2	8	\N	2010-06-10	39022	\N	2379862	\N
3443289	GENERIC_DAY	2	8	\N	2010-06-03	39015	\N	2379862	\N
3443268	GENERIC_DAY	2	8	\N	2010-06-15	39022	\N	2379862	\N
3443303	GENERIC_DAY	2	8	\N	2010-06-08	39022	\N	2379862	\N
3443305	GENERIC_DAY	2	8	\N	2010-06-21	39015	\N	2379862	\N
3443276	GENERIC_DAY	2	0	\N	2010-06-19	39015	\N	2379862	\N
3443271	GENERIC_DAY	2	8	\N	2010-06-22	39015	\N	2379862	\N
3443288	GENERIC_DAY	2	8	\N	2010-06-08	39015	\N	2379862	\N
3443312	GENERIC_DAY	2	0	\N	2010-06-05	39015	\N	2379862	\N
3443286	GENERIC_DAY	2	8	\N	2010-06-03	39022	\N	2379862	\N
3443306	GENERIC_DAY	2	8	\N	2010-06-18	39022	\N	2379862	\N
3443308	GENERIC_DAY	2	8	\N	2010-06-16	39015	\N	2379862	\N
3443282	GENERIC_DAY	2	8	\N	2010-06-09	39022	\N	2379862	\N
3443309	GENERIC_DAY	2	8	\N	2010-06-22	39022	\N	2379862	\N
3443302	GENERIC_DAY	2	0	\N	2010-06-19	39022	\N	2379862	\N
3443291	GENERIC_DAY	2	8	\N	2010-06-24	39022	\N	2379862	\N
3443269	GENERIC_DAY	2	0	\N	2010-06-06	39015	\N	2379862	\N
3443298	GENERIC_DAY	2	0	\N	2010-06-20	39022	\N	2379862	\N
3443293	GENERIC_DAY	2	6	\N	2010-06-25	39022	\N	2379862	\N
3443279	GENERIC_DAY	2	8	\N	2010-06-18	39015	\N	2379862	\N
3443281	GENERIC_DAY	2	8	\N	2010-06-02	39022	\N	2379862	\N
3443307	GENERIC_DAY	2	0	\N	2010-06-06	39022	\N	2379862	\N
3443304	GENERIC_DAY	2	8	\N	2010-06-10	39015	\N	2379862	\N
3443295	GENERIC_DAY	2	8	\N	2010-06-02	39015	\N	2379862	\N
3443313	GENERIC_DAY	2	8	\N	2010-06-07	39022	\N	2379862	\N
2494063	GENERIC_DAY	0	1	\N	2010-05-13	1128	\N	14149	\N
2494064	GENERIC_DAY	0	2	\N	2010-05-12	1128	\N	14149	\N
2494065	GENERIC_DAY	0	3	\N	2010-05-11	1128	\N	14149	\N
2494066	GENERIC_DAY	0	3	\N	2010-05-12	1126	\N	14149	\N
2494067	GENERIC_DAY	0	1	\N	2010-05-13	1126	\N	14149	\N
2494068	GENERIC_DAY	0	3	\N	2010-05-12	1130	\N	14149	\N
2494069	GENERIC_DAY	0	3	\N	2010-05-11	1126	\N	14149	\N
2494070	GENERIC_DAY	0	2	\N	2010-05-11	1130	\N	14149	\N
2494071	GENERIC_DAY	0	2	\N	2010-05-13	1130	\N	14149	\N
2494072	GENERIC_DAY	0	2	\N	2010-05-10	1130	\N	14148	\N
2494073	GENERIC_DAY	0	2	\N	2010-05-05	1130	\N	14148	\N
2494074	GENERIC_DAY	0	0	\N	2010-05-09	1126	\N	14148	\N
2494075	GENERIC_DAY	0	3	\N	2010-05-07	1130	\N	14148	\N
2494076	GENERIC_DAY	0	2	\N	2010-05-07	1128	\N	14148	\N
2494077	GENERIC_DAY	0	0	\N	2010-05-09	1128	\N	14148	\N
2494078	GENERIC_DAY	0	2	\N	2010-05-10	1128	\N	14148	\N
2494079	GENERIC_DAY	0	0	\N	2010-05-08	1130	\N	14148	\N
2494080	GENERIC_DAY	0	3	\N	2010-05-07	1126	\N	14148	\N
2494081	GENERIC_DAY	0	3	\N	2010-05-05	1126	\N	14148	\N
2494082	GENERIC_DAY	0	0	\N	2010-05-08	1126	\N	14148	\N
2494083	GENERIC_DAY	0	3	\N	2010-05-06	1126	\N	14148	\N
2494084	GENERIC_DAY	0	0	\N	2010-05-09	1130	\N	14148	\N
2494085	GENERIC_DAY	0	2	\N	2010-05-10	1126	\N	14148	\N
2494086	GENERIC_DAY	0	0	\N	2010-05-08	1128	\N	14148	\N
2494087	GENERIC_DAY	0	2	\N	2010-05-06	1128	\N	14148	\N
2494088	GENERIC_DAY	0	3	\N	2010-05-05	1128	\N	14148	\N
2494089	GENERIC_DAY	0	3	\N	2010-05-06	1130	\N	14148	\N
2494090	GENERIC_DAY	0	2	\N	2010-05-19	1128	\N	14151	\N
2494091	GENERIC_DAY	0	3	\N	2010-05-19	1130	\N	14151	\N
2494092	GENERIC_DAY	0	3	\N	2010-05-19	1126	\N	14151	\N
2494093	GENERIC_DAY	0	3	\N	2010-05-18	1128	\N	14151	\N
2494094	GENERIC_DAY	0	3	\N	2010-05-18	1126	\N	14151	\N
2494095	GENERIC_DAY	0	2	\N	2010-05-18	1130	\N	14151	\N
2494096	GENERIC_DAY	0	2	\N	2010-05-20	1130	\N	14151	\N
2494097	GENERIC_DAY	0	1	\N	2010-05-20	1128	\N	14151	\N
2494098	GENERIC_DAY	0	1	\N	2010-05-20	1126	\N	14151	\N
2494099	GENERIC_DAY	0	0	\N	2010-05-16	26463	\N	14150	\N
2494100	GENERIC_DAY	0	2	\N	2010-05-17	26463	\N	14150	\N
2494101	GENERIC_DAY	0	0	\N	2010-05-17	14343	\N	14150	\N
2494102	GENERIC_DAY	0	0	\N	2010-05-17	14345	\N	14150	\N
2494103	GENERIC_DAY	0	0	\N	2010-05-15	26463	\N	14150	\N
2494104	GENERIC_DAY	0	0	\N	2010-05-16	14343	\N	14150	\N
2494105	GENERIC_DAY	0	0	\N	2010-05-16	14345	\N	14150	\N
2494106	GENERIC_DAY	0	3	\N	2010-05-14	14343	\N	14150	\N
2494107	GENERIC_DAY	0	0	\N	2010-05-15	14343	\N	14150	\N
2494108	GENERIC_DAY	0	2	\N	2010-05-14	26463	\N	14150	\N
2494109	GENERIC_DAY	0	0	\N	2010-05-15	14345	\N	14150	\N
2494110	GENERIC_DAY	0	3	\N	2010-05-14	14345	\N	14150	\N
3768848	GENERIC_DAY	9	0	\N	2010-09-12	3513195	\N	3766824	\N
3768849	GENERIC_DAY	9	0	\N	2010-08-15	3513195	\N	3766824	\N
3768859	GENERIC_DAY	9	8	\N	2010-09-07	3513195	\N	3766824	\N
3768862	GENERIC_DAY	9	8	\N	2010-09-06	3513195	\N	3766824	\N
3768852	GENERIC_DAY	9	8	\N	2010-09-09	3513195	\N	3766824	\N
3768845	GENERIC_DAY	9	8	\N	2010-08-13	3513195	\N	3766824	\N
3768873	GENERIC_DAY	9	8	\N	2010-08-19	3513195	\N	3766824	\N
3768867	GENERIC_DAY	9	0	\N	2010-08-14	3513195	\N	3766824	\N
3768844	GENERIC_DAY	9	0	\N	2010-09-05	3513195	\N	3766824	\N
3768847	GENERIC_DAY	9	8	\N	2010-08-31	3513195	\N	3766824	\N
3768872	GENERIC_DAY	9	8	\N	2010-08-23	3513195	\N	3766824	\N
3768869	GENERIC_DAY	9	0	\N	2010-09-04	3513195	\N	3766824	\N
3768877	GENERIC_DAY	9	8	\N	2010-09-08	3513195	\N	3766824	\N
3768866	GENERIC_DAY	9	8	\N	2010-09-10	3513195	\N	3766824	\N
3768861	GENERIC_DAY	9	8	\N	2010-08-18	3513195	\N	3766824	\N
3768853	GENERIC_DAY	9	8	\N	2010-09-16	3513195	\N	3766824	\N
3768865	GENERIC_DAY	9	8	\N	2010-08-25	3513195	\N	3766824	\N
3768846	GENERIC_DAY	9	8	\N	2010-09-15	3513195	\N	3766824	\N
3768878	GENERIC_DAY	9	8	\N	2010-08-17	3513195	\N	3766824	\N
3768850	GENERIC_DAY	9	8	\N	2010-08-20	3513195	\N	3766824	\N
3768858	GENERIC_DAY	9	8	\N	2010-09-13	3513195	\N	3766824	\N
3768854	GENERIC_DAY	9	8	\N	2010-09-02	3513195	\N	3766824	\N
3768860	GENERIC_DAY	9	0	\N	2010-08-22	3513195	\N	3766824	\N
3768874	GENERIC_DAY	9	8	\N	2010-08-26	3513195	\N	3766824	\N
3768855	GENERIC_DAY	9	8	\N	2010-08-16	3513195	\N	3766824	\N
3768876	GENERIC_DAY	9	8	\N	2010-09-03	3513195	\N	3766824	\N
3768875	GENERIC_DAY	9	8	\N	2010-09-01	3513195	\N	3766824	\N
3768870	GENERIC_DAY	9	8	\N	2010-08-24	3513195	\N	3766824	\N
3768863	GENERIC_DAY	9	0	\N	2010-09-11	3513195	\N	3766824	\N
3768868	GENERIC_DAY	9	0	\N	2010-08-21	3513195	\N	3766824	\N
3768851	GENERIC_DAY	9	8	\N	2010-08-30	3513195	\N	3766824	\N
3519447	GENERIC_DAY	24	4	\N	2010-01-06	3513191	\N	3518351	\N
3519466	GENERIC_DAY	24	0	\N	2010-01-02	38991	\N	3518351	\N
3519446	GENERIC_DAY	24	4	\N	2010-01-05	3513191	\N	3518351	\N
3519464	GENERIC_DAY	24	4	\N	2010-01-07	3513191	\N	3518351	\N
3514990	GENERIC_DAY	29	1	\N	2010-06-10	3513187	\N	3511789	\N
3514966	GENERIC_DAY	29	1	\N	2010-09-15	3513187	\N	3511789	\N
3514986	GENERIC_DAY	29	1	\N	2010-07-28	3513187	\N	3511789	\N
3514972	GENERIC_DAY	29	1	\N	2010-09-16	3513187	\N	3511789	\N
3514977	GENERIC_DAY	29	1	\N	2010-09-10	3513187	\N	3511789	\N
3514998	GENERIC_DAY	29	1	\N	2010-09-01	3513187	\N	3511789	\N
3514991	GENERIC_DAY	29	1	\N	2010-06-14	3513187	\N	3511789	\N
3514992	GENERIC_DAY	29	1	\N	2010-05-27	3513187	\N	3511789	\N
3514974	GENERIC_DAY	29	1	\N	2010-07-21	3513187	\N	3511789	\N
3514995	GENERIC_DAY	29	1	\N	2010-09-24	3513187	\N	3511789	\N
3514961	GENERIC_DAY	29	1	\N	2010-06-22	3513187	\N	3511789	\N
3514969	GENERIC_DAY	29	1	\N	2010-07-06	3513187	\N	3511789	\N
3515000	GENERIC_DAY	29	1	\N	2010-07-15	3513187	\N	3511789	\N
3514999	GENERIC_DAY	29	1	\N	2010-06-11	3513187	\N	3511789	\N
3514983	GENERIC_DAY	29	1	\N	2010-06-18	3513187	\N	3511789	\N
3514982	GENERIC_DAY	29	1	\N	2010-05-31	3513187	\N	3511789	\N
3514965	GENERIC_DAY	29	1	\N	2010-06-25	3513187	\N	3511789	\N
3514960	GENERIC_DAY	29	1	\N	2010-09-22	3513187	\N	3511789	\N
3514978	GENERIC_DAY	29	1	\N	2010-06-21	3513187	\N	3511789	\N
3514993	GENERIC_DAY	29	1	\N	2010-06-29	3513187	\N	3511789	\N
3514962	GENERIC_DAY	29	1	\N	2010-06-23	3513187	\N	3511789	\N
3514996	GENERIC_DAY	29	1	\N	2010-07-08	3513187	\N	3511789	\N
3515001	GENERIC_DAY	29	1	\N	2010-09-09	3513187	\N	3511789	\N
3514970	GENERIC_DAY	29	1	\N	2010-06-07	3513187	\N	3511789	\N
3514963	GENERIC_DAY	29	1	\N	2010-06-08	3513187	\N	3511789	\N
3514989	GENERIC_DAY	29	1	\N	2010-09-20	3513187	\N	3511789	\N
3514994	GENERIC_DAY	29	1	\N	2010-07-22	3513187	\N	3511789	\N
3514973	GENERIC_DAY	29	1	\N	2010-09-21	3513187	\N	3511789	\N
3514968	GENERIC_DAY	29	1	\N	2010-06-09	3513187	\N	3511789	\N
3514971	GENERIC_DAY	29	1	\N	2010-09-29	3513187	\N	3511789	\N
3514988	GENERIC_DAY	29	1	\N	2010-09-27	3513187	\N	3511789	\N
3514979	GENERIC_DAY	29	1	\N	2010-07-27	3513187	\N	3511789	\N
3514975	GENERIC_DAY	29	1	\N	2010-06-17	3513187	\N	3511789	\N
3514984	GENERIC_DAY	29	1	\N	2010-08-02	3513187	\N	3511789	\N
3514981	GENERIC_DAY	29	1	\N	2010-09-23	3513187	\N	3511789	\N
3514967	GENERIC_DAY	29	1	\N	2010-09-07	3513187	\N	3511789	\N
3514997	GENERIC_DAY	29	1	\N	2010-07-07	3513187	\N	3511789	\N
3514987	GENERIC_DAY	29	1	\N	2010-07-13	3513187	\N	3511789	\N
3514964	GENERIC_DAY	29	1	\N	2010-06-30	3513187	\N	3511789	\N
3514959	GENERIC_DAY	29	1	\N	2010-09-13	3513187	\N	3511789	\N
3514985	GENERIC_DAY	29	1	\N	2010-07-12	3513187	\N	3511789	\N
3514976	GENERIC_DAY	29	1	\N	2010-07-26	3513187	\N	3511789	\N
3514980	GENERIC_DAY	29	1	\N	2010-07-29	3513187	\N	3511789	\N
3515022	GENERIC_DAY	29	1	\N	2010-06-15	3513187	\N	3511789	\N
3515016	GENERIC_DAY	29	1	\N	2010-07-16	3513187	\N	3511789	\N
3515004	GENERIC_DAY	29	1	\N	2010-09-17	3513187	\N	3511789	\N
3515012	GENERIC_DAY	29	1	\N	2010-09-28	3513187	\N	3511789	\N
3515017	GENERIC_DAY	29	1	\N	2010-09-03	3513187	\N	3511789	\N
3515027	GENERIC_DAY	29	1	\N	2010-05-25	3513187	\N	3511789	\N
3515013	GENERIC_DAY	29	1	\N	2010-06-02	3513187	\N	3511789	\N
3515018	GENERIC_DAY	29	1	\N	2010-09-14	3513187	\N	3511789	\N
3515003	GENERIC_DAY	29	1	\N	2010-06-24	3513187	\N	3511789	\N
3515028	GENERIC_DAY	29	1	\N	2010-06-01	3513187	\N	3511789	\N
3515008	GENERIC_DAY	29	1	\N	2010-07-30	3513187	\N	3511789	\N
3515009	GENERIC_DAY	29	1	\N	2010-06-28	3513187	\N	3511789	\N
3515011	GENERIC_DAY	29	1	\N	2010-06-16	3513187	\N	3511789	\N
3515002	GENERIC_DAY	29	1	\N	2010-06-04	3513187	\N	3511789	\N
3515010	GENERIC_DAY	29	1	\N	2010-09-08	3513187	\N	3511789	\N
3515026	GENERIC_DAY	29	1	\N	2010-07-09	3513187	\N	3511789	\N
3515014	GENERIC_DAY	29	1	\N	2010-07-02	3513187	\N	3511789	\N
3515007	GENERIC_DAY	29	1	\N	2010-07-05	3513187	\N	3511789	\N
3515023	GENERIC_DAY	29	1	\N	2010-07-20	3513187	\N	3511789	\N
3515021	GENERIC_DAY	29	1	\N	2010-07-14	3513187	\N	3511789	\N
3515024	GENERIC_DAY	29	1	\N	2010-07-23	3513187	\N	3511789	\N
3515029	GENERIC_DAY	29	1	\N	2010-06-03	3513187	\N	3511789	\N
3515006	GENERIC_DAY	29	1	\N	2010-07-01	3513187	\N	3511789	\N
3515005	GENERIC_DAY	29	1	\N	2010-07-19	3513187	\N	3511789	\N
3515020	GENERIC_DAY	29	1	\N	2010-09-06	3513187	\N	3511789	\N
3515015	GENERIC_DAY	29	1	\N	2010-09-02	3513187	\N	3511789	\N
3515025	GENERIC_DAY	29	1	\N	2010-05-26	3513187	\N	3511789	\N
3515019	GENERIC_DAY	29	1	\N	2010-05-28	3513187	\N	3511789	\N
3515129	GENERIC_DAY	29	1	\N	2010-09-03	3513187	\N	3511790	\N
3515140	GENERIC_DAY	29	1	\N	2010-09-23	3513187	\N	3511790	\N
3515137	GENERIC_DAY	29	1	\N	2010-06-22	3513187	\N	3511790	\N
3515110	GENERIC_DAY	29	1	\N	2010-09-30	3513187	\N	3511790	\N
3515109	GENERIC_DAY	29	1	\N	2010-05-25	3513187	\N	3511790	\N
3515135	GENERIC_DAY	29	1	\N	2010-07-22	3513187	\N	3511790	\N
3515139	GENERIC_DAY	29	1	\N	2010-07-06	3513187	\N	3511790	\N
3515143	GENERIC_DAY	29	1	\N	2010-06-11	3513187	\N	3511790	\N
3515133	GENERIC_DAY	29	1	\N	2010-07-02	3513187	\N	3511790	\N
3515117	GENERIC_DAY	29	1	\N	2010-09-28	3513187	\N	3511790	\N
3515112	GENERIC_DAY	29	1	\N	2010-09-08	3513187	\N	3511790	\N
3515171	GENERIC_DAY	29	1	\N	2010-09-14	3513187	\N	3511790	\N
3515118	GENERIC_DAY	29	1	\N	2010-06-16	3513187	\N	3511790	\N
3515168	GENERIC_DAY	29	1	\N	2010-09-06	3513187	\N	3511790	\N
3515127	GENERIC_DAY	29	1	\N	2010-09-07	3513187	\N	3511790	\N
3515103	GENERIC_DAY	29	1	\N	2010-09-13	3513187	\N	3511790	\N
3515169	GENERIC_DAY	29	1	\N	2010-06-09	3513187	\N	3511790	\N
3515148	GENERIC_DAY	29	1	\N	2010-09-10	3513187	\N	3511790	\N
3515173	GENERIC_DAY	29	1	\N	2010-09-17	3513187	\N	3511790	\N
3515172	GENERIC_DAY	29	1	\N	2010-07-19	3513187	\N	3511790	\N
3515260	GENERIC_DAY	29	1	\N	2010-06-30	3513187	\N	3511791	\N
3515268	GENERIC_DAY	29	1	\N	2010-07-06	3513187	\N	3511791	\N
3515243	GENERIC_DAY	29	1	\N	2010-06-21	3513187	\N	3511791	\N
3515241	GENERIC_DAY	29	1	\N	2010-08-02	3513187	\N	3511791	\N
3515263	GENERIC_DAY	29	1	\N	2010-07-05	3513187	\N	3511791	\N
3515240	GENERIC_DAY	29	1	\N	2010-06-25	3513187	\N	3511791	\N
3515255	GENERIC_DAY	29	1	\N	2010-07-02	3513187	\N	3511791	\N
3515270	GENERIC_DAY	29	1	\N	2010-08-13	3513187	\N	3511791	\N
3515262	GENERIC_DAY	29	1	\N	2010-08-04	3513187	\N	3511791	\N
3515252	GENERIC_DAY	29	1	\N	2010-06-15	3513187	\N	3511791	\N
3515265	GENERIC_DAY	29	1	\N	2010-08-06	3513187	\N	3511791	\N
3515244	GENERIC_DAY	29	1	\N	2010-06-08	3513187	\N	3511791	\N
3515245	GENERIC_DAY	29	1	\N	2010-06-16	3513187	\N	3511791	\N
3515254	GENERIC_DAY	29	1	\N	2010-08-19	3513187	\N	3511791	\N
3515259	GENERIC_DAY	29	1	\N	2010-06-01	3513187	\N	3511791	\N
3515247	GENERIC_DAY	29	1	\N	2010-09-16	3513187	\N	3511791	\N
3515251	GENERIC_DAY	29	1	\N	2010-05-28	3513187	\N	3511791	\N
3515257	GENERIC_DAY	29	1	\N	2010-07-01	3513187	\N	3511791	\N
3515238	GENERIC_DAY	29	1	\N	2010-09-08	3513187	\N	3511791	\N
3515264	GENERIC_DAY	29	1	\N	2010-09-10	3513187	\N	3511791	\N
3515242	GENERIC_DAY	29	1	\N	2010-06-22	3513187	\N	3511791	\N
3515266	GENERIC_DAY	29	1	\N	2010-06-04	3513187	\N	3511791	\N
3515246	GENERIC_DAY	29	1	\N	2010-06-23	3513187	\N	3511791	\N
3515239	GENERIC_DAY	29	1	\N	2010-06-28	3513187	\N	3511791	\N
3515256	GENERIC_DAY	29	1	\N	2010-05-25	3513187	\N	3511791	\N
3515253	GENERIC_DAY	29	1	\N	2010-09-09	3513187	\N	3511791	\N
3515267	GENERIC_DAY	29	1	\N	2010-07-09	3513187	\N	3511791	\N
3515250	GENERIC_DAY	29	1	\N	2010-06-14	3513187	\N	3511791	\N
3515261	GENERIC_DAY	29	1	\N	2010-07-08	3513187	\N	3511791	\N
3515248	GENERIC_DAY	29	1	\N	2010-08-20	3513187	\N	3511791	\N
3515249	GENERIC_DAY	29	1	\N	2010-07-12	3513187	\N	3511791	\N
3515269	GENERIC_DAY	29	1	\N	2010-09-06	3513187	\N	3511791	\N
3515258	GENERIC_DAY	29	1	\N	2010-06-29	3513187	\N	3511791	\N
3515293	GENERIC_DAY	29	1	\N	2010-07-07	3513187	\N	3511791	\N
3515296	GENERIC_DAY	29	1	\N	2010-06-03	3513187	\N	3511791	\N
3515294	GENERIC_DAY	29	1	\N	2010-08-05	3513187	\N	3511791	\N
3515278	GENERIC_DAY	29	1	\N	2010-06-09	3513187	\N	3511791	\N
3515282	GENERIC_DAY	29	1	\N	2010-08-11	3513187	\N	3511791	\N
3515289	GENERIC_DAY	29	1	\N	2010-07-13	3513187	\N	3511791	\N
3515283	GENERIC_DAY	29	1	\N	2010-06-24	3513187	\N	3511791	\N
3515292	GENERIC_DAY	29	1	\N	2010-08-16	3513187	\N	3511791	\N
3515276	GENERIC_DAY	29	1	\N	2010-06-07	3513187	\N	3511791	\N
3515284	GENERIC_DAY	29	1	\N	2010-08-10	3513187	\N	3511791	\N
3515287	GENERIC_DAY	29	1	\N	2010-05-31	3513187	\N	3511791	\N
3515281	GENERIC_DAY	29	1	\N	2010-09-07	3513187	\N	3511791	\N
3515297	GENERIC_DAY	29	1	\N	2010-09-02	3513187	\N	3511791	\N
3515286	GENERIC_DAY	29	1	\N	2010-07-14	3513187	\N	3511791	\N
3515295	GENERIC_DAY	29	1	\N	2010-06-10	3513187	\N	3511791	\N
3515279	GENERIC_DAY	29	1	\N	2010-06-11	3513187	\N	3511791	\N
3515301	GENERIC_DAY	29	1	\N	2010-08-12	3513187	\N	3511791	\N
3515300	GENERIC_DAY	29	1	\N	2010-09-01	3513187	\N	3511791	\N
3515290	GENERIC_DAY	29	1	\N	2010-06-18	3513187	\N	3511791	\N
3515273	GENERIC_DAY	29	1	\N	2010-08-09	3513187	\N	3511791	\N
3515280	GENERIC_DAY	29	1	\N	2010-09-03	3513187	\N	3511791	\N
3515272	GENERIC_DAY	29	1	\N	2010-09-15	3513187	\N	3511791	\N
3515291	GENERIC_DAY	29	1	\N	2010-09-14	3513187	\N	3511791	\N
3515285	GENERIC_DAY	29	1	\N	2010-09-13	3513187	\N	3511791	\N
3515271	GENERIC_DAY	29	1	\N	2010-06-02	3513187	\N	3511791	\N
3515277	GENERIC_DAY	29	1	\N	2010-05-26	3513187	\N	3511791	\N
3515275	GENERIC_DAY	29	1	\N	2010-06-17	3513187	\N	3511791	\N
3515274	GENERIC_DAY	29	1	\N	2010-05-27	3513187	\N	3511791	\N
3515299	GENERIC_DAY	29	1	\N	2010-08-18	3513187	\N	3511791	\N
3515298	GENERIC_DAY	29	1	\N	2010-08-03	3513187	\N	3511791	\N
3515288	GENERIC_DAY	29	1	\N	2010-08-17	3513187	\N	3511791	\N
3515349	GENERIC_DAY	29	1	\N	2010-05-31	3513187	\N	3511792	\N
3515329	GENERIC_DAY	29	1	\N	2010-09-02	3513187	\N	3511792	\N
3515350	GENERIC_DAY	29	1	\N	2010-07-02	3513187	\N	3511792	\N
3515345	GENERIC_DAY	29	1	\N	2010-09-01	3513187	\N	3511792	\N
3515334	GENERIC_DAY	29	1	\N	2010-05-28	3513187	\N	3511792	\N
3515352	GENERIC_DAY	29	1	\N	2010-09-09	3513187	\N	3511792	\N
3515344	GENERIC_DAY	29	1	\N	2010-06-07	3513187	\N	3511792	\N
3515339	GENERIC_DAY	29	1	\N	2010-08-06	3513187	\N	3511792	\N
3515354	GENERIC_DAY	29	1	\N	2010-06-01	3513187	\N	3511792	\N
3515353	GENERIC_DAY	29	1	\N	2010-05-27	3513187	\N	3511792	\N
3515347	GENERIC_DAY	29	1	\N	2010-08-02	3513187	\N	3511792	\N
3515330	GENERIC_DAY	29	1	\N	2010-07-06	3513187	\N	3511792	\N
3515336	GENERIC_DAY	29	1	\N	2010-07-01	3513187	\N	3511792	\N
3515342	GENERIC_DAY	29	1	\N	2010-09-08	3513187	\N	3511792	\N
3515341	GENERIC_DAY	29	1	\N	2010-05-25	3513187	\N	3511792	\N
3515331	GENERIC_DAY	29	1	\N	2010-09-03	3513187	\N	3511792	\N
3515337	GENERIC_DAY	29	1	\N	2010-06-02	3513187	\N	3511792	\N
3515335	GENERIC_DAY	29	1	\N	2010-09-06	3513187	\N	3511792	\N
3515351	GENERIC_DAY	29	1	\N	2010-06-03	3513187	\N	3511792	\N
3515332	GENERIC_DAY	29	1	\N	2010-08-03	3513187	\N	3511792	\N
3515333	GENERIC_DAY	29	1	\N	2010-09-07	3513187	\N	3511792	\N
3515338	GENERIC_DAY	29	1	\N	2010-07-05	3513187	\N	3511792	\N
3515343	GENERIC_DAY	29	1	\N	2010-06-04	3513187	\N	3511792	\N
3515340	GENERIC_DAY	29	1	\N	2010-08-05	3513187	\N	3511792	\N
3515348	GENERIC_DAY	29	1	\N	2010-08-04	3513187	\N	3511792	\N
3515346	GENERIC_DAY	29	1	\N	2010-05-26	3513187	\N	3511792	\N
3515355	GENERIC_DAY	29	1	\N	2010-07-07	3513187	\N	3511792	\N
3515388	GENERIC_DAY	29	1	\N	2010-09-03	3513187	\N	3511793	\N
3515377	GENERIC_DAY	29	1	\N	2010-09-06	3513187	\N	3511793	\N
3515386	GENERIC_DAY	29	1	\N	2010-09-02	3513187	\N	3511793	\N
3515381	GENERIC_DAY	29	1	\N	2010-05-28	3513187	\N	3511793	\N
3515383	GENERIC_DAY	29	1	\N	2010-05-25	3513187	\N	3511793	\N
3515384	GENERIC_DAY	29	1	\N	2010-09-01	3513187	\N	3511793	\N
3515382	GENERIC_DAY	29	1	\N	2010-07-02	3513187	\N	3511793	\N
3515389	GENERIC_DAY	29	1	\N	2010-06-01	3513187	\N	3511793	\N
3515376	GENERIC_DAY	29	1	\N	2010-05-31	3513187	\N	3511793	\N
3515380	GENERIC_DAY	29	1	\N	2010-08-04	3513187	\N	3511793	\N
3515385	GENERIC_DAY	29	1	\N	2010-07-01	3513187	\N	3511793	\N
3515379	GENERIC_DAY	29	1	\N	2010-05-27	3513187	\N	3511793	\N
3515378	GENERIC_DAY	29	1	\N	2010-09-07	3513187	\N	3511793	\N
3515387	GENERIC_DAY	29	1	\N	2010-08-05	3513187	\N	3511793	\N
3515391	GENERIC_DAY	29	1	\N	2010-05-26	3513187	\N	3511793	\N
3515393	GENERIC_DAY	29	1	\N	2010-06-03	3513187	\N	3511793	\N
3515390	GENERIC_DAY	29	1	\N	2010-07-05	3513187	\N	3511793	\N
3515392	GENERIC_DAY	29	1	\N	2010-08-03	3513187	\N	3511793	\N
3515394	GENERIC_DAY	29	1	\N	2010-06-02	3513187	\N	3511793	\N
3515395	GENERIC_DAY	29	1	\N	2010-08-02	3513187	\N	3511793	\N
3835471	GENERIC_DAY	5	0	f	2010-05-22	1126	\N	3836285	\N
3835464	GENERIC_DAY	5	2	f	2010-05-24	1130	\N	3836285	\N
3835470	GENERIC_DAY	5	0	f	2010-05-23	1130	\N	3836285	\N
3835450	GENERIC_DAY	5	1	t	2010-05-28	14343	\N	3836283	\N
3835448	GENERIC_DAY	5	0	t	2010-05-28	26463	\N	3836283	\N
3835446	GENERIC_DAY	5	2	t	2010-05-27	26463	\N	3836283	\N
3835447	GENERIC_DAY	5	3	t	2010-05-27	14343	\N	3836283	\N
3835451	GENERIC_DAY	5	3	t	2010-05-27	14345	\N	3836283	\N
3835449	GENERIC_DAY	5	1	t	2010-05-28	14345	\N	3836283	\N
3835467	GENERIC_DAY	5	0	f	2010-05-23	1128	\N	3836285	\N
3835466	GENERIC_DAY	5	3	f	2010-05-25	1126	\N	3836285	\N
3835468	GENERIC_DAY	5	3	f	2010-05-24	1128	\N	3836285	\N
3835472	GENERIC_DAY	5	3	f	2010-05-25	1128	\N	3836285	\N
3835469	GENERIC_DAY	5	3	f	2010-05-24	1126	\N	3836285	\N
3835465	GENERIC_DAY	5	0	f	2010-05-22	1128	\N	3836285	\N
3836387	GENERIC_DAY	5	2	f	2010-05-26	1126	\N	3836285	\N
3836384	GENERIC_DAY	5	1	f	2010-05-26	1130	\N	3836285	\N
3836386	GENERIC_DAY	5	0	f	2010-05-23	1126	\N	3836285	\N
3835473	GENERIC_DAY	5	0	f	2010-05-22	1130	\N	3836285	\N
3836385	GENERIC_DAY	5	1	f	2010-05-26	1128	\N	3836285	\N
3835474	GENERIC_DAY	5	2	f	2010-05-25	1130	\N	3836285	\N
3836730	GENERIC_DAY	3	3	t	2010-05-19	1130	\N	3836284	\N
3836732	GENERIC_DAY	3	3	t	2010-05-20	1128	\N	3836284	\N
3836731	GENERIC_DAY	3	5	f	2010-05-21	1130	\N	3836284	\N
3836729	GENERIC_DAY	3	2	t	2010-05-19	1126	\N	3836284	\N
3836813	GENERIC_DAY	1	0	t	2010-05-30	1126	\N	3836286	\N
3836814	GENERIC_DAY	1	1	t	2010-06-02	1130	\N	3836286	\N
3836815	GENERIC_DAY	1	0	t	2010-05-29	1126	\N	3836286	\N
3836816	GENERIC_DAY	1	2	f	2010-06-09	1126	\N	3836286	\N
3836817	GENERIC_DAY	1	2	t	2010-05-31	1130	\N	3836286	\N
3836818	GENERIC_DAY	1	0	t	2010-05-29	1130	\N	3836286	\N
3836819	GENERIC_DAY	1	3	t	2010-05-31	1128	\N	3836286	\N
3836820	GENERIC_DAY	1	0	t	2010-05-30	1128	\N	3836286	\N
3836821	GENERIC_DAY	1	0	t	2010-05-29	1128	\N	3836286	\N
3836822	GENERIC_DAY	1	3	f	2010-06-08	1130	\N	3836286	\N
3836823	GENERIC_DAY	1	2	t	2010-06-01	1130	\N	3836286	\N
3836824	GENERIC_DAY	1	2	f	2010-06-08	1126	\N	3836286	\N
3836825	GENERIC_DAY	1	1	t	2010-06-02	1128	\N	3836286	\N
3836826	GENERIC_DAY	1	3	f	2010-06-09	1130	\N	3836286	\N
3836827	GENERIC_DAY	1	2	t	2010-06-02	1126	\N	3836286	\N
3836828	GENERIC_DAY	1	2	f	2010-06-08	1128	\N	3836286	\N
3836829	GENERIC_DAY	1	3	t	2010-06-01	1126	\N	3836286	\N
3836830	GENERIC_DAY	1	0	t	2010-05-30	1130	\N	3836286	\N
3836831	GENERIC_DAY	1	2	f	2010-06-09	1128	\N	3836286	\N
3836832	GENERIC_DAY	1	3	t	2010-05-31	1126	\N	3836286	\N
3836833	GENERIC_DAY	1	3	t	2010-06-01	1128	\N	3836286	\N
3836740	GENERIC_DAY	3	2	t	2010-05-20	1130	\N	3836284	\N
3836738	GENERIC_DAY	3	5	f	2010-05-21	1128	\N	3836284	\N
3836734	GENERIC_DAY	3	3	t	2010-05-18	1126	\N	3836284	\N
3836736	GENERIC_DAY	3	3	t	2010-05-18	1130	\N	3836284	\N
3836739	GENERIC_DAY	3	2	t	2010-05-18	1128	\N	3836284	\N
3836737	GENERIC_DAY	3	3	t	2010-05-20	1126	\N	3836284	\N
3836735	GENERIC_DAY	3	5	f	2010-05-21	1126	\N	3836284	\N
3836733	GENERIC_DAY	3	3	t	2010-05-19	1128	\N	3836284	\N
3774325	GENERIC_DAY	7	1	\N	2010-08-06	3513197	\N	3766828	\N
3774354	GENERIC_DAY	7	1	\N	2010-09-14	3513197	\N	3766828	\N
3774318	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766828	\N
3774291	GENERIC_DAY	7	2	\N	2010-06-07	3513197	\N	3766828	\N
3774294	GENERIC_DAY	7	1	\N	2010-07-16	3513197	\N	3766828	\N
3774345	GENERIC_DAY	7	2	\N	2010-05-28	3513197	\N	3766828	\N
3774306	GENERIC_DAY	7	1	\N	2010-06-22	3513197	\N	3766828	\N
3774321	GENERIC_DAY	7	1	\N	2010-09-03	3513197	\N	3766828	\N
3774340	GENERIC_DAY	7	1	\N	2010-07-05	3513197	\N	3766828	\N
3774358	GENERIC_DAY	7	2	\N	2010-06-11	3513197	\N	3766828	\N
3774290	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766828	\N
3774297	GENERIC_DAY	7	1	\N	2010-08-24	3513197	\N	3766828	\N
3774339	GENERIC_DAY	7	1	\N	2010-08-02	3513197	\N	3766828	\N
3774286	GENERIC_DAY	7	2	\N	2010-06-08	3513197	\N	3766828	\N
3774296	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766828	\N
3774310	GENERIC_DAY	7	1	\N	2010-07-20	3513197	\N	3766828	\N
3774311	GENERIC_DAY	7	1	\N	2010-08-23	3513197	\N	3766828	\N
3774338	GENERIC_DAY	7	1	\N	2010-06-29	3513197	\N	3766828	\N
3774356	GENERIC_DAY	7	1	\N	2010-08-26	3513197	\N	3766828	\N
3774343	GENERIC_DAY	7	1	\N	2010-08-10	3513197	\N	3766828	\N
3774319	GENERIC_DAY	7	2	\N	2010-06-16	3513197	\N	3766828	\N
3774330	GENERIC_DAY	7	1	\N	2010-06-25	3513197	\N	3766828	\N
3774314	GENERIC_DAY	7	1	\N	2010-06-28	3513197	\N	3766828	\N
3774303	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766828	\N
3774322	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766828	\N
3774734	GENERIC_DAY	7	1	\N	2010-09-08	3513197	\N	3766833	\N
3774790	GENERIC_DAY	7	1	\N	2010-07-15	3513197	\N	3766833	\N
3774761	GENERIC_DAY	7	1	\N	2010-08-05	3513197	\N	3766833	\N
3774747	GENERIC_DAY	7	1	\N	2010-06-17	3513197	\N	3766833	\N
3774781	GENERIC_DAY	7	1	\N	2010-07-06	3513197	\N	3766833	\N
3774721	GENERIC_DAY	7	1	\N	2010-07-02	3513197	\N	3766833	\N
3774769	GENERIC_DAY	7	1	\N	2010-09-02	3513197	\N	3766833	\N
3774776	GENERIC_DAY	7	1	\N	2010-06-22	3513197	\N	3766833	\N
3774789	GENERIC_DAY	7	1	\N	2010-07-22	3513197	\N	3766833	\N
3774757	GENERIC_DAY	7	1	\N	2010-07-12	3513197	\N	3766833	\N
3774740	GENERIC_DAY	7	1	\N	2010-07-14	3513197	\N	3766833	\N
3774723	GENERIC_DAY	7	1	\N	2010-07-28	3513197	\N	3766833	\N
3774783	GENERIC_DAY	7	1	\N	2010-06-11	3513197	\N	3766833	\N
3774773	GENERIC_DAY	7	1	\N	2010-08-12	3513197	\N	3766833	\N
3774714	GENERIC_DAY	7	1	\N	2010-05-28	3513197	\N	3766833	\N
3774748	GENERIC_DAY	7	1	\N	2010-08-20	3513197	\N	3766833	\N
3774722	GENERIC_DAY	7	1	\N	2010-08-11	3513197	\N	3766833	\N
3774778	GENERIC_DAY	7	1	\N	2010-09-01	3513197	\N	3766833	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type, queue_dependency) FROM stdin;
4554835	6	13947	13948	0	\N
4554798	6	13947	13948	0	\N
4554836	6	13946	13947	0	\N
4554799	6	13946	13947	0	\N
4554837	6	13948	13949	0	\N
4554800	6	13948	13949	0	\N
1137311764	2	3505306	3505307	0	\N
4554863	8	13955	13956	0	\N
4554864	8	13954	13955	0	\N
4554862	8	13956	13957	0	\N
4554861	8	13957	13958	0	\N
4554860	8	13958	13961	0	\N
819277	2	2424	2426	0	\N
819274	4	2434	2435	0	\N
819275	4	2431	2434	0	\N
819276	4	2428	2429	0	\N
819200	3	2427	2428	0	\N
819271	4	2427	2428	0	\N
819272	4	2430	2431	0	\N
819273	4	2429	2430	0	\N
819278	2	2424	2426	0	\N
1140557204	4	3796792	3511163	0	\N
1140556921	18	3511105	3511106	0	\N
1140556922	18	3511097	3511105	0	\N
1140556923	18	3511106	3511107	0	\N
1140556924	18	3511107	3511108	0	\N
4554794	3	13941	13945	0	\N
4554795	3	13940	13941	0	\N
4554797	3	13938	13939	0	\N
4554796	3	13939	13940	0	\N
8945672	3	27373	27374	0	\N
8945673	3	27373	27375	0	\N
8945671	3	27371	27372	0	\N
1140556925	18	3511108	3511109	0	\N
1140556926	18	3511109	3511110	0	\N
1140556927	18	3511110	3511149	0	\N
1140556928	18	3511149	3511150	0	\N
1140556929	18	3511150	3511151	0	\N
1140556930	18	3511151	3511152	0	\N
1140556931	18	3511152	3511153	0	\N
1140556932	18	3511153	3511154	0	\N
1140556992	13	3511117	3511091	0	\N
1140557197	11	3511132	3511136	0	\N
1140557199	11	3511132	3511133	0	\N
1140557198	11	3511132	3511134	0	\N
1140557200	11	3511133	3511135	0	\N
1140557201	11	3511134	3511135	0	\N
1140557202	11	3511136	3511135	0	\N
1140556987	13	3511097	3511112	0	\N
1140556986	13	3511112	3511113	0	\N
1140556988	13	3511113	3511114	0	\N
1140556989	13	3511114	3511115	0	\N
1140556991	13	3511116	3511117	0	\N
1140556990	13	3511115	3511116	0	\N
78514164	5	13961	13962	0	\N
1137311765	0	3505308	3505310	0	\N
1140557056	12	3511125	3511126	0	\N
1140557055	12	3511097	3511125	0	\N
1140555874	24	3511081	3511082	0	\N
1140557057	12	3511126	3511127	0	\N
1140557058	12	3511127	3511128	0	\N
1140557059	12	3511128	3511129	0	\N
1140557060	12	3511129	3511155	0	\N
1140557061	12	3511155	3511156	0	\N
1140557062	12	3511156	3511157	0	\N
1140557054	12	3511157	3511131	0	\N
1140557203	6	3511135	3511163	0	\N
1140556940	17	3511154	3511088	0	\N
1140555963	20	3511099	3511100	0	\N
1140555964	20	3511100	3511101	0	\N
1140555965	20	3511101	3511102	0	\N
1140555966	20	3511102	3511103	0	\N
1140557221	2	3511103	3796793	0	\N
1140557222	2	3796793	3511141	0	\N
1140555969	20	3511141	3511142	0	\N
1140555970	20	3511142	3511143	0	\N
1140555971	20	3511143	3511144	0	\N
1140555972	20	3511144	3511145	0	\N
1140555973	20	3511145	3511146	0	\N
1140555974	20	3511146	3511147	0	\N
1140555975	20	3511147	3511148	0	\N
1140555976	19	3511148	3511087	0	\N
1140555885	22	3511097	3511086	0	\N
1140555881	23	3511093	3511094	0	\N
1244594215	5	3835982	3835983	0	\N
1244594216	5	3835981	3835982	0	\N
1244594217	5	3835980	3835981	0	\N
1140555882	23	3511094	3511095	0	\N
1140555883	23	3511095	3511096	0	\N
1140555884	23	3511096	3511097	0	\N
1140555871	24	3511078	3511079	0	\N
1140555872	24	3511079	3511080	0	\N
1140555873	24	3511080	3511081	0	\N
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
16060	Indcidencias	None.
16061	Indcidencias	Incidencia...
16063	Indcidencias	None
2495104	Indcidencias	
2495105	Indcidencias	
2496619	Indcidencias	
2496620	Indcidencias	
2496621	Indcidencias	
2496625	Indcidencias	
2496626	Indcidencias	
3507427	Indcidencias	
3507428	Indcidencias	
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
3835506	3510692	100.00
3835507	3510693	100.00
3835508	3510694	100.00
3835509	3510695	100.00
2494909	13484	100.00
2494921	1838	100.00
2494922	1839	100.00
2496736	13435	100.00
2496737	13436	100.00
2496792	13485	100.00
3835510	3510696	100.00
3835511	3510697	100.00
3835512	3713366	100.00
3835514	3510662	100.00
3835515	3510663	100.00
2496783	3466220	100.00
2496784	3466220	100.00
2496785	3466222	100.00
2496786	3466222	100.00
2496787	3466223	100.00
3835516	3510664	100.00
3835517	3510665	100.00
3835518	3510666	100.00
3835519	3510667	100.00
3835520	3510668	100.00
3835523	3510670	100.00
3835524	3510671	100.00
3835525	3510672	100.00
3835526	3510673	100.00
3835527	3510674	100.00
3504297	26969	100.00
3504351	3505046	100.00
3504346	3505052	100.00
3504345	3505052	100.00
3835475	13468	100.00
13547	13465	100.00
2494902	13466	100.00
2496797	13467	100.00
3835529	3510676	100.00
3835530	3510684	100.00
3835531	3510685	100.00
3835532	3510686	100.00
3835533	3510689	100.00
3835535	3510677	100.00
3835536	3510707	100.00
3835537	3510708	100.00
3835538	3510709	100.00
3835539	3510710	100.00
3835541	3510678	100.00
3835542	3510712	100.00
3835543	3510713	100.00
3835544	3510714	100.00
3835545	3510715	100.00
3835546	3510739	100.00
3835476	3835693	100.00
3835477	3835694	100.00
3835478	3835695	100.00
3835479	3835696	100.00
3835482	49896	100.00
3835483	49908	100.00
3835484	49909	100.00
3835547	3510740	100.00
3835548	3510741	100.00
3835549	3510742	100.00
3835550	3510743	100.00
3835551	3510744	100.00
3835552	3510745	100.00
3835553	3510746	100.00
3835554	3510747	100.00
3835556	3510679	100.00
3835557	3510717	100.00
3835558	3510718	100.00
3835559	3510719	100.00
3835560	3510720	100.00
3835561	3510721	100.00
3835562	3510748	100.00
3835563	3510749	100.00
3835564	3510750	100.00
3835565	3510751	100.00
3835566	3510752	100.00
3835567	3510753	100.00
3835569	3510680	100.00
3835570	3510723	100.00
3835571	3510724	100.00
3835572	3510725	100.00
3835573	3510726	100.00
3835574	3510727	100.00
3839111	3510682	100.00
3839112	3510735	100.00
3839113	3510736	100.00
3839114	3510737	100.00
3839115	3510738	100.00
3839116	3510754	100.00
3839117	3510755	100.00
3839118	3510756	100.00
3839120	3510698	100.00
3839121	3510700	100.00
3839122	3510701	100.00
3839123	3510702	100.00
3839124	3510703	100.00
3839125	3510704	100.00
3839127	3713372	100.00
3839130	3835698	100.00
3839131	3835706	100.00
3839132	3835707	100.00
\.


--
-- Data for Name: external_company; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY external_company (id, version, name, nif, client, subcontractor, interactswithapplications, appuri, ourcompanylogin, ourcompanypassword, companyuser) FROM stdin;
1515	1	Igalia	B15804842	t	t	t	http://localhost:8080/navalplanner-webapp/	wswriter	wswriter	1013
1516	2	Navantia	N00000000	t	t	t	http://localhost:8080/navalplanner-webapp/	wswriter	wswriter	1013
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
2679
2680
2681
2717
2718
2719
2720
2721
14142
14143
14146
14147
14148
14149
14150
14151
24071
24072
3505617
24074
27674
27675
39509
39510
39511
39518
39519
39520
3505622
3505623
57178
57179
57180
3511787
3511789
3511790
3511791
3511792
3511793
3511795
3518347
3518348
3518349
3518350
3518351
3518352
3518353
3518354
3518355
3518356
3518380
3518381
3518382
3518383
3518384
3518385
3518386
3518387
3518388
3522858
3522859
3522860
3522861
3522862
3522863
3522864
3522865
3559792
3559793
3559794
3559795
3559796
3559797
3559799
3559800
3559802
3559803
3659355
3659356
3659364
3659365
3659366
3659367
3659387
3659389
3679794
3679795
3679796
3679797
3679798
3679799
3679800
3679801
2379862
2494207
2494210
2494211
2494212
3766823
3766824
3766828
3766829
3766830
3766831
3766832
3766833
3766834
3766861
3819130
3819131
3819132
3819133
3819135
3836283
3836284
3836285
3836286
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, positionnumber) FROM stdin;
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
38166
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, code, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
3480662	1	07d4ee87-a18b-442c-91d9-10dcad92fdae	15.50	2010-05-14	\N	16161	3480561
3480663	1	e3aad857-5c4b-46db-958e-d9c0f9e1fd5f	12.50	2010-05-14	\N	16160	3480561
3480664	1	75f84160-b06f-4d49-9ece-287805aca066	10.00	2010-05-14	\N	16161	3480562
3480665	1	306123a5-295b-424d-b162-b1a31452fd72	8.00	2010-05-14	\N	16160	3480562
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, code, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line, order_line_template) FROM stdin;
13810	1	2e8715ce-98ce-4392-9d0c-48ed8724274d	WORKER	450	1.00	f	\N	14908
13811	1	58d5f8d4-bf24-458c-a2f6-54ac80fc7658	WORKER	300	1.00	f	\N	14909
13812	1	1529f659-1615-442a-9b92-a70ee47e7b0b	WORKER	300	1.00	f	\N	14910
13813	1	ee435ae5-8885-4bfa-80f4-f1ee1f842f7b	WORKER	24	1.00	f	\N	14911
13814	1	ea34222c-86be-4511-a257-ef004c8a041e	WORKER	40	1.00	f	\N	14912
13815	1	d4a8eda4-4400-4ab8-a945-299f8995d28a	WORKER	40	1.00	f	\N	14913
13752	1	d676fa93-8306-4e8b-800b-29086226418f	WORKER	30	1.00	f	\N	14863
13753	1	ffb42ec8-8736-46da-897d-1161ae42fff3	WORKER	20	1.00	f	\N	14864
13754	1	90cf475b-1e51-4271-836b-21665763c003	WORKER	10	1.00	f	\N	14865
13755	1	4a3f39bb-9ccf-4868-abec-c42ba76bf74c	WORKER	20	1.00	f	\N	14866
13816	1	6f2153d8-4abf-4006-acf1-0f272b4e694e	WORKER	100	1.00	f	\N	14914
13817	1	1a3ac5f1-7d34-42a6-bdf9-32567c7572ce	WORKER	140	1.00	f	\N	14916
13818	1	74efc2bd-c2d4-465f-8998-db0119e7bdc0	WORKER	170	1.00	f	\N	14917
13819	1	b84d217e-6341-4f90-89d9-433155852ad2	WORKER	60	1.00	f	\N	14918
13737	8	Navalplan-00002-00002-00001	WORKER	20	1.00	f	13436	\N
13738	8	Navalplan-00002-00003-00001	WORKER	10	1.00	f	13437	\N
13739	8	Navalplan-00002-00004-00001	WORKER	20	1.00	f	13438	\N
3835895	5	Navalplan-00014-00001-00001	WORKER	20	1.00	f	3835698	\N
27279	6	Navalplan-00006-00001-00002	WORKER	100	0.50	f	26970	\N
27270	8	Navalplan-00006-00001-00001	WORKER	100	0.50	f	26970	\N
27271	8	Navalplan-00006-00002-00001	WORKER	1000	0.20	f	26971	\N
16665	3	Navalplan-00004-00011-00001	WORKER	140	1.00	f	13492	\N
16666	3	Navalplan-00004-00012-00001	WORKER	170	1.00	f	13493	\N
16667	3	Navalplan-00004-00007-00001	WORKER	60	1.00	f	13494	\N
2032	6	Navalplan-00001-00008-00001	WORKER	450	1.00	f	1838	\N
2033	6	Navalplan-00001-00009-00001	WORKER	300	1.00	f	1839	\N
27282	5	Navalplan-00006-00002-00002	WORKER	2000	0.40	f	26971	\N
2034	6	Navalplan-00001-00010-00001	WORKER	300	1.00	f	1840	\N
2035	6	Navalplan-00001-00002-00001	WORKER	24	1.00	f	1841	\N
2037	6	Navalplan-00001-00004-00001	WORKER	40	1.00	f	1843	\N
2038	6	Navalplan-00001-00005-00001	WORKER	100	1.00	f	1844	\N
2039	6	Navalplan-00001-00011-00001	WORKER	140	1.00	f	1846	\N
2040	6	Navalplan-00001-00012-00001	WORKER	170	1.00	f	1847	\N
2041	6	Navalplan-00001-00007-00001	WORKER	60	1.00	f	1848	\N
27283	5	Navalplan-00006-00002-00003	WORKER	2000	0.40	f	26971	\N
27275	7	Navalplan-00006-00003-00001	WORKER	1000	1.00	f	26975	\N
27276	7	Navalplan-00006-00004-00001	WORKER	500	1.00	f	26976	\N
13736	8	Navalplan-00002-00001-00001	WORKER	30	1.00	f	13435	\N
3511029	24	Navalplan-00012-00079-00001	WORKER	96	1.00	f	3510739	\N
2036	6	Navalplan-00001-00003-00001	WORKER	40	1.00	f	1842	\N
13776	12	Navalplan-00003-00001-00001	WORKER	30	1.00	f	13465	\N
13777	12	Navalplan-00003-00002-00001	WORKER	20	1.00	f	13466	\N
3511030	24	Navalplan-00012-00080-00001	WORKER	72	1.00	f	3510740	\N
3511031	24	Navalplan-00012-00081-00001	WORKER	48	1.00	f	3510741	\N
27277	7	Navalplan-00006-00005-00001	WORKER	2000	1.00	f	26977	\N
13778	12	Navalplan-00003-00003-00001	WORKER	10	1.00	f	13467	\N
13779	12	Navalplan-00003-00004-00001	WORKER	20	1.00	f	13468	\N
3511032	24	Navalplan-00012-00082-00001	WORKER	64	1.00	f	3510742	\N
13830	3	Navalplan-00004-00008-00001	WORKER	450	1.00	f	13484	\N
13831	3	Navalplan-00004-00009-00001	WORKER	300	1.00	f	13485	\N
13832	3	Navalplan-00004-00010-00001	WORKER	300	1.00	f	13486	\N
13833	3	Navalplan-00004-00002-00001	WORKER	24	1.00	f	13487	\N
13834	3	Navalplan-00004-00003-00001	WORKER	40	1.00	f	13488	\N
13835	3	Navalplan-00004-00004-00001	WORKER	40	1.00	f	13489	\N
3511033	24	Navalplan-00012-00083-00001	WORKER	32	1.00	f	3510743	\N
13836	3	Navalplan-00004-00005-00001	WORKER	100	1.00	f	13490	\N
3466320	5	Navalplan-00009-00001-00001	WORKER	100	1.00	f	3466220	\N
3511034	23	Navalplan-00012-00084-00001	WORKER	40	1.00	f	3510744	\N
3511035	23	Navalplan-00012-00085-00001	WORKER	64	1.00	f	3510745	\N
3511036	23	Navalplan-00012-00086-00001	WORKER	112	1.00	f	3510746	\N
3511037	23	Navalplan-00012-00087-00001	WORKER	144	1.00	f	3510747	\N
3835900	5	Navalplan-00014-00003-00001	WORKER	30	1.00	f	3835706	\N
3835901	5	Navalplan-00014-00004-00001	WORKER	50	1.00	f	3835707	\N
3466321	5	Navalplan-00009-00004-00001	WORKER	100	1.00	f	3466222	\N
3466322	5	Navalplan-00009-00003-00001	WORKER	100	1.00	f	3466223	\N
3511038	22	Navalplan-00012-00088-00001	WORKER	72	1.00	f	3510748	\N
3511039	22	Navalplan-00012-00089-00001	WORKER	48	1.00	f	3510749	\N
3511040	22	Navalplan-00012-00090-00001	WORKER	120	1.00	f	3510750	\N
3511041	22	Navalplan-00012-00091-00001	WORKER	168	1.00	f	3510751	\N
3511042	22	Navalplan-00012-00092-00001	WORKER	104	1.00	f	3510752	\N
3511043	22	Navalplan-00012-00093-00001	WORKER	56	1.00	f	3510753	\N
3505224	6	Navalplan-00010-00005-00001	WORKER	40	1.00	f	3505045	\N
3505225	6	Navalplan-00010-00006-00001	WORKER	50	1.00	f	3505046	\N
3505226	6	Navalplan-00010-00007-00001	WORKER	50	1.00	f	3505048	\N
3505227	6	Navalplan-00010-00008-00001	WORKER	30	1.00	f	3505049	\N
3505228	6	Navalplan-00010-00003-00001	WORKER	40	1.00	f	3505050	\N
50200	29	Navalplan-00008-00004-00001	WORKER	154	1.00	f	49899	\N
50227	25	Navalplan-00008-00035-00001	WORKER	352	1.00	f	49930	\N
50228	25	Navalplan-00008-00036-00001	WORKER	35	1.00	f	49931	\N
50274	13	Navalplan-00008-00001-00002	WORKER	1000	0.43	f	49896	\N
50197	30	Navalplan-00008-00001-00001	WORKER	1300	0.56	f	49896	\N
50208	28	Navalplan-00008-00013-00001	WORKER	300	1.00	f	49908	\N
50209	28	Navalplan-00008-00014-00001	WORKER	1493	1.00	f	49909	\N
50210	26	Navalplan-00008-00017-00001	WORKER	105	1.00	f	49911	\N
50199	30	Navalplan-00008-00003-00001	WORKER	84	1.00	f	49898	\N
50211	26	Navalplan-00008-00018-00001	WORKER	112	1.00	f	49912	\N
50212	26	Navalplan-00008-00019-00001	WORKER	105	1.00	f	49913	\N
50213	26	Navalplan-00008-00020-00001	WORKER	105	1.00	f	49914	\N
3511044	20	Navalplan-00012-00094-00001	WORKER	72	1.00	f	3510754	\N
3511045	20	Navalplan-00012-00095-00001	WORKER	144	1.00	f	3510755	\N
3511046	20	Navalplan-00012-00096-00001	WORKER	120	1.00	f	3510756	\N
50229	25	Navalplan-00008-00037-00001	WORKER	35	1.00	f	49932	\N
50230	25	Navalplan-00008-00038-00001	WORKER	35	1.00	f	49933	\N
50231	25	Navalplan-00008-00039-00001	WORKER	50	1.00	f	49934	\N
50214	26	Navalplan-00008-00021-00001	WORKER	112	1.00	f	49915	\N
50215	26	Navalplan-00008-00022-00001	WORKER	232	1.00	f	49916	\N
50216	26	Navalplan-00008-00023-00001	WORKER	77	1.00	f	49917	\N
50217	26	Navalplan-00008-00024-00001	WORKER	155	1.00	f	49918	\N
3505223	6	Navalplan-00010-00004-00001	WORKER	20	1.00	f	3505044	\N
50218	26	Navalplan-00008-00025-00001	WORKER	63	1.00	f	49919	\N
50219	26	Navalplan-00008-00026-00001	WORKER	134	1.00	f	49920	\N
50220	26	Navalplan-00008-00027-00001	WORKER	240	1.00	f	49921	\N
50221	26	Navalplan-00008-00028-00001	WORKER	6	1.00	f	49922	\N
50222	26	Navalplan-00008-00029-00001	WORKER	183	1.00	f	49923	\N
50223	26	Navalplan-00008-00030-00001	WORKER	162	1.00	f	49924	\N
50224	26	Navalplan-00008-00031-00001	WORKER	190	1.00	f	49925	\N
50225	26	Navalplan-00008-00032-00001	WORKER	140	1.00	f	49926	\N
50226	26	Navalplan-00008-00034-00001	WORKER	140	1.00	f	49929	\N
50232	25	Navalplan-00008-00040-00001	WORKER	56	1.00	f	49935	\N
50203	29	Navalplan-00008-00006-00001	WORKER	261	1.00	f	49903	\N
3505229	4	Navalplan-00011-00001-00001	WORKER	30	1.00	f	3505052	\N
50233	25	Navalplan-00008-00041-00001	WORKER	260	1.00	f	49936	\N
50234	25	Navalplan-00008-00042-00001	WORKER	63	1.00	f	49937	\N
50239	22	Navalplan-00008-00049-00001	WORKER	70	1.00	f	49944	\N
50236	24	Navalplan-00008-00044-00001	WORKER	21	1.00	f	49939	\N
50248	21	Navalplan-00008-00058-00001	WORKER	56	1.00	f	49953	\N
50249	21	Navalplan-00008-00059-00001	WORKER	70	1.00	f	49954	\N
50250	21	Navalplan-00008-00060-00001	WORKER	70	1.00	f	49955	\N
50251	21	Navalplan-00008-00061-00001	WORKER	70	1.00	f	49956	\N
50252	21	Navalplan-00008-00062-00001	WORKER	35	1.00	f	49957	\N
50237	23	Navalplan-00008-00046-00001	WORKER	35	1.00	f	49941	\N
50238	23	Navalplan-00008-00047-00001	WORKER	35	1.00	f	49942	\N
50235	24	Navalplan-00008-00043-00001	WORKER	35	1.00	f	49938	\N
50240	22	Navalplan-00008-00050-00001	WORKER	140	1.00	f	49945	\N
50241	22	Navalplan-00008-00051-00001	WORKER	70	1.00	f	49946	\N
50242	22	Navalplan-00008-00052-00001	WORKER	70	1.00	f	49947	\N
50243	22	Navalplan-00008-00053-00001	WORKER	35	1.00	f	49948	\N
50244	22	Navalplan-00008-00054-00001	WORKER	35	1.00	f	49949	\N
50245	22	Navalplan-00008-00055-00001	WORKER	70	1.00	f	49950	\N
50246	22	Navalplan-00008-00056-00001	WORKER	70	1.00	f	49951	\N
50247	22	Navalplan-00008-00057-00001	WORKER	70	1.00	f	49952	\N
50202	29	Navalplan-00008-00012-00001	WORKER	176	1.00	f	49902	\N
50253	20	Navalplan-00008-00064-00001	WORKER	70	1.00	f	49959	\N
50254	20	Navalplan-00008-00065-00001	WORKER	77	1.00	f	49960	\N
50255	20	Navalplan-00008-00066-00001	WORKER	42	1.00	f	49961	\N
50256	20	Navalplan-00008-00067-00001	WORKER	100	1.00	f	49962	\N
50257	20	Navalplan-00008-00068-00001	WORKER	35	1.00	f	49963	\N
3511050	14	Navalplan-00012-00097-00001	WORKER	120	1.00	f	3713366	\N
50258	20	Navalplan-00008-00069-00001	WORKER	56	1.00	f	49964	\N
50259	20	Navalplan-00008-00070-00001	WORKER	77	1.00	f	49965	\N
50260	20	Navalplan-00008-00071-00001	WORKER	300	1.00	f	49966	\N
50261	19	Navalplan-00008-00073-00001	WORKER	93	1.00	f	49968	\N
50262	19	Navalplan-00008-00074-00001	WORKER	50	1.00	f	49969	\N
50263	19	Navalplan-00008-00075-00001	WORKER	482	1.00	f	49970	\N
50264	19	Navalplan-00008-00076-00001	WORKER	340	1.00	f	49971	\N
3505233	4	Navalplan-00011-00003-00001	WORKER	20	1.00	f	3505060	\N
50265	19	Navalplan-00008-00077-00001	WORKER	130	1.00	f	49972	\N
50266	19	Navalplan-00008-00078-00001	WORKER	269	1.00	f	49973	\N
50267	19	Navalplan-00008-00079-00001	WORKER	180	1.00	f	49974	\N
50268	19	Navalplan-00008-00080-00001	WORKER	120	1.00	f	49975	\N
50204	29	Navalplan-00008-00007-00001	WORKER	387	1.00	f	49904	\N
50205	29	Navalplan-00008-00008-00001	WORKER	570	1.00	f	49905	\N
50206	29	Navalplan-00008-00009-00001	WORKER	1000	1.00	f	49906	\N
50207	29	Navalplan-00008-00010-00001	WORKER	300	1.00	f	49907	\N
50269	16	Navalplan-00008-00081-00001	WORKER	100	1.00	f	49976	\N
2394217	5	Navalplan-00008-00082-00001	WORKER	320	1.00	f	2394116	\N
2394218	5	Navalplan-00008-00083-00001	WORKER	500	1.00	f	2394117	\N
3510989	40	Navalplan-00012-00032-00001	WORKER	100	1.00	f	3510692	\N
3511051	10	Navalplan-00012-00098-00001	WORKER	200	1.00	f	3713367	\N
3511052	10	Navalplan-00012-00099-00001	WORKER	400	1.00	f	3713368	\N
3511053	10	Navalplan-00012-00100-00001	WORKER	200	1.00	f	3713369	\N
3511054	10	Navalplan-00012-00101-00001	WORKER	400	1.00	f	3713370	\N
3510962	42	Navalplan-00012-00010-00001	WORKER	100	1.00	f	3510662	\N
3510963	42	Navalplan-00012-00011-00001	WORKER	100	1.00	f	3510663	\N
3510964	42	Navalplan-00012-00012-00001	WORKER	72	1.00	f	3510664	\N
3510965	42	Navalplan-00012-00013-00001	WORKER	72	1.00	f	3510665	\N
3510966	42	Navalplan-00012-00014-00001	WORKER	64	1.00	f	3510666	\N
3510967	42	Navalplan-00012-00015-00001	WORKER	27	1.00	f	3510667	\N
3510968	42	Navalplan-00012-00016-00001	WORKER	20	1.00	f	3510668	\N
3510969	42	Navalplan-00012-00017-00001	WORKER	20	1.00	f	3510670	\N
3510970	42	Navalplan-00012-00018-00001	WORKER	68	1.00	f	3510671	\N
3510971	42	Navalplan-00012-00019-00001	WORKER	176	1.00	f	3510672	\N
3510972	42	Navalplan-00012-00020-00001	WORKER	280	1.00	f	3510673	\N
3510973	42	Navalplan-00012-00021-00001	WORKER	176	1.00	f	3510674	\N
3510975	42	Navalplan-00012-00003-00001	WORKER	40	1.00	f	3510676	\N
3510982	41	Navalplan-00012-00024-00001	WORKER	40	1.00	f	3510684	\N
3510983	41	Navalplan-00012-00025-00001	WORKER	96	1.00	f	3510685	\N
3510984	41	Navalplan-00012-00026-00001	WORKER	116	1.00	f	3510686	\N
3510987	41	Navalplan-00012-00029-00001	WORKER	88	1.00	f	3510689	\N
3510976	42	Navalplan-00012-00004-00001	WORKER	64	1.00	f	3510677	\N
3510977	42	Navalplan-00012-00005-00001	WORKER	56	1.00	f	3510678	\N
3510978	42	Navalplan-00012-00006-00001	WORKER	64	1.00	f	3510679	\N
3510979	42	Navalplan-00012-00007-00001	WORKER	72	1.00	f	3510680	\N
3510981	42	Navalplan-00012-00009-00001	WORKER	144	1.00	f	3510682	\N
3511003	38	Navalplan-00012-00049-00001	WORKER	48	1.00	f	3510708	\N
3511004	38	Navalplan-00012-00050-00001	WORKER	96	1.00	f	3510709	\N
3511005	38	Navalplan-00012-00051-00001	WORKER	144	1.00	f	3510710	\N
3511006	38	Navalplan-00012-00052-00001	WORKER	48	1.00	f	3510712	\N
3511007	38	Navalplan-00012-00053-00001	WORKER	40	1.00	f	3510713	\N
3511008	38	Navalplan-00012-00054-00001	WORKER	56	1.00	f	3510714	\N
3511009	38	Navalplan-00012-00055-00001	WORKER	96	1.00	f	3510715	\N
3511010	37	Navalplan-00012-00057-00001	WORKER	56	1.00	f	3510717	\N
3511011	37	Navalplan-00012-00058-00001	WORKER	48	1.00	f	3510718	\N
3511012	37	Navalplan-00012-00059-00001	WORKER	176	1.00	f	3510719	\N
3511013	37	Navalplan-00012-00060-00001	WORKER	144	1.00	f	3510720	\N
3511014	37	Navalplan-00012-00061-00001	WORKER	152	1.00	f	3510721	\N
3511015	36	Navalplan-00012-00063-00001	WORKER	144	1.00	f	3510723	\N
3511016	35	Navalplan-00012-00066-00001	WORKER	32	1.00	f	3510724	\N
3511017	35	Navalplan-00012-00067-00001	WORKER	168	1.00	f	3510725	\N
3511018	35	Navalplan-00012-00068-00001	WORKER	240	1.00	f	3510726	\N
3511019	35	Navalplan-00012-00069-00001	WORKER	96	1.00	f	3510727	\N
3510995	39	Navalplan-00012-00034-00001	WORKER	200	1.00	f	3510698	\N
3510996	39	Navalplan-00012-00040-00001	WORKER	80	1.00	f	3510700	\N
3510997	39	Navalplan-00012-00041-00001	WORKER	200	1.00	f	3510701	\N
3510998	39	Navalplan-00012-00042-00001	WORKER	200	1.00	f	3510702	\N
3510999	39	Navalplan-00012-00043-00001	WORKER	100	1.00	f	3510703	\N
3511000	39	Navalplan-00012-00044-00001	WORKER	400	1.00	f	3510704	\N
3510990	40	Navalplan-00012-00033-00001	WORKER	100	1.00	f	3510693	\N
3510991	39	Navalplan-00012-00036-00001	WORKER	80	1.00	f	3510694	\N
3510992	39	Navalplan-00012-00037-00001	WORKER	100	1.00	f	3510695	\N
3510993	39	Navalplan-00012-00038-00001	WORKER	180	1.00	f	3510696	\N
3510994	39	Navalplan-00012-00039-00001	WORKER	80	1.00	f	3510697	\N
3511055	10	Navalplan-00012-00102-00001	WORKER	400	1.00	f	3713371	\N
3511002	38	Navalplan-00012-00048-00001	WORKER	56	1.00	f	3510707	\N
3511025	34	Navalplan-00012-00075-00001	WORKER	176	1.00	f	3510735	\N
3511026	34	Navalplan-00012-00076-00001	WORKER	72	1.00	f	3510736	\N
3511027	34	Navalplan-00012-00077-00001	WORKER	72	1.00	f	3510737	\N
3511028	34	Navalplan-00012-00078-00001	WORKER	72	1.00	f	3510738	\N
3511056	9	Navalplan-00012-00103-00001	WORKER	120	1.00	f	3713372	\N
3835891	7	Navalplan-00013-00001-00001	WORKER	30	1.00	f	3835693	\N
3835892	7	Navalplan-00013-00002-00001	WORKER	20	1.00	f	3835694	\N
3835893	7	Navalplan-00013-00003-00001	WORKER	10	1.00	f	3835695	\N
3835894	7	Navalplan-00013-00004-00001	WORKER	20	1.00	f	3835696	\N
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
505	8	0
505	8	1
505	8	2
505	8	3
505	8	4
505	0	5
505	0	6
509	16	0
509	16	1
509	16	2
509	16	3
509	16	4
509	16	5
509	16	6
510	24	0
510	24	1
510	24	2
510	24	3
510	24	4
510	24	5
510	24	6
3504700	8	0
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
2494910	13483
2494911	13482
13552	13483
13553	13491
13554	13482
2494923	1837
2494924	1836
1925	1837
2496738	13434
2496793	13483
2496794	13482
3839134	3835705
3839133	3835705
3839135	3835697
3839136	3835697
2496740	3466221
2496788	3466221
2496789	3466221
2496739	3466219
2496791	3466219
2496790	3466219
13548	13464
2496798	13464
13541	13464
3504320	3505043
3504321	3505047
3504313	3505018
3504349	3505051
3504350	3505051
3504322	3505051
3504352	3505043
3504353	3505018
3504348	3505059
3504326	3505059
3504347	3505059
3835480	3835692
3835481	3835692
3835485	49895
3835486	49895
49998	49910
49999	49928
50003	49943
50005	49967
3835513	3510690
3510765	3510690
3835521	3510661
3835522	3510661
3835528	3510669
3510763	3510669
3510764	3510683
3835534	3510683
3835540	3510706
3510767	3510706
3510768	3510711
3835555	3510711
3835568	3510716
3510769	3510716
3835575	3510722
3510770	3510722
3510772	3510734
3839119	3510734
3510766	3510699
3839126	3510699
3839128	3510660
3839129	3510660
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, code, name, label_type_id) FROM stdin;
1425	22	ea683d67-0096-4270-b9d7-14556be44007	CC Cadiz	1315
1414	1	ba75de5d-a7ee-430a-8dfb-720c23cc9735	Bloque 2	1313
1415	1	da5d0351-c4c5-43ea-8af4-80c744ba6504	Bloque 5	1313
1416	1	5d94f20f-d52b-402a-90ab-d39744b6efa5	Bloque 1	1313
1418	1	a48874a6-7079-4c98-b8a8-e383dca0942b	Bloque 3	1313
1419	1	d17daf21-a2c4-46cf-9564-162e39e1f47d	Zona motores	1314
1420	1	3ce2f523-a79e-4cb2-a29c-21019aee328d	Puente	1314
1421	1	4d10737d-01e7-4e13-9b83-e157154b0e31	Bodegas	1314
1422	1	a927f5c2-f5a6-4d80-8a7d-1dde1b65f343	Sentinas	1314
1423	1	ea361cbc-e71f-45de-99b8-634dfb601023	Cubierta	1314
1424	1	1c135347-293d-488a-ae56-9afca04a3f01	CC Ferrol	1315
1426	1	226a2bcc-7ff2-4511-afdb-329047e16d30	CC Bilbao	1315
1427	1	3d91e6c9-2678-4cb7-9fa8-61ca401daba4	CC Vigo	1315
1428	1	47028151-05d6-44bd-a370-c454f347f9af	CC Coruña	1315
1417	12	8d471b29-ec63-4311-af69-e33f878f5dae	Bloque 4	1313
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, code, name, generatecode) FROM stdin;
1313	1	8da07df6-dcf0-4c99-b2a1-03a13fb6bca8	Bloque	t
1314	1	b1f69297-3874-4284-896f-638117f71d52	Zona del barco	t
1315	1	2200db81-67c3-46a5-99aa-6b6f18d9cb7f	Centro de coste	t
\.


--
-- Data for Name: limiting_resource_queue; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue (id, version, resource_id) FROM stdin;
\.


--
-- Data for Name: limiting_resource_queue_dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_dependency (id, type, origin_queue_element_id, destiny_queue_element_id) FROM stdin;
\.


--
-- Data for Name: limiting_resource_queue_element; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY limiting_resource_queue_element (id, version, resource_allocation_id, limiting_resource_queue_id, earlier_start_date_because_of_gantt, creation_timestamp, start_date, start_hour, end_date, end_hour, earliest_end_date_because_of_gantt) FROM stdin;
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, positionnumber) FROM stdin;
15756	Indcidencias	100	0
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, name, description) FROM stdin;
1115	Torno A	Torno
1117	Torno 2	Torno
1113	Grúa 1	Primera grúa de la grada norte
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
3503893	2	2	Tubo 16mm	23.00	13332	\N	3503794
3503892	2	1	Tubo 8mm	15.00	13332	\N	3503794
3503894	1	Acero	desc	20.00	208	\N	3503793
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, material_id, estimated_availability, status, order_element_id) FROM stdin;
3504195	3	100	23.00	3503893	2010-05-24 00:00:00	0	13467
3504196	3	100	15.00	3503892	\N	1	13467
3504197	2	100	23.00	3503893	\N	1	13467
\.


--
-- Data for Name: material_assigment_template; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment_template (id, version, units, unit_price, material_id, order_element_template_id) FROM stdin;
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, code, name, generatecode, parent_id) FROM stdin;
303	3	329dc02d-b60f-435f-8cfa-5aa08bef3e1c	Imported materials without category	f	\N
3503792	2	06d08e21-3e05-43fe-b5eb-1fc43add6913	Tubos	t	303
3503794	2	cc2feab1-029f-43c3-b98b-880d966c1f72	Tubos de acero	t	3503792
3503795	2	5f3c985e-0523-4011-9c69-2eb8da831334	Tubos de cobre	t	3503792
3503793	2	0b94e18d-b2d2-4d15-8711-152c0bf97f2e	Acero	t	303
3503791	2	82ea64fe-7a26-49cf-89bc-8dd34dc2d758	obre	t	\N
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
3480763	1	Visor de pedidos
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled) FROM stdin;
1010	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f
1011	3	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f
1012	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f
1013	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f
3480864	1	visor	9533206da5708b1cfe5245917dbe7430297b79911f3dbf56e9f12b99ccd90fcbb6ccd1650fbb976c120e6809395da8354fa6a321a6e0ead331ce8c8d0c3c9be4	visor@visor.com	f
\.


--
-- Data for Name: order_authorization; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_authorization (id, order_authorization_subclass, version, authorizationtype, order_id, user_id, profile_id) FROM stdin;
2121	USER	5	WRITE_AUTHORIZATION	1836	1011	\N
13635	USER	8	WRITE_AUTHORIZATION	13434	1011	\N
3480965	PROFILE	2	READ_AUTHORIZATION	26969	\N	3480763
27169	USER	8	WRITE_AUTHORIZATION	26969	1011	\N
3505104	USER	6	WRITE_AUTHORIZATION	3505018	1011	\N
13637	USER	2	WRITE_AUTHORIZATION	13482	1011	\N
13636	USER	11	WRITE_AUTHORIZATION	13464	1011	\N
3836081	USER	6	WRITE_AUTHORIZATION	3835692	1011	\N
50096	USER	30	WRITE_AUTHORIZATION	49895	1011	\N
3510861	USER	43	WRITE_AUTHORIZATION	3510660	1011	\N
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
13434	1425
13464	1425
13465	1417
3835692	1425
\.


--
-- Data for Name: order_element_template_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_label (order_element_template_id, label_id) FROM stdin;
14862	1425
\.


--
-- Data for Name: order_element_template_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_template_quality_form (order_element_template_id, quality_form_id) FROM stdin;
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, dependenciesconstraintshavepriority, codeautogenerated, lastorderelementsequencecode, workbudget, materialsbudget, totalhours, customerreference, externalcode, state, customer, base_calendar_id) FROM stdin;
3835697	\N	\N	t	4	30000.00	0.00	100	COD-1	\N	5	1515	404
3466219	\N	\N	t	4	20000.00	0.00	300	\N	\N	1	1515	404
26969	Xavier Castaño	t	t	5	2000000.00	0.00	8700	DESC-1000	\N	0	1515	407
3505018	Xavier	t	t	8	50000.00	20000.00	230	\N	\N	0	1516	407
3505051	\N	\N	t	3	15000.00	0.00	50	code1.1	\N	5	1515	404
13482	\N	\N	t	12	0.00	0.00	1624	\N	\N	0	\N	404
1836	Xavi	t	t	12	50000.00	0.00	1624	B15804842	\N	0	1516	404
13434	\N	\N	t	4	20000.00	0.00	80	\N	\N	0	1516	404
13464	\N	\N	t	4	0.00	0.00	80	\N	\N	0	1516	404
3835692	\N	\N	t	4	0.00	0.00	80	\N	\N	0	\N	404
49895	\N	\N	t	83	621000.00	0.00	14570	\N	\N	0	\N	407
3510660	\N	\N	t	103	95000.00	0.00	9423	\N	\N	0	1515	404
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, description, code, initdate, deadline, schedulingstatetype, parent, template, externalcode, positionincontainer, lastadvancemeausurementforspreading, dirtylastadvancemeasurementforspreading) FROM stdin;
1848	6	Impermeabilización	\N	Navalplan-00001-00007	\N	\N	0	1836	\N	\N	6	\N	\N
13434	10	Laminado Moldeado	\N	Navalplan-00002	2010-05-06 19:31:14.452	2010-06-30 00:00:00	3	\N	\N	\N	\N	\N	\N
13435	8	Pegar tablillas	\N	Navalplan-00002-00001	\N	\N	0	13434	\N	\N	0	\N	\N
13436	8	Saturar interna y externamente con resina epoxy	\N	Navalplan-00002-00002	\N	\N	0	13434	\N	\N	1	\N	\N
13437	8	Colocar estructura in interior	\N	Navalplan-00002-00003	\N	\N	0	13434	\N	\N	2	\N	\N
13464	12	Laminado Moldeado Abril Navantia	\N	Navalplan-00003	2010-05-02 00:00:00	2010-07-29 00:00:00	3	\N	\N	\N	\N	0.52	f
13465	12	Pegar tablillas	\N	Navalplan-00003-00001	\N	\N	0	13464	14863	\N	0	1.00	f
13466	12	Saturar interna y externamente con resina epoxy	\N	Navalplan-00003-00002	\N	\N	0	13464	14864	\N	1	0.50	f
13467	12	Colocar estructura in interior	\N	Navalplan-00003-00003	\N	\N	0	13464	14865	\N	2	0.20	f
13468	12	Colocar malla fina	\N	Navalplan-00003-00004	\N	\N	0	13464	14866	\N	3	0.00	f
3835697	5	Descripción. Planificación	\N	Navalplan-00014	2010-01-01 00:00:00	2010-09-30 00:00:00	3	\N	\N	\N	\N	0.25	f
3835698	5	Subtarea 3	\N	Navalplan-00014-00001	2010-01-01 00:00:00	2010-09-30 00:00:00	0	3835705	\N	\N	0	0.00	f
3510739	24	Infraestructura de composición e colaboración de diferentes estratexias dispoñibles	\N	Navalplan-00012-00079	\N	\N	0	3510711	\N	\N	5	0.00	f
3510740	24	Modelo de dependencias	\N	Navalplan-00012-00080	\N	\N	0	3510711	\N	\N	6	0.00	f
3510741	24	Modelo de restriccións	\N	Navalplan-00012-00081	\N	\N	0	3510711	\N	\N	7	0.00	f
3510742	24	Modelos de clases para calendarios	\N	Navalplan-00012-00082	\N	\N	0	3510711	\N	\N	8	0.00	f
3510743	24	Modelo de clases de calendarios asociados a recursos	\N	Navalplan-00012-00083	\N	\N	0	3510711	\N	\N	9	0.00	f
13438	8	Colocar malla fina	\N	Navalplan-00002-00004	\N	\N	0	13434	\N	\N	3	\N	\N
13483	4	Fabricación en bancada	\N	Navalplan-00004-00001	\N	\N	3	13482	14907	\N	0	\N	\N
13482	4	Construcción de barco de recreo para Sergio Sumay	Desc.	Navalplan-00004	2010-05-07 08:54:00.144	2010-06-06 00:00:00	3	\N	\N	\N	\N	\N	\N
13484	3	Construcción de estructura transversal 	\N	Navalplan-00004-00008	\N	\N	0	13483	14908	\N	0	\N	\N
1836	7	Construcción de barco de recreo	Desc.	Navalplan-00001	2010-05-04 08:05:33.531	\N	3	\N	\N	\N	\N	\N	\N
1837	6	Fabricación en bancada	\N	Navalplan-00001-00001	\N	\N	3	1836	\N	\N	0	\N	\N
1838	6	Construcción de estructura transversal 	\N	Navalplan-00001-00008	\N	\N	0	1837	\N	\N	0	\N	\N
1839	6	Construcción de cavernas	\N	Navalplan-00001-00009	\N	\N	0	1837	\N	\N	1	\N	\N
1840	6	Construcción de anteparas	\N	Navalplan-00001-00010	\N	\N	0	1837	\N	\N	2	\N	\N
1841	6	Fijar estructura a base	\N	Navalplan-00001-00002	\N	\N	0	1836	\N	\N	1	\N	\N
1842	6	Unir quila	\N	Navalplan-00001-00003	\N	\N	0	1836	\N	\N	2	\N	\N
1843	6	Pegar terciado náutico	\N	Navalplan-00001-00004	\N	\N	0	1836	\N	\N	3	\N	\N
1844	6	Aplicar fibras de vidrio	\N	Navalplan-00001-00005	\N	\N	0	1836	\N	\N	4	\N	\N
1845	6	Lijado	\N	Navalplan-00001-00006	\N	\N	3	1836	\N	\N	5	\N	\N
1846	6	Lijado de cubierta	\N	Navalplan-00001-00011	\N	\N	0	1845	\N	\N	0	\N	\N
1847	6	Lijado de casco	\N	Navalplan-00001-00012	\N	\N	0	1845	\N	\N	1	\N	\N
13486	3	Construcción de anteparas	\N	Navalplan-00004-00010	\N	\N	0	13483	14910	\N	2	\N	\N
13487	3	Fijar estructura a base	\N	Navalplan-00004-00002	\N	\N	0	13482	14911	\N	1	\N	\N
13488	3	Unir quila	\N	Navalplan-00004-00003	\N	\N	0	13482	14912	\N	2	\N	\N
13489	3	Pegar terciado náutico	\N	Navalplan-00004-00004	\N	\N	0	13482	14913	\N	3	\N	\N
13490	3	Aplicar fibras de vidrio	\N	Navalplan-00004-00005	\N	\N	0	13482	14914	\N	4	\N	\N
13491	3	Lijado	\N	Navalplan-00004-00006	\N	\N	3	13482	14915	\N	5	\N	\N
13492	3	Lijado de cubierta	\N	Navalplan-00004-00011	\N	\N	0	13491	14916	\N	0	\N	\N
13493	3	Lijado de casco	\N	Navalplan-00004-00012	\N	\N	0	13491	14917	\N	1	\N	\N
13494	3	Impermeabilización	\N	Navalplan-00004-00007	\N	\N	0	13482	14918	\N	6	\N	\N
3466220	5	Construcción elemento 2	\N	Navalplan-00009-00001	2010-05-07 08:54:00.144	2010-05-19 08:54:00.144	0	3466221	\N	\N	0	\N	\N
3466219	6	Construcción de las cavernas	\N	Navalplan-00009	2010-05-07 08:54:00.144	2010-05-19 08:54:00.144	3	\N	\N	\N	\N	\N	\N
13485	4	Construcción de cavernas	\N	Navalplan-00004-00009	\N	\N	0	13483	14909	\N	1	\N	\N
26969	9	Construcción de barco de competición en acero	Desc.	Navalplan-00006	2010-06-10 00:00:00	2010-11-18 00:00:00	3	\N	\N	\N	\N	\N	\N
26970	8	Montaje de andamios	\N	Navalplan-00006-00001	\N	\N	0	26969	\N	\N	0	\N	\N
26971	8	Construcción del casco	\N	Navalplan-00006-00002	\N	\N	0	26969	\N	\N	1	\N	\N
26975	7	Construcción de cubierta	\N	Navalplan-00006-00003	\N	\N	0	26969	\N	\N	2	\N	\N
26976	7	Hélices	\N	Navalplan-00006-00004	\N	\N	0	26969	\N	\N	3	\N	\N
26977	7	Confección velamen	\N	Navalplan-00006-00005	\N	\N	0	26969	\N	\N	4	\N	\N
3835705	5	Planificación periódica	\N	Navalplan-00014-00002	2010-01-01 00:00:00	2010-09-30 00:00:00	3	3835697	\N	Navalplan-00012-00011	0	0.25	f
3835706	5	Subtarea 1 	\N	Navalplan-00014-00003	\N	\N	0	3835705	\N	\N	1	0.00	f
3835707	5	Subtarea 2	\N	Navalplan-00014-00004	\N	\N	0	3835705	\N	\N	2	0.50	f
3510694	39	Relacións institucionais	\N	Navalplan-00012-00036	\N	\N	0	3510690	\N	\N	2	0.00	f
3510695	39	Redaccións de actas de reunións	\N	Navalplan-00012-00037	\N	\N	0	3510690	\N	\N	3	0.00	f
3510696	39	Definición de alcance	\N	Navalplan-00012-00038	\N	\N	0	3510690	\N	\N	4	0.00	f
3510697	39	Reunións presentación, fitos e outros implicados	\N	Navalplan-00012-00039	\N	\N	0	3510690	\N	\N	5	0.00	f
3510744	23	Modelo de función plana	\N	Navalplan-00012-00084	\N	\N	0	3510711	\N	\N	10	0.00	f
3510745	23	Modelo de función lineal por tramos	\N	Navalplan-00012-00085	\N	\N	0	3510711	\N	\N	11	0.00	f
3510746	23	Modelo de función de curvas S	\N	Navalplan-00012-00086	\N	\N	0	3510711	\N	\N	12	0.00	f
3510747	23	Modelo de asignación segundo a cadea crítica	\N	Navalplan-00012-00087	\N	\N	0	3510711	\N	\N	13	0.00	f
3510698	39	Probas de integración, aceptación e funcionais	\N	Navalplan-00012-00034	\N	\N	0	3510660	\N	\N	9	0.00	f
3510699	39	Implantación en 5 empresas do sector	\N	Navalplan-00012-00035	\N	\N	3	3510660	\N	\N	10	0.00	f
3510700	39	Definición do proceso de implantación	\N	Navalplan-00012-00040	\N	\N	0	3510699	\N	\N	0	0.00	f
3510701	39	Control do proceso de implentación	\N	Navalplan-00012-00041	\N	\N	0	3510699	\N	\N	1	0.00	f
3510702	39	Seguimento do proceso de implantación	\N	Navalplan-00012-00042	\N	\N	0	3510699	\N	\N	2	0.00	f
3510703	39	Verificación do proceso de implantación	\N	Navalplan-00012-00043	\N	\N	0	3510699	\N	\N	3	0.00	f
3510704	39	Implantación do proxecto en cada empresa	\N	Navalplan-00012-00044	\N	\N	0	3510699	\N	\N	4	0.00	f
3466221	5	Construcción de cavernas	\N	Navalplan-00009-00002	2010-05-07 08:54:00.144	2010-05-19 08:54:00.144	3	3466219	\N	Navalplan-00004-00009	0	\N	\N
3466222	5	Construcción elemento 1	\N	Navalplan-00009-00004	\N	\N	0	3466221	\N	\N	1	\N	\N
3466223	5	Construcción elemento 3	\N	Navalplan-00009-00003	\N	\N	0	3466221	\N	\N	2	\N	\N
3510706	38	Módulo de arquitectura	\N	Navalplan-00012-00046	\N	\N	3	3510660	\N	\N	4	0.00	f
3510707	38	Deseño de paquetes e estrutura interna da librería	\N	Navalplan-00012-00048	\N	\N	0	3510706	\N	\N	1	0.00	f
3510708	38	Definición de documentación	\N	Navalplan-00012-00049	\N	\N	0	3510706	\N	\N	2	0.00	f
3510709	38	Deseño de conversacións con librería	\N	Navalplan-00012-00050	\N	\N	0	3510706	\N	\N	3	0.00	f
3510710	38	Deseño e implementación de soporte de fases de proceso coa librería	\N	Navalplan-00012-00051	\N	\N	0	3510706	\N	\N	4	0.00	f
3510711	38	Módulo de representación de información	\N	Navalplan-00012-00047	\N	\N	3	3510660	\N	\N	5	0.00	f
3510712	38	Modelo de recursos con capacidade variable	\N	Navalplan-00012-00052	\N	\N	0	3510711	\N	\N	1	0.00	f
3510713	38	Modelo de capacidade variable ata un máximo	\N	Navalplan-00012-00053	\N	\N	0	3510711	\N	\N	2	0.00	f
3510714	38	Modelo de clase para os criterios	\N	Navalplan-00012-00054	\N	\N	0	3510711	\N	\N	3	0.00	f
3510715	38	Modelo de clases de recursos limitados	\N	Navalplan-00012-00055	\N	\N	0	3510711	\N	\N	4	0.00	f
3510748	22	Avaliación de proxecto segundo cadea crítica	\N	Navalplan-00012-00088	\N	\N	0	3510716	\N	\N	6	0.00	f
3510749	22	Servizo de configuración de asignación de recursos	\N	Navalplan-00012-00089	\N	\N	0	3510716	\N	\N	7	0.00	f
3510750	22	Algoritmo de asignación de recursos tendo en conta a capacidade máxima	\N	Navalplan-00012-00090	\N	\N	0	3510716	\N	\N	8	0.00	f
3510751	22	Algoritmo de recursos limitantes con cumprimento de datas de fin	\N	Navalplan-00012-00091	\N	\N	0	3510716	\N	\N	9	0.00	f
3510752	22	Algoritmo de realización de asignacións dando prioridade a deadlines	\N	Navalplan-00012-00092	\N	\N	0	3510716	\N	\N	10	0.00	f
3510753	22	Configuración de planificación a nivelar	\N	Navalplan-00012-00093	\N	\N	0	3510716	\N	\N	11	0.00	f
3505018	9	Developt a project	Desc.	Navalplan-00010	2010-05-17 17:54:19.322	2010-09-24 00:00:00	3	\N	\N	\N	\N	\N	\N
3510716	37	Módiulo de planificación	\N	Navalplan-00012-00056	\N	\N	3	3510660	\N	\N	6	0.00	f
3510717	37	Modo de análise cara atrás. Planificación fiin a inicio.	\N	Navalplan-00012-00057	\N	\N	0	3510716	\N	\N	1	0.00	f
3510718	37	Algoritmo de camiño crítico sobre unha rede de tarefas	\N	Navalplan-00012-00058	\N	\N	0	3510716	\N	\N	2	0.00	f
3510719	37	Servizo para cálculo de cadea crítica	\N	Navalplan-00012-00059	\N	\N	0	3510716	\N	\N	3	0.00	f
3510720	37	Método de Montecarlo para simulacións de risco	\N	Navalplan-00012-00060	\N	\N	0	3510716	\N	\N	4	0.00	f
3510721	37	Modificación de asignacións seguindo indicacións da cadea crítica	\N	Navalplan-00012-00061	\N	\N	0	3510716	\N	\N	5	0.00	f
3510754	20	API de avaliación e comparación dos resultados de cálculo de planificación	\N	Navalplan-00012-00094	\N	\N	0	3510734	\N	\N	5	0.00	f
3510755	20	API de extracción comunicación XML	\N	Navalplan-00012-00095	\N	\N	0	3510734	\N	\N	6	0.00	f
3510756	20	API de extracción de comunicación XML	\N	Navalplan-00012-00096	\N	\N	0	3510734	\N	\N	7	0.00	f
3505044	6	Task 1.1	\N	Navalplan-00010-00004	\N	\N	0	3505043	\N	\N	0	\N	\N
3505045	6	Task 1.3	\N	Navalplan-00010-00005	\N	\N	0	3505043	\N	\N	1	\N	\N
3505047	6	Task 2	\N	Navalplan-00010-00002	\N	\N	0	3505018	\N	\N	1	\N	\N
3505048	6	Subtask 2.3	\N	Navalplan-00010-00007	\N	\N	1	3505047	\N	\N	0	\N	\N
3505049	6	Subtask 2.1	\N	Navalplan-00010-00008	\N	\N	1	3505047	\N	\N	1	\N	\N
3505050	6	Subtask 2.2	\N	Navalplan-00010-00003	\N	\N	1	3505047	\N	\N	2	\N	\N
3505046	7	Subtask 1.2	\N	Navalplan-00010-00006	\N	\N	0	3505043	\N	\N	2	\N	\N
49895	35	Openapps - Invattur	\N	Navalplan-00008	2010-06-01 00:00:00	2011-01-31 00:00:00	2	\N	\N	\N	\N	0.00	f
49896	30	Coordinación del proyecto	\N	Navalplan-00008-00001	\N	\N	0	49895	\N	\N	0	0.00	f
49908	28	Definición de modelo de negocio	\N	Navalplan-00008-00013	\N	\N	0	49895	\N	\N	1	0.00	f
3713366	14	Avaliación de propostas 	\N	Navalplan-00012-00097	\N	\N	0	3510690	\N	\N	6	0.00	f
3510722	36	Módulo de interfaz	\N	Navalplan-00012-00062	\N	\N	3	3510660	\N	\N	7	0.00	f
49909	28	Análisis y diseño	\N	Navalplan-00008-00014	\N	\N	0	49895	\N	\N	2	0.00	f
3505043	7	Task 1	\N	Navalplan-00010-00001	\N	2010-08-17 00:00:00	3	3505018	\N	\N	0	\N	\N
49910	26	Sistema de Gestión de Reservas	\N	Navalplan-00008-00015	\N	\N	4	49895	\N	\N	3	0.00	f
3510723	36	Planificación segundo o cálculo de cadea critica	\N	Navalplan-00012-00063	\N	\N	0	3510722	\N	\N	1	0.00	f
49911	26	Gestor de establicimientos	\N	Navalplan-00008-00017	\N	\N	4	49910	\N	\N	0	0.00	f
49898	30	Gestor de productos	\N	Navalplan-00008-00003	\N	\N	4	49910	\N	\N	1	0.00	f
49912	26	Gestor de tarifas	\N	Navalplan-00008-00018	\N	\N	4	49910	\N	\N	2	0.00	f
49913	26	Gestor temporadas	\N	Navalplan-00008-00019	\N	\N	4	49910	\N	\N	3	0.00	f
49914	26	Gestor de clientes	\N	Navalplan-00008-00020	\N	\N	4	49910	\N	\N	4	0.00	f
49915	26	Gestor de cupos	\N	Navalplan-00008-00021	\N	\N	4	49910	\N	\N	5	0.00	f
49916	26	Gestor de pagos	\N	Navalplan-00008-00022	\N	\N	4	49910	\N	\N	6	0.00	f
49917	26	Gestor de tipos de habitación	\N	Navalplan-00008-00023	\N	\N	4	49910	\N	\N	7	0.00	f
49918	26	Gestor de reservas	\N	Navalplan-00008-00024	\N	\N	4	49910	\N	\N	8	0.00	f
49919	26	Gestor de usuarios	\N	Navalplan-00008-00025	\N	\N	4	49910	\N	\N	9	0.00	f
49920	26	Generador de alertas condicionadas al estado de las reservas	\N	Navalplan-00008-00026	\N	\N	4	49910	\N	\N	10	0.00	f
49921	26	Gestión de comisiones y retribuciones	\N	Navalplan-00008-00027	\N	\N	4	49910	\N	\N	11	0.00	f
49922	26	Sistema acceso personalizado	\N	Navalplan-00008-00028	\N	\N	4	49910	\N	\N	12	0.00	f
49923	26	Gestión de inventario y rentabilización	\N	Navalplan-00008-00029	\N	\N	4	49910	\N	\N	13	0.00	f
49924	26	Gestor de paquetes dinámicos	\N	Navalplan-00008-00030	\N	\N	4	49910	\N	\N	14	0.00	f
49925	26	Implementación XML OTA para consumo de datos	\N	Navalplan-00008-00031	\N	\N	4	49910	\N	\N	15	0.00	f
49926	26	Refactorización y optimización	\N	Navalplan-00008-00032	\N	\N	4	49910	\N	\N	16	0.00	f
49933	25	Gestor de disponibilidad y rejillas visuales de ocupación	\N	Navalplan-00008-00038	\N	\N	4	49928	\N	\N	5	0.00	f
49934	25	Búsqueda de reservas	\N	Navalplan-00008-00039	\N	\N	4	49928	\N	\N	6	0.00	f
49935	25	Optimización de habitaciones	\N	Navalplan-00008-00040	\N	\N	4	49928	\N	\N	7	0.00	f
49936	25	Gestión de facturación	\N	Navalplan-00008-00041	\N	\N	4	49928	\N	\N	8	0.00	f
3505051	4	Ship paint	\N	Navalplan-00011	2010-05-17 17:54:19.322	2010-06-23 00:00:00	4	\N	\N	\N	\N	\N	\N
3505052	4	specific 1.2.2	\N	Navalplan-00011-00001	2010-05-17 17:54:19.322	2010-06-23 00:00:00	4	3505059	\N	\N	0	\N	\N
49937	25	Planning de gestión con interfaz gráfica	\N	Navalplan-00008-00042	\N	\N	4	49928	\N	\N	9	0.00	f
49943	22	Sistema de inteligencia de negocio (BI)	\N	Navalplan-00008-00048	\N	\N	4	49927	\N	\N	1	0.00	f
49944	22	Asistente para la creación de informes e indicadores	\N	Navalplan-00008-00049	\N	\N	4	49943	\N	\N	0	0.00	f
49939	24	Ejecución automática de informes	\N	Navalplan-00008-00044	\N	\N	4	49943	\N	\N	1	0.00	f
3713367	10	Xestión do e equipo de traballo	\N	Navalplan-00012-00098	\N	\N	4	3510690	\N	\N	7	0.00	f
3713368	10	Xestión e seguimento do proxecto	\N	Navalplan-00012-00099	\N	\N	4	3510690	\N	\N	8	0.00	f
3713369	10	Redacción de propostas	\N	Navalplan-00012-00100	\N	\N	4	3510690	\N	\N	9	0.00	f
3713370	10	Xestión de relación con empresas e outros implicados	\N	Navalplan-00012-00101	\N	\N	4	3510690	\N	\N	10	0.00	f
3713371	10	Xestión de incidencias, riscos, cambios de alcance, etc.	\N	Navalplan-00012-00102	\N	\N	4	3510690	\N	\N	11	0.00	f
3510724	35	Solicitar cálculo de cadea crítica	\N	Navalplan-00012-00066	\N	\N	0	3510722	\N	\N	2	0.00	f
3510725	35	Seguimento aplicación cadea crítica	\N	Navalplan-00012-00067	\N	\N	0	3510722	\N	\N	3	0.00	f
3510726	35	Modificación asignación de recursos NavalPlan para poder interactuar con librería de cálculo de solucións de asignación.	\N	Navalplan-00012-00068	\N	\N	0	3510722	\N	\N	4	0.00	f
3510727	35	Interfaz para solicitud/recepción de nivelación de planificación sobre datos de planificación.	\N	Navalplan-00012-00069	\N	\N	0	3510722	\N	\N	5	0.00	f
49953	21	Análisis dinámicos	\N	Navalplan-00008-00058	\N	\N	4	49943	\N	\N	2	0.00	f
49954	21	Panel interactivo (Dashboard)	\N	Navalplan-00008-00059	\N	\N	4	49943	\N	\N	3	0.00	f
49955	21	Análisis diferencial y herramientas de predicción	\N	Navalplan-00008-00060	\N	\N	4	49943	\N	\N	4	0.00	f
49956	21	Data mining	\N	Navalplan-00008-00061	\N	\N	4	49943	\N	\N	5	0.00	f
49957	21	Creación de sistema de alertas configurables para indicadores	\N	Navalplan-00008-00062	\N	\N	4	49943	\N	\N	6	0.00	f
49940	23	Sistema de gestión de relaciones (CRM)	\N	Navalplan-00008-00045	\N	\N	4	49927	\N	\N	2	0.00	f
49941	23	Administración de cuentas y contactos	\N	Navalplan-00008-00046	\N	\N	4	49940	\N	\N	0	0.00	f
49942	23	Cuadro de oportunidades y tendencias	\N	Navalplan-00008-00047	\N	\N	4	49940	\N	\N	1	0.00	f
49938	24	Gestor de historial de clientes	\N	Navalplan-00008-00043	\N	\N	4	49940	\N	\N	2	0.00	f
49945	22	Gestor de mailings	\N	Navalplan-00008-00050	\N	\N	4	49940	\N	\N	3	0.00	f
49947	22	Gestor de tareas	\N	Navalplan-00008-00052	\N	\N	4	49940	\N	\N	5	0.00	f
2394116	5	Pruebas de integración	\N	Navalplan-00008-00082	\N	\N	4	49895	\N	\N	12	0.00	f
2394117	5	Gestión del entorno y configuración	\N	Navalplan-00008-00083	\N	\N	4	49895	\N	\N	13	0.00	f
3510660	48	Sistema de computo de solucións a problemas de planificación	O sistema consistirá nun motor de calculo que permita unha variedade ampla de algoritmos de planificación. 	Navalplan-00012	2010-01-01 00:00:00	2010-09-30 00:00:00	2	\N	\N	\N	\N	0.00	f
3713372	9	Formación	\N	Navalplan-00012-00103	\N	\N	0	3510660	\N	\N	11	0.00	f
49946	22	Gestor de programas de fidelización (copy)	\N	Navalplan-00008-00051	\N	\N	4	49940	\N	\N	4	0.00	f
49948	22	Gestor de clientes especiales	\N	Navalplan-00008-00053	\N	\N	4	49940	\N	\N	6	0.00	f
49949	22	Gestor de perfiles de cliente	\N	Navalplan-00008-00054	\N	\N	4	49940	\N	\N	7	0.00	f
49950	22	Gestor de incidencias y seguimiento	\N	Navalplan-00008-00055	\N	\N	4	49940	\N	\N	8	0.00	f
49951	22	Gestor de seguimiento de campañas	\N	Navalplan-00008-00056	\N	\N	4	49940	\N	\N	9	0.00	f
3505059	4	Subtask 1.2	\N	Navalplan-00011-00002	2010-05-17 17:54:19.322	2010-06-23 00:00:00	4	3505051	\N	Navalplan-00010-00006	0	\N	\N
3505060	4	specific 1.2.1	\N	Navalplan-00011-00003	\N	\N	4	3505059	\N	\N	1	\N	\N
49952	22	Gestor de proyectos	\N	Navalplan-00008-00057	\N	\N	4	49940	\N	\N	10	0.00	f
49900	29	Gestión de Canal	\N	Navalplan-00008-00005	\N	\N	4	49895	\N	\N	5	0.00	f
49958	20	Sistema de gestión de canal	\N	Navalplan-00008-00063	\N	\N	4	49900	\N	\N	0	0.00	f
49902	29	Integración con PMS	\N	Navalplan-00008-00012	\N	\N	4	49958	\N	\N	0	0.00	f
49959	20	Gesor de precios, cupos y reservas	\N	Navalplan-00008-00064	\N	\N	4	49958	\N	\N	1	0.00	f
49960	20	Gestor de tarifas	\N	Navalplan-00008-00065	\N	\N	4	49958	\N	\N	2	0.00	f
49961	20	Gesor de cierre de ventas	\N	Navalplan-00008-00066	\N	\N	4	49958	\N	\N	3	0.00	f
49962	20	Informe predefinidos	\N	Navalplan-00008-00067	\N	\N	4	49958	\N	\N	4	0.00	f
49963	20	Gestor de alertas	\N	Navalplan-00008-00068	\N	\N	4	49958	\N	\N	5	0.00	f
49964	20	Gestor de divisas	\N	Navalplan-00008-00069	\N	\N	4	49958	\N	\N	6	0.00	f
49965	20	Soporte de gestión asíncrona	\N	Navalplan-00008-00070	\N	\N	4	49958	\N	\N	7	0.00	f
49966	20	Interfaz acceso agencias de viajes	\N	Navalplan-00008-00071	\N	\N	4	49900	\N	\N	1	0.00	f
49967	19	Sistema de gestión de contenidos	\N	Navalplan-00008-00072	\N	\N	4	49895	\N	\N	6	0.00	f
49968	19	Módulo de gestión de usuarios y perfiles	\N	Navalplan-00008-00073	\N	\N	4	49967	\N	\N	0	0.00	f
49969	19	Módulo de valoración	\N	Navalplan-00008-00074	\N	\N	4	49967	\N	\N	1	0.00	f
49903	29	Módulo de reserva online	\N	Navalplan-00008-00006	\N	\N	4	49967	\N	\N	2	0.00	f
49970	19	Arquitectura información y gestión de contenidos	\N	Navalplan-00008-00075	\N	\N	4	49967	\N	\N	3	0.00	f
49971	19	Accesibilidad	\N	Navalplan-00008-00076	\N	\N	4	49967	\N	\N	4	0.00	f
49972	19	Módulo de establecimientos	\N	Navalplan-00008-00077	\N	\N	4	49967	\N	\N	5	0.00	f
49973	19	Módulo multiportal	\N	Navalplan-00008-00078	\N	\N	4	49967	\N	\N	6	0.00	f
3510661	42	Coordinación interna	\N	Navalplan-00012-00001	\N	\N	3	3510660	\N	\N	1	0.13	f
3510662	42	Informes de seguimento	\N	Navalplan-00012-00010	\N	\N	0	3510661	\N	\N	0	0.60	f
3510663	42	Planificación periódica	\N	Navalplan-00012-00011	\N	\N	0	3510661	\N	\N	1	0.00	f
3510664	42	Reunións internas	\N	Navalplan-00012-00012	\N	\N	0	3510661	\N	\N	2	0.00	f
3510665	42	Reunións seguimento con implicados	\N	Navalplan-00012-00013	\N	\N	0	3510661	\N	\N	3	0.00	f
3510666	42	Control do estado do proxecto	\N	Navalplan-00012-00014	\N	\N	0	3510661	\N	\N	4	0.00	f
3510667	42	Control de calidade do proxecto	\N	Navalplan-00012-00015	\N	\N	0	3510661	\N	\N	5	0.00	f
3510668	42	Xestión de riscos, incidencias e compromisos	\N	Navalplan-00012-00016	\N	\N	0	3510661	\N	\N	6	0.00	f
3510669	42	Análise	\N	Navalplan-00012-00002	\N	\N	3	3510660	\N	\N	2	0.00	f
3510670	42	Estudio de alternativas algoritmos de planificación	\N	Navalplan-00012-00017	\N	\N	0	3510669	\N	\N	0	0.00	f
3510671	42	Análise do módulo de arquitectura	\N	Navalplan-00012-00018	\N	\N	0	3510669	\N	\N	1	0.00	f
3510672	42	Análise do módulo de representación	\N	Navalplan-00012-00019	\N	\N	0	3510669	\N	\N	2	0.00	f
3510673	42	Análise do módulo de planificación	\N	Navalplan-00012-00020	\N	\N	0	3510669	\N	\N	3	0.00	f
3510674	42	Análise de interfaz uso da librería	\N	Navalplan-00012-00021	\N	\N	0	3510669	\N	\N	4	0.00	f
3510676	42	Montaxe infraestructura de probas	\N	Navalplan-00012-00003	\N	\N	0	3510683	\N	\N	0	0.00	f
3510677	42	Deseño de API's e fachadas para comunicación	\N	Navalplan-00012-00004	\N	\N	0	3510706	\N	\N	0	0.00	f
3510678	42	Modelo de clases básicas para representar a información de recursos e asignar as planificacións	\N	Navalplan-00012-00005	\N	\N	0	3510711	\N	\N	0	0.00	f
3510679	42	Modo de análise cara adiante. Planificación inicio a fin.	\N	Navalplan-00012-00006	\N	\N	0	3510716	\N	\N	0	0.00	f
3510680	42	Interfaz para soporte de recursos con máximo de capacidade non sobrepasable en asignación.	\N	Navalplan-00012-00007	\N	\N	0	3510722	\N	\N	0	0.00	f
3510682	42	API de carga de comunicación con Navalplan	\N	Navalplan-00012-00009	\N	\N	0	3510734	\N	\N	0	0.00	f
3835693	7	Pegar tablillas	\N	Navalplan-00013-00001	\N	\N	0	3835692	14863	\N	0	0.50	f
3835694	7	Saturar interna y externamente con resina epoxy	\N	Navalplan-00013-00002	\N	\N	0	3835692	14864	\N	1	0.50	f
3835695	7	Colocar estructura in interior	\N	Navalplan-00013-00003	\N	\N	0	3835692	14865	\N	2	0.20	f
3835696	7	Colocar malla fina	\N	Navalplan-00013-00004	\N	\N	0	3835692	14866	\N	3	0.30	f
49927	26	Sistema de Gestión de Empresas	\N	Navalplan-00008-00016	\N	\N	4	49895	\N	\N	4	0.00	f
49928	26	Sistema de gestión de propiedades (PMS)	\N	Navalplan-00008-00033	\N	\N	4	49927	\N	\N	0	0.00	f
49929	26	Gestor de usuarios y perfiles	\N	Navalplan-00008-00034	\N	\N	4	49928	\N	\N	0	0.00	f
49899	29	Dashboard	\N	Navalplan-00008-00004	\N	\N	4	49928	\N	\N	1	0.00	f
49930	25	Generación de informes	\N	Navalplan-00008-00035	\N	\N	4	49928	\N	\N	2	0.00	f
49931	25	Gestor de habitaciones	\N	Navalplan-00008-00036	\N	\N	4	49928	\N	\N	3	0.00	f
3510690	40	Xestión proxecto Aclunaga	\N	Navalplan-00012-00030	\N	\N	2	3510660	\N	\N	0	0.00	f
3510692	40	Revisión documentación socio tecnolóxico	\N	Navalplan-00012-00032	\N	\N	0	3510690	\N	\N	0	0.00	f
49932	25	Gestor de inventario	\N	Navalplan-00008-00037	\N	\N	4	49928	\N	\N	4	0.00	f
49974	19	Infraestructura portal	\N	Navalplan-00008-00079	\N	\N	4	49967	\N	\N	7	0.00	f
49975	19	Diseño gráfico portal	\N	Navalplan-00008-00080	\N	\N	4	49967	\N	\N	8	0.00	f
49904	29	Repositorio multimedia	\N	Navalplan-00008-00007	\N	\N	4	49895	\N	\N	7	0.00	f
49905	29	Orquestador	\N	Navalplan-00008-00008	\N	\N	4	49895	\N	\N	8	0.00	f
49906	29	Documentación	\N	Navalplan-00008-00009	\N	\N	4	49895	\N	\N	9	0.00	f
49907	29	Implantación	\N	Navalplan-00008-00010	\N	\N	4	49895	\N	\N	10	0.00	f
3510693	40	Revisión informes seguimento	\N	Navalplan-00012-00033	\N	\N	0	3510690	\N	\N	1	0.00	f
49976	16	Formación	\N	Navalplan-00008-00081	\N	\N	4	49895	\N	\N	11	0.00	f
3510683	41	Probas unidade	\N	Navalplan-00012-00023	\N	\N	3	3510660	\N	\N	3	0.00	f
3510684	41	Probas de unidade do modulo de arquitectura	\N	Navalplan-00012-00024	\N	\N	0	3510683	\N	\N	1	0.00	f
3510685	41	Probas de unidade do módulo de representación	\N	Navalplan-00012-00025	\N	\N	0	3510683	\N	\N	2	0.00	f
3510686	41	Probas de unidade do módulo de planificación	\N	Navalplan-00012-00026	\N	\N	0	3510683	\N	\N	3	0.00	f
3510689	41	Probas da interfaz da librería	\N	Navalplan-00012-00029	\N	\N	0	3510683	\N	\N	4	0.00	f
3510734	34	Módulo de entradas/saídas	\N	Navalplan-00012-00074	\N	\N	3	3510660	\N	\N	8	0.00	f
3510735	34	API de carga de comunicación vía XML	\N	Navalplan-00012-00075	\N	\N	0	3510734	\N	\N	1	0.00	f
3510736	34	API de preprocesamento e análise de datos	\N	Navalplan-00012-00076	\N	\N	0	3510734	\N	\N	2	0.00	f
3510737	34	API de configuración de elaboración do proceso de planificación	\N	Navalplan-00012-00077	\N	\N	0	3510734	\N	\N	3	0.00	f
3510738	34	API de execusión do proceso de cálculo de planificación	\N	Navalplan-00012-00078	\N	\N	0	3510734	\N	\N	4	0.00	f
3835692	7	Laminado Moldeado Template	\N	Navalplan-00013	2010-05-18 00:00:00	2010-06-16 00:00:00	3	\N	\N	\N	\N	0.41	f
\.


--
-- Data for Name: orderelementtemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelementtemplate (id, version, name, description, code, startasdaysfrombeginning, deadlineasdaysfrombeginning, schedulingstatetype, parent, positionincontainer) FROM stdin;
14862	1	Laminado Moldeado Template	\N	Navalplan-00002	0	54	3	\N	\N
14863	1	Pegar tablillas	\N	Navalplan-00002-00001	\N	\N	0	14862	0
14864	1	Saturar interna y externamente con resina epoxy	\N	Navalplan-00002-00002	\N	\N	0	14862	1
14865	1	Colocar estructura in interior	\N	Navalplan-00002-00003	\N	\N	0	14862	2
14866	1	Colocar malla fina	\N	Navalplan-00002-00004	\N	\N	0	14862	3
14906	1	Construcción de barco de recreo Template	Desc.	Navalplan-00001	5	30	3	\N	\N
14907	1	Fabricación en bancada	\N	Navalplan-00001-00001	\N	\N	3	14906	0
14911	1	Fijar estructura a base	\N	Navalplan-00001-00002	\N	\N	0	14906	1
14912	1	Unir quila	\N	Navalplan-00001-00003	\N	\N	0	14906	2
14913	1	Pegar terciado náutico	\N	Navalplan-00001-00004	\N	\N	0	14906	3
14914	1	Aplicar fibras de vidrio	\N	Navalplan-00001-00005	\N	\N	0	14906	4
14915	1	Lijado	\N	Navalplan-00001-00006	\N	\N	3	14906	5
14918	1	Impermeabilización	\N	Navalplan-00001-00007	\N	\N	0	14906	6
14908	1	Construcción de estructura transversal 	\N	Navalplan-00001-00008	\N	\N	0	14907	0
14909	1	Construcción de cavernas	\N	Navalplan-00001-00009	\N	\N	0	14907	1
14910	1	Construcción de anteparas	\N	Navalplan-00001-00010	\N	\N	0	14907	2
14916	1	Lijado de cubierta	\N	Navalplan-00001-00011	\N	\N	0	14915	0
14917	1	Lijado de casco	\N	Navalplan-00001-00012	\N	\N	0	14915	1
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid, lasthoursgroupsequencecode) FROM stdin;
3505052	1
13465	1
13466	1
13467	1
13468	1
3510739	1
3510740	1
3510741	1
3510742	1
3510743	1
3510754	1
3510755	1
3510756	1
3713372	1
3835698	1
13484	1
13485	1
13486	1
13487	1
13488	1
13489	1
13490	1
13492	1
13493	1
13494	1
1838	1
1839	1
1840	1
1841	1
1842	1
1843	1
1844	1
1846	1
1847	1
1848	1
13435	1
13436	1
13437	1
13438	1
26970	2
26971	3
26975	1
26976	1
26977	1
3510692	1
3510693	1
3510694	1
3510695	1
3510696	1
3510697	1
3713366	1
3510662	1
3510663	1
3510664	1
3510665	1
3510666	1
3510667	1
3510668	1
3510670	1
3510671	1
3510672	1
3510673	1
3510674	1
3510676	1
3510684	1
3510685	1
3510686	1
3510689	1
3510677	1
3510707	1
3510708	1
3510709	1
3510710	1
3510744	1
3510745	1
3510746	1
3510747	1
3510717	1
3510718	1
3510719	1
3835706	1
3835707	1
3505044	1
3505045	1
3505046	1
3505048	1
3505049	1
3505050	1
3505060	1
49896	2
49908	1
49909	1
49911	1
49898	1
49912	1
49913	1
49914	1
49915	1
49916	1
49917	1
49918	1
49919	1
49920	1
49921	1
49922	1
49923	1
49924	1
3466220	1
3466222	1
3466223	1
49925	1
49926	1
49929	1
49899	1
49930	1
49931	1
49932	1
49933	1
49934	1
49935	1
49936	1
49937	1
49944	1
49939	1
49953	1
49954	1
49955	1
49956	1
49957	1
49941	1
49942	1
49938	1
49945	1
49946	1
49947	1
49948	1
49949	1
49950	1
49951	1
49952	1
49902	1
49959	1
49960	1
49961	1
49962	1
3713367	1
3713368	1
3713369	1
3713370	1
3713371	1
3510678	1
3510712	1
3510713	1
3510714	1
3510715	1
3510679	1
3510720	1
3510721	1
3510748	1
3510749	1
3510750	1
3835693	1
3835694	1
3835695	1
3835696	1
49963	1
49964	1
49965	1
49966	1
49968	1
49969	1
49903	1
49970	1
49971	1
49972	1
49973	1
49974	1
49975	1
49904	1
49905	1
49906	1
49907	1
49976	1
2394116	1
2394117	1
3510751	1
3510752	1
3510753	1
3510680	1
3510723	1
3510724	1
3510725	1
3510726	1
3510727	1
3510682	1
3510735	1
3510736	1
3510737	1
3510738	1
3510698	1
3510700	1
3510701	1
3510702	1
3510703	1
3510704	1
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1836
1837
1845
13434
13464
13482
13483
13491
26969
49895
49900
49910
49927
49928
49940
49943
49958
49967
3466219
3466221
3505018
3505043
3505047
3505051
3505059
3510660
3510661
3510669
3510683
3510690
3510699
3510706
3510711
3510716
3510722
3510734
3835692
3835697
3835705
\.


--
-- Data for Name: orderlinegrouptemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegrouptemplate (group_template_id) FROM stdin;
14862
14906
14907
14915
\.


--
-- Data for Name: orderlinetemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinetemplate (order_line_template_id, lasthoursgroupsequencecode) FROM stdin;
14863	0
14864	0
14865	0
14866	0
14908	0
14909	0
14910	0
14911	0
14912	0
14913	0
14914	0
14916	0
14917	0
14918	0
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
707	20	Navalplan	14	5	t
\.


--
-- Data for Name: ordertemplate; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordertemplate (order_template_id, base_calendar_id) FROM stdin;
14862	404
14906	404
\.


--
-- Data for Name: pending_consolidated_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY pending_consolidated_hours (pending_hours_id, pendingconsolidatedhours, resource_allocation_id) FROM stdin;
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
3480763	ROLE_READ_ALL_ORDERS
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype, reportadvance, advance_type_id) FROM stdin;
3503993	1	Cuestionario calidade estandar		0	t	3480461
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
3503993	¿Rematouse o paso 1?	20.00	0	0
3503993	¿Rematouse o paso 2?	40.00	1	1
3503993	¿Rematouse o paso 3?	67.00	2	2
3503993	¿Rematouse o paso 4?	90.00	3	3
3503993	¿Rematouse o paso 5?	100.00	4	4
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, code, generatecode, limited_resource, base_calendar_id) FROM stdin;
3513189	1	6b931aa0-c4e0-4d21-ac5f-1882db8f0d7b	t	f	3513287
1123	31	e7262a78-843b-4250-a0e9-1a65a069e4c6	t	f	417
39003	2	9244274c-0994-4538-b920-2d3f5166001b	t	f	39094
1115	3	3ca4b534-5160-400f-99ce-dd5801433e6e	t	f	412
1130	24	78e0701b-490e-4ba5-a0c6-d595c41a669d	t	f	420
39005	3	5cb253e5-0de7-4e6c-9563-b77bcf257bfb	t	f	39095
1126	18	95eb279c-f82e-4ce6-9073-d3592c4ad2d6	t	f	418
14345	4	c4376055-55fd-460c-b0fd-2aaef66b1734	t	f	14444
38993	3	ecff19bb-fc76-4d4a-b9e5-06b863f3fcf0	t	f	39089
39017	2	c7ac7af9-8f13-417c-9b46-75427c20c008	t	f	39101
39022	2	4438b0d3-3101-48ae-b11a-4cc1e53f9835	t	f	39103
1132	3	5ae0aa09-efa1-43ca-97ab-e602d19f5974	t	f	421
39015	3	8115deeb-045c-438c-94ca-a3a1682b0d39	t	f	39100
3513187	18	02120ed8-893f-4cb6-9fc3-26df85700981	t	f	3513286
1117	2	61a07e75-96cd-43dd-b8b5-b3c483212d01	t	f	413
3513185	2	3a88b32a-f2e3-4f2c-8edc-abb403de029d	t	f	3513285
1113	2	3c324240-63e0-445a-bcf5-0b314b59afcc	t	f	410
1136	2	91324863-6b57-4872-bd7c-6efd2eb8a63e	t	f	423
38999	2	a0ce3e65-c053-4fc4-8f5e-6ee9395f4423	t	f	39092
39020	2	94aa93dd-49a2-43c8-9041-c485844fbb9c	t	f	39102
3504499	4	b05c3d82-13e9-4d5a-a0ea-81be92868fc6	t	f	3504599
39007	2	4fe9732b-cd03-42ce-8dd1-ae4187456c97	t	f	39096
26463	3	be0c73e7-c14a-407d-b7dd-de0b19b353f4	t	f	26563
39011	2	63ba508e-2573-459f-8a97-928e2cae2e43	t	f	39098
38991	8	8cf7b604-407f-4d29-961b-feca4afbe56e	t	f	39088
1128	18	81044d94-0054-40bb-880b-b39643801af1	t	f	419
1121	38	10e48579-9c92-46e9-8d4a-fceca41f8129	t	f	416
14343	3	b26d9987-2e77-4f9e-af03-4c998dc23829	t	f	14443
39013	2	0c8460dc-3db8-424d-8509-2647ccdd7f10	t	f	39099
39009	2	0fc047d4-ef35-4354-8c4d-2894a4315f1b	t	f	39097
38995	2	723091c5-7091-440d-ad9f-1b26aba267e3	t	f	39090
39001	2	562429a0-91f7-4612-aa54-8b748ce9c3cf	t	f	39093
1134	3	46d8e901-aedb-4208-8193-56c1007bde5d	t	f	422
38987	2	0cd7a053-4ba1-4f3c-95a4-f2f24d91b70e	t	f	39087
38997	3	6d8b7cce-66eb-42b4-aeed-917e703120d2	t	f	39091
3513191	4	1c5255b8-e93d-4e6d-a45f-a0dac8cea107	t	f	3513288
3513197	1	9f0d84cc-a459-4e32-a482-12528065545b	t	f	3513291
3513193	3	4231569e-7be0-43ab-a1f4-5b9929aea872	t	f	3513289
3513195	2	5b52e0b6-a771-46d3-9c06-8f66e63de27d	t	f	3513290
1119	38	fdd18762-9b4a-49a5-a3b3-33dc2b208ba7	t	f	415
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, intended_total_hours, originaltotalassignment, task, assignment_function) FROM stdin;
2679	2	2.00	\N	450	2424	\N
2680	2	1.00	\N	300	2425	\N
2681	2	1.00	\N	300	2426	\N
2715	0	1.00	\N	140	2432	\N
2716	0	1.00	\N	170	2433	\N
2717	0	1.00	\N	24	2428	\N
2718	0	1.00	\N	100	2431	\N
2719	0	1.00	\N	60	2435	\N
2720	0	1.00	\N	40	2429	\N
2721	0	1.00	\N	40	2430	\N
14143	1	1.00	\N	30	13938	\N
14142	1	1.00	\N	20	13939	\N
14146	0	1.00	\N	20	13941	\N
14147	0	1.00	\N	10	13940	\N
39518	1	2.00	0	500	27374	\N
39519	1	4.00	0	2000	27375	\N
27675	3	1.00	0	100	27371	\N
27674	3	1.00	0	100	27371	\N
39509	2	4.00	0	2000	27372	\N
39511	2	4.00	0	2000	27372	\N
39510	2	2.00	0	1000	27372	\N
39520	1	3.00	0	1000	27373	\N
3505621	2	1.00	\N	40	3505310	\N
14149	5	1.00	\N	20	13947	\N
14148	6	0.94	\N	30	13946	16363
3505623	2	1.00	\N	40	3505310	\N
3505622	2	1.00	\N	40	3505310	\N
14151	5	1.00	\N	20	13949	\N
14150	5	1.00	\N	10	13948	\N
3522865	20	1.00	\N	144	3511148	\N
3766823	9	2.00	\N	400	3511136	\N
3659387	15	1.00	\N	240	3511116	\N
3766861	4	1.00	\N	120	3796792	\N
24072	13	5.63	\N	450	13951	3467032
24074	13	5.36	\N	300	13953	\N
3679794	12	1.00	\N	144	3511125	\N
3679795	12	1.00	\N	176	3511126	\N
3679796	12	1.00	\N	72	3511127	\N
3679797	12	1.00	\N	72	3511128	\N
3679798	12	1.00	\N	72	3511129	\N
3679799	12	1.00	\N	72	3511155	\N
3679800	12	1.00	\N	144	3511156	\N
3679801	12	1.00	\N	120	3511157	\N
3766824	9	1.00	\N	200	3511131	\N
3659355	17	1.50	\N	72	3511149	\N
3659356	17	1.50	\N	168	3511152	\N
24071	13	3.00	\N	24	13955	\N
2494211	10	0.83	\N	40	13956	\N
2494212	10	1.00	\N	40	13957	\N
2494210	10	1.00	\N	100	13958	\N
2494208	10	1.00	\N	140	13959	\N
2494209	10	1.00	\N	170	13960	\N
2494207	10	1.00	\N	60	13962	\N
3819135	2	1.00	\N	96	3796793	\N
3522858	20	1.00	\N	72	3511141	\N
3522859	20	1.00	\N	48	3511142	\N
3522860	20	1.00	\N	64	3511143	\N
3522861	20	1.00	\N	32	3511144	\N
3522862	20	1.00	\N	40	3511145	\N
3522863	20	1.00	\N	64	3511146	\N
3522864	20	1.00	\N	112	3511147	\N
3505617	3	0.91	\N	29	3505306	3506317
3511787	28	0.15	\N	100	3511070	\N
3511789	28	0.13	\N	71	3511072	\N
3511790	28	0.13	\N	72	3511073	\N
3511791	28	0.13	\N	64	3511074	\N
3511792	28	0.13	\N	27	3511075	\N
3511793	28	0.13	\N	20	3511076	\N
3766828	7	0.15	\N	96	3511063	\N
3766829	7	0.13	\N	96	3511064	\N
3766830	7	0.13	\N	78	3511065	\N
3766831	7	0.13	\N	96	3511066	\N
3766832	7	0.24	\N	176	3511067	\N
3766833	7	0.13	\N	78	3511068	\N
57180	34	1.10	\N	1493	57067	\N
3766834	7	0.16	\N	116	3511158	\N
3559792	18	1.50	\N	64	3511105	\N
3559793	18	1.50	\N	56	3511106	\N
3559794	18	1.50	\N	48	3511107	\N
3559795	18	1.50	\N	176	3511108	\N
3559796	18	1.50	\N	144	3511109	\N
3559797	18	1.50	\N	152	3511110	\N
3559799	18	1.50	\N	48	3511150	\N
3559800	18	1.50	\N	120	3511151	\N
57178	35	0.74	\N	1000	57065	\N
57179	35	0.96	\N	1300	57065	\N
2379862	5	2.00	\N	300	57066	\N
3559802	18	1.50	\N	104	3511153	\N
3559803	18	1.50	\N	56	3511154	\N
3518384	21	1.00	\N	56	3511099	\N
3836286	5	0.88	\N	20	3835983	\N
3836285	5	1.00	\N	20	3835981	\N
3518385	21	1.00	\N	48	3511100	\N
3518386	21	1.00	\N	40	3511101	\N
3518387	21	1.00	\N	56	3511102	\N
3518388	21	1.00	\N	96	3511103	\N
3518352	24	0.50	\N	40	3511085	\N
3518353	24	0.25	\N	40	3511086	\N
3518354	24	0.25	\N	96	3511087	\N
3518355	24	0.50	\N	116	3511088	\N
3518356	24	0.25	\N	88	3511091	\N
3819130	3	1.00	\N	80	3511132	\N
3819131	3	1.00	\N	200	3511133	\N
3819132	3	1.00	\N	200	3511134	\N
3819133	3	1.00	\N	100	3511135	\N
3518351	24	1.00	\N	64	3511093	\N
3518380	23	1.00	\N	56	3511094	\N
3518381	23	1.00	\N	48	3511095	\N
3518382	23	1.00	\N	96	3511096	\N
3518383	23	1.00	\N	144	3511097	\N
3836283	5	0.63	\N	0	3835982	\N
3836284	5	1.88	\N	30	3835980	\N
3659364	16	1.00	\N	72	3511112	\N
3659365	16	1.00	\N	144	3511113	\N
3659366	16	1.00	\N	32	3511114	\N
3659367	16	1.00	\N	168	3511115	\N
3659389	14	1.00	\N	96	3511117	\N
3511795	25	0.50	\N	20	3511078	\N
3518347	24	0.50	\N	68	3511079	\N
3518348	24	0.50	\N	176	3511080	\N
3518349	24	0.50	\N	280	3511081	\N
3518350	24	0.50	\N	176	3511082	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
411	1
414	1
3513287	1
3513286	1
3513285	1
39088	1
3513288	1
3513291	1
3513289	1
3513290	1
417	1
39094	1
412	1
420	1
39095	1
418	1
14444	1
39089	1
39101	1
39103	1
421	1
39100	1
413	1
410	1
423	1
39092	1
39102	1
3504599	1
39096	1
26563	1
39098	1
419	1
416	1
14443	1
39099	1
39097	1
39090	1
39093	1
422	1
39087	1
39091	1
415	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, code, initdate, enddate, cost_category_id, resource_id) FROM stdin;
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
2715	1132
2716	1134
2494208	1130
2494209	1121
3505621	14343
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
16363	2010-05-07	0.50	0.25	0
16363	2010-05-11	1.00	1.00	1
3467030	2010-05-28	0.50	0.25	0
3467030	2010-05-30	0.75	0.70	1
3467030	2010-06-01	1.00	1.00	2
3467032	2010-05-11	0.30	0.20	0
3467032	2010-05-14	0.50	0.30	1
3467032	2010-05-18	0.75	0.65	2
3467032	2010-05-22	1.00	1.00	3
3506317	2010-05-18	0.30	0.20	0
3506317	2010-05-19	0.60	0.30	1
3506317	2010-05-21	1.00	1.00	2
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id, type) FROM stdin;
16363	0
3467028	0
3467029	0
3467030	0
3467032	1
3506317	0
\.


--
-- Data for Name: subcontractedtaskdata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY subcontractedtaskdata (id, version, externalcompany, subcontratationdate, subcontractcommunicationdate, workdescription, subcontractprice, subcontractedcode, nodewithoutchildrenexported, labelsexported, materialassignmentsexported, hoursgroupsexported, state) FROM stdin;
1124499457	6	1515	2010-05-14 13:51:41.182	2010-05-14 13:54:24.119	Construcción de las cavernas	20000.00	\N	t	t	t	t	2
1137704962	4	1515	2010-05-17 18:21:27.994	2010-05-17 18:25:13.193	Ship paint	15000.00	code1.1	t	t	t	t	2
1249935361	4	1515	2010-06-07 17:25:16.121	2010-06-07 17:26:15.574	Descripción. Planificación	30000.00	COD-1	t	t	t	t	2
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate, subcontrated_task_data_id, priority) FROM stdin;
13946	1	1	2010-05-03 00:00:00	\N	\N
3511158	2	0	\N	\N	\N
13947	1	0	\N	\N	\N
13948	1	0	\N	\N	\N
13949	1	0	\N	\N	\N
3835985	1	1	2010-01-01 00:00:00	\N	\N
3835986	1	1	2010-01-01 00:00:00	\N	\N
3835987	1	1	2010-01-01 00:00:00	\N	\N
13951	1	0	\N	\N	\N
13953	1	0	\N	\N	\N
13955	1	0	\N	\N	\N
13956	1	0	\N	\N	\N
13957	1	0	\N	\N	\N
13958	1	0	\N	\N	\N
13959	1	0	\N	\N	\N
13960	1	0	\N	\N	\N
13962	1	0	\N	\N	\N
27371	1	0	\N	\N	\N
27372	1	0	\N	\N	\N
27373	1	0	\N	\N	\N
27374	1	0	\N	\N	\N
27375	1	0	\N	\N	\N
2424	1	0	\N	\N	\N
2425	1	0	\N	\N	\N
2426	1	0	\N	\N	\N
2428	1	0	\N	\N	\N
2429	1	0	\N	\N	\N
2430	1	0	\N	\N	\N
2431	1	0	\N	\N	\N
2432	1	0	\N	\N	\N
2433	1	0	\N	\N	\N
2435	1	0	\N	\N	\N
13938	1	0	\N	\N	\N
13939	1	0	\N	\N	\N
13940	1	0	\N	\N	\N
13941	1	0	\N	\N	\N
13952	1	2	2010-05-07 08:54:00.144	1124499457	\N
3796792	1	1	2010-09-07 00:00:00	\N	\N
3796793	1	0	\N	\N	\N
57065	2	0	\N	\N	\N
57066	1	0	\N	\N	\N
57067	2	0	\N	\N	\N
3511125	1	0	\N	\N	\N
3511126	1	0	\N	\N	\N
3511127	1	0	\N	\N	\N
3511128	1	0	\N	\N	\N
3511070	2	0	\N	\N	\N
3511071	2	2	2010-01-01 00:00:00	1249935361	\N
3511072	2	0	\N	\N	\N
3511073	2	0	\N	\N	\N
3511074	2	0	\N	\N	\N
3511075	2	0	\N	\N	\N
3511076	2	0	\N	\N	\N
3511063	2	0	\N	\N	\N
3511064	2	0	\N	\N	\N
3511065	2	0	\N	\N	\N
3511066	2	0	\N	\N	\N
3511067	2	0	\N	\N	\N
3511068	2	0	\N	\N	\N
3511105	1	0	\N	\N	\N
3511106	1	0	\N	\N	\N
3511107	1	0	\N	\N	\N
3511108	1	0	\N	\N	\N
3511109	1	0	\N	\N	\N
3511110	1	0	\N	\N	\N
3511149	1	0	\N	\N	\N
3511150	1	0	\N	\N	\N
3511151	1	0	\N	\N	\N
3511152	1	0	\N	\N	\N
3511099	1	0	\N	\N	\N
3511100	1	0	\N	\N	\N
3511101	1	0	\N	\N	\N
3511102	1	0	\N	\N	\N
3511103	1	0	\N	\N	\N
3511141	1	0	\N	\N	\N
3511142	1	0	\N	\N	\N
3511143	1	0	\N	\N	\N
3511144	1	0	\N	\N	\N
3511145	1	0	\N	\N	\N
3511146	1	0	\N	\N	\N
3511147	1	0	\N	\N	\N
3511148	1	0	\N	\N	\N
3511085	1	0	\N	\N	\N
3511086	1	0	\N	\N	\N
3511087	1	0	\N	\N	\N
3505306	2	1	2010-05-18 00:00:00	\N	\N
3505307	1	0	\N	\N	\N
3505308	1	2	2010-05-17 17:54:19.322	1137704962	\N
3505310	1	0	\N	\N	\N
3511088	1	0	\N	\N	\N
3511091	1	0	\N	\N	\N
3511093	1	0	\N	\N	\N
3511094	1	0	\N	\N	\N
3511095	1	0	\N	\N	\N
3511096	1	0	\N	\N	\N
3511097	1	0	\N	\N	\N
3511112	1	0	\N	\N	\N
3511113	1	0	\N	\N	\N
3511114	1	0	\N	\N	\N
3511115	1	0	\N	\N	\N
3511116	1	0	\N	\N	\N
3511117	1	0	\N	\N	\N
3511078	1	0	\N	\N	\N
3511079	1	0	\N	\N	\N
3511080	1	0	\N	\N	\N
3511081	1	0	\N	\N	\N
3511082	1	0	\N	\N	\N
3465918	1	1	2010-05-07 08:54:00.144	\N	\N
3465919	1	1	2010-05-07 08:54:00.144	\N	\N
3465920	1	1	2010-05-07 08:54:00.144	\N	\N
3511129	1	0	\N	\N	\N
3511155	1	0	\N	\N	\N
3511156	1	0	\N	\N	\N
3511157	1	0	\N	\N	\N
3511131	1	0	\N	\N	\N
3511153	1	0	\N	\N	\N
3511154	1	0	\N	\N	\N
3511132	1	1	2010-07-23 00:00:00	\N	\N
3511133	1	0	\N	\N	\N
3511134	1	0	\N	\N	\N
3511135	1	0	\N	\N	\N
3511136	1	0	\N	\N	\N
3835980	1	0	\N	\N	\N
3835981	1	0	\N	\N	\N
3835982	1	0	\N	\N	\N
3835983	1	0	\N	\N	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id, reportadvance) FROM stdin;
3504095	3	3503993	13467	t
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
3504095	¿Rematouse o paso 1?	20.00	0	t	2010-05-17 00:00:00	0
3504095	¿Rematouse o paso 2?	40.00	1	f	\N	1
3504095	¿Rematouse o paso 3?	67.00	2	f	\N	2
3504095	¿Rematouse o paso 4?	90.00	3	f	\N	3
3504095	¿Rematouse o paso 5?	100.00	4	f	\N	4
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
3511063	3510989
3511064	3510990
3511065	3510991
3511066	3510992
3511067	3510993
3511068	3510994
3511158	3511050
3511070	3510962
27371	27279
27371	27270
27372	27271
27372	27282
27372	27283
27373	27275
3511071	3510963
3511072	3510964
3511073	3510965
3511074	3510966
2424	2032
2425	2033
2426	2034
2428	2035
2429	2036
2430	2037
2431	2038
2432	2039
27374	27276
27375	27277
3511075	3510967
3511076	3510968
3511078	3510969
3511079	3510970
3511080	3510971
3511081	3510972
3511082	3510973
3511085	3510975
3511086	3510982
3511087	3510983
3511088	3510984
3511091	3510987
3511093	3510976
3511094	3511002
3511095	3511003
3511096	3511004
2433	2040
2435	2041
13938	13736
13939	13737
13940	13738
13941	13739
3511097	3511005
3511099	3510977
3511100	3511006
3511101	3511007
3511102	3511008
3511103	3511009
3796793	3511029
3511141	3511030
3511142	3511031
3511143	3511032
3511144	3511033
3511145	3511034
3511146	3511035
3511147	3511036
3511148	3511037
3511105	3510978
3511106	3511010
3511107	3511011
3511108	3511012
3511109	3511013
3511110	3511014
3511149	3511038
3511150	3511039
3511151	3511040
3511152	3511041
3511153	3511042
3511154	3511043
3511112	3510979
3511113	3511015
3511114	3511016
3511115	3511017
3511116	3511018
3511117	3511019
3511125	3510981
3511126	3511025
3511127	3511026
3511128	3511027
3511129	3511028
3511155	3511044
3511156	3511045
3511157	3511046
3511131	3510995
3511132	3510996
3511133	3510997
3511134	3510998
3511135	3510999
3511136	3511000
3796792	3511056
3835985	3835895
3835986	3835900
3835987	3835901
3465918	3466320
3465919	3466321
3465920	3466322
13946	13776
13947	13777
13948	13778
13949	13779
3505306	3505223
3505307	3505224
3505308	3505225
3505310	3505226
3505310	3505228
3505310	3505227
3835980	3835891
3835981	3835892
3835982	3835893
3835983	3835894
57065	50274
57065	50197
57066	50208
57067	50209
13951	13830
13952	13831
13953	13832
13955	13833
13956	13834
13957	13835
13958	13836
13959	16665
13960	16666
13962	16667
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent, advancepercentage) FROM stdin;
13962	15	Impermeabilización	\N	2010-07-27 00:00:00	2010-08-06 00:00:00	\N	13963	\N	6	\N
2429	6	Unir quila	\N	2010-08-11 08:05:33.531	2010-08-18 08:05:33.531	\N	2436	\N	2	\N
3511141	49	Modelo de dependencias	\N	2010-03-11 00:00:00	2010-03-24 00:00:00	\N	3511104	\N	6	0.00
13938	7	Pegar tablillas	\N	2010-05-06 19:31:14.452	2010-05-12 19:31:14.452	\N	13942	\N	0	\N
13939	7	Saturar interna y externamente con resina epoxy	\N	2010-05-12 19:31:14.452	2010-05-15 19:31:14.452	\N	13942	\N	1	\N
13940	7	Colocar estructura in interior	\N	2010-05-15 19:31:14.452	2010-05-19 19:31:14.452	\N	13942	\N	2	\N
13941	7	Colocar malla fina	\N	2010-05-19 19:31:14.452	2010-05-22 19:31:14.452	\N	13942	\N	3	\N
13942	11	Laminado Moldeado	\N	2010-05-06 19:31:14.452	2010-05-22 19:31:14.452	2010-06-30	\N	\N	\N	\N
13963	10	Construcción de barco de recreo para Sergio Sumay	\N	2010-05-07 08:54:00.144	2010-08-06 00:00:00	2010-06-06	\N	\N	\N	\N
3511142	49	Modelo de restriccións	\N	2010-03-24 00:00:00	2010-04-01 00:00:00	\N	3511104	\N	7	0.00
3511143	49	Modelos de clases para calendarios	\N	2010-04-01 00:00:00	2010-04-13 00:00:00	\N	3511104	\N	8	0.00
3511144	49	Modelo de clases de calendarios asociados a recursos	\N	2010-04-13 00:00:00	2010-04-17 00:00:00	\N	3511104	\N	9	0.00
13946	18	Pegar tablillas	\N	2010-05-03 00:00:00	2010-05-11 00:00:00	\N	13950	\N	0	1.00
13947	18	Saturar interna y externamente con resina epoxy	\N	2010-05-11 00:00:00	2010-05-14 00:00:00	\N	13950	\N	1	0.50
13948	18	Colocar estructura in interior	\N	2010-05-14 00:00:00	2010-05-18 00:00:00	\N	13950	\N	2	0.20
2430	6	Pegar terciado náutico	\N	2010-08-18 08:05:33.531	2010-08-25 08:05:33.531	\N	2436	\N	3	\N
13949	18	Colocar malla fina	\N	2010-05-18 00:00:00	2010-05-21 00:00:00	\N	13950	\N	3	0.00
13950	27	Laminado Moldeado Abril Navantia	\N	2010-05-03 00:00:00	2010-05-21 00:00:00	2010-07-29	\N	\N	\N	0.52
3835988	3	Planificación periódica	\N	2010-01-01 00:00:00	2010-01-07 06:00:00	2010-09-30	3835989	\N	0	0.25
3835989	3	Descripción. Planificación	\N	2010-01-01 00:00:00	2010-01-07 06:00:00	2010-09-30	\N	\N	\N	0.25
27371	10	Montaje de andamios	\N	2010-06-10 00:00:00	2010-06-29 00:00:00	\N	27376	\N	0	\N
27372	10	Construcción del casco	\N	2010-06-29 00:00:00	2010-09-24 00:00:00	\N	27376	\N	1	\N
13954	10	Fabricación en bancada	\N	2010-05-07 08:54:00.144	2010-05-22 08:54:00.144	\N	13963	\N	0	\N
2431	6	Aplicar fibras de vidrio	\N	2010-08-25 08:05:33.531	2010-09-11 08:05:33.531	\N	2436	\N	4	\N
27373	10	Construcción de cubierta	\N	2010-06-10 00:00:00	2010-08-07 00:00:00	\N	27376	\N	2	\N
27374	10	Hélices	\N	2010-08-07 00:00:00	2010-09-22 00:00:00	\N	27376	\N	3	\N
27375	10	Confección velamen	\N	2010-08-07 00:00:00	2010-11-06 00:00:00	\N	27376	\N	4	\N
2432	6	Lijado de cubierta	\N	2010-09-11 08:05:33.531	2010-10-07 08:05:33.531	\N	2434	\N	0	\N
2433	6	Lijado de casco	\N	2010-09-11 08:05:33.531	2010-10-14 08:05:33.531	\N	2434	\N	1	\N
27376	15	Construcción de barco de competición en acero	\N	2010-06-10 00:00:00	2010-11-06 00:00:00	2010-11-18	\N	\N	\N	\N
13945	1	Entrega	\N	2010-05-22 19:31:14.452	2010-05-22 19:31:14.452	\N	13942	\N	4	\N
13951	16	Construcción de estructura transversal 	\N	2010-05-07 00:00:00	2010-05-22 00:00:00	\N	13954	\N	0	\N
2435	6	Impermeabilización	\N	2010-10-14 08:05:33.531	2010-10-26 08:05:33.531	\N	2436	\N	6	\N
13953	16	Construcción de anteparas	\N	2010-05-07 00:00:00	2010-05-19 00:00:00	\N	13954	\N	2	\N
13955	16	Fijar estructura a base	\N	2010-05-22 00:00:00	2010-05-25 00:00:00	\N	13963	\N	1	\N
13956	15	Unir quila	\N	2010-05-25 00:00:00	2010-06-02 00:00:00	\N	13963	\N	2	\N
13957	15	Pegar terciado náutico	\N	2010-06-01 00:00:00	2010-06-08 00:00:00	\N	13963	\N	3	\N
2427	7	Fabricación en bancada	\N	2010-05-04 08:05:33.531	2010-08-06 08:05:33.531	\N	2436	\N	0	\N
2434	7	Lijado	\N	2010-09-11 08:05:33.531	2010-10-14 08:05:33.531	\N	2436	\N	5	\N
2436	7	Construcción de barco de recreo	\N	2010-05-04 08:05:33.531	2010-10-26 08:05:33.531	\N	\N	\N	\N	\N
3835985	2	Subtarea 3	\N	2010-01-01 00:00:00	2010-01-03 12:00:00	2010-09-30	3835988	\N	0	0.00
3835986	2	Subtarea 1 	\N	2010-01-01 00:00:00	2010-01-04 18:00:00	\N	3835988	\N	1	0.00
3835987	2	Subtarea 2	\N	2010-01-01 00:00:00	2010-01-07 06:00:00	\N	3835988	\N	2	0.50
13958	15	Aplicar fibras de vidrio	\N	2010-06-08 00:00:00	2010-06-25 00:00:00	\N	13963	\N	4	\N
13959	15	Lijado de cubierta	\N	2010-06-25 00:00:00	2010-07-21 00:00:00	\N	13961	\N	0	\N
13952	10	Construcción de cavernas	\N	2010-05-07 08:54:00.144	2010-05-19 08:54:00.144	\N	13954	\N	1	\N
2424	6	Construcción de estructura transversal 	\N	2010-05-04 08:05:33.531	2010-06-15 08:05:33.531	\N	2427	\N	0	\N
2425	6	Construcción de cavernas	\N	2010-05-04 08:05:33.531	2010-06-26 08:05:33.531	\N	2427	\N	1	\N
2426	6	Construcción de anteparas	\N	2010-06-15 08:05:33.531	2010-08-06 08:05:33.531	\N	2427	\N	2	\N
13960	15	Lijado de casco	\N	2010-06-25 00:00:00	2010-07-27 00:00:00	\N	13961	\N	1	\N
2428	6	Fijar estructura a base	\N	2010-08-06 08:05:33.531	2010-08-11 08:05:33.531	\N	2436	\N	1	\N
13961	10	Lijado	\N	2010-06-25 08:54:00.144	2010-07-27 00:00:00	\N	13963	\N	5	\N
3511149	48	Avaliación de proxecto segundo cadea crítica	\N	2010-05-29 00:00:00	2010-06-08 00:00:00	\N	3511111	\N	6	0.00
3511150	48	Servizo de configuración de asignación de recursos	\N	2010-06-08 00:00:00	2010-06-12 00:00:00	\N	3511111	\N	7	0.00
3511151	48	Algoritmo de asignación de recursos tendo en conta a capacidade máxima	\N	2010-06-12 00:00:00	2010-06-26 00:00:00	\N	3511111	\N	8	0.00
3511152	48	Algoritmo de recursos limitantes con cumprimento de datas de fin	\N	2010-06-26 00:00:00	2010-07-16 00:00:00	\N	3511111	\N	9	0.00
3511153	49	Algoritmo de realización de asignacións dando prioridade a deadlines	\N	2010-07-16 00:00:00	2010-07-29 00:00:00	\N	3511111	\N	10	0.00
3511154	48	Configuración de planificación a nivelar	\N	2010-07-29 00:00:00	2010-08-05 00:00:00	\N	3511111	\N	11	0.00
3511145	48	Modelo de función plana	\N	2010-04-17 00:00:00	2010-04-24 00:00:00	\N	3511104	\N	10	0.00
3511146	48	Modelo de función lineal por tramos	\N	2010-04-24 00:00:00	2010-05-06 00:00:00	\N	3511104	\N	11	0.00
3511147	48	Modelo de función de curvas S	\N	2010-05-06 00:00:00	2010-05-26 00:00:00	\N	3511104	\N	12	0.00
3511148	48	Modelo de asignación segundo a cadea crítica	\N	2010-05-26 00:00:00	2010-06-19 00:00:00	\N	3511104	\N	13	0.00
3511155	46	API de avaliación e comparación dos resultados de cálculo de planificación	\N	2010-06-16 00:00:00	2010-06-29 00:00:00	\N	3511130	\N	5	0.00
3511156	46	API de extracción comunicación XML	\N	2010-06-29 00:00:00	2010-07-23 00:00:00	\N	3511130	\N	6	0.00
3511157	46	API de extracción de comunicación XML	\N	2010-07-23 00:00:00	2010-08-13 00:00:00	\N	3511130	\N	7	0.00
3511158	24	Avaliación de propostas 	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511069	\N	6	0.00
3511160	6	2º release	\N	2010-08-05 00:00:00	2010-08-05 00:00:00	\N	3511139	\N	8	\N
3511159	6	1º release do proxecto	\N	2010-06-19 00:00:00	2010-06-19 00:00:00	\N	3511139	\N	6	\N
3511162	5	3º release	\N	2010-09-17 00:00:00	2010-09-17 00:00:00	\N	3511139	\N	12	\N
3511163	5	Entrega proxecto	\N	2010-09-29 00:00:00	2010-09-29 00:00:00	\N	3511139	\N	14	\N
3796792	13	Formación	\N	2010-09-07 00:00:00	2010-09-28 00:00:00	\N	3511139	\N	15	0.00
3796793	6	Infraestructura de composición e colaboración de diferentes estratexias dispoñibles	\N	2010-02-23 00:00:00	2010-03-11 00:00:00	\N	3511104	\N	5	0.00
57066	43	Definición de modelo de negocio	\N	2010-06-01 00:00:00	2010-06-26 00:00:00	\N	50376	\N	1	0.00
57130	33	Entrega proyecto	\N	2011-01-28 03:24:36	2011-01-28 03:24:36	\N	50376	\N	5	\N
57065	43	Coordinación del proyecto	\N	2010-06-01 00:00:00	2011-01-29 00:00:00	\N	50376	\N	0	0.00
57067	44	Análisis y diseño	\N	2010-06-01 00:00:00	2011-01-29 00:00:00	\N	50376	\N	2	0.00
50376	67	Openapps - Invattur	\N	2010-06-01 00:00:00	2011-01-29 00:00:00	2011-01-31	\N	\N	\N	0.00
3465922	1	Construcción de las cavernas	\N	2010-05-07 08:54:00.144	2010-05-19 20:54:00.144	2010-05-19	\N	\N	\N	\N
3465918	1	Construcción elemento 2	\N	2010-05-07 08:54:00.144	2010-05-19 20:54:00.144	2010-05-19	3465921	\N	0	\N
3465919	1	Construcción elemento 1	\N	2010-05-07 08:54:00.144	2010-05-19 20:54:00.144	\N	3465921	\N	1	\N
3465920	1	Construcción elemento 3	\N	2010-05-07 08:54:00.144	2010-05-19 20:54:00.144	\N	3465921	\N	2	\N
3465921	1	Construcción de cavernas	\N	2010-05-07 08:54:00.144	2010-05-19 20:54:00.144	2010-05-19	3465922	\N	0	\N
3465917	0	Entrega bocetos diseño gráfico	\N	2010-07-02 10:24:00	2010-07-02 10:24:00	\N	50376	\N	3	\N
57129	33	Entrega primer prototipo	\N	2010-11-30 18:38:31.20	2010-11-30 18:38:31.20	\N	50376	\N	4	\N
3505309	8	Task 1	\N	2010-05-17 17:54:19.322	2010-06-23 00:00:00	2010-08-17	3505311	\N	0	\N
3505306	7	Task 1.1	\N	2010-05-18 00:00:00	2010-05-23 00:00:00	\N	3505309	\N	0	\N
3505307	6	Task 1.3	\N	2010-05-23 00:00:00	2010-05-28 00:00:00	\N	3505309	\N	1	\N
3505308	6	Subtask 1.2	\N	2010-05-17 17:54:19.322	2010-06-23 00:00:00	\N	3505309	\N	2	\N
3505310	7	Task 2	\N	2010-06-23 00:00:00	2010-06-30 00:00:00	\N	3505311	\N	1	\N
3505311	8	Developt a project	\N	2010-05-17 17:54:19.322	2010-06-30 00:00:00	2010-09-24	\N	\N	\N	\N
3511070	61	Informes de seguimento	\N	2010-01-01 00:00:00	2010-07-10 00:00:00	\N	3511077	\N	0	0.60
3511071	61	Planificación periódica	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511077	\N	1	0.00
3511072	61	Reunións internas	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511077	\N	2	0.00
3511073	61	Reunións seguimento con implicados	\N	2010-01-01 00:00:00	2010-10-01 00:00:00	\N	3511077	\N	3	0.00
3511074	61	Control do estado do proxecto	\N	2010-01-01 00:00:00	2010-09-17 00:00:00	\N	3511077	\N	4	0.00
3511075	61	Control de calidade do proxecto	\N	2010-01-01 00:00:00	2010-09-10 00:00:00	\N	3511077	\N	5	0.00
3511076	61	Xestión de riscos, incidencias e compromisos	\N	2010-01-01 00:00:00	2010-09-08 00:00:00	\N	3511077	\N	6	0.00
3511063	59	Revisión documentación socio tecnolóxico	\N	2010-01-01 00:00:00	2010-09-15 00:00:00	\N	3511069	\N	0	0.00
3511064	59	Revisión informes seguimento	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511069	\N	1	0.00
3511065	59	Relacións institucionais	\N	2010-01-01 00:00:00	2010-09-11 00:00:00	\N	3511069	\N	2	0.00
3511066	59	Redaccións de actas de reunións	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511069	\N	3	0.00
3511067	59	Definición de alcance	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511069	\N	4	0.00
3511068	60	Reunións presentación, fitos e outros implicados	\N	2010-01-01 00:00:00	2010-09-11 00:00:00	\N	3511069	\N	5	0.00
3511085	61	Montaxe infraestructura de probas	\N	2010-01-01 00:00:00	2010-01-15 00:00:00	\N	3511092	\N	0	0.00
3511086	59	Probas de unidade do modulo de arquitectura	\N	2010-03-13 00:00:00	2010-04-10 00:00:00	\N	3511092	\N	1	0.00
3511087	59	Probas de unidade do módulo de representación	\N	2010-06-19 00:00:00	2010-08-26 00:00:00	\N	3511092	\N	2	0.00
3511088	59	Probas de unidade do módulo de planificación	\N	2010-08-05 00:00:00	2010-09-15 00:00:00	\N	3511092	\N	3	0.00
3511091	60	Probas da interfaz da librería	\N	2010-07-23 00:00:00	2010-09-23 00:00:00	\N	3511092	\N	4	0.00
3511078	59	Estudio de alternativas algoritmos de planificación	\N	2010-01-01 00:00:00	2010-01-08 00:00:00	\N	3511084	\N	0	0.00
3511079	59	Análise do módulo de arquitectura	\N	2010-01-08 00:00:00	2010-02-02 00:00:00	\N	3511084	\N	1	0.00
3511080	59	Análise do módulo de representación	\N	2010-02-02 00:00:00	2010-04-03 00:00:00	\N	3511084	\N	2	0.00
3511081	59	Análise do módulo de planificación	\N	2010-04-03 00:00:00	2010-07-10 00:00:00	\N	3511084	\N	3	0.00
3511082	60	Análise de interfaz uso da librería	\N	2010-07-10 00:00:00	2010-09-10 00:00:00	\N	3511084	\N	4	0.00
3511105	60	Modo de análise cara adiante. Planificación inicio a fin.	\N	2010-03-13 00:00:00	2010-03-23 00:00:00	\N	3511111	\N	0	0.00
3511106	60	Modo de análise cara atrás. Planificación fiin a inicio.	\N	2010-03-23 00:00:00	2010-03-30 00:00:00	\N	3511111	\N	1	0.00
3511107	60	Algoritmo de camiño crítico sobre unha rede de tarefas	\N	2010-03-30 00:00:00	2010-04-03 00:00:00	\N	3511111	\N	2	0.00
3511108	60	Servizo para cálculo de cadea crítica	\N	2010-04-03 00:00:00	2010-04-24 00:00:00	\N	3511111	\N	3	0.00
3511109	60	Método de Montecarlo para simulacións de risco	\N	2010-04-24 00:00:00	2010-05-12 00:00:00	\N	3511111	\N	4	0.00
3511110	60	Modificación de asignacións seguindo indicacións da cadea crítica	\N	2010-05-12 00:00:00	2010-05-29 00:00:00	\N	3511111	\N	5	0.00
3511099	60	Modelo de clases básicas para representar a información de recursos e asignar as planificacións	\N	2010-01-01 00:00:00	2010-01-12 00:00:00	\N	3511104	\N	0	0.00
3511100	60	Modelo de recursos con capacidade variable	\N	2010-01-12 00:00:00	2010-01-20 00:00:00	\N	3511104	\N	1	0.00
3511101	60	Modelo de capacidade variable ata un máximo	\N	2010-01-20 00:00:00	2010-01-27 00:00:00	\N	3511104	\N	2	0.00
3511102	60	Modelo de clase para os criterios	\N	2010-01-27 00:00:00	2010-02-05 00:00:00	\N	3511104	\N	3	0.00
3511103	60	Modelo de clases de recursos limitados	\N	2010-02-05 00:00:00	2010-02-23 00:00:00	\N	3511104	\N	4	0.00
3511093	59	Deseño de API's e fachadas para comunicación	\N	2010-01-01 00:00:00	2010-01-13 00:00:00	\N	3511098	\N	0	0.00
3511094	59	Deseño de paquetes e estrutura interna da librería	\N	2010-01-13 00:00:00	2010-01-22 00:00:00	\N	3511098	\N	1	0.00
3511095	59	Definición de documentación	\N	2010-01-22 00:00:00	2010-01-30 00:00:00	\N	3511098	\N	2	0.00
3511096	59	Deseño de conversacións con librería	\N	2010-01-30 00:00:00	2010-02-17 00:00:00	\N	3511098	\N	3	0.00
3511097	59	Deseño e implementación de soporte de fases de proceso coa librería	\N	2010-02-17 00:00:00	2010-03-13 00:00:00	\N	3511098	\N	4	0.00
3511112	60	Interfaz para soporte de recursos con máximo de capacidade non sobrepasable en asignación.	\N	2010-03-13 00:00:00	2010-03-26 00:00:00	\N	3511121	\N	0	0.00
3511125	60	API de carga de comunicación con Navalplan	\N	2010-03-13 00:00:00	2010-04-08 00:00:00	\N	3511130	\N	0	0.00
3511126	60	API de carga de comunicación vía XML	\N	2010-04-08 00:00:00	2010-05-08 00:00:00	\N	3511130	\N	1	0.00
3511127	59	API de preprocesamento e análise de datos	\N	2010-05-08 00:00:00	2010-05-21 00:00:00	\N	3511130	\N	2	0.00
3511128	60	API de configuración de elaboración do proceso de planificación	\N	2010-05-21 00:00:00	2010-06-03 00:00:00	\N	3511130	\N	3	0.00
3511129	60	API de execusión do proceso de cálculo de planificación	\N	2010-06-03 00:00:00	2010-06-16 00:00:00	\N	3511130	\N	4	0.00
3511131	60	Probas de integración, aceptación e funcionais	\N	2010-08-13 00:00:00	2010-09-17 00:00:00	\N	3511139	\N	11	0.00
3511132	59	Definición do proceso de implantación	\N	2010-07-23 00:00:00	2010-08-06 00:00:00	\N	3511138	\N	0	0.00
3511133	59	Control do proceso de implentación	\N	2010-08-06 00:00:00	2010-09-10 00:00:00	\N	3511138	\N	1	0.00
3511134	59	Seguimento do proceso de implantación	\N	2010-08-06 00:00:00	2010-09-10 00:00:00	\N	3511138	\N	2	0.00
3511113	60	Planificación segundo o cálculo de cadea critica	\N	2010-03-26 00:00:00	2010-04-21 00:00:00	\N	3511121	\N	1	0.00
3511114	60	Solicitar cálculo de cadea crítica	\N	2010-04-21 00:00:00	2010-04-27 00:00:00	\N	3511121	\N	2	0.00
3511115	60	Seguimento aplicación cadea crítica	\N	2010-04-27 00:00:00	2010-05-26 00:00:00	\N	3511121	\N	3	0.00
3511116	61	Modificación asignación de recursos NavalPlan para poder interactuar con librería de cálculo de solucións de asignación.	\N	2010-05-26 00:00:00	2010-07-07 00:00:00	\N	3511121	\N	4	0.00
3511117	60	Interfaz para solicitud/recepción de nivelación de planificación sobre datos de planificación.	\N	2010-07-07 00:00:00	2010-07-23 00:00:00	\N	3511121	\N	5	0.00
3511130	89	Módulo de entradas/saídas	\N	2010-03-13 00:00:00	2010-08-13 00:00:00	\N	3511139	\N	10	0.00
3511077	89	Coordinación interna	\N	2010-01-01 00:00:00	2010-10-01 00:00:00	\N	3511139	\N	1	0.13
3511069	89	Xestión proxecto Aclunaga	\N	2010-01-01 00:00:00	2010-09-30 00:00:00	\N	3511139	\N	0	0.00
3511111	89	Módiulo de planificación	\N	2010-03-13 00:00:00	2010-08-05 00:00:00	\N	3511139	\N	7	0.00
3511104	89	Módulo de representación de información	\N	2010-01-01 00:00:00	2010-06-19 00:00:00	\N	3511139	\N	5	0.00
3511092	89	Probas unidade	\N	2010-01-01 00:00:00	2010-09-23 00:00:00	\N	3511139	\N	3	0.00
3511138	89	Implantación en 5 empresas do sector	\N	2010-07-23 00:00:00	2010-09-29 00:00:00	\N	3511139	\N	13	0.00
3511135	59	Verificación do proceso de implantación	\N	2010-09-10 00:00:00	2010-09-29 00:00:00	\N	3511138	\N	3	0.00
3511136	60	Implantación do proxecto en cada empresa	\N	2010-08-06 00:00:00	2010-09-10 00:00:00	\N	3511138	\N	4	0.00
3511098	89	Módulo de arquitectura	\N	2010-01-01 00:00:00	2010-03-13 00:00:00	\N	3511139	\N	4	0.00
3511121	89	Módulo de interfaz	\N	2010-03-13 00:00:00	2010-07-23 00:00:00	\N	3511139	\N	9	0.00
3511084	89	Análise	\N	2010-01-01 00:00:00	2010-09-10 00:00:00	\N	3511139	\N	2	0.00
3511139	89	Sistema de computo de solucións a problemas de planificación	\N	2010-01-01 00:00:00	2010-10-01 00:00:00	2010-09-30	\N	\N	\N	0.00
3835980	12	Pegar tablillas	\N	2010-05-18 00:00:00	2010-05-22 00:00:00	\N	3835984	\N	0	0.50
3835981	12	Saturar interna y externamente con resina epoxy	\N	2010-05-22 00:00:00	2010-05-27 00:00:00	\N	3835984	\N	1	0.50
3835982	12	Colocar estructura in interior	\N	2010-05-27 00:00:00	2010-05-29 00:00:00	\N	3835984	\N	2	0.20
3835983	12	Colocar malla fina	\N	2010-05-29 00:00:00	2010-06-10 00:00:00	\N	3835984	\N	3	0.30
3835984	17	Laminado Moldeado Template	\N	2010-05-18 00:00:00	2010-06-10 00:00:00	2010-06-16	\N	\N	\N	0.41
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
2427
2434
2436
13942
13950
13954
13961
13963
27376
50376
3465921
3465922
3505309
3505311
3511069
3511077
3511084
3511092
3511098
3511104
3511111
3511121
3511130
3511138
3511139
3835984
3835988
3835989
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
13945
57129
57130
3465917
3511159
3511160
3511162
3511163
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
13942	5	13434
13938	9	13435
13939	9	13436
13940	9	13437
13941	9	13438
13950	11	13464
13946	21	13465
13947	21	13466
13948	21	13467
13949	21	13468
3511158	25	3713366
3511117	61	3510727
3511125	61	3510682
3511126	61	3510735
3835988	2	3835705
3835989	2	3835697
3511127	61	3510736
3511128	61	3510737
3511129	61	3510738
3511131	61	3510698
3511132	61	3510700
3835985	3	3835698
3835986	3	3835706
3511133	61	3510701
3511134	61	3510702
3511135	61	3510703
27376	6	26969
27371	11	26970
27372	11	26971
27373	11	26975
27374	11	26976
27375	11	26977
3511136	61	3510704
3835987	3	3835707
13954	2	13483
13961	2	13491
13963	2	13482
13951	3	13484
13952	3	13485
13953	3	13486
13955	3	13487
13956	3	13488
13957	3	13489
13958	3	13490
13959	3	13492
13960	3	13493
13962	3	13494
2427	2	1837
2434	2	1845
2436	2	1836
2424	3	1838
2425	3	1839
2426	3	1840
2428	3	1841
2429	3	1842
2430	3	1843
2431	3	1844
2432	3	1846
2433	3	1847
2435	3	1848
3465918	1	3466220
3465919	1	3466222
3465920	1	3466223
3465921	1	3466221
3465922	1	3466219
50376	16	49895
3511141	43	3510740
3511142	43	3510741
3511143	43	3510742
3511144	43	3510743
3796792	15	3713372
3505309	3	3505043
57065	13	49896
3505311	3	3505018
3505306	5	3505044
3505307	5	3505045
3505308	5	3505046
57066	13	49908
3505310	5	3505047
57067	13	49909
3511069	31	3510690
3511077	31	3510661
3511084	31	3510669
3511092	31	3510683
3511098	31	3510706
3511104	31	3510711
3511111	31	3510716
3511121	31	3510722
3511063	61	3510692
3511064	61	3510693
3511065	61	3510694
3511066	61	3510695
3511067	61	3510696
3511068	61	3510697
3511070	61	3510662
3511071	61	3510663
3511072	61	3510664
3796793	5	3510739
3511145	41	3510744
3511146	41	3510745
3511147	41	3510746
3511148	41	3510747
3511149	41	3510748
3511150	41	3510749
3511151	41	3510750
3511152	41	3510751
3511153	41	3510752
3511154	41	3510753
3511130	31	3510734
3511138	31	3510699
3511139	31	3510660
3511073	61	3510665
3511074	61	3510666
3511075	61	3510667
3511076	61	3510668
3511078	61	3510670
3511079	61	3510671
3511080	61	3510672
3511081	61	3510673
3511082	61	3510674
3835984	6	3835692
3835980	11	3835693
3835981	11	3835694
3835982	11	3835695
3835983	11	3835696
3511085	61	3510676
3511086	61	3510684
3511087	61	3510685
3511088	61	3510686
3511091	61	3510689
3511093	61	3510677
3511094	61	3510707
3511095	61	3510708
3511096	61	3510709
3511097	61	3510710
3511099	61	3510678
3511100	61	3510712
3511101	61	3510713
3511102	61	3510714
3511103	61	3510715
3511105	61	3510679
3511106	61	3510717
3511107	61	3510718
3511108	61	3510719
3511109	61	3510720
3511110	61	3510721
3511112	61	3510680
3511113	61	3510723
3511114	61	3510724
3511115	61	3510725
3511116	61	3510726
3511155	37	3510754
3511156	37	3510755
3511157	37	3510756
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled, generatecode) FROM stdin;
16160	1	NORMAL	e2512a1f-a47f-4411-9e59-7947896c399e	12.00	t	t
16161	1	EXTRA	fae62c2f-21f1-466e-a289-3f07fc367f01	15.00	t	t
\.


--
-- Data for Name: unit_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY unit_type (id, version, code, measure, generatecode) FROM stdin;
203	1	33a83512-40fb-4683-a832-3a432855ddb4	kg	f
204	1	a5ee87fa-db82-4f52-ab73-aede17b584cc	km	f
205	1	12450b3b-0404-498c-9f6d-7ac09cb41159	l	f
206	1	cc004e97-1f3b-43df-88ae-853b3bbc5fdb	m	f
207	1	a557dbef-071d-42b8-b970-d7574b10e701	m2	f
208	1	2b426725-a948-4978-8239-c268367c4ad0	m3	f
209	1	cca49eaa-2113-40dd-b33d-24f427855cf2	tn	f
202	2	3b454c1c-2d35-4ed6-8f5c-638e671f12ef	Unidades	f
13332	1	d166a759-1447-450a-bf82-bee9366dd5c2	units	f
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
3480864	3480763
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
1011	ROLE_READ_ALL_ORDERS
1011	ROLE_ADMINISTRATION
1011	ROLE_CREATE_ORDER
1011	ROLE_EDIT_ALL_ORDERS
1012	ROLE_WS_READER
1013	ROLE_WS_READER
1013	ROLE_WS_WRITER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, code, date, generatecode, work_report_type_id, resource_id, order_element_id) FROM stdin;
15959	1	eb0814b0-ad0e-4300-b50e-5c227c74fb7f	2010-05-05 00:00:00	t	15756	1128	\N
15960	2	04146c8a-a321-4d60-bff3-1e2843ec782f	2010-05-04 00:00:00	t	15756	1128	\N
15962	1	ad1c376a-1e9e-4387-a9b4-141f9e035e34	2010-05-06 00:00:00	t	15756	1128	\N
2495003	1	09d629ce-c85b-441b-94ae-6e8ec6527389	2010-05-11 00:00:00	t	15756	1132	\N
2496518	1	b664be86-97e9-45e2-af65-232fdf98188c	2010-05-09 00:00:00	t	15756	1134	\N
2496522	1	a1dc2622-48a6-42d3-a458-830134ba4bbd	2010-05-12 00:00:00	t	15756	1134	\N
3507326	1	dc871c3e-0e00-4222-97a8-cdcdf3b2b4a7	2010-05-17 00:00:00	t	15756	1123	\N
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, positionnumber, label_type_id, label_id, work_report_type_id) FROM stdin;
15857	1	f	1	1315	1428	15756
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, code, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
16060	1	c28be531-148c-49aa-b774-b915a2cd06d0	8	2010-05-05 00:00:00	\N	\N	15959	1128	13465	16160
16061	2	6c7e151a-fff6-47a7-990a-c166b0da3d18	8	2010-05-04 00:00:00	\N	\N	15960	1128	13465	16160
16063	1	9d38726d-6693-4cfc-8a0d-65aeb5ad5697	8	2010-05-06 00:00:00	\N	\N	15962	1128	13465	16160
2495104	1	1433241e-97b5-4c38-8cc2-4454dd248855	8	2010-05-11 00:00:00	\N	\N	2495003	1132	13436	16160
2495105	1	2cc59e1b-3ebb-4aca-964d-d49b1a76337a	8	2010-05-11 00:00:00	\N	\N	2495003	1132	13435	16160
2496619	1	fd92ead9-47ba-4ff9-b272-f49b96e72335	40	2010-05-09 00:00:00	\N	\N	2496518	1134	1842	16160
2496620	1	d2aecde7-62d7-4ad2-83fd-569b54852457	40	2010-05-09 00:00:00	\N	\N	2496518	1134	1841	16160
2496621	1	70c1f219-3eb6-4f0d-84b2-004a8d1924dd	25	2010-05-09 00:00:00	\N	\N	2496518	1134	1841	16160
2496625	1	ae1be4e2-397d-4945-a1a7-cf6bc24b2a60	20	2010-05-12 00:00:00	\N	\N	2496522	1134	13466	16160
2496626	1	224d7a04-4cc7-4bf6-a138-a1224c9c539c	30	2010-05-12 00:00:00	\N	\N	2496522	1134	13465	16160
3507427	1	fef8564f-c20d-4be8-b658-13825302870e	8	2010-05-17 00:00:00	\N	\N	3507326	1123	3505044	16160
3507428	1	85bf596b-9b5b-4e87-87ca-6fee59779f33	8	2010-05-17 00:00:00	\N	\N	3507326	1123	3505045	16160
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
15756	1	Parte estándar	0001	t	t	f	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
3513189	Lorenzo	Tilve Álvaro	99999999R
3513187	Xavier	Castaño García	11111111R
3513185	José María	Casanova Crespo	11111111C
38991	Diego	Desarrollador I	11111111A
3513191	Óscar	González Fernández	88888888Y
3513197	Tomás	Casquero	20202020D
3513193	Javier	Morán Rúa	11111111E
3513195	Susana	Montes	34343434E
1123	Ramón	Soldador	12312312C
39003	Desarrollador	Corunet 4	11111111G
1130	Sara	Peón	12312312D
39005	Desarrollador	Redegal 1	11111111H
1126	Susana	Peón	12312313D
14345	Susana	Pintora	34343444D
38993	Manuel	Desarrollador I	11111111B
39017	Manuel	Pan	22222222B
39022	Agustín	Asolif	22222222C
1132	Samuel	Andamiero	12312312P
39015	Luis	Agasol	22222222A
1136	Jaime	Andamiero	12312333R
38999	Desarrollador	Corunet 2	11111111E
39020	David	Corunet	22222222D
3504499	Example 1	Resource	34444444D
39007	Desarrollador	Redegal 2	11111111J
26463	Manuel	Viveiro Ríos	44543678D
39011	Desarrollador	Egalcom 1	11111111U
1128	Luis	Peón	12312312E
1121	María	Soldadora	F12312323
14343	José María	Pintor	33333333C
39013	Desarrollador	Egalcom 2	11111111o
39009	Desarrollador	Redegal 3	11111111K
38995	Jacobo	Desarrollador I	11111111C
39001	Desarrollador	Corunet 3	11111111F
1134	Alicia	Andamiera	12312312G
38987	Silvia	Gruísta	34343434e
38997	Desarrollador 	Corunet 1	11111111D
1119	José	Soldador	C12312312
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
16060	1428
16061	1428
16063	1428
2495104	1428
2495105	1428
2496619	1428
2496620	1428
2496621	1428
2496625	1428
2496626	1428
3507427	1428
3507428	1428
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advanceassignmenttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT advanceassignmenttemplate_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_code_key UNIQUE (code);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_code_key UNIQUE (code);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_code_key UNIQUE (code);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_code_key UNIQUE (code);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: consolidatedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT consolidatedvalue_pkey PRIMARY KEY (id);


--
-- Name: consolidation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT consolidation_pkey PRIMARY KEY (id);


--
-- Name: cost_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_code_key UNIQUE (code);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_code_key UNIQUE (code);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_code_key UNIQUE (code);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_code_key UNIQUE (code);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: external_company_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_name_key UNIQUE (name);


--
-- Name: external_company_nif_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_nif_key UNIQUE (nif);


--
-- Name: external_company_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT external_company_pkey PRIMARY KEY (id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hour_cost_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_code_key UNIQUE (code);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_code_key UNIQUE (code);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_code_key UNIQUE (code);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT limiting_resource_queue_dependency_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_element_resource_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT limiting_resource_queue_element_resource_allocation_id_key UNIQUE (resource_allocation_id);


--
-- Name: limiting_resource_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_pkey PRIMARY KEY (id);


--
-- Name: limiting_resource_queue_resource_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT limiting_resource_queue_resource_id_key UNIQUE (resource_id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_template_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT material_assigment_template_pkey PRIMARY KEY (id);


--
-- Name: material_category_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_code_key UNIQUE (code);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT order_authorization_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_element_template_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT order_element_template_label_pkey PRIMARY KEY (order_element_template_id, label_id);


--
-- Name: order_element_template_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT order_element_template_quality_form_pkey PRIMARY KEY (order_element_template_id, quality_form_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_code_key UNIQUE (code);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderelementtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT orderelementtemplate_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegrouptemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT orderlinegrouptemplate_pkey PRIMARY KEY (group_template_id);


--
-- Name: orderlinetemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT orderlinetemplate_pkey PRIMARY KEY (order_line_template_id);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: ordertemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT ordertemplate_pkey PRIMARY KEY (order_template_id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_base_calendar_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_base_calendar_id_key UNIQUE (base_calendar_id);


--
-- Name: resource_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_code_key UNIQUE (code);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_code_key UNIQUE (code);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: subcontractedtaskdata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT subcontractedtaskdata_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: task_subcontrated_task_data_id_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_subcontrated_task_data_id_key UNIQUE (subcontrated_task_data_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: unit_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_code_key UNIQUE (code);


--
-- Name: unit_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY unit_type
    ADD CONSTRAINT unit_type_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_code_key UNIQUE (code);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_code_key UNIQUE (code);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk1ccb0f7419b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f7419b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk1ccb0f74b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment_template
    ADD CONSTRAINT fk1ccb0f74b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fk1fc5f45575ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f45575ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk1fc5f455bd2209e8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_element
    ADD CONSTRAINT fk1fc5f455bd2209e8 FOREIGN KEY (limiting_resource_queue_id) REFERENCES limiting_resource_queue(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk27a9a55b595a0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a55b595a0 FOREIGN KEY (subcontrated_task_data_id) REFERENCES subcontractedtaskdata(id);


--
-- Name: fk29d0015519b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d0015519b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk29d001558b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_quality_form
    ADD CONSTRAINT fk29d001558b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk3a79eb0219b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0219b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk40795527f11b2d0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk40795527f11b2d0 FOREIGN KEY (unit_type) REFERENCES unit_type(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk49876b734287ea05; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY pending_consolidated_hours
    ADD CONSTRAINT fk49876b734287ea05 FOREIGN KEY (pending_hours_id) REFERENCES consolidatedvalue(id);


--
-- Name: fk49876b7375ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY pending_consolidated_hours
    ADD CONSTRAINT fk49876b7375ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk4a1d42dc9fb7fc18; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinetemplate
    ADD CONSTRAINT fk4a1d42dc9fb7fc18 FOREIGN KEY (order_line_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fk4d68b9c89a4a7d90; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c89a4a7d90 FOREIGN KEY (order_template_id) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fk4d68b9c8a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY ordertemplate
    ADD CONSTRAINT fk4d68b9c8a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5948535285ebb87c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk5948535285ebb87c FOREIGN KEY (destiny_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk59485352a44b51e8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue_dependency
    ADD CONSTRAINT fk59485352a44b51e8 FOREIGN KEY (origin_queue_element_id) REFERENCES limiting_resource_queue_element(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be6ee3f5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be6ee3f5d FOREIGN KEY (queue_dependency) REFERENCES limiting_resource_queue_dependency(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39d4ec080cf; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39d4ec080cf FOREIGN KEY (customer) REFERENCES external_company(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk7e57469848d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY limiting_resource_queue
    ADD CONSTRAINT fk7e57469848d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk8217a424b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT fk8217a424b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fk9bb0b28841638aab; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelementtemplate
    ADD CONSTRAINT fk9bb0b28841638aab FOREIGN KEY (parent) REFERENCES orderlinegrouptemplate(group_template_id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fka87c31085567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c31085567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fka87c310887287288; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c310887287288 FOREIGN KEY (order_id) REFERENCES order_table(orderelementid);


--
-- Name: fka87c3108edc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_authorization
    ADD CONSTRAINT fka87c3108edc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fka9542ec319b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec319b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fka9542ec3c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_template_label
    ADD CONSTRAINT fka9542ec3c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f501b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f501b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkcf1f2cd08bdc6ac6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd08bdc6ac6 FOREIGN KEY (order_line_template) REFERENCES orderlinetemplate(order_line_template_id);


--
-- Name: fkd3056ef7ddc82952; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegrouptemplate
    ADD CONSTRAINT fkd3056ef7ddc82952 FOREIGN KEY (group_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fkdbbb4feed97bcc8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4feed97bcc8c FOREIGN KEY (template) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb026919b9dfde; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb026919b9dfde FOREIGN KEY (order_element_template_id) REFERENCES orderelementtemplate(id);


--
-- Name: fkdfdb0269b216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignmenttemplate
    ADD CONSTRAINT fkdfdb0269b216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke562c7e93fee60cc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY external_company
    ADD CONSTRAINT fke562c7e93fee60cc FOREIGN KEY (companyuser) REFERENCES naval_user(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkecc6114019960f43; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY subcontractedtaskdata
    ADD CONSTRAINT fkecc6114019960f43 FOREIGN KEY (externalcompany) REFERENCES external_company(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282edc874c20; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282edc874c20 FOREIGN KEY (base_calendar_id) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf436a4163ae24ff8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a4163ae24ff8 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf436a416b96bba28; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416b96bba28 FOREIGN KEY (advance_measurement_id) REFERENCES advancemeasurement(id);


--
-- Name: fkf436a416cec54333; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidatedvalue
    ADD CONSTRAINT fkf436a416cec54333 FOREIGN KEY (consolidation_id) REFERENCES consolidation(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf8df3e0c430ea1de; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c430ea1de FOREIGN KEY (ind_advance_assignment_id) REFERENCES indirectadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0c9f1d6611; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0c9f1d6611 FOREIGN KEY (dir_advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkf8df3e0cff2b2ba3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY consolidation
    ADD CONSTRAINT fkf8df3e0cff2b2ba3 FOREIGN KEY (id) REFERENCES task(task_element_id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

