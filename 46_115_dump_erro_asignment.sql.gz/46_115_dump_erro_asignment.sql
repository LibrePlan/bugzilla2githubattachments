-- MySQL dump 10.11
--
-- Host: localhost    Database: navaldev
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ASSIGNMENT_FUNCTION`
--

DROP TABLE IF EXISTS `ASSIGNMENT_FUNCTION`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ASSIGNMENT_FUNCTION` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ASSIGNMENT_FUNCTION`
--

LOCK TABLES `ASSIGNMENT_FUNCTION` WRITE;
/*!40000 ALTER TABLE `ASSIGNMENT_FUNCTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `ASSIGNMENT_FUNCTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AdvanceAssignment`
--

DROP TABLE IF EXISTS `AdvanceAssignment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `AdvanceAssignment` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `reportGlobalAdvance` bit(1) default NULL,
  `ADVANCE_TYPE_ID` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK808010CFB216ED4C` (`ADVANCE_TYPE_ID`),
  CONSTRAINT `FK808010CFB216ED4C` FOREIGN KEY (`ADVANCE_TYPE_ID`) REFERENCES `AdvanceType` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `AdvanceAssignment`
--

LOCK TABLES `AdvanceAssignment` WRITE;
/*!40000 ALTER TABLE `AdvanceAssignment` DISABLE KEYS */;
INSERT INTO `AdvanceAssignment` VALUES (1313,6,'',202),(1314,6,'',202),(1317,1,'',203),(1318,1,'\0',203);
/*!40000 ALTER TABLE `AdvanceAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AdvanceMeasurement`
--

DROP TABLE IF EXISTS `AdvanceMeasurement`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `AdvanceMeasurement` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date` date default NULL,
  `value` decimal(19,2) default NULL,
  `ADVANCE_ASSIGNMENT_ID` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKBB2F91FAA9E53843` (`ADVANCE_ASSIGNMENT_ID`),
  KEY `FKBB2F91FA2F2D3AEC` (`ADVANCE_ASSIGNMENT_ID`),
  CONSTRAINT `FKBB2F91FA2F2D3AEC` FOREIGN KEY (`ADVANCE_ASSIGNMENT_ID`) REFERENCES `AdvanceAssignment` (`id`),
  CONSTRAINT `FKBB2F91FAA9E53843` FOREIGN KEY (`ADVANCE_ASSIGNMENT_ID`) REFERENCES `DirectAdvanceAssignment` (`ADVANCE_ASSIGNMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `AdvanceMeasurement`
--

LOCK TABLES `AdvanceMeasurement` WRITE;
/*!40000 ALTER TABLE `AdvanceMeasurement` DISABLE KEYS */;
INSERT INTO `AdvanceMeasurement` VALUES (2325,1,'2009-10-15','40.00',1317),(2326,1,'2009-10-05','20.00',1317);
/*!40000 ALTER TABLE `AdvanceMeasurement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AdvanceType`
--

DROP TABLE IF EXISTS `AdvanceType`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `AdvanceType` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `unitName` varchar(255) default NULL,
  `defaultMaxValue` decimal(19,4) default NULL,
  `updatable` bit(1) default NULL,
  `unitPrecision` decimal(19,4) default NULL,
  `active` bit(1) default NULL,
  `percentage` bit(1) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unitName` (`unitName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `AdvanceType`
--

LOCK TABLES `AdvanceType` WRITE;
/*!40000 ALTER TABLE `AdvanceType` DISABLE KEYS */;
INSERT INTO `AdvanceType` VALUES (202,3,'children','100.0000','\0','0.0100','',''),(203,2,'percentage','100.0000','\0','0.0100','',''),(204,1,'units','2147483647.0000','\0','1.0000','','\0'),(303,1,'Presuposto','6000000.0000','','1000.0000','','\0'),(304,1,'Presupostado pactado','6000000.0000','','1000.0000','','\0');
/*!40000 ALTER TABLE `AdvanceType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BaseCalendar`
--

DROP TABLE IF EXISTS `BaseCalendar`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `BaseCalendar` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `BaseCalendar`
--

LOCK TABLES `BaseCalendar` WRITE;
/*!40000 ALTER TABLE `BaseCalendar` DISABLE KEYS */;
INSERT INTO `BaseCalendar` VALUES (404,1,'España'),(405,2,'c1');
/*!40000 ALTER TABLE `BaseCalendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CRITERION_TYPE_WORK_REPORT_TYPE`
--

DROP TABLE IF EXISTS `CRITERION_TYPE_WORK_REPORT_TYPE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CRITERION_TYPE_WORK_REPORT_TYPE` (
  `WORK_REPORT_TYPE_ID` bigint(20) NOT NULL default '0',
  `CRITERION_TYPE_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`WORK_REPORT_TYPE_ID`,`CRITERION_TYPE_ID`),
  KEY `FK4822B25E131853A1` (`WORK_REPORT_TYPE_ID`),
  KEY `FK4822B25EFF876347` (`CRITERION_TYPE_ID`),
  CONSTRAINT `FK4822B25EFF876347` FOREIGN KEY (`CRITERION_TYPE_ID`) REFERENCES `CriterionType` (`id`),
  CONSTRAINT `FK4822B25E131853A1` FOREIGN KEY (`WORK_REPORT_TYPE_ID`) REFERENCES `WORK_REPORT_TYPE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CRITERION_TYPE_WORK_REPORT_TYPE`
--

LOCK TABLES `CRITERION_TYPE_WORK_REPORT_TYPE` WRITE;
/*!40000 ALTER TABLE `CRITERION_TYPE_WORK_REPORT_TYPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CRITERION_TYPE_WORK_REPORT_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CRITERION_WORK_REPORT_LINE`
--

DROP TABLE IF EXISTS `CRITERION_WORK_REPORT_LINE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CRITERION_WORK_REPORT_LINE` (
  `WORK_REPORT_LINE_ID` bigint(20) NOT NULL default '0',
  `CRITERION_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`WORK_REPORT_LINE_ID`,`CRITERION_ID`),
  KEY `FK9654B9EF61F02C44` (`CRITERION_ID`),
  KEY `FK9654B9EF5078E161` (`WORK_REPORT_LINE_ID`),
  CONSTRAINT `FK9654B9EF5078E161` FOREIGN KEY (`WORK_REPORT_LINE_ID`) REFERENCES `WORK_REPORT_LINE` (`id`),
  CONSTRAINT `FK9654B9EF61F02C44` FOREIGN KEY (`CRITERION_ID`) REFERENCES `Criterion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CRITERION_WORK_REPORT_LINE`
--

LOCK TABLES `CRITERION_WORK_REPORT_LINE` WRITE;
/*!40000 ALTER TABLE `CRITERION_WORK_REPORT_LINE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CRITERION_WORK_REPORT_LINE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalendarData`
--

DROP TABLE IF EXISTS `CalendarData`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CalendarData` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `parent` bigint(20) default NULL,
  `expiringDate` date default NULL,
  `BASE_CALENDAR_ID` bigint(20) default NULL,
  `POSITION_IN_CALENDAR` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKF4BEE428A44ABEE3` (`BASE_CALENDAR_ID`),
  KEY `FKF4BEE4287FA34E3F` (`parent`),
  CONSTRAINT `FKF4BEE4287FA34E3F` FOREIGN KEY (`parent`) REFERENCES `BaseCalendar` (`id`),
  CONSTRAINT `FKF4BEE428A44ABEE3` FOREIGN KEY (`BASE_CALENDAR_ID`) REFERENCES `BaseCalendar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CalendarData`
--

LOCK TABLES `CalendarData` WRITE;
/*!40000 ALTER TABLE `CalendarData` DISABLE KEYS */;
INSERT INTO `CalendarData` VALUES (505,1,NULL,NULL,404,0),(506,2,404,NULL,405,0);
/*!40000 ALTER TABLE `CalendarData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Criterion`
--

DROP TABLE IF EXISTS `Criterion`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Criterion` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  `active` bit(1) default NULL,
  `id_criterion_type` bigint(20) NOT NULL,
  `parent` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`,`id_criterion_type`),
  KEY `FK8E542E8114A5C61` (`id_criterion_type`),
  KEY `FK8E542E813A156175` (`parent`),
  CONSTRAINT `FK8E542E813A156175` FOREIGN KEY (`parent`) REFERENCES `Criterion` (`id`),
  CONSTRAINT `FK8E542E8114A5C61` FOREIGN KEY (`id_criterion_type`) REFERENCES `CriterionType` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Criterion`
--

LOCK TABLES `Criterion` WRITE;
/*!40000 ALTER TABLE `Criterion` DISABLE KEYS */;
INSERT INTO `Criterion` VALUES (101,14,'medicalLeave','',1,NULL),(102,13,'paternityLeave','',1,NULL),(103,4,'hiredResourceWorkingRelationship','',5,NULL),(104,3,'firedResourceWorkingRelationship','',5,NULL),(909,1,'Trazador','',4,NULL),(910,1,'Soldador','',4,NULL),(911,1,'Tornero','',4,NULL),(912,1,'Delineante','',4,NULL),(913,1,'Calderero','',4,NULL),(914,1,'Peon','',2,NULL),(915,1,'Oficial 2ª','',2,NULL),(916,1,'Oficial 1ª','',2,NULL);
/*!40000 ALTER TABLE `Criterion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CriterionHoursGroup`
--

DROP TABLE IF EXISTS `CriterionHoursGroup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CriterionHoursGroup` (
  `hoursGroupId` bigint(20) NOT NULL default '0',
  `criterionId` bigint(20) NOT NULL,
  PRIMARY KEY  (`hoursGroupId`,`criterionId`),
  KEY `FKA3CFEE1117B6C7CD` (`hoursGroupId`),
  KEY `FKA3CFEE115C035047` (`criterionId`),
  CONSTRAINT `FKA3CFEE115C035047` FOREIGN KEY (`criterionId`) REFERENCES `Criterion` (`id`),
  CONSTRAINT `FKA3CFEE1117B6C7CD` FOREIGN KEY (`hoursGroupId`) REFERENCES `HoursGroup` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CriterionHoursGroup`
--

LOCK TABLES `CriterionHoursGroup` WRITE;
/*!40000 ALTER TABLE `CriterionHoursGroup` DISABLE KEYS */;
INSERT INTO `CriterionHoursGroup` VALUES (1212,912),(1213,912),(1214,912),(1215,912),(1216,912),(1217,912);
/*!40000 ALTER TABLE `CriterionHoursGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CriterionSatisfaction`
--

DROP TABLE IF EXISTS `CriterionSatisfaction`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CriterionSatisfaction` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `startDate` datetime NOT NULL,
  `finishDate` datetime default NULL,
  `isDeleted` bit(1) default NULL,
  `criterion` bigint(20) NOT NULL,
  `resource` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK3F30D9AD8C4C676C` (`criterion`),
  KEY `FK3F30D9ADEAE850B2` (`resource`),
  CONSTRAINT `FK3F30D9ADEAE850B2` FOREIGN KEY (`resource`) REFERENCES `Resource` (`id`),
  CONSTRAINT `FK3F30D9AD8C4C676C` FOREIGN KEY (`criterion`) REFERENCES `Criterion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CriterionSatisfaction`
--

LOCK TABLES `CriterionSatisfaction` WRITE;
/*!40000 ALTER TABLE `CriterionSatisfaction` DISABLE KEYS */;
INSERT INTO `CriterionSatisfaction` VALUES (1010,2,'2009-10-15 21:59:06',NULL,'\0',911,808),(1011,2,'2009-10-15 21:58:49',NULL,'\0',912,808),(1012,2,'2009-10-15 21:59:12',NULL,'\0',913,808);
/*!40000 ALTER TABLE `CriterionSatisfaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CriterionType`
--

DROP TABLE IF EXISTS `CriterionType`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CriterionType` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `allowSimultaneousCriterionsPerResource` bit(1) default NULL,
  `allowHierarchy` bit(1) default NULL,
  `enabled` bit(1) default NULL,
  `resource` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CriterionType`
--

LOCK TABLES `CriterionType` WRITE;
/*!40000 ALTER TABLE `CriterionType` DISABLE KEYS */;
INSERT INTO `CriterionType` VALUES (1,15,'LEAVE','Leave','\0','\0','',1),(2,12,'CATEGORY','Professional category','','','',1),(3,9,'TRAINING','Training courses and labor training','','','',1),(4,8,'JOB','Job','','','',1),(5,5,'WORK_RELATIONSHIP','Relationship of the resource with the enterprise ','\0','\0','',1),(6,1,'LOCATION_GROUP','Location where the resource work','','\0','',0);
/*!40000 ALTER TABLE `CriterionType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dependency`
--

DROP TABLE IF EXISTS `Dependency`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Dependency` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `ORIGIN` bigint(20) default NULL,
  `DESTINATION` bigint(20) default NULL,
  `type` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK7540AF6BE838F362` (`DESTINATION`),
  KEY `FK7540AF6B1545E7A` (`ORIGIN`),
  CONSTRAINT `FK7540AF6B1545E7A` FOREIGN KEY (`ORIGIN`) REFERENCES `TaskElement` (`id`),
  CONSTRAINT `FK7540AF6BE838F362` FOREIGN KEY (`DESTINATION`) REFERENCES `TaskElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Dependency`
--

LOCK TABLES `Dependency` WRITE;
/*!40000 ALTER TABLE `Dependency` DISABLE KEYS */;
INSERT INTO `Dependency` VALUES (491523,5,1416,1417,0),(491524,5,1415,1416,0),(491525,5,1418,1420,0),(491530,2,1420,1421,0),(491532,2,1417,1421,0),(491533,2,1420,1421,0);
/*!40000 ALTER TABLE `Dependency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DirectAdvanceAssignment`
--

DROP TABLE IF EXISTS `DirectAdvanceAssignment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `DirectAdvanceAssignment` (
  `ADVANCE_ASSIGNMENT_ID` bigint(20) NOT NULL,
  `DIRECT_ORDER_ELEMENT_ID` bigint(20) default NULL,
  `maxValue` decimal(19,2) default NULL,
  PRIMARY KEY  (`ADVANCE_ASSIGNMENT_ID`),
  KEY `FKFC7B7BE6A1127CE5` (`DIRECT_ORDER_ELEMENT_ID`),
  KEY `FKFC7B7BE62F2D3AEC` (`ADVANCE_ASSIGNMENT_ID`),
  CONSTRAINT `FKFC7B7BE62F2D3AEC` FOREIGN KEY (`ADVANCE_ASSIGNMENT_ID`) REFERENCES `AdvanceAssignment` (`id`),
  CONSTRAINT `FKFC7B7BE6A1127CE5` FOREIGN KEY (`DIRECT_ORDER_ELEMENT_ID`) REFERENCES `OrderElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `DirectAdvanceAssignment`
--

LOCK TABLES `DirectAdvanceAssignment` WRITE;
/*!40000 ALTER TABLE `DirectAdvanceAssignment` DISABLE KEYS */;
INSERT INTO `DirectAdvanceAssignment` VALUES (1317,1112,'100.00');
/*!40000 ALTER TABLE `DirectAdvanceAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExceptionDay`
--

DROP TABLE IF EXISTS `ExceptionDay`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ExceptionDay` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date` date default NULL,
  `hours` int(11) default NULL,
  `BASE_CALENDAR_ID` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKF9CE78EDA44ABEE3` (`BASE_CALENDAR_ID`),
  CONSTRAINT `FKF9CE78EDA44ABEE3` FOREIGN KEY (`BASE_CALENDAR_ID`) REFERENCES `BaseCalendar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ExceptionDay`
--

LOCK TABLES `ExceptionDay` WRITE;
/*!40000 ALTER TABLE `ExceptionDay` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExceptionDay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HoursGroup`
--

DROP TABLE IF EXISTS `HoursGroup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `HoursGroup` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `workingHours` int(11) default NULL,
  `percentage` decimal(19,2) default NULL,
  `fixedPercentage` bit(1) default NULL,
  `PARENT_ORDER_LINE` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKCF1F2CD01ED629EA` (`PARENT_ORDER_LINE`),
  CONSTRAINT `FKCF1F2CD01ED629EA` FOREIGN KEY (`PARENT_ORDER_LINE`) REFERENCES `OrderLine` (`ORDERELEMENTID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `HoursGroup`
--

LOCK TABLES `HoursGroup` WRITE;
/*!40000 ALTER TABLE `HoursGroup` DISABLE KEYS */;
INSERT INTO `HoursGroup` VALUES (1212,6,300,'1.00','\0',1112),(1213,6,200,'1.00','\0',1113),(1214,6,1500,'1.00','\0',1114),(1215,6,100,'1.00','\0',1115),(1216,6,50,'1.00','\0',1117),(1217,6,60,'1.00','\0',1118);
/*!40000 ALTER TABLE `HoursGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IndirectAdvanceAssignment`
--

DROP TABLE IF EXISTS `IndirectAdvanceAssignment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `IndirectAdvanceAssignment` (
  `ADVANCE_ASSIGNMENT_ID` bigint(20) NOT NULL,
  `INDIRECT_ORDER_ELEMENT_ID` bigint(20) default NULL,
  PRIMARY KEY  (`ADVANCE_ASSIGNMENT_ID`),
  KEY `FK3D1FFD218202350F` (`INDIRECT_ORDER_ELEMENT_ID`),
  KEY `FK3D1FFD21218D7620` (`INDIRECT_ORDER_ELEMENT_ID`),
  KEY `FK3D1FFD212F2D3AEC` (`ADVANCE_ASSIGNMENT_ID`),
  CONSTRAINT `FK3D1FFD212F2D3AEC` FOREIGN KEY (`ADVANCE_ASSIGNMENT_ID`) REFERENCES `AdvanceAssignment` (`id`),
  CONSTRAINT `FK3D1FFD21218D7620` FOREIGN KEY (`INDIRECT_ORDER_ELEMENT_ID`) REFERENCES `OrderElement` (`id`),
  CONSTRAINT `FK3D1FFD218202350F` FOREIGN KEY (`INDIRECT_ORDER_ELEMENT_ID`) REFERENCES `OrderLineGroup` (`ORDERELEMENTID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `IndirectAdvanceAssignment`
--

LOCK TABLES `IndirectAdvanceAssignment` WRITE;
/*!40000 ALTER TABLE `IndirectAdvanceAssignment` DISABLE KEYS */;
INSERT INTO `IndirectAdvanceAssignment` VALUES (1314,1111),(1318,1111),(1313,1116);
/*!40000 ALTER TABLE `IndirectAdvanceAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LABEL`
--

DROP TABLE IF EXISTS `LABEL`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `LABEL` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  `LABEL_TYPE_ID` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`,`LABEL_TYPE_ID`),
  KEY `FK44D86D4707CD777` (`LABEL_TYPE_ID`),
  CONSTRAINT `FK44D86D4707CD777` FOREIGN KEY (`LABEL_TYPE_ID`) REFERENCES `LABEL_TYPE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `LABEL`
--

LOCK TABLES `LABEL` WRITE;
/*!40000 ALTER TABLE `LABEL` DISABLE KEYS */;
INSERT INTO `LABEL` VALUES (707,1,'Bodega',606),(708,1,'Cubierta',606),(709,1,'Motores',606),(710,1,'Puente de mando',606),(711,1,'Vulcano',607),(712,1,'Navantia',607);
/*!40000 ALTER TABLE `LABEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LABEL_TYPE`
--

DROP TABLE IF EXISTS `LABEL_TYPE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `LABEL_TYPE` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `LABEL_TYPE`
--

LOCK TABLES `LABEL_TYPE` WRITE;
/*!40000 ALTER TABLE `LABEL_TYPE` DISABLE KEYS */;
INSERT INTO `LABEL_TYPE` VALUES (606,1,'Zona'),(607,1,'Cliente');
/*!40000 ALTER TABLE `LABEL_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_ELEMENT_LABEL`
--

DROP TABLE IF EXISTS `ORDER_ELEMENT_LABEL`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ORDER_ELEMENT_LABEL` (
  `ORDER_ELEMENT_ID` bigint(20) NOT NULL,
  `LABEL_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`ORDER_ELEMENT_ID`,`LABEL_ID`),
  KEY `FKE203860C1C2746E` (`LABEL_ID`),
  KEY `FKE203860EFDA874F` (`ORDER_ELEMENT_ID`),
  CONSTRAINT `FKE203860EFDA874F` FOREIGN KEY (`ORDER_ELEMENT_ID`) REFERENCES `OrderElement` (`id`),
  CONSTRAINT `FKE203860C1C2746E` FOREIGN KEY (`LABEL_ID`) REFERENCES `LABEL` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ORDER_ELEMENT_LABEL`
--

LOCK TABLES `ORDER_ELEMENT_LABEL` WRITE;
/*!40000 ALTER TABLE `ORDER_ELEMENT_LABEL` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORDER_ELEMENT_LABEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderElement`
--

DROP TABLE IF EXISTS `OrderElement`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `OrderElement` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  `initDate` datetime default NULL,
  `endDate` datetime default NULL,
  `mandatoryInit` bit(1) default NULL,
  `mandatoryEnd` bit(1) default NULL,
  `description` varchar(255) default NULL,
  `code` varchar(255) default NULL,
  `parent` bigint(20) default NULL,
  `positionInContainer` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKDBBB4FEE1E635C19` (`parent`),
  CONSTRAINT `FKDBBB4FEE1E635C19` FOREIGN KEY (`parent`) REFERENCES `OrderLineGroup` (`ORDERELEMENTID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `OrderElement`
--

LOCK TABLES `OrderElement` WRITE;
/*!40000 ALTER TABLE `OrderElement` DISABLE KEYS */;
INSERT INTO `OrderElement` VALUES (1111,6,'Consultoría montaxe aplicación','2009-10-15 22:04:29',NULL,'\0','\0','Desc.','ped1',NULL,NULL),(1112,6,'Coordinación',NULL,NULL,'\0','\0','','ped1.1',1111,0),(1113,6,'Análise',NULL,NULL,'\0','\0','','ped1.2',1111,1),(1114,6,'Desenvolvemento',NULL,NULL,'\0','\0','','ped1.3',1111,2),(1115,6,'Validación',NULL,NULL,'\0','\0','','ped1.4',1111,3),(1116,6,'Probas',NULL,NULL,'\0','\0','','ped1.5',1111,4),(1117,6,'Probas funcionales',NULL,NULL,'\0','\0','','ped1.6',1116,0),(1118,6,'Probas unitarias',NULL,NULL,'\0','\0','','ped1.51',1116,1);
/*!40000 ALTER TABLE `OrderElement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderLine`
--

DROP TABLE IF EXISTS `OrderLine`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `OrderLine` (
  `ORDERELEMENTID` bigint(20) NOT NULL,
  PRIMARY KEY  (`ORDERELEMENTID`),
  KEY `FK6017744297B1C209` (`ORDERELEMENTID`),
  CONSTRAINT `FK6017744297B1C209` FOREIGN KEY (`ORDERELEMENTID`) REFERENCES `OrderElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `OrderLine`
--

LOCK TABLES `OrderLine` WRITE;
/*!40000 ALTER TABLE `OrderLine` DISABLE KEYS */;
INSERT INTO `OrderLine` VALUES (1112),(1113),(1114),(1115),(1117),(1118);
/*!40000 ALTER TABLE `OrderLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderLineGroup`
--

DROP TABLE IF EXISTS `OrderLineGroup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `OrderLineGroup` (
  `ORDERELEMENTID` bigint(20) NOT NULL,
  PRIMARY KEY  (`ORDERELEMENTID`),
  KEY `FK7D2EEB5D97B1C209` (`ORDERELEMENTID`),
  CONSTRAINT `FK7D2EEB5D97B1C209` FOREIGN KEY (`ORDERELEMENTID`) REFERENCES `OrderElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `OrderLineGroup`
--

LOCK TABLES `OrderLineGroup` WRITE;
/*!40000 ALTER TABLE `OrderLineGroup` DISABLE KEYS */;
INSERT INTO `OrderLineGroup` VALUES (1111),(1116);
/*!40000 ALTER TABLE `OrderLineGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Resource`
--

DROP TABLE IF EXISTS `Resource`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Resource` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `calendar` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `calendar` (`calendar`),
  KEY `FKEF86282EE893CE10` (`calendar`),
  CONSTRAINT `FKEF86282EE893CE10` FOREIGN KEY (`calendar`) REFERENCES `ResourceCalendar` (`BASE_CALENDAR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Resource`
--

LOCK TABLES `Resource` WRITE;
/*!40000 ALTER TABLE `Resource` DISABLE KEYS */;
INSERT INTO `Resource` VALUES (808,4,NULL),(809,1,NULL),(810,1,NULL),(811,1,NULL),(812,1,NULL);
/*!40000 ALTER TABLE `Resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceAllocation`
--

DROP TABLE IF EXISTS `ResourceAllocation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ResourceAllocation` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `resourcesPerDay` decimal(19,2) default NULL,
  `TASK` bigint(20) default NULL,
  `ASSIGNMENT_FUNCTION` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK41E073AEFF61540D` (`TASK`),
  KEY `FK41E073AE15671E92` (`ASSIGNMENT_FUNCTION`),
  CONSTRAINT `FK41E073AE15671E92` FOREIGN KEY (`ASSIGNMENT_FUNCTION`) REFERENCES `ASSIGNMENT_FUNCTION` (`id`),
  CONSTRAINT `FK41E073AEFF61540D` FOREIGN KEY (`TASK`) REFERENCES `Task` (`TASK_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ResourceAllocation`
--

LOCK TABLES `ResourceAllocation` WRITE;
/*!40000 ALTER TABLE `ResourceAllocation` DISABLE KEYS */;
INSERT INTO `ResourceAllocation` VALUES (1617,5,'1.00',1420,NULL),(1618,0,'1.00',1417,NULL),(1619,0,'1.00',1418,NULL),(1620,0,'1.00',1416,NULL),(1621,0,'1.00',1415,NULL);
/*!40000 ALTER TABLE `ResourceAllocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceCalendar`
--

DROP TABLE IF EXISTS `ResourceCalendar`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ResourceCalendar` (
  `BASE_CALENDAR_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`BASE_CALENDAR_ID`),
  KEY `FK5863798CA44ABEE3` (`BASE_CALENDAR_ID`),
  CONSTRAINT `FK5863798CA44ABEE3` FOREIGN KEY (`BASE_CALENDAR_ID`) REFERENCES `BaseCalendar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ResourceCalendar`
--

LOCK TABLES `ResourceCalendar` WRITE;
/*!40000 ALTER TABLE `ResourceCalendar` DISABLE KEYS */;
INSERT INTO `ResourceCalendar` VALUES (405);
/*!40000 ALTER TABLE `ResourceCalendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Task`
--

DROP TABLE IF EXISTS `Task`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Task` (
  `TASK_ELEMENT_ID` bigint(20) NOT NULL,
  `hoursGroup` bigint(20) default NULL,
  `calculatedValue` int(11) default NULL,
  PRIMARY KEY  (`TASK_ELEMENT_ID`),
  KEY `FK27A9A55AC3AEB2` (`hoursGroup`),
  KEY `FK27A9A54936BB8C` (`TASK_ELEMENT_ID`),
  CONSTRAINT `FK27A9A54936BB8C` FOREIGN KEY (`TASK_ELEMENT_ID`) REFERENCES `TaskElement` (`id`),
  CONSTRAINT `FK27A9A55AC3AEB2` FOREIGN KEY (`hoursGroup`) REFERENCES `HoursGroup` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Task`
--

LOCK TABLES `Task` WRITE;
/*!40000 ALTER TABLE `Task` DISABLE KEYS */;
INSERT INTO `Task` VALUES (1415,1212,1),(1416,1213,1),(1417,1214,1),(1418,1215,1),(1420,1216,1),(1421,1217,1);
/*!40000 ALTER TABLE `Task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskElement`
--

DROP TABLE IF EXISTS `TaskElement`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `TaskElement` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `shareOfHours` int(11) default NULL,
  `name` varchar(255) default NULL,
  `notes` varchar(255) default NULL,
  `startDate` datetime default NULL,
  `endDate` datetime default NULL,
  `ORDER_ELEMENT_ID` bigint(20) default NULL,
  `parent` bigint(20) default NULL,
  `BASE_CALENDAR_ID` bigint(20) default NULL,
  `positionInParent` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK70D5D997A44ABEE3` (`BASE_CALENDAR_ID`),
  KEY `FK70D5D997EFDA874F` (`ORDER_ELEMENT_ID`),
  KEY `FK70D5D997A5F3C581` (`parent`),
  CONSTRAINT `FK70D5D997A5F3C581` FOREIGN KEY (`parent`) REFERENCES `TaskGroup` (`TASK_ELEMENT_ID`),
  CONSTRAINT `FK70D5D997A44ABEE3` FOREIGN KEY (`BASE_CALENDAR_ID`) REFERENCES `BaseCalendar` (`id`),
  CONSTRAINT `FK70D5D997EFDA874F` FOREIGN KEY (`ORDER_ELEMENT_ID`) REFERENCES `OrderElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `TaskElement`
--

LOCK TABLES `TaskElement` WRITE;
/*!40000 ALTER TABLE `TaskElement` DISABLE KEYS */;
INSERT INTO `TaskElement` VALUES (1414,4,NULL,NULL,NULL,'2009-10-15 00:00:00','2010-06-25 12:00:00',1111,NULL,NULL,NULL),(1415,4,NULL,'Coordinación',NULL,'2009-10-15 00:00:00','2009-11-22 00:00:00',1112,1414,NULL,0),(1416,4,NULL,'Análise',NULL,'2009-11-22 00:00:00','2009-12-17 00:00:00',1113,1414,NULL,1),(1417,4,NULL,'Desenvolvemento',NULL,'2009-12-17 00:00:00','2010-06-23 00:00:00',1114,1414,NULL,2),(1418,4,NULL,'Validación',NULL,'2009-10-28 00:00:00','2009-11-10 00:00:00',1115,1414,NULL,3),(1419,4,NULL,'Probas',NULL,'2009-11-10 00:00:00','2010-06-25 12:00:00',1116,1414,NULL,4),(1420,4,NULL,'Probas funcionales',NULL,'2009-11-10 00:00:00','2009-11-17 00:00:00',1117,1419,NULL,0),(1421,4,NULL,'Probas unitarias',NULL,'2010-06-23 00:00:00','2010-06-25 12:00:00',1118,1419,NULL,1);
/*!40000 ALTER TABLE `TaskElement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskGroup`
--

DROP TABLE IF EXISTS `TaskGroup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `TaskGroup` (
  `TASK_ELEMENT_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`TASK_ELEMENT_ID`),
  KEY `FK80E79BDA4936BB8C` (`TASK_ELEMENT_ID`),
  CONSTRAINT `FK80E79BDA4936BB8C` FOREIGN KEY (`TASK_ELEMENT_ID`) REFERENCES `TaskElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `TaskGroup`
--

LOCK TABLES `TaskGroup` WRITE;
/*!40000 ALTER TABLE `TaskGroup` DISABLE KEYS */;
INSERT INTO `TaskGroup` VALUES (1414),(1419);
/*!40000 ALTER TABLE `TaskGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskMilestone`
--

DROP TABLE IF EXISTS `TaskMilestone`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `TaskMilestone` (
  `TASK_ELEMENT_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`TASK_ELEMENT_ID`),
  KEY `FK62B2994B4936BB8C` (`TASK_ELEMENT_ID`),
  CONSTRAINT `FK62B2994B4936BB8C` FOREIGN KEY (`TASK_ELEMENT_ID`) REFERENCES `TaskElement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `TaskMilestone`
--

LOCK TABLES `TaskMilestone` WRITE;
/*!40000 ALTER TABLE `TaskMilestone` DISABLE KEYS */;
/*!40000 ALTER TABLE `TaskMilestone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WORK_REPORT`
--

DROP TABLE IF EXISTS `WORK_REPORT`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `WORK_REPORT` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date` datetime default NULL,
  `place` varchar(255) default NULL,
  `responsible` varchar(255) default NULL,
  `WORK_REPORT_TYPE_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK1A95A222131853A1` (`WORK_REPORT_TYPE_ID`),
  CONSTRAINT `FK1A95A222131853A1` FOREIGN KEY (`WORK_REPORT_TYPE_ID`) REFERENCES `WORK_REPORT_TYPE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `WORK_REPORT`
--

LOCK TABLES `WORK_REPORT` WRITE;
/*!40000 ALTER TABLE `WORK_REPORT` DISABLE KEYS */;
INSERT INTO `WORK_REPORT` VALUES (2121,1,'2009-10-15 00:00:00','Vigo','Xavi',2020),(2123,1,'2009-10-15 00:00:00','Vigo','Xavier',2020);
/*!40000 ALTER TABLE `WORK_REPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WORK_REPORT_LINE`
--

DROP TABLE IF EXISTS `WORK_REPORT_LINE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `WORK_REPORT_LINE` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `numHours` int(11) default NULL,
  `WORK_REPORT_ID` bigint(20) default NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `ORDER_ELEMENT_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKEB02C3F1F1A3177C` (`WORK_REPORT_ID`),
  KEY `FKEB02C3F148D21790` (`RESOURCE_ID`),
  KEY `FKEB02C3F1EFDA874F` (`ORDER_ELEMENT_ID`),
  CONSTRAINT `FKEB02C3F1EFDA874F` FOREIGN KEY (`ORDER_ELEMENT_ID`) REFERENCES `OrderElement` (`id`),
  CONSTRAINT `FKEB02C3F148D21790` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `Resource` (`id`),
  CONSTRAINT `FKEB02C3F1F1A3177C` FOREIGN KEY (`WORK_REPORT_ID`) REFERENCES `WORK_REPORT` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `WORK_REPORT_LINE`
--

LOCK TABLES `WORK_REPORT_LINE` WRITE;
/*!40000 ALTER TABLE `WORK_REPORT_LINE` DISABLE KEYS */;
INSERT INTO `WORK_REPORT_LINE` VALUES (2222,1,8,2121,808,1112),(2223,1,8,2121,808,1112),(2227,1,40,2123,811,1112),(2228,1,8,2123,809,1112);
/*!40000 ALTER TABLE `WORK_REPORT_LINE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WORK_REPORT_TYPE`
--

DROP TABLE IF EXISTS `WORK_REPORT_TYPE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `WORK_REPORT_TYPE` (
  `id` bigint(20) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `WORK_REPORT_TYPE`
--

LOCK TABLES `WORK_REPORT_TYPE` WRITE;
/*!40000 ALTER TABLE `WORK_REPORT_TYPE` DISABLE KEYS */;
INSERT INTO `WORK_REPORT_TYPE` VALUES (2020,1,'Informe estándar');
/*!40000 ALTER TABLE `WORK_REPORT_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Worker`
--

DROP TABLE IF EXISTS `Worker`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Worker` (
  `WORKER_ID` bigint(20) NOT NULL,
  `firstName` varchar(255) default NULL,
  `surname` varchar(255) default NULL,
  `nif` varchar(255) default NULL,
  PRIMARY KEY  (`WORKER_ID`),
  KEY `FK9AC73F9E40901220` (`WORKER_ID`),
  CONSTRAINT `FK9AC73F9E40901220` FOREIGN KEY (`WORKER_ID`) REFERENCES `Resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Worker`
--

LOCK TABLES `Worker` WRITE;
/*!40000 ALTER TABLE `Worker` DISABLE KEYS */;
INSERT INTO `Worker` VALUES (808,'Felipe','Melo','11111111A'),(809,'María','Gomez','22222222B'),(810,'Samuel','Hernandez','33333333C'),(811,'Sara','Martinez','44444444D'),(812,'Esteban','Gonzalez','55555555E');
/*!40000 ALTER TABLE `Worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_criterions`
--

DROP TABLE IF EXISTS `all_criterions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `all_criterions` (
  `GENERIC_RESOURCE_ALLOCATION_ID` bigint(20) NOT NULL,
  `criterion_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`GENERIC_RESOURCE_ALLOCATION_ID`,`criterion_id`),
  KEY `FK7980035061F02C44` (`criterion_id`),
  KEY `FK79800350B1524A73` (`GENERIC_RESOURCE_ALLOCATION_ID`),
  CONSTRAINT `FK79800350B1524A73` FOREIGN KEY (`GENERIC_RESOURCE_ALLOCATION_ID`) REFERENCES `generic_resource_allocation` (`RESOURCE_ALLOCATION_ID`),
  CONSTRAINT `FK7980035061F02C44` FOREIGN KEY (`criterion_id`) REFERENCES `Criterion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `all_criterions`
--

LOCK TABLES `all_criterions` WRITE;
/*!40000 ALTER TABLE `all_criterions` DISABLE KEYS */;
INSERT INTO `all_criterions` VALUES (1617,912),(1618,912),(1619,912),(1620,912),(1621,912);
/*!40000 ALTER TABLE `all_criterions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `day_assignment`
--

DROP TABLE IF EXISTS `day_assignment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `day_assignment` (
  `id` bigint(20) NOT NULL,
  `DAY_ASSIGNMENT_TYPE` varchar(255) NOT NULL,
  `version` bigint(20) NOT NULL,
  `hours` int(11) NOT NULL,
  `day` date NOT NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `SPECIFIC_RESOURCE_ALLOCATION_ID` bigint(20) default NULL,
  `GENERIC_RESOURCE_ALLOCATION_ID` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKBB493F506394139` (`SPECIFIC_RESOURCE_ALLOCATION_ID`),
  KEY `FKBB493F50B1524A73` (`GENERIC_RESOURCE_ALLOCATION_ID`),
  KEY `FKBB493F5048D21790` (`RESOURCE_ID`),
  CONSTRAINT `FKBB493F5048D21790` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `Resource` (`id`),
  CONSTRAINT `FKBB493F506394139` FOREIGN KEY (`SPECIFIC_RESOURCE_ALLOCATION_ID`) REFERENCES `specific_resource_allocation` (`RESOURCE_ALLOCATION_ID`),
  CONSTRAINT `FKBB493F50B1524A73` FOREIGN KEY (`GENERIC_RESOURCE_ALLOCATION_ID`) REFERENCES `generic_resource_allocation` (`RESOURCE_ALLOCATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `day_assignment`
--

LOCK TABLES `day_assignment` WRITE;
/*!40000 ALTER TABLE `day_assignment` DISABLE KEYS */;
INSERT INTO `day_assignment` VALUES (1724,'GENERIC_DAY',5,8,'2009-10-20',808,NULL,1617),(1725,'GENERIC_DAY',5,8,'2009-10-18',808,NULL,1617),(1726,'GENERIC_DAY',5,8,'2009-10-16',808,NULL,1617),(1727,'GENERIC_DAY',5,8,'2009-10-19',808,NULL,1617),(1728,'GENERIC_DAY',5,8,'2009-10-17',808,NULL,1617),(1729,'GENERIC_DAY',5,8,'2009-10-15',808,NULL,1617),(1730,'GENERIC_DAY',5,2,'2009-10-21',808,NULL,1617),(1731,'GENERIC_DAY',0,8,'2010-03-15',808,NULL,1618),(1732,'GENERIC_DAY',0,8,'2010-05-30',808,NULL,1618),(1733,'GENERIC_DAY',0,8,'2010-02-23',808,NULL,1618),(1734,'GENERIC_DAY',0,8,'2010-04-06',808,NULL,1618),(1735,'GENERIC_DAY',0,8,'2010-01-15',808,NULL,1618),(1736,'GENERIC_DAY',0,8,'2010-02-13',808,NULL,1618),(1737,'GENERIC_DAY',0,8,'2010-06-19',808,NULL,1618),(1738,'GENERIC_DAY',0,8,'2010-06-15',808,NULL,1618),(1739,'GENERIC_DAY',0,8,'2010-02-07',808,NULL,1618),(1740,'GENERIC_DAY',0,8,'2010-06-10',808,NULL,1618),(1741,'GENERIC_DAY',0,8,'2010-04-01',808,NULL,1618),(1742,'GENERIC_DAY',0,8,'2010-01-01',808,NULL,1618),(1743,'GENERIC_DAY',0,8,'2010-02-02',808,NULL,1618),(1744,'GENERIC_DAY',0,8,'2010-01-31',808,NULL,1618),(1745,'GENERIC_DAY',0,8,'2010-05-17',808,NULL,1618),(1746,'GENERIC_DAY',0,8,'2010-03-06',808,NULL,1618),(1747,'GENERIC_DAY',0,8,'2009-12-31',808,NULL,1618),(1748,'GENERIC_DAY',0,8,'2010-05-10',808,NULL,1618),(1749,'GENERIC_DAY',0,8,'2010-04-09',808,NULL,1618),(1750,'GENERIC_DAY',0,8,'2010-03-19',808,NULL,1618),(1751,'GENERIC_DAY',0,8,'2010-04-29',808,NULL,1618),(1752,'GENERIC_DAY',0,8,'2010-01-30',808,NULL,1618),(1753,'GENERIC_DAY',0,8,'2010-06-03',808,NULL,1618),(1754,'GENERIC_DAY',0,8,'2010-02-05',808,NULL,1618),(1755,'GENERIC_DAY',0,8,'2009-12-19',808,NULL,1618),(1756,'GENERIC_DAY',0,8,'2010-06-06',808,NULL,1618),(1757,'GENERIC_DAY',0,8,'2010-03-25',808,NULL,1618),(1758,'GENERIC_DAY',0,8,'2010-06-08',808,NULL,1618),(1759,'GENERIC_DAY',0,8,'2010-04-24',808,NULL,1618),(1760,'GENERIC_DAY',0,8,'2010-06-17',808,NULL,1618),(1761,'GENERIC_DAY',0,8,'2010-05-15',808,NULL,1618),(1762,'GENERIC_DAY',0,8,'2010-03-04',808,NULL,1618),(1763,'GENERIC_DAY',0,8,'2009-12-26',808,NULL,1618),(1764,'GENERIC_DAY',0,8,'2010-03-17',808,NULL,1618),(1765,'GENERIC_DAY',0,8,'2010-04-26',808,NULL,1618),(1766,'GENERIC_DAY',0,8,'2010-01-27',808,NULL,1618),(1767,'GENERIC_DAY',0,8,'2010-03-14',808,NULL,1618),(1768,'GENERIC_DAY',0,8,'2010-06-14',808,NULL,1618),(1769,'GENERIC_DAY',0,8,'2010-03-10',808,NULL,1618),(1770,'GENERIC_DAY',0,8,'2010-03-13',808,NULL,1618),(1771,'GENERIC_DAY',0,8,'2010-01-09',808,NULL,1618),(1772,'GENERIC_DAY',0,8,'2010-05-13',808,NULL,1618),(1773,'GENERIC_DAY',0,8,'2010-03-08',808,NULL,1618),(1774,'GENERIC_DAY',0,8,'2009-12-20',808,NULL,1618),(1775,'GENERIC_DAY',0,8,'2010-03-02',808,NULL,1618),(1776,'GENERIC_DAY',0,8,'2010-06-21',808,NULL,1618),(1777,'GENERIC_DAY',0,8,'2010-05-16',808,NULL,1618),(1778,'GENERIC_DAY',0,8,'2010-04-14',808,NULL,1618),(1779,'GENERIC_DAY',0,8,'2010-06-16',808,NULL,1618),(1780,'GENERIC_DAY',0,8,'2010-03-28',808,NULL,1618),(1781,'GENERIC_DAY',0,8,'2010-02-16',808,NULL,1618),(1782,'GENERIC_DAY',0,8,'2010-01-19',808,NULL,1618),(1783,'GENERIC_DAY',0,8,'2010-03-03',808,NULL,1618),(1784,'GENERIC_DAY',0,8,'2010-03-20',808,NULL,1618),(1785,'GENERIC_DAY',0,8,'2010-03-22',808,NULL,1618),(1786,'GENERIC_DAY',0,8,'2010-04-07',808,NULL,1618),(1787,'GENERIC_DAY',0,8,'2010-04-10',808,NULL,1618),(1788,'GENERIC_DAY',0,8,'2009-12-29',808,NULL,1618),(1789,'GENERIC_DAY',0,8,'2010-01-28',808,NULL,1618),(1790,'GENERIC_DAY',0,8,'2010-04-18',808,NULL,1618),(1791,'GENERIC_DAY',0,8,'2010-03-18',808,NULL,1618),(1792,'GENERIC_DAY',0,8,'2010-01-25',808,NULL,1618),(1793,'GENERIC_DAY',0,8,'2010-02-17',808,NULL,1618),(1794,'GENERIC_DAY',0,8,'2010-02-20',808,NULL,1618),(1795,'GENERIC_DAY',0,8,'2010-03-16',808,NULL,1618),(1796,'GENERIC_DAY',0,8,'2010-06-11',808,NULL,1618),(1797,'GENERIC_DAY',0,8,'2010-04-15',808,NULL,1618),(1798,'GENERIC_DAY',0,8,'2010-03-26',808,NULL,1618),(1799,'GENERIC_DAY',0,8,'2010-01-26',808,NULL,1618),(1800,'GENERIC_DAY',0,8,'2010-05-22',808,NULL,1618),(1801,'GENERIC_DAY',0,8,'2010-06-12',808,NULL,1618),(1802,'GENERIC_DAY',0,8,'2010-04-12',808,NULL,1618),(1803,'GENERIC_DAY',0,8,'2009-12-24',808,NULL,1618),(1804,'GENERIC_DAY',0,8,'2009-12-25',808,NULL,1618),(1805,'GENERIC_DAY',0,8,'2009-12-21',808,NULL,1618),(1806,'GENERIC_DAY',0,8,'2010-05-25',808,NULL,1618),(1807,'GENERIC_DAY',0,8,'2009-12-23',808,NULL,1618),(1808,'GENERIC_DAY',0,8,'2010-02-11',808,NULL,1618),(1809,'GENERIC_DAY',0,8,'2010-02-22',808,NULL,1618),(1810,'GENERIC_DAY',0,8,'2010-05-24',808,NULL,1618),(1811,'GENERIC_DAY',0,8,'2010-01-14',808,NULL,1618),(1812,'GENERIC_DAY',0,8,'2010-04-21',808,NULL,1618),(1813,'GENERIC_DAY',0,8,'2010-04-30',808,NULL,1618),(1814,'GENERIC_DAY',0,8,'2010-03-12',808,NULL,1618),(1815,'GENERIC_DAY',0,8,'2010-06-18',808,NULL,1618),(1816,'GENERIC_DAY',0,8,'2010-04-03',808,NULL,1618),(1817,'GENERIC_DAY',0,8,'2010-01-22',808,NULL,1618),(1818,'GENERIC_DAY',0,8,'2010-01-06',808,NULL,1618),(1819,'GENERIC_DAY',0,8,'2010-02-18',808,NULL,1618),(1820,'GENERIC_DAY',0,8,'2010-05-21',808,NULL,1618),(1821,'GENERIC_DAY',0,8,'2010-04-28',808,NULL,1618),(1822,'GENERIC_DAY',0,8,'2010-05-27',808,NULL,1618),(1823,'GENERIC_DAY',0,8,'2010-02-01',808,NULL,1618),(1824,'GENERIC_DAY',0,8,'2010-06-07',808,NULL,1618),(1825,'GENERIC_DAY',0,8,'2010-06-13',808,NULL,1618),(1826,'GENERIC_DAY',0,8,'2010-04-19',808,NULL,1618),(1827,'GENERIC_DAY',0,8,'2010-02-19',808,NULL,1618),(1828,'GENERIC_DAY',0,8,'2010-04-16',808,NULL,1618),(1829,'GENERIC_DAY',0,4,'2010-06-22',808,NULL,1618),(1830,'GENERIC_DAY',0,8,'2010-01-20',808,NULL,1618),(1831,'GENERIC_DAY',0,8,'2010-02-26',808,NULL,1618),(1832,'GENERIC_DAY',0,8,'2010-06-04',808,NULL,1618),(1833,'GENERIC_DAY',0,8,'2010-01-18',808,NULL,1618),(1834,'GENERIC_DAY',0,8,'2010-01-21',808,NULL,1618),(1835,'GENERIC_DAY',0,8,'2010-04-04',808,NULL,1618),(1836,'GENERIC_DAY',0,8,'2010-03-31',808,NULL,1618),(1837,'GENERIC_DAY',0,8,'2009-12-30',808,NULL,1618),(1838,'GENERIC_DAY',0,8,'2010-05-14',808,NULL,1618),(1839,'GENERIC_DAY',0,8,'2010-02-25',808,NULL,1618),(1840,'GENERIC_DAY',0,8,'2010-02-24',808,NULL,1618),(1841,'GENERIC_DAY',0,8,'2010-01-24',808,NULL,1618),(1842,'GENERIC_DAY',0,8,'2010-02-04',808,NULL,1618),(1843,'GENERIC_DAY',0,8,'2010-02-09',808,NULL,1618),(1844,'GENERIC_DAY',0,8,'2010-05-01',808,NULL,1618),(1845,'GENERIC_DAY',0,8,'2010-01-10',808,NULL,1618),(1846,'GENERIC_DAY',0,8,'2010-05-18',808,NULL,1618),(1847,'GENERIC_DAY',0,8,'2010-04-17',808,NULL,1618),(1848,'GENERIC_DAY',0,8,'2010-01-07',808,NULL,1618),(1849,'GENERIC_DAY',0,8,'2010-02-12',808,NULL,1618),(1850,'GENERIC_DAY',0,8,'2010-03-01',808,NULL,1618),(1851,'GENERIC_DAY',0,8,'2010-04-27',808,NULL,1618),(1852,'GENERIC_DAY',0,8,'2009-12-18',808,NULL,1618),(1853,'GENERIC_DAY',0,8,'2010-05-12',808,NULL,1618),(1854,'GENERIC_DAY',0,8,'2010-02-27',808,NULL,1618),(1855,'GENERIC_DAY',0,8,'2010-05-03',808,NULL,1618),(1856,'GENERIC_DAY',0,8,'2010-01-11',808,NULL,1618),(1857,'GENERIC_DAY',0,8,'2010-04-11',808,NULL,1618),(1858,'GENERIC_DAY',0,8,'2010-05-11',808,NULL,1618),(1859,'GENERIC_DAY',0,8,'2010-01-05',808,NULL,1618),(1860,'GENERIC_DAY',0,8,'2010-02-08',808,NULL,1618),(1861,'GENERIC_DAY',0,8,'2010-04-20',808,NULL,1618),(1862,'GENERIC_DAY',0,8,'2010-03-30',808,NULL,1618),(1863,'GENERIC_DAY',0,8,'2010-04-25',808,NULL,1618),(1864,'GENERIC_DAY',0,8,'2010-06-01',808,NULL,1618),(1865,'GENERIC_DAY',0,8,'2010-02-06',808,NULL,1618),(1866,'GENERIC_DAY',0,8,'2009-12-22',808,NULL,1618),(1867,'GENERIC_DAY',0,8,'2010-03-24',808,NULL,1618),(1868,'GENERIC_DAY',0,8,'2010-06-02',808,NULL,1618),(1869,'GENERIC_DAY',0,8,'2010-04-02',808,NULL,1618),(1870,'GENERIC_DAY',0,8,'2010-05-05',808,NULL,1618),(1871,'GENERIC_DAY',0,8,'2010-03-21',808,NULL,1618),(1872,'GENERIC_DAY',0,8,'2010-03-27',808,NULL,1618),(1873,'GENERIC_DAY',0,8,'2010-02-21',808,NULL,1618),(1874,'GENERIC_DAY',0,8,'2010-05-29',808,NULL,1618),(1875,'GENERIC_DAY',0,8,'2009-12-28',808,NULL,1618),(1876,'GENERIC_DAY',0,8,'2010-04-08',808,NULL,1618),(1877,'GENERIC_DAY',0,8,'2010-03-07',808,NULL,1618),(1878,'GENERIC_DAY',0,8,'2010-01-17',808,NULL,1618),(1879,'GENERIC_DAY',0,8,'2010-05-04',808,NULL,1618),(1880,'GENERIC_DAY',0,8,'2010-06-09',808,NULL,1618),(1881,'GENERIC_DAY',0,8,'2010-01-29',808,NULL,1618),(1882,'GENERIC_DAY',0,8,'2010-01-02',808,NULL,1618),(1883,'GENERIC_DAY',0,8,'2010-05-26',808,NULL,1618),(1884,'GENERIC_DAY',0,8,'2010-04-05',808,NULL,1618),(1885,'GENERIC_DAY',0,8,'2009-12-27',808,NULL,1618),(1886,'GENERIC_DAY',0,8,'2010-03-11',808,NULL,1618),(1887,'GENERIC_DAY',0,8,'2010-05-19',808,NULL,1618),(1888,'GENERIC_DAY',0,8,'2010-01-03',808,NULL,1618),(1889,'GENERIC_DAY',0,8,'2010-03-29',808,NULL,1618),(1890,'GENERIC_DAY',0,8,'2010-01-16',808,NULL,1618),(1891,'GENERIC_DAY',0,8,'2010-04-23',808,NULL,1618),(1892,'GENERIC_DAY',0,8,'2010-01-08',808,NULL,1618),(1893,'GENERIC_DAY',0,8,'2009-12-17',808,NULL,1618),(1894,'GENERIC_DAY',0,8,'2010-05-28',808,NULL,1618),(1895,'GENERIC_DAY',0,8,'2010-04-13',808,NULL,1618),(1896,'GENERIC_DAY',0,8,'2010-01-04',808,NULL,1618),(1897,'GENERIC_DAY',0,8,'2010-02-03',808,NULL,1618),(1898,'GENERIC_DAY',0,8,'2010-05-07',808,NULL,1618),(1899,'GENERIC_DAY',0,8,'2010-02-10',808,NULL,1618),(1900,'GENERIC_DAY',0,8,'2010-05-02',808,NULL,1618),(1901,'GENERIC_DAY',0,8,'2010-02-15',808,NULL,1618),(1902,'GENERIC_DAY',0,8,'2010-05-31',808,NULL,1618),(1903,'GENERIC_DAY',0,8,'2010-01-23',808,NULL,1618),(1904,'GENERIC_DAY',0,8,'2010-01-13',808,NULL,1618),(1905,'GENERIC_DAY',0,8,'2010-05-09',808,NULL,1618),(1906,'GENERIC_DAY',0,8,'2010-01-12',808,NULL,1618),(1907,'GENERIC_DAY',0,8,'2010-06-05',808,NULL,1618),(1908,'GENERIC_DAY',0,8,'2010-05-08',808,NULL,1618),(1909,'GENERIC_DAY',0,8,'2010-04-22',808,NULL,1618),(1910,'GENERIC_DAY',0,8,'2010-06-20',808,NULL,1618),(1911,'GENERIC_DAY',0,8,'2010-02-14',808,NULL,1618),(1912,'GENERIC_DAY',0,8,'2010-02-28',808,NULL,1618),(1913,'GENERIC_DAY',0,8,'2010-05-23',808,NULL,1618),(1914,'GENERIC_DAY',0,8,'2010-05-20',808,NULL,1618),(1915,'GENERIC_DAY',0,8,'2010-05-06',808,NULL,1618),(1916,'GENERIC_DAY',0,8,'2010-03-09',808,NULL,1618),(1917,'GENERIC_DAY',0,8,'2010-03-05',808,NULL,1618),(1918,'GENERIC_DAY',0,8,'2010-03-23',808,NULL,1618),(1919,'GENERIC_DAY',0,8,'2009-11-01',808,NULL,1619),(1920,'GENERIC_DAY',0,8,'2009-11-05',808,NULL,1619),(1921,'GENERIC_DAY',0,8,'2009-11-04',808,NULL,1619),(1922,'GENERIC_DAY',0,8,'2009-10-30',808,NULL,1619),(1923,'GENERIC_DAY',0,8,'2009-10-28',808,NULL,1619),(1924,'GENERIC_DAY',0,4,'2009-11-09',808,NULL,1619),(1925,'GENERIC_DAY',0,8,'2009-11-06',808,NULL,1619),(1926,'GENERIC_DAY',0,8,'2009-11-02',808,NULL,1619),(1927,'GENERIC_DAY',0,8,'2009-11-03',808,NULL,1619),(1928,'GENERIC_DAY',0,8,'2009-10-29',808,NULL,1619),(1929,'GENERIC_DAY',0,8,'2009-10-31',808,NULL,1619),(1930,'GENERIC_DAY',0,8,'2009-11-08',808,NULL,1619),(1931,'GENERIC_DAY',0,8,'2009-11-07',808,NULL,1619),(1932,'GENERIC_DAY',0,8,'2009-12-06',808,NULL,1620),(1933,'GENERIC_DAY',0,8,'2009-12-14',808,NULL,1620),(1934,'GENERIC_DAY',0,8,'2009-11-29',808,NULL,1620),(1935,'GENERIC_DAY',0,8,'2009-11-24',808,NULL,1620),(1936,'GENERIC_DAY',0,8,'2009-11-23',808,NULL,1620),(1937,'GENERIC_DAY',0,8,'2009-12-04',808,NULL,1620),(1938,'GENERIC_DAY',0,8,'2009-11-25',808,NULL,1620),(1939,'GENERIC_DAY',0,8,'2009-12-02',808,NULL,1620),(1940,'GENERIC_DAY',0,8,'2009-12-12',808,NULL,1620),(1941,'GENERIC_DAY',0,8,'2009-11-26',808,NULL,1620),(1942,'GENERIC_DAY',0,8,'2009-11-28',808,NULL,1620),(1943,'GENERIC_DAY',0,8,'2009-12-05',808,NULL,1620),(1944,'GENERIC_DAY',0,8,'2009-12-13',808,NULL,1620),(1945,'GENERIC_DAY',0,8,'2009-12-15',808,NULL,1620),(1946,'GENERIC_DAY',0,8,'2009-12-01',808,NULL,1620),(1947,'GENERIC_DAY',0,8,'2009-11-30',808,NULL,1620),(1948,'GENERIC_DAY',0,8,'2009-12-07',808,NULL,1620),(1949,'GENERIC_DAY',0,8,'2009-12-08',808,NULL,1620),(1950,'GENERIC_DAY',0,8,'2009-12-11',808,NULL,1620),(1951,'GENERIC_DAY',0,8,'2009-12-03',808,NULL,1620),(1952,'GENERIC_DAY',0,8,'2009-11-27',808,NULL,1620),(1953,'GENERIC_DAY',0,8,'2009-11-22',808,NULL,1620),(1954,'GENERIC_DAY',0,8,'2009-12-10',808,NULL,1620),(1955,'GENERIC_DAY',0,8,'2009-12-16',808,NULL,1620),(1956,'GENERIC_DAY',0,8,'2009-12-09',808,NULL,1620),(1957,'GENERIC_DAY',0,8,'2009-10-22',808,NULL,1621),(1958,'GENERIC_DAY',0,8,'2009-10-29',808,NULL,1621),(1959,'GENERIC_DAY',0,4,'2009-11-21',808,NULL,1621),(1960,'GENERIC_DAY',0,8,'2009-10-18',808,NULL,1621),(1961,'GENERIC_DAY',0,8,'2009-11-14',808,NULL,1621),(1962,'GENERIC_DAY',0,8,'2009-11-04',808,NULL,1621),(1963,'GENERIC_DAY',0,8,'2009-11-13',808,NULL,1621),(1964,'GENERIC_DAY',0,8,'2009-10-27',808,NULL,1621),(1965,'GENERIC_DAY',0,8,'2009-11-16',808,NULL,1621),(1966,'GENERIC_DAY',0,8,'2009-11-09',808,NULL,1621),(1967,'GENERIC_DAY',0,8,'2009-11-06',808,NULL,1621),(1968,'GENERIC_DAY',0,8,'2009-11-11',808,NULL,1621),(1969,'GENERIC_DAY',0,8,'2009-10-16',808,NULL,1621),(1970,'GENERIC_DAY',0,8,'2009-10-17',808,NULL,1621),(1971,'GENERIC_DAY',0,8,'2009-11-02',808,NULL,1621),(1972,'GENERIC_DAY',0,8,'2009-11-17',808,NULL,1621),(1973,'GENERIC_DAY',0,8,'2009-10-24',808,NULL,1621),(1974,'GENERIC_DAY',0,8,'2009-10-19',808,NULL,1621),(1975,'GENERIC_DAY',0,8,'2009-10-15',808,NULL,1621),(1976,'GENERIC_DAY',0,8,'2009-11-18',808,NULL,1621),(1977,'GENERIC_DAY',0,8,'2009-10-21',808,NULL,1621),(1978,'GENERIC_DAY',0,8,'2009-10-25',808,NULL,1621),(1979,'GENERIC_DAY',0,8,'2009-11-15',808,NULL,1621),(1980,'GENERIC_DAY',0,8,'2009-11-12',808,NULL,1621),(1981,'GENERIC_DAY',0,8,'2009-11-19',808,NULL,1621),(1982,'GENERIC_DAY',0,8,'2009-11-05',808,NULL,1621),(1983,'GENERIC_DAY',0,8,'2009-10-26',808,NULL,1621),(1984,'GENERIC_DAY',0,8,'2009-11-01',808,NULL,1621),(1985,'GENERIC_DAY',0,8,'2009-11-03',808,NULL,1621),(1986,'GENERIC_DAY',0,8,'2009-11-07',808,NULL,1621),(1987,'GENERIC_DAY',0,8,'2009-10-31',808,NULL,1621),(1988,'GENERIC_DAY',0,8,'2009-10-23',808,NULL,1621),(1989,'GENERIC_DAY',0,8,'2009-10-20',808,NULL,1621),(1990,'GENERIC_DAY',0,8,'2009-11-08',808,NULL,1621),(1991,'GENERIC_DAY',0,8,'2009-10-28',808,NULL,1621),(1992,'GENERIC_DAY',0,8,'2009-11-20',808,NULL,1621),(1993,'GENERIC_DAY',0,8,'2009-11-10',808,NULL,1621),(1994,'GENERIC_DAY',0,8,'2009-10-30',808,NULL,1621);
/*!40000 ALTER TABLE `day_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_resource_allocation`
--

DROP TABLE IF EXISTS `generic_resource_allocation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `generic_resource_allocation` (
  `RESOURCE_ALLOCATION_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`RESOURCE_ALLOCATION_ID`),
  KEY `FKF788B34975ED79BA` (`RESOURCE_ALLOCATION_ID`),
  CONSTRAINT `FKF788B34975ED79BA` FOREIGN KEY (`RESOURCE_ALLOCATION_ID`) REFERENCES `ResourceAllocation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `generic_resource_allocation`
--

LOCK TABLES `generic_resource_allocation` WRITE;
/*!40000 ALTER TABLE `generic_resource_allocation` DISABLE KEYS */;
INSERT INTO `generic_resource_allocation` VALUES (1617),(1618),(1619),(1620),(1621);
/*!40000 ALTER TABLE `generic_resource_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_unique_key`
--

DROP TABLE IF EXISTS `hibernate_unique_key`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hibernate_unique_key` (
  `next_hi` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hibernate_unique_key`
--

LOCK TABLES `hibernate_unique_key` WRITE;
/*!40000 ALTER TABLE `hibernate_unique_key` DISABLE KEYS */;
INSERT INTO `hibernate_unique_key` VALUES (24);
/*!40000 ALTER TABLE `hibernate_unique_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoursPerDay`
--

DROP TABLE IF EXISTS `hoursPerDay`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hoursPerDay` (
  `BASE_CALENDAR_ID` bigint(20) NOT NULL,
  `HOURS` int(11) default NULL,
  `DAY_ID` int(11) NOT NULL,
  PRIMARY KEY  (`BASE_CALENDAR_ID`,`DAY_ID`),
  KEY `FKC001D52EFD5E49BC` (`BASE_CALENDAR_ID`),
  CONSTRAINT `FKC001D52EFD5E49BC` FOREIGN KEY (`BASE_CALENDAR_ID`) REFERENCES `CalendarData` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hoursPerDay`
--

LOCK TABLES `hoursPerDay` WRITE;
/*!40000 ALTER TABLE `hoursPerDay` DISABLE KEYS */;
INSERT INTO `hoursPerDay` VALUES (505,8,0),(505,8,1),(505,8,2),(505,8,3),(505,8,4);
/*!40000 ALTER TABLE `hoursPerDay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_table`
--

DROP TABLE IF EXISTS `order_table`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `order_table` (
  `ORDERELEMENTID` bigint(20) NOT NULL,
  `responsible` varchar(255) default NULL,
  `customer` varchar(255) default NULL,
  PRIMARY KEY  (`ORDERELEMENTID`),
  KEY `FK75A2F39DF82680F8` (`ORDERELEMENTID`),
  CONSTRAINT `FK75A2F39DF82680F8` FOREIGN KEY (`ORDERELEMENTID`) REFERENCES `OrderLineGroup` (`ORDERELEMENTID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `order_table`
--

LOCK TABLES `order_table` WRITE;
/*!40000 ALTER TABLE `order_table` DISABLE KEYS */;
INSERT INTO `order_table` VALUES (1111,'Xavier','Navantia');
/*!40000 ALTER TABLE `order_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specific_resource_allocation`
--

DROP TABLE IF EXISTS `specific_resource_allocation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `specific_resource_allocation` (
  `RESOURCE_ALLOCATION_ID` bigint(20) NOT NULL,
  `resource` bigint(20) default NULL,
  PRIMARY KEY  (`RESOURCE_ALLOCATION_ID`),
  KEY `FKF0E8572475ED79BA` (`RESOURCE_ALLOCATION_ID`),
  KEY `FKF0E85724EAE850B2` (`resource`),
  CONSTRAINT `FKF0E85724EAE850B2` FOREIGN KEY (`resource`) REFERENCES `Resource` (`id`),
  CONSTRAINT `FKF0E8572475ED79BA` FOREIGN KEY (`RESOURCE_ALLOCATION_ID`) REFERENCES `ResourceAllocation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `specific_resource_allocation`
--

LOCK TABLES `specific_resource_allocation` WRITE;
/*!40000 ALTER TABLE `specific_resource_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `specific_resource_allocation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-10-16  6:10:45
