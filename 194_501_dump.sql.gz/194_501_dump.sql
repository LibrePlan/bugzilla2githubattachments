--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advanceassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    reportglobaladvance boolean,
    advance_type_id bigint
);


ALTER TABLE public.advanceassignment OWNER TO naval;

--
-- Name: advancemeasurement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancemeasurement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    value numeric(19,2),
    advance_assignment_id bigint
);


ALTER TABLE public.advancemeasurement OWNER TO naval;

--
-- Name: advancetype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE advancetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    unitname character varying(255),
    defaultmaxvalue numeric(19,4),
    updatable boolean,
    unitprecision numeric(19,4),
    active boolean,
    percentage boolean
);


ALTER TABLE public.advancetype OWNER TO naval;

--
-- Name: all_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE all_criterions (
    generic_resource_allocation_id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.all_criterions OWNER TO naval;

--
-- Name: assignment_function; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE assignment_function (
    id bigint NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.assignment_function OWNER TO naval;

--
-- Name: basecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE basecalendar (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.basecalendar OWNER TO naval;

--
-- Name: calendaravailability; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendaravailability (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate date,
    enddate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendaravailability OWNER TO naval;

--
-- Name: calendardata; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendardata (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent bigint,
    expiringdate date,
    base_calendar_id bigint,
    position_in_calendar integer
);


ALTER TABLE public.calendardata OWNER TO naval;

--
-- Name: calendarexception; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexception (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date date,
    hours integer,
    calendar_exception_id bigint,
    base_calendar_id bigint
);


ALTER TABLE public.calendarexception OWNER TO naval;

--
-- Name: calendarexceptiontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE calendarexceptiontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    color character varying(255),
    notassignable boolean
);


ALTER TABLE public.calendarexceptiontype OWNER TO naval;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE configuration (
    id bigint NOT NULL,
    version bigint NOT NULL,
    configuration_id bigint,
    companycode character varying(255)
);


ALTER TABLE public.configuration OWNER TO naval;

--
-- Name: cost_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE cost_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    enabled boolean
);


ALTER TABLE public.cost_category OWNER TO naval;

--
-- Name: criterion; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterion (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    active boolean,
    id_criterion_type bigint NOT NULL,
    parent bigint
);


ALTER TABLE public.criterion OWNER TO naval;

--
-- Name: criterionrequirement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionrequirement (
    id bigint NOT NULL,
    criterion_requirement_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours_group_id bigint,
    order_element_id bigint,
    criterion_id bigint,
    parent bigint,
    isvalid boolean
);


ALTER TABLE public.criterionrequirement OWNER TO naval;

--
-- Name: criterionsatisfaction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criterionsatisfaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone NOT NULL,
    finishdate timestamp without time zone,
    isdeleted boolean,
    criterion bigint NOT NULL,
    resource bigint NOT NULL
);


ALTER TABLE public.criterionsatisfaction OWNER TO naval;

--
-- Name: criteriontype; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE criteriontype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    allowsimultaneouscriterionsperresource boolean,
    allowhierarchy boolean,
    enabled boolean,
    resource integer
);


ALTER TABLE public.criteriontype OWNER TO naval;

--
-- Name: day_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE day_assignment (
    id bigint NOT NULL,
    day_assignment_type character varying(255) NOT NULL,
    version bigint NOT NULL,
    hours integer NOT NULL,
    day date NOT NULL,
    resource_id bigint NOT NULL,
    specific_resource_allocation_id bigint,
    generic_resource_allocation_id bigint,
    derived_allocation_id bigint
);


ALTER TABLE public.day_assignment OWNER TO naval;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE dependency (
    id bigint NOT NULL,
    version bigint NOT NULL,
    origin bigint,
    destination bigint,
    type integer
);


ALTER TABLE public.dependency OWNER TO naval;

--
-- Name: derivedallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE derivedallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resource_allocation_id bigint NOT NULL,
    configurationunit bigint NOT NULL
);


ALTER TABLE public.derivedallocation OWNER TO naval;

--
-- Name: description_values; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values OWNER TO naval;

--
-- Name: description_values_in_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE description_values_in_line (
    description_value_id bigint NOT NULL,
    fieldname character varying(255),
    value character varying(255)
);


ALTER TABLE public.description_values_in_line OWNER TO naval;

--
-- Name: directadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE directadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    direct_order_element_id bigint,
    maxvalue numeric(19,2)
);


ALTER TABLE public.directadvanceassignment OWNER TO naval;

--
-- Name: generic_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE generic_resource_allocation (
    resource_allocation_id bigint NOT NULL
);


ALTER TABLE public.generic_resource_allocation OWNER TO naval;

--
-- Name: heading_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE heading_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer,
    positionnumber integer
);


ALTER TABLE public.heading_field OWNER TO naval;

--
-- Name: hibernate_unique_key; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hibernate_unique_key (
    next_hi integer
);


ALTER TABLE public.hibernate_unique_key OWNER TO naval;

--
-- Name: hour_cost; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hour_cost (
    id bigint NOT NULL,
    version bigint NOT NULL,
    pricecost numeric(19,2),
    initdate date,
    enddate date,
    type_of_work_hours_id bigint,
    cost_category_id bigint
);


ALTER TABLE public.hour_cost OWNER TO naval;

--
-- Name: hoursgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursgroup (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    resourcetype bytea,
    workinghours integer,
    percentage numeric(19,2),
    fixedpercentage boolean,
    parent_order_line bigint NOT NULL
);


ALTER TABLE public.hoursgroup OWNER TO naval;

--
-- Name: hoursperday; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE hoursperday (
    base_calendar_id bigint NOT NULL,
    hours integer,
    day_id integer NOT NULL
);


ALTER TABLE public.hoursperday OWNER TO naval;

--
-- Name: indirectadvanceassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE indirectadvanceassignment (
    advance_assignment_id bigint NOT NULL,
    indirect_order_element_id bigint
);


ALTER TABLE public.indirectadvanceassignment OWNER TO naval;

--
-- Name: label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    label_type_id bigint
);


ALTER TABLE public.label OWNER TO naval;

--
-- Name: label_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE label_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.label_type OWNER TO naval;

--
-- Name: line_field; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE line_field (
    heading_id bigint NOT NULL,
    fieldname character varying(255),
    length integer,
    index integer,
    positionnumber integer
);


ALTER TABLE public.line_field OWNER TO naval;

--
-- Name: machine; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine (
    machine_id bigint NOT NULL,
    code character varying(255),
    name character varying(255),
    description character varying(255)
);


ALTER TABLE public.machine OWNER TO naval;

--
-- Name: machine_configuration_unit_required_criterions; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machine_configuration_unit_required_criterions (
    id bigint NOT NULL,
    criterion_id bigint NOT NULL
);


ALTER TABLE public.machine_configuration_unit_required_criterions OWNER TO naval;

--
-- Name: machineworkerassignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkerassignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    startdate timestamp without time zone,
    finishdate timestamp without time zone,
    configuration_id bigint NOT NULL,
    worker_id bigint
);


ALTER TABLE public.machineworkerassignment OWNER TO naval;

--
-- Name: machineworkersconfigurationunit; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE machineworkersconfigurationunit (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    alpha numeric(19,2) NOT NULL,
    machine bigint NOT NULL
);


ALTER TABLE public.machineworkersconfigurationunit OWNER TO naval;

--
-- Name: material; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material (
    id bigint NOT NULL,
    version bigint NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    default_unit_price numeric(19,2),
    unit_type integer,
    disabled boolean,
    category_id bigint
);


ALTER TABLE public.material OWNER TO naval;

--
-- Name: material_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    units double precision,
    unit_price numeric(19,2),
    estimated_availability timestamp without time zone,
    status integer,
    order_element_id bigint,
    material_id bigint
);


ALTER TABLE public.material_assigment OWNER TO naval;

--
-- Name: material_category; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE material_category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    parent_id bigint
);


ALTER TABLE public.material_category OWNER TO naval;

--
-- Name: naval_profile; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_profile (
    id bigint NOT NULL,
    version bigint NOT NULL,
    profilename character varying(255) NOT NULL
);


ALTER TABLE public.naval_profile OWNER TO naval;

--
-- Name: naval_user; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE naval_user (
    id bigint NOT NULL,
    version bigint NOT NULL,
    loginname character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    disabled boolean
);


ALTER TABLE public.naval_user OWNER TO naval;

--
-- Name: order_element_label; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_element_label (
    order_element_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.order_element_label OWNER TO naval;

--
-- Name: order_table; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE order_table (
    orderelementid bigint NOT NULL,
    responsible character varying(255),
    customer character varying(255),
    dependenciesconstraintshavepriority boolean,
    base_calendar_id bigint
);


ALTER TABLE public.order_table OWNER TO naval;

--
-- Name: orderelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    initdate timestamp without time zone,
    deadline timestamp without time zone,
    mandatoryinit boolean,
    mandatoryend boolean,
    description character varying(255),
    code character varying(255),
    schedulingstatetype integer,
    parent bigint,
    positionincontainer integer
);


ALTER TABLE public.orderelement OWNER TO naval;

--
-- Name: orderline; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderline (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderline OWNER TO naval;

--
-- Name: orderlinegroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE orderlinegroup (
    orderelementid bigint NOT NULL
);


ALTER TABLE public.orderlinegroup OWNER TO naval;

--
-- Name: ordersequence; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE ordersequence (
    id bigint NOT NULL,
    version bigint NOT NULL,
    prefix character varying(255),
    lastvalue integer,
    numberofdigits integer,
    active boolean
);


ALTER TABLE public.ordersequence OWNER TO naval;

--
-- Name: profile_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE profile_roles (
    profileid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.profile_roles OWNER TO naval;

--
-- Name: quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    description character varying(255),
    qualityformtype integer
);


ALTER TABLE public.quality_form OWNER TO naval;

--
-- Name: quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE quality_form_items (
    quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    idx integer NOT NULL
);


ALTER TABLE public.quality_form_items OWNER TO naval;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    calendar bigint
);


ALTER TABLE public.resource OWNER TO naval;

--
-- Name: resourceallocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourceallocation (
    id bigint NOT NULL,
    version bigint NOT NULL,
    resourcesperday numeric(19,2),
    task bigint,
    assignment_function bigint
);


ALTER TABLE public.resourceallocation OWNER TO naval;

--
-- Name: resourcecalendar; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resourcecalendar (
    base_calendar_id bigint NOT NULL,
    capacity integer
);


ALTER TABLE public.resourcecalendar OWNER TO naval;

--
-- Name: resources_cost_category_assignment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE resources_cost_category_assignment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    initdate date,
    enddate date,
    cost_category_id bigint,
    resource_id bigint
);


ALTER TABLE public.resources_cost_category_assignment OWNER TO naval;

--
-- Name: specific_resource_allocation; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE specific_resource_allocation (
    resource_allocation_id bigint NOT NULL,
    resource bigint
);


ALTER TABLE public.specific_resource_allocation OWNER TO naval;

--
-- Name: stretches; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretches (
    assignment_function_id bigint NOT NULL,
    date date NOT NULL,
    lengthpercentage numeric(19,2) NOT NULL,
    amountworkpercentage numeric(19,2) NOT NULL,
    stretch_position integer NOT NULL
);


ALTER TABLE public.stretches OWNER TO naval;

--
-- Name: stretchesfunction; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE stretchesfunction (
    assignment_function_id bigint NOT NULL
);


ALTER TABLE public.stretchesfunction OWNER TO naval;

--
-- Name: task; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task (
    task_element_id bigint NOT NULL,
    calculatedvalue integer,
    startconstrainttype integer,
    constraintdate timestamp without time zone
);


ALTER TABLE public.task OWNER TO naval;

--
-- Name: task_quality_form; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form (
    id bigint NOT NULL,
    version bigint NOT NULL,
    quality_form_id bigint,
    order_element_id bigint
);


ALTER TABLE public.task_quality_form OWNER TO naval;

--
-- Name: task_quality_form_items; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_quality_form_items (
    task_quality_form_id bigint NOT NULL,
    name character varying(255),
    percentage numeric(19,2),
    "position" integer,
    passed boolean,
    date timestamp without time zone,
    idx integer NOT NULL
);


ALTER TABLE public.task_quality_form_items OWNER TO naval;

--
-- Name: task_source_hours_groups; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE task_source_hours_groups (
    task_source_id bigint NOT NULL,
    hours_group_id bigint NOT NULL
);


ALTER TABLE public.task_source_hours_groups OWNER TO naval;

--
-- Name: taskelement; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskelement (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    notes character varying(255),
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    deadline date,
    parent bigint,
    base_calendar_id bigint,
    positioninparent integer
);


ALTER TABLE public.taskelement OWNER TO naval;

--
-- Name: taskgroup; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskgroup (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskgroup OWNER TO naval;

--
-- Name: taskmilestone; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE taskmilestone (
    task_element_id bigint NOT NULL
);


ALTER TABLE public.taskmilestone OWNER TO naval;

--
-- Name: tasksource; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE tasksource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    orderelement bigint
);


ALTER TABLE public.tasksource OWNER TO naval;

--
-- Name: type_of_work_hours; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE type_of_work_hours (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    defaultprice numeric(19,2),
    enabled boolean
);


ALTER TABLE public.type_of_work_hours OWNER TO naval;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id bigint NOT NULL,
    profile_id bigint NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO naval;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE user_roles (
    userid bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.user_roles OWNER TO naval;

--
-- Name: virtualworker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE virtualworker (
    virtualworker_id bigint NOT NULL,
    observations character varying(255)
);


ALTER TABLE public.virtualworker OWNER TO naval;

--
-- Name: work_report; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date timestamp without time zone,
    work_report_type_id bigint NOT NULL,
    resource_id bigint,
    order_element_id bigint
);


ALTER TABLE public.work_report OWNER TO naval;

--
-- Name: work_report_label_type_assigment; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_label_type_assigment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    labelssharedbylines boolean,
    index integer,
    label_type_id bigint,
    label_id bigint,
    work_report_type_id bigint,
    positionnumber integer
);


ALTER TABLE public.work_report_label_type_assigment OWNER TO naval;

--
-- Name: work_report_line; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_line (
    id bigint NOT NULL,
    version bigint NOT NULL,
    numhours integer,
    date timestamp without time zone,
    clockstart timestamp without time zone,
    clockfinish timestamp without time zone,
    work_report_id bigint,
    resource_id bigint NOT NULL,
    order_element_id bigint NOT NULL,
    type_work_hours_id bigint NOT NULL
);


ALTER TABLE public.work_report_line OWNER TO naval;

--
-- Name: work_report_type; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE work_report_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255),
    code character varying(255),
    dateissharedbylines boolean,
    resourceissharedinlines boolean,
    orderelementissharedinlines boolean,
    hoursmanagement integer
);


ALTER TABLE public.work_report_type OWNER TO naval;

--
-- Name: worker; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE worker (
    worker_id bigint NOT NULL,
    firstname character varying(255),
    surname character varying(255),
    nif character varying(255)
);


ALTER TABLE public.worker OWNER TO naval;

--
-- Name: workreports_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreports_labels (
    work_report_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreports_labels OWNER TO naval;

--
-- Name: workreportslines_labels; Type: TABLE; Schema: public; Owner: naval; Tablespace: 
--

CREATE TABLE workreportslines_labels (
    work_report_line_id bigint NOT NULL,
    label_id bigint NOT NULL
);


ALTER TABLE public.workreportslines_labels OWNER TO naval;

--
-- Data for Name: advanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advanceassignment (id, version, reportglobaladvance, advance_type_id) FROM stdin;
3052	6	t	606
3053	6	t	606
3054	6	t	606
3042	7	t	606
2250	3	t	606
2251	3	t	606
2234	4	t	606
3056	18	f	509
3099	15	t	607
3115	14	t	607
3130	12	t	607
6178	3	t	607
6179	3	t	607
2739	22	t	606
3100	15	f	607
29406	5	t	606
29407	5	t	606
35867	11	t	606
16659	12	t	607
16660	12	t	607
16661	12	t	607
2932	19	f	606
16662	12	t	607
16663	12	t	607
6186	13	t	607
6187	13	t	607
6894	4	t	607
6895	4	t	607
6902	3	t	607
2945	7	t	606
6896	4	f	607
27689	5	t	606
27690	5	t	606
39934	8	t	606
39935	8	t	606
39936	8	t	606
39924	9	t	606
49251	10	t	606
49252	10	t	606
49253	10	t	606
49254	10	t	606
49255	10	t	606
49256	10	t	606
49257	10	t	606
49258	10	t	606
49267	9	t	606
49268	9	t	606
49269	9	t	606
49270	9	t	606
49273	7	t	606
\.


--
-- Data for Name: advancemeasurement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancemeasurement (id, version, date, value, advance_assignment_id) FROM stdin;
19436	7	2009-12-08	25.00	16659
16728	12	2009-12-02	10.00	16659
19437	7	2009-12-08	25.00	16660
16729	12	2009-12-01	10.00	16660
16730	12	2009-12-08	20.00	16662
16731	12	2009-12-08	10.00	16663
6290	13	2009-12-08	30.00	6186
6984	4	2009-12-08	50.00	6894
6985	4	2009-12-08	40.00	6895
6991	3	2009-12-08	45.00	6902
1519	18	2009-12-25	100.00	3056
1520	18	2009-12-10	15.00	3056
1521	18	2009-12-07	5.00	3056
1522	18	2009-12-04	1.00	3056
1544	15	2009-12-04	10.00	3099
1573	14	2009-12-07	30.00	3115
1574	14	2009-12-04	10.00	3115
3233	12	2009-12-07	30.00	3130
3234	12	2009-12-04	10.00	3130
3235	12	2009-12-03	2.00	3130
6284	3	2009-12-07	30.00	6178
6285	3	2009-12-08	30.00	6179
6286	3	2009-12-07	50.00	6179
\.


--
-- Data for Name: advancetype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY advancetype (id, version, unitname, defaultmaxvalue, updatable, unitprecision, active, percentage) FROM stdin;
606	3	children	100.0000	f	0.0100	t	t
607	2	percentage	100.0000	f	0.0100	t	t
608	1	units	2147483647.0000	f	1.0000	t	f
508	1	Pactado	1000000.0000	t	1000.0000	t	f
510	1	Toneladas	4000.0000	t	1.0000	t	f
509	2	Porcentage pactado	100.0000	t	1.0000	t	t
\.


--
-- Data for Name: all_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY all_criterions (generic_resource_allocation_id, criterion_id) FROM stdin;
3940	105
3950	106
3951	106
3952	107
3953	106
3955	110
3982	107
3983	106
3984	105
3985	105
6367	106
6368	110
6369	106
8588	107
8589	105
19897	105
19898	107
19899	105
19901	105
24143	111
28093	106
29808	106
36966	36057
38582	36057
38583	36057
38595	36057
38596	36057
38597	36057
38598	36057
38600	36057
38601	36057
41013	36057
41014	36057
41050	36057
41051	36057
41052	36057
41053	36057
41054	36057
41061	36057
41069	36057
41076	36057
41077	36057
\.


--
-- Data for Name: assignment_function; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY assignment_function (id, version) FROM stdin;
4245	7
24953	2
37371	17
\.


--
-- Data for Name: basecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY basecalendar (id, version, name) FROM stdin;
204	2	Ferrol
58787	3	\N
58788	2	\N
49395	2	\N
58790	3	\N
58786	3	\N
58785	2	\N
58784	2	\N
206	2	\N
205	2	\N
58782	3	\N
58789	6	\N
49399	3	Pontevedra Proxecto 2
58783	3	\N
208	5	\N
26159	1	Vigo
207	3	\N
7373	6	\N
209	7	\N
210	8	\N
202	3	España
203	4	Galicia
37674	2	\N
36259	2	\N
37673	2	\N
40299	3	\N
49391	1	\N
49392	1	\N
49393	1	\N
49389	3	\N
49394	1	\N
49390	3	\N
49396	2	\N
36260	4	Pontevedra
49397	2	Pontevedra Proxecto
\.


--
-- Data for Name: calendaravailability; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendaravailability (id, version, startdate, enddate, base_calendar_id, position_in_calendar) FROM stdin;
7677	1	2009-11-04	\N	206	0
7678	1	2009-11-04	\N	205	0
58989	3	2009-12-14	\N	58787	0
58990	2	2009-12-14	\N	58788	0
49597	2	2009-12-14	\N	49395	0
58992	3	2009-12-14	\N	58790	0
58988	3	2009-12-14	\N	58786	0
58987	2	2009-12-14	\N	58785	0
58986	2	2009-12-14	\N	58784	0
58984	3	2009-12-14	\N	58782	0
58991	6	2009-12-14	2010-01-31	58789	0
7679	4	2009-11-04	\N	208	0
7680	2	2009-11-04	\N	207	0
61206	1	2010-02-01	\N	58789	1
58985	3	2009-12-14	\N	58783	0
7879	5	2009-11-04	\N	7373	0
7676	4	2009-11-07	\N	209	0
7878	6	2009-11-04	\N	210	0
37876	2	2009-12-14	\N	37674	0
36461	2	2009-12-14	\N	36259	0
37875	2	2009-12-14	\N	37673	0
40501	3	2009-12-18	\N	40299	0
49593	1	2009-12-23	\N	49391	0
49594	1	2009-12-23	\N	49392	0
49595	1	2009-12-23	\N	49393	0
49591	3	2009-12-23	\N	49389	0
49596	1	2009-12-23	\N	49394	0
49592	3	2009-12-23	\N	49390	0
49598	2	2009-12-23	\N	49396	0
\.


--
-- Data for Name: calendardata; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendardata (id, version, parent, expiringdate, base_calendar_id, position_in_calendar) FROM stdin;
37775	2	202	\N	37674	0
306	2	203	\N	204	0
58888	3	49399	\N	58787	0
58889	2	49399	\N	58788	0
36360	2	202	\N	36259	0
37774	2	202	\N	37673	0
40400	3	202	\N	40299	0
308	2	202	\N	206	0
307	2	202	\N	205	0
49496	2	202	\N	49395	0
58891	3	49399	\N	58790	0
58887	3	49399	\N	58786	0
49492	1	202	\N	49391	0
58886	2	49399	\N	58785	0
49493	1	202	\N	49392	0
58885	2	49399	\N	58784	0
310	5	202	\N	208	0
26361	1	203	\N	26159	0
309	3	202	\N	207	0
49494	1	202	\N	49393	0
49490	3	202	\N	49389	0
7474	6	202	\N	7373	0
311	7	202	\N	209	0
58883	3	49399	\N	58782	0
49495	1	36260	\N	49394	0
58890	6	49399	\N	58789	0
312	8	202	2009-12-11	210	0
31916	2	202	\N	210	1
49491	3	202	\N	49390	0
49500	3	\N	\N	49399	0
303	3	\N	\N	202	0
304	3	\N	\N	202	1
305	4	202	\N	203	0
58884	3	49399	\N	58783	0
49497	2	202	\N	49396	0
36361	4	203	2010-01-01	36260	0
36362	2	203	\N	36260	1
49498	2	\N	\N	49397	0
\.


--
-- Data for Name: calendarexception; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexception (id, version, date, hours, calendar_exception_id, base_calendar_id) FROM stdin;
808	2	2009-12-25	0	505	202
26260	1	2010-12-28	0	505	26159
26261	1	2010-12-27	0	505	26159
26262	1	2010-04-05	0	505	26159
26263	1	2010-12-31	0	505	26159
26264	1	2011-01-02	0	505	26159
26265	1	2010-12-30	0	505	26159
26266	1	2011-01-01	0	505	26159
26267	1	2010-12-29	0	505	26159
59102	2	2010-01-07	0	505	58790
809	2	2010-01-01	0	505	202
59100	2	2010-01-12	0	505	58790
59095	2	2010-01-09	0	505	58790
36663	1	2010-04-01	0	505	202
36664	1	2010-11-01	0	505	202
36665	1	2010-12-06	0	505	202
36666	1	2010-04-02	0	505	202
36667	1	2010-10-12	0	505	202
36668	1	2010-12-08	0	505	202
36669	1	2010-01-06	0	505	202
810	2	2010-05-17	0	505	203
59104	2	2010-01-08	0	505	58790
36670	1	2010-03-19	0	505	203
59089	2	2010-01-26	0	505	58790
59105	2	2010-01-14	0	505	58790
59098	2	2010-01-13	0	505	58790
59103	2	2010-01-15	0	505	58790
59085	2	2010-01-22	0	505	58790
26268	1	2010-07-12	0	505	207
26269	1	2010-07-08	0	505	207
26270	1	2010-07-21	0	505	207
26271	1	2010-07-16	0	505	207
26272	1	2010-07-04	0	505	207
26273	1	2010-07-15	0	505	207
26274	1	2010-07-13	0	505	207
26275	1	2010-07-01	0	505	207
26276	1	2010-07-14	0	505	207
26277	1	2010-07-23	0	505	207
26278	1	2010-07-19	0	505	207
26279	1	2010-07-02	0	505	207
26280	1	2010-07-07	0	505	207
26281	1	2010-07-06	0	505	207
26282	1	2010-07-10	0	505	207
26283	1	2010-07-03	0	505	207
26284	1	2010-07-17	0	505	207
26285	1	2010-07-09	0	505	207
26286	1	2010-07-18	0	505	207
26287	1	2010-07-11	0	505	207
26288	1	2010-07-22	0	505	207
26289	1	2010-07-20	0	505	207
26290	1	2010-07-05	0	505	207
36671	3	2010-04-05	0	505	36260
36672	3	2010-02-17	0	505	36260
59111	5	2009-12-31	0	505	58789
59112	5	2010-01-03	0	505	58789
59108	5	2009-12-28	0	505	58789
59113	4	2010-01-26	7	505	58789
59106	5	2009-12-30	0	505	58789
59107	5	2009-12-29	0	505	58789
59109	5	2010-01-02	0	505	58789
58278	2	2010-01-06	0	505	49397
58277	2	2010-01-01	0	505	49397
58283	1	2009-12-25	0	505	49397
58282	3	2009-12-25	0	505	49399
58280	3	2010-01-01	0	505	49399
62014	1	2010-01-06	0	505	49399
59099	2	2010-01-18	0	505	58790
59097	2	2010-01-25	0	505	58790
59090	2	2010-01-11	0	505	58790
59086	2	2010-01-20	0	505	58790
59093	2	2010-01-23	0	505	58790
59096	2	2010-01-21	0	505	58790
59087	2	2010-01-19	0	505	58790
59092	2	2010-01-10	0	505	58790
59101	2	2010-01-24	0	505	58790
59088	2	2010-01-16	0	505	58790
59091	2	2010-01-17	0	505	58790
59094	2	2010-01-06	0	505	58790
59114	4	2010-01-31	7	505	58789
59110	5	2010-01-01	0	505	58789
59134	2	2010-01-13	0	505	58786
59130	2	2010-01-16	0	505	58786
59132	2	2010-01-14	0	505	58786
59133	2	2010-01-11	0	505	58786
59131	2	2010-01-15	0	505	58786
59129	2	2010-01-17	0	505	58786
59135	2	2010-01-12	0	505	58786
59123	4	2010-01-20	7	505	58789
59124	4	2010-01-23	7	505	58789
59126	4	2010-01-28	7	505	58789
59116	4	2010-01-25	7	505	58789
59121	4	2010-01-30	7	505	58789
59117	4	2010-01-24	7	505	58789
59122	4	2010-01-19	7	505	58789
59120	4	2010-01-08	7	510	58789
59127	4	2010-01-29	7	505	58789
59115	4	2010-01-27	7	505	58789
59128	4	2010-01-06	0	505	58789
59119	4	2010-01-18	7	505	58789
59118	4	2010-01-22	7	505	58789
59125	4	2010-01-21	7	505	58789
\.


--
-- Data for Name: calendarexceptiontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY calendarexceptiontype (id, version, name, color, notassignable) FROM stdin;
505	6	HOLIDAY	red	t
506	5	SICK_LEAVE	red	t
507	4	LEAVE	red	t
508	3	STRIKE	red	t
509	2	BANK_HOLIDAY	red	t
510	1	WORKABLE_BANK_HOLIDAY	orange	f
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY configuration (id, version, configuration_id, companycode) FROM stdin;
404	4	202	\N
\.


--
-- Data for Name: cost_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY cost_category (id, version, name, enabled) FROM stdin;
1313	1	Oficial 1º	t
1315	3	Peón	t
1314	3	Oficial 2º	t
\.


--
-- Data for Name: criterion; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterion (id, version, name, active, id_criterion_type, parent) FROM stdin;
108	4	Calderero	t	4	\N
106	4	Soldador	t	4	\N
107	4	Andamiero	t	4	\N
36057	3	Ingeniero en Informática	t	4	\N
105	4	Pintor	t	4	\N
38481	2	Diseñador gráfico	t	4	\N
49894	1	Desarrollador	t	16154624	\N
49895	1	Analista	t	16154624	\N
49896	1	Coordinador	t	16154624	\N
101	14	medicalLeave	t	1	\N
102	13	paternityLeave	t	1	\N
103	4	hiredResourceWorkingRelationship	t	5	\N
104	3	firedResourceWorkingRelationship	t	5	\N
109	2	Curso de riesgos laborales	t	3	\N
110	2	Torno	t	7	\N
111	2	Plegadora	t	7	\N
25755	2	Horno	t	7	\N
\.


--
-- Data for Name: criterionrequirement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionrequirement (id, criterion_requirement_type, version, hours_group_id, order_element_id, criterion_id, parent, isvalid) FROM stdin;
28007	DIRECT	3	\N	27607	109	\N	\N
28008	DIRECT	3	27792	\N	106	\N	\N
28009	INDIRECT	3	27792	\N	109	28007	t
36916	DIRECT	7	\N	35766	36057	\N	\N
36917	INDIRECT	7	\N	35791	36057	36916	t
28030	DIRECT	2	\N	27608	106	\N	\N
28031	INDIRECT	2	27793	\N	106	28030	t
36918	INDIRECT	7	35980	\N	36057	36916	t
36919	INDIRECT	7	\N	35792	36057	36916	t
36920	INDIRECT	7	35981	\N	36057	36916	t
36921	INDIRECT	7	\N	35793	36057	36916	t
36922	INDIRECT	7	35982	\N	36057	36916	t
36923	INDIRECT	7	\N	35794	36057	36916	t
36924	INDIRECT	7	35983	\N	36057	36916	t
36925	INDIRECT	7	\N	35795	36057	36916	t
29783	DIRECT	4	\N	29323	109	\N	\N
29785	INDIRECT	4	29508	\N	109	29783	t
29784	DIRECT	4	29508	\N	106	\N	\N
29786	DIRECT	4	\N	29325	106	\N	\N
29787	INDIRECT	4	29510	\N	106	29786	t
2204	DIRECT	15	\N	1150	110	\N	\N
3420	INDIRECT	14	2863	\N	110	2204	t
2205	DIRECT	15	\N	1151	111	\N	\N
4910	DIRECT	4	1435	\N	105	\N	\N
4911	DIRECT	4	1436	\N	107	\N	\N
4912	DIRECT	4	1437	\N	106	\N	\N
4913	DIRECT	4	\N	1362	108	\N	\N
2389	DIRECT	5	2880	\N	106	\N	\N
2388	DIRECT	5	1891	\N	110	\N	\N
2390	DIRECT	5	\N	1182	108	\N	\N
3421	INDIRECT	14	2864	\N	111	2205	t
2206	DIRECT	15	\N	1152	105	\N	\N
2207	INDIRECT	15	2865	\N	105	2206	t
2208	DIRECT	15	\N	1153	105	\N	\N
2209	INDIRECT	15	2866	\N	105	2208	t
2210	DIRECT	15	\N	1154	107	\N	\N
2211	INDIRECT	15	2867	\N	107	2210	t
2391	DIRECT	5	\N	1182	106	\N	\N
2392	INDIRECT	5	2882	\N	108	2390	t
2393	INDIRECT	5	2882	\N	106	2391	t
2394	DIRECT	5	\N	1183	108	\N	\N
2395	INDIRECT	5	2883	\N	108	2394	t
4914	INDIRECT	4	1438	\N	108	4913	t
4915	DIRECT	4	\N	1363	106	\N	\N
4916	INDIRECT	4	1439	\N	106	4915	t
4918	DIRECT	4	\N	1364	106	\N	\N
4917	DIRECT	4	\N	1364	105	\N	\N
4919	INDIRECT	4	1440	\N	106	4918	t
4920	INDIRECT	4	1440	\N	105	4917	t
4921	DIRECT	4	\N	1365	107	\N	\N
4922	INDIRECT	4	1441	\N	107	4921	t
1646	DIRECT	11	\N	1126	105	\N	\N
1647	INDIRECT	11	2843	\N	105	1646	t
1679	DIRECT	10	1457	\N	107	\N	\N
1678	DIRECT	10	2844	\N	106	\N	\N
1816	DIRECT	9	\N	1128	105	\N	\N
1817	INDIRECT	9	2845	\N	105	1816	t
1919	DIRECT	9	2846	\N	108	\N	\N
1935	DIRECT	8	1855	\N	106	\N	\N
1966	DIRECT	7	1856	\N	106	\N	\N
1967	DIRECT	7	2847	\N	108	\N	\N
50440	INDIRECT	10	50501	\N	36057	49998	t
50441	INDIRECT	10	\N	50374	36057	49998	t
50442	INDIRECT	10	50502	\N	36057	49998	t
50443	INDIRECT	10	\N	50375	36057	49998	t
50444	INDIRECT	10	50503	\N	36057	49998	t
50445	INDIRECT	10	\N	50376	36057	49998	t
36926	INDIRECT	7	35984	\N	36057	36916	t
36927	INDIRECT	7	\N	35796	36057	36916	t
36928	INDIRECT	7	35985	\N	36057	36916	t
36931	INDIRECT	7	\N	35798	36057	36916	t
36932	INDIRECT	7	35987	\N	36057	36916	t
36929	INDIRECT	7	\N	35797	36057	36916	t
36930	INDIRECT	7	35986	\N	36057	36916	t
38184	INDIRECT	6	\N	38080	36057	36916	t
38185	INDIRECT	6	38282	\N	36057	36916	t
40793	DIRECT	5	\N	39823	36057	\N	\N
40794	INDIRECT	5	\N	39872	36057	40793	t
40795	INDIRECT	5	40035	\N	36057	40793	t
40796	INDIRECT	5	\N	39873	36057	40793	t
40797	INDIRECT	5	40036	\N	36057	40793	t
40798	INDIRECT	5	\N	39874	36057	40793	t
40799	INDIRECT	5	\N	39875	36057	40793	t
40800	INDIRECT	5	40037	\N	36057	40793	t
40801	INDIRECT	5	\N	39876	36057	40793	t
40802	INDIRECT	5	40038	\N	36057	40793	t
40803	INDIRECT	5	\N	39877	36057	40793	t
40804	INDIRECT	5	\N	39878	36057	40793	t
40805	INDIRECT	5	40039	\N	36057	40793	t
40806	INDIRECT	5	\N	39879	36057	40793	t
40807	INDIRECT	5	40040	\N	36057	40793	t
40808	INDIRECT	5	\N	39880	36057	40793	t
40809	INDIRECT	5	40041	\N	36057	40793	t
40810	INDIRECT	5	\N	39881	36057	40793	t
40811	INDIRECT	5	40042	\N	36057	40793	t
40812	INDIRECT	5	\N	39882	36057	40793	t
51615	DIRECT	6	\N	50360	49894	\N	\N
51616	INDIRECT	6	\N	50361	49894	51615	t
51617	INDIRECT	6	50189	\N	49894	51615	t
51618	INDIRECT	6	\N	50362	49894	51615	t
51619	INDIRECT	6	50190	\N	49894	51615	t
51620	INDIRECT	6	\N	50363	49894	51615	t
51621	INDIRECT	6	50191	\N	49894	51615	t
51622	INDIRECT	6	\N	50364	49894	51615	t
51623	INDIRECT	6	50192	\N	49894	51615	t
51624	DIRECT	6	\N	50365	49894	\N	\N
51625	INDIRECT	6	\N	50366	49894	51624	t
51626	INDIRECT	6	50193	\N	49894	51624	t
51627	INDIRECT	6	\N	50367	49894	51624	t
51628	INDIRECT	6	50194	\N	49894	51624	t
51629	INDIRECT	6	\N	50368	49894	51624	t
51630	INDIRECT	6	50195	\N	49894	51624	t
51631	DIRECT	6	\N	50369	49894	\N	\N
51632	INDIRECT	6	\N	50370	49894	51631	t
56955	DIRECT	5	\N	50646	49894	\N	\N
56956	INDIRECT	5	\N	50647	49894	56955	t
50769	INDIRECT	9	\N	50647	36057	49998	t
50770	INDIRECT	9	50557	\N	36057	49998	t
56957	INDIRECT	5	50557	\N	49894	56955	t
50771	INDIRECT	9	\N	50648	36057	49998	t
50772	INDIRECT	9	\N	50649	36057	49998	t
50773	INDIRECT	9	50558	\N	36057	49998	t
40813	INDIRECT	5	40043	\N	36057	40793	t
40814	INDIRECT	5	\N	39883	36057	40793	t
40815	INDIRECT	5	\N	39884	36057	40793	t
40816	INDIRECT	5	40044	\N	36057	40793	t
40817	INDIRECT	5	\N	39885	36057	40793	t
40818	INDIRECT	5	40045	\N	36057	40793	t
40819	INDIRECT	5	\N	39886	36057	40793	t
40820	INDIRECT	5	40046	\N	36057	40793	t
40821	INDIRECT	5	\N	39887	36057	40793	t
40822	INDIRECT	5	40047	\N	36057	40793	t
49998	DIRECT	11	\N	49125	36057	\N	\N
51633	INDIRECT	6	50196	\N	49894	51631	t
51634	DIRECT	6	\N	50371	49894	\N	\N
51635	INDIRECT	6	\N	50372	49894	51634	t
51636	INDIRECT	6	50500	\N	49894	51634	t
51637	INDIRECT	6	\N	50373	49894	51634	t
51638	INDIRECT	6	50501	\N	49894	51634	t
51639	INDIRECT	6	\N	50374	49894	51634	t
51640	INDIRECT	6	50502	\N	49894	51634	t
51641	INDIRECT	6	\N	50375	49894	51634	t
50461	INDIRECT	10	\N	50386	36057	49998	t
50462	INDIRECT	10	50510	\N	36057	49998	t
50463	INDIRECT	10	\N	50387	36057	49998	t
50464	INDIRECT	10	50511	\N	36057	49998	t
50465	INDIRECT	10	\N	50388	36057	49998	t
50466	INDIRECT	10	50512	\N	36057	49998	t
50467	INDIRECT	10	\N	50389	36057	49998	t
50468	INDIRECT	10	50513	\N	36057	49998	t
50469	INDIRECT	10	\N	50390	36057	49998	t
50470	INDIRECT	10	50514	\N	36057	49998	t
50471	INDIRECT	10	\N	50391	36057	49998	t
50472	INDIRECT	10	\N	50392	36057	49998	t
50782	INDIRECT	9	50562	\N	36057	49998	t
50783	INDIRECT	9	\N	50655	36057	49998	t
50784	INDIRECT	9	50563	\N	36057	49998	t
50785	INDIRECT	9	\N	50656	36057	49998	t
50786	INDIRECT	9	50564	\N	36057	49998	t
50787	INDIRECT	9	\N	50657	36057	49998	t
50788	INDIRECT	9	50565	\N	36057	49998	t
50789	INDIRECT	9	\N	50658	36057	49998	t
50790	INDIRECT	9	50566	\N	36057	49998	t
50791	INDIRECT	9	\N	50659	36057	49998	t
50792	INDIRECT	9	50567	\N	36057	49998	t
50793	INDIRECT	9	\N	50660	36057	49998	t
50794	INDIRECT	9	50568	\N	36057	49998	t
50795	INDIRECT	9	\N	50661	36057	49998	t
50796	INDIRECT	9	50569	\N	36057	49998	t
50797	INDIRECT	9	\N	50662	36057	49998	t
50417	INDIRECT	10	\N	50360	36057	49998	t
50418	INDIRECT	10	\N	50361	36057	49998	t
50419	INDIRECT	10	50189	\N	36057	49998	t
50420	INDIRECT	10	\N	50362	36057	49998	t
50421	INDIRECT	10	50190	\N	36057	49998	t
50422	INDIRECT	10	\N	50363	36057	49998	t
50423	INDIRECT	10	50191	\N	36057	49998	t
50424	INDIRECT	10	\N	50364	36057	49998	t
50425	INDIRECT	10	50192	\N	36057	49998	t
50426	INDIRECT	10	\N	50365	36057	49998	t
50427	INDIRECT	10	\N	50366	36057	49998	t
50428	INDIRECT	10	50193	\N	36057	49998	t
50429	INDIRECT	10	\N	50367	36057	49998	t
50430	INDIRECT	10	50194	\N	36057	49998	t
50431	INDIRECT	10	\N	50368	36057	49998	t
50432	INDIRECT	10	50195	\N	36057	49998	t
50433	INDIRECT	10	\N	50369	36057	49998	t
50434	INDIRECT	10	\N	50370	36057	49998	t
50435	INDIRECT	10	50196	\N	36057	49998	t
50436	INDIRECT	10	\N	50371	36057	49998	t
51642	INDIRECT	6	50503	\N	49894	51634	t
50473	INDIRECT	10	50515	\N	36057	49998	t
50474	INDIRECT	10	\N	50393	36057	49998	t
50475	INDIRECT	10	50516	\N	36057	49998	t
50476	INDIRECT	10	\N	50394	36057	49998	t
50477	INDIRECT	10	50517	\N	36057	49998	t
50478	INDIRECT	10	\N	50395	36057	49998	t
50479	INDIRECT	10	50518	\N	36057	49998	t
50480	INDIRECT	10	\N	50396	36057	49998	t
50481	INDIRECT	10	50519	\N	36057	49998	t
50484	INDIRECT	10	\N	50398	36057	49998	t
50485	INDIRECT	10	\N	50601	36057	49998	t
50486	INDIRECT	10	50521	\N	36057	49998	t
50487	INDIRECT	10	\N	50602	36057	49998	t
50488	INDIRECT	10	50522	\N	36057	49998	t
50763	INDIRECT	9	\N	50643	36057	49998	t
50764	INDIRECT	9	\N	50644	36057	49998	t
50765	INDIRECT	9	50555	\N	36057	49998	t
50766	INDIRECT	9	\N	50645	36057	49998	t
50767	INDIRECT	9	50556	\N	36057	49998	t
50768	INDIRECT	9	\N	50646	36057	49998	t
58107	DIRECT	4	\N	50669	49894	\N	\N
50437	INDIRECT	10	\N	50372	36057	49998	t
50438	INDIRECT	10	50500	\N	36057	49998	t
50439	INDIRECT	10	\N	50373	36057	49998	t
50446	INDIRECT	10	\N	50377	36057	49998	t
50447	INDIRECT	10	50504	\N	36057	49998	t
50448	INDIRECT	10	\N	50378	36057	49998	t
56910	INDIRECT	5	\N	50379	49894	56909	t
50449	INDIRECT	10	\N	50379	36057	49998	t
50450	INDIRECT	10	50505	\N	36057	49998	t
56911	INDIRECT	5	50505	\N	49894	56909	t
50451	INDIRECT	10	\N	50380	36057	49998	t
56912	DIRECT	5	\N	50380	49894	\N	\N
56913	INDIRECT	5	\N	50381	49894	56912	t
50452	INDIRECT	10	\N	50381	36057	49998	t
56914	INDIRECT	5	50506	\N	49894	56912	t
50453	INDIRECT	10	50506	\N	36057	49998	t
50454	INDIRECT	10	\N	50382	36057	49998	t
56915	INDIRECT	5	\N	50382	49894	56912	t
50455	INDIRECT	10	50507	\N	36057	49998	t
56916	INDIRECT	5	50507	\N	49894	56912	t
56917	INDIRECT	5	\N	50383	49894	56912	t
50456	INDIRECT	10	\N	50383	36057	49998	t
56918	INDIRECT	5	50508	\N	49894	56912	t
50457	INDIRECT	10	50508	\N	36057	49998	t
50458	INDIRECT	10	\N	50384	36057	49998	t
56919	DIRECT	5	\N	50384	49894	\N	\N
50459	INDIRECT	10	\N	50385	36057	49998	t
56920	INDIRECT	5	\N	50385	49894	56919	t
56921	INDIRECT	5	50509	\N	49894	56919	t
50460	INDIRECT	10	50509	\N	36057	49998	t
56922	INDIRECT	5	\N	50386	49894	56919	t
56923	INDIRECT	5	50510	\N	49894	56919	t
56924	INDIRECT	5	\N	50387	49894	56919	t
56925	INDIRECT	5	50511	\N	49894	56919	t
56926	INDIRECT	5	\N	50388	49894	56919	t
56927	INDIRECT	5	50512	\N	49894	56919	t
56928	INDIRECT	5	\N	50389	49894	56919	t
56929	INDIRECT	5	50513	\N	49894	56919	t
56930	INDIRECT	5	\N	50390	49894	56919	t
56931	INDIRECT	5	50514	\N	49894	56919	t
56906	DIRECT	5	\N	50376	49894	\N	\N
56907	INDIRECT	5	\N	50377	49894	56906	t
56908	INDIRECT	5	50504	\N	49894	56906	t
56909	DIRECT	5	\N	50378	49894	\N	\N
56940	INDIRECT	5	50517	\N	49894	56932	t
56941	INDIRECT	5	\N	50395	49894	56932	t
56942	INDIRECT	5	50518	\N	49894	56932	t
56943	INDIRECT	5	\N	50396	49894	56932	t
56944	INDIRECT	5	50519	\N	49894	56932	t
56945	DIRECT	5	\N	50398	49894	\N	\N
56946	INDIRECT	5	\N	50601	49894	56945	t
56947	INDIRECT	5	50521	\N	49894	56945	t
56948	INDIRECT	5	\N	50602	49894	56945	t
56949	INDIRECT	5	50522	\N	49894	56945	t
56950	DIRECT	5	\N	50643	49894	\N	\N
56951	INDIRECT	5	\N	50644	49894	56950	t
56952	INDIRECT	5	50555	\N	49894	56950	t
56953	INDIRECT	5	\N	50645	49894	56950	t
56954	INDIRECT	5	50556	\N	49894	56950	t
50774	INDIRECT	9	\N	50650	36057	49998	t
50775	INDIRECT	9	\N	50651	36057	49998	t
50776	INDIRECT	9	50559	\N	36057	49998	t
50777	INDIRECT	9	\N	50652	36057	49998	t
50778	INDIRECT	9	50560	\N	36057	49998	t
50779	INDIRECT	9	\N	50653	36057	49998	t
50780	INDIRECT	9	50561	\N	36057	49998	t
50781	INDIRECT	9	\N	50654	36057	49998	t
50798	INDIRECT	9	50570	\N	36057	49998	t
50809	INDIRECT	7	\N	50669	36057	49998	t
50810	INDIRECT	7	\N	50670	36057	49998	t
50811	INDIRECT	7	50575	\N	36057	49998	t
58095	INDIRECT	4	\N	50657	49894	58082	t
58096	INDIRECT	4	50565	\N	49894	58082	t
58097	INDIRECT	4	\N	50658	49894	58082	t
56932	DIRECT	5	\N	50391	49894	\N	\N
56934	DIRECT	5	\N	50392	49895	\N	\N
56933	INDIRECT	5	\N	50392	49894	56932	f
56936	INDIRECT	5	50515	\N	49894	56932	f
56935	INDIRECT	5	50515	\N	49895	56934	t
56937	INDIRECT	5	\N	50393	49894	56932	t
56938	INDIRECT	5	50516	\N	49894	56932	t
56939	INDIRECT	5	\N	50394	49894	56932	t
58082	DIRECT	4	\N	50650	49894	\N	\N
58083	INDIRECT	4	\N	50651	49894	58082	t
58084	INDIRECT	4	50559	\N	49894	58082	t
58085	INDIRECT	4	\N	50652	49894	58082	t
58086	INDIRECT	4	50560	\N	49894	58082	t
58087	INDIRECT	4	\N	50653	49894	58082	t
58088	INDIRECT	4	50561	\N	49894	58082	t
58089	INDIRECT	4	\N	50654	49894	58082	t
58090	INDIRECT	4	50562	\N	49894	58082	t
58091	INDIRECT	4	\N	50655	49894	58082	t
58092	INDIRECT	4	50563	\N	49894	58082	t
58093	INDIRECT	4	\N	50656	49894	58082	t
58094	INDIRECT	4	50564	\N	49894	58082	t
58098	INDIRECT	4	50566	\N	49894	58082	t
58099	INDIRECT	4	\N	50659	49894	58082	t
58100	INDIRECT	4	50567	\N	49894	58082	t
58101	INDIRECT	4	\N	50660	49894	58082	t
58102	INDIRECT	4	50568	\N	49894	58082	t
58103	DIRECT	4	\N	50661	49896	\N	\N
58104	INDIRECT	4	50569	\N	49896	58103	t
58105	DIRECT	4	\N	50662	49895	\N	\N
58106	INDIRECT	4	50570	\N	49895	58105	t
58108	INDIRECT	4	\N	50670	49894	58107	t
58109	INDIRECT	4	50575	\N	49894	58107	t
50812	INDIRECT	7	\N	50671	36057	49998	t
58110	INDIRECT	4	\N	50671	49894	58107	t
50813	INDIRECT	7	50576	\N	36057	49998	t
58111	INDIRECT	4	50576	\N	49894	58107	t
\.


--
-- Data for Name: criterionsatisfaction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criterionsatisfaction (id, version, startdate, finishdate, isdeleted, criterion, resource) FROM stdin;
49705	4	2009-12-23 13:42:26.88	\N	f	36057	49302
49704	4	2009-12-23 13:42:31.649	\N	f	49895	49302
49692	5	2009-12-23 13:31:53.237	\N	f	36057	49289
49715	2	2009-12-23 14:05:57.765	\N	f	49894	49313
49714	2	2009-12-23 14:05:54.245	\N	f	36057	49313
49700	6	2009-12-23 13:41:16.177	\N	f	49894	49297
49701	6	2009-12-23 13:41:11.777	\N	f	36057	49297
49693	4	2009-12-23 13:33:29.272	\N	f	49894	36159
36562	5	2009-12-14 12:02:22.226	\N	f	36057	36159
37976	4	2009-12-14 12:37:38.899	\N	f	36057	37573
49694	3	2009-12-23 13:33:42.338	\N	f	49894	37573
49703	3	2009-12-23 13:42:13.486	\N	f	36057	49300
1819	2	2009-12-07 12:14:12.984	\N	f	107	1720
1818	2	2009-12-07 12:13:55.69	\N	f	105	1718
49702	3	2009-12-23 13:42:17.331	\N	f	49894	49300
49716	2	2009-12-23 14:06:21.862	\N	f	108	49315
1821	3	2009-12-07 12:15:40.633	\N	f	106	1724
1820	3	2009-12-07 12:14:39.805	\N	f	105	1722
49707	6	2009-12-23 13:44:09.703	\N	f	49896	49304
49706	6	2009-12-23 13:43:57.657	\N	f	36057	49304
49695	7	2009-12-23 13:33:57.905	\N	f	49894	40199
40602	8	2009-12-18 11:37:52.396	\N	f	36057	40199
7575	6	2009-12-08 11:38:48.256	\N	f	111	7272
1822	7	2009-12-07 12:16:13.031	\N	f	105	1726
49711	7	2009-12-23 13:47:11.819	\N	f	49894	49309
1823	7	2009-12-07 12:22:26.956	\N	f	110	1727
49710	7	2009-12-23 13:47:08.42	\N	f	36057	49309
37977	1	2009-12-14 13:20:50.703	\N	f	38481	37575
\.


--
-- Data for Name: criteriontype; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY criteriontype (id, version, name, description, allowsimultaneouscriterionsperresource, allowhierarchy, enabled, resource) FROM stdin;
4	9	JOB	Job	t	t	t	1
16154624	1	Rol proyecto	\N	t	t	t	0
1	15	LEAVE	Leave	f	f	t	1
2	11	CATEGORY	Professional category	t	t	t	1
3	9	TRAINING	Training courses and labor training	t	t	t	1
5	5	WORK_RELATIONSHIP	Relationship of the resource with the enterprise 	f	f	t	1
6	1	LOCATION_GROUP	Location where the resource work	t	f	t	0
7	2	Tipo de máquina	\N	t	f	t	2
\.


--
-- Data for Name: day_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY day_assignment (id, day_assignment_type, version, hours, day, resource_id, specific_resource_allocation_id, generic_resource_allocation_id, derived_allocation_id) FROM stdin;
30862	GENERIC_DAY	3	3	2010-02-05	1724	\N	29808	\N
30863	GENERIC_DAY	3	3	2010-03-09	1724	\N	29808	\N
30864	GENERIC_DAY	3	3	2010-01-15	1724	\N	29808	\N
30865	GENERIC_DAY	3	3	2010-02-16	1724	\N	29808	\N
30866	GENERIC_DAY	3	3	2010-01-21	1724	\N	29808	\N
30867	GENERIC_DAY	3	0	2010-04-10	1724	\N	29808	\N
30868	GENERIC_DAY	3	3	2010-01-25	1724	\N	29808	\N
30869	GENERIC_DAY	3	0	2010-03-13	1724	\N	29808	\N
30870	GENERIC_DAY	3	2	2010-04-15	1724	\N	29808	\N
30871	GENERIC_DAY	3	0	2010-04-11	1724	\N	29808	\N
30872	GENERIC_DAY	3	0	2010-03-20	1724	\N	29808	\N
30873	GENERIC_DAY	3	3	2010-03-12	1724	\N	29808	\N
30874	GENERIC_DAY	3	0	2010-03-06	1724	\N	29808	\N
30875	GENERIC_DAY	3	3	2010-03-31	1724	\N	29808	\N
30876	GENERIC_DAY	3	3	2010-03-17	1724	\N	29808	\N
30877	GENERIC_DAY	3	2	2010-04-05	1724	\N	29808	\N
30878	GENERIC_DAY	3	0	2010-03-27	1724	\N	29808	\N
30879	GENERIC_DAY	3	0	2010-03-21	1724	\N	29808	\N
30880	GENERIC_DAY	3	3	2010-03-10	1724	\N	29808	\N
30881	GENERIC_DAY	3	3	2010-03-30	1724	\N	29808	\N
30882	GENERIC_DAY	3	3	2010-03-11	1724	\N	29808	\N
30883	GENERIC_DAY	3	3	2010-02-02	1724	\N	29808	\N
30884	GENERIC_DAY	3	3	2010-03-24	1724	\N	29808	\N
30885	GENERIC_DAY	3	0	2010-03-14	1724	\N	29808	\N
30886	GENERIC_DAY	3	0	2010-02-21	1724	\N	29808	\N
30887	GENERIC_DAY	3	0	2010-04-04	1724	\N	29808	\N
30888	GENERIC_DAY	3	3	2010-01-20	1724	\N	29808	\N
30889	GENERIC_DAY	3	3	2010-02-19	1724	\N	29808	\N
30890	GENERIC_DAY	3	3	2010-02-04	1724	\N	29808	\N
30891	GENERIC_DAY	3	3	2010-03-05	1724	\N	29808	\N
30892	GENERIC_DAY	3	3	2010-02-12	1724	\N	29808	\N
30893	GENERIC_DAY	3	3	2010-01-28	1724	\N	29808	\N
30894	GENERIC_DAY	3	2	2010-04-13	1724	\N	29808	\N
30895	GENERIC_DAY	3	3	2010-01-22	1724	\N	29808	\N
30896	GENERIC_DAY	3	3	2010-03-02	1724	\N	29808	\N
30897	GENERIC_DAY	3	0	2010-02-06	1724	\N	29808	\N
30898	GENERIC_DAY	3	3	2010-01-12	1724	\N	29808	\N
30899	GENERIC_DAY	3	3	2010-01-18	1724	\N	29808	\N
30900	GENERIC_DAY	3	3	2010-03-23	1724	\N	29808	\N
30901	GENERIC_DAY	3	2	2010-04-07	1724	\N	29808	\N
30902	GENERIC_DAY	3	3	2010-01-11	1724	\N	29808	\N
30903	GENERIC_DAY	3	0	2010-02-07	1724	\N	29808	\N
30904	GENERIC_DAY	3	3	2010-02-24	1724	\N	29808	\N
30905	GENERIC_DAY	3	0	2010-04-03	1724	\N	29808	\N
30906	GENERIC_DAY	3	2	2010-04-08	1724	\N	29808	\N
30907	GENERIC_DAY	3	3	2010-02-25	1724	\N	29808	\N
30908	GENERIC_DAY	3	3	2010-01-29	1724	\N	29808	\N
30909	GENERIC_DAY	3	0	2010-01-30	1724	\N	29808	\N
30910	GENERIC_DAY	3	3	2010-02-17	1724	\N	29808	\N
30911	GENERIC_DAY	3	3	2010-02-10	1724	\N	29808	\N
30912	GENERIC_DAY	3	3	2010-01-19	1724	\N	29808	\N
30913	GENERIC_DAY	3	2	2010-04-12	1724	\N	29808	\N
30914	GENERIC_DAY	3	0	2010-04-18	1724	\N	29808	\N
30915	GENERIC_DAY	3	3	2010-02-08	1724	\N	29808	\N
30916	GENERIC_DAY	3	0	2010-01-24	1724	\N	29808	\N
30917	GENERIC_DAY	3	0	2010-03-07	1724	\N	29808	\N
30918	GENERIC_DAY	3	0	2010-02-27	1724	\N	29808	\N
30919	GENERIC_DAY	3	0	2010-01-23	1724	\N	29808	\N
30920	GENERIC_DAY	3	3	2010-02-01	1724	\N	29808	\N
30921	GENERIC_DAY	3	3	2010-03-25	1724	\N	29808	\N
30922	GENERIC_DAY	3	3	2010-04-01	1724	\N	29808	\N
30923	GENERIC_DAY	3	0	2010-01-17	1724	\N	29808	\N
16002	GENERIC_DAY	3	3	2010-04-07	1726	\N	3985	\N
16003	GENERIC_DAY	3	2	2010-04-08	1718	\N	3985	\N
16004	GENERIC_DAY	3	1	2010-04-10	1718	\N	3985	\N
16005	GENERIC_DAY	3	3	2010-03-29	1722	\N	3985	\N
16006	GENERIC_DAY	3	2	2010-04-05	1718	\N	3985	\N
16007	GENERIC_DAY	3	3	2010-04-03	1722	\N	3985	\N
16008	GENERIC_DAY	3	3	2010-04-01	1726	\N	3985	\N
16009	GENERIC_DAY	3	2	2010-04-09	1718	\N	3985	\N
16010	GENERIC_DAY	3	2	2010-03-30	1718	\N	3985	\N
16011	GENERIC_DAY	3	3	2010-04-09	1722	\N	3985	\N
16012	GENERIC_DAY	3	2	2010-04-02	1718	\N	3985	\N
16013	GENERIC_DAY	3	2	2010-04-03	1718	\N	3985	\N
16014	GENERIC_DAY	3	2	2010-03-31	1718	\N	3985	\N
16015	GENERIC_DAY	3	3	2010-04-09	1726	\N	3985	\N
16016	GENERIC_DAY	3	3	2010-03-29	1726	\N	3985	\N
16017	GENERIC_DAY	3	3	2010-04-05	1722	\N	3985	\N
16018	GENERIC_DAY	3	2	2010-04-07	1718	\N	3985	\N
16019	GENERIC_DAY	3	3	2010-04-04	1722	\N	3985	\N
16020	GENERIC_DAY	3	2	2010-03-29	1718	\N	3985	\N
16021	GENERIC_DAY	3	2	2010-04-04	1718	\N	3985	\N
16022	GENERIC_DAY	3	2	2010-04-01	1718	\N	3985	\N
16023	GENERIC_DAY	3	3	2010-03-30	1722	\N	3985	\N
16024	GENERIC_DAY	3	3	2010-04-02	1722	\N	3985	\N
16025	GENERIC_DAY	3	3	2010-04-07	1722	\N	3985	\N
16026	GENERIC_DAY	3	3	2010-04-04	1726	\N	3985	\N
16027	GENERIC_DAY	3	2	2010-04-06	1718	\N	3985	\N
16028	GENERIC_DAY	3	3	2010-04-06	1726	\N	3985	\N
16029	GENERIC_DAY	3	1	2010-04-10	1726	\N	3985	\N
16030	GENERIC_DAY	3	2	2010-04-10	1722	\N	3985	\N
16031	GENERIC_DAY	3	3	2010-04-03	1726	\N	3985	\N
16032	GENERIC_DAY	3	3	2010-03-31	1726	\N	3985	\N
16033	GENERIC_DAY	3	3	2010-04-06	1722	\N	3985	\N
16034	GENERIC_DAY	3	3	2010-04-08	1726	\N	3985	\N
38745	GENERIC_DAY	6	5	2010-03-09	37573	\N	38583	\N
38732	GENERIC_DAY	6	0	2010-03-14	37573	\N	38583	\N
38744	GENERIC_DAY	6	3	2010-03-02	36159	\N	38583	\N
38752	GENERIC_DAY	6	4	2010-02-24	37573	\N	38583	\N
38759	GENERIC_DAY	6	3	2010-03-11	36159	\N	38583	\N
38746	GENERIC_DAY	6	5	2010-03-03	37573	\N	38583	\N
38757	GENERIC_DAY	6	4	2010-02-26	36159	\N	38583	\N
38736	GENERIC_DAY	6	0	2010-03-06	36159	\N	38583	\N
38747	GENERIC_DAY	6	3	2010-03-01	36159	\N	38583	\N
38753	GENERIC_DAY	6	5	2010-03-12	37573	\N	38583	\N
38734	GENERIC_DAY	6	4	2010-02-25	36159	\N	38583	\N
38733	GENERIC_DAY	6	0	2010-03-13	36159	\N	38583	\N
38730	GENERIC_DAY	6	0	2010-03-14	36159	\N	38583	\N
38756	GENERIC_DAY	6	3	2010-03-08	36159	\N	38583	\N
27203	GENERIC_DAY	1	3	2009-12-09	1718	\N	3940	\N
27204	GENERIC_DAY	1	3	2009-12-16	1726	\N	3940	\N
27205	GENERIC_DAY	1	3	2009-12-10	1726	\N	3940	\N
27206	GENERIC_DAY	1	1	2009-12-23	1726	\N	3940	\N
27207	GENERIC_DAY	1	2	2009-12-08	1718	\N	3940	\N
27208	GENERIC_DAY	1	3	2009-12-08	1722	\N	3940	\N
27209	GENERIC_DAY	1	0	2009-12-13	1718	\N	3940	\N
38735	GENERIC_DAY	6	3	2010-03-03	36159	\N	38583	\N
38741	GENERIC_DAY	6	3	2010-02-22	36159	\N	38583	\N
38742	GENERIC_DAY	6	3	2010-03-05	36159	\N	38583	\N
31145	GENERIC_DAY	1	8	2010-03-15	1724	\N	28093	\N
31146	GENERIC_DAY	1	0	2010-02-20	1724	\N	28093	\N
24760	GENERIC_DAY	1	8	2010-04-15	1720	\N	19898	\N
24748	GENERIC_DAY	1	8	2010-04-20	1720	\N	19898	\N
24751	GENERIC_DAY	1	8	2010-04-21	1720	\N	19898	\N
24764	GENERIC_DAY	1	8	2010-04-08	1720	\N	19898	\N
24756	GENERIC_DAY	1	0	2010-04-10	1720	\N	19898	\N
24745	GENERIC_DAY	1	0	2010-04-03	1720	\N	19898	\N
24749	GENERIC_DAY	1	0	2010-04-18	1720	\N	19898	\N
24755	GENERIC_DAY	1	0	2010-04-04	1720	\N	19898	\N
24752	GENERIC_DAY	1	8	2010-04-09	1720	\N	19898	\N
24753	GENERIC_DAY	1	8	2010-04-05	1720	\N	19898	\N
24762	GENERIC_DAY	1	8	2010-04-12	1720	\N	19898	\N
24758	GENERIC_DAY	1	8	2010-04-06	1720	\N	19898	\N
24763	GENERIC_DAY	1	8	2010-04-01	1720	\N	19898	\N
24750	GENERIC_DAY	1	8	2010-04-13	1720	\N	19898	\N
24766	GENERIC_DAY	1	4	2010-04-22	1720	\N	19898	\N
24747	GENERIC_DAY	1	8	2010-04-07	1720	\N	19898	\N
24754	GENERIC_DAY	1	8	2010-04-02	1720	\N	19898	\N
24757	GENERIC_DAY	1	8	2010-03-31	1720	\N	19898	\N
24759	GENERIC_DAY	1	8	2010-04-19	1720	\N	19898	\N
24743	GENERIC_DAY	1	8	2010-04-16	1720	\N	19898	\N
24744	GENERIC_DAY	1	0	2010-04-11	1720	\N	19898	\N
24746	GENERIC_DAY	1	8	2010-03-30	1720	\N	19898	\N
24765	GENERIC_DAY	1	0	2010-04-17	1720	\N	19898	\N
24761	GENERIC_DAY	1	8	2010-04-14	1720	\N	19898	\N
24660	GENERIC_DAY	1	2	2010-02-10	1718	\N	19899	\N
24694	GENERIC_DAY	1	0	2009-12-27	1726	\N	19899	\N
24699	GENERIC_DAY	1	0	2010-01-10	1722	\N	19899	\N
24691	GENERIC_DAY	1	2	2010-02-11	1718	\N	19899	\N
24621	GENERIC_DAY	1	2	2010-01-05	1722	\N	19899	\N
24732	GENERIC_DAY	1	0	2010-01-03	1726	\N	19899	\N
24693	GENERIC_DAY	1	3	2009-12-18	1726	\N	19899	\N
24603	GENERIC_DAY	1	2	2010-02-09	1718	\N	19899	\N
24695	GENERIC_DAY	1	2	2009-12-22	1726	\N	19899	\N
24684	GENERIC_DAY	1	2	2010-01-27	1726	\N	19899	\N
24618	GENERIC_DAY	1	2	2010-02-03	1722	\N	19899	\N
24722	GENERIC_DAY	1	2	2009-12-23	1722	\N	19899	\N
24672	GENERIC_DAY	1	0	2010-01-30	1718	\N	19899	\N
24737	GENERIC_DAY	1	0	2010-01-16	1722	\N	19899	\N
24734	GENERIC_DAY	1	3	2010-01-13	1726	\N	19899	\N
24697	GENERIC_DAY	1	2	2010-01-18	1718	\N	19899	\N
24630	GENERIC_DAY	1	2	2009-12-24	1722	\N	19899	\N
24656	GENERIC_DAY	1	3	2009-12-24	1718	\N	19899	\N
24718	GENERIC_DAY	1	0	2010-01-03	1722	\N	19899	\N
24663	GENERIC_DAY	1	2	2009-12-29	1726	\N	19899	\N
24708	GENERIC_DAY	1	0	2009-12-26	1722	\N	19899	\N
24644	GENERIC_DAY	1	2	2010-01-25	1718	\N	19899	\N
24692	GENERIC_DAY	1	0	2010-01-24	1726	\N	19899	\N
24639	GENERIC_DAY	1	3	2010-01-08	1726	\N	19899	\N
24698	GENERIC_DAY	1	2	2009-12-28	1726	\N	19899	\N
24742	GENERIC_DAY	1	0	2009-12-20	1722	\N	19899	\N
24726	GENERIC_DAY	1	2	2010-01-27	1718	\N	19899	\N
24647	GENERIC_DAY	1	0	2010-01-10	1726	\N	19899	\N
24730	GENERIC_DAY	1	2	2010-01-13	1722	\N	19899	\N
24641	GENERIC_DAY	1	1	2009-12-18	1722	\N	19899	\N
24602	GENERIC_DAY	1	0	2010-02-07	1726	\N	19899	\N
24649	GENERIC_DAY	1	2	2010-01-18	1722	\N	19899	\N
24638	GENERIC_DAY	1	3	2010-01-05	1718	\N	19899	\N
24655	GENERIC_DAY	1	0	2010-01-10	1718	\N	19899	\N
24733	GENERIC_DAY	1	2	2010-01-29	1722	\N	19899	\N
24702	GENERIC_DAY	1	2	2010-02-10	1726	\N	19899	\N
24689	GENERIC_DAY	1	2	2010-02-09	1726	\N	19899	\N
24711	GENERIC_DAY	1	2	2010-01-07	1718	\N	19899	\N
24614	GENERIC_DAY	1	2	2010-02-04	1722	\N	19899	\N
24609	GENERIC_DAY	1	2	2010-01-08	1718	\N	19899	\N
24690	GENERIC_DAY	1	3	2009-12-31	1718	\N	19899	\N
24611	GENERIC_DAY	1	2	2009-12-21	1726	\N	19899	\N
24632	GENERIC_DAY	1	0	2010-01-02	1726	\N	19899	\N
24687	GENERIC_DAY	1	0	2010-01-24	1718	\N	19899	\N
24654	GENERIC_DAY	1	0	2009-12-26	1726	\N	19899	\N
24619	GENERIC_DAY	1	0	2010-01-16	1726	\N	19899	\N
24716	GENERIC_DAY	1	0	2010-01-09	1722	\N	19899	\N
24642	GENERIC_DAY	1	0	2009-12-26	1718	\N	19899	\N
24736	GENERIC_DAY	1	2	2010-01-20	1718	\N	19899	\N
24653	GENERIC_DAY	1	2	2009-12-30	1722	\N	19899	\N
24628	GENERIC_DAY	1	0	2010-01-03	1718	\N	19899	\N
24652	GENERIC_DAY	1	2	2010-02-09	1722	\N	19899	\N
24666	GENERIC_DAY	1	2	2010-01-04	1722	\N	19899	\N
24741	GENERIC_DAY	1	0	2010-01-17	1726	\N	19899	\N
24686	GENERIC_DAY	1	2	2010-01-26	1726	\N	19899	\N
24738	GENERIC_DAY	1	2	2010-02-04	1726	\N	19899	\N
24615	GENERIC_DAY	1	2	2010-01-26	1722	\N	19899	\N
24723	GENERIC_DAY	1	0	2010-01-09	1726	\N	19899	\N
24657	GENERIC_DAY	1	2	2010-01-15	1718	\N	19899	\N
24608	GENERIC_DAY	1	2	2010-01-14	1718	\N	19899	\N
24665	GENERIC_DAY	1	0	2009-12-19	1726	\N	19899	\N
24648	GENERIC_DAY	1	2	2010-02-01	1726	\N	19899	\N
24721	GENERIC_DAY	1	0	2010-01-30	1726	\N	19899	\N
24635	GENERIC_DAY	1	3	2009-12-18	1718	\N	19899	\N
24717	GENERIC_DAY	1	0	2010-01-24	1722	\N	19899	\N
24673	GENERIC_DAY	1	3	2009-12-21	1718	\N	19899	\N
24600	GENERIC_DAY	1	2	2010-01-28	1718	\N	19899	\N
24735	GENERIC_DAY	1	0	2009-12-27	1718	\N	19899	\N
24643	GENERIC_DAY	1	0	2010-01-31	1726	\N	19899	\N
24682	GENERIC_DAY	1	0	2010-02-07	1718	\N	19899	\N
24704	GENERIC_DAY	1	3	2010-01-18	1726	\N	19899	\N
24625	GENERIC_DAY	1	2	2010-01-06	1718	\N	19899	\N
24616	GENERIC_DAY	1	2	2009-12-31	1726	\N	19899	\N
24613	GENERIC_DAY	1	3	2010-01-15	1726	\N	19899	\N
24661	GENERIC_DAY	1	2	2010-01-21	1722	\N	19899	\N
24688	GENERIC_DAY	1	3	2009-12-28	1718	\N	19899	\N
24633	GENERIC_DAY	1	3	2009-12-23	1718	\N	19899	\N
24667	GENERIC_DAY	1	2	2010-02-11	1726	\N	19899	\N
24669	GENERIC_DAY	1	0	2010-02-07	1722	\N	19899	\N
24617	GENERIC_DAY	1	2	2010-01-11	1718	\N	19899	\N
24664	GENERIC_DAY	1	2	2010-01-21	1718	\N	19899	\N
24677	GENERIC_DAY	1	2	2010-01-20	1722	\N	19899	\N
24605	GENERIC_DAY	1	0	2010-01-01	1722	\N	19899	\N
24629	GENERIC_DAY	1	2	2009-12-24	1726	\N	19899	\N
24731	GENERIC_DAY	1	2	2010-01-07	1722	\N	19899	\N
24681	GENERIC_DAY	1	2	2010-02-08	1726	\N	19899	\N
24674	GENERIC_DAY	1	0	2010-01-31	1718	\N	19899	\N
24715	GENERIC_DAY	1	3	2009-12-29	1718	\N	19899	\N
24724	GENERIC_DAY	1	0	2009-12-25	1726	\N	19899	\N
24739	GENERIC_DAY	1	2	2010-01-26	1718	\N	19899	\N
24612	GENERIC_DAY	1	3	2009-12-30	1718	\N	19899	\N
24636	GENERIC_DAY	1	2	2010-01-25	1722	\N	19899	\N
24725	GENERIC_DAY	1	2	2010-02-08	1718	\N	19899	\N
24679	GENERIC_DAY	1	0	2009-12-19	1722	\N	19899	\N
24662	GENERIC_DAY	1	0	2010-01-02	1718	\N	19899	\N
24683	GENERIC_DAY	1	0	2010-02-06	1718	\N	19899	\N
24626	GENERIC_DAY	1	2	2010-01-27	1722	\N	19899	\N
24645	GENERIC_DAY	1	0	2010-02-06	1722	\N	19899	\N
24640	GENERIC_DAY	1	2	2010-02-11	1722	\N	19899	\N
24604	GENERIC_DAY	1	0	2010-01-09	1718	\N	19899	\N
24710	GENERIC_DAY	1	0	2010-01-23	1726	\N	19899	\N
24610	GENERIC_DAY	1	3	2010-01-04	1718	\N	19899	\N
24728	GENERIC_DAY	1	2	2010-01-04	1726	\N	19899	\N
24634	GENERIC_DAY	1	2	2010-01-22	1718	\N	19899	\N
24700	GENERIC_DAY	1	2	2010-02-05	1718	\N	19899	\N
24729	GENERIC_DAY	1	2	2010-01-08	1722	\N	19899	\N
24650	GENERIC_DAY	1	2	2010-01-12	1722	\N	19899	\N
24646	GENERIC_DAY	1	3	2010-01-11	1726	\N	19899	\N
24706	GENERIC_DAY	1	2	2010-02-04	1718	\N	19899	\N
24701	GENERIC_DAY	1	2	2010-01-12	1718	\N	19899	\N
24599	GENERIC_DAY	1	2	2009-12-22	1722	\N	19899	\N
24727	GENERIC_DAY	1	2	2010-02-03	1718	\N	19899	\N
24606	GENERIC_DAY	1	2	2010-01-14	1722	\N	19899	\N
24712	GENERIC_DAY	1	2	2009-12-31	1722	\N	19899	\N
24707	GENERIC_DAY	1	2	2010-02-05	1722	\N	19899	\N
24696	GENERIC_DAY	1	2	2009-12-29	1722	\N	19899	\N
24607	GENERIC_DAY	1	0	2010-01-02	1722	\N	19899	\N
24740	GENERIC_DAY	1	0	2009-12-20	1726	\N	19899	\N
24601	GENERIC_DAY	1	2	2010-01-25	1726	\N	19899	\N
24620	GENERIC_DAY	1	2	2010-01-28	1726	\N	19899	\N
24637	GENERIC_DAY	1	3	2010-01-14	1726	\N	19899	\N
24680	GENERIC_DAY	1	2	2010-02-03	1726	\N	19899	\N
24623	GENERIC_DAY	1	0	2009-12-25	1722	\N	19899	\N
24659	GENERIC_DAY	1	2	2009-12-21	1722	\N	19899	\N
24719	GENERIC_DAY	1	2	2010-02-01	1722	\N	19899	\N
24703	GENERIC_DAY	1	2	2010-02-08	1722	\N	19899	\N
24624	GENERIC_DAY	1	0	2010-01-23	1722	\N	19899	\N
24678	GENERIC_DAY	1	2	2009-12-28	1722	\N	19899	\N
24720	GENERIC_DAY	1	2	2010-01-21	1726	\N	19899	\N
24705	GENERIC_DAY	1	0	2010-01-01	1718	\N	19899	\N
24668	GENERIC_DAY	1	2	2010-01-22	1726	\N	19899	\N
24675	GENERIC_DAY	1	2	2010-02-10	1722	\N	19899	\N
24709	GENERIC_DAY	1	0	2010-01-23	1718	\N	19899	\N
24676	GENERIC_DAY	1	2	2010-01-19	1718	\N	19899	\N
24714	GENERIC_DAY	1	2	2010-01-19	1722	\N	19899	\N
24627	GENERIC_DAY	1	2	2010-01-28	1722	\N	19899	\N
24651	GENERIC_DAY	1	2	2010-01-29	1726	\N	19899	\N
24622	GENERIC_DAY	1	0	2009-12-25	1718	\N	19899	\N
24631	GENERIC_DAY	1	2	2010-02-01	1718	\N	19899	\N
24713	GENERIC_DAY	1	0	2010-01-17	1718	\N	19899	\N
24685	GENERIC_DAY	1	0	2009-12-19	1718	\N	19899	\N
24658	GENERIC_DAY	1	2	2009-12-23	1726	\N	19899	\N
24671	GENERIC_DAY	1	0	2010-02-06	1726	\N	19899	\N
24670	GENERIC_DAY	1	3	2010-01-20	1726	\N	19899	\N
24787	GENERIC_DAY	1	1	2010-03-01	1722	\N	19897	\N
24820	GENERIC_DAY	1	4	2010-02-23	1718	\N	19897	\N
24884	GENERIC_DAY	1	0	2010-03-14	1722	\N	19897	\N
24869	GENERIC_DAY	1	2	2010-03-23	1722	\N	19897	\N
24817	GENERIC_DAY	1	0	2010-02-28	1722	\N	19897	\N
24826	GENERIC_DAY	1	0	2010-03-07	1726	\N	19897	\N
24776	GENERIC_DAY	1	2	2010-03-24	1722	\N	19897	\N
24844	GENERIC_DAY	1	3	2010-03-18	1718	\N	19897	\N
24852	GENERIC_DAY	1	0	2010-03-13	1722	\N	19897	\N
24785	GENERIC_DAY	1	2	2010-03-05	1722	\N	19897	\N
24854	GENERIC_DAY	1	3	2010-02-22	1726	\N	19897	\N
24789	GENERIC_DAY	1	0	2010-02-14	1722	\N	19897	\N
24876	GENERIC_DAY	1	1	2010-02-19	1722	\N	19897	\N
24804	GENERIC_DAY	1	0	2010-03-07	1718	\N	19897	\N
24821	GENERIC_DAY	1	0	2010-03-28	1722	\N	19897	\N
24790	GENERIC_DAY	1	0	2010-02-13	1722	\N	19897	\N
24793	GENERIC_DAY	1	0	2010-03-06	1722	\N	19897	\N
24846	GENERIC_DAY	1	0	2010-02-28	1718	\N	19897	\N
24881	GENERIC_DAY	1	0	2010-02-28	1726	\N	19897	\N
24836	GENERIC_DAY	1	2	2010-03-08	1722	\N	19897	\N
24808	GENERIC_DAY	1	0	2010-03-27	1718	\N	19897	\N
24875	GENERIC_DAY	1	0	2010-03-28	1726	\N	19897	\N
24889	GENERIC_DAY	1	3	2010-03-10	1718	\N	19897	\N
39365	GENERIC_DAY	3	0	2010-02-13	36159	\N	38596	\N
39364	GENERIC_DAY	3	0	2010-02-06	37573	\N	38596	\N
39375	GENERIC_DAY	3	1	2010-02-09	36159	\N	38596	\N
39369	GENERIC_DAY	3	0	2010-02-16	37573	\N	38596	\N
39360	GENERIC_DAY	3	0	2010-02-14	36159	\N	38596	\N
39362	GENERIC_DAY	3	0	2010-02-15	36159	\N	38596	\N
39374	GENERIC_DAY	3	0	2010-02-15	37573	\N	38596	\N
39363	GENERIC_DAY	3	0	2010-02-12	37573	\N	38596	\N
39372	GENERIC_DAY	3	0	2010-02-06	36159	\N	38596	\N
39367	GENERIC_DAY	3	0	2010-01-24	37573	\N	38596	\N
39358	GENERIC_DAY	3	0	2010-02-07	36159	\N	38596	\N
39357	GENERIC_DAY	3	1	2010-01-28	37573	\N	38596	\N
39373	GENERIC_DAY	3	0	2010-02-08	37573	\N	38596	\N
39356	GENERIC_DAY	3	0	2010-02-17	37573	\N	38596	\N
39371	GENERIC_DAY	3	0	2010-02-05	37573	\N	38596	\N
39370	GENERIC_DAY	3	0	2010-02-03	37573	\N	38596	\N
39361	GENERIC_DAY	3	0	2010-01-29	36159	\N	38596	\N
39359	GENERIC_DAY	3	0	2010-01-22	37573	\N	38596	\N
39366	GENERIC_DAY	3	0	2010-02-14	37573	\N	38596	\N
39368	GENERIC_DAY	3	0	2010-01-26	37573	\N	38596	\N
39376	GENERIC_DAY	3	0	2010-01-27	36159	\N	38596	\N
39354	GENERIC_DAY	3	4	2010-03-16	37573	\N	38595	\N
39355	GENERIC_DAY	3	3	2010-03-16	36159	\N	38595	\N
31194	GENERIC_DAY	1	0	2010-02-28	1724	\N	28093	\N
31169	GENERIC_DAY	1	8	2010-03-09	1724	\N	28093	\N
31167	GENERIC_DAY	1	8	2010-02-01	1724	\N	28093	\N
31229	GENERIC_DAY	1	0	2010-03-27	1724	\N	28093	\N
31207	GENERIC_DAY	1	8	2010-03-29	1724	\N	28093	\N
31221	GENERIC_DAY	1	8	2010-03-04	1724	\N	28093	\N
31217	GENERIC_DAY	1	8	2010-03-08	1724	\N	28093	\N
31185	GENERIC_DAY	1	9	2010-01-22	1724	\N	28093	\N
31175	GENERIC_DAY	1	9	2010-01-18	1724	\N	28093	\N
31189	GENERIC_DAY	1	8	2010-03-17	1724	\N	28093	\N
31163	GENERIC_DAY	1	8	2010-04-09	1724	\N	28093	\N
39385	GENERIC_DAY	3	0	2010-02-17	36159	\N	38596	\N
39398	GENERIC_DAY	3	0	2010-01-24	36159	\N	38596	\N
39381	GENERIC_DAY	3	0	2010-02-11	37573	\N	38596	\N
39409	GENERIC_DAY	3	1	2010-02-03	36159	\N	38596	\N
39397	GENERIC_DAY	3	0	2010-01-25	37573	\N	38596	\N
39404	GENERIC_DAY	3	1	2010-02-04	36159	\N	38596	\N
39379	GENERIC_DAY	3	0	2010-01-30	36159	\N	38596	\N
39383	GENERIC_DAY	3	1	2010-01-29	37573	\N	38596	\N
39380	GENERIC_DAY	3	0	2010-02-10	37573	\N	38596	\N
39405	GENERIC_DAY	3	1	2010-01-26	36159	\N	38596	\N
39401	GENERIC_DAY	3	1	2010-01-27	37573	\N	38596	\N
39378	GENERIC_DAY	3	0	2010-02-13	37573	\N	38596	\N
39392	GENERIC_DAY	3	0	2010-02-02	37573	\N	38596	\N
39400	GENERIC_DAY	3	1	2010-01-22	36159	\N	38596	\N
39386	GENERIC_DAY	3	1	2010-01-25	36159	\N	38596	\N
39388	GENERIC_DAY	3	1	2010-02-05	36159	\N	38596	\N
39399	GENERIC_DAY	3	0	2010-01-31	36159	\N	38596	\N
39394	GENERIC_DAY	3	1	2010-02-12	36159	\N	38596	\N
39387	GENERIC_DAY	3	1	2010-02-08	36159	\N	38596	\N
39391	GENERIC_DAY	3	0	2010-02-16	36159	\N	38596	\N
39377	GENERIC_DAY	3	0	2010-01-28	36159	\N	38596	\N
39403	GENERIC_DAY	3	0	2010-01-23	37573	\N	38596	\N
39384	GENERIC_DAY	3	0	2010-02-04	37573	\N	38596	\N
39407	GENERIC_DAY	3	1	2010-02-01	37573	\N	38596	\N
39395	GENERIC_DAY	3	0	2010-01-30	37573	\N	38596	\N
39402	GENERIC_DAY	3	0	2010-02-07	37573	\N	38596	\N
39393	GENERIC_DAY	3	1	2010-02-11	36159	\N	38596	\N
39396	GENERIC_DAY	3	1	2010-02-10	36159	\N	38596	\N
39390	GENERIC_DAY	3	1	2010-02-02	36159	\N	38596	\N
39406	GENERIC_DAY	3	0	2010-01-31	37573	\N	38596	\N
39389	GENERIC_DAY	3	0	2010-02-09	37573	\N	38596	\N
39408	GENERIC_DAY	3	0	2010-02-01	36159	\N	38596	\N
39382	GENERIC_DAY	3	0	2010-01-23	36159	\N	38596	\N
39410	GENERIC_DAY	3	3	2010-02-18	37573	\N	38597	\N
39411	GENERIC_DAY	3	4	2010-02-18	36159	\N	38597	\N
39414	GENERIC_DAY	3	4	2010-03-17	36159	\N	38598	\N
39412	GENERIC_DAY	3	3	2010-03-18	36159	\N	38598	\N
39413	GENERIC_DAY	3	4	2010-03-17	37573	\N	38598	\N
39415	GENERIC_DAY	3	3	2010-03-18	37573	\N	38598	\N
41319	GENERIC_DAY	18	2	2010-01-12	36159	\N	41014	\N
41325	GENERIC_DAY	18	2	2010-01-11	37573	\N	41014	\N
41320	GENERIC_DAY	18	2	2010-01-11	36159	\N	41014	\N
41321	GENERIC_DAY	18	2	2010-01-12	40199	\N	41014	\N
41323	GENERIC_DAY	18	1	2010-01-13	36159	\N	41014	\N
41324	GENERIC_DAY	18	2	2010-01-12	37573	\N	41014	\N
41322	GENERIC_DAY	18	0	2010-01-13	40199	\N	41014	\N
41318	GENERIC_DAY	18	1	2010-01-13	37573	\N	41014	\N
41317	GENERIC_DAY	18	2	2010-01-11	40199	\N	41014	\N
45744	GENERIC_DAY	6	0	2010-02-03	40199	\N	41069	\N
45748	GENERIC_DAY	6	0	2010-02-01	40199	\N	41069	\N
45728	GENERIC_DAY	6	0	2010-01-15	36159	\N	41069	\N
45727	GENERIC_DAY	6	0	2010-02-04	40199	\N	41069	\N
45735	GENERIC_DAY	6	1	2010-01-12	37573	\N	41069	\N
45738	GENERIC_DAY	6	0	2010-01-13	40199	\N	41069	\N
27496	GENERIC_DAY	1	8	2009-12-31	1724	\N	3953	\N
39428	GENERIC_DAY	2	0	2010-03-21	37573	\N	38600	\N
39429	GENERIC_DAY	2	2	2010-03-22	37573	\N	38600	\N
39430	GENERIC_DAY	2	1	2010-03-24	36159	\N	38600	\N
39431	GENERIC_DAY	2	0	2010-03-20	36159	\N	38600	\N
24778	GENERIC_DAY	1	0	2010-03-14	1726	\N	19897	\N
24883	GENERIC_DAY	1	3	2010-03-05	1718	\N	19897	\N
24860	GENERIC_DAY	1	4	2010-02-17	1726	\N	19897	\N
24801	GENERIC_DAY	1	3	2010-02-16	1718	\N	19897	\N
24822	GENERIC_DAY	1	3	2010-03-08	1726	\N	19897	\N
24772	GENERIC_DAY	1	2	2010-03-25	1726	\N	19897	\N
24887	GENERIC_DAY	1	4	2010-02-25	1718	\N	19897	\N
24807	GENERIC_DAY	1	4	2010-02-16	1726	\N	19897	\N
24786	GENERIC_DAY	1	4	2010-02-26	1718	\N	19897	\N
24857	GENERIC_DAY	1	4	2010-02-24	1718	\N	19897	\N
24855	GENERIC_DAY	1	1	2010-02-24	1722	\N	19897	\N
24834	GENERIC_DAY	1	2	2010-03-16	1722	\N	19897	\N
24788	GENERIC_DAY	1	0	2010-02-27	1718	\N	19897	\N
24864	GENERIC_DAY	1	3	2010-03-09	1718	\N	19897	\N
24851	GENERIC_DAY	1	3	2010-03-08	1718	\N	19897	\N
24850	GENERIC_DAY	1	2	2010-03-26	1726	\N	19897	\N
24880	GENERIC_DAY	1	1	2010-02-12	1722	\N	19897	\N
39432	GENERIC_DAY	2	2	2010-03-24	37573	\N	38600	\N
39433	GENERIC_DAY	2	2	2010-03-19	36159	\N	38600	\N
39434	GENERIC_DAY	2	0	2010-03-20	37573	\N	38600	\N
39435	GENERIC_DAY	2	2	2010-03-22	36159	\N	38600	\N
39436	GENERIC_DAY	2	0	2010-03-21	36159	\N	38600	\N
39437	GENERIC_DAY	2	2	2010-03-23	37573	\N	38600	\N
39438	GENERIC_DAY	2	1	2010-03-23	36159	\N	38600	\N
24870	GENERIC_DAY	1	0	2010-02-20	1722	\N	19897	\N
24856	GENERIC_DAY	1	2	2010-03-24	1726	\N	19897	\N
24879	GENERIC_DAY	1	2	2010-03-12	1722	\N	19897	\N
24841	GENERIC_DAY	1	3	2010-03-03	1726	\N	19897	\N
24866	GENERIC_DAY	1	3	2010-03-17	1718	\N	19897	\N
24799	GENERIC_DAY	1	4	2010-03-26	1718	\N	19897	\N
24828	GENERIC_DAY	1	2	2010-03-29	1718	\N	19897	\N
24837	GENERIC_DAY	1	1	2010-03-03	1722	\N	19897	\N
24796	GENERIC_DAY	1	3	2010-02-17	1718	\N	19897	\N
24775	GENERIC_DAY	1	2	2010-03-19	1726	\N	19897	\N
24871	GENERIC_DAY	1	2	2010-03-11	1722	\N	19897	\N
24865	GENERIC_DAY	1	0	2010-03-20	1726	\N	19897	\N
24867	GENERIC_DAY	1	3	2010-02-23	1726	\N	19897	\N
24814	GENERIC_DAY	1	3	2010-03-11	1718	\N	19897	\N
24842	GENERIC_DAY	1	2	2010-03-23	1726	\N	19897	\N
24812	GENERIC_DAY	1	4	2010-03-02	1718	\N	19897	\N
24795	GENERIC_DAY	1	3	2010-03-12	1726	\N	19897	\N
24774	GENERIC_DAY	1	2	2010-03-22	1726	\N	19897	\N
24833	GENERIC_DAY	1	1	2010-03-02	1722	\N	19897	\N
24862	GENERIC_DAY	1	3	2010-02-18	1718	\N	19897	\N
24802	GENERIC_DAY	1	3	2010-03-16	1718	\N	19897	\N
24845	GENERIC_DAY	1	2	2010-03-17	1722	\N	19897	\N
24872	GENERIC_DAY	1	0	2010-02-13	1726	\N	19897	\N
24783	GENERIC_DAY	1	0	2010-03-27	1722	\N	19897	\N
24800	GENERIC_DAY	1	4	2010-02-18	1726	\N	19897	\N
24838	GENERIC_DAY	1	4	2010-02-12	1718	\N	19897	\N
24868	GENERIC_DAY	1	3	2010-02-25	1726	\N	19897	\N
24859	GENERIC_DAY	1	0	2010-03-29	1722	\N	19897	\N
24831	GENERIC_DAY	1	3	2010-03-04	1726	\N	19897	\N
24847	GENERIC_DAY	1	4	2010-02-15	1726	\N	19897	\N
24886	GENERIC_DAY	1	0	2010-03-07	1722	\N	19897	\N
24813	GENERIC_DAY	1	3	2010-03-04	1718	\N	19897	\N
24810	GENERIC_DAY	1	0	2010-02-21	1726	\N	19897	\N
24861	GENERIC_DAY	1	2	2010-03-04	1722	\N	19897	\N
24791	GENERIC_DAY	1	3	2010-03-11	1726	\N	19897	\N
24777	GENERIC_DAY	1	3	2010-03-10	1726	\N	19897	\N
24792	GENERIC_DAY	1	0	2010-03-06	1718	\N	19897	\N
24874	GENERIC_DAY	1	1	2010-02-16	1722	\N	19897	\N
24770	GENERIC_DAY	1	0	2010-03-13	1718	\N	19897	\N
24848	GENERIC_DAY	1	2	2010-03-26	1722	\N	19897	\N
24849	GENERIC_DAY	1	3	2010-03-18	1722	\N	19897	\N
24882	GENERIC_DAY	1	3	2010-03-17	1726	\N	19897	\N
24782	GENERIC_DAY	1	0	2010-02-27	1726	\N	19897	\N
24767	GENERIC_DAY	1	3	2010-02-12	1726	\N	19897	\N
24835	GENERIC_DAY	1	0	2010-03-28	1718	\N	19897	\N
24769	GENERIC_DAY	1	2	2010-03-22	1722	\N	19897	\N
24773	GENERIC_DAY	1	3	2010-03-05	1726	\N	19897	\N
45732	GENERIC_DAY	6	0	2010-01-27	36159	\N	41069	\N
45731	GENERIC_DAY	6	0	2010-02-04	36159	\N	41069	\N
45736	GENERIC_DAY	6	0	2010-01-26	36159	\N	41069	\N
45743	GENERIC_DAY	6	1	2010-01-26	40199	\N	41069	\N
45729	GENERIC_DAY	6	0	2010-01-19	40199	\N	41069	\N
45734	GENERIC_DAY	6	1	2010-01-25	40199	\N	41069	\N
45750	GENERIC_DAY	6	0	2010-01-18	36159	\N	41069	\N
45745	GENERIC_DAY	6	0	2010-01-31	40199	\N	41069	\N
24839	GENERIC_DAY	1	4	2010-03-01	1718	\N	19897	\N
24768	GENERIC_DAY	1	4	2010-02-22	1718	\N	19897	\N
24781	GENERIC_DAY	1	1	2010-02-18	1722	\N	19897	\N
24823	GENERIC_DAY	1	4	2010-03-23	1718	\N	19897	\N
24843	GENERIC_DAY	1	1	2010-02-17	1722	\N	19897	\N
24811	GENERIC_DAY	1	3	2010-02-26	1726	\N	19897	\N
24829	GENERIC_DAY	1	3	2010-03-12	1718	\N	19897	\N
24873	GENERIC_DAY	1	3	2010-03-01	1726	\N	19897	\N
45822	GENERIC_DAY	6	1	2010-01-18	37573	\N	41069	\N
45749	GENERIC_DAY	6	0	2010-01-16	36159	\N	41069	\N
45746	GENERIC_DAY	6	0	2010-01-19	37573	\N	41069	\N
45740	GENERIC_DAY	6	0	2010-02-06	36159	\N	41069	\N
45820	GENERIC_DAY	6	0	2010-02-10	40199	\N	41069	\N
39439	GENERIC_DAY	2	2	2010-03-19	37573	\N	38600	\N
45741	GENERIC_DAY	6	0	2010-01-28	40199	\N	41069	\N
45730	GENERIC_DAY	6	0	2010-01-22	37573	\N	41069	\N
45742	GENERIC_DAY	6	0	2010-02-07	36159	\N	41069	\N
45737	GENERIC_DAY	6	0	2010-01-29	37573	\N	41069	\N
45739	GENERIC_DAY	6	0	2010-02-09	36159	\N	41069	\N
45733	GENERIC_DAY	6	0	2010-01-21	40199	\N	41069	\N
45819	GENERIC_DAY	6	0	2010-02-03	36159	\N	41069	\N
45747	GENERIC_DAY	6	0	2010-02-04	37573	\N	41069	\N
45821	GENERIC_DAY	6	0	2010-01-12	36159	\N	41069	\N
43093	GENERIC_DAY	10	0	2010-01-24	37573	\N	41054	\N
43065	GENERIC_DAY	10	0	2010-02-11	37573	\N	41054	\N
43099	GENERIC_DAY	10	0	2010-01-12	40199	\N	41054	\N
43064	GENERIC_DAY	10	1	2010-02-03	40199	\N	41054	\N
43058	GENERIC_DAY	10	0	2010-01-11	37573	\N	41054	\N
43103	GENERIC_DAY	10	1	2010-01-12	36159	\N	41054	\N
43091	GENERIC_DAY	10	0	2010-02-10	37573	\N	41054	\N
43029	GENERIC_DAY	10	0	2010-02-08	37573	\N	41054	\N
43073	GENERIC_DAY	10	0	2010-01-21	36159	\N	41054	\N
43039	GENERIC_DAY	10	0	2010-01-19	36159	\N	41054	\N
43101	GENERIC_DAY	10	1	2010-01-26	36159	\N	41054	\N
43098	GENERIC_DAY	10	0	2010-01-31	40199	\N	41054	\N
43092	GENERIC_DAY	10	0	2010-01-17	36159	\N	41054	\N
43100	GENERIC_DAY	10	0	2010-01-20	36159	\N	41054	\N
24830	GENERIC_DAY	1	2	2010-03-15	1722	\N	19897	\N
24780	GENERIC_DAY	1	0	2010-02-13	1718	\N	19897	\N
24806	GENERIC_DAY	1	0	2010-03-14	1718	\N	19897	\N
24818	GENERIC_DAY	1	0	2010-03-06	1726	\N	19897	\N
24825	GENERIC_DAY	1	2	2010-03-18	1726	\N	19897	\N
24858	GENERIC_DAY	1	0	2010-02-20	1726	\N	19897	\N
24878	GENERIC_DAY	1	0	2010-03-27	1726	\N	19897	\N
24779	GENERIC_DAY	1	3	2010-02-19	1726	\N	19897	\N
24798	GENERIC_DAY	1	4	2010-03-19	1718	\N	19897	\N
24877	GENERIC_DAY	1	0	2010-02-14	1726	\N	19897	\N
24797	GENERIC_DAY	1	4	2010-03-22	1718	\N	19897	\N
24809	GENERIC_DAY	1	1	2010-02-22	1722	\N	19897	\N
24827	GENERIC_DAY	1	2	2010-03-25	1722	\N	19897	\N
24853	GENERIC_DAY	1	3	2010-02-15	1718	\N	19897	\N
24815	GENERIC_DAY	1	0	2010-02-27	1722	\N	19897	\N
24832	GENERIC_DAY	1	1	2010-02-23	1722	\N	19897	\N
24784	GENERIC_DAY	1	0	2010-03-29	1726	\N	19897	\N
24794	GENERIC_DAY	1	3	2010-03-15	1718	\N	19897	\N
24819	GENERIC_DAY	1	2	2010-03-19	1722	\N	19897	\N
24771	GENERIC_DAY	1	0	2010-03-20	1718	\N	19897	\N
24824	GENERIC_DAY	1	3	2010-03-02	1726	\N	19897	\N
24885	GENERIC_DAY	1	0	2010-02-21	1722	\N	19897	\N
24803	GENERIC_DAY	1	1	2010-02-25	1722	\N	19897	\N
24888	GENERIC_DAY	1	3	2010-03-09	1726	\N	19897	\N
24840	GENERIC_DAY	1	0	2010-02-20	1718	\N	19897	\N
24805	GENERIC_DAY	1	4	2010-03-03	1718	\N	19897	\N
24816	GENERIC_DAY	1	3	2010-03-15	1726	\N	19897	\N
24863	GENERIC_DAY	1	1	2010-02-15	1722	\N	19897	\N
24410	GENERIC_DAY	4	10	2009-12-04	1727	\N	3955	\N
24469	GENERIC_DAY	4	10	2009-11-16	1727	\N	3955	\N
24440	GENERIC_DAY	4	10	2010-01-06	1727	\N	3955	\N
24428	GENERIC_DAY	4	2	2010-01-23	1727	\N	3955	\N
24434	GENERIC_DAY	4	10	2010-01-07	1727	\N	3955	\N
24413	GENERIC_DAY	4	2	2009-12-19	1727	\N	3955	\N
24427	GENERIC_DAY	4	2	2009-12-20	1727	\N	3955	\N
24441	GENERIC_DAY	4	10	2009-11-17	1727	\N	3955	\N
24476	GENERIC_DAY	4	10	2010-02-12	1727	\N	3955	\N
24423	GENERIC_DAY	4	2	2010-02-06	1727	\N	3955	\N
24397	GENERIC_DAY	4	2	2010-01-02	1727	\N	3955	\N
24417	GENERIC_DAY	4	10	2009-12-31	1727	\N	3955	\N
24408	GENERIC_DAY	4	10	2009-11-05	1727	\N	3955	\N
24481	GENERIC_DAY	4	2	2009-12-05	1727	\N	3955	\N
24399	GENERIC_DAY	4	10	2010-01-20	1727	\N	3955	\N
24424	GENERIC_DAY	4	2	2010-02-20	1727	\N	3955	\N
24400	GENERIC_DAY	4	2	2010-01-31	1727	\N	3955	\N
24450	GENERIC_DAY	4	2	2010-01-09	1727	\N	3955	\N
24439	GENERIC_DAY	4	10	2010-01-05	1727	\N	3955	\N
24412	GENERIC_DAY	4	10	2009-11-20	1727	\N	3955	\N
43079	GENERIC_DAY	10	0	2010-01-25	36159	\N	41054	\N
24447	GENERIC_DAY	4	10	2010-02-10	1727	\N	3955	\N
24471	GENERIC_DAY	4	10	2010-02-08	1727	\N	3955	\N
24465	GENERIC_DAY	4	10	2009-11-18	1727	\N	3955	\N
24478	GENERIC_DAY	4	10	2009-12-07	1727	\N	3955	\N
24404	GENERIC_DAY	4	10	2009-11-11	1727	\N	3955	\N
24420	GENERIC_DAY	4	10	2009-11-10	1727	\N	3955	\N
24442	GENERIC_DAY	4	10	2010-01-21	1727	\N	3955	\N
24396	GENERIC_DAY	4	10	2009-11-30	1727	\N	3955	\N
24426	GENERIC_DAY	4	10	2009-12-23	1727	\N	3955	\N
24483	GENERIC_DAY	4	2	2009-12-13	1727	\N	3955	\N
24491	GENERIC_DAY	4	10	2010-01-22	1727	\N	3955	\N
24458	GENERIC_DAY	4	2	2009-11-14	1727	\N	3955	\N
24401	GENERIC_DAY	4	2	2009-11-15	1727	\N	3955	\N
24486	GENERIC_DAY	4	10	2009-11-09	1727	\N	3955	\N
24405	GENERIC_DAY	4	2	2009-11-22	1727	\N	3955	\N
24429	GENERIC_DAY	4	2	2009-12-26	1727	\N	3955	\N
24411	GENERIC_DAY	4	10	2009-12-21	1727	\N	3955	\N
24489	GENERIC_DAY	4	10	2009-12-01	1727	\N	3955	\N
24456	GENERIC_DAY	4	10	2010-02-05	1727	\N	3955	\N
24472	GENERIC_DAY	4	2	2010-01-10	1727	\N	3955	\N
24436	GENERIC_DAY	4	10	2009-12-28	1727	\N	3955	\N
24437	GENERIC_DAY	4	10	2009-11-04	1727	\N	3955	\N
24416	GENERIC_DAY	4	10	2009-12-09	1727	\N	3955	\N
24467	GENERIC_DAY	4	10	2010-02-02	1727	\N	3955	\N
24477	GENERIC_DAY	4	10	2009-12-14	1727	\N	3955	\N
24453	GENERIC_DAY	4	10	2010-01-13	1727	\N	3955	\N
24402	GENERIC_DAY	4	2	2009-12-27	1727	\N	3955	\N
24480	GENERIC_DAY	4	10	2009-11-25	1727	\N	3955	\N
24485	GENERIC_DAY	4	2	2009-12-06	1727	\N	3955	\N
24418	GENERIC_DAY	4	10	2009-12-11	1727	\N	3955	\N
24484	GENERIC_DAY	4	10	2009-12-24	1727	\N	3955	\N
24457	GENERIC_DAY	4	10	2009-11-12	1727	\N	3955	\N
24433	GENERIC_DAY	4	2	2009-11-29	1727	\N	3955	\N
24438	GENERIC_DAY	4	10	2010-02-19	1727	\N	3955	\N
24487	GENERIC_DAY	4	2	2010-02-14	1727	\N	3955	\N
24414	GENERIC_DAY	4	10	2010-02-17	1727	\N	3955	\N
24461	GENERIC_DAY	4	2	2010-01-03	1727	\N	3955	\N
24492	GENERIC_DAY	4	10	2009-12-29	1727	\N	3955	\N
24459	GENERIC_DAY	4	10	2010-02-01	1727	\N	3955	\N
24398	GENERIC_DAY	4	10	2009-12-03	1727	\N	3955	\N
24475	GENERIC_DAY	4	2	2009-11-28	1727	\N	3955	\N
24455	GENERIC_DAY	4	10	2010-01-28	1727	\N	3955	\N
24466	GENERIC_DAY	4	10	2009-11-26	1727	\N	3955	\N
24446	GENERIC_DAY	4	10	2009-12-08	1727	\N	3955	\N
24468	GENERIC_DAY	4	10	2010-01-27	1727	\N	3955	\N
24452	GENERIC_DAY	4	10	2010-02-04	1727	\N	3955	\N
24419	GENERIC_DAY	4	10	2010-02-24	1727	\N	3955	\N
24460	GENERIC_DAY	4	2	2010-02-07	1727	\N	3955	\N
24479	GENERIC_DAY	4	10	2009-11-06	1727	\N	3955	\N
24443	GENERIC_DAY	4	10	2010-01-08	1727	\N	3955	\N
24490	GENERIC_DAY	4	10	2010-02-16	1727	\N	3955	\N
24454	GENERIC_DAY	4	10	2009-11-27	1727	\N	3955	\N
24488	GENERIC_DAY	4	10	2010-02-15	1727	\N	3955	\N
24435	GENERIC_DAY	4	10	2010-01-26	1727	\N	3955	\N
24445	GENERIC_DAY	4	2	2009-12-25	1727	\N	3955	\N
24506	GENERIC_DAY	4	10	2009-12-16	1727	\N	3955	\N
24482	GENERIC_DAY	4	10	2010-02-22	1727	\N	3955	\N
24403	GENERIC_DAY	4	10	2010-02-26	1727	\N	3955	\N
24470	GENERIC_DAY	4	2	2010-01-16	1727	\N	3955	\N
24432	GENERIC_DAY	4	10	2010-02-09	1727	\N	3955	\N
24430	GENERIC_DAY	4	2	2009-11-08	1727	\N	3955	\N
24409	GENERIC_DAY	4	10	2010-02-18	1727	\N	3955	\N
24495	GENERIC_DAY	4	10	2010-01-15	1727	\N	3955	\N
24444	GENERIC_DAY	4	10	2009-12-30	1727	\N	3955	\N
24449	GENERIC_DAY	4	10	2009-11-23	1727	\N	3955	\N
24422	GENERIC_DAY	4	10	2010-02-03	1727	\N	3955	\N
24407	GENERIC_DAY	4	2	2010-01-30	1727	\N	3955	\N
24462	GENERIC_DAY	4	10	2010-02-23	1727	\N	3955	\N
24474	GENERIC_DAY	4	10	2010-02-25	1727	\N	3955	\N
24448	GENERIC_DAY	4	10	2009-12-02	1727	\N	3955	\N
24503	GENERIC_DAY	4	10	2009-12-22	1727	\N	3955	\N
24421	GENERIC_DAY	4	2	2010-01-17	1727	\N	3955	\N
24406	GENERIC_DAY	4	2	2010-02-13	1727	\N	3955	\N
24415	GENERIC_DAY	4	11	2009-11-02	1727	\N	3955	\N
24507	GENERIC_DAY	4	2	2010-02-21	1727	\N	3955	\N
24473	GENERIC_DAY	4	10	2009-11-13	1727	\N	3955	\N
24511	GENERIC_DAY	4	10	2010-01-12	1727	\N	3955	\N
24451	GENERIC_DAY	4	10	2009-11-24	1727	\N	3955	\N
24425	GENERIC_DAY	4	10	2010-01-04	1727	\N	3955	\N
24431	GENERIC_DAY	4	10	2009-12-18	1727	\N	3955	\N
24463	GENERIC_DAY	4	2	2010-01-24	1727	\N	3955	\N
24464	GENERIC_DAY	4	10	2010-01-29	1727	\N	3955	\N
43026	GENERIC_DAY	10	0	2010-02-09	37573	\N	41054	\N
43025	GENERIC_DAY	10	1	2010-01-15	37573	\N	41054	\N
43068	GENERIC_DAY	10	0	2010-01-13	37573	\N	41054	\N
43080	GENERIC_DAY	10	0	2010-02-07	37573	\N	41054	\N
43047	GENERIC_DAY	10	0	2010-01-14	40199	\N	41054	\N
43048	GENERIC_DAY	10	1	2010-01-29	40199	\N	41054	\N
43057	GENERIC_DAY	10	0	2010-01-15	40199	\N	41054	\N
43035	GENERIC_DAY	10	0	2010-02-01	40199	\N	41054	\N
43049	GENERIC_DAY	10	0	2010-01-18	40199	\N	41054	\N
43094	GENERIC_DAY	10	0	2010-01-24	36159	\N	41054	\N
43041	GENERIC_DAY	10	0	2010-01-27	36159	\N	41054	\N
43069	GENERIC_DAY	10	0	2010-01-17	37573	\N	41054	\N
43056	GENERIC_DAY	10	0	2010-02-06	36159	\N	41054	\N
43033	GENERIC_DAY	10	0	2010-01-20	37573	\N	41054	\N
43028	GENERIC_DAY	10	1	2010-02-08	40199	\N	41054	\N
43071	GENERIC_DAY	10	0	2010-01-16	40199	\N	41054	\N
43046	GENERIC_DAY	10	0	2010-02-01	36159	\N	41054	\N
43095	GENERIC_DAY	10	0	2010-01-28	36159	\N	41054	\N
43081	GENERIC_DAY	10	0	2010-02-09	36159	\N	41054	\N
43042	GENERIC_DAY	10	0	2010-01-26	37573	\N	41054	\N
43036	GENERIC_DAY	10	1	2010-01-22	37573	\N	41054	\N
43043	GENERIC_DAY	10	0	2010-01-26	40199	\N	41054	\N
43076	GENERIC_DAY	10	1	2010-02-04	40199	\N	41054	\N
43040	GENERIC_DAY	10	1	2010-02-02	40199	\N	41054	\N
43022	GENERIC_DAY	10	0	2010-02-10	36159	\N	41054	\N
43032	GENERIC_DAY	10	0	2010-02-04	37573	\N	41054	\N
43084	GENERIC_DAY	10	0	2010-01-14	36159	\N	41054	\N
43075	GENERIC_DAY	10	0	2010-02-11	36159	\N	41054	\N
43030	GENERIC_DAY	10	0	2010-01-29	36159	\N	41054	\N
43045	GENERIC_DAY	10	0	2010-01-27	37573	\N	41054	\N
43110	GENERIC_DAY	10	0	2010-02-06	37573	\N	41054	\N
43112	GENERIC_DAY	10	0	2010-01-16	37573	\N	41054	\N
43070	GENERIC_DAY	10	0	2010-02-03	37573	\N	41054	\N
43114	GENERIC_DAY	10	0	2010-01-30	36159	\N	41054	\N
43021	GENERIC_DAY	10	0	2010-01-28	37573	\N	41054	\N
43105	GENERIC_DAY	10	1	2010-01-14	37573	\N	41054	\N
43051	GENERIC_DAY	10	0	2010-01-13	36159	\N	41054	\N
31156	GENERIC_DAY	1	8	2010-04-06	1724	\N	28093	\N
31158	GENERIC_DAY	1	0	2010-02-06	1724	\N	28093	\N
31149	GENERIC_DAY	1	0	2010-04-04	1724	\N	28093	\N
31152	GENERIC_DAY	1	8	2010-03-16	1724	\N	28093	\N
31151	GENERIC_DAY	1	9	2010-01-19	1724	\N	28093	\N
31157	GENERIC_DAY	1	8	2010-02-26	1724	\N	28093	\N
31219	GENERIC_DAY	1	8	2010-01-29	1724	\N	28093	\N
31161	GENERIC_DAY	1	8	2010-03-12	1724	\N	28093	\N
31187	GENERIC_DAY	1	8	2010-04-05	1724	\N	28093	\N
31193	GENERIC_DAY	1	9	2010-01-26	1724	\N	28093	\N
31177	GENERIC_DAY	1	0	2010-03-07	1724	\N	28093	\N
31154	GENERIC_DAY	1	8	2010-02-18	1724	\N	28093	\N
31211	GENERIC_DAY	1	8	2010-03-05	1724	\N	28093	\N
31199	GENERIC_DAY	1	0	2010-02-27	1724	\N	28093	\N
31230	GENERIC_DAY	1	8	2010-03-25	1724	\N	28093	\N
31214	GENERIC_DAY	1	0	2010-03-13	1724	\N	28093	\N
31223	GENERIC_DAY	1	8	2010-02-05	1724	\N	28093	\N
31206	GENERIC_DAY	1	8	2010-04-08	1724	\N	28093	\N
31200	GENERIC_DAY	1	8	2010-03-26	1724	\N	28093	\N
31208	GENERIC_DAY	1	0	2010-02-07	1724	\N	28093	\N
31226	GENERIC_DAY	1	0	2010-03-06	1724	\N	28093	\N
31180	GENERIC_DAY	1	9	2010-01-27	1724	\N	28093	\N
31168	GENERIC_DAY	1	8	2010-02-22	1724	\N	28093	\N
31160	GENERIC_DAY	1	1	2010-01-16	1724	\N	28093	\N
31203	GENERIC_DAY	1	8	2010-04-02	1724	\N	28093	\N
31174	GENERIC_DAY	1	8	2010-02-09	1724	\N	28093	\N
31188	GENERIC_DAY	1	8	2010-02-17	1724	\N	28093	\N
31150	GENERIC_DAY	1	8	2010-03-19	1724	\N	28093	\N
31186	GENERIC_DAY	1	1	2010-01-23	1724	\N	28093	\N
31213	GENERIC_DAY	1	8	2010-02-16	1724	\N	28093	\N
31227	GENERIC_DAY	1	8	2010-02-24	1724	\N	28093	\N
31184	GENERIC_DAY	1	8	2010-02-03	1724	\N	28093	\N
31179	GENERIC_DAY	1	8	2010-02-10	1724	\N	28093	\N
31176	GENERIC_DAY	1	0	2010-04-03	1724	\N	28093	\N
31183	GENERIC_DAY	1	8	2010-03-11	1724	\N	28093	\N
31148	GENERIC_DAY	1	9	2010-01-25	1724	\N	28093	\N
31166	GENERIC_DAY	1	8	2010-04-01	1724	\N	28093	\N
31155	GENERIC_DAY	1	0	2010-03-28	1724	\N	28093	\N
31192	GENERIC_DAY	1	0	2010-01-30	1724	\N	28093	\N
31201	GENERIC_DAY	1	8	2010-03-02	1724	\N	28093	\N
31220	GENERIC_DAY	1	8	2010-03-22	1724	\N	28093	\N
31159	GENERIC_DAY	1	9	2010-01-20	1724	\N	28093	\N
31212	GENERIC_DAY	1	8	2010-03-30	1724	\N	28093	\N
31202	GENERIC_DAY	1	8	2010-03-10	1724	\N	28093	\N
31181	GENERIC_DAY	1	8	2010-02-12	1724	\N	28093	\N
31198	GENERIC_DAY	1	8	2010-04-12	1724	\N	28093	\N
31173	GENERIC_DAY	1	8	2010-03-01	1724	\N	28093	\N
31178	GENERIC_DAY	1	0	2010-02-14	1724	\N	28093	\N
31191	GENERIC_DAY	1	8	2010-02-25	1724	\N	28093	\N
31209	GENERIC_DAY	1	0	2010-03-20	1724	\N	28093	\N
31216	GENERIC_DAY	1	8	2010-03-24	1724	\N	28093	\N
31205	GENERIC_DAY	1	8	2010-02-23	1724	\N	28093	\N
31195	GENERIC_DAY	1	0	2010-03-21	1724	\N	28093	\N
31147	GENERIC_DAY	1	0	2010-02-21	1724	\N	28093	\N
31170	GENERIC_DAY	1	0	2010-04-10	1724	\N	28093	\N
31171	GENERIC_DAY	1	8	2010-02-04	1724	\N	28093	\N
31215	GENERIC_DAY	1	0	2010-01-31	1724	\N	28093	\N
31225	GENERIC_DAY	1	8	2010-03-31	1724	\N	28093	\N
31210	GENERIC_DAY	1	0	2010-03-14	1724	\N	28093	\N
31197	GENERIC_DAY	1	8	2010-03-18	1724	\N	28093	\N
31165	GENERIC_DAY	1	8	2010-02-11	1724	\N	28093	\N
31182	GENERIC_DAY	1	1	2010-01-17	1724	\N	28093	\N
31172	GENERIC_DAY	1	8	2010-02-02	1724	\N	28093	\N
31162	GENERIC_DAY	1	8	2010-01-28	1724	\N	28093	\N
31196	GENERIC_DAY	1	8	2010-02-19	1724	\N	28093	\N
31218	GENERIC_DAY	1	0	2010-02-13	1724	\N	28093	\N
31224	GENERIC_DAY	1	9	2010-01-21	1724	\N	28093	\N
31204	GENERIC_DAY	1	8	2010-04-07	1724	\N	28093	\N
31231	GENERIC_DAY	1	8	2010-03-03	1724	\N	28093	\N
31190	GENERIC_DAY	1	8	2010-03-23	1724	\N	28093	\N
31222	GENERIC_DAY	1	0	2010-04-11	1724	\N	28093	\N
31228	GENERIC_DAY	1	8	2010-02-15	1724	\N	28093	\N
31153	GENERIC_DAY	1	8	2010-02-08	1724	\N	28093	\N
31164	GENERIC_DAY	1	1	2010-01-24	1724	\N	28093	\N
39440	GENERIC_DAY	1	0	2010-02-11	37573	\N	38601	\N
39441	GENERIC_DAY	1	0	2010-03-19	36159	\N	38601	\N
39442	GENERIC_DAY	1	0	2010-03-07	36159	\N	38601	\N
39443	GENERIC_DAY	1	0	2010-02-22	36159	\N	38601	\N
43053	GENERIC_DAY	10	0	2010-02-04	36159	\N	41054	\N
43031	GENERIC_DAY	10	0	2010-01-12	37573	\N	41054	\N
43024	GENERIC_DAY	10	0	2010-01-30	40199	\N	41054	\N
43060	GENERIC_DAY	10	1	2010-02-01	37573	\N	41054	\N
43059	GENERIC_DAY	10	1	2010-01-18	36159	\N	41054	\N
43090	GENERIC_DAY	10	0	2010-01-16	36159	\N	41054	\N
43037	GENERIC_DAY	10	0	2010-02-08	36159	\N	41054	\N
43085	GENERIC_DAY	10	1	2010-02-05	40199	\N	41054	\N
43066	GENERIC_DAY	10	0	2010-01-24	40199	\N	41054	\N
43034	GENERIC_DAY	10	0	2010-02-03	36159	\N	41054	\N
43054	GENERIC_DAY	10	0	2010-02-11	40199	\N	41054	\N
43097	GENERIC_DAY	10	0	2010-02-09	40199	\N	41054	\N
43038	GENERIC_DAY	10	0	2010-02-05	37573	\N	41054	\N
43027	GENERIC_DAY	10	0	2010-01-23	40199	\N	41054	\N
43096	GENERIC_DAY	10	0	2010-01-23	37573	\N	41054	\N
43023	GENERIC_DAY	10	0	2010-01-23	36159	\N	41054	\N
43067	GENERIC_DAY	10	1	2010-01-25	40199	\N	41054	\N
43083	GENERIC_DAY	10	0	2010-01-21	40199	\N	41054	\N
43102	GENERIC_DAY	10	1	2010-01-13	40199	\N	41054	\N
43044	GENERIC_DAY	10	0	2010-02-05	36159	\N	41054	\N
27210	GENERIC_DAY	1	3	2009-12-07	1726	\N	3940	\N
27211	GENERIC_DAY	1	2	2009-12-18	1726	\N	3940	\N
27212	GENERIC_DAY	1	3	2009-12-14	1722	\N	3940	\N
27213	GENERIC_DAY	1	3	2009-12-09	1726	\N	3940	\N
27214	GENERIC_DAY	1	0	2009-12-12	1718	\N	3940	\N
27215	GENERIC_DAY	1	0	2009-12-19	1718	\N	3940	\N
27216	GENERIC_DAY	1	2	2009-12-22	1718	\N	3940	\N
27217	GENERIC_DAY	1	4	2009-12-18	1722	\N	3940	\N
27218	GENERIC_DAY	1	2	2009-12-17	1722	\N	3940	\N
27219	GENERIC_DAY	1	0	2009-12-19	1722	\N	3940	\N
27220	GENERIC_DAY	1	3	2009-12-15	1726	\N	3940	\N
27221	GENERIC_DAY	1	0	2009-12-13	1722	\N	3940	\N
27222	GENERIC_DAY	1	2	2009-12-11	1718	\N	3940	\N
27223	GENERIC_DAY	1	3	2009-12-14	1726	\N	3940	\N
27224	GENERIC_DAY	1	3	2009-12-21	1722	\N	3940	\N
27225	GENERIC_DAY	1	2	2009-12-23	1722	\N	3940	\N
27226	GENERIC_DAY	1	0	2009-12-12	1726	\N	3940	\N
27227	GENERIC_DAY	1	2	2009-12-09	1722	\N	3940	\N
27228	GENERIC_DAY	1	3	2009-12-17	1718	\N	3940	\N
27229	GENERIC_DAY	1	0	2009-12-20	1722	\N	3940	\N
27230	GENERIC_DAY	1	2	2009-12-16	1718	\N	3940	\N
27231	GENERIC_DAY	1	3	2009-12-17	1726	\N	3940	\N
27232	GENERIC_DAY	1	2	2009-12-10	1718	\N	3940	\N
27233	GENERIC_DAY	1	2	2009-12-07	1718	\N	3940	\N
27234	GENERIC_DAY	1	2	2009-12-15	1718	\N	3940	\N
27235	GENERIC_DAY	1	0	2009-12-20	1726	\N	3940	\N
27236	GENERIC_DAY	1	2	2009-12-21	1718	\N	3940	\N
27237	GENERIC_DAY	1	2	2009-12-18	1718	\N	3940	\N
27238	GENERIC_DAY	1	3	2009-12-07	1722	\N	3940	\N
27239	GENERIC_DAY	1	3	2009-12-22	1722	\N	3940	\N
27240	GENERIC_DAY	1	3	2009-12-10	1722	\N	3940	\N
27241	GENERIC_DAY	1	3	2009-12-11	1722	\N	3940	\N
27242	GENERIC_DAY	1	0	2009-12-20	1718	\N	3940	\N
27243	GENERIC_DAY	1	0	2009-12-19	1726	\N	3940	\N
27244	GENERIC_DAY	1	3	2009-12-22	1726	\N	3940	\N
27245	GENERIC_DAY	1	3	2009-12-11	1726	\N	3940	\N
27246	GENERIC_DAY	1	2	2009-12-14	1718	\N	3940	\N
27247	GENERIC_DAY	1	1	2009-12-23	1718	\N	3940	\N
27248	GENERIC_DAY	1	0	2009-12-13	1726	\N	3940	\N
27249	GENERIC_DAY	1	3	2009-12-21	1726	\N	3940	\N
27250	GENERIC_DAY	1	3	2009-12-16	1722	\N	3940	\N
27251	GENERIC_DAY	1	0	2009-12-12	1722	\N	3940	\N
27252	GENERIC_DAY	1	3	2009-12-08	1726	\N	3940	\N
27253	GENERIC_DAY	1	3	2009-12-15	1722	\N	3940	\N
27254	GENERIC_DAY	1	0	2010-01-02	1718	\N	19901	\N
27255	GENERIC_DAY	1	0	2010-01-31	1718	\N	19901	\N
27256	GENERIC_DAY	1	3	2010-01-27	1718	\N	19901	\N
27257	GENERIC_DAY	1	3	2010-02-12	1722	\N	19901	\N
27258	GENERIC_DAY	1	3	2010-01-19	1718	\N	19901	\N
27259	GENERIC_DAY	1	3	2010-01-22	1726	\N	19901	\N
27260	GENERIC_DAY	1	0	2010-01-31	1722	\N	19901	\N
27261	GENERIC_DAY	1	3	2010-02-09	1726	\N	19901	\N
27262	GENERIC_DAY	1	3	2010-01-22	1718	\N	19901	\N
27263	GENERIC_DAY	1	1	2010-02-10	1722	\N	19901	\N
27264	GENERIC_DAY	1	2	2010-01-26	1718	\N	19901	\N
27265	GENERIC_DAY	1	3	2010-01-07	1718	\N	19901	\N
27266	GENERIC_DAY	1	4	2010-01-13	1718	\N	19901	\N
27267	GENERIC_DAY	1	2	2010-01-18	1722	\N	19901	\N
27268	GENERIC_DAY	1	0	2010-02-07	1718	\N	19901	\N
27269	GENERIC_DAY	1	2	2010-01-28	1722	\N	19901	\N
27270	GENERIC_DAY	1	3	2010-01-26	1726	\N	19901	\N
27271	GENERIC_DAY	1	1	2010-02-17	1718	\N	19901	\N
27272	GENERIC_DAY	1	2	2010-01-14	1722	\N	19901	\N
27273	GENERIC_DAY	1	3	2010-01-04	1718	\N	19901	\N
27274	GENERIC_DAY	1	3	2010-01-29	1718	\N	19901	\N
27275	GENERIC_DAY	1	0	2010-01-03	1726	\N	19901	\N
27276	GENERIC_DAY	1	2	2010-01-11	1722	\N	19901	\N
27277	GENERIC_DAY	1	2	2010-02-17	1726	\N	19901	\N
27278	GENERIC_DAY	1	0	2010-02-06	1726	\N	19901	\N
27279	GENERIC_DAY	1	4	2010-01-11	1718	\N	19901	\N
27280	GENERIC_DAY	1	3	2010-01-07	1726	\N	19901	\N
27281	GENERIC_DAY	1	3	2009-12-28	1726	\N	19901	\N
27282	GENERIC_DAY	1	3	2010-02-01	1726	\N	19901	\N
27283	GENERIC_DAY	1	3	2010-02-15	1726	\N	19901	\N
27284	GENERIC_DAY	1	3	2010-01-21	1726	\N	19901	\N
27285	GENERIC_DAY	1	2	2009-12-28	1718	\N	19901	\N
27286	GENERIC_DAY	1	1	2010-02-08	1722	\N	19901	\N
27287	GENERIC_DAY	1	0	2010-02-07	1726	\N	19901	\N
27288	GENERIC_DAY	1	2	2009-12-29	1718	\N	19901	\N
27289	GENERIC_DAY	1	3	2010-02-11	1726	\N	19901	\N
27290	GENERIC_DAY	1	2	2010-02-16	1718	\N	19901	\N
27291	GENERIC_DAY	1	3	2010-01-15	1718	\N	19901	\N
27292	GENERIC_DAY	1	2	2010-01-05	1718	\N	19901	\N
27293	GENERIC_DAY	1	3	2010-01-25	1726	\N	19901	\N
27294	GENERIC_DAY	1	3	2010-02-16	1722	\N	19901	\N
27295	GENERIC_DAY	1	3	2010-02-03	1726	\N	19901	\N
27296	GENERIC_DAY	1	4	2010-02-11	1718	\N	19901	\N
27297	GENERIC_DAY	1	3	2009-12-31	1722	\N	19901	\N
27298	GENERIC_DAY	1	3	2010-02-08	1726	\N	19901	\N
25510	GENERIC_DAY	3	7	2010-04-22	7272	\N	24143	\N
25511	GENERIC_DAY	3	0	2010-03-14	7272	\N	24143	\N
25512	GENERIC_DAY	3	7	2010-03-19	7272	\N	24143	\N
27299	GENERIC_DAY	1	2	2010-01-21	1722	\N	19901	\N
27300	GENERIC_DAY	1	0	2010-01-17	1726	\N	19901	\N
27301	GENERIC_DAY	1	0	2010-01-03	1722	\N	19901	\N
25513	GENERIC_DAY	3	0	2010-04-11	7272	\N	24143	\N
25514	GENERIC_DAY	3	0	2010-04-04	7272	\N	24143	\N
25515	GENERIC_DAY	3	0	2010-04-17	7272	\N	24143	\N
25516	GENERIC_DAY	3	7	2010-03-24	7272	\N	24143	\N
25517	GENERIC_DAY	3	7	2010-03-29	7272	\N	24143	\N
25518	GENERIC_DAY	3	0	2010-04-03	7272	\N	24143	\N
25519	GENERIC_DAY	3	0	2010-02-28	7272	\N	24143	\N
25520	GENERIC_DAY	3	7	2010-03-03	7272	\N	24143	\N
25521	GENERIC_DAY	3	7	2010-04-16	7272	\N	24143	\N
25522	GENERIC_DAY	3	7	2010-04-07	7272	\N	24143	\N
25523	GENERIC_DAY	3	0	2010-03-21	7272	\N	24143	\N
15942	GENERIC_DAY	0	2	2010-04-22	1722	\N	3984	\N
15943	GENERIC_DAY	0	2	2010-04-16	1722	\N	3984	\N
15944	GENERIC_DAY	0	2	2010-04-18	1726	\N	3984	\N
15945	GENERIC_DAY	0	2	2010-04-11	1726	\N	3984	\N
15946	GENERIC_DAY	0	1	2010-04-17	1718	\N	3984	\N
15947	GENERIC_DAY	0	2	2010-04-10	1722	\N	3984	\N
15948	GENERIC_DAY	0	2	2010-04-06	1722	\N	3984	\N
15949	GENERIC_DAY	0	2	2010-04-18	1722	\N	3984	\N
15950	GENERIC_DAY	0	2	2010-04-11	1718	\N	3984	\N
15951	GENERIC_DAY	0	2	2010-04-14	1726	\N	3984	\N
15952	GENERIC_DAY	0	2	2010-04-10	1726	\N	3984	\N
15953	GENERIC_DAY	0	1	2010-04-22	1718	\N	3984	\N
15954	GENERIC_DAY	0	2	2010-04-17	1726	\N	3984	\N
15955	GENERIC_DAY	0	2	2010-04-09	1718	\N	3984	\N
15956	GENERIC_DAY	0	2	2010-04-17	1722	\N	3984	\N
15957	GENERIC_DAY	0	2	2010-04-20	1722	\N	3984	\N
15958	GENERIC_DAY	0	1	2010-04-19	1718	\N	3984	\N
15959	GENERIC_DAY	0	2	2010-04-22	1726	\N	3984	\N
15960	GENERIC_DAY	0	2	2010-04-14	1722	\N	3984	\N
15961	GENERIC_DAY	0	2	2010-04-13	1726	\N	3984	\N
15962	GENERIC_DAY	0	2	2010-04-07	1722	\N	3984	\N
15963	GENERIC_DAY	0	2	2010-04-15	1722	\N	3984	\N
15964	GENERIC_DAY	0	2	2010-04-06	1726	\N	3984	\N
15965	GENERIC_DAY	0	1	2010-04-18	1718	\N	3984	\N
15966	GENERIC_DAY	0	1	2010-04-16	1718	\N	3984	\N
15967	GENERIC_DAY	0	2	2010-04-06	1718	\N	3984	\N
15968	GENERIC_DAY	0	1	2010-04-20	1718	\N	3984	\N
15969	GENERIC_DAY	0	2	2010-04-05	1722	\N	3984	\N
15970	GENERIC_DAY	0	2	2010-04-13	1722	\N	3984	\N
15971	GENERIC_DAY	0	2	2010-04-08	1718	\N	3984	\N
15972	GENERIC_DAY	0	2	2010-04-10	1718	\N	3984	\N
15973	GENERIC_DAY	0	2	2010-04-16	1726	\N	3984	\N
15974	GENERIC_DAY	0	1	2010-04-21	1718	\N	3984	\N
15975	GENERIC_DAY	0	2	2010-04-11	1722	\N	3984	\N
15976	GENERIC_DAY	0	2	2010-04-15	1726	\N	3984	\N
15977	GENERIC_DAY	0	2	2010-04-12	1718	\N	3984	\N
15978	GENERIC_DAY	0	2	2010-04-19	1722	\N	3984	\N
15979	GENERIC_DAY	0	2	2010-04-12	1726	\N	3984	\N
15980	GENERIC_DAY	0	2	2010-04-05	1726	\N	3984	\N
15981	GENERIC_DAY	0	2	2010-04-20	1726	\N	3984	\N
15982	GENERIC_DAY	0	2	2010-04-19	1726	\N	3984	\N
15983	GENERIC_DAY	0	2	2010-04-21	1722	\N	3984	\N
15984	GENERIC_DAY	0	2	2010-04-21	1726	\N	3984	\N
15985	GENERIC_DAY	0	2	2010-04-09	1722	\N	3984	\N
15986	GENERIC_DAY	0	2	2010-04-14	1718	\N	3984	\N
15987	GENERIC_DAY	0	2	2010-04-07	1718	\N	3984	\N
15988	GENERIC_DAY	0	2	2010-04-13	1718	\N	3984	\N
15989	GENERIC_DAY	0	2	2010-04-12	1722	\N	3984	\N
15990	GENERIC_DAY	0	2	2010-04-09	1726	\N	3984	\N
15991	GENERIC_DAY	0	2	2010-04-05	1718	\N	3984	\N
15992	GENERIC_DAY	0	2	2010-04-08	1722	\N	3984	\N
15993	GENERIC_DAY	0	2	2010-04-07	1726	\N	3984	\N
15994	GENERIC_DAY	0	2	2010-04-08	1726	\N	3984	\N
15995	GENERIC_DAY	0	1	2010-04-15	1718	\N	3984	\N
25524	GENERIC_DAY	3	7	2010-04-23	7272	\N	24143	\N
25525	GENERIC_DAY	3	7	2010-03-11	7272	\N	24143	\N
25526	GENERIC_DAY	3	7	2010-03-02	7272	\N	24143	\N
25527	GENERIC_DAY	3	7	2010-04-14	7272	\N	24143	\N
25528	GENERIC_DAY	3	7	2010-03-10	7272	\N	24143	\N
25529	GENERIC_DAY	3	7	2010-03-16	7272	\N	24143	\N
25530	GENERIC_DAY	3	0	2010-03-28	7272	\N	24143	\N
25531	GENERIC_DAY	3	7	2010-03-22	7272	\N	24143	\N
25532	GENERIC_DAY	3	7	2010-03-05	7272	\N	24143	\N
25533	GENERIC_DAY	3	7	2010-04-05	7272	\N	24143	\N
25534	GENERIC_DAY	3	7	2010-04-12	7272	\N	24143	\N
25535	GENERIC_DAY	3	7	2010-04-27	7272	\N	24143	\N
25536	GENERIC_DAY	3	7	2010-03-26	7272	\N	24143	\N
25537	GENERIC_DAY	3	7	2010-03-25	7272	\N	24143	\N
25538	GENERIC_DAY	3	0	2010-03-07	7272	\N	24143	\N
25539	GENERIC_DAY	3	0	2010-03-20	7272	\N	24143	\N
25540	GENERIC_DAY	3	7	2010-04-06	7272	\N	24143	\N
25541	GENERIC_DAY	3	7	2010-03-09	7272	\N	24143	\N
25542	GENERIC_DAY	3	7	2010-04-26	7272	\N	24143	\N
25543	GENERIC_DAY	3	7	2010-04-15	7272	\N	24143	\N
25544	GENERIC_DAY	3	7	2010-03-23	7272	\N	24143	\N
25545	GENERIC_DAY	3	0	2010-04-25	7272	\N	24143	\N
25546	GENERIC_DAY	3	7	2010-04-21	7272	\N	24143	\N
25547	GENERIC_DAY	3	0	2010-03-13	7272	\N	24143	\N
25548	GENERIC_DAY	3	7	2010-04-08	7272	\N	24143	\N
25549	GENERIC_DAY	3	0	2010-04-18	7272	\N	24143	\N
25550	GENERIC_DAY	3	7	2010-03-15	7272	\N	24143	\N
25551	GENERIC_DAY	3	7	2010-04-19	7272	\N	24143	\N
25552	GENERIC_DAY	3	7	2010-03-04	7272	\N	24143	\N
25553	GENERIC_DAY	3	7	2010-04-13	7272	\N	24143	\N
25554	GENERIC_DAY	3	7	2010-03-30	7272	\N	24143	\N
25555	GENERIC_DAY	3	7	2010-04-02	7272	\N	24143	\N
25556	GENERIC_DAY	3	7	2010-03-18	7272	\N	24143	\N
25557	GENERIC_DAY	3	7	2010-03-31	7272	\N	24143	\N
25558	GENERIC_DAY	3	7	2010-03-08	7272	\N	24143	\N
25559	GENERIC_DAY	3	6	2010-04-28	7272	\N	24143	\N
25560	GENERIC_DAY	3	7	2010-04-01	7272	\N	24143	\N
25561	GENERIC_DAY	3	0	2010-02-27	7272	\N	24143	\N
16035	GENERIC_DAY	0	2	2010-03-04	1726	\N	8589	\N
16036	GENERIC_DAY	0	4	2010-02-15	1722	\N	8589	\N
16037	GENERIC_DAY	0	2	2010-02-10	1726	\N	8589	\N
16038	GENERIC_DAY	0	3	2010-03-19	1722	\N	8589	\N
16039	GENERIC_DAY	0	3	2010-03-13	1722	\N	8589	\N
16040	GENERIC_DAY	0	2	2010-02-22	1726	\N	8589	\N
16041	GENERIC_DAY	0	3	2010-03-15	1722	\N	8589	\N
16042	GENERIC_DAY	0	3	2010-03-20	1722	\N	8589	\N
16043	GENERIC_DAY	0	3	2010-03-16	1722	\N	8589	\N
16044	GENERIC_DAY	0	3	2010-03-24	1726	\N	8589	\N
16045	GENERIC_DAY	0	3	2010-03-10	1722	\N	8589	\N
16046	GENERIC_DAY	0	2	2010-03-09	1726	\N	8589	\N
16047	GENERIC_DAY	0	2	2010-03-08	1726	\N	8589	\N
16048	GENERIC_DAY	0	4	2010-02-22	1722	\N	8589	\N
16049	GENERIC_DAY	0	3	2010-03-07	1722	\N	8589	\N
16050	GENERIC_DAY	0	2	2010-03-05	1726	\N	8589	\N
16051	GENERIC_DAY	0	3	2010-02-18	1718	\N	8589	\N
16052	GENERIC_DAY	0	5	2010-02-14	1722	\N	8589	\N
16053	GENERIC_DAY	0	2	2010-02-26	1726	\N	8589	\N
16054	GENERIC_DAY	0	2	2010-02-13	1726	\N	8589	\N
16055	GENERIC_DAY	0	4	2010-02-19	1722	\N	8589	\N
16056	GENERIC_DAY	0	2	2010-03-03	1726	\N	8589	\N
16057	GENERIC_DAY	0	2	2010-02-19	1718	\N	8589	\N
16058	GENERIC_DAY	0	2	2010-02-25	1718	\N	8589	\N
16059	GENERIC_DAY	0	2	2010-02-21	1718	\N	8589	\N
16060	GENERIC_DAY	0	2	2010-02-24	1718	\N	8589	\N
16061	GENERIC_DAY	0	2	2010-03-17	1726	\N	8589	\N
16062	GENERIC_DAY	0	2	2010-02-11	1718	\N	8589	\N
16063	GENERIC_DAY	0	2	2010-03-24	1718	\N	8589	\N
16064	GENERIC_DAY	0	2	2010-02-13	1718	\N	8589	\N
16065	GENERIC_DAY	0	3	2010-03-06	1718	\N	8589	\N
16066	GENERIC_DAY	0	4	2010-03-02	1722	\N	8589	\N
16067	GENERIC_DAY	0	2	2010-03-25	1718	\N	8589	\N
16068	GENERIC_DAY	0	2	2010-03-14	1726	\N	8589	\N
16069	GENERIC_DAY	0	3	2010-03-23	1726	\N	8589	\N
16070	GENERIC_DAY	0	3	2010-03-05	1722	\N	8589	\N
16071	GENERIC_DAY	0	3	2010-03-20	1726	\N	8589	\N
16072	GENERIC_DAY	0	3	2010-03-11	1722	\N	8589	\N
16073	GENERIC_DAY	0	2	2010-02-25	1726	\N	8589	\N
16074	GENERIC_DAY	0	3	2010-03-14	1718	\N	8589	\N
16075	GENERIC_DAY	0	4	2010-02-13	1722	\N	8589	\N
16076	GENERIC_DAY	0	4	2010-02-08	1722	\N	8589	\N
16077	GENERIC_DAY	0	1	2010-02-14	1726	\N	8589	\N
16078	GENERIC_DAY	0	4	2010-02-28	1722	\N	8589	\N
16079	GENERIC_DAY	0	4	2010-02-26	1722	\N	8589	\N
16080	GENERIC_DAY	0	2	2010-02-09	1718	\N	8589	\N
16081	GENERIC_DAY	0	4	2010-02-25	1722	\N	8589	\N
16082	GENERIC_DAY	0	1	2010-02-18	1726	\N	8589	\N
16083	GENERIC_DAY	0	3	2010-03-16	1718	\N	8589	\N
16084	GENERIC_DAY	0	3	2010-03-05	1718	\N	8589	\N
16085	GENERIC_DAY	0	1	2010-02-16	1726	\N	8589	\N
16086	GENERIC_DAY	0	2	2010-02-27	1726	\N	8589	\N
16087	GENERIC_DAY	0	3	2010-03-04	1722	\N	8589	\N
16088	GENERIC_DAY	0	2	2010-02-23	1726	\N	8589	\N
16089	GENERIC_DAY	0	2	2010-03-12	1726	\N	8589	\N
16090	GENERIC_DAY	0	3	2010-03-17	1718	\N	8589	\N
16091	GENERIC_DAY	0	3	2010-03-13	1718	\N	8589	\N
16092	GENERIC_DAY	0	2	2010-02-08	1718	\N	8589	\N
16093	GENERIC_DAY	0	4	2010-02-21	1722	\N	8589	\N
16094	GENERIC_DAY	0	2	2010-02-19	1726	\N	8589	\N
16095	GENERIC_DAY	0	2	2010-02-26	1718	\N	8589	\N
16096	GENERIC_DAY	0	4	2010-02-18	1722	\N	8589	\N
16097	GENERIC_DAY	0	2	2010-02-11	1726	\N	8589	\N
16098	GENERIC_DAY	0	2	2010-02-09	1726	\N	8589	\N
16099	GENERIC_DAY	0	3	2010-03-14	1722	\N	8589	\N
16100	GENERIC_DAY	0	1	2010-02-17	1726	\N	8589	\N
16101	GENERIC_DAY	0	2	2010-02-12	1718	\N	8589	\N
16102	GENERIC_DAY	0	2	2010-03-11	1726	\N	8589	\N
16103	GENERIC_DAY	0	3	2010-03-24	1722	\N	8589	\N
16104	GENERIC_DAY	0	4	2010-02-12	1722	\N	8589	\N
16105	GENERIC_DAY	0	2	2010-02-07	1726	\N	8589	\N
16106	GENERIC_DAY	0	3	2010-03-15	1718	\N	8589	\N
16107	GENERIC_DAY	0	4	2010-02-11	1722	\N	8589	\N
16108	GENERIC_DAY	0	2	2010-03-15	1726	\N	8589	\N
16109	GENERIC_DAY	0	2	2010-03-19	1718	\N	8589	\N
16110	GENERIC_DAY	0	2	2010-03-03	1718	\N	8589	\N
16111	GENERIC_DAY	0	4	2010-02-20	1722	\N	8589	\N
16112	GENERIC_DAY	0	2	2010-02-20	1726	\N	8589	\N
16113	GENERIC_DAY	0	2	2010-02-07	1718	\N	8589	\N
16114	GENERIC_DAY	0	3	2010-03-06	1722	\N	8589	\N
16115	GENERIC_DAY	0	4	2010-02-24	1722	\N	8589	\N
16116	GENERIC_DAY	0	2	2010-02-10	1718	\N	8589	\N
16117	GENERIC_DAY	0	3	2010-03-18	1726	\N	8589	\N
16118	GENERIC_DAY	0	3	2010-03-08	1722	\N	8589	\N
16119	GENERIC_DAY	0	4	2010-02-09	1722	\N	8589	\N
16120	GENERIC_DAY	0	3	2010-03-27	1726	\N	8589	\N
16121	GENERIC_DAY	0	3	2010-03-11	1718	\N	8589	\N
16122	GENERIC_DAY	0	3	2010-03-23	1722	\N	8589	\N
16123	GENERIC_DAY	0	2	2010-03-21	1718	\N	8589	\N
25562	GENERIC_DAY	3	7	2010-04-09	7272	\N	24143	\N
25563	GENERIC_DAY	3	0	2010-03-06	7272	\N	24143	\N
25564	GENERIC_DAY	3	7	2010-03-01	7272	\N	24143	\N
25565	GENERIC_DAY	3	7	2010-03-17	7272	\N	24143	\N
25566	GENERIC_DAY	3	7	2010-04-20	7272	\N	24143	\N
25567	GENERIC_DAY	3	0	2010-03-27	7272	\N	24143	\N
25568	GENERIC_DAY	3	7	2010-03-12	7272	\N	24143	\N
25569	GENERIC_DAY	3	0	2010-04-24	7272	\N	24143	\N
25570	GENERIC_DAY	3	0	2010-04-10	7272	\N	24143	\N
27302	GENERIC_DAY	1	2	2010-01-15	1722	\N	19901	\N
27303	GENERIC_DAY	1	0	2009-12-26	1718	\N	19901	\N
27304	GENERIC_DAY	1	0	2010-02-14	1718	\N	19901	\N
27305	GENERIC_DAY	1	2	2010-02-05	1722	\N	19901	\N
16124	GENERIC_DAY	0	2	2010-03-18	1722	\N	8589	\N
16125	GENERIC_DAY	0	3	2010-03-25	1726	\N	8589	\N
16126	GENERIC_DAY	0	2	2010-03-06	1726	\N	8589	\N
16127	GENERIC_DAY	0	2	2010-03-02	1726	\N	8589	\N
16128	GENERIC_DAY	0	2	2010-03-27	1718	\N	8589	\N
16129	GENERIC_DAY	0	4	2010-02-17	1722	\N	8589	\N
16130	GENERIC_DAY	0	4	2010-02-10	1722	\N	8589	\N
16131	GENERIC_DAY	0	2	2010-02-23	1718	\N	8589	\N
16132	GENERIC_DAY	0	2	2010-02-22	1718	\N	8589	\N
16133	GENERIC_DAY	0	3	2010-03-17	1722	\N	8589	\N
16134	GENERIC_DAY	0	3	2010-03-28	1726	\N	8589	\N
16135	GENERIC_DAY	0	2	2010-03-23	1718	\N	8589	\N
16136	GENERIC_DAY	0	3	2010-03-27	1722	\N	8589	\N
16137	GENERIC_DAY	0	1	2010-02-15	1726	\N	8589	\N
16138	GENERIC_DAY	0	3	2010-03-10	1718	\N	8589	\N
16139	GENERIC_DAY	0	4	2010-02-16	1722	\N	8589	\N
16140	GENERIC_DAY	0	2	2010-03-10	1726	\N	8589	\N
16141	GENERIC_DAY	0	4	2010-03-03	1722	\N	8589	\N
16142	GENERIC_DAY	0	3	2010-03-08	1718	\N	8589	\N
16143	GENERIC_DAY	0	2	2010-03-01	1726	\N	8589	\N
16144	GENERIC_DAY	0	2	2010-03-13	1726	\N	8589	\N
16145	GENERIC_DAY	0	3	2010-03-07	1718	\N	8589	\N
16146	GENERIC_DAY	0	2	2010-02-14	1718	\N	8589	\N
16147	GENERIC_DAY	0	2	2010-03-22	1718	\N	8589	\N
16148	GENERIC_DAY	0	2	2010-03-26	1718	\N	8589	\N
16149	GENERIC_DAY	0	3	2010-03-28	1722	\N	8589	\N
16150	GENERIC_DAY	0	3	2010-03-21	1726	\N	8589	\N
16151	GENERIC_DAY	0	3	2010-03-09	1722	\N	8589	\N
16152	GENERIC_DAY	0	3	2010-03-12	1722	\N	8589	\N
16153	GENERIC_DAY	0	4	2010-03-01	1722	\N	8589	\N
16154	GENERIC_DAY	0	2	2010-02-21	1726	\N	8589	\N
16155	GENERIC_DAY	0	3	2010-03-21	1722	\N	8589	\N
16156	GENERIC_DAY	0	2	2010-02-20	1718	\N	8589	\N
16157	GENERIC_DAY	0	2	2010-03-01	1718	\N	8589	\N
16158	GENERIC_DAY	0	3	2010-03-26	1726	\N	8589	\N
16159	GENERIC_DAY	0	3	2010-03-22	1722	\N	8589	\N
16160	GENERIC_DAY	0	3	2010-03-25	1722	\N	8589	\N
16161	GENERIC_DAY	0	3	2010-02-15	1718	\N	8589	\N
16162	GENERIC_DAY	0	3	2010-03-18	1718	\N	8589	\N
16163	GENERIC_DAY	0	3	2010-03-04	1718	\N	8589	\N
16164	GENERIC_DAY	0	4	2010-02-27	1722	\N	8589	\N
16165	GENERIC_DAY	0	2	2010-03-28	1718	\N	8589	\N
16166	GENERIC_DAY	0	2	2010-02-28	1726	\N	8589	\N
16167	GENERIC_DAY	0	4	2010-02-23	1722	\N	8589	\N
16168	GENERIC_DAY	0	3	2010-03-09	1718	\N	8589	\N
16169	GENERIC_DAY	0	4	2010-02-07	1722	\N	8589	\N
16170	GENERIC_DAY	0	3	2010-03-12	1718	\N	8589	\N
16171	GENERIC_DAY	0	2	2010-03-16	1726	\N	8589	\N
16172	GENERIC_DAY	0	3	2010-03-26	1722	\N	8589	\N
16173	GENERIC_DAY	0	3	2010-03-22	1726	\N	8589	\N
16174	GENERIC_DAY	0	3	2010-02-16	1718	\N	8589	\N
16175	GENERIC_DAY	0	2	2010-02-27	1718	\N	8589	\N
16176	GENERIC_DAY	0	2	2010-02-12	1726	\N	8589	\N
16177	GENERIC_DAY	0	2	2010-03-20	1718	\N	8589	\N
16178	GENERIC_DAY	0	2	2010-02-28	1718	\N	8589	\N
16179	GENERIC_DAY	0	2	2010-02-08	1726	\N	8589	\N
16180	GENERIC_DAY	0	2	2010-02-24	1726	\N	8589	\N
16181	GENERIC_DAY	0	3	2010-02-17	1718	\N	8589	\N
16182	GENERIC_DAY	0	2	2010-03-07	1726	\N	8589	\N
16183	GENERIC_DAY	0	2	2010-03-02	1718	\N	8589	\N
16184	GENERIC_DAY	0	3	2010-03-19	1726	\N	8589	\N
16185	GENERIC_DAY	0	8	2010-04-22	1720	\N	8588	\N
16186	GENERIC_DAY	0	8	2010-04-12	1720	\N	8588	\N
16187	GENERIC_DAY	0	8	2010-04-19	1720	\N	8588	\N
16188	GENERIC_DAY	0	8	2010-04-15	1720	\N	8588	\N
16189	GENERIC_DAY	0	8	2010-04-21	1720	\N	8588	\N
16190	GENERIC_DAY	0	8	2010-04-11	1720	\N	8588	\N
16191	GENERIC_DAY	0	8	2010-04-14	1720	\N	8588	\N
16192	GENERIC_DAY	0	8	2010-04-16	1720	\N	8588	\N
16193	GENERIC_DAY	0	8	2010-04-18	1720	\N	8588	\N
16194	GENERIC_DAY	0	4	2010-04-23	1720	\N	8588	\N
16195	GENERIC_DAY	0	8	2010-04-17	1720	\N	8588	\N
27306	GENERIC_DAY	1	0	2009-12-25	1718	\N	19901	\N
27307	GENERIC_DAY	1	3	2010-02-04	1726	\N	19901	\N
27308	GENERIC_DAY	1	3	2010-02-16	1726	\N	19901	\N
27309	GENERIC_DAY	1	0	2009-12-26	1726	\N	19901	\N
27310	GENERIC_DAY	1	0	2009-12-25	1726	\N	19901	\N
27311	GENERIC_DAY	1	0	2010-01-02	1722	\N	19901	\N
27312	GENERIC_DAY	1	3	2009-12-29	1726	\N	19901	\N
27313	GENERIC_DAY	1	0	2010-01-16	1726	\N	19901	\N
27314	GENERIC_DAY	1	0	2010-01-30	1718	\N	19901	\N
27315	GENERIC_DAY	1	0	2010-01-01	1726	\N	19901	\N
27316	GENERIC_DAY	1	0	2010-01-30	1726	\N	19901	\N
20789	GENERIC_DAY	1	8	2010-03-02	1724	\N	6367	\N
20788	GENERIC_DAY	1	8	2010-03-08	1724	\N	6367	\N
20790	GENERIC_DAY	1	8	2010-03-05	1724	\N	6367	\N
27317	GENERIC_DAY	1	3	2009-12-29	1722	\N	19901	\N
27318	GENERIC_DAY	1	0	2010-02-13	1722	\N	19901	\N
27319	GENERIC_DAY	1	3	2009-12-31	1726	\N	19901	\N
27320	GENERIC_DAY	1	3	2010-01-29	1726	\N	19901	\N
27321	GENERIC_DAY	1	3	2010-01-20	1718	\N	19901	\N
27322	GENERIC_DAY	1	0	2010-02-06	1718	\N	19901	\N
27323	GENERIC_DAY	1	1	2010-02-09	1722	\N	19901	\N
27324	GENERIC_DAY	1	1	2010-02-17	1722	\N	19901	\N
27325	GENERIC_DAY	1	0	2010-02-06	1722	\N	19901	\N
27326	GENERIC_DAY	1	3	2010-01-28	1718	\N	19901	\N
27327	GENERIC_DAY	1	0	2010-01-09	1726	\N	19901	\N
27328	GENERIC_DAY	1	2	2009-12-31	1718	\N	19901	\N
27329	GENERIC_DAY	1	2	2009-12-30	1718	\N	19901	\N
27330	GENERIC_DAY	1	0	2010-01-01	1718	\N	19901	\N
27331	GENERIC_DAY	1	2	2010-02-03	1722	\N	19901	\N
27332	GENERIC_DAY	1	3	2010-02-05	1718	\N	19901	\N
27333	GENERIC_DAY	1	2	2010-01-29	1722	\N	19901	\N
27334	GENERIC_DAY	1	0	2010-01-09	1718	\N	19901	\N
27335	GENERIC_DAY	1	2	2010-01-13	1722	\N	19901	\N
27336	GENERIC_DAY	1	3	2010-02-01	1718	\N	19901	\N
27337	GENERIC_DAY	1	3	2010-02-03	1718	\N	19901	\N
27338	GENERIC_DAY	1	3	2010-01-06	1726	\N	19901	\N
27339	GENERIC_DAY	1	4	2010-01-12	1718	\N	19901	\N
27340	GENERIC_DAY	1	3	2010-01-06	1718	\N	19901	\N
27341	GENERIC_DAY	1	3	2010-01-20	1726	\N	19901	\N
27342	GENERIC_DAY	1	3	2010-01-15	1726	\N	19901	\N
27343	GENERIC_DAY	1	3	2010-02-04	1718	\N	19901	\N
27344	GENERIC_DAY	1	3	2010-01-27	1726	\N	19901	\N
27345	GENERIC_DAY	1	2	2010-02-04	1722	\N	19901	\N
27346	GENERIC_DAY	1	2	2010-01-20	1722	\N	19901	\N
27347	GENERIC_DAY	1	3	2009-12-24	1722	\N	19901	\N
27348	GENERIC_DAY	1	3	2009-12-30	1722	\N	19901	\N
27349	GENERIC_DAY	1	0	2010-02-14	1726	\N	19901	\N
27350	GENERIC_DAY	1	3	2010-02-02	1726	\N	19901	\N
27351	GENERIC_DAY	1	3	2010-02-02	1718	\N	19901	\N
27352	GENERIC_DAY	1	0	2010-02-13	1718	\N	19901	\N
27353	GENERIC_DAY	1	0	2010-01-01	1722	\N	19901	\N
27354	GENERIC_DAY	1	2	2010-01-04	1722	\N	19901	\N
27355	GENERIC_DAY	1	0	2010-02-13	1726	\N	19901	\N
27356	GENERIC_DAY	1	0	2010-01-31	1726	\N	19901	\N
27357	GENERIC_DAY	1	3	2010-01-18	1718	\N	19901	\N
27358	GENERIC_DAY	1	2	2010-01-07	1722	\N	19901	\N
27359	GENERIC_DAY	1	2	2010-02-01	1722	\N	19901	\N
27360	GENERIC_DAY	1	0	2010-01-24	1718	\N	19901	\N
27361	GENERIC_DAY	1	2	2010-02-15	1718	\N	19901	\N
27362	GENERIC_DAY	1	2	2010-01-06	1722	\N	19901	\N
27363	GENERIC_DAY	1	2	2010-01-19	1722	\N	19901	\N
27364	GENERIC_DAY	1	2	2010-01-13	1726	\N	19901	\N
27365	GENERIC_DAY	1	0	2010-01-09	1722	\N	19901	\N
27366	GENERIC_DAY	1	2	2010-01-12	1726	\N	19901	\N
27367	GENERIC_DAY	1	0	2010-01-10	1722	\N	19901	\N
27368	GENERIC_DAY	1	3	2010-01-25	1718	\N	19901	\N
27369	GENERIC_DAY	1	3	2010-02-15	1722	\N	19901	\N
27370	GENERIC_DAY	1	0	2010-01-23	1718	\N	19901	\N
27371	GENERIC_DAY	1	2	2009-12-24	1718	\N	19901	\N
27372	GENERIC_DAY	1	3	2010-01-05	1722	\N	19901	\N
27373	GENERIC_DAY	1	2	2010-01-12	1722	\N	19901	\N
27374	GENERIC_DAY	1	4	2010-01-14	1718	\N	19901	\N
27375	GENERIC_DAY	1	0	2010-01-02	1726	\N	19901	\N
27376	GENERIC_DAY	1	3	2009-12-28	1722	\N	19901	\N
27377	GENERIC_DAY	1	2	2010-01-27	1722	\N	19901	\N
27378	GENERIC_DAY	1	3	2010-02-05	1726	\N	19901	\N
27379	GENERIC_DAY	1	4	2010-02-09	1718	\N	19901	\N
27380	GENERIC_DAY	1	3	2010-01-19	1726	\N	19901	\N
27381	GENERIC_DAY	1	0	2010-01-17	1722	\N	19901	\N
27382	GENERIC_DAY	1	0	2010-01-24	1722	\N	19901	\N
27383	GENERIC_DAY	1	2	2010-01-08	1722	\N	19901	\N
27384	GENERIC_DAY	1	3	2010-01-05	1726	\N	19901	\N
27385	GENERIC_DAY	1	2	2010-01-14	1726	\N	19901	\N
27386	GENERIC_DAY	1	0	2010-01-17	1718	\N	19901	\N
27387	GENERIC_DAY	1	2	2010-01-11	1726	\N	19901	\N
27388	GENERIC_DAY	1	3	2010-01-18	1726	\N	19901	\N
27389	GENERIC_DAY	1	3	2009-12-30	1726	\N	19901	\N
27390	GENERIC_DAY	1	0	2009-12-27	1718	\N	19901	\N
27391	GENERIC_DAY	1	2	2010-02-12	1718	\N	19901	\N
27392	GENERIC_DAY	1	3	2010-02-12	1726	\N	19901	\N
27393	GENERIC_DAY	1	0	2010-01-30	1722	\N	19901	\N
27394	GENERIC_DAY	1	0	2010-01-24	1726	\N	19901	\N
27395	GENERIC_DAY	1	1	2010-02-11	1722	\N	19901	\N
27396	GENERIC_DAY	1	0	2009-12-26	1722	\N	19901	\N
27397	GENERIC_DAY	1	3	2010-01-26	1722	\N	19901	\N
27398	GENERIC_DAY	1	0	2010-01-23	1722	\N	19901	\N
27399	GENERIC_DAY	1	0	2010-01-23	1726	\N	19901	\N
27400	GENERIC_DAY	1	0	2010-02-07	1722	\N	19901	\N
27401	GENERIC_DAY	1	3	2010-01-28	1726	\N	19901	\N
27402	GENERIC_DAY	1	0	2010-01-03	1718	\N	19901	\N
27403	GENERIC_DAY	1	2	2010-02-02	1722	\N	19901	\N
27404	GENERIC_DAY	1	0	2010-02-14	1722	\N	19901	\N
27405	GENERIC_DAY	1	3	2010-02-10	1726	\N	19901	\N
27406	GENERIC_DAY	1	3	2010-01-08	1726	\N	19901	\N
27407	GENERIC_DAY	1	4	2010-02-08	1718	\N	19901	\N
27408	GENERIC_DAY	1	0	2010-01-10	1726	\N	19901	\N
20797	GENERIC_DAY	1	8	2010-02-26	1724	\N	6367	\N
20794	GENERIC_DAY	1	8	2010-03-01	1724	\N	6367	\N
20793	GENERIC_DAY	1	8	2010-02-28	1724	\N	6367	\N
20798	GENERIC_DAY	1	8	2010-03-09	1724	\N	6367	\N
20791	GENERIC_DAY	1	8	2010-03-07	1724	\N	6367	\N
20796	GENERIC_DAY	1	8	2010-03-06	1724	\N	6367	\N
20799	GENERIC_DAY	1	8	2010-02-27	1724	\N	6367	\N
20795	GENERIC_DAY	1	8	2010-03-03	1724	\N	6367	\N
20792	GENERIC_DAY	1	8	2010-03-04	1724	\N	6367	\N
20800	GENERIC_DAY	1	4	2010-03-10	1724	\N	6367	\N
27409	GENERIC_DAY	1	3	2009-12-24	1726	\N	19901	\N
27410	GENERIC_DAY	1	0	2010-01-10	1718	\N	19901	\N
27411	GENERIC_DAY	1	3	2010-01-21	1718	\N	19901	\N
27412	GENERIC_DAY	1	0	2010-01-16	1722	\N	19901	\N
27413	GENERIC_DAY	1	4	2010-02-10	1718	\N	19901	\N
27414	GENERIC_DAY	1	2	2010-01-25	1722	\N	19901	\N
27415	GENERIC_DAY	1	3	2010-01-08	1718	\N	19901	\N
27416	GENERIC_DAY	1	3	2010-01-04	1726	\N	19901	\N
27417	GENERIC_DAY	1	0	2009-12-27	1726	\N	19901	\N
27418	GENERIC_DAY	1	0	2009-12-27	1722	\N	19901	\N
27419	GENERIC_DAY	1	0	2010-01-16	1718	\N	19901	\N
27420	GENERIC_DAY	1	0	2009-12-25	1722	\N	19901	\N
27421	GENERIC_DAY	1	2	2010-01-22	1722	\N	19901	\N
27422	GENERIC_DAY	1	7	2010-01-10	1720	\N	3952	\N
27423	GENERIC_DAY	1	15	2010-01-11	1720	\N	3952	\N
27424	GENERIC_DAY	1	7	2010-01-09	1720	\N	3952	\N
27425	GENERIC_DAY	1	14	2010-01-12	1720	\N	3952	\N
27426	GENERIC_DAY	1	14	2010-01-13	1720	\N	3952	\N
27427	GENERIC_DAY	1	15	2010-01-08	1720	\N	3952	\N
27428	GENERIC_DAY	1	14	2010-01-14	1720	\N	3952	\N
27429	GENERIC_DAY	1	14	2010-01-15	1720	\N	3952	\N
27430	GENERIC_DAY	1	14	2010-01-13	1724	\N	3951	\N
27431	GENERIC_DAY	1	14	2010-01-12	1724	\N	3951	\N
27432	GENERIC_DAY	1	15	2010-01-08	1724	\N	3951	\N
27433	GENERIC_DAY	1	15	2010-01-11	1724	\N	3951	\N
27434	GENERIC_DAY	1	7	2010-01-10	1724	\N	3951	\N
27435	GENERIC_DAY	1	14	2010-01-15	1724	\N	3951	\N
27436	GENERIC_DAY	1	14	2010-01-14	1724	\N	3951	\N
27437	GENERIC_DAY	1	7	2010-01-09	1724	\N	3951	\N
27438	GENERIC_DAY	1	0	2010-03-21	1724	\N	3950	\N
27439	GENERIC_DAY	1	2	2010-02-19	1724	\N	3950	\N
27440	GENERIC_DAY	1	2	2010-03-11	1724	\N	3950	\N
27441	GENERIC_DAY	1	2	2010-03-15	1724	\N	3950	\N
27442	GENERIC_DAY	1	2	2010-03-04	1724	\N	3950	\N
27443	GENERIC_DAY	1	0	2010-02-28	1724	\N	3950	\N
27444	GENERIC_DAY	1	2	2010-03-17	1724	\N	3950	\N
27445	GENERIC_DAY	1	2	2010-03-16	1724	\N	3950	\N
27446	GENERIC_DAY	1	2	2010-02-22	1724	\N	3950	\N
27447	GENERIC_DAY	1	0	2010-03-20	1724	\N	3950	\N
27448	GENERIC_DAY	1	0	2010-02-20	1724	\N	3950	\N
27449	GENERIC_DAY	1	0	2010-03-14	1724	\N	3950	\N
27450	GENERIC_DAY	1	2	2010-03-23	1724	\N	3950	\N
27451	GENERIC_DAY	1	2	2010-03-08	1724	\N	3950	\N
27452	GENERIC_DAY	1	2	2010-02-24	1724	\N	3950	\N
27453	GENERIC_DAY	1	2	2010-03-03	1724	\N	3950	\N
27454	GENERIC_DAY	1	2	2010-03-10	1724	\N	3950	\N
27455	GENERIC_DAY	1	0	2010-03-06	1724	\N	3950	\N
27456	GENERIC_DAY	1	2	2010-03-19	1724	\N	3950	\N
27457	GENERIC_DAY	1	2	2010-03-05	1724	\N	3950	\N
27458	GENERIC_DAY	1	0	2010-03-13	1724	\N	3950	\N
27459	GENERIC_DAY	1	2	2010-02-23	1724	\N	3950	\N
27460	GENERIC_DAY	1	0	2010-03-07	1724	\N	3950	\N
27461	GENERIC_DAY	1	2	2010-03-24	1724	\N	3950	\N
27462	GENERIC_DAY	1	2	2010-03-09	1724	\N	3950	\N
27463	GENERIC_DAY	1	2	2010-02-26	1724	\N	3950	\N
27464	GENERIC_DAY	1	2	2010-03-18	1724	\N	3950	\N
27465	GENERIC_DAY	1	2	2010-02-18	1724	\N	3950	\N
27466	GENERIC_DAY	1	2	2010-03-12	1724	\N	3950	\N
27467	GENERIC_DAY	1	2	2010-03-02	1724	\N	3950	\N
27468	GENERIC_DAY	1	2	2010-02-25	1724	\N	3950	\N
27469	GENERIC_DAY	1	0	2010-02-27	1724	\N	3950	\N
27470	GENERIC_DAY	1	2	2010-03-22	1724	\N	3950	\N
27471	GENERIC_DAY	1	0	2010-02-21	1724	\N	3950	\N
27472	GENERIC_DAY	1	2	2010-03-01	1724	\N	3950	\N
27473	GENERIC_DAY	1	0	2010-01-03	1724	\N	3953	\N
27474	GENERIC_DAY	1	0	2009-12-27	1724	\N	3953	\N
27475	GENERIC_DAY	1	0	2009-12-26	1724	\N	3953	\N
27476	GENERIC_DAY	1	8	2009-12-16	1724	\N	3953	\N
27477	GENERIC_DAY	1	0	2010-01-01	1724	\N	3953	\N
27478	GENERIC_DAY	1	8	2009-12-15	1724	\N	3953	\N
27479	GENERIC_DAY	1	0	2009-12-25	1724	\N	3953	\N
27480	GENERIC_DAY	1	8	2010-01-05	1724	\N	3953	\N
27481	GENERIC_DAY	1	8	2009-12-22	1724	\N	3953	\N
27482	GENERIC_DAY	1	8	2009-12-24	1724	\N	3953	\N
27483	GENERIC_DAY	1	8	2009-12-23	1724	\N	3953	\N
27484	GENERIC_DAY	1	8	2009-12-28	1724	\N	3953	\N
27485	GENERIC_DAY	1	8	2009-12-18	1724	\N	3953	\N
27486	GENERIC_DAY	1	8	2010-01-06	1724	\N	3953	\N
27487	GENERIC_DAY	1	8	2009-12-21	1724	\N	3953	\N
27488	GENERIC_DAY	1	0	2010-01-02	1724	\N	3953	\N
27489	GENERIC_DAY	1	8	2010-01-07	1724	\N	3953	\N
27490	GENERIC_DAY	1	8	2009-12-17	1724	\N	3953	\N
27491	GENERIC_DAY	1	8	2010-01-04	1724	\N	3953	\N
27492	GENERIC_DAY	1	8	2009-12-29	1724	\N	3953	\N
27493	GENERIC_DAY	1	0	2009-12-20	1724	\N	3953	\N
27494	GENERIC_DAY	1	8	2009-12-30	1724	\N	3953	\N
27495	GENERIC_DAY	1	0	2009-12-19	1724	\N	3953	\N
31454	SPECIFIC_DAY	3	0	2010-01-09	1720	31014	\N	\N
31455	SPECIFIC_DAY	3	8	2009-12-15	1720	31014	\N	\N
31456	SPECIFIC_DAY	3	8	2009-12-16	1720	31014	\N	\N
31457	SPECIFIC_DAY	3	0	2009-12-12	1720	31014	\N	\N
31458	SPECIFIC_DAY	3	8	2009-12-28	1720	31014	\N	\N
31459	SPECIFIC_DAY	3	8	2009-12-30	1720	31014	\N	\N
31460	SPECIFIC_DAY	3	8	2010-01-15	1720	31014	\N	\N
31461	SPECIFIC_DAY	3	8	2009-12-22	1720	31014	\N	\N
31462	SPECIFIC_DAY	3	0	2010-01-03	1720	31014	\N	\N
31463	SPECIFIC_DAY	3	8	2009-12-17	1720	31014	\N	\N
31464	SPECIFIC_DAY	3	8	2010-01-12	1720	31014	\N	\N
31465	SPECIFIC_DAY	3	0	2009-12-26	1720	31014	\N	\N
31466	SPECIFIC_DAY	3	8	2010-01-13	1720	31014	\N	\N
31467	SPECIFIC_DAY	3	8	2010-01-04	1720	31014	\N	\N
31468	SPECIFIC_DAY	3	8	2009-12-11	1720	31014	\N	\N
31469	SPECIFIC_DAY	3	8	2009-12-18	1720	31014	\N	\N
31470	SPECIFIC_DAY	3	8	2009-12-23	1720	31014	\N	\N
31471	SPECIFIC_DAY	3	0	2009-12-20	1720	31014	\N	\N
31472	SPECIFIC_DAY	3	8	2009-12-31	1720	31014	\N	\N
31473	SPECIFIC_DAY	3	8	2009-12-14	1720	31014	\N	\N
31474	SPECIFIC_DAY	3	8	2010-01-06	1720	31014	\N	\N
31475	SPECIFIC_DAY	3	8	2009-12-10	1720	31014	\N	\N
31476	SPECIFIC_DAY	3	8	2009-12-24	1720	31014	\N	\N
31477	SPECIFIC_DAY	3	8	2010-01-11	1720	31014	\N	\N
31478	SPECIFIC_DAY	3	0	2010-01-02	1720	31014	\N	\N
31479	SPECIFIC_DAY	3	8	2009-12-29	1720	31014	\N	\N
31480	SPECIFIC_DAY	3	8	2010-01-14	1720	31014	\N	\N
31481	SPECIFIC_DAY	3	8	2009-12-21	1720	31014	\N	\N
31482	SPECIFIC_DAY	3	0	2009-12-25	1720	31014	\N	\N
31483	SPECIFIC_DAY	3	8	2010-01-08	1720	31014	\N	\N
31484	SPECIFIC_DAY	3	8	2010-01-05	1720	31014	\N	\N
31485	SPECIFIC_DAY	3	0	2009-12-27	1720	31014	\N	\N
31486	SPECIFIC_DAY	3	8	2010-01-07	1720	31014	\N	\N
31487	SPECIFIC_DAY	3	0	2010-01-01	1720	31014	\N	\N
31488	SPECIFIC_DAY	3	0	2010-01-10	1720	31014	\N	\N
31489	SPECIFIC_DAY	3	0	2009-12-19	1720	31014	\N	\N
31490	SPECIFIC_DAY	3	0	2009-12-13	1720	31014	\N	\N
48919	GENERIC_DAY	0	3	2010-02-08	40199	\N	41050	\N
48920	GENERIC_DAY	0	2	2010-02-08	37573	\N	41050	\N
48921	GENERIC_DAY	0	0	2010-02-06	36159	\N	41050	\N
48922	GENERIC_DAY	0	3	2010-02-05	37573	\N	41050	\N
48923	GENERIC_DAY	0	0	2010-02-06	37573	\N	41050	\N
48924	GENERIC_DAY	0	0	2010-02-07	36159	\N	41050	\N
48925	GENERIC_DAY	0	1	2010-02-08	36159	\N	41050	\N
48926	GENERIC_DAY	0	3	2010-02-05	40199	\N	41050	\N
48927	GENERIC_DAY	0	2	2010-02-05	36159	\N	41050	\N
48928	GENERIC_DAY	0	0	2010-02-07	40199	\N	41050	\N
48929	GENERIC_DAY	0	0	2010-02-07	37573	\N	41050	\N
48930	GENERIC_DAY	0	0	2010-02-06	40199	\N	41050	\N
39501	GENERIC_DAY	1	0	2010-02-05	36159	\N	38601	\N
39502	GENERIC_DAY	1	0	2010-03-22	36159	\N	38601	\N
39503	GENERIC_DAY	1	0	2010-02-01	37573	\N	38601	\N
39504	GENERIC_DAY	1	0	2010-02-26	37573	\N	38601	\N
39505	GENERIC_DAY	1	0	2010-02-10	36159	\N	38601	\N
39506	GENERIC_DAY	1	1	2010-01-28	36159	\N	38601	\N
16196	GENERIC_DAY	0	8	2010-04-20	1720	\N	8588	\N
16197	GENERIC_DAY	0	8	2010-04-13	1720	\N	8588	\N
16198	GENERIC_DAY	0	8	2010-03-24	1724	\N	3983	\N
16199	GENERIC_DAY	0	8	2010-03-13	1724	\N	3983	\N
16200	GENERIC_DAY	0	8	2010-03-20	1724	\N	3983	\N
16201	GENERIC_DAY	0	8	2010-03-16	1724	\N	3983	\N
16202	GENERIC_DAY	0	8	2010-03-04	1724	\N	3983	\N
16203	GENERIC_DAY	0	8	2010-03-26	1724	\N	3983	\N
16204	GENERIC_DAY	0	8	2010-04-02	1724	\N	3983	\N
16205	GENERIC_DAY	0	8	2010-03-19	1724	\N	3983	\N
16206	GENERIC_DAY	0	8	2010-03-18	1724	\N	3983	\N
16207	GENERIC_DAY	0	8	2010-03-29	1724	\N	3983	\N
16208	GENERIC_DAY	0	8	2010-04-03	1724	\N	3983	\N
16209	GENERIC_DAY	0	8	2010-03-06	1724	\N	3983	\N
16210	GENERIC_DAY	0	8	2010-04-01	1724	\N	3983	\N
16211	GENERIC_DAY	0	8	2010-03-30	1724	\N	3983	\N
16212	GENERIC_DAY	0	8	2010-03-11	1724	\N	3983	\N
16213	GENERIC_DAY	0	8	2010-03-12	1724	\N	3983	\N
16214	GENERIC_DAY	0	8	2010-03-09	1724	\N	3983	\N
16215	GENERIC_DAY	0	8	2010-03-02	1724	\N	3983	\N
16216	GENERIC_DAY	0	8	2010-03-25	1724	\N	3983	\N
16217	GENERIC_DAY	0	8	2010-03-22	1724	\N	3983	\N
16218	GENERIC_DAY	0	8	2010-03-27	1724	\N	3983	\N
16219	GENERIC_DAY	0	8	2010-03-23	1724	\N	3983	\N
16220	GENERIC_DAY	0	8	2010-03-31	1724	\N	3983	\N
16221	GENERIC_DAY	0	8	2010-03-14	1724	\N	3983	\N
16222	GENERIC_DAY	0	8	2010-03-28	1724	\N	3983	\N
16223	GENERIC_DAY	0	8	2010-03-08	1724	\N	3983	\N
16224	GENERIC_DAY	0	8	2010-03-01	1724	\N	3983	\N
16225	GENERIC_DAY	0	8	2010-03-21	1724	\N	3983	\N
16226	GENERIC_DAY	0	8	2010-03-15	1724	\N	3983	\N
16227	GENERIC_DAY	0	8	2010-03-17	1724	\N	3983	\N
16228	GENERIC_DAY	0	8	2010-03-05	1724	\N	3983	\N
16229	GENERIC_DAY	0	8	2010-03-10	1724	\N	3983	\N
16230	GENERIC_DAY	0	8	2010-03-07	1724	\N	3983	\N
16231	GENERIC_DAY	0	8	2010-03-03	1724	\N	3983	\N
16232	GENERIC_DAY	0	3	2010-04-04	1724	\N	3983	\N
16233	GENERIC_DAY	0	8	2010-03-24	1720	\N	3982	\N
16234	GENERIC_DAY	0	8	2010-03-31	1720	\N	3982	\N
16235	GENERIC_DAY	0	8	2010-03-18	1720	\N	3982	\N
16236	GENERIC_DAY	0	8	2010-03-25	1720	\N	3982	\N
16237	GENERIC_DAY	0	8	2010-03-14	1720	\N	3982	\N
16238	GENERIC_DAY	0	8	2010-03-11	1720	\N	3982	\N
16239	GENERIC_DAY	0	8	2010-03-04	1720	\N	3982	\N
16240	GENERIC_DAY	0	8	2010-03-13	1720	\N	3982	\N
16241	GENERIC_DAY	0	8	2010-03-03	1720	\N	3982	\N
16242	GENERIC_DAY	0	8	2010-03-29	1720	\N	3982	\N
16243	GENERIC_DAY	0	8	2010-04-02	1720	\N	3982	\N
16244	GENERIC_DAY	0	8	2010-03-23	1720	\N	3982	\N
16245	GENERIC_DAY	0	8	2010-03-12	1720	\N	3982	\N
16246	GENERIC_DAY	0	8	2010-03-22	1720	\N	3982	\N
16247	GENERIC_DAY	0	8	2010-03-17	1720	\N	3982	\N
16248	GENERIC_DAY	0	8	2010-03-16	1720	\N	3982	\N
16249	GENERIC_DAY	0	8	2010-03-30	1720	\N	3982	\N
16250	GENERIC_DAY	0	8	2010-03-15	1720	\N	3982	\N
16251	GENERIC_DAY	0	8	2010-03-06	1720	\N	3982	\N
16252	GENERIC_DAY	0	8	2010-03-28	1720	\N	3982	\N
16253	GENERIC_DAY	0	8	2010-03-08	1720	\N	3982	\N
16254	GENERIC_DAY	0	8	2010-03-26	1720	\N	3982	\N
16255	GENERIC_DAY	0	8	2010-03-05	1720	\N	3982	\N
16256	GENERIC_DAY	0	8	2010-04-01	1720	\N	3982	\N
16257	GENERIC_DAY	0	8	2010-04-03	1720	\N	3982	\N
16258	GENERIC_DAY	0	8	2010-03-01	1720	\N	3982	\N
16259	GENERIC_DAY	0	3	2010-04-04	1720	\N	3982	\N
16260	GENERIC_DAY	0	8	2010-03-21	1720	\N	3982	\N
16261	GENERIC_DAY	0	8	2010-03-09	1720	\N	3982	\N
16262	GENERIC_DAY	0	8	2010-03-10	1720	\N	3982	\N
16263	GENERIC_DAY	0	8	2010-03-02	1720	\N	3982	\N
16264	GENERIC_DAY	0	8	2010-03-07	1720	\N	3982	\N
16265	GENERIC_DAY	0	8	2010-03-27	1720	\N	3982	\N
16266	GENERIC_DAY	0	8	2010-03-20	1720	\N	3982	\N
16267	GENERIC_DAY	0	8	2010-03-19	1720	\N	3982	\N
15996	GENERIC_DAY	3	3	2010-03-31	1722	\N	3985	\N
15997	GENERIC_DAY	3	3	2010-04-05	1726	\N	3985	\N
15998	GENERIC_DAY	3	3	2010-04-01	1722	\N	3985	\N
15999	GENERIC_DAY	3	3	2010-03-30	1726	\N	3985	\N
16000	GENERIC_DAY	3	3	2010-04-02	1726	\N	3985	\N
16001	GENERIC_DAY	3	3	2010-04-08	1722	\N	3985	\N
39444	GENERIC_DAY	1	0	2010-01-23	36159	\N	38601	\N
39445	GENERIC_DAY	1	0	2010-03-01	37573	\N	38601	\N
39446	GENERIC_DAY	1	1	2010-01-26	37573	\N	38601	\N
39447	GENERIC_DAY	1	0	2010-03-23	37573	\N	38601	\N
39448	GENERIC_DAY	1	0	2010-03-05	37573	\N	38601	\N
39449	GENERIC_DAY	1	0	2010-03-02	36159	\N	38601	\N
39450	GENERIC_DAY	1	1	2010-02-03	37573	\N	38601	\N
39451	GENERIC_DAY	1	0	2010-03-01	36159	\N	38601	\N
39452	GENERIC_DAY	1	0	2010-03-06	36159	\N	38601	\N
39453	GENERIC_DAY	1	0	2010-01-26	36159	\N	38601	\N
39454	GENERIC_DAY	1	0	2010-02-09	36159	\N	38601	\N
39455	GENERIC_DAY	1	0	2010-02-23	36159	\N	38601	\N
39456	GENERIC_DAY	1	0	2010-01-31	36159	\N	38601	\N
39457	GENERIC_DAY	1	0	2010-03-16	37573	\N	38601	\N
39458	GENERIC_DAY	1	0	2010-02-21	36159	\N	38601	\N
39459	GENERIC_DAY	1	0	2010-02-12	36159	\N	38601	\N
39460	GENERIC_DAY	1	0	2010-02-14	37573	\N	38601	\N
39461	GENERIC_DAY	1	0	2010-03-10	37573	\N	38601	\N
39462	GENERIC_DAY	1	0	2010-02-24	36159	\N	38601	\N
39463	GENERIC_DAY	1	0	2010-02-21	37573	\N	38601	\N
39464	GENERIC_DAY	1	0	2010-03-13	36159	\N	38601	\N
39465	GENERIC_DAY	1	0	2010-02-13	37573	\N	38601	\N
39466	GENERIC_DAY	1	0	2010-02-18	36159	\N	38601	\N
39467	GENERIC_DAY	1	0	2010-03-06	37573	\N	38601	\N
39468	GENERIC_DAY	1	0	2010-02-11	36159	\N	38601	\N
39469	GENERIC_DAY	1	0	2010-02-20	37573	\N	38601	\N
39470	GENERIC_DAY	1	0	2010-02-17	37573	\N	38601	\N
39471	GENERIC_DAY	1	1	2010-02-05	37573	\N	38601	\N
39472	GENERIC_DAY	1	0	2010-03-04	37573	\N	38601	\N
39473	GENERIC_DAY	1	0	2010-02-22	37573	\N	38601	\N
39474	GENERIC_DAY	1	0	2010-02-27	36159	\N	38601	\N
39475	GENERIC_DAY	1	0	2010-03-21	36159	\N	38601	\N
39476	GENERIC_DAY	1	0	2010-03-20	37573	\N	38601	\N
39477	GENERIC_DAY	1	0	2010-02-15	36159	\N	38601	\N
39478	GENERIC_DAY	1	1	2010-02-04	37573	\N	38601	\N
39479	GENERIC_DAY	1	0	2010-03-04	36159	\N	38601	\N
39480	GENERIC_DAY	1	0	2010-02-08	36159	\N	38601	\N
39481	GENERIC_DAY	1	0	2010-02-23	37573	\N	38601	\N
39482	GENERIC_DAY	1	0	2010-03-02	37573	\N	38601	\N
39483	GENERIC_DAY	1	0	2010-02-28	36159	\N	38601	\N
39484	GENERIC_DAY	1	0	2010-03-09	36159	\N	38601	\N
39485	GENERIC_DAY	1	0	2010-03-22	37573	\N	38601	\N
39486	GENERIC_DAY	1	0	2010-01-22	36159	\N	38601	\N
39487	GENERIC_DAY	1	1	2010-01-22	37573	\N	38601	\N
39488	GENERIC_DAY	1	0	2010-02-04	36159	\N	38601	\N
39489	GENERIC_DAY	1	0	2010-03-14	36159	\N	38601	\N
39490	GENERIC_DAY	1	0	2010-03-08	37573	\N	38601	\N
39491	GENERIC_DAY	1	1	2010-02-01	36159	\N	38601	\N
39492	GENERIC_DAY	1	0	2010-02-20	36159	\N	38601	\N
39493	GENERIC_DAY	1	0	2010-02-24	37573	\N	38601	\N
39494	GENERIC_DAY	1	1	2010-02-10	37573	\N	38601	\N
39495	GENERIC_DAY	1	0	2010-03-21	37573	\N	38601	\N
39496	GENERIC_DAY	1	0	2010-03-14	37573	\N	38601	\N
39497	GENERIC_DAY	1	0	2010-03-07	37573	\N	38601	\N
39498	GENERIC_DAY	1	0	2010-03-17	37573	\N	38601	\N
39499	GENERIC_DAY	1	0	2010-03-12	36159	\N	38601	\N
39500	GENERIC_DAY	1	0	2010-02-16	36159	\N	38601	\N
39507	GENERIC_DAY	1	0	2010-03-24	36159	\N	38601	\N
39508	GENERIC_DAY	1	0	2010-03-15	37573	\N	38601	\N
39509	GENERIC_DAY	1	0	2010-03-11	37573	\N	38601	\N
39510	GENERIC_DAY	1	0	2010-03-20	36159	\N	38601	\N
39511	GENERIC_DAY	1	0	2010-01-24	36159	\N	38601	\N
39512	GENERIC_DAY	1	0	2010-02-25	36159	\N	38601	\N
39513	GENERIC_DAY	1	1	2010-01-25	37573	\N	38601	\N
39514	GENERIC_DAY	1	0	2010-01-30	37573	\N	38601	\N
39515	GENERIC_DAY	1	0	2010-02-18	37573	\N	38601	\N
39516	GENERIC_DAY	1	0	2010-03-11	36159	\N	38601	\N
39517	GENERIC_DAY	1	0	2010-03-09	37573	\N	38601	\N
39518	GENERIC_DAY	1	1	2010-02-09	37573	\N	38601	\N
39519	GENERIC_DAY	1	0	2010-03-19	37573	\N	38601	\N
39520	GENERIC_DAY	1	0	2010-03-03	36159	\N	38601	\N
39521	GENERIC_DAY	1	0	2010-03-15	36159	\N	38601	\N
39522	GENERIC_DAY	1	0	2010-01-25	36159	\N	38601	\N
39523	GENERIC_DAY	1	0	2010-03-18	37573	\N	38601	\N
39524	GENERIC_DAY	1	0	2010-02-17	36159	\N	38601	\N
39525	GENERIC_DAY	1	0	2010-02-16	37573	\N	38601	\N
39526	GENERIC_DAY	1	0	2010-02-07	37573	\N	38601	\N
39527	GENERIC_DAY	1	0	2010-02-19	37573	\N	38601	\N
39528	GENERIC_DAY	1	0	2010-02-07	36159	\N	38601	\N
39529	GENERIC_DAY	1	0	2010-02-26	36159	\N	38601	\N
39530	GENERIC_DAY	1	1	2010-01-29	36159	\N	38601	\N
39531	GENERIC_DAY	1	0	2010-01-31	37573	\N	38601	\N
39532	GENERIC_DAY	1	1	2010-02-08	37573	\N	38601	\N
39533	GENERIC_DAY	1	0	2010-03-10	36159	\N	38601	\N
39534	GENERIC_DAY	1	0	2010-03-16	36159	\N	38601	\N
39535	GENERIC_DAY	1	0	2010-02-06	37573	\N	38601	\N
39536	GENERIC_DAY	1	0	2010-02-06	36159	\N	38601	\N
39537	GENERIC_DAY	1	0	2010-01-28	37573	\N	38601	\N
39538	GENERIC_DAY	1	1	2010-02-02	37573	\N	38601	\N
39539	GENERIC_DAY	1	0	2010-02-15	37573	\N	38601	\N
39540	GENERIC_DAY	1	0	2010-01-29	37573	\N	38601	\N
39541	GENERIC_DAY	1	0	2010-03-05	36159	\N	38601	\N
39542	GENERIC_DAY	1	0	2010-02-28	37573	\N	38601	\N
39543	GENERIC_DAY	1	0	2010-03-17	36159	\N	38601	\N
39544	GENERIC_DAY	1	1	2010-01-27	36159	\N	38601	\N
39545	GENERIC_DAY	1	0	2010-01-27	37573	\N	38601	\N
39546	GENERIC_DAY	1	0	2010-02-03	36159	\N	38601	\N
39547	GENERIC_DAY	1	0	2010-01-24	37573	\N	38601	\N
39548	GENERIC_DAY	1	0	2010-03-12	37573	\N	38601	\N
39549	GENERIC_DAY	1	0	2010-02-27	37573	\N	38601	\N
39550	GENERIC_DAY	1	0	2010-03-08	36159	\N	38601	\N
39551	GENERIC_DAY	1	0	2010-02-12	37573	\N	38601	\N
39552	GENERIC_DAY	1	0	2010-02-19	36159	\N	38601	\N
39553	GENERIC_DAY	1	0	2010-02-14	36159	\N	38601	\N
39554	GENERIC_DAY	1	0	2010-02-13	36159	\N	38601	\N
39555	GENERIC_DAY	1	0	2010-01-30	36159	\N	38601	\N
39556	GENERIC_DAY	1	0	2010-03-13	37573	\N	38601	\N
39557	GENERIC_DAY	1	0	2010-03-24	37573	\N	38601	\N
39558	GENERIC_DAY	1	0	2010-02-02	36159	\N	38601	\N
39559	GENERIC_DAY	1	0	2010-01-23	37573	\N	38601	\N
39560	GENERIC_DAY	1	0	2010-02-25	37573	\N	38601	\N
39561	GENERIC_DAY	1	0	2010-03-03	37573	\N	38601	\N
39562	GENERIC_DAY	1	0	2010-03-23	36159	\N	38601	\N
39563	GENERIC_DAY	1	0	2010-03-18	36159	\N	38601	\N
48811	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077	\N
48812	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077	\N
48813	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077	\N
48814	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077	\N
48815	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077	\N
21933	SPECIFIC_DAY	4	8	2010-02-17	1724	19903	\N	\N
21968	SPECIFIC_DAY	4	8	2010-02-23	1724	19903	\N	\N
21958	SPECIFIC_DAY	4	8	2010-02-04	1724	19903	\N	\N
21964	SPECIFIC_DAY	4	8	2010-01-22	1724	19903	\N	\N
21961	SPECIFIC_DAY	4	8	2010-02-15	1724	19903	\N	\N
21932	SPECIFIC_DAY	4	8	2010-01-08	1724	19903	\N	\N
21942	SPECIFIC_DAY	4	8	2010-02-12	1724	19903	\N	\N
21960	SPECIFIC_DAY	4	0	2010-02-21	1724	19903	\N	\N
21941	SPECIFIC_DAY	4	8	2010-02-01	1724	19903	\N	\N
21930	SPECIFIC_DAY	4	8	2010-01-13	1724	19903	\N	\N
21959	SPECIFIC_DAY	4	8	2010-01-04	1724	19903	\N	\N
21928	SPECIFIC_DAY	4	8	2010-02-02	1724	19903	\N	\N
21935	SPECIFIC_DAY	4	8	2010-02-03	1724	19903	\N	\N
21966	SPECIFIC_DAY	4	0	2010-01-01	1724	19903	\N	\N
21944	SPECIFIC_DAY	4	8	2010-01-27	1724	19903	\N	\N
21975	SPECIFIC_DAY	4	8	2010-01-11	1724	19903	\N	\N
21934	SPECIFIC_DAY	4	8	2010-01-29	1724	19903	\N	\N
21925	SPECIFIC_DAY	4	8	2010-02-18	1724	19903	\N	\N
21953	SPECIFIC_DAY	4	8	2010-02-09	1724	19903	\N	\N
21974	SPECIFIC_DAY	4	8	2010-01-07	1724	19903	\N	\N
21973	SPECIFIC_DAY	4	8	2010-01-26	1724	19903	\N	\N
21962	SPECIFIC_DAY	4	0	2010-01-02	1724	19903	\N	\N
21938	SPECIFIC_DAY	4	8	2010-02-19	1724	19903	\N	\N
21957	SPECIFIC_DAY	4	0	2010-02-14	1724	19903	\N	\N
21967	SPECIFIC_DAY	4	0	2010-02-06	1724	19903	\N	\N
21936	SPECIFIC_DAY	4	0	2010-01-10	1724	19903	\N	\N
21923	SPECIFIC_DAY	4	0	2010-01-24	1724	19903	\N	\N
21952	SPECIFIC_DAY	4	8	2010-01-28	1724	19903	\N	\N
21945	SPECIFIC_DAY	4	4	2010-02-24	1724	19903	\N	\N
21963	SPECIFIC_DAY	4	8	2010-01-18	1724	19903	\N	\N
21924	SPECIFIC_DAY	4	0	2010-02-13	1724	19903	\N	\N
21927	SPECIFIC_DAY	4	8	2010-02-22	1724	19903	\N	\N
21949	SPECIFIC_DAY	4	8	2010-02-16	1724	19903	\N	\N
21921	SPECIFIC_DAY	4	8	2010-02-05	1724	19903	\N	\N
21940	SPECIFIC_DAY	4	8	2010-01-06	1724	19903	\N	\N
21947	SPECIFIC_DAY	4	8	2010-01-19	1724	19903	\N	\N
21931	SPECIFIC_DAY	4	0	2010-02-20	1724	19903	\N	\N
21970	SPECIFIC_DAY	4	8	2010-01-15	1724	19903	\N	\N
21969	SPECIFIC_DAY	4	8	2010-01-12	1724	19903	\N	\N
21946	SPECIFIC_DAY	4	0	2010-01-31	1724	19903	\N	\N
21951	SPECIFIC_DAY	4	8	2010-02-08	1724	19903	\N	\N
21972	SPECIFIC_DAY	4	8	2010-01-05	1724	19903	\N	\N
21950	SPECIFIC_DAY	4	8	2010-02-11	1724	19903	\N	\N
21922	SPECIFIC_DAY	4	0	2010-01-30	1724	19903	\N	\N
21943	SPECIFIC_DAY	4	8	2010-01-20	1724	19903	\N	\N
21965	SPECIFIC_DAY	4	8	2010-01-21	1724	19903	\N	\N
21971	SPECIFIC_DAY	4	0	2010-01-09	1724	19903	\N	\N
21956	SPECIFIC_DAY	4	0	2010-01-23	1724	19903	\N	\N
21939	SPECIFIC_DAY	4	0	2010-01-03	1724	19903	\N	\N
21926	SPECIFIC_DAY	4	8	2010-02-10	1724	19903	\N	\N
21955	SPECIFIC_DAY	4	0	2010-01-17	1724	19903	\N	\N
21929	SPECIFIC_DAY	4	0	2010-01-16	1724	19903	\N	\N
21937	SPECIFIC_DAY	4	8	2010-01-14	1724	19903	\N	\N
21954	SPECIFIC_DAY	4	8	2010-01-25	1724	19903	\N	\N
21948	SPECIFIC_DAY	4	0	2010-02-07	1724	19903	\N	\N
48816	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077	\N
48817	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077	\N
48818	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077	\N
48819	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077	\N
48820	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077	\N
48821	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077	\N
48822	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077	\N
48823	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077	\N
48824	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077	\N
48825	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077	\N
25621	GENERIC_DAY	0	7	2009-12-23	1724	\N	6369	\N
25622	GENERIC_DAY	0	6	2009-12-18	1724	\N	6369	\N
25623	GENERIC_DAY	0	0	2009-12-19	1724	\N	6369	\N
25624	GENERIC_DAY	0	6	2009-12-16	1724	\N	6369	\N
25625	GENERIC_DAY	0	6	2009-12-15	1724	\N	6369	\N
25626	GENERIC_DAY	0	2	2009-12-08	1724	\N	6369	\N
25627	GENERIC_DAY	0	5	2009-12-10	1724	\N	6369	\N
25628	GENERIC_DAY	0	0	2009-12-25	1724	\N	6369	\N
25629	GENERIC_DAY	0	0	2009-12-13	1724	\N	6369	\N
25630	GENERIC_DAY	0	0	2009-12-12	1724	\N	6369	\N
25631	GENERIC_DAY	0	0	2009-12-26	1724	\N	6369	\N
25632	GENERIC_DAY	0	1	2009-12-09	1724	\N	6369	\N
25633	GENERIC_DAY	0	5	2009-12-11	1724	\N	6369	\N
25634	GENERIC_DAY	0	7	2009-12-21	1724	\N	6369	\N
25635	GENERIC_DAY	0	7	2009-12-24	1724	\N	6369	\N
25636	GENERIC_DAY	0	6	2009-12-31	1724	\N	6369	\N
25637	GENERIC_DAY	0	7	2009-12-30	1724	\N	6369	\N
25638	GENERIC_DAY	0	0	2009-12-20	1724	\N	6369	\N
25639	GENERIC_DAY	0	7	2009-12-28	1724	\N	6369	\N
25640	GENERIC_DAY	0	0	2009-12-27	1724	\N	6369	\N
25641	GENERIC_DAY	0	7	2009-12-22	1724	\N	6369	\N
25642	GENERIC_DAY	0	2	2009-12-07	1724	\N	6369	\N
25643	GENERIC_DAY	0	7	2009-12-29	1724	\N	6369	\N
25644	GENERIC_DAY	0	6	2009-12-17	1724	\N	6369	\N
25645	GENERIC_DAY	0	6	2009-12-14	1724	\N	6369	\N
25646	GENERIC_DAY	0	4	2009-12-18	1727	\N	6368	\N
25647	GENERIC_DAY	0	4	2009-12-16	1727	\N	6368	\N
25648	GENERIC_DAY	0	4	2009-12-08	1727	\N	6368	\N
25649	GENERIC_DAY	0	4	2009-12-22	1727	\N	6368	\N
25650	GENERIC_DAY	0	4	2009-12-17	1727	\N	6368	\N
25651	GENERIC_DAY	0	4	2009-12-23	1727	\N	6368	\N
25652	GENERIC_DAY	0	4	2009-12-31	1727	\N	6368	\N
25653	GENERIC_DAY	0	4	2009-12-21	1727	\N	6368	\N
25654	GENERIC_DAY	0	4	2009-12-19	1727	\N	6368	\N
25655	GENERIC_DAY	0	4	2009-12-26	1727	\N	6368	\N
25656	GENERIC_DAY	0	4	2009-12-12	1727	\N	6368	\N
25657	GENERIC_DAY	0	4	2009-12-30	1727	\N	6368	\N
25658	GENERIC_DAY	0	4	2009-12-25	1727	\N	6368	\N
25659	GENERIC_DAY	0	4	2009-12-20	1727	\N	6368	\N
25660	GENERIC_DAY	0	4	2009-12-29	1727	\N	6368	\N
25661	GENERIC_DAY	0	4	2009-12-27	1727	\N	6368	\N
48826	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077	\N
48827	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077	\N
48828	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077	\N
48829	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077	\N
48830	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077	\N
48831	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077	\N
48832	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013	\N
48833	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013	\N
48834	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013	\N
48835	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013	\N
48836	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013	\N
48837	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013	\N
48838	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013	\N
48839	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013	\N
48840	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013	\N
48841	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013	\N
48842	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013	\N
48843	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013	\N
48844	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013	\N
48845	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013	\N
48846	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013	\N
48847	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013	\N
48848	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013	\N
48849	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013	\N
48850	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013	\N
48851	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013	\N
48852	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013	\N
48853	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013	\N
48854	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013	\N
48855	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013	\N
48856	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013	\N
48857	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013	\N
48858	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013	\N
48859	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013	\N
25662	GENERIC_DAY	0	4	2009-12-07	1727	\N	6368	\N
25663	GENERIC_DAY	0	4	2009-12-10	1727	\N	6368	\N
25664	GENERIC_DAY	0	4	2009-12-11	1727	\N	6368	\N
25665	GENERIC_DAY	0	4	2009-12-13	1727	\N	6368	\N
25666	GENERIC_DAY	0	4	2009-12-14	1727	\N	6368	\N
25667	GENERIC_DAY	0	4	2009-12-28	1727	\N	6368	\N
25668	GENERIC_DAY	0	4	2009-12-15	1727	\N	6368	\N
25669	GENERIC_DAY	0	4	2009-12-09	1727	\N	6368	\N
25670	GENERIC_DAY	0	4	2009-12-24	1727	\N	6368	\N
48860	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013	\N
48861	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013	\N
48862	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013	\N
48863	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013	\N
48864	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013	\N
48865	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013	\N
48866	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013	\N
48867	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013	\N
48868	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013	\N
48869	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013	\N
48870	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013	\N
48871	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013	\N
48872	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013	\N
48873	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013	\N
48874	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013	\N
48875	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013	\N
48876	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013	\N
48877	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013	\N
48878	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013	\N
48879	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013	\N
48880	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013	\N
48881	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013	\N
48882	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013	\N
48883	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013	\N
48884	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013	\N
48885	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013	\N
48886	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013	\N
48887	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013	\N
48888	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013	\N
48889	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013	\N
48890	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013	\N
48891	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013	\N
48892	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013	\N
48893	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013	\N
48894	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013	\N
48895	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013	\N
48896	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013	\N
48897	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013	\N
48898	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013	\N
48899	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013	\N
48900	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013	\N
48901	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013	\N
48902	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013	\N
48903	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013	\N
48904	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013	\N
48905	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013	\N
48906	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013	\N
48907	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013	\N
48908	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013	\N
48909	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013	\N
48910	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013	\N
48911	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013	\N
48912	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013	\N
48913	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013	\N
48914	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013	\N
48915	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013	\N
48916	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013	\N
48917	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013	\N
48918	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013	\N
48931	GENERIC_DAY	3	0	2010-01-19	37573	\N	41061	\N
48932	GENERIC_DAY	3	1	2010-01-20	36159	\N	41061	\N
48933	GENERIC_DAY	3	3	2010-01-19	40199	\N	41061	\N
48934	GENERIC_DAY	3	4	2010-01-20	40199	\N	41061	\N
48935	GENERIC_DAY	3	3	2010-01-19	36159	\N	41061	\N
48936	GENERIC_DAY	3	0	2010-01-20	37573	\N	41061	\N
48937	GENERIC_DAY	3	1	2010-01-21	36159	\N	41051	\N
48938	GENERIC_DAY	3	1	2010-01-21	37573	\N	41051	\N
48939	GENERIC_DAY	3	2	2010-01-21	40199	\N	41051	\N
48940	GENERIC_DAY	3	1	2010-01-22	36159	\N	41052	\N
48941	GENERIC_DAY	3	1	2010-01-22	40199	\N	41052	\N
48942	GENERIC_DAY	3	2	2010-01-22	37573	\N	41052	\N
48943	GENERIC_DAY	3	0	2010-01-23	37573	\N	41053	\N
48944	GENERIC_DAY	3	0	2010-01-24	40199	\N	41053	\N
48945	GENERIC_DAY	3	0	2010-01-23	36159	\N	41053	\N
48946	GENERIC_DAY	3	1	2010-01-25	40199	\N	41053	\N
48947	GENERIC_DAY	3	0	2010-01-23	40199	\N	41053	\N
48948	GENERIC_DAY	3	0	2010-01-24	36159	\N	41053	\N
48949	GENERIC_DAY	3	2	2010-01-25	37573	\N	41053	\N
48950	GENERIC_DAY	3	1	2010-01-25	36159	\N	41053	\N
48951	GENERIC_DAY	3	0	2010-01-24	37573	\N	41053	\N
24595	GENERIC_DAY	1	2	2010-02-05	1726	\N	19899	\N
24578	GENERIC_DAY	1	3	2010-01-19	1726	\N	19899	\N
24575	GENERIC_DAY	1	2	2010-01-13	1718	\N	19899	\N
24583	GENERIC_DAY	1	3	2010-01-06	1726	\N	19899	\N
24598	GENERIC_DAY	1	3	2010-01-07	1726	\N	19899	\N
24580	GENERIC_DAY	1	0	2010-01-30	1722	\N	19899	\N
24581	GENERIC_DAY	1	2	2010-02-02	1718	\N	19899	\N
24597	GENERIC_DAY	1	0	2010-01-17	1722	\N	19899	\N
24587	GENERIC_DAY	1	2	2010-02-02	1722	\N	19899	\N
24596	GENERIC_DAY	1	2	2010-02-02	1726	\N	19899	\N
24588	GENERIC_DAY	1	2	2010-01-29	1718	\N	19899	\N
24585	GENERIC_DAY	1	2	2010-01-22	1722	\N	19899	\N
24589	GENERIC_DAY	1	3	2010-01-12	1726	\N	19899	\N
24591	GENERIC_DAY	1	0	2009-12-27	1722	\N	19899	\N
24590	GENERIC_DAY	1	0	2010-01-01	1726	\N	19899	\N
24582	GENERIC_DAY	1	3	2009-12-22	1718	\N	19899	\N
24576	GENERIC_DAY	1	0	2009-12-20	1718	\N	19899	\N
24594	GENERIC_DAY	1	0	2010-01-31	1722	\N	19899	\N
24584	GENERIC_DAY	1	0	2010-01-16	1718	\N	19899	\N
24593	GENERIC_DAY	1	2	2009-12-30	1726	\N	19899	\N
24579	GENERIC_DAY	1	2	2010-01-15	1722	\N	19899	\N
24586	GENERIC_DAY	1	2	2010-01-11	1722	\N	19899	\N
24592	GENERIC_DAY	1	2	2010-01-05	1726	\N	19899	\N
24577	GENERIC_DAY	1	2	2010-01-06	1722	\N	19899	\N
37481	GENERIC_DAY	15	0	2010-01-27	36159	\N	36966	\N
37511	GENERIC_DAY	15	1	2010-03-22	36159	\N	36966	\N
37495	GENERIC_DAY	15	0	2010-02-27	36159	\N	36966	\N
37488	GENERIC_DAY	15	1	2010-03-18	36159	\N	36966	\N
37473	GENERIC_DAY	15	0	2010-02-14	36159	\N	36966	\N
37493	GENERIC_DAY	15	1	2010-01-25	36159	\N	36966	\N
37504	GENERIC_DAY	15	0	2010-01-29	36159	\N	36966	\N
37498	GENERIC_DAY	15	2	2010-02-17	36159	\N	36966	\N
37474	GENERIC_DAY	15	0	2010-02-02	36159	\N	36966	\N
37516	GENERIC_DAY	15	0	2010-02-09	36159	\N	36966	\N
37514	GENERIC_DAY	15	2	2010-02-16	36159	\N	36966	\N
37499	GENERIC_DAY	15	0	2010-02-20	36159	\N	36966	\N
37475	GENERIC_DAY	15	0	2010-02-12	36159	\N	36966	\N
37480	GENERIC_DAY	15	1	2010-03-04	36159	\N	36966	\N
37519	GENERIC_DAY	15	0	2010-01-24	36159	\N	36966	\N
37491	GENERIC_DAY	15	1	2010-03-02	36159	\N	36966	\N
37489	GENERIC_DAY	15	0	2010-01-23	36159	\N	36966	\N
37500	GENERIC_DAY	15	0	2010-02-08	36159	\N	36966	\N
37513	GENERIC_DAY	15	1	2010-03-25	36159	\N	36966	\N
37517	GENERIC_DAY	15	1	2010-02-26	36159	\N	36966	\N
45788	GENERIC_DAY	6	0	2010-01-25	36159	\N	41069	\N
37529	GENERIC_DAY	15	0	2010-02-28	36159	\N	36966	\N
37531	GENERIC_DAY	15	0	2010-01-28	36159	\N	36966	\N
37526	GENERIC_DAY	15	1	2010-02-18	36159	\N	36966	\N
37522	GENERIC_DAY	15	1	2010-01-22	36159	\N	36966	\N
37528	GENERIC_DAY	15	1	2010-03-11	36159	\N	36966	\N
37524	GENERIC_DAY	15	1	2010-02-24	36159	\N	36966	\N
37521	GENERIC_DAY	15	0	2010-01-31	36159	\N	36966	\N
37530	GENERIC_DAY	15	0	2010-02-03	36159	\N	36966	\N
37533	GENERIC_DAY	15	1	2010-03-12	36159	\N	36966	\N
37532	GENERIC_DAY	15	0	2010-02-21	36159	\N	36966	\N
37527	GENERIC_DAY	15	0	2010-02-04	36159	\N	36966	\N
37523	GENERIC_DAY	15	1	2010-03-23	36159	\N	36966	\N
37525	GENERIC_DAY	15	0	2010-03-06	36159	\N	36966	\N
43115	GENERIC_DAY	10	0	2010-01-22	36159	\N	41054	\N
43078	GENERIC_DAY	10	0	2010-02-02	37573	\N	41054	\N
43082	GENERIC_DAY	10	1	2010-01-28	40199	\N	41054	\N
43086	GENERIC_DAY	10	0	2010-01-30	37573	\N	41054	\N
43055	GENERIC_DAY	10	1	2010-01-19	40199	\N	41054	\N
43107	GENERIC_DAY	10	0	2010-02-02	36159	\N	41054	\N
43111	GENERIC_DAY	10	0	2010-01-18	37573	\N	41054	\N
43072	GENERIC_DAY	10	0	2010-01-19	37573	\N	41054	\N
43109	GENERIC_DAY	10	0	2010-02-07	36159	\N	41054	\N
43087	GENERIC_DAY	10	0	2010-02-10	40199	\N	41054	\N
43077	GENERIC_DAY	10	0	2010-01-31	37573	\N	41054	\N
43106	GENERIC_DAY	10	0	2010-02-07	40199	\N	41054	\N
43074	GENERIC_DAY	10	0	2010-01-31	36159	\N	41054	\N
43116	GENERIC_DAY	10	0	2010-01-25	37573	\N	41054	\N
43062	GENERIC_DAY	10	0	2010-01-11	40199	\N	41054	\N
43061	GENERIC_DAY	10	0	2010-01-29	37573	\N	41054	\N
43108	GENERIC_DAY	10	1	2010-01-11	36159	\N	41054	\N
43089	GENERIC_DAY	10	1	2010-01-20	40199	\N	41054	\N
43063	GENERIC_DAY	10	0	2010-01-17	40199	\N	41054	\N
43088	GENERIC_DAY	10	1	2010-01-27	40199	\N	41054	\N
43113	GENERIC_DAY	10	0	2010-01-15	36159	\N	41054	\N
43052	GENERIC_DAY	10	0	2010-01-22	40199	\N	41054	\N
43050	GENERIC_DAY	10	0	2010-02-06	40199	\N	41054	\N
43104	GENERIC_DAY	10	1	2010-01-21	37573	\N	41054	\N
37482	GENERIC_DAY	15	0	2010-02-15	36159	\N	36966	\N
37471	GENERIC_DAY	15	1	2010-03-09	36159	\N	36966	\N
37476	GENERIC_DAY	15	1	2010-03-08	36159	\N	36966	\N
37509	GENERIC_DAY	15	1	2010-03-15	36159	\N	36966	\N
37501	GENERIC_DAY	15	0	2010-03-20	36159	\N	36966	\N
37485	GENERIC_DAY	15	1	2010-03-10	36159	\N	36966	\N
37515	GENERIC_DAY	15	0	2010-03-07	36159	\N	36966	\N
37496	GENERIC_DAY	15	0	2010-03-14	36159	\N	36966	\N
37506	GENERIC_DAY	15	0	2010-02-10	36159	\N	36966	\N
37508	GENERIC_DAY	15	1	2010-03-16	36159	\N	36966	\N
37510	GENERIC_DAY	15	1	2010-03-17	36159	\N	36966	\N
37492	GENERIC_DAY	15	1	2010-02-23	36159	\N	36966	\N
37502	GENERIC_DAY	15	0	2010-02-07	36159	\N	36966	\N
37483	GENERIC_DAY	15	0	2010-02-13	36159	\N	36966	\N
37497	GENERIC_DAY	15	1	2010-01-26	36159	\N	36966	\N
37477	GENERIC_DAY	15	1	2010-02-22	36159	\N	36966	\N
37479	GENERIC_DAY	15	0	2010-02-05	36159	\N	36966	\N
37512	GENERIC_DAY	15	0	2010-02-01	36159	\N	36966	\N
37490	GENERIC_DAY	15	1	2010-03-24	36159	\N	36966	\N
37487	GENERIC_DAY	15	0	2010-02-11	36159	\N	36966	\N
37472	GENERIC_DAY	15	1	2010-03-05	36159	\N	36966	\N
37486	GENERIC_DAY	15	1	2010-03-03	36159	\N	36966	\N
37478	GENERIC_DAY	15	0	2010-02-06	36159	\N	36966	\N
37518	GENERIC_DAY	15	0	2010-03-21	36159	\N	36966	\N
37520	GENERIC_DAY	15	1	2010-02-25	36159	\N	36966	\N
37494	GENERIC_DAY	15	1	2010-03-19	36159	\N	36966	\N
37484	GENERIC_DAY	15	0	2010-03-13	36159	\N	36966	\N
37505	GENERIC_DAY	15	1	2010-02-19	36159	\N	36966	\N
37507	GENERIC_DAY	15	1	2010-03-01	36159	\N	36966	\N
37503	GENERIC_DAY	15	0	2010-01-30	36159	\N	36966	\N
37545	GENERIC_DAY	13	0	2010-01-31	37573	\N	38582	\N
37548	GENERIC_DAY	13	0	2010-01-23	37573	\N	38582	\N
37567	GENERIC_DAY	13	1	2010-02-19	36159	\N	38582	\N
37538	GENERIC_DAY	13	0	2010-01-30	37573	\N	38582	\N
37539	GENERIC_DAY	13	2	2010-01-27	37573	\N	38582	\N
37534	GENERIC_DAY	13	0	2010-02-07	36159	\N	38582	\N
37542	GENERIC_DAY	13	1	2010-02-10	37573	\N	38582	\N
37562	GENERIC_DAY	13	2	2010-01-29	37573	\N	38582	\N
37535	GENERIC_DAY	13	0	2010-02-21	37573	\N	38582	\N
37563	GENERIC_DAY	13	0	2010-02-06	37573	\N	38582	\N
37565	GENERIC_DAY	13	0	2010-01-24	36159	\N	38582	\N
37558	GENERIC_DAY	13	2	2010-02-02	36159	\N	38582	\N
37564	GENERIC_DAY	13	2	2010-02-12	36159	\N	38582	\N
37568	GENERIC_DAY	13	2	2010-01-28	37573	\N	38582	\N
37543	GENERIC_DAY	13	0	2010-02-14	36159	\N	38582	\N
37557	GENERIC_DAY	13	2	2010-01-26	37573	\N	38582	\N
37551	GENERIC_DAY	13	1	2010-02-15	37573	\N	38582	\N
37540	GENERIC_DAY	13	0	2010-02-13	36159	\N	38582	\N
37541	GENERIC_DAY	13	1	2010-02-03	37573	\N	38582	\N
37554	GENERIC_DAY	13	2	2010-02-16	37573	\N	38582	\N
37561	GENERIC_DAY	13	2	2010-01-25	36159	\N	38582	\N
37549	GENERIC_DAY	13	2	2010-02-15	36159	\N	38582	\N
37560	GENERIC_DAY	13	2	2010-02-17	37573	\N	38582	\N
37546	GENERIC_DAY	13	2	2010-01-28	36159	\N	38582	\N
37544	GENERIC_DAY	13	2	2010-02-10	36159	\N	38582	\N
37559	GENERIC_DAY	13	0	2010-01-23	36159	\N	38582	\N
37550	GENERIC_DAY	13	2	2010-02-19	37573	\N	38582	\N
37536	GENERIC_DAY	13	2	2010-02-18	37573	\N	38582	\N
37566	GENERIC_DAY	13	2	2010-02-05	36159	\N	38582	\N
37556	GENERIC_DAY	13	2	2010-01-25	37573	\N	38582	\N
37553	GENERIC_DAY	13	2	2010-01-29	36159	\N	38582	\N
37555	GENERIC_DAY	13	1	2010-02-05	37573	\N	38582	\N
37547	GENERIC_DAY	13	1	2010-02-04	37573	\N	38582	\N
37537	GENERIC_DAY	13	2	2010-02-11	36159	\N	38582	\N
37552	GENERIC_DAY	13	2	2010-02-01	37573	\N	38582	\N
24901	GENERIC_DAY	1	2	2010-03-10	1722	\N	19897	\N
24895	GENERIC_DAY	1	3	2010-02-24	1726	\N	19897	\N
24896	GENERIC_DAY	1	4	2010-02-19	1718	\N	19897	\N
24902	GENERIC_DAY	1	0	2010-02-21	1718	\N	19897	\N
24890	GENERIC_DAY	1	2	2010-03-09	1722	\N	19897	\N
24900	GENERIC_DAY	1	0	2010-03-21	1718	\N	19897	\N
24904	GENERIC_DAY	1	0	2010-03-21	1726	\N	19897	\N
24897	GENERIC_DAY	1	1	2010-02-26	1722	\N	19897	\N
24899	GENERIC_DAY	1	4	2010-03-24	1718	\N	19897	\N
24893	GENERIC_DAY	1	0	2010-02-14	1718	\N	19897	\N
24892	GENERIC_DAY	1	0	2010-03-13	1726	\N	19897	\N
24891	GENERIC_DAY	1	4	2010-03-25	1718	\N	19897	\N
24898	GENERIC_DAY	1	0	2010-03-21	1722	\N	19897	\N
24894	GENERIC_DAY	1	0	2010-03-20	1722	\N	19897	\N
24903	GENERIC_DAY	1	3	2010-03-16	1726	\N	19897	\N
38683	GENERIC_DAY	13	2	2010-01-22	37573	\N	38582	\N
38702	GENERIC_DAY	13	2	2010-02-08	36159	\N	38582	\N
38688	GENERIC_DAY	13	0	2010-02-20	36159	\N	38582	\N
38693	GENERIC_DAY	13	0	2010-02-14	37573	\N	38582	\N
38706	GENERIC_DAY	13	0	2010-02-06	36159	\N	38582	\N
38687	GENERIC_DAY	13	1	2010-02-17	36159	\N	38582	\N
38697	GENERIC_DAY	13	1	2010-02-08	37573	\N	38582	\N
38695	GENERIC_DAY	13	2	2010-01-22	36159	\N	38582	\N
38699	GENERIC_DAY	13	0	2010-02-07	37573	\N	38582	\N
38700	GENERIC_DAY	13	1	2010-02-18	36159	\N	38582	\N
47022	GENERIC_DAY	6	2	2010-01-27	36159	\N	41076	\N
47015	GENERIC_DAY	6	0	2010-01-28	37573	\N	41076	\N
47018	GENERIC_DAY	6	2	2010-01-27	37573	\N	41076	\N
38698	GENERIC_DAY	13	0	2010-01-24	37573	\N	38582	\N
37570	GENERIC_DAY	13	1	2010-02-16	36159	\N	38582	\N
38703	GENERIC_DAY	13	0	2010-01-31	36159	\N	38582	\N
38691	GENERIC_DAY	13	2	2010-02-09	36159	\N	38582	\N
37571	GENERIC_DAY	13	1	2010-02-11	37573	\N	38582	\N
38686	GENERIC_DAY	13	0	2010-02-20	37573	\N	38582	\N
38701	GENERIC_DAY	13	1	2010-02-02	37573	\N	38582	\N
38705	GENERIC_DAY	13	0	2010-01-30	36159	\N	38582	\N
38696	GENERIC_DAY	13	1	2010-02-09	37573	\N	38582	\N
38704	GENERIC_DAY	13	0	2010-02-13	37573	\N	38582	\N
38694	GENERIC_DAY	13	2	2010-02-01	36159	\N	38582	\N
38690	GENERIC_DAY	13	2	2010-02-03	36159	\N	38582	\N
38685	GENERIC_DAY	13	2	2010-01-26	36159	\N	38582	\N
38684	GENERIC_DAY	13	2	2010-02-04	36159	\N	38582	\N
37569	GENERIC_DAY	13	2	2010-01-27	36159	\N	38582	\N
38692	GENERIC_DAY	13	1	2010-02-12	37573	\N	38582	\N
38689	GENERIC_DAY	13	0	2010-02-21	36159	\N	38582	\N
45753	GENERIC_DAY	6	0	2010-02-01	36159	\N	41069	\N
45783	GENERIC_DAY	6	0	2010-01-14	36159	\N	41069	\N
45758	GENERIC_DAY	6	1	2010-01-22	40199	\N	41069	\N
45781	GENERIC_DAY	6	0	2010-01-30	36159	\N	41069	\N
45818	GENERIC_DAY	6	0	2010-01-23	37573	\N	41069	\N
45794	GENERIC_DAY	6	0	2010-01-17	40199	\N	41069	\N
45791	GENERIC_DAY	6	1	2010-01-21	36159	\N	41069	\N
45811	GENERIC_DAY	6	0	2010-02-05	36159	\N	41069	\N
45754	GENERIC_DAY	6	0	2010-01-31	37573	\N	41069	\N
45764	GENERIC_DAY	6	0	2010-01-22	36159	\N	41069	\N
45770	GENERIC_DAY	6	0	2010-01-31	36159	\N	41069	\N
45755	GENERIC_DAY	6	0	2010-02-07	40199	\N	41069	\N
45756	GENERIC_DAY	6	0	2010-02-06	40199	\N	41069	\N
45772	GENERIC_DAY	6	0	2010-02-05	40199	\N	41069	\N
45787	GENERIC_DAY	6	1	2010-01-14	40199	\N	41069	\N
30814	SPECIFIC_DAY	0	8	2010-01-08	1722	29807	\N	\N
30815	SPECIFIC_DAY	0	0	2010-01-10	1722	29807	\N	\N
30816	SPECIFIC_DAY	0	0	2010-01-09	1722	29807	\N	\N
30817	SPECIFIC_DAY	0	8	2010-01-18	1722	29807	\N	\N
30818	SPECIFIC_DAY	0	8	2010-01-11	1722	29807	\N	\N
30819	SPECIFIC_DAY	0	8	2010-01-07	1722	29807	\N	\N
30820	SPECIFIC_DAY	0	8	2010-01-12	1722	29807	\N	\N
30821	SPECIFIC_DAY	0	8	2010-01-15	1722	29807	\N	\N
30822	SPECIFIC_DAY	0	8	2010-01-14	1722	29807	\N	\N
30823	SPECIFIC_DAY	0	8	2010-01-13	1722	29807	\N	\N
30824	SPECIFIC_DAY	0	0	2010-01-17	1722	29807	\N	\N
30825	SPECIFIC_DAY	0	0	2010-01-16	1722	29807	\N	\N
38723	GENERIC_DAY	6	0	2010-02-27	36159	\N	38583	\N
38726	GENERIC_DAY	6	5	2010-03-08	37573	\N	38583	\N
38727	GENERIC_DAY	6	5	2010-03-10	37573	\N	38583	\N
38724	GENERIC_DAY	6	5	2010-03-04	37573	\N	38583	\N
38722	GENERIC_DAY	6	0	2010-02-27	37573	\N	38583	\N
38729	GENERIC_DAY	6	4	2010-03-15	37573	\N	38583	\N
38728	GENERIC_DAY	6	5	2010-03-02	37573	\N	38583	\N
38719	GENERIC_DAY	6	4	2010-02-23	37573	\N	38583	\N
38721	GENERIC_DAY	6	0	2010-03-06	37573	\N	38583	\N
38720	GENERIC_DAY	6	3	2010-03-04	36159	\N	38583	\N
38718	GENERIC_DAY	6	4	2010-02-25	37573	\N	38583	\N
38717	GENERIC_DAY	6	0	2010-03-13	37573	\N	38583	\N
38725	GENERIC_DAY	6	3	2010-03-10	36159	\N	38583	\N
45751	GENERIC_DAY	6	0	2010-02-01	37573	\N	41069	\N
45761	GENERIC_DAY	6	0	2010-01-30	40199	\N	41069	\N
45789	GENERIC_DAY	6	1	2010-01-15	40199	\N	41069	\N
45785	GENERIC_DAY	6	0	2010-02-09	37573	\N	41069	\N
45769	GENERIC_DAY	6	0	2010-01-24	40199	\N	41069	\N
45782	GENERIC_DAY	6	0	2010-02-10	37573	\N	41069	\N
45810	GENERIC_DAY	6	0	2010-02-07	37573	\N	41069	\N
45775	GENERIC_DAY	6	0	2010-01-13	37573	\N	41069	\N
45757	GENERIC_DAY	6	1	2010-01-27	40199	\N	41069	\N
45808	GENERIC_DAY	6	0	2010-01-29	40199	\N	41069	\N
45793	GENERIC_DAY	6	0	2010-01-16	40199	\N	41069	\N
45816	GENERIC_DAY	6	0	2010-02-02	37573	\N	41069	\N
45777	GENERIC_DAY	6	1	2010-01-19	36159	\N	41069	\N
45790	GENERIC_DAY	6	0	2010-02-11	37573	\N	41069	\N
45795	GENERIC_DAY	6	0	2010-01-16	37573	\N	41069	\N
45786	GENERIC_DAY	6	0	2010-01-25	37573	\N	41069	\N
45763	GENERIC_DAY	6	0	2010-01-11	36159	\N	41069	\N
45767	GENERIC_DAY	6	0	2010-01-26	37573	\N	41069	\N
45780	GENERIC_DAY	6	0	2010-01-17	37573	\N	41069	\N
45809	GENERIC_DAY	6	0	2010-01-11	40199	\N	41069	\N
45779	GENERIC_DAY	6	0	2010-01-20	36159	\N	41069	\N
45762	GENERIC_DAY	6	0	2010-01-30	37573	\N	41069	\N
45768	GENERIC_DAY	6	0	2010-01-27	37573	\N	41069	\N
45759	GENERIC_DAY	6	1	2010-01-13	36159	\N	41069	\N
45812	GENERIC_DAY	6	0	2010-01-17	36159	\N	41069	\N
45773	GENERIC_DAY	6	0	2010-01-24	37573	\N	41069	\N
45817	GENERIC_DAY	6	0	2010-02-08	40199	\N	41069	\N
45814	GENERIC_DAY	6	0	2010-02-05	37573	\N	41069	\N
45776	GENERIC_DAY	6	0	2010-02-09	40199	\N	41069	\N
45774	GENERIC_DAY	6	0	2010-02-02	36159	\N	41069	\N
45778	GENERIC_DAY	6	1	2010-01-20	37573	\N	41069	\N
45813	GENERIC_DAY	6	1	2010-01-11	37573	\N	41069	\N
45752	GENERIC_DAY	6	0	2010-01-28	36159	\N	41069	\N
45765	GENERIC_DAY	6	0	2010-01-15	37573	\N	41069	\N
45815	GENERIC_DAY	6	0	2010-02-11	36159	\N	41069	\N
45766	GENERIC_DAY	6	1	2010-01-28	37573	\N	41069	\N
45760	GENERIC_DAY	6	0	2010-01-23	40199	\N	41069	\N
45771	GENERIC_DAY	6	0	2010-02-08	37573	\N	41069	\N
45792	GENERIC_DAY	6	0	2010-01-29	36159	\N	41069	\N
45784	GENERIC_DAY	6	0	2010-01-23	36159	\N	41069	\N
38731	GENERIC_DAY	6	0	2010-02-28	36159	\N	38583	\N
38755	GENERIC_DAY	6	5	2010-03-11	37573	\N	38583	\N
38748	GENERIC_DAY	6	4	2010-02-23	36159	\N	38583	\N
38740	GENERIC_DAY	6	5	2010-03-05	37573	\N	38583	\N
38760	GENERIC_DAY	6	3	2010-03-09	36159	\N	38583	\N
38754	GENERIC_DAY	6	0	2010-03-07	36159	\N	38583	\N
38758	GENERIC_DAY	6	5	2010-02-22	37573	\N	38583	\N
38749	GENERIC_DAY	6	3	2010-03-12	36159	\N	38583	\N
38738	GENERIC_DAY	6	4	2010-02-26	37573	\N	38583	\N
38750	GENERIC_DAY	6	5	2010-03-01	37573	\N	38583	\N
38739	GENERIC_DAY	6	0	2010-03-07	37573	\N	38583	\N
38743	GENERIC_DAY	6	2	2010-03-15	36159	\N	38583	\N
38737	GENERIC_DAY	6	0	2010-02-28	37573	\N	38583	\N
38751	GENERIC_DAY	6	4	2010-02-24	36159	\N	38583	\N
30826	GENERIC_DAY	3	3	2010-03-29	1724	\N	29808	\N
30827	GENERIC_DAY	3	3	2010-04-02	1724	\N	29808	\N
30828	GENERIC_DAY	3	3	2010-02-26	1724	\N	29808	\N
30829	GENERIC_DAY	3	3	2010-02-11	1724	\N	29808	\N
30830	GENERIC_DAY	3	2	2010-04-14	1724	\N	29808	\N
30831	GENERIC_DAY	3	3	2010-03-16	1724	\N	29808	\N
30832	GENERIC_DAY	3	3	2010-02-15	1724	\N	29808	\N
30833	GENERIC_DAY	3	3	2010-03-22	1724	\N	29808	\N
30834	GENERIC_DAY	3	3	2010-01-27	1724	\N	29808	\N
30835	GENERIC_DAY	3	3	2010-01-13	1724	\N	29808	\N
30836	GENERIC_DAY	3	3	2010-02-09	1724	\N	29808	\N
30837	GENERIC_DAY	3	3	2010-02-23	1724	\N	29808	\N
30838	GENERIC_DAY	3	3	2010-02-22	1724	\N	29808	\N
30839	GENERIC_DAY	3	3	2010-03-18	1724	\N	29808	\N
30840	GENERIC_DAY	3	2	2010-04-06	1724	\N	29808	\N
30841	GENERIC_DAY	3	3	2010-03-08	1724	\N	29808	\N
30842	GENERIC_DAY	3	3	2010-03-04	1724	\N	29808	\N
30843	GENERIC_DAY	3	3	2010-03-19	1724	\N	29808	\N
30844	GENERIC_DAY	3	0	2010-02-28	1724	\N	29808	\N
30845	GENERIC_DAY	3	3	2010-03-15	1724	\N	29808	\N
30846	GENERIC_DAY	3	3	2010-03-01	1724	\N	29808	\N
30847	GENERIC_DAY	3	0	2010-01-16	1724	\N	29808	\N
24498	GENERIC_DAY	4	11	2009-11-03	1727	\N	3955	\N
24509	GENERIC_DAY	4	10	2010-01-19	1727	\N	3955	\N
24504	GENERIC_DAY	4	10	2010-01-11	1727	\N	3955	\N
24499	GENERIC_DAY	4	10	2009-12-15	1727	\N	3955	\N
24493	GENERIC_DAY	4	10	2010-01-18	1727	\N	3955	\N
24497	GENERIC_DAY	4	10	2010-01-14	1727	\N	3955	\N
24508	GENERIC_DAY	4	10	2009-11-19	1727	\N	3955	\N
24496	GENERIC_DAY	4	2	2009-11-21	1727	\N	3955	\N
24494	GENERIC_DAY	4	2	2009-11-07	1727	\N	3955	\N
24500	GENERIC_DAY	4	2	2010-01-01	1727	\N	3955	\N
24510	GENERIC_DAY	4	10	2009-12-10	1727	\N	3955	\N
24502	GENERIC_DAY	4	2	2009-12-12	1727	\N	3955	\N
24505	GENERIC_DAY	4	10	2010-01-25	1727	\N	3955	\N
24501	GENERIC_DAY	4	10	2009-12-17	1727	\N	3955	\N
24512	GENERIC_DAY	4	10	2010-02-11	1727	\N	3955	\N
30848	GENERIC_DAY	3	2	2010-04-16	1724	\N	29808	\N
30849	GENERIC_DAY	3	0	2010-02-14	1724	\N	29808	\N
30850	GENERIC_DAY	3	0	2010-01-31	1724	\N	29808	\N
30851	GENERIC_DAY	3	3	2010-01-26	1724	\N	29808	\N
30852	GENERIC_DAY	3	3	2010-01-14	1724	\N	29808	\N
30853	GENERIC_DAY	3	3	2010-02-18	1724	\N	29808	\N
30854	GENERIC_DAY	3	3	2010-03-26	1724	\N	29808	\N
30855	GENERIC_DAY	3	0	2010-02-20	1724	\N	29808	\N
30856	GENERIC_DAY	3	3	2010-02-03	1724	\N	29808	\N
30857	GENERIC_DAY	3	0	2010-02-13	1724	\N	29808	\N
30858	GENERIC_DAY	3	3	2010-03-03	1724	\N	29808	\N
30859	GENERIC_DAY	3	2	2010-04-09	1724	\N	29808	\N
30860	GENERIC_DAY	3	0	2010-03-28	1724	\N	29808	\N
30861	GENERIC_DAY	3	0	2010-04-17	1724	\N	29808	\N
45801	GENERIC_DAY	6	0	2010-01-24	36159	\N	41069	\N
45796	GENERIC_DAY	6	0	2010-02-08	36159	\N	41069	\N
45797	GENERIC_DAY	6	0	2010-02-10	36159	\N	41069	\N
45800	GENERIC_DAY	6	0	2010-01-20	40199	\N	41069	\N
45798	GENERIC_DAY	6	0	2010-02-11	40199	\N	41069	\N
45807	GENERIC_DAY	6	0	2010-02-02	40199	\N	41069	\N
45804	GENERIC_DAY	6	0	2010-02-06	37573	\N	41069	\N
45805	GENERIC_DAY	6	0	2010-01-12	40199	\N	41069	\N
45806	GENERIC_DAY	6	0	2010-01-21	37573	\N	41069	\N
45802	GENERIC_DAY	6	0	2010-01-18	40199	\N	41069	\N
45799	GENERIC_DAY	6	0	2010-02-03	37573	\N	41069	\N
45803	GENERIC_DAY	6	0	2010-01-14	37573	\N	41069	\N
47797	GENERIC_DAY	3	2	2010-02-01	37573	\N	41077	\N
47798	GENERIC_DAY	3	1	2010-02-03	37573	\N	41077	\N
47799	GENERIC_DAY	3	2	2010-01-29	40199	\N	41077	\N
47800	GENERIC_DAY	3	1	2010-02-04	37573	\N	41077	\N
47801	GENERIC_DAY	3	2	2010-02-01	40199	\N	41077	\N
47802	GENERIC_DAY	3	2	2010-02-02	40199	\N	41077	\N
47803	GENERIC_DAY	3	1	2010-02-04	36159	\N	41077	\N
47804	GENERIC_DAY	3	0	2010-01-30	40199	\N	41077	\N
47805	GENERIC_DAY	3	2	2010-02-01	36159	\N	41077	\N
47806	GENERIC_DAY	3	1	2010-02-02	36159	\N	41077	\N
47807	GENERIC_DAY	3	0	2010-01-31	37573	\N	41077	\N
47808	GENERIC_DAY	3	2	2010-01-29	37573	\N	41077	\N
47809	GENERIC_DAY	3	2	2010-01-29	36159	\N	41077	\N
47810	GENERIC_DAY	3	2	2010-02-03	36159	\N	41077	\N
47811	GENERIC_DAY	3	0	2010-01-31	36159	\N	41077	\N
47812	GENERIC_DAY	3	2	2010-02-04	40199	\N	41077	\N
47813	GENERIC_DAY	3	3	2010-02-03	40199	\N	41077	\N
47814	GENERIC_DAY	3	3	2010-02-02	37573	\N	41077	\N
47815	GENERIC_DAY	3	0	2010-01-30	37573	\N	41077	\N
47816	GENERIC_DAY	3	0	2010-01-31	40199	\N	41077	\N
47817	GENERIC_DAY	3	0	2010-01-30	36159	\N	41077	\N
47818	GENERIC_DAY	3	0	2010-01-31	37573	\N	41013	\N
47819	GENERIC_DAY	3	1	2010-02-11	40199	\N	41013	\N
47820	GENERIC_DAY	3	1	2010-02-05	37573	\N	41013	\N
47821	GENERIC_DAY	3	2	2010-01-18	40199	\N	41013	\N
47822	GENERIC_DAY	3	1	2010-02-02	40199	\N	41013	\N
47823	GENERIC_DAY	3	1	2010-02-08	37573	\N	41013	\N
47824	GENERIC_DAY	3	1	2010-02-03	37573	\N	41013	\N
47825	GENERIC_DAY	3	3	2010-01-26	36159	\N	41013	\N
47826	GENERIC_DAY	3	0	2010-01-17	37573	\N	41013	\N
47827	GENERIC_DAY	3	1	2010-02-08	40199	\N	41013	\N
47828	GENERIC_DAY	3	0	2010-01-17	36159	\N	41013	\N
47829	GENERIC_DAY	3	2	2010-01-14	36159	\N	41013	\N
47830	GENERIC_DAY	3	2	2010-02-03	40199	\N	41013	\N
47831	GENERIC_DAY	3	1	2010-01-22	37573	\N	41013	\N
47832	GENERIC_DAY	3	0	2010-02-07	36159	\N	41013	\N
47833	GENERIC_DAY	3	2	2010-01-25	36159	\N	41013	\N
47834	GENERIC_DAY	3	0	2010-02-07	37573	\N	41013	\N
47835	GENERIC_DAY	3	1	2010-01-18	37573	\N	41013	\N
47836	GENERIC_DAY	3	1	2010-02-05	36159	\N	41013	\N
47837	GENERIC_DAY	3	1	2010-01-29	36159	\N	41013	\N
47838	GENERIC_DAY	3	0	2010-01-22	40199	\N	41013	\N
47839	GENERIC_DAY	3	1	2010-01-28	37573	\N	41013	\N
47840	GENERIC_DAY	3	0	2010-01-23	40199	\N	41013	\N
47841	GENERIC_DAY	3	1	2010-01-14	40199	\N	41013	\N
47842	GENERIC_DAY	3	0	2010-01-16	36159	\N	41013	\N
47843	GENERIC_DAY	3	1	2010-01-15	40199	\N	41013	\N
47844	GENERIC_DAY	3	0	2010-02-06	37573	\N	41013	\N
47845	GENERIC_DAY	3	2	2010-02-04	40199	\N	41013	\N
47846	GENERIC_DAY	3	1	2010-01-19	40199	\N	41013	\N
47847	GENERIC_DAY	3	0	2010-01-21	40199	\N	41013	\N
47848	GENERIC_DAY	3	1	2010-02-11	37573	\N	41013	\N
47849	GENERIC_DAY	3	0	2010-02-07	40199	\N	41013	\N
47850	GENERIC_DAY	3	1	2010-02-10	36159	\N	41013	\N
47851	GENERIC_DAY	3	1	2010-01-27	36159	\N	41013	\N
47852	GENERIC_DAY	3	1	2010-01-26	37573	\N	41013	\N
47853	GENERIC_DAY	3	0	2010-02-06	40199	\N	41013	\N
47854	GENERIC_DAY	3	1	2010-02-10	37573	\N	41013	\N
47855	GENERIC_DAY	3	1	2010-02-01	40199	\N	41013	\N
47856	GENERIC_DAY	3	0	2010-01-24	36159	\N	41013	\N
47857	GENERIC_DAY	3	1	2010-02-09	36159	\N	41013	\N
47858	GENERIC_DAY	3	1	2010-02-09	37573	\N	41013	\N
47859	GENERIC_DAY	3	1	2010-02-08	36159	\N	41013	\N
47860	GENERIC_DAY	3	1	2010-01-18	36159	\N	41013	\N
47861	GENERIC_DAY	3	2	2010-01-27	40199	\N	41013	\N
47862	GENERIC_DAY	3	1	2010-01-19	36159	\N	41013	\N
47863	GENERIC_DAY	3	2	2010-02-01	37573	\N	41013	\N
47864	GENERIC_DAY	3	1	2010-01-14	37573	\N	41013	\N
47865	GENERIC_DAY	3	0	2010-01-31	36159	\N	41013	\N
47866	GENERIC_DAY	3	2	2010-01-28	40199	\N	41013	\N
47867	GENERIC_DAY	3	1	2010-01-25	40199	\N	41013	\N
47868	GENERIC_DAY	3	1	2010-02-09	40199	\N	41013	\N
47869	GENERIC_DAY	3	0	2010-02-06	36159	\N	41013	\N
47870	GENERIC_DAY	3	1	2010-01-25	37573	\N	41013	\N
47871	GENERIC_DAY	3	2	2010-01-29	40199	\N	41013	\N
47872	GENERIC_DAY	3	0	2010-01-30	36159	\N	41013	\N
47873	GENERIC_DAY	3	1	2010-01-27	37573	\N	41013	\N
47874	GENERIC_DAY	3	0	2010-01-24	40199	\N	41013	\N
47875	GENERIC_DAY	3	0	2010-01-31	40199	\N	41013	\N
47876	GENERIC_DAY	3	0	2010-01-30	37573	\N	41013	\N
47877	GENERIC_DAY	3	2	2010-02-05	40199	\N	41013	\N
47878	GENERIC_DAY	3	0	2010-01-21	36159	\N	41013	\N
47879	GENERIC_DAY	3	2	2010-02-02	37573	\N	41013	\N
47880	GENERIC_DAY	3	1	2010-01-28	36159	\N	41013	\N
47881	GENERIC_DAY	3	0	2010-01-23	37573	\N	41013	\N
47882	GENERIC_DAY	3	4	2010-01-21	37573	\N	41013	\N
47883	GENERIC_DAY	3	0	2010-01-16	37573	\N	41013	\N
47884	GENERIC_DAY	3	1	2010-02-01	36159	\N	41013	\N
47885	GENERIC_DAY	3	1	2010-02-10	40199	\N	41013	\N
47886	GENERIC_DAY	3	2	2010-01-15	37573	\N	41013	\N
47887	GENERIC_DAY	3	1	2010-02-02	36159	\N	41013	\N
47888	GENERIC_DAY	3	1	2010-02-11	36159	\N	41013	\N
47889	GENERIC_DAY	3	0	2010-01-23	36159	\N	41013	\N
47890	GENERIC_DAY	3	1	2010-01-15	36159	\N	41013	\N
47891	GENERIC_DAY	3	0	2010-01-16	40199	\N	41013	\N
47892	GENERIC_DAY	3	1	2010-02-04	36159	\N	41013	\N
47893	GENERIC_DAY	3	0	2010-01-17	40199	\N	41013	\N
47894	GENERIC_DAY	3	1	2010-01-20	37573	\N	41013	\N
47895	GENERIC_DAY	3	1	2010-02-04	37573	\N	41013	\N
47896	GENERIC_DAY	3	0	2010-01-30	40199	\N	41013	\N
47020	GENERIC_DAY	6	2	2010-01-26	37573	\N	41076	\N
47021	GENERIC_DAY	6	0	2010-01-26	36159	\N	41076	\N
47014	GENERIC_DAY	6	4	2010-01-26	40199	\N	41076	\N
47019	GENERIC_DAY	6	1	2010-01-28	40199	\N	41076	\N
47017	GENERIC_DAY	6	2	2010-01-27	40199	\N	41076	\N
47016	GENERIC_DAY	6	1	2010-01-28	36159	\N	41076	\N
47897	GENERIC_DAY	3	2	2010-01-19	37573	\N	41013	\N
47898	GENERIC_DAY	3	3	2010-01-22	36159	\N	41013	\N
47899	GENERIC_DAY	3	1	2010-01-29	37573	\N	41013	\N
47900	GENERIC_DAY	3	1	2010-02-03	36159	\N	41013	\N
47901	GENERIC_DAY	3	0	2010-01-20	40199	\N	41013	\N
47902	GENERIC_DAY	3	0	2010-01-24	37573	\N	41013	\N
47903	GENERIC_DAY	3	0	2010-01-26	40199	\N	41013	\N
47904	GENERIC_DAY	3	3	2010-01-20	36159	\N	41013	\N
66203	SPECIFIC_DAY	5	2	2009-12-22	49289	66055	\N	\N
66224	SPECIFIC_DAY	5	0	2010-01-10	49289	66055	\N	\N
66237	SPECIFIC_DAY	5	0	2010-01-16	49289	66055	\N	\N
66235	SPECIFIC_DAY	5	0	2010-01-01	49289	66055	\N	\N
66242	SPECIFIC_DAY	5	2	2009-12-30	49289	66055	\N	\N
66243	SPECIFIC_DAY	5	0	2010-01-03	49289	66055	\N	\N
66209	SPECIFIC_DAY	5	2	2009-12-14	49289	66055	\N	\N
66227	SPECIFIC_DAY	5	2	2009-12-16	49289	66055	\N	\N
66238	SPECIFIC_DAY	5	2	2010-01-28	49289	66055	\N	\N
66241	SPECIFIC_DAY	5	2	2010-01-11	49289	66055	\N	\N
66240	SPECIFIC_DAY	5	0	2009-12-20	49289	66055	\N	\N
66206	SPECIFIC_DAY	5	2	2009-12-31	49289	66055	\N	\N
66222	SPECIFIC_DAY	5	2	2009-12-29	49289	66055	\N	\N
66236	SPECIFIC_DAY	5	2	2010-01-27	49289	66055	\N	\N
66216	SPECIFIC_DAY	5	0	2010-01-17	49289	66055	\N	\N
66030	SPECIFIC_DAY	5	0	2009-12-25	49304	61508	\N	\N
66015	SPECIFIC_DAY	5	0	2009-12-20	49304	61508	\N	\N
66027	SPECIFIC_DAY	5	0	2010-01-02	49304	61508	\N	\N
66041	SPECIFIC_DAY	5	0	2010-01-24	49304	61508	\N	\N
66051	SPECIFIC_DAY	5	4	2009-12-16	49304	61508	\N	\N
66021	SPECIFIC_DAY	5	3	2009-12-23	49304	61508	\N	\N
66020	SPECIFIC_DAY	5	4	2009-12-21	49304	61508	\N	\N
66026	SPECIFIC_DAY	5	3	2009-12-29	49304	61508	\N	\N
66008	SPECIFIC_DAY	5	4	2009-12-17	49304	61508	\N	\N
66033	SPECIFIC_DAY	5	0	2009-12-19	49304	61508	\N	\N
66029	SPECIFIC_DAY	5	3	2010-01-11	49304	61508	\N	\N
66042	SPECIFIC_DAY	5	0	2010-01-16	49304	61508	\N	\N
66052	SPECIFIC_DAY	5	0	2010-01-23	49304	61508	\N	\N
66049	SPECIFIC_DAY	5	3	2010-01-15	49304	61508	\N	\N
66044	SPECIFIC_DAY	5	3	2010-01-27	49304	61508	\N	\N
66047	SPECIFIC_DAY	5	4	2009-12-22	49304	61508	\N	\N
66040	SPECIFIC_DAY	5	3	2010-01-22	49304	61508	\N	\N
66028	SPECIFIC_DAY	5	0	2010-01-06	49304	61508	\N	\N
66011	SPECIFIC_DAY	5	3	2009-12-30	49304	61508	\N	\N
66019	SPECIFIC_DAY	5	0	2010-01-03	49304	61508	\N	\N
66039	SPECIFIC_DAY	5	3	2010-01-07	49304	61508	\N	\N
66025	SPECIFIC_DAY	5	3	2009-12-31	49304	61508	\N	\N
66043	SPECIFIC_DAY	5	0	2009-12-27	49304	61508	\N	\N
66018	SPECIFIC_DAY	5	3	2010-01-26	49304	61508	\N	\N
66046	SPECIFIC_DAY	5	3	2010-01-18	49304	61508	\N	\N
66010	SPECIFIC_DAY	5	0	2009-12-26	49304	61508	\N	\N
66013	SPECIFIC_DAY	5	3	2010-01-14	49304	61508	\N	\N
66034	SPECIFIC_DAY	5	3	2009-12-24	49304	61508	\N	\N
66016	SPECIFIC_DAY	5	3	2010-01-21	49304	61508	\N	\N
66022	SPECIFIC_DAY	5	4	2009-12-15	49304	61508	\N	\N
66045	SPECIFIC_DAY	5	4	2009-12-14	49304	61508	\N	\N
66009	SPECIFIC_DAY	5	4	2009-12-18	49304	61508	\N	\N
66050	SPECIFIC_DAY	5	3	2010-01-08	49304	61508	\N	\N
66036	SPECIFIC_DAY	5	3	2010-01-19	49304	61508	\N	\N
66031	SPECIFIC_DAY	5	3	2009-12-28	49304	61508	\N	\N
66012	SPECIFIC_DAY	5	0	2010-01-01	49304	61508	\N	\N
66048	SPECIFIC_DAY	5	3	2010-01-28	49304	61508	\N	\N
66037	SPECIFIC_DAY	5	0	2010-01-09	49304	61508	\N	\N
66053	SPECIFIC_DAY	5	0	2010-01-17	49304	61508	\N	\N
66017	SPECIFIC_DAY	5	3	2010-01-04	49304	61508	\N	\N
66024	SPECIFIC_DAY	5	0	2010-01-10	49304	61508	\N	\N
66035	SPECIFIC_DAY	5	3	2010-01-20	49304	61508	\N	\N
66032	SPECIFIC_DAY	5	3	2010-01-05	49304	61508	\N	\N
66023	SPECIFIC_DAY	5	3	2010-01-25	49304	61508	\N	\N
66014	SPECIFIC_DAY	5	3	2010-01-12	49304	61508	\N	\N
66038	SPECIFIC_DAY	5	3	2010-01-13	49304	61508	\N	\N
66155	SPECIFIC_DAY	5	2	2010-01-28	49302	66054	\N	\N
66165	SPECIFIC_DAY	5	2	2009-12-21	49302	66054	\N	\N
66160	SPECIFIC_DAY	5	0	2009-12-19	49302	66054	\N	\N
66198	SPECIFIC_DAY	5	2	2010-01-19	49302	66054	\N	\N
66163	SPECIFIC_DAY	5	2	2010-01-22	49302	66054	\N	\N
66168	SPECIFIC_DAY	5	2	2010-01-13	49302	66054	\N	\N
66195	SPECIFIC_DAY	5	0	2010-01-24	49302	66054	\N	\N
66188	SPECIFIC_DAY	5	0	2010-01-16	49302	66054	\N	\N
66199	SPECIFIC_DAY	5	0	2010-01-17	49302	66054	\N	\N
66159	SPECIFIC_DAY	5	2	2010-01-25	49302	66054	\N	\N
66200	SPECIFIC_DAY	5	2	2009-12-24	49302	66054	\N	\N
66189	SPECIFIC_DAY	5	2	2009-12-15	49302	66054	\N	\N
66162	SPECIFIC_DAY	5	2	2009-12-18	49302	66054	\N	\N
66192	SPECIFIC_DAY	5	2	2010-01-15	49302	66054	\N	\N
66178	SPECIFIC_DAY	5	2	2009-12-17	49302	66054	\N	\N
66179	SPECIFIC_DAY	5	2	2010-01-27	49302	66054	\N	\N
66180	SPECIFIC_DAY	5	2	2010-01-14	49302	66054	\N	\N
66158	SPECIFIC_DAY	5	2	2010-01-21	49302	66054	\N	\N
66190	SPECIFIC_DAY	5	0	2010-01-01	49302	66054	\N	\N
66177	SPECIFIC_DAY	5	0	2010-01-23	49302	66054	\N	\N
66156	SPECIFIC_DAY	5	0	2010-01-06	49302	66054	\N	\N
66172	SPECIFIC_DAY	5	2	2010-01-18	49302	66054	\N	\N
66169	SPECIFIC_DAY	5	2	2010-01-07	49302	66054	\N	\N
66191	SPECIFIC_DAY	5	2	2010-01-12	49302	66054	\N	\N
66182	SPECIFIC_DAY	5	2	2010-01-26	49302	66054	\N	\N
66171	SPECIFIC_DAY	5	2	2010-01-08	49302	66054	\N	\N
66164	SPECIFIC_DAY	5	2	2009-12-22	49302	66054	\N	\N
69217	SPECIFIC_DAY	5	4	2009-12-15	49289	68695	\N	\N
69228	SPECIFIC_DAY	5	4	2009-12-22	49289	68695	\N	\N
69213	SPECIFIC_DAY	5	0	2010-01-02	49289	68695	\N	\N
69215	SPECIFIC_DAY	5	4	2009-12-21	49289	68695	\N	\N
69218	SPECIFIC_DAY	5	4	2009-12-18	49289	68695	\N	\N
69220	SPECIFIC_DAY	5	4	2009-12-23	49289	68695	\N	\N
69221	SPECIFIC_DAY	5	4	2009-12-14	49289	68695	\N	\N
69225	SPECIFIC_DAY	5	4	2009-12-17	49289	68695	\N	\N
69230	SPECIFIC_DAY	5	0	2009-12-27	49289	68695	\N	\N
69222	SPECIFIC_DAY	5	0	2009-12-26	49289	68695	\N	\N
59571	SPECIFIC_DAY	25	7	2009-12-18	37573	59218	\N	\N
59576	SPECIFIC_DAY	25	0	2009-12-19	37573	59218	\N	\N
59579	SPECIFIC_DAY	25	7	2009-12-17	37573	59218	\N	\N
59573	SPECIFIC_DAY	25	0	2009-12-20	37573	59218	\N	\N
59570	SPECIFIC_DAY	25	7	2009-12-22	37573	59218	\N	\N
59575	SPECIFIC_DAY	25	7	2009-12-14	37573	59218	\N	\N
59574	SPECIFIC_DAY	25	7	2009-12-21	37573	59218	\N	\N
59577	SPECIFIC_DAY	25	7	2009-12-15	37573	59218	\N	\N
59572	SPECIFIC_DAY	25	7	2009-12-23	37573	59218	\N	\N
59578	SPECIFIC_DAY	25	7	2009-12-16	37573	59218	\N	\N
69183	SPECIFIC_DAY	5	0	2010-01-03	49289	68692	\N	\N
69182	SPECIFIC_DAY	5	1	2010-01-25	49289	68692	\N	\N
69164	SPECIFIC_DAY	5	1	2010-01-05	49289	68692	\N	\N
69166	SPECIFIC_DAY	5	0	2010-01-09	49289	68692	\N	\N
69167	SPECIFIC_DAY	5	1	2010-01-27	49289	68692	\N	\N
69178	SPECIFIC_DAY	5	0	2009-12-27	49289	68692	\N	\N
69150	SPECIFIC_DAY	5	1	2010-01-14	49289	68692	\N	\N
69171	SPECIFIC_DAY	5	1	2009-12-30	49289	68692	\N	\N
69158	SPECIFIC_DAY	5	1	2009-12-31	49289	68692	\N	\N
69173	SPECIFIC_DAY	5	0	2010-01-06	49289	68692	\N	\N
69172	SPECIFIC_DAY	5	1	2010-01-18	49289	68692	\N	\N
69162	SPECIFIC_DAY	5	1	2009-12-21	49289	68692	\N	\N
69146	SPECIFIC_DAY	5	1	2010-01-20	49289	68692	\N	\N
69159	SPECIFIC_DAY	5	1	2009-12-29	49289	68692	\N	\N
69181	SPECIFIC_DAY	5	1	2010-01-12	49289	68692	\N	\N
69184	SPECIFIC_DAY	5	1	2010-01-11	49289	68692	\N	\N
69179	SPECIFIC_DAY	5	1	2010-01-22	49289	68692	\N	\N
69189	SPECIFIC_DAY	5	0	2009-12-26	49289	68692	\N	\N
69163	SPECIFIC_DAY	5	1	2009-12-18	49289	68692	\N	\N
69169	SPECIFIC_DAY	5	1	2010-01-26	49289	68692	\N	\N
69180	SPECIFIC_DAY	5	0	2010-01-16	49289	68692	\N	\N
69153	SPECIFIC_DAY	5	0	2009-12-19	49289	68692	\N	\N
69160	SPECIFIC_DAY	5	0	2010-01-23	49289	68692	\N	\N
69149	SPECIFIC_DAY	5	1	2010-01-04	49289	68692	\N	\N
69148	SPECIFIC_DAY	5	0	2010-01-10	49289	68692	\N	\N
69177	SPECIFIC_DAY	5	1	2009-12-28	49289	68692	\N	\N
69161	SPECIFIC_DAY	5	2	2009-12-14	49289	68692	\N	\N
69185	SPECIFIC_DAY	5	2	2009-12-15	49289	68692	\N	\N
69190	SPECIFIC_DAY	5	0	2010-01-01	49289	68692	\N	\N
69176	SPECIFIC_DAY	5	2	2009-12-16	49289	68692	\N	\N
69168	SPECIFIC_DAY	5	1	2010-01-07	49289	68692	\N	\N
69187	SPECIFIC_DAY	5	1	2010-01-15	49289	68692	\N	\N
69152	SPECIFIC_DAY	5	0	2010-01-17	49289	68692	\N	\N
69175	SPECIFIC_DAY	5	2	2009-12-17	49289	68692	\N	\N
69170	SPECIFIC_DAY	5	0	2010-01-24	49289	68692	\N	\N
69145	SPECIFIC_DAY	5	1	2010-01-19	49289	68692	\N	\N
66655	SPECIFIC_DAY	5	4	2009-12-15	49289	66060	\N	\N
66694	SPECIFIC_DAY	5	0	2009-12-26	49289	66060	\N	\N
66684	SPECIFIC_DAY	5	0	2009-12-20	49289	66060	\N	\N
66659	SPECIFIC_DAY	5	4	2009-12-14	49289	66060	\N	\N
66683	SPECIFIC_DAY	5	4	2010-01-08	49289	66060	\N	\N
66657	SPECIFIC_DAY	5	3	2010-01-27	49289	66060	\N	\N
66653	SPECIFIC_DAY	5	0	2010-01-01	49289	66060	\N	\N
66662	SPECIFIC_DAY	5	3	2010-01-15	49289	66060	\N	\N
66654	SPECIFIC_DAY	5	4	2009-12-28	49289	66060	\N	\N
66670	SPECIFIC_DAY	5	0	2010-01-10	49289	66060	\N	\N
66682	SPECIFIC_DAY	5	3	2010-01-28	49289	66060	\N	\N
66673	SPECIFIC_DAY	5	3	2010-01-14	49289	66060	\N	\N
66669	SPECIFIC_DAY	5	4	2009-12-30	49289	66060	\N	\N
66671	SPECIFIC_DAY	5	0	2009-12-25	49289	66060	\N	\N
66689	SPECIFIC_DAY	5	3	2010-01-25	49289	66060	\N	\N
66675	SPECIFIC_DAY	5	4	2009-12-16	49289	66060	\N	\N
66664	SPECIFIC_DAY	5	4	2010-01-04	49289	66060	\N	\N
66656	SPECIFIC_DAY	5	3	2010-01-22	49289	66060	\N	\N
66652	SPECIFIC_DAY	5	4	2010-01-05	49289	66060	\N	\N
66666	SPECIFIC_DAY	5	3	2010-01-13	49289	66060	\N	\N
66680	SPECIFIC_DAY	5	4	2010-01-07	49289	66060	\N	\N
66677	SPECIFIC_DAY	5	0	2009-12-27	49289	66060	\N	\N
66658	SPECIFIC_DAY	5	0	2010-01-24	49289	66060	\N	\N
66685	SPECIFIC_DAY	5	0	2010-01-06	49289	66060	\N	\N
66660	SPECIFIC_DAY	5	4	2009-12-29	49289	66060	\N	\N
66661	SPECIFIC_DAY	5	0	2010-01-02	49289	66060	\N	\N
66691	SPECIFIC_DAY	5	3	2010-01-21	49289	66060	\N	\N
66665	SPECIFIC_DAY	5	0	2010-01-17	49289	66060	\N	\N
66681	SPECIFIC_DAY	5	4	2009-12-23	49289	66060	\N	\N
66693	SPECIFIC_DAY	5	4	2009-12-24	49289	66060	\N	\N
66679	SPECIFIC_DAY	5	4	2009-12-18	49289	66060	\N	\N
66672	SPECIFIC_DAY	5	0	2010-01-03	49289	66060	\N	\N
66696	SPECIFIC_DAY	5	4	2010-01-11	49289	66060	\N	\N
66690	SPECIFIC_DAY	5	4	2009-12-21	49289	66060	\N	\N
66667	SPECIFIC_DAY	5	4	2009-12-31	49289	66060	\N	\N
66678	SPECIFIC_DAY	5	3	2010-01-26	49289	66060	\N	\N
66686	SPECIFIC_DAY	5	3	2010-01-20	49289	66060	\N	\N
66688	SPECIFIC_DAY	5	4	2009-12-17	49289	66060	\N	\N
66674	SPECIFIC_DAY	5	0	2010-01-16	49289	66060	\N	\N
66651	SPECIFIC_DAY	5	3	2010-01-18	49289	66060	\N	\N
66676	SPECIFIC_DAY	5	0	2009-12-19	49289	66060	\N	\N
66692	SPECIFIC_DAY	5	4	2009-12-22	49289	66060	\N	\N
66695	SPECIFIC_DAY	5	4	2010-01-12	49289	66060	\N	\N
66687	SPECIFIC_DAY	5	3	2010-01-19	49289	66060	\N	\N
66668	SPECIFIC_DAY	5	0	2010-01-23	49289	66060	\N	\N
66663	SPECIFIC_DAY	5	0	2010-01-09	49289	66060	\N	\N
66741	SPECIFIC_DAY	5	0	2010-01-10	49302	66061	\N	\N
66740	SPECIFIC_DAY	5	4	2010-01-04	49302	66061	\N	\N
66709	SPECIFIC_DAY	5	3	2010-01-20	49302	66061	\N	\N
66718	SPECIFIC_DAY	5	3	2010-01-26	49302	66061	\N	\N
66713	SPECIFIC_DAY	5	3	2010-01-22	49302	66061	\N	\N
66715	SPECIFIC_DAY	5	3	2010-01-14	49302	66061	\N	\N
68820	SPECIFIC_DAY	5	7	2009-12-15	49297	68683	\N	\N
68819	SPECIFIC_DAY	5	7	2009-12-14	49297	68683	\N	\N
60266	SPECIFIC_DAY	16	7	2009-12-14	36159	59284	\N	\N
60264	SPECIFIC_DAY	16	0	2009-12-19	36159	59284	\N	\N
60262	SPECIFIC_DAY	16	7	2009-12-18	36159	59284	\N	\N
60268	SPECIFIC_DAY	16	7	2009-12-17	36159	59284	\N	\N
60267	SPECIFIC_DAY	16	0	2009-12-20	36159	59284	\N	\N
60263	SPECIFIC_DAY	16	7	2009-12-21	36159	59284	\N	\N
60261	SPECIFIC_DAY	16	7	2009-12-16	36159	59284	\N	\N
60265	SPECIFIC_DAY	16	7	2009-12-15	36159	59284	\N	\N
61024	SPECIFIC_DAY	16	7	2009-12-17	36159	60445	\N	\N
61023	SPECIFIC_DAY	16	7	2009-12-14	36159	60445	\N	\N
61027	SPECIFIC_DAY	16	7	2009-12-15	36159	60445	\N	\N
61022	SPECIFIC_DAY	16	0	2009-12-19	36159	60445	\N	\N
61021	SPECIFIC_DAY	16	7	2009-12-16	36159	60445	\N	\N
61028	SPECIFIC_DAY	16	7	2009-12-18	36159	60445	\N	\N
61026	SPECIFIC_DAY	16	0	2009-12-20	36159	60445	\N	\N
61025	SPECIFIC_DAY	16	7	2009-12-21	36159	60445	\N	\N
66225	SPECIFIC_DAY	5	2	2009-12-21	49289	66055	\N	\N
66211	SPECIFIC_DAY	5	2	2010-01-18	49289	66055	\N	\N
66246	SPECIFIC_DAY	5	0	2010-01-23	49289	66055	\N	\N
66204	SPECIFIC_DAY	5	2	2010-01-05	49289	66055	\N	\N
66228	SPECIFIC_DAY	5	2	2010-01-13	49289	66055	\N	\N
66234	SPECIFIC_DAY	5	0	2009-12-19	49289	66055	\N	\N
66220	SPECIFIC_DAY	5	2	2009-12-23	49289	66055	\N	\N
66239	SPECIFIC_DAY	5	2	2010-01-22	49289	66055	\N	\N
66218	SPECIFIC_DAY	5	2	2009-12-28	49289	66055	\N	\N
66230	SPECIFIC_DAY	5	2	2009-12-15	49289	66055	\N	\N
66231	SPECIFIC_DAY	5	0	2010-01-02	49289	66055	\N	\N
66223	SPECIFIC_DAY	5	0	2010-01-06	49289	66055	\N	\N
66214	SPECIFIC_DAY	5	2	2010-01-14	49289	66055	\N	\N
66207	SPECIFIC_DAY	5	2	2010-01-26	49289	66055	\N	\N
66208	SPECIFIC_DAY	5	0	2009-12-27	49289	66055	\N	\N
66244	SPECIFIC_DAY	5	2	2009-12-24	49289	66055	\N	\N
66205	SPECIFIC_DAY	5	2	2010-01-04	49289	66055	\N	\N
66217	SPECIFIC_DAY	5	2	2009-12-17	49289	66055	\N	\N
66245	SPECIFIC_DAY	5	2	2010-01-25	49289	66055	\N	\N
66212	SPECIFIC_DAY	5	0	2009-12-25	49289	66055	\N	\N
66226	SPECIFIC_DAY	5	2	2010-01-15	49289	66055	\N	\N
66232	SPECIFIC_DAY	5	2	2010-01-19	49289	66055	\N	\N
66215	SPECIFIC_DAY	5	2	2009-12-18	49289	66055	\N	\N
66213	SPECIFIC_DAY	5	2	2010-01-21	49289	66055	\N	\N
66219	SPECIFIC_DAY	5	2	2010-01-12	49289	66055	\N	\N
66202	SPECIFIC_DAY	5	2	2010-01-20	49289	66055	\N	\N
66221	SPECIFIC_DAY	5	0	2010-01-09	49289	66055	\N	\N
66201	SPECIFIC_DAY	5	0	2009-12-26	49289	66055	\N	\N
66229	SPECIFIC_DAY	5	2	2010-01-08	49289	66055	\N	\N
66210	SPECIFIC_DAY	5	2	2010-01-07	49289	66055	\N	\N
66233	SPECIFIC_DAY	5	0	2010-01-24	49289	66055	\N	\N
66197	SPECIFIC_DAY	5	2	2010-01-04	49302	66054	\N	\N
66157	SPECIFIC_DAY	5	0	2009-12-20	49302	66054	\N	\N
66167	SPECIFIC_DAY	5	2	2009-12-14	49302	66054	\N	\N
66196	SPECIFIC_DAY	5	2	2009-12-28	49302	66054	\N	\N
66194	SPECIFIC_DAY	5	0	2010-01-02	49302	66054	\N	\N
66176	SPECIFIC_DAY	5	0	2009-12-27	49302	66054	\N	\N
66161	SPECIFIC_DAY	5	0	2009-12-26	49302	66054	\N	\N
66170	SPECIFIC_DAY	5	2	2010-01-11	49302	66054	\N	\N
66193	SPECIFIC_DAY	5	2	2009-12-16	49302	66054	\N	\N
66173	SPECIFIC_DAY	5	0	2010-01-09	49302	66054	\N	\N
66186	SPECIFIC_DAY	5	2	2009-12-30	49302	66054	\N	\N
66185	SPECIFIC_DAY	5	0	2010-01-10	49302	66054	\N	\N
66181	SPECIFIC_DAY	5	2	2010-01-20	49302	66054	\N	\N
66166	SPECIFIC_DAY	5	2	2009-12-29	49302	66054	\N	\N
66175	SPECIFIC_DAY	5	2	2009-12-23	49302	66054	\N	\N
66174	SPECIFIC_DAY	5	2	2009-12-31	49302	66054	\N	\N
66187	SPECIFIC_DAY	5	0	2010-01-03	49302	66054	\N	\N
66184	SPECIFIC_DAY	5	0	2009-12-25	49302	66054	\N	\N
66183	SPECIFIC_DAY	5	2	2010-01-05	49302	66054	\N	\N
59369	SPECIFIC_DAY	25	7	2009-12-14	40199	59189	\N	\N
59328	SPECIFIC_DAY	25	7	2009-12-14	40199	59189	\N	\N
59590	SPECIFIC_DAY	25	7	2009-12-14	40199	59189	\N	\N
59342	SPECIFIC_DAY	25	7	2009-12-14	40199	59189	\N	\N
59334	SPECIFIC_DAY	25	7	2009-12-14	40199	59189	\N	\N
73185	SPECIFIC_DAY	3	0	2010-01-18	49297	68684	\N	\N
73186	SPECIFIC_DAY	3	0	2010-01-21	49297	68684	\N	\N
73187	SPECIFIC_DAY	3	8	2010-01-05	49297	68684	\N	\N
73188	SPECIFIC_DAY	3	1	2010-01-08	49297	68684	\N	\N
73189	SPECIFIC_DAY	3	0	2010-01-22	49297	68684	\N	\N
73190	SPECIFIC_DAY	3	0	2010-01-12	49297	68684	\N	\N
73191	SPECIFIC_DAY	3	1	2010-01-07	49297	68684	\N	\N
73192	SPECIFIC_DAY	3	0	2010-01-16	49297	68684	\N	\N
73193	SPECIFIC_DAY	3	7	2010-01-27	49297	68684	\N	\N
73194	SPECIFIC_DAY	3	0	2010-01-19	49297	68684	\N	\N
73195	SPECIFIC_DAY	3	0	2010-01-25	49297	68684	\N	\N
73196	SPECIFIC_DAY	3	0	2010-01-24	49297	68684	\N	\N
73197	SPECIFIC_DAY	3	0	2010-01-23	49297	68684	\N	\N
73198	SPECIFIC_DAY	3	0	2010-01-15	49297	68684	\N	\N
73199	SPECIFIC_DAY	3	0	2010-01-20	49297	68684	\N	\N
73200	SPECIFIC_DAY	3	0	2010-01-13	49297	68684	\N	\N
73201	SPECIFIC_DAY	3	0	2010-01-26	49297	68684	\N	\N
73202	SPECIFIC_DAY	3	0	2010-01-14	49297	68684	\N	\N
73203	SPECIFIC_DAY	3	1	2010-01-11	49297	68684	\N	\N
73204	SPECIFIC_DAY	3	1	2010-01-09	49297	68684	\N	\N
73205	SPECIFIC_DAY	3	1	2010-01-06	49297	68684	\N	\N
73206	SPECIFIC_DAY	3	1	2010-01-10	49297	68684	\N	\N
73207	SPECIFIC_DAY	3	0	2010-01-17	49297	68684	\N	\N
73208	SPECIFIC_DAY	3	21	2010-01-28	49297	68685	\N	\N
73209	SPECIFIC_DAY	3	7	2009-12-16	49297	68686	\N	\N
73210	SPECIFIC_DAY	3	7	2009-12-18	49297	68686	\N	\N
73211	SPECIFIC_DAY	3	7	2009-12-17	49297	68686	\N	\N
73212	SPECIFIC_DAY	3	7	2009-12-29	49297	68687	\N	\N
73213	SPECIFIC_DAY	3	7	2009-12-30	49297	68687	\N	\N
73214	SPECIFIC_DAY	3	7	2009-12-31	49297	68687	\N	\N
73215	SPECIFIC_DAY	3	2	2009-12-19	49297	68688	\N	\N
73216	SPECIFIC_DAY	3	2	2009-12-20	49297	68688	\N	\N
73217	SPECIFIC_DAY	3	9	2009-12-21	49297	68688	\N	\N
73218	SPECIFIC_DAY	3	8	2009-12-22	49297	68688	\N	\N
73219	SPECIFIC_DAY	3	7	2009-12-28	49297	68689	\N	\N
73220	SPECIFIC_DAY	3	0	2009-12-26	49297	68689	\N	\N
73221	SPECIFIC_DAY	3	0	2009-12-25	49297	68689	\N	\N
73222	SPECIFIC_DAY	3	0	2009-12-27	49297	68689	\N	\N
73223	SPECIFIC_DAY	3	7	2009-12-23	49297	68689	\N	\N
73224	SPECIFIC_DAY	3	7	2009-12-24	49297	68689	\N	\N
73225	SPECIFIC_DAY	3	10	2010-01-04	49297	68690	\N	\N
73226	SPECIFIC_DAY	3	4	2010-01-01	49297	68690	\N	\N
73227	SPECIFIC_DAY	3	4	2010-01-02	49297	68690	\N	\N
73228	SPECIFIC_DAY	3	3	2010-01-03	49297	68690	\N	\N
73229	SPECIFIC_DAY	3	13	2010-01-21	36159	60446	\N	\N
73230	SPECIFIC_DAY	3	6	2010-01-09	36159	60446	\N	\N
73231	SPECIFIC_DAY	3	6	2010-01-13	36159	60446	\N	\N
73232	SPECIFIC_DAY	3	13	2010-01-20	36159	60446	\N	\N
73233	SPECIFIC_DAY	3	13	2010-01-25	36159	60446	\N	\N
73234	SPECIFIC_DAY	3	6	2010-01-24	36159	60446	\N	\N
73235	SPECIFIC_DAY	3	6	2010-01-12	36159	60446	\N	\N
73236	SPECIFIC_DAY	3	6	2010-01-15	36159	60446	\N	\N
73237	SPECIFIC_DAY	3	6	2010-01-14	36159	60446	\N	\N
73238	SPECIFIC_DAY	3	6	2010-01-16	36159	60446	\N	\N
73239	SPECIFIC_DAY	3	13	2010-01-27	36159	60446	\N	\N
73240	SPECIFIC_DAY	3	13	2010-01-22	36159	60446	\N	\N
73241	SPECIFIC_DAY	3	13	2010-01-08	36159	60446	\N	\N
73242	SPECIFIC_DAY	3	6	2010-01-23	36159	60446	\N	\N
73243	SPECIFIC_DAY	3	6	2010-01-11	36159	60446	\N	\N
73244	SPECIFIC_DAY	3	13	2010-01-28	36159	60446	\N	\N
73245	SPECIFIC_DAY	3	13	2010-01-18	36159	60446	\N	\N
73246	SPECIFIC_DAY	3	6	2010-01-10	36159	60446	\N	\N
73247	SPECIFIC_DAY	3	13	2010-01-19	36159	60446	\N	\N
73248	SPECIFIC_DAY	3	6	2010-01-17	36159	60446	\N	\N
73249	SPECIFIC_DAY	3	13	2010-01-26	36159	60446	\N	\N
73250	SPECIFIC_DAY	3	14	2010-01-07	36159	60446	\N	\N
73251	SPECIFIC_DAY	3	9	2009-12-27	36159	60447	\N	\N
73252	SPECIFIC_DAY	3	9	2010-01-06	36159	60447	\N	\N
73253	SPECIFIC_DAY	3	16	2009-12-29	36159	60447	\N	\N
73254	SPECIFIC_DAY	3	9	2010-01-02	36159	60447	\N	\N
73255	SPECIFIC_DAY	3	16	2010-01-04	36159	60447	\N	\N
73256	SPECIFIC_DAY	3	16	2009-12-31	36159	60447	\N	\N
73257	SPECIFIC_DAY	3	16	2010-01-05	36159	60447	\N	\N
73258	SPECIFIC_DAY	3	9	2010-01-03	36159	60447	\N	\N
73259	SPECIFIC_DAY	3	17	2009-12-22	36159	60447	\N	\N
73260	SPECIFIC_DAY	3	9	2009-12-25	36159	60447	\N	\N
73261	SPECIFIC_DAY	3	17	2009-12-23	36159	60447	\N	\N
73262	SPECIFIC_DAY	3	9	2010-01-01	36159	60447	\N	\N
73263	SPECIFIC_DAY	3	9	2009-12-26	36159	60447	\N	\N
73264	SPECIFIC_DAY	3	16	2009-12-28	36159	60447	\N	\N
73265	SPECIFIC_DAY	3	16	2009-12-30	36159	60447	\N	\N
73266	SPECIFIC_DAY	3	17	2009-12-24	36159	60447	\N	\N
73267	SPECIFIC_DAY	3	7	2010-01-04	49300	68697	\N	\N
73268	SPECIFIC_DAY	3	0	2010-01-03	49300	68697	\N	\N
73269	SPECIFIC_DAY	3	0	2010-01-02	49300	68697	\N	\N
73270	SPECIFIC_DAY	3	7	2009-12-31	49300	68697	\N	\N
73271	SPECIFIC_DAY	3	7	2009-12-30	49300	68697	\N	\N
73272	SPECIFIC_DAY	3	0	2010-01-01	49300	68697	\N	\N
73273	SPECIFIC_DAY	3	0	2010-01-06	49300	68698	\N	\N
73274	SPECIFIC_DAY	3	7	2010-01-05	49300	68698	\N	\N
73275	SPECIFIC_DAY	3	7	2010-01-13	49300	68698	\N	\N
73276	SPECIFIC_DAY	3	7	2010-01-12	49300	68698	\N	\N
73277	SPECIFIC_DAY	3	7	2010-01-08	49300	68698	\N	\N
73278	SPECIFIC_DAY	3	0	2010-01-10	49300	68698	\N	\N
73279	SPECIFIC_DAY	3	7	2010-01-07	49300	68698	\N	\N
73280	SPECIFIC_DAY	3	0	2010-01-09	49300	68698	\N	\N
73281	SPECIFIC_DAY	3	7	2010-01-11	49300	68698	\N	\N
73282	SPECIFIC_DAY	3	7	2010-01-26	49300	68699	\N	\N
73283	SPECIFIC_DAY	3	0	2010-01-24	49300	68699	\N	\N
73284	SPECIFIC_DAY	3	3	2010-01-28	49300	68699	\N	\N
73285	SPECIFIC_DAY	3	7	2010-01-25	49300	68699	\N	\N
73286	SPECIFIC_DAY	3	0	2010-01-23	49300	68699	\N	\N
73287	SPECIFIC_DAY	3	7	2010-01-27	49300	68699	\N	\N
73288	SPECIFIC_DAY	3	7	2009-12-28	49300	68700	\N	\N
73289	SPECIFIC_DAY	3	7	2009-12-23	49300	68700	\N	\N
73290	SPECIFIC_DAY	3	0	2009-12-20	49300	68700	\N	\N
73291	SPECIFIC_DAY	3	0	2009-12-27	49300	68700	\N	\N
73292	SPECIFIC_DAY	3	7	2009-12-29	49300	68700	\N	\N
73293	SPECIFIC_DAY	3	0	2009-12-19	49300	68700	\N	\N
73294	SPECIFIC_DAY	3	0	2009-12-25	49300	68700	\N	\N
73295	SPECIFIC_DAY	3	7	2009-12-21	49300	68700	\N	\N
73296	SPECIFIC_DAY	3	7	2009-12-22	49300	68700	\N	\N
73297	SPECIFIC_DAY	3	7	2009-12-24	49300	68700	\N	\N
73298	SPECIFIC_DAY	3	0	2009-12-26	49300	68700	\N	\N
73299	SPECIFIC_DAY	3	8	2010-01-25	36159	60451	\N	\N
73300	SPECIFIC_DAY	3	0	2010-01-23	36159	60451	\N	\N
73301	SPECIFIC_DAY	3	8	2010-01-22	36159	60451	\N	\N
73302	SPECIFIC_DAY	3	8	2010-01-20	36159	60451	\N	\N
73303	SPECIFIC_DAY	3	8	2010-01-19	36159	60451	\N	\N
73304	SPECIFIC_DAY	3	8	2010-01-21	36159	60451	\N	\N
73305	SPECIFIC_DAY	3	0	2010-01-24	36159	60451	\N	\N
73306	SPECIFIC_DAY	3	8	2010-01-26	36159	60451	\N	\N
73307	SPECIFIC_DAY	3	8	2010-01-27	36159	60451	\N	\N
73308	SPECIFIC_DAY	3	0	2010-01-17	36159	60452	\N	\N
73309	SPECIFIC_DAY	3	0	2010-01-13	36159	60452	\N	\N
73310	SPECIFIC_DAY	3	7	2009-12-28	36159	60452	\N	\N
73311	SPECIFIC_DAY	3	0	2010-01-01	36159	60452	\N	\N
73312	SPECIFIC_DAY	3	7	2009-12-22	36159	60452	\N	\N
73313	SPECIFIC_DAY	3	0	2010-01-15	36159	60452	\N	\N
73314	SPECIFIC_DAY	3	0	2010-01-06	36159	60452	\N	\N
73315	SPECIFIC_DAY	3	7	2010-01-04	36159	60452	\N	\N
73316	SPECIFIC_DAY	3	0	2010-01-14	36159	60452	\N	\N
73317	SPECIFIC_DAY	3	0	2010-01-10	36159	60452	\N	\N
73318	SPECIFIC_DAY	3	0	2010-01-11	36159	60452	\N	\N
73319	SPECIFIC_DAY	3	0	2009-12-25	36159	60452	\N	\N
73320	SPECIFIC_DAY	3	7	2009-12-29	36159	60452	\N	\N
73321	SPECIFIC_DAY	3	7	2010-01-08	36159	60452	\N	\N
73322	SPECIFIC_DAY	3	0	2009-12-27	36159	60452	\N	\N
73323	SPECIFIC_DAY	3	0	2009-12-26	36159	60452	\N	\N
73324	SPECIFIC_DAY	3	7	2009-12-31	36159	60452	\N	\N
73325	SPECIFIC_DAY	3	7	2010-01-05	36159	60452	\N	\N
73326	SPECIFIC_DAY	3	7	2009-12-23	36159	60452	\N	\N
73327	SPECIFIC_DAY	3	7	2010-01-07	36159	60452	\N	\N
73328	SPECIFIC_DAY	3	7	2010-01-18	36159	60452	\N	\N
73329	SPECIFIC_DAY	3	0	2010-01-16	36159	60452	\N	\N
73330	SPECIFIC_DAY	3	0	2010-01-09	36159	60452	\N	\N
73331	SPECIFIC_DAY	3	0	2010-01-12	36159	60452	\N	\N
73332	SPECIFIC_DAY	3	7	2009-12-30	36159	60452	\N	\N
73333	SPECIFIC_DAY	3	0	2010-01-02	36159	60452	\N	\N
73334	SPECIFIC_DAY	3	7	2009-12-24	36159	60452	\N	\N
73335	SPECIFIC_DAY	3	0	2010-01-03	36159	60452	\N	\N
73336	SPECIFIC_DAY	3	7	2010-09-02	49309	61409	\N	\N
73337	SPECIFIC_DAY	3	7	2010-08-16	49309	61409	\N	\N
73338	SPECIFIC_DAY	3	7	2010-09-09	49309	61409	\N	\N
73339	SPECIFIC_DAY	3	7	2010-07-29	49309	61409	\N	\N
73340	SPECIFIC_DAY	3	0	2010-07-10	49309	61409	\N	\N
73341	SPECIFIC_DAY	3	7	2010-08-02	49309	61409	\N	\N
73342	SPECIFIC_DAY	3	7	2010-07-27	49309	61409	\N	\N
73343	SPECIFIC_DAY	3	7	2010-07-16	49309	61409	\N	\N
73344	SPECIFIC_DAY	3	7	2010-07-15	49309	61409	\N	\N
73345	SPECIFIC_DAY	3	7	2010-08-19	49309	61409	\N	\N
73346	SPECIFIC_DAY	3	7	2010-07-13	49309	61409	\N	\N
73347	SPECIFIC_DAY	3	7	2010-07-14	49309	61409	\N	\N
73348	SPECIFIC_DAY	3	0	2010-08-21	49309	61409	\N	\N
73349	SPECIFIC_DAY	3	7	2010-08-13	49309	61409	\N	\N
73350	SPECIFIC_DAY	3	7	2010-07-09	49309	61409	\N	\N
73351	SPECIFIC_DAY	3	7	2010-08-03	49309	61409	\N	\N
73352	SPECIFIC_DAY	3	0	2010-07-04	49309	61409	\N	\N
73353	SPECIFIC_DAY	3	7	2010-08-20	49309	61409	\N	\N
73354	SPECIFIC_DAY	3	0	2010-07-03	49309	61409	\N	\N
73355	SPECIFIC_DAY	3	0	2010-09-05	49309	61409	\N	\N
73356	SPECIFIC_DAY	3	7	2010-08-23	49309	61409	\N	\N
73357	SPECIFIC_DAY	3	0	2010-07-11	49309	61409	\N	\N
73358	SPECIFIC_DAY	3	7	2010-07-20	49309	61409	\N	\N
73359	SPECIFIC_DAY	3	7	2010-07-21	49309	61409	\N	\N
73360	SPECIFIC_DAY	3	7	2010-07-19	49309	61409	\N	\N
73361	SPECIFIC_DAY	3	7	2010-07-07	49309	61409	\N	\N
73362	SPECIFIC_DAY	3	7	2010-08-31	49309	61409	\N	\N
73363	SPECIFIC_DAY	3	7	2010-08-27	49309	61409	\N	\N
73364	SPECIFIC_DAY	3	7	2010-08-25	49309	61409	\N	\N
73365	SPECIFIC_DAY	3	0	2010-07-24	49309	61409	\N	\N
73366	SPECIFIC_DAY	3	0	2010-08-07	49309	61409	\N	\N
73367	SPECIFIC_DAY	3	7	2010-08-12	49309	61409	\N	\N
73368	SPECIFIC_DAY	3	0	2010-08-28	49309	61409	\N	\N
73369	SPECIFIC_DAY	3	0	2010-08-29	49309	61409	\N	\N
73370	SPECIFIC_DAY	3	7	2010-07-23	49309	61409	\N	\N
73371	SPECIFIC_DAY	3	0	2010-09-04	49309	61409	\N	\N
73372	SPECIFIC_DAY	3	7	2010-08-24	49309	61409	\N	\N
73373	SPECIFIC_DAY	3	7	2010-08-06	49309	61409	\N	\N
73374	SPECIFIC_DAY	3	0	2010-07-31	49309	61409	\N	\N
73375	SPECIFIC_DAY	3	0	2010-07-25	49309	61409	\N	\N
73376	SPECIFIC_DAY	3	7	2010-08-30	49309	61409	\N	\N
73377	SPECIFIC_DAY	3	7	2010-07-26	49309	61409	\N	\N
73378	SPECIFIC_DAY	3	7	2010-09-01	49309	61409	\N	\N
73379	SPECIFIC_DAY	3	7	2010-07-05	49309	61409	\N	\N
73380	SPECIFIC_DAY	3	0	2010-08-15	49309	61409	\N	\N
73381	SPECIFIC_DAY	3	7	2010-08-05	49309	61409	\N	\N
73382	SPECIFIC_DAY	3	7	2010-09-08	49309	61409	\N	\N
73383	SPECIFIC_DAY	3	7	2010-07-28	49309	61409	\N	\N
73384	SPECIFIC_DAY	3	0	2010-07-18	49309	61409	\N	\N
73385	SPECIFIC_DAY	3	7	2010-09-10	49309	61409	\N	\N
73386	SPECIFIC_DAY	3	0	2010-08-22	49309	61409	\N	\N
73387	SPECIFIC_DAY	3	0	2010-08-08	49309	61409	\N	\N
73388	SPECIFIC_DAY	3	7	2010-09-07	49309	61409	\N	\N
73389	SPECIFIC_DAY	3	7	2010-08-10	49309	61409	\N	\N
73390	SPECIFIC_DAY	3	7	2010-09-06	49309	61409	\N	\N
73391	SPECIFIC_DAY	3	7	2010-08-26	49309	61409	\N	\N
73392	SPECIFIC_DAY	3	7	2010-08-09	49309	61409	\N	\N
73393	SPECIFIC_DAY	3	7	2010-08-11	49309	61409	\N	\N
73394	SPECIFIC_DAY	3	7	2010-09-03	49309	61409	\N	\N
73395	SPECIFIC_DAY	3	0	2010-08-01	49309	61409	\N	\N
73396	SPECIFIC_DAY	3	7	2010-08-04	49309	61409	\N	\N
73397	SPECIFIC_DAY	3	7	2010-07-12	49309	61409	\N	\N
73398	SPECIFIC_DAY	3	7	2010-08-18	49309	61409	\N	\N
73399	SPECIFIC_DAY	3	0	2010-08-14	49309	61409	\N	\N
73400	SPECIFIC_DAY	3	0	2010-07-17	49309	61409	\N	\N
73401	SPECIFIC_DAY	3	7	2010-07-08	49309	61409	\N	\N
73402	SPECIFIC_DAY	3	7	2010-08-17	49309	61409	\N	\N
73403	SPECIFIC_DAY	3	7	2010-07-06	49309	61409	\N	\N
73404	SPECIFIC_DAY	3	7	2010-07-30	49309	61409	\N	\N
73405	SPECIFIC_DAY	3	7	2010-07-22	49309	61409	\N	\N
73406	SPECIFIC_DAY	3	0	2010-04-02	37573	59217	\N	\N
73407	SPECIFIC_DAY	3	0	2010-04-17	37573	59217	\N	\N
73408	SPECIFIC_DAY	3	9	2011-01-12	37573	59217	\N	\N
73409	SPECIFIC_DAY	3	9	2010-07-22	37573	59217	\N	\N
73410	SPECIFIC_DAY	3	9	2010-12-13	37573	59217	\N	\N
73411	SPECIFIC_DAY	3	9	2010-03-05	37573	59217	\N	\N
73412	SPECIFIC_DAY	3	9	2010-03-02	37573	59217	\N	\N
73413	SPECIFIC_DAY	3	9	2010-11-04	37573	59217	\N	\N
73414	SPECIFIC_DAY	3	0	2010-01-24	37573	59217	\N	\N
73415	SPECIFIC_DAY	3	0	2010-12-05	37573	59217	\N	\N
73416	SPECIFIC_DAY	3	0	2010-07-04	37573	59217	\N	\N
73417	SPECIFIC_DAY	3	0	2010-09-05	37573	59217	\N	\N
73418	SPECIFIC_DAY	3	9	2010-05-05	37573	59217	\N	\N
73419	SPECIFIC_DAY	3	9	2010-10-22	37573	59217	\N	\N
73420	SPECIFIC_DAY	3	9	2010-06-18	37573	59217	\N	\N
73421	SPECIFIC_DAY	3	0	2010-05-30	37573	59217	\N	\N
73422	SPECIFIC_DAY	3	9	2010-12-23	37573	59217	\N	\N
73423	SPECIFIC_DAY	3	0	2010-08-28	37573	59217	\N	\N
73424	SPECIFIC_DAY	3	9	2010-01-13	37573	59217	\N	\N
73425	SPECIFIC_DAY	3	9	2010-03-29	37573	59217	\N	\N
73426	SPECIFIC_DAY	3	0	2010-03-19	37573	59217	\N	\N
73427	SPECIFIC_DAY	3	0	2010-09-18	37573	59217	\N	\N
73428	SPECIFIC_DAY	3	9	2010-08-18	37573	59217	\N	\N
73429	SPECIFIC_DAY	3	9	2010-10-14	37573	59217	\N	\N
73430	SPECIFIC_DAY	3	9	2010-06-11	37573	59217	\N	\N
73431	SPECIFIC_DAY	3	9	2010-01-22	37573	59217	\N	\N
73432	SPECIFIC_DAY	3	9	2011-01-24	37573	59217	\N	\N
73433	SPECIFIC_DAY	3	9	2011-02-02	37573	59217	\N	\N
73434	SPECIFIC_DAY	3	9	2010-08-05	37573	59217	\N	\N
73435	SPECIFIC_DAY	3	9	2010-03-12	37573	59217	\N	\N
73436	SPECIFIC_DAY	3	0	2010-11-07	37573	59217	\N	\N
73437	SPECIFIC_DAY	3	9	2010-10-05	37573	59217	\N	\N
73438	SPECIFIC_DAY	3	0	2010-04-24	37573	59217	\N	\N
73439	SPECIFIC_DAY	3	9	2010-03-03	37573	59217	\N	\N
73440	SPECIFIC_DAY	3	9	2010-10-27	37573	59217	\N	\N
73441	SPECIFIC_DAY	3	9	2010-11-05	37573	59217	\N	\N
73442	SPECIFIC_DAY	3	9	2010-01-26	37573	59217	\N	\N
73443	SPECIFIC_DAY	3	9	2010-10-25	37573	59217	\N	\N
73444	SPECIFIC_DAY	3	9	2010-07-20	37573	59217	\N	\N
73445	SPECIFIC_DAY	3	9	2010-03-15	37573	59217	\N	\N
73446	SPECIFIC_DAY	3	9	2010-11-12	37573	59217	\N	\N
73447	SPECIFIC_DAY	3	0	2010-01-17	37573	59217	\N	\N
73448	SPECIFIC_DAY	3	9	2010-10-08	37573	59217	\N	\N
73449	SPECIFIC_DAY	3	9	2010-12-02	37573	59217	\N	\N
73450	SPECIFIC_DAY	3	0	2010-12-11	37573	59217	\N	\N
73451	SPECIFIC_DAY	3	9	2010-06-15	37573	59217	\N	\N
73452	SPECIFIC_DAY	3	0	2010-08-08	37573	59217	\N	\N
73453	SPECIFIC_DAY	3	9	2011-02-24	37573	59217	\N	\N
73454	SPECIFIC_DAY	3	0	2010-03-20	37573	59217	\N	\N
73455	SPECIFIC_DAY	3	0	2010-09-11	37573	59217	\N	\N
73456	SPECIFIC_DAY	3	9	2010-08-16	37573	59217	\N	\N
73457	SPECIFIC_DAY	3	9	2010-06-24	37573	59217	\N	\N
73458	SPECIFIC_DAY	3	0	2010-06-13	37573	59217	\N	\N
73459	SPECIFIC_DAY	3	9	2010-03-18	37573	59217	\N	\N
73460	SPECIFIC_DAY	3	0	2010-05-23	37573	59217	\N	\N
73461	SPECIFIC_DAY	3	0	2010-08-21	37573	59217	\N	\N
73462	SPECIFIC_DAY	3	9	2010-04-26	37573	59217	\N	\N
73463	SPECIFIC_DAY	3	9	2010-05-07	37573	59217	\N	\N
73464	SPECIFIC_DAY	3	9	2010-02-10	37573	59217	\N	\N
73465	SPECIFIC_DAY	3	9	2010-02-12	37573	59217	\N	\N
73466	SPECIFIC_DAY	3	9	2010-05-25	37573	59217	\N	\N
73467	SPECIFIC_DAY	3	0	2011-02-06	37573	59217	\N	\N
73468	SPECIFIC_DAY	3	9	2010-04-28	37573	59217	\N	\N
73469	SPECIFIC_DAY	3	9	2011-01-11	37573	59217	\N	\N
73470	SPECIFIC_DAY	3	9	2010-12-22	37573	59217	\N	\N
73471	SPECIFIC_DAY	3	0	2010-02-14	37573	59217	\N	\N
73472	SPECIFIC_DAY	3	9	2010-04-20	37573	59217	\N	\N
73473	SPECIFIC_DAY	3	9	2011-01-05	37573	59217	\N	\N
73474	SPECIFIC_DAY	3	9	2010-02-02	37573	59217	\N	\N
73475	SPECIFIC_DAY	3	9	2010-01-28	37573	59217	\N	\N
73476	SPECIFIC_DAY	3	9	2010-06-21	37573	59217	\N	\N
73477	SPECIFIC_DAY	3	0	2010-07-24	37573	59217	\N	\N
73478	SPECIFIC_DAY	3	9	2010-01-18	37573	59217	\N	\N
73479	SPECIFIC_DAY	3	9	2010-04-21	37573	59217	\N	\N
73480	SPECIFIC_DAY	3	9	2010-08-27	37573	59217	\N	\N
73481	SPECIFIC_DAY	3	9	2010-09-24	37573	59217	\N	\N
73482	SPECIFIC_DAY	3	9	2010-01-20	37573	59217	\N	\N
73483	SPECIFIC_DAY	3	9	2010-05-14	37573	59217	\N	\N
73484	SPECIFIC_DAY	3	9	2010-12-17	37573	59217	\N	\N
73485	SPECIFIC_DAY	3	9	2010-09-14	37573	59217	\N	\N
73486	SPECIFIC_DAY	3	9	2010-08-12	37573	59217	\N	\N
73487	SPECIFIC_DAY	3	9	2011-02-14	37573	59217	\N	\N
73488	SPECIFIC_DAY	3	9	2010-05-03	37573	59217	\N	\N
73489	SPECIFIC_DAY	3	9	2010-03-24	37573	59217	\N	\N
73490	SPECIFIC_DAY	3	0	2010-12-04	37573	59217	\N	\N
73491	SPECIFIC_DAY	3	0	2010-05-29	37573	59217	\N	\N
73492	SPECIFIC_DAY	3	9	2010-10-20	37573	59217	\N	\N
73493	SPECIFIC_DAY	3	0	2010-04-04	37573	59217	\N	\N
73494	SPECIFIC_DAY	3	0	2010-04-11	37573	59217	\N	\N
73495	SPECIFIC_DAY	3	9	2010-09-27	37573	59217	\N	\N
73496	SPECIFIC_DAY	3	0	2010-12-12	37573	59217	\N	\N
73497	SPECIFIC_DAY	3	9	2010-02-18	37573	59217	\N	\N
73498	SPECIFIC_DAY	3	9	2011-01-10	37573	59217	\N	\N
73499	SPECIFIC_DAY	3	0	2010-05-01	37573	59217	\N	\N
73500	SPECIFIC_DAY	3	9	2010-03-04	37573	59217	\N	\N
73501	SPECIFIC_DAY	3	0	2010-06-05	37573	59217	\N	\N
73502	SPECIFIC_DAY	3	9	2010-11-25	37573	59217	\N	\N
73503	SPECIFIC_DAY	3	9	2010-02-26	37573	59217	\N	\N
73504	SPECIFIC_DAY	3	9	2010-10-21	37573	59217	\N	\N
73505	SPECIFIC_DAY	3	9	2010-02-03	37573	59217	\N	\N
73506	SPECIFIC_DAY	3	9	2010-09-06	37573	59217	\N	\N
73507	SPECIFIC_DAY	3	9	2010-06-01	37573	59217	\N	\N
73508	SPECIFIC_DAY	3	9	2010-10-01	37573	59217	\N	\N
73509	SPECIFIC_DAY	3	0	2011-01-15	37573	59217	\N	\N
73510	SPECIFIC_DAY	3	9	2010-04-19	37573	59217	\N	\N
73511	SPECIFIC_DAY	3	0	2010-02-27	37573	59217	\N	\N
73512	SPECIFIC_DAY	3	9	2010-03-26	37573	59217	\N	\N
73513	SPECIFIC_DAY	3	9	2010-02-23	37573	59217	\N	\N
73514	SPECIFIC_DAY	3	9	2011-02-21	37573	59217	\N	\N
73515	SPECIFIC_DAY	3	9	2010-07-15	37573	59217	\N	\N
73516	SPECIFIC_DAY	3	9	2010-10-06	37573	59217	\N	\N
73517	SPECIFIC_DAY	3	0	2010-07-18	37573	59217	\N	\N
73518	SPECIFIC_DAY	3	9	2010-06-04	37573	59217	\N	\N
73519	SPECIFIC_DAY	3	0	2011-01-08	37573	59217	\N	\N
73520	SPECIFIC_DAY	3	9	2010-03-23	37573	59217	\N	\N
73521	SPECIFIC_DAY	3	9	2010-05-18	37573	59217	\N	\N
73522	SPECIFIC_DAY	3	9	2010-10-11	37573	59217	\N	\N
73523	SPECIFIC_DAY	3	0	2011-03-06	37573	59217	\N	\N
73524	SPECIFIC_DAY	3	9	2011-02-22	37573	59217	\N	\N
73525	SPECIFIC_DAY	3	9	2011-02-04	37573	59217	\N	\N
73526	SPECIFIC_DAY	3	0	2010-10-12	37573	59217	\N	\N
73527	SPECIFIC_DAY	3	9	2010-10-15	37573	59217	\N	\N
73528	SPECIFIC_DAY	3	9	2010-12-14	37573	59217	\N	\N
73529	SPECIFIC_DAY	3	9	2010-05-19	37573	59217	\N	\N
73530	SPECIFIC_DAY	3	9	2010-04-08	37573	59217	\N	\N
73531	SPECIFIC_DAY	3	0	2011-01-02	37573	59217	\N	\N
73532	SPECIFIC_DAY	3	9	2010-04-12	37573	59217	\N	\N
73533	SPECIFIC_DAY	3	9	2010-08-10	37573	59217	\N	\N
73534	SPECIFIC_DAY	3	9	2010-05-11	37573	59217	\N	\N
73535	SPECIFIC_DAY	3	0	2011-01-01	37573	59217	\N	\N
73536	SPECIFIC_DAY	3	9	2010-11-16	37573	59217	\N	\N
73537	SPECIFIC_DAY	3	9	2011-03-01	37573	59217	\N	\N
73538	SPECIFIC_DAY	3	0	2010-05-02	37573	59217	\N	\N
73539	SPECIFIC_DAY	3	9	2010-03-17	37573	59217	\N	\N
73540	SPECIFIC_DAY	3	9	2010-04-16	37573	59217	\N	\N
73541	SPECIFIC_DAY	3	0	2010-01-09	37573	59217	\N	\N
73542	SPECIFIC_DAY	3	0	2010-06-19	37573	59217	\N	\N
73543	SPECIFIC_DAY	3	0	2011-02-12	37573	59217	\N	\N
73544	SPECIFIC_DAY	3	9	2010-11-18	37573	59217	\N	\N
73545	SPECIFIC_DAY	3	9	2011-02-10	37573	59217	\N	\N
73546	SPECIFIC_DAY	3	9	2010-05-28	37573	59217	\N	\N
73547	SPECIFIC_DAY	3	0	2010-05-09	37573	59217	\N	\N
73548	SPECIFIC_DAY	3	9	2010-05-26	37573	59217	\N	\N
73549	SPECIFIC_DAY	3	9	2010-08-26	37573	59217	\N	\N
73550	SPECIFIC_DAY	3	9	2010-08-30	37573	59217	\N	\N
73551	SPECIFIC_DAY	3	9	2010-06-10	37573	59217	\N	\N
73552	SPECIFIC_DAY	3	9	2011-02-15	37573	59217	\N	\N
73553	SPECIFIC_DAY	3	9	2010-06-09	37573	59217	\N	\N
73554	SPECIFIC_DAY	3	9	2010-12-01	37573	59217	\N	\N
73555	SPECIFIC_DAY	3	0	2010-05-15	37573	59217	\N	\N
73556	SPECIFIC_DAY	3	9	2011-02-16	37573	59217	\N	\N
73557	SPECIFIC_DAY	3	9	2010-09-01	37573	59217	\N	\N
73558	SPECIFIC_DAY	3	0	2010-08-07	37573	59217	\N	\N
73559	SPECIFIC_DAY	3	9	2010-06-29	37573	59217	\N	\N
73560	SPECIFIC_DAY	3	9	2010-08-19	37573	59217	\N	\N
73561	SPECIFIC_DAY	3	9	2011-01-19	37573	59217	\N	\N
73562	SPECIFIC_DAY	3	9	2010-06-30	37573	59217	\N	\N
73563	SPECIFIC_DAY	3	9	2010-05-06	37573	59217	\N	\N
73564	SPECIFIC_DAY	3	0	2011-02-27	37573	59217	\N	\N
73565	SPECIFIC_DAY	3	0	2010-07-25	37573	59217	\N	\N
73566	SPECIFIC_DAY	3	9	2010-12-31	37573	59217	\N	\N
73567	SPECIFIC_DAY	3	9	2010-09-02	37573	59217	\N	\N
73568	SPECIFIC_DAY	3	0	2010-01-06	37573	59217	\N	\N
73569	SPECIFIC_DAY	3	0	2010-10-23	37573	59217	\N	\N
73570	SPECIFIC_DAY	3	9	2011-01-25	37573	59217	\N	\N
73571	SPECIFIC_DAY	3	0	2010-10-03	37573	59217	\N	\N
73572	SPECIFIC_DAY	3	0	2010-08-14	37573	59217	\N	\N
73573	SPECIFIC_DAY	3	9	2010-02-11	37573	59217	\N	\N
73574	SPECIFIC_DAY	3	9	2010-01-14	37573	59217	\N	\N
73575	SPECIFIC_DAY	3	0	2010-12-08	37573	59217	\N	\N
73576	SPECIFIC_DAY	3	0	2010-06-27	37573	59217	\N	\N
73577	SPECIFIC_DAY	3	9	2010-08-17	37573	59217	\N	\N
73578	SPECIFIC_DAY	3	0	2010-10-16	37573	59217	\N	\N
73579	SPECIFIC_DAY	3	0	2010-05-16	37573	59217	\N	\N
73580	SPECIFIC_DAY	3	9	2010-12-15	37573	59217	\N	\N
73581	SPECIFIC_DAY	3	9	2011-02-11	37573	59217	\N	\N
73582	SPECIFIC_DAY	3	9	2010-05-21	37573	59217	\N	\N
73583	SPECIFIC_DAY	3	0	2010-02-17	37573	59217	\N	\N
73584	SPECIFIC_DAY	3	9	2010-10-28	37573	59217	\N	\N
73585	SPECIFIC_DAY	3	9	2010-11-17	37573	59217	\N	\N
73586	SPECIFIC_DAY	3	9	2011-01-14	37573	59217	\N	\N
73587	SPECIFIC_DAY	3	9	2010-09-03	37573	59217	\N	\N
73588	SPECIFIC_DAY	3	9	2010-11-15	37573	59217	\N	\N
73589	SPECIFIC_DAY	3	9	2010-06-25	37573	59217	\N	\N
73590	SPECIFIC_DAY	3	0	2011-02-13	37573	59217	\N	\N
73591	SPECIFIC_DAY	3	9	2010-10-29	37573	59217	\N	\N
73592	SPECIFIC_DAY	3	9	2010-08-13	37573	59217	\N	\N
73593	SPECIFIC_DAY	3	9	2010-09-21	37573	59217	\N	\N
73594	SPECIFIC_DAY	3	9	2010-07-28	37573	59217	\N	\N
73595	SPECIFIC_DAY	3	0	2011-02-19	37573	59217	\N	\N
73596	SPECIFIC_DAY	3	0	2010-10-24	37573	59217	\N	\N
73597	SPECIFIC_DAY	3	9	2011-01-31	37573	59217	\N	\N
73598	SPECIFIC_DAY	3	0	2011-02-26	37573	59217	\N	\N
73599	SPECIFIC_DAY	3	0	2011-01-30	37573	59217	\N	\N
73600	SPECIFIC_DAY	3	9	2010-03-31	37573	59217	\N	\N
73601	SPECIFIC_DAY	3	9	2010-03-30	37573	59217	\N	\N
73602	SPECIFIC_DAY	3	0	2010-02-20	37573	59217	\N	\N
73603	SPECIFIC_DAY	3	9	2010-09-20	37573	59217	\N	\N
73604	SPECIFIC_DAY	3	9	2010-04-22	37573	59217	\N	\N
73605	SPECIFIC_DAY	3	9	2010-11-23	37573	59217	\N	\N
73606	SPECIFIC_DAY	3	9	2011-02-25	37573	59217	\N	\N
73607	SPECIFIC_DAY	3	0	2010-10-10	37573	59217	\N	\N
73608	SPECIFIC_DAY	3	9	2010-12-30	37573	59217	\N	\N
73609	SPECIFIC_DAY	3	9	2010-08-04	37573	59217	\N	\N
73610	SPECIFIC_DAY	3	0	2010-03-13	37573	59217	\N	\N
73611	SPECIFIC_DAY	3	9	2010-03-09	37573	59217	\N	\N
73612	SPECIFIC_DAY	3	0	2010-01-30	37573	59217	\N	\N
73613	SPECIFIC_DAY	3	0	2010-03-27	37573	59217	\N	\N
73614	SPECIFIC_DAY	3	0	2010-03-21	37573	59217	\N	\N
73615	SPECIFIC_DAY	3	9	2011-01-28	37573	59217	\N	\N
73616	SPECIFIC_DAY	3	0	2010-07-11	37573	59217	\N	\N
73617	SPECIFIC_DAY	3	9	2010-05-04	37573	59217	\N	\N
73618	SPECIFIC_DAY	3	0	2010-03-14	37573	59217	\N	\N
73619	SPECIFIC_DAY	3	9	2011-01-21	37573	59217	\N	\N
73620	SPECIFIC_DAY	3	0	2010-01-23	37573	59217	\N	\N
73621	SPECIFIC_DAY	3	0	2011-02-20	37573	59217	\N	\N
73622	SPECIFIC_DAY	3	0	2010-03-28	37573	59217	\N	\N
73623	SPECIFIC_DAY	3	0	2010-03-07	37573	59217	\N	\N
73624	SPECIFIC_DAY	3	9	2011-02-07	37573	59217	\N	\N
73625	SPECIFIC_DAY	3	9	2010-07-08	37573	59217	\N	\N
73626	SPECIFIC_DAY	3	0	2010-10-09	37573	59217	\N	\N
73627	SPECIFIC_DAY	3	9	2010-01-25	37573	59217	\N	\N
73628	SPECIFIC_DAY	3	0	2011-01-16	37573	59217	\N	\N
73629	SPECIFIC_DAY	3	9	2010-07-01	37573	59217	\N	\N
73630	SPECIFIC_DAY	3	9	2010-04-09	37573	59217	\N	\N
73631	SPECIFIC_DAY	3	9	2010-07-12	37573	59217	\N	\N
73632	SPECIFIC_DAY	3	9	2010-06-16	37573	59217	\N	\N
73633	SPECIFIC_DAY	3	9	2011-02-03	37573	59217	\N	\N
73634	SPECIFIC_DAY	3	9	2010-04-06	37573	59217	\N	\N
73635	SPECIFIC_DAY	3	9	2011-03-07	37573	59217	\N	\N
73636	SPECIFIC_DAY	3	0	2010-11-21	37573	59217	\N	\N
73637	SPECIFIC_DAY	3	0	2010-06-26	37573	59217	\N	\N
73638	SPECIFIC_DAY	3	9	2010-11-11	37573	59217	\N	\N
73639	SPECIFIC_DAY	3	0	2010-02-07	37573	59217	\N	\N
73640	SPECIFIC_DAY	3	0	2010-01-10	37573	59217	\N	\N
73641	SPECIFIC_DAY	3	9	2010-05-10	37573	59217	\N	\N
73642	SPECIFIC_DAY	3	9	2010-05-24	37573	59217	\N	\N
73643	SPECIFIC_DAY	3	9	2010-07-06	37573	59217	\N	\N
73644	SPECIFIC_DAY	3	9	2010-08-20	37573	59217	\N	\N
73645	SPECIFIC_DAY	3	9	2010-07-16	37573	59217	\N	\N
73646	SPECIFIC_DAY	3	0	2010-11-20	37573	59217	\N	\N
73647	SPECIFIC_DAY	3	9	2010-09-10	37573	59217	\N	\N
73648	SPECIFIC_DAY	3	0	2010-08-22	37573	59217	\N	\N
73649	SPECIFIC_DAY	3	9	2011-03-02	37573	59217	\N	\N
73650	SPECIFIC_DAY	3	9	2010-07-30	37573	59217	\N	\N
73651	SPECIFIC_DAY	3	9	2010-03-16	37573	59217	\N	\N
73652	SPECIFIC_DAY	3	0	2010-06-06	37573	59217	\N	\N
73653	SPECIFIC_DAY	3	9	2010-08-03	37573	59217	\N	\N
73654	SPECIFIC_DAY	3	9	2010-12-29	37573	59217	\N	\N
73655	SPECIFIC_DAY	3	9	2010-04-23	37573	59217	\N	\N
73656	SPECIFIC_DAY	3	9	2010-10-26	37573	59217	\N	\N
73657	SPECIFIC_DAY	3	9	2010-09-09	37573	59217	\N	\N
73658	SPECIFIC_DAY	3	9	2010-06-28	37573	59217	\N	\N
73659	SPECIFIC_DAY	3	9	2010-07-07	37573	59217	\N	\N
73660	SPECIFIC_DAY	3	9	2010-11-30	37573	59217	\N	\N
73661	SPECIFIC_DAY	3	9	2010-08-06	37573	59217	\N	\N
73662	SPECIFIC_DAY	3	9	2010-09-28	37573	59217	\N	\N
73663	SPECIFIC_DAY	3	0	2011-02-05	37573	59217	\N	\N
73664	SPECIFIC_DAY	3	9	2010-11-08	37573	59217	\N	\N
73665	SPECIFIC_DAY	3	9	2010-08-31	37573	59217	\N	\N
73666	SPECIFIC_DAY	3	9	2010-09-15	37573	59217	\N	\N
73667	SPECIFIC_DAY	3	9	2010-03-11	37573	59217	\N	\N
73668	SPECIFIC_DAY	3	9	2010-08-23	37573	59217	\N	\N
73669	SPECIFIC_DAY	3	9	2010-03-10	37573	59217	\N	\N
73670	SPECIFIC_DAY	3	0	2010-01-16	37573	59217	\N	\N
73671	SPECIFIC_DAY	3	9	2010-06-14	37573	59217	\N	\N
73672	SPECIFIC_DAY	3	0	2010-04-01	37573	59217	\N	\N
73673	SPECIFIC_DAY	3	0	2010-10-30	37573	59217	\N	\N
73674	SPECIFIC_DAY	3	9	2010-09-23	37573	59217	\N	\N
73675	SPECIFIC_DAY	3	9	2010-02-19	37573	59217	\N	\N
73676	SPECIFIC_DAY	3	9	2010-09-08	37573	59217	\N	\N
73677	SPECIFIC_DAY	3	0	2010-12-26	37573	59217	\N	\N
73678	SPECIFIC_DAY	3	9	2010-07-26	37573	59217	\N	\N
73679	SPECIFIC_DAY	3	9	2010-01-08	37573	59217	\N	\N
73680	SPECIFIC_DAY	3	9	2011-03-04	37573	59217	\N	\N
73681	SPECIFIC_DAY	3	9	2010-11-03	37573	59217	\N	\N
73682	SPECIFIC_DAY	3	0	2010-08-29	37573	59217	\N	\N
73683	SPECIFIC_DAY	3	0	2010-10-31	37573	59217	\N	\N
73684	SPECIFIC_DAY	3	9	2010-04-14	37573	59217	\N	\N
73685	SPECIFIC_DAY	3	0	2010-09-12	37573	59217	\N	\N
73686	SPECIFIC_DAY	3	9	2010-11-10	37573	59217	\N	\N
73687	SPECIFIC_DAY	3	9	2010-01-07	37573	59217	\N	\N
73688	SPECIFIC_DAY	3	9	2010-01-15	37573	59217	\N	\N
73689	SPECIFIC_DAY	3	0	2010-07-31	37573	59217	\N	\N
73690	SPECIFIC_DAY	3	0	2010-08-01	37573	59217	\N	\N
73691	SPECIFIC_DAY	3	9	2010-03-08	37573	59217	\N	\N
73692	SPECIFIC_DAY	3	9	2010-02-09	37573	59217	\N	\N
73693	SPECIFIC_DAY	3	9	2010-10-07	37573	59217	\N	\N
73694	SPECIFIC_DAY	3	9	2010-02-08	37573	59217	\N	\N
73695	SPECIFIC_DAY	3	0	2010-02-21	37573	59217	\N	\N
73696	SPECIFIC_DAY	3	9	2011-02-17	37573	59217	\N	\N
73697	SPECIFIC_DAY	3	9	2010-08-02	37573	59217	\N	\N
73698	SPECIFIC_DAY	3	9	2010-11-02	37573	59217	\N	\N
73699	SPECIFIC_DAY	3	9	2010-07-13	37573	59217	\N	\N
73700	SPECIFIC_DAY	3	0	2010-06-12	37573	59217	\N	\N
73701	SPECIFIC_DAY	3	9	2010-12-07	37573	59217	\N	\N
73702	SPECIFIC_DAY	3	9	2010-11-19	37573	59217	\N	\N
73703	SPECIFIC_DAY	3	9	2010-07-09	37573	59217	\N	\N
73704	SPECIFIC_DAY	3	9	2010-04-27	37573	59217	\N	\N
73705	SPECIFIC_DAY	3	9	2010-08-09	37573	59217	\N	\N
73706	SPECIFIC_DAY	3	9	2010-05-27	37573	59217	\N	\N
73707	SPECIFIC_DAY	3	9	2010-01-29	37573	59217	\N	\N
73708	SPECIFIC_DAY	3	0	2010-12-18	37573	59217	\N	\N
73709	SPECIFIC_DAY	3	9	2010-03-25	37573	59217	\N	\N
73710	SPECIFIC_DAY	3	9	2010-01-19	37573	59217	\N	\N
73711	SPECIFIC_DAY	3	0	2010-01-31	37573	59217	\N	\N
73712	SPECIFIC_DAY	3	9	2010-11-24	37573	59217	\N	\N
73713	SPECIFIC_DAY	3	9	2010-05-12	37573	59217	\N	\N
73714	SPECIFIC_DAY	3	9	2010-12-09	37573	59217	\N	\N
73715	SPECIFIC_DAY	3	9	2010-06-22	37573	59217	\N	\N
73716	SPECIFIC_DAY	3	9	2011-01-18	37573	59217	\N	\N
73717	SPECIFIC_DAY	3	9	2010-02-04	37573	59217	\N	\N
73718	SPECIFIC_DAY	3	9	2010-06-02	37573	59217	\N	\N
73719	SPECIFIC_DAY	3	9	2010-12-21	37573	59217	\N	\N
73720	SPECIFIC_DAY	3	9	2010-10-13	37573	59217	\N	\N
73721	SPECIFIC_DAY	3	9	2011-01-27	37573	59217	\N	\N
73722	SPECIFIC_DAY	3	9	2010-04-07	37573	59217	\N	\N
73723	SPECIFIC_DAY	3	0	2011-01-23	37573	59217	\N	\N
73724	SPECIFIC_DAY	3	0	2010-11-13	37573	59217	\N	\N
73725	SPECIFIC_DAY	3	9	2011-02-01	37573	59217	\N	\N
73726	SPECIFIC_DAY	3	0	2010-04-03	37573	59217	\N	\N
73727	SPECIFIC_DAY	3	0	2010-12-19	37573	59217	\N	\N
73728	SPECIFIC_DAY	3	0	2010-11-27	37573	59217	\N	\N
73729	SPECIFIC_DAY	3	0	2011-01-22	37573	59217	\N	\N
73730	SPECIFIC_DAY	3	9	2011-02-23	37573	59217	\N	\N
73731	SPECIFIC_DAY	3	9	2011-02-08	37573	59217	\N	\N
73732	SPECIFIC_DAY	3	9	2010-08-24	37573	59217	\N	\N
73733	SPECIFIC_DAY	3	9	2011-01-07	37573	59217	\N	\N
73734	SPECIFIC_DAY	3	0	2010-09-19	37573	59217	\N	\N
73735	SPECIFIC_DAY	3	0	2010-10-02	37573	59217	\N	\N
73736	SPECIFIC_DAY	3	0	2010-11-01	37573	59217	\N	\N
73737	SPECIFIC_DAY	3	0	2010-12-06	37573	59217	\N	\N
73738	SPECIFIC_DAY	3	0	2010-02-06	37573	59217	\N	\N
73739	SPECIFIC_DAY	3	9	2010-06-23	37573	59217	\N	\N
73740	SPECIFIC_DAY	3	9	2010-12-03	37573	59217	\N	\N
73741	SPECIFIC_DAY	3	9	2010-12-20	37573	59217	\N	\N
73742	SPECIFIC_DAY	3	9	2011-02-09	37573	59217	\N	\N
73743	SPECIFIC_DAY	3	9	2010-01-05	37573	59217	\N	\N
73744	SPECIFIC_DAY	3	9	2010-05-13	37573	59217	\N	\N
73745	SPECIFIC_DAY	3	9	2011-02-28	37573	59217	\N	\N
73746	SPECIFIC_DAY	3	9	2010-09-17	37573	59217	\N	\N
73747	SPECIFIC_DAY	3	9	2010-01-11	37573	59217	\N	\N
73748	SPECIFIC_DAY	3	9	2010-02-25	37573	59217	\N	\N
73749	SPECIFIC_DAY	3	0	2010-12-25	37573	59217	\N	\N
73750	SPECIFIC_DAY	3	0	2010-10-17	37573	59217	\N	\N
73751	SPECIFIC_DAY	3	9	2011-03-03	37573	59217	\N	\N
73752	SPECIFIC_DAY	3	9	2010-09-07	37573	59217	\N	\N
73753	SPECIFIC_DAY	3	0	2010-09-26	37573	59217	\N	\N
73754	SPECIFIC_DAY	3	0	2011-01-09	37573	59217	\N	\N
73755	SPECIFIC_DAY	3	9	2010-04-15	37573	59217	\N	\N
73756	SPECIFIC_DAY	3	9	2010-02-05	37573	59217	\N	\N
73757	SPECIFIC_DAY	3	9	2010-06-03	37573	59217	\N	\N
73758	SPECIFIC_DAY	3	9	2010-01-21	37573	59217	\N	\N
73759	SPECIFIC_DAY	3	0	2010-04-25	37573	59217	\N	\N
73760	SPECIFIC_DAY	3	0	2010-07-17	37573	59217	\N	\N
73761	SPECIFIC_DAY	3	9	2010-01-12	37573	59217	\N	\N
73762	SPECIFIC_DAY	3	0	2010-11-06	37573	59217	\N	\N
73763	SPECIFIC_DAY	3	9	2010-10-04	37573	59217	\N	\N
73764	SPECIFIC_DAY	3	9	2010-09-16	37573	59217	\N	\N
73765	SPECIFIC_DAY	3	9	2010-07-21	37573	59217	\N	\N
73766	SPECIFIC_DAY	3	9	2010-08-11	37573	59217	\N	\N
73767	SPECIFIC_DAY	3	9	2010-08-25	37573	59217	\N	\N
73768	SPECIFIC_DAY	3	0	2010-08-15	37573	59217	\N	\N
73769	SPECIFIC_DAY	3	0	2010-05-17	37573	59217	\N	\N
73770	SPECIFIC_DAY	3	0	2011-01-29	37573	59217	\N	\N
73771	SPECIFIC_DAY	3	0	2010-04-18	37573	59217	\N	\N
73772	SPECIFIC_DAY	3	0	2010-07-03	37573	59217	\N	\N
73773	SPECIFIC_DAY	3	9	2010-10-19	37573	59217	\N	\N
73774	SPECIFIC_DAY	3	0	2010-06-20	37573	59217	\N	\N
73775	SPECIFIC_DAY	3	9	2011-01-20	37573	59217	\N	\N
73776	SPECIFIC_DAY	3	9	2010-09-13	37573	59217	\N	\N
73777	SPECIFIC_DAY	3	0	2010-11-14	37573	59217	\N	\N
73778	SPECIFIC_DAY	3	9	2010-09-29	37573	59217	\N	\N
73779	SPECIFIC_DAY	3	9	2010-04-13	37573	59217	\N	\N
73780	SPECIFIC_DAY	3	0	2010-05-22	37573	59217	\N	\N
73781	SPECIFIC_DAY	3	0	2010-05-08	37573	59217	\N	\N
73782	SPECIFIC_DAY	3	0	2010-04-05	37573	59217	\N	\N
73783	SPECIFIC_DAY	3	9	2010-05-20	37573	59217	\N	\N
73784	SPECIFIC_DAY	3	9	2011-02-18	37573	59217	\N	\N
73785	SPECIFIC_DAY	3	0	2010-02-28	37573	59217	\N	\N
73786	SPECIFIC_DAY	3	9	2010-09-30	37573	59217	\N	\N
73787	SPECIFIC_DAY	3	9	2010-07-29	37573	59217	\N	\N
73788	SPECIFIC_DAY	3	9	2010-11-22	37573	59217	\N	\N
73789	SPECIFIC_DAY	3	9	2010-04-30	37573	59217	\N	\N
73790	SPECIFIC_DAY	3	0	2010-09-25	37573	59217	\N	\N
73791	SPECIFIC_DAY	3	9	2010-02-22	37573	59217	\N	\N
73792	SPECIFIC_DAY	3	9	2010-11-09	37573	59217	\N	\N
73793	SPECIFIC_DAY	3	9	2010-06-08	37573	59217	\N	\N
73794	SPECIFIC_DAY	3	9	2010-02-01	37573	59217	\N	\N
73795	SPECIFIC_DAY	3	9	2010-03-22	37573	59217	\N	\N
73796	SPECIFIC_DAY	3	9	2011-01-06	37573	59217	\N	\N
73797	SPECIFIC_DAY	3	9	2010-11-29	37573	59217	\N	\N
73798	SPECIFIC_DAY	3	9	2010-07-14	37573	59217	\N	\N
73799	SPECIFIC_DAY	3	9	2010-07-27	37573	59217	\N	\N
73800	SPECIFIC_DAY	3	9	2010-01-27	37573	59217	\N	\N
73801	SPECIFIC_DAY	3	0	2010-11-28	37573	59217	\N	\N
73802	SPECIFIC_DAY	3	9	2011-01-26	37573	59217	\N	\N
73803	SPECIFIC_DAY	3	9	2010-03-01	37573	59217	\N	\N
73804	SPECIFIC_DAY	3	0	2010-03-06	37573	59217	\N	\N
73805	SPECIFIC_DAY	3	9	2010-02-16	37573	59217	\N	\N
73806	SPECIFIC_DAY	3	9	2010-11-26	37573	59217	\N	\N
73807	SPECIFIC_DAY	3	9	2010-07-05	37573	59217	\N	\N
73808	SPECIFIC_DAY	3	0	2010-09-04	37573	59217	\N	\N
73809	SPECIFIC_DAY	3	9	2010-09-22	37573	59217	\N	\N
73810	SPECIFIC_DAY	3	9	2010-05-31	37573	59217	\N	\N
73811	SPECIFIC_DAY	3	9	2011-01-13	37573	59217	\N	\N
73812	SPECIFIC_DAY	3	9	2010-07-19	37573	59217	\N	\N
73813	SPECIFIC_DAY	3	0	2010-07-10	37573	59217	\N	\N
73814	SPECIFIC_DAY	3	9	2010-06-17	37573	59217	\N	\N
73815	SPECIFIC_DAY	3	9	2010-04-29	37573	59217	\N	\N
73816	SPECIFIC_DAY	3	9	2010-06-07	37573	59217	\N	\N
73817	SPECIFIC_DAY	3	9	2010-12-28	37573	59217	\N	\N
73818	SPECIFIC_DAY	3	9	2010-02-24	37573	59217	\N	\N
73819	SPECIFIC_DAY	3	9	2010-02-15	37573	59217	\N	\N
73820	SPECIFIC_DAY	3	9	2011-01-03	37573	59217	\N	\N
73821	SPECIFIC_DAY	3	0	2010-04-10	37573	59217	\N	\N
73822	SPECIFIC_DAY	3	9	2011-01-17	37573	59217	\N	\N
73823	SPECIFIC_DAY	3	0	2010-02-13	37573	59217	\N	\N
73824	SPECIFIC_DAY	3	9	2011-01-04	37573	59217	\N	\N
73825	SPECIFIC_DAY	3	9	2010-12-10	37573	59217	\N	\N
73826	SPECIFIC_DAY	3	0	2011-03-05	37573	59217	\N	\N
73827	SPECIFIC_DAY	3	9	2010-07-23	37573	59217	\N	\N
73828	SPECIFIC_DAY	3	9	2010-12-24	37573	59217	\N	\N
73829	SPECIFIC_DAY	3	9	2010-12-16	37573	59217	\N	\N
73830	SPECIFIC_DAY	3	9	2010-10-18	37573	59217	\N	\N
73831	SPECIFIC_DAY	3	9	2010-12-27	37573	59217	\N	\N
69243	SPECIFIC_DAY	5	0	2009-12-20	49302	68696	\N	\N
69256	SPECIFIC_DAY	5	4	2009-12-16	49302	68696	\N	\N
69238	SPECIFIC_DAY	5	0	2009-12-19	49302	68696	\N	\N
69235	SPECIFIC_DAY	5	4	2009-12-22	49302	68696	\N	\N
69250	SPECIFIC_DAY	5	4	2009-12-30	49302	68696	\N	\N
69239	SPECIFIC_DAY	5	4	2009-12-23	49302	68696	\N	\N
69251	SPECIFIC_DAY	5	0	2009-12-27	49302	68696	\N	\N
69242	SPECIFIC_DAY	5	4	2009-12-17	49302	68696	\N	\N
69245	SPECIFIC_DAY	5	4	2009-12-29	49302	68696	\N	\N
69252	SPECIFIC_DAY	5	0	2009-12-25	49302	68696	\N	\N
69240	SPECIFIC_DAY	5	1	2010-01-04	49302	68696	\N	\N
69255	SPECIFIC_DAY	5	4	2009-12-15	49302	68696	\N	\N
69237	SPECIFIC_DAY	5	4	2009-12-18	49302	68696	\N	\N
69248	SPECIFIC_DAY	5	4	2009-12-14	49302	68696	\N	\N
69246	SPECIFIC_DAY	5	4	2009-12-21	49302	68696	\N	\N
69241	SPECIFIC_DAY	5	0	2010-01-02	49302	68696	\N	\N
69244	SPECIFIC_DAY	5	0	2009-12-26	49302	68696	\N	\N
69253	SPECIFIC_DAY	5	0	2010-01-03	49302	68696	\N	\N
69236	SPECIFIC_DAY	5	4	2009-12-28	49302	68696	\N	\N
69247	SPECIFIC_DAY	5	4	2009-12-24	49302	68696	\N	\N
69254	SPECIFIC_DAY	5	4	2009-12-31	49302	68696	\N	\N
69249	SPECIFIC_DAY	5	0	2010-01-01	49302	68696	\N	\N
69216	SPECIFIC_DAY	5	0	2010-01-03	49289	68695	\N	\N
69231	SPECIFIC_DAY	5	0	2009-12-25	49289	68695	\N	\N
69224	SPECIFIC_DAY	5	4	2009-12-31	49289	68695	\N	\N
69234	SPECIFIC_DAY	5	4	2009-12-24	49289	68695	\N	\N
69226	SPECIFIC_DAY	5	0	2009-12-19	49289	68695	\N	\N
69233	SPECIFIC_DAY	5	4	2009-12-28	49289	68695	\N	\N
69232	SPECIFIC_DAY	5	0	2009-12-20	49289	68695	\N	\N
69219	SPECIFIC_DAY	5	0	2010-01-01	49289	68695	\N	\N
69229	SPECIFIC_DAY	5	4	2009-12-16	49289	68695	\N	\N
69227	SPECIFIC_DAY	5	0	2010-01-04	49289	68695	\N	\N
69214	SPECIFIC_DAY	5	4	2009-12-30	49289	68695	\N	\N
69223	SPECIFIC_DAY	5	4	2009-12-29	49289	68695	\N	\N
61068	SPECIFIC_DAY	16	7	2009-12-17	49309	60448	\N	\N
61073	SPECIFIC_DAY	16	0	2009-12-19	49309	60448	\N	\N
61072	SPECIFIC_DAY	16	7	2009-12-15	49309	60448	\N	\N
61071	SPECIFIC_DAY	16	7	2009-12-16	49309	60448	\N	\N
61067	SPECIFIC_DAY	16	7	2009-12-21	49309	60448	\N	\N
61070	SPECIFIC_DAY	16	7	2009-12-14	49309	60448	\N	\N
61069	SPECIFIC_DAY	16	0	2009-12-20	49309	60448	\N	\N
61074	SPECIFIC_DAY	16	7	2009-12-18	49309	60448	\N	\N
73832	SPECIFIC_DAY	3	9	2010-07-02	37573	59217	\N	\N
73833	SPECIFIC_DAY	3	0	2010-09-18	49309	68681	\N	\N
73834	SPECIFIC_DAY	3	7	2010-09-16	49309	68681	\N	\N
73835	SPECIFIC_DAY	3	7	2010-09-20	49309	68681	\N	\N
73836	SPECIFIC_DAY	3	7	2010-09-15	49309	68681	\N	\N
73837	SPECIFIC_DAY	3	0	2010-09-11	49309	68681	\N	\N
73838	SPECIFIC_DAY	3	7	2010-09-21	49309	68681	\N	\N
73839	SPECIFIC_DAY	3	7	2010-09-14	49309	68681	\N	\N
73840	SPECIFIC_DAY	3	7	2010-09-17	49309	68681	\N	\N
73841	SPECIFIC_DAY	3	0	2010-09-19	49309	68681	\N	\N
73842	SPECIFIC_DAY	3	7	2010-09-13	49309	68681	\N	\N
73843	SPECIFIC_DAY	3	0	2010-09-12	49309	68681	\N	\N
73844	SPECIFIC_DAY	3	4	2010-01-29	49300	68682	\N	\N
73845	SPECIFIC_DAY	3	0	2011-04-02	37573	60440	\N	\N
73846	SPECIFIC_DAY	3	7	2011-04-06	37573	60440	\N	\N
73847	SPECIFIC_DAY	3	7	2011-03-22	37573	60440	\N	\N
73848	SPECIFIC_DAY	3	7	2011-04-05	37573	60440	\N	\N
73849	SPECIFIC_DAY	3	7	2011-03-31	37573	60440	\N	\N
73850	SPECIFIC_DAY	3	7	2011-03-18	37573	60440	\N	\N
73851	SPECIFIC_DAY	3	0	2011-03-19	37573	60440	\N	\N
73852	SPECIFIC_DAY	3	7	2011-04-04	37573	60440	\N	\N
73853	SPECIFIC_DAY	3	0	2011-03-20	37573	60440	\N	\N
73854	SPECIFIC_DAY	3	0	2011-04-03	37573	60440	\N	\N
73855	SPECIFIC_DAY	3	7	2011-03-25	37573	60440	\N	\N
73856	SPECIFIC_DAY	3	7	2011-03-21	37573	60440	\N	\N
73857	SPECIFIC_DAY	3	0	2011-03-26	37573	60440	\N	\N
73858	SPECIFIC_DAY	3	7	2011-03-23	37573	60440	\N	\N
73859	SPECIFIC_DAY	3	7	2011-03-24	37573	60440	\N	\N
73860	SPECIFIC_DAY	3	7	2011-03-29	37573	60440	\N	\N
73861	SPECIFIC_DAY	3	0	2011-03-27	37573	60440	\N	\N
73862	SPECIFIC_DAY	3	7	2011-03-30	37573	60440	\N	\N
73863	SPECIFIC_DAY	3	7	2011-04-01	37573	60440	\N	\N
73864	SPECIFIC_DAY	3	7	2011-03-28	37573	60440	\N	\N
73865	SPECIFIC_DAY	3	0	2011-05-07	37573	60441	\N	\N
73866	SPECIFIC_DAY	3	0	2011-04-10	37573	60441	\N	\N
73867	SPECIFIC_DAY	3	7	2011-05-13	37573	60441	\N	\N
73868	SPECIFIC_DAY	3	7	2011-04-12	37573	60441	\N	\N
73869	SPECIFIC_DAY	3	7	2011-04-13	37573	60441	\N	\N
73870	SPECIFIC_DAY	3	7	2011-04-18	37573	60441	\N	\N
73871	SPECIFIC_DAY	3	7	2011-04-20	37573	60441	\N	\N
73872	SPECIFIC_DAY	3	7	2011-05-10	37573	60441	\N	\N
73873	SPECIFIC_DAY	3	7	2011-05-05	37573	60441	\N	\N
73874	SPECIFIC_DAY	3	7	2011-04-29	37573	60441	\N	\N
73875	SPECIFIC_DAY	3	7	2011-04-07	37573	60441	\N	\N
73876	SPECIFIC_DAY	3	7	2011-04-27	37573	60441	\N	\N
73877	SPECIFIC_DAY	3	7	2011-04-22	37573	60441	\N	\N
73878	SPECIFIC_DAY	3	7	2011-05-03	37573	60441	\N	\N
73879	SPECIFIC_DAY	3	0	2011-04-09	37573	60441	\N	\N
73880	SPECIFIC_DAY	3	7	2011-05-16	37573	60441	\N	\N
73881	SPECIFIC_DAY	3	0	2011-04-17	37573	60441	\N	\N
73882	SPECIFIC_DAY	3	7	2011-04-19	37573	60441	\N	\N
73883	SPECIFIC_DAY	3	0	2011-04-16	37573	60441	\N	\N
73884	SPECIFIC_DAY	3	0	2011-05-01	37573	60441	\N	\N
73885	SPECIFIC_DAY	3	0	2011-04-24	37573	60441	\N	\N
73886	SPECIFIC_DAY	3	7	2011-05-06	37573	60441	\N	\N
73887	SPECIFIC_DAY	3	7	2011-04-26	37573	60441	\N	\N
73888	SPECIFIC_DAY	3	0	2011-05-15	37573	60441	\N	\N
73889	SPECIFIC_DAY	3	7	2011-05-04	37573	60441	\N	\N
73890	SPECIFIC_DAY	3	7	2011-04-11	37573	60441	\N	\N
73891	SPECIFIC_DAY	3	0	2011-05-14	37573	60441	\N	\N
73892	SPECIFIC_DAY	3	7	2011-05-02	37573	60441	\N	\N
73893	SPECIFIC_DAY	3	7	2011-05-09	37573	60441	\N	\N
73894	SPECIFIC_DAY	3	7	2011-04-08	37573	60441	\N	\N
73895	SPECIFIC_DAY	3	7	2011-04-15	37573	60441	\N	\N
73896	SPECIFIC_DAY	3	7	2011-04-21	37573	60441	\N	\N
73897	SPECIFIC_DAY	3	7	2011-04-25	37573	60441	\N	\N
73898	SPECIFIC_DAY	3	0	2011-05-08	37573	60441	\N	\N
73899	SPECIFIC_DAY	3	7	2011-05-11	37573	60441	\N	\N
73900	SPECIFIC_DAY	3	0	2011-04-30	37573	60441	\N	\N
73901	SPECIFIC_DAY	3	7	2011-04-28	37573	60441	\N	\N
73902	SPECIFIC_DAY	3	7	2011-04-14	37573	60441	\N	\N
73903	SPECIFIC_DAY	3	0	2011-04-23	37573	60441	\N	\N
69147	SPECIFIC_DAY	5	1	2009-12-22	49289	68692	\N	\N
69188	SPECIFIC_DAY	5	0	2009-12-25	49289	68692	\N	\N
69151	SPECIFIC_DAY	5	1	2010-01-08	49289	68692	\N	\N
69154	SPECIFIC_DAY	5	0	2010-01-02	49289	68692	\N	\N
69174	SPECIFIC_DAY	5	1	2009-12-23	49289	68692	\N	\N
69165	SPECIFIC_DAY	5	1	2010-01-21	49289	68692	\N	\N
69157	SPECIFIC_DAY	5	1	2010-01-13	49289	68692	\N	\N
69156	SPECIFIC_DAY	5	0	2009-12-20	49289	68692	\N	\N
69155	SPECIFIC_DAY	5	1	2010-01-28	49289	68692	\N	\N
69186	SPECIFIC_DAY	5	1	2009-12-24	49289	68692	\N	\N
73904	SPECIFIC_DAY	3	7	2011-05-12	37573	60441	\N	\N
73905	SPECIFIC_DAY	3	82	2011-05-17	37573	60442	\N	\N
73906	SPECIFIC_DAY	3	82	2011-05-18	37573	60442	\N	\N
73907	SPECIFIC_DAY	3	81	2011-05-19	37573	60442	\N	\N
73908	SPECIFIC_DAY	3	30	2011-05-21	37573	60443	\N	\N
73909	SPECIFIC_DAY	3	30	2011-05-22	37573	60443	\N	\N
73910	SPECIFIC_DAY	3	38	2011-05-20	37573	60443	\N	\N
73911	SPECIFIC_DAY	3	65	2011-05-24	37573	60444	\N	\N
73912	SPECIFIC_DAY	3	66	2011-05-23	37573	60444	\N	\N
73913	SPECIFIC_DAY	3	65	2011-05-25	37573	60444	\N	\N
73914	SPECIFIC_DAY	3	0	2010-06-26	40199	59220	\N	\N
73915	SPECIFIC_DAY	3	7	2010-04-15	40199	59220	\N	\N
73916	SPECIFIC_DAY	3	7	2009-12-24	40199	59220	\N	\N
73917	SPECIFIC_DAY	3	0	2010-08-22	40199	59220	\N	\N
73918	SPECIFIC_DAY	3	7	2010-08-11	40199	59220	\N	\N
73919	SPECIFIC_DAY	3	0	2010-01-24	40199	59220	\N	\N
73920	SPECIFIC_DAY	3	7	2010-07-15	40199	59220	\N	\N
73921	SPECIFIC_DAY	3	7	2010-07-27	40199	59220	\N	\N
73922	SPECIFIC_DAY	3	7	2010-06-21	40199	59220	\N	\N
73923	SPECIFIC_DAY	3	7	2010-06-02	40199	59220	\N	\N
73924	SPECIFIC_DAY	3	7	2010-07-01	40199	59220	\N	\N
73925	SPECIFIC_DAY	3	7	2010-05-07	40199	59220	\N	\N
73926	SPECIFIC_DAY	3	7	2010-02-10	40199	59220	\N	\N
73927	SPECIFIC_DAY	3	7	2010-02-23	40199	59220	\N	\N
73928	SPECIFIC_DAY	3	0	2010-09-05	40199	59220	\N	\N
73929	SPECIFIC_DAY	3	7	2010-02-19	40199	59220	\N	\N
73930	SPECIFIC_DAY	3	7	2010-05-28	40199	59220	\N	\N
73931	SPECIFIC_DAY	3	7	2010-02-01	40199	59220	\N	\N
73932	SPECIFIC_DAY	3	7	2010-09-07	40199	59220	\N	\N
73933	SPECIFIC_DAY	3	7	2010-04-09	40199	59220	\N	\N
73934	SPECIFIC_DAY	3	0	2010-09-04	40199	59220	\N	\N
73935	SPECIFIC_DAY	3	7	2010-04-22	40199	59220	\N	\N
73936	SPECIFIC_DAY	3	0	2010-07-31	40199	59220	\N	\N
73937	SPECIFIC_DAY	3	0	2009-12-25	40199	59220	\N	\N
73938	SPECIFIC_DAY	3	7	2010-04-28	40199	59220	\N	\N
73939	SPECIFIC_DAY	3	0	2010-07-11	40199	59220	\N	\N
73940	SPECIFIC_DAY	3	7	2010-05-14	40199	59220	\N	\N
73941	SPECIFIC_DAY	3	7	2010-02-22	40199	59220	\N	\N
73942	SPECIFIC_DAY	3	0	2010-08-21	40199	59220	\N	\N
73943	SPECIFIC_DAY	3	7	2010-05-12	40199	59220	\N	\N
73944	SPECIFIC_DAY	3	7	2010-07-23	40199	59220	\N	\N
73945	SPECIFIC_DAY	3	7	2010-08-23	40199	59220	\N	\N
73946	SPECIFIC_DAY	3	7	2010-02-05	40199	59220	\N	\N
73947	SPECIFIC_DAY	3	0	2010-04-02	40199	59220	\N	\N
73948	SPECIFIC_DAY	3	7	2010-05-27	40199	59220	\N	\N
73949	SPECIFIC_DAY	3	7	2010-03-02	40199	59220	\N	\N
73950	SPECIFIC_DAY	3	7	2010-08-27	40199	59220	\N	\N
73951	SPECIFIC_DAY	3	7	2010-09-08	40199	59220	\N	\N
73952	SPECIFIC_DAY	3	7	2010-01-25	40199	59220	\N	\N
73953	SPECIFIC_DAY	3	7	2010-03-12	40199	59220	\N	\N
73954	SPECIFIC_DAY	3	7	2010-02-12	40199	59220	\N	\N
73955	SPECIFIC_DAY	3	7	2010-02-25	40199	59220	\N	\N
73956	SPECIFIC_DAY	3	7	2010-05-13	40199	59220	\N	\N
73957	SPECIFIC_DAY	3	7	2010-04-19	40199	59220	\N	\N
73958	SPECIFIC_DAY	3	7	2010-07-28	40199	59220	\N	\N
73959	SPECIFIC_DAY	3	0	2010-05-17	40199	59220	\N	\N
73960	SPECIFIC_DAY	3	7	2010-08-17	40199	59220	\N	\N
73961	SPECIFIC_DAY	3	0	2010-03-20	40199	59220	\N	\N
73962	SPECIFIC_DAY	3	0	2010-05-01	40199	59220	\N	\N
73963	SPECIFIC_DAY	3	7	2010-08-02	40199	59220	\N	\N
73964	SPECIFIC_DAY	3	0	2009-12-19	40199	59220	\N	\N
73965	SPECIFIC_DAY	3	7	2010-06-04	40199	59220	\N	\N
73966	SPECIFIC_DAY	3	0	2010-04-24	40199	59220	\N	\N
73967	SPECIFIC_DAY	3	7	2010-02-03	40199	59220	\N	\N
73968	SPECIFIC_DAY	3	7	2010-08-31	40199	59220	\N	\N
73969	SPECIFIC_DAY	3	7	2010-03-10	40199	59220	\N	\N
73970	SPECIFIC_DAY	3	0	2010-01-03	40199	59220	\N	\N
73971	SPECIFIC_DAY	3	7	2010-09-06	40199	59220	\N	\N
66738	SPECIFIC_DAY	5	3	2010-01-13	49302	66061	\N	\N
66711	SPECIFIC_DAY	5	0	2009-12-19	49302	66061	\N	\N
66736	SPECIFIC_DAY	5	0	2010-01-06	49302	66061	\N	\N
66739	SPECIFIC_DAY	5	4	2009-12-30	49302	66061	\N	\N
66700	SPECIFIC_DAY	5	4	2009-12-31	49302	66061	\N	\N
66705	SPECIFIC_DAY	5	3	2010-01-15	49302	66061	\N	\N
66699	SPECIFIC_DAY	5	4	2009-12-22	49302	66061	\N	\N
66712	SPECIFIC_DAY	5	4	2009-12-28	49302	66061	\N	\N
66703	SPECIFIC_DAY	5	4	2009-12-29	49302	66061	\N	\N
66708	SPECIFIC_DAY	5	0	2010-01-23	49302	66061	\N	\N
66737	SPECIFIC_DAY	5	4	2009-12-24	49302	66061	\N	\N
66731	SPECIFIC_DAY	5	4	2009-12-21	49302	66061	\N	\N
66730	SPECIFIC_DAY	5	4	2010-01-11	49302	66061	\N	\N
66706	SPECIFIC_DAY	5	4	2010-01-08	49302	66061	\N	\N
66742	SPECIFIC_DAY	5	0	2010-01-01	49302	66061	\N	\N
66702	SPECIFIC_DAY	5	3	2010-01-18	49302	66061	\N	\N
66714	SPECIFIC_DAY	5	0	2009-12-25	49302	66061	\N	\N
66726	SPECIFIC_DAY	5	0	2010-01-24	49302	66061	\N	\N
66735	SPECIFIC_DAY	5	0	2009-12-27	49302	66061	\N	\N
66732	SPECIFIC_DAY	5	4	2009-12-14	49302	66061	\N	\N
66727	SPECIFIC_DAY	5	3	2010-01-21	49302	66061	\N	\N
66725	SPECIFIC_DAY	5	0	2009-12-20	49302	66061	\N	\N
66719	SPECIFIC_DAY	5	0	2010-01-17	49302	66061	\N	\N
66721	SPECIFIC_DAY	5	4	2010-01-05	49302	66061	\N	\N
66733	SPECIFIC_DAY	5	4	2009-12-15	49302	66061	\N	\N
66722	SPECIFIC_DAY	5	4	2010-01-07	49302	66061	\N	\N
66716	SPECIFIC_DAY	5	4	2009-12-16	49302	66061	\N	\N
66723	SPECIFIC_DAY	5	3	2010-01-25	49302	66061	\N	\N
66720	SPECIFIC_DAY	5	4	2009-12-23	49302	66061	\N	\N
66697	SPECIFIC_DAY	5	4	2010-01-12	49302	66061	\N	\N
66734	SPECIFIC_DAY	5	0	2009-12-26	49302	66061	\N	\N
66704	SPECIFIC_DAY	5	0	2010-01-16	49302	66061	\N	\N
66710	SPECIFIC_DAY	5	3	2010-01-19	49302	66061	\N	\N
66724	SPECIFIC_DAY	5	0	2010-01-09	49302	66061	\N	\N
66707	SPECIFIC_DAY	5	3	2010-01-27	49302	66061	\N	\N
66698	SPECIFIC_DAY	5	4	2009-12-18	49302	66061	\N	\N
66729	SPECIFIC_DAY	5	0	2010-01-03	49302	66061	\N	\N
66717	SPECIFIC_DAY	5	3	2010-01-28	49302	66061	\N	\N
66728	SPECIFIC_DAY	5	0	2010-01-02	49302	66061	\N	\N
66701	SPECIFIC_DAY	5	4	2009-12-17	49302	66061	\N	\N
73972	SPECIFIC_DAY	3	0	2010-06-13	40199	59220	\N	\N
73973	SPECIFIC_DAY	3	7	2010-05-19	40199	59220	\N	\N
73974	SPECIFIC_DAY	3	7	2010-06-24	40199	59220	\N	\N
73975	SPECIFIC_DAY	3	7	2010-08-09	40199	59220	\N	\N
73976	SPECIFIC_DAY	3	7	2010-08-06	40199	59220	\N	\N
73977	SPECIFIC_DAY	3	0	2010-01-30	40199	59220	\N	\N
73978	SPECIFIC_DAY	3	7	2010-01-29	40199	59220	\N	\N
73979	SPECIFIC_DAY	3	0	2010-08-28	40199	59220	\N	\N
68647	SPECIFIC_DAY	5	7	2009-12-14	49300	68680	\N	\N
68646	SPECIFIC_DAY	5	7	2009-12-18	49300	68680	\N	\N
68644	SPECIFIC_DAY	5	7	2009-12-16	49300	68680	\N	\N
68645	SPECIFIC_DAY	5	7	2009-12-17	49300	68680	\N	\N
68643	SPECIFIC_DAY	5	7	2009-12-15	49300	68680	\N	\N
73980	SPECIFIC_DAY	3	0	2010-03-13	40199	59220	\N	\N
73981	SPECIFIC_DAY	3	0	2010-07-17	40199	59220	\N	\N
73982	SPECIFIC_DAY	3	7	2010-02-16	40199	59220	\N	\N
73983	SPECIFIC_DAY	3	7	2010-08-20	40199	59220	\N	\N
73984	SPECIFIC_DAY	3	0	2010-02-13	40199	59220	\N	\N
73985	SPECIFIC_DAY	3	7	2010-05-26	40199	59220	\N	\N
73986	SPECIFIC_DAY	3	0	2010-06-19	40199	59220	\N	\N
73987	SPECIFIC_DAY	3	7	2010-01-15	40199	59220	\N	\N
73988	SPECIFIC_DAY	3	7	2010-04-12	40199	59220	\N	\N
73989	SPECIFIC_DAY	3	0	2010-01-17	40199	59220	\N	\N
73990	SPECIFIC_DAY	3	0	2010-05-16	40199	59220	\N	\N
73991	SPECIFIC_DAY	3	7	2010-05-03	40199	59220	\N	\N
73992	SPECIFIC_DAY	3	0	2010-02-21	40199	59220	\N	\N
73993	SPECIFIC_DAY	3	7	2010-06-10	40199	59220	\N	\N
73994	SPECIFIC_DAY	3	7	2010-01-11	40199	59220	\N	\N
73995	SPECIFIC_DAY	3	7	2010-06-18	40199	59220	\N	\N
73996	SPECIFIC_DAY	3	7	2010-05-06	40199	59220	\N	\N
73997	SPECIFIC_DAY	3	7	2010-02-04	40199	59220	\N	\N
73998	SPECIFIC_DAY	3	0	2010-01-23	40199	59220	\N	\N
73999	SPECIFIC_DAY	3	7	2010-03-01	40199	59220	\N	\N
74000	SPECIFIC_DAY	3	7	2010-04-26	40199	59220	\N	\N
74001	SPECIFIC_DAY	3	7	2010-04-07	40199	59220	\N	\N
74002	SPECIFIC_DAY	3	0	2010-07-24	40199	59220	\N	\N
74003	SPECIFIC_DAY	3	0	2010-04-11	40199	59220	\N	\N
74004	SPECIFIC_DAY	3	0	2010-05-29	40199	59220	\N	\N
74005	SPECIFIC_DAY	3	7	2010-04-27	40199	59220	\N	\N
74006	SPECIFIC_DAY	3	7	2010-01-18	40199	59220	\N	\N
74007	SPECIFIC_DAY	3	0	2009-12-27	40199	59220	\N	\N
74008	SPECIFIC_DAY	3	7	2010-08-30	40199	59220	\N	\N
74009	SPECIFIC_DAY	3	0	2010-03-07	40199	59220	\N	\N
74010	SPECIFIC_DAY	3	7	2010-05-21	40199	59220	\N	\N
74011	SPECIFIC_DAY	3	0	2010-07-10	40199	59220	\N	\N
74012	SPECIFIC_DAY	3	7	2010-05-04	40199	59220	\N	\N
74013	SPECIFIC_DAY	3	0	2010-01-02	40199	59220	\N	\N
74014	SPECIFIC_DAY	3	7	2010-07-30	40199	59220	\N	\N
74015	SPECIFIC_DAY	3	0	2010-05-02	40199	59220	\N	\N
74016	SPECIFIC_DAY	3	7	2010-02-24	40199	59220	\N	\N
74017	SPECIFIC_DAY	3	0	2010-04-01	40199	59220	\N	\N
74018	SPECIFIC_DAY	3	7	2010-03-04	40199	59220	\N	\N
74019	SPECIFIC_DAY	3	0	2010-06-20	40199	59220	\N	\N
74020	SPECIFIC_DAY	3	0	2010-04-03	40199	59220	\N	\N
74021	SPECIFIC_DAY	3	7	2010-04-08	40199	59220	\N	\N
74022	SPECIFIC_DAY	3	7	2010-06-09	40199	59220	\N	\N
74023	SPECIFIC_DAY	3	0	2010-01-10	40199	59220	\N	\N
74024	SPECIFIC_DAY	3	0	2010-05-30	40199	59220	\N	\N
74025	SPECIFIC_DAY	3	7	2010-07-12	40199	59220	\N	\N
74026	SPECIFIC_DAY	3	0	2010-01-06	40199	59220	\N	\N
74027	SPECIFIC_DAY	3	7	2010-03-08	40199	59220	\N	\N
74028	SPECIFIC_DAY	3	0	2010-03-27	40199	59220	\N	\N
74029	SPECIFIC_DAY	3	7	2010-03-09	40199	59220	\N	\N
74030	SPECIFIC_DAY	3	7	2010-06-28	40199	59220	\N	\N
74031	SPECIFIC_DAY	3	0	2010-02-28	40199	59220	\N	\N
74032	SPECIFIC_DAY	3	7	2010-07-06	40199	59220	\N	\N
74033	SPECIFIC_DAY	3	7	2010-04-21	40199	59220	\N	\N
74034	SPECIFIC_DAY	3	7	2010-08-24	40199	59220	\N	\N
74035	SPECIFIC_DAY	3	7	2010-03-24	40199	59220	\N	\N
74036	SPECIFIC_DAY	3	0	2010-08-01	40199	59220	\N	\N
74037	SPECIFIC_DAY	3	7	2010-03-23	40199	59220	\N	\N
74038	SPECIFIC_DAY	3	7	2010-03-29	40199	59220	\N	\N
74039	SPECIFIC_DAY	3	7	2010-07-22	40199	59220	\N	\N
74040	SPECIFIC_DAY	3	0	2010-07-18	40199	59220	\N	\N
74041	SPECIFIC_DAY	3	7	2010-07-29	40199	59220	\N	\N
74042	SPECIFIC_DAY	3	7	2009-12-22	40199	59220	\N	\N
74043	SPECIFIC_DAY	3	0	2010-02-14	40199	59220	\N	\N
74044	SPECIFIC_DAY	3	0	2009-12-31	40199	59220	\N	\N
74045	SPECIFIC_DAY	3	7	2010-06-25	40199	59220	\N	\N
74046	SPECIFIC_DAY	3	7	2010-07-02	40199	59220	\N	\N
74047	SPECIFIC_DAY	3	7	2010-06-17	40199	59220	\N	\N
74048	SPECIFIC_DAY	3	7	2010-04-23	40199	59220	\N	\N
74049	SPECIFIC_DAY	3	7	2010-08-04	40199	59220	\N	\N
74050	SPECIFIC_DAY	3	7	2010-04-13	40199	59220	\N	\N
74051	SPECIFIC_DAY	3	0	2010-03-28	40199	59220	\N	\N
74052	SPECIFIC_DAY	3	7	2010-01-12	40199	59220	\N	\N
74053	SPECIFIC_DAY	3	7	2010-01-20	40199	59220	\N	\N
74054	SPECIFIC_DAY	3	7	2010-01-08	40199	59220	\N	\N
74055	SPECIFIC_DAY	3	7	2010-03-22	40199	59220	\N	\N
74056	SPECIFIC_DAY	3	7	2010-08-05	40199	59220	\N	\N
74057	SPECIFIC_DAY	3	7	2010-05-24	40199	59220	\N	\N
74058	SPECIFIC_DAY	3	0	2010-07-04	40199	59220	\N	\N
74059	SPECIFIC_DAY	3	7	2010-07-08	40199	59220	\N	\N
74060	SPECIFIC_DAY	3	0	2009-12-20	40199	59220	\N	\N
74061	SPECIFIC_DAY	3	7	2010-01-19	40199	59220	\N	\N
74062	SPECIFIC_DAY	3	7	2010-06-07	40199	59220	\N	\N
74063	SPECIFIC_DAY	3	7	2009-12-21	40199	59220	\N	\N
74064	SPECIFIC_DAY	3	0	2010-03-19	40199	59220	\N	\N
74065	SPECIFIC_DAY	3	0	2009-12-29	40199	59220	\N	\N
74066	SPECIFIC_DAY	3	7	2010-08-12	40199	59220	\N	\N
74067	SPECIFIC_DAY	3	0	2010-08-15	40199	59220	\N	\N
74068	SPECIFIC_DAY	3	7	2010-04-20	40199	59220	\N	\N
74069	SPECIFIC_DAY	3	0	2010-02-27	40199	59220	\N	\N
74070	SPECIFIC_DAY	3	7	2010-06-23	40199	59220	\N	\N
74071	SPECIFIC_DAY	3	7	2010-07-07	40199	59220	\N	\N
74072	SPECIFIC_DAY	3	0	2009-12-30	40199	59220	\N	\N
74073	SPECIFIC_DAY	3	0	2010-02-06	40199	59220	\N	\N
74074	SPECIFIC_DAY	3	0	2010-05-09	40199	59220	\N	\N
74075	SPECIFIC_DAY	3	0	2010-04-10	40199	59220	\N	\N
74076	SPECIFIC_DAY	3	0	2010-06-06	40199	59220	\N	\N
74077	SPECIFIC_DAY	3	0	2010-03-06	40199	59220	\N	\N
74078	SPECIFIC_DAY	3	7	2010-07-05	40199	59220	\N	\N
74079	SPECIFIC_DAY	3	0	2010-02-17	40199	59220	\N	\N
74080	SPECIFIC_DAY	3	7	2010-06-03	40199	59220	\N	\N
74081	SPECIFIC_DAY	3	7	2010-06-01	40199	59220	\N	\N
74082	SPECIFIC_DAY	3	7	2010-01-27	40199	59220	\N	\N
74083	SPECIFIC_DAY	3	7	2010-04-14	40199	59220	\N	\N
74084	SPECIFIC_DAY	3	7	2010-07-26	40199	59220	\N	\N
74085	SPECIFIC_DAY	3	0	2010-04-04	40199	59220	\N	\N
74086	SPECIFIC_DAY	3	0	2010-06-27	40199	59220	\N	\N
74087	SPECIFIC_DAY	3	7	2010-05-20	40199	59220	\N	\N
74088	SPECIFIC_DAY	3	7	2010-03-18	40199	59220	\N	\N
74089	SPECIFIC_DAY	3	7	2010-01-21	40199	59220	\N	\N
74090	SPECIFIC_DAY	3	7	2010-02-26	40199	59220	\N	\N
74091	SPECIFIC_DAY	3	7	2009-12-17	40199	59220	\N	\N
74092	SPECIFIC_DAY	3	7	2010-02-18	40199	59220	\N	\N
74093	SPECIFIC_DAY	3	7	2010-08-16	40199	59220	\N	\N
74094	SPECIFIC_DAY	3	7	2010-01-26	40199	59220	\N	\N
74095	SPECIFIC_DAY	3	0	2010-05-23	40199	59220	\N	\N
74096	SPECIFIC_DAY	3	7	2010-05-25	40199	59220	\N	\N
74097	SPECIFIC_DAY	3	7	2010-01-05	40199	59220	\N	\N
74098	SPECIFIC_DAY	3	7	2010-06-30	40199	59220	\N	\N
74099	SPECIFIC_DAY	3	0	2010-06-12	40199	59220	\N	\N
74100	SPECIFIC_DAY	3	7	2010-09-02	40199	59220	\N	\N
74101	SPECIFIC_DAY	3	7	2010-02-15	40199	59220	\N	\N
74102	SPECIFIC_DAY	3	0	2010-07-25	40199	59220	\N	\N
74103	SPECIFIC_DAY	3	7	2010-05-10	40199	59220	\N	\N
74104	SPECIFIC_DAY	3	7	2010-03-05	40199	59220	\N	\N
74105	SPECIFIC_DAY	3	7	2010-08-19	40199	59220	\N	\N
74106	SPECIFIC_DAY	3	0	2009-12-26	40199	59220	\N	\N
74107	SPECIFIC_DAY	3	7	2010-03-26	40199	59220	\N	\N
74108	SPECIFIC_DAY	3	7	2010-03-17	40199	59220	\N	\N
74109	SPECIFIC_DAY	3	0	2010-06-05	40199	59220	\N	\N
74110	SPECIFIC_DAY	3	7	2010-08-10	40199	59220	\N	\N
74111	SPECIFIC_DAY	3	7	2010-05-11	40199	59220	\N	\N
74112	SPECIFIC_DAY	3	0	2010-04-05	40199	59220	\N	\N
74113	SPECIFIC_DAY	3	0	2010-03-14	40199	59220	\N	\N
74114	SPECIFIC_DAY	3	0	2010-08-14	40199	59220	\N	\N
74115	SPECIFIC_DAY	3	7	2010-08-03	40199	59220	\N	\N
74116	SPECIFIC_DAY	3	7	2010-06-22	40199	59220	\N	\N
74117	SPECIFIC_DAY	3	0	2010-02-07	40199	59220	\N	\N
74118	SPECIFIC_DAY	3	7	2010-02-09	40199	59220	\N	\N
74119	SPECIFIC_DAY	3	7	2010-05-18	40199	59220	\N	\N
74120	SPECIFIC_DAY	3	7	2010-07-16	40199	59220	\N	\N
74121	SPECIFIC_DAY	3	7	2010-07-09	40199	59220	\N	\N
74122	SPECIFIC_DAY	3	7	2010-03-16	40199	59220	\N	\N
74123	SPECIFIC_DAY	3	7	2010-07-20	40199	59220	\N	\N
74124	SPECIFIC_DAY	3	7	2010-06-16	40199	59220	\N	\N
74125	SPECIFIC_DAY	3	7	2010-03-31	40199	59220	\N	\N
74126	SPECIFIC_DAY	3	0	2009-12-28	40199	59220	\N	\N
74127	SPECIFIC_DAY	3	7	2010-01-28	40199	59220	\N	\N
74128	SPECIFIC_DAY	3	7	2010-04-06	40199	59220	\N	\N
74129	SPECIFIC_DAY	3	7	2010-04-30	40199	59220	\N	\N
74130	SPECIFIC_DAY	3	7	2010-02-02	40199	59220	\N	\N
74131	SPECIFIC_DAY	3	7	2010-02-08	40199	59220	\N	\N
74132	SPECIFIC_DAY	3	7	2010-03-11	40199	59220	\N	\N
74133	SPECIFIC_DAY	3	7	2009-12-18	40199	59220	\N	\N
74134	SPECIFIC_DAY	3	7	2010-06-15	40199	59220	\N	\N
74135	SPECIFIC_DAY	3	7	2010-06-29	40199	59220	\N	\N
74136	SPECIFIC_DAY	3	7	2010-06-08	40199	59220	\N	\N
74137	SPECIFIC_DAY	3	7	2010-08-18	40199	59220	\N	\N
74138	SPECIFIC_DAY	3	7	2009-12-15	40199	59220	\N	\N
74139	SPECIFIC_DAY	3	7	2010-01-13	40199	59220	\N	\N
74140	SPECIFIC_DAY	3	0	2010-01-01	40199	59220	\N	\N
74141	SPECIFIC_DAY	3	0	2010-03-21	40199	59220	\N	\N
74142	SPECIFIC_DAY	3	7	2010-08-25	40199	59220	\N	\N
74143	SPECIFIC_DAY	3	7	2010-09-01	40199	59220	\N	\N
74144	SPECIFIC_DAY	3	7	2010-01-07	40199	59220	\N	\N
74145	SPECIFIC_DAY	3	7	2010-07-13	40199	59220	\N	\N
74146	SPECIFIC_DAY	3	7	2010-04-29	40199	59220	\N	\N
74147	SPECIFIC_DAY	3	0	2010-01-16	40199	59220	\N	\N
74148	SPECIFIC_DAY	3	7	2010-07-19	40199	59220	\N	\N
74149	SPECIFIC_DAY	3	0	2010-04-17	40199	59220	\N	\N
74150	SPECIFIC_DAY	3	7	2010-06-11	40199	59220	\N	\N
74151	SPECIFIC_DAY	3	0	2010-05-22	40199	59220	\N	\N
74152	SPECIFIC_DAY	3	0	2010-05-08	40199	59220	\N	\N
74153	SPECIFIC_DAY	3	0	2010-08-08	40199	59220	\N	\N
74154	SPECIFIC_DAY	3	7	2010-01-04	40199	59220	\N	\N
74155	SPECIFIC_DAY	3	0	2010-04-18	40199	59220	\N	\N
74156	SPECIFIC_DAY	3	0	2010-01-31	40199	59220	\N	\N
74157	SPECIFIC_DAY	3	7	2010-08-13	40199	59220	\N	\N
74158	SPECIFIC_DAY	3	7	2010-03-15	40199	59220	\N	\N
74159	SPECIFIC_DAY	3	0	2010-05-15	40199	59220	\N	\N
74160	SPECIFIC_DAY	3	7	2010-06-14	40199	59220	\N	\N
74161	SPECIFIC_DAY	3	7	2010-07-21	40199	59220	\N	\N
74162	SPECIFIC_DAY	3	0	2010-08-29	40199	59220	\N	\N
74163	SPECIFIC_DAY	3	0	2010-08-07	40199	59220	\N	\N
74164	SPECIFIC_DAY	3	7	2010-03-03	40199	59220	\N	\N
74165	SPECIFIC_DAY	3	7	2010-05-31	40199	59220	\N	\N
74166	SPECIFIC_DAY	3	7	2010-07-14	40199	59220	\N	\N
74167	SPECIFIC_DAY	3	7	2010-08-26	40199	59220	\N	\N
74168	SPECIFIC_DAY	3	0	2010-07-03	40199	59220	\N	\N
74169	SPECIFIC_DAY	3	7	2010-01-14	40199	59220	\N	\N
74170	SPECIFIC_DAY	3	0	2010-01-09	40199	59220	\N	\N
74171	SPECIFIC_DAY	3	0	2010-02-20	40199	59220	\N	\N
74172	SPECIFIC_DAY	3	7	2010-01-22	40199	59220	\N	\N
74173	SPECIFIC_DAY	3	7	2010-05-05	40199	59220	\N	\N
74174	SPECIFIC_DAY	3	7	2010-03-30	40199	59220	\N	\N
74175	SPECIFIC_DAY	3	7	2010-04-16	40199	59220	\N	\N
74176	SPECIFIC_DAY	3	7	2010-02-11	40199	59220	\N	\N
74177	SPECIFIC_DAY	3	7	2010-09-03	40199	59220	\N	\N
74178	SPECIFIC_DAY	3	7	2009-12-16	40199	59220	\N	\N
74179	SPECIFIC_DAY	3	7	2009-12-23	40199	59220	\N	\N
74180	SPECIFIC_DAY	3	7	2010-09-09	40199	59220	\N	\N
74181	SPECIFIC_DAY	3	7	2010-03-25	40199	59220	\N	\N
74182	SPECIFIC_DAY	3	0	2010-04-25	40199	59220	\N	\N
74183	SPECIFIC_DAY	3	7	2010-11-02	40199	59221	\N	\N
74184	SPECIFIC_DAY	3	0	2011-03-12	40199	59221	\N	\N
74185	SPECIFIC_DAY	3	7	2010-12-15	40199	59221	\N	\N
74186	SPECIFIC_DAY	3	7	2011-01-27	40199	59221	\N	\N
74187	SPECIFIC_DAY	3	0	2010-12-11	40199	59221	\N	\N
74188	SPECIFIC_DAY	3	7	2010-12-16	40199	59221	\N	\N
74189	SPECIFIC_DAY	3	7	2011-02-22	40199	59221	\N	\N
74190	SPECIFIC_DAY	3	0	2011-01-16	40199	59221	\N	\N
74191	SPECIFIC_DAY	3	7	2010-10-08	40199	59221	\N	\N
74192	SPECIFIC_DAY	3	7	2010-10-01	40199	59221	\N	\N
74193	SPECIFIC_DAY	3	7	2010-11-05	40199	59221	\N	\N
74194	SPECIFIC_DAY	3	7	2010-10-07	40199	59221	\N	\N
74195	SPECIFIC_DAY	3	7	2011-03-02	40199	59221	\N	\N
74196	SPECIFIC_DAY	3	7	2010-11-23	40199	59221	\N	\N
74197	SPECIFIC_DAY	3	7	2011-04-04	40199	59221	\N	\N
74198	SPECIFIC_DAY	3	7	2011-03-29	40199	59221	\N	\N
74199	SPECIFIC_DAY	3	7	2010-10-05	40199	59221	\N	\N
74200	SPECIFIC_DAY	3	7	2010-12-30	40199	59221	\N	\N
74201	SPECIFIC_DAY	3	7	2011-02-01	40199	59221	\N	\N
74202	SPECIFIC_DAY	3	7	2010-10-19	40199	59221	\N	\N
74203	SPECIFIC_DAY	3	7	2011-04-19	40199	59221	\N	\N
74204	SPECIFIC_DAY	3	0	2011-03-13	40199	59221	\N	\N
74205	SPECIFIC_DAY	3	0	2010-10-02	40199	59221	\N	\N
74206	SPECIFIC_DAY	3	0	2010-11-07	40199	59221	\N	\N
74207	SPECIFIC_DAY	3	7	2011-03-07	40199	59221	\N	\N
74208	SPECIFIC_DAY	3	0	2011-02-05	40199	59221	\N	\N
74209	SPECIFIC_DAY	3	7	2010-11-30	40199	59221	\N	\N
74210	SPECIFIC_DAY	3	0	2011-01-30	40199	59221	\N	\N
74211	SPECIFIC_DAY	3	7	2011-02-15	40199	59221	\N	\N
74212	SPECIFIC_DAY	3	7	2011-01-21	40199	59221	\N	\N
74213	SPECIFIC_DAY	3	7	2010-09-10	40199	59221	\N	\N
74214	SPECIFIC_DAY	3	7	2010-12-29	40199	59221	\N	\N
74215	SPECIFIC_DAY	3	0	2011-02-27	40199	59221	\N	\N
74216	SPECIFIC_DAY	3	7	2011-03-25	40199	59221	\N	\N
74217	SPECIFIC_DAY	3	7	2010-09-21	40199	59221	\N	\N
74218	SPECIFIC_DAY	3	0	2011-04-30	40199	59221	\N	\N
74219	SPECIFIC_DAY	3	7	2011-03-04	40199	59221	\N	\N
74220	SPECIFIC_DAY	3	7	2010-10-26	40199	59221	\N	\N
74221	SPECIFIC_DAY	3	7	2011-03-18	40199	59221	\N	\N
74222	SPECIFIC_DAY	3	7	2011-05-06	40199	59221	\N	\N
74223	SPECIFIC_DAY	3	7	2011-04-27	40199	59221	\N	\N
74224	SPECIFIC_DAY	3	0	2010-11-27	40199	59221	\N	\N
74225	SPECIFIC_DAY	3	0	2010-09-26	40199	59221	\N	\N
74226	SPECIFIC_DAY	3	0	2010-11-14	40199	59221	\N	\N
74227	SPECIFIC_DAY	3	7	2011-04-13	40199	59221	\N	\N
74228	SPECIFIC_DAY	3	7	2011-01-06	40199	59221	\N	\N
74229	SPECIFIC_DAY	3	7	2010-09-23	40199	59221	\N	\N
74230	SPECIFIC_DAY	3	7	2010-10-15	40199	59221	\N	\N
74231	SPECIFIC_DAY	3	7	2010-12-28	40199	59221	\N	\N
74232	SPECIFIC_DAY	3	0	2010-09-18	40199	59221	\N	\N
74233	SPECIFIC_DAY	3	7	2010-09-24	40199	59221	\N	\N
74234	SPECIFIC_DAY	3	7	2010-10-20	40199	59221	\N	\N
74235	SPECIFIC_DAY	3	7	2011-03-31	40199	59221	\N	\N
74236	SPECIFIC_DAY	3	7	2011-03-28	40199	59221	\N	\N
74237	SPECIFIC_DAY	3	7	2011-01-05	40199	59221	\N	\N
74238	SPECIFIC_DAY	3	0	2011-01-08	40199	59221	\N	\N
74239	SPECIFIC_DAY	3	7	2011-01-04	40199	59221	\N	\N
74240	SPECIFIC_DAY	3	7	2010-10-06	40199	59221	\N	\N
74241	SPECIFIC_DAY	3	7	2011-02-24	40199	59221	\N	\N
74242	SPECIFIC_DAY	3	7	2011-03-22	40199	59221	\N	\N
74243	SPECIFIC_DAY	3	0	2010-12-19	40199	59221	\N	\N
74244	SPECIFIC_DAY	3	0	2011-05-22	40199	59221	\N	\N
74245	SPECIFIC_DAY	3	7	2011-04-05	40199	59221	\N	\N
74246	SPECIFIC_DAY	3	7	2010-12-13	40199	59221	\N	\N
74247	SPECIFIC_DAY	3	7	2011-01-19	40199	59221	\N	\N
74248	SPECIFIC_DAY	3	7	2011-02-02	40199	59221	\N	\N
74249	SPECIFIC_DAY	3	7	2011-02-18	40199	59221	\N	\N
74250	SPECIFIC_DAY	3	0	2010-09-12	40199	59221	\N	\N
74251	SPECIFIC_DAY	3	7	2010-11-29	40199	59221	\N	\N
74252	SPECIFIC_DAY	3	7	2010-12-14	40199	59221	\N	\N
74253	SPECIFIC_DAY	3	7	2010-11-15	40199	59221	\N	\N
74254	SPECIFIC_DAY	3	7	2011-03-21	40199	59221	\N	\N
74255	SPECIFIC_DAY	3	0	2011-03-27	40199	59221	\N	\N
74256	SPECIFIC_DAY	3	7	2011-01-18	40199	59221	\N	\N
74257	SPECIFIC_DAY	3	0	2011-02-13	40199	59221	\N	\N
74258	SPECIFIC_DAY	3	0	2010-10-12	40199	59221	\N	\N
74259	SPECIFIC_DAY	3	7	2010-10-28	40199	59221	\N	\N
74260	SPECIFIC_DAY	3	0	2011-04-24	40199	59221	\N	\N
74261	SPECIFIC_DAY	3	7	2010-10-18	40199	59221	\N	\N
74262	SPECIFIC_DAY	3	0	2011-01-01	40199	59221	\N	\N
74263	SPECIFIC_DAY	3	7	2010-11-03	40199	59221	\N	\N
74264	SPECIFIC_DAY	3	0	2011-03-05	40199	59221	\N	\N
74265	SPECIFIC_DAY	3	7	2011-03-15	40199	59221	\N	\N
74266	SPECIFIC_DAY	3	7	2011-04-28	40199	59221	\N	\N
74267	SPECIFIC_DAY	3	7	2010-12-22	40199	59221	\N	\N
74268	SPECIFIC_DAY	3	7	2011-02-23	40199	59221	\N	\N
74269	SPECIFIC_DAY	3	7	2011-04-12	40199	59221	\N	\N
74270	SPECIFIC_DAY	3	7	2010-09-30	40199	59221	\N	\N
74271	SPECIFIC_DAY	3	7	2010-09-17	40199	59221	\N	\N
74272	SPECIFIC_DAY	3	7	2010-11-25	40199	59221	\N	\N
74273	SPECIFIC_DAY	3	7	2011-04-26	40199	59221	\N	\N
74274	SPECIFIC_DAY	3	7	2010-12-31	40199	59221	\N	\N
74275	SPECIFIC_DAY	3	7	2010-11-10	40199	59221	\N	\N
74276	SPECIFIC_DAY	3	7	2010-12-02	40199	59221	\N	\N
74277	SPECIFIC_DAY	3	7	2011-04-21	40199	59221	\N	\N
74278	SPECIFIC_DAY	3	0	2010-10-03	40199	59221	\N	\N
74279	SPECIFIC_DAY	3	7	2011-05-24	40199	59221	\N	\N
74280	SPECIFIC_DAY	3	0	2011-05-08	40199	59221	\N	\N
74281	SPECIFIC_DAY	3	0	2010-10-09	40199	59221	\N	\N
74282	SPECIFIC_DAY	3	7	2011-03-09	40199	59221	\N	\N
74283	SPECIFIC_DAY	3	0	2011-02-12	40199	59221	\N	\N
74284	SPECIFIC_DAY	3	7	2011-05-02	40199	59221	\N	\N
74285	SPECIFIC_DAY	3	0	2011-02-26	40199	59221	\N	\N
74286	SPECIFIC_DAY	3	0	2010-10-10	40199	59221	\N	\N
74287	SPECIFIC_DAY	3	7	2010-11-22	40199	59221	\N	\N
74288	SPECIFIC_DAY	3	7	2011-03-11	40199	59221	\N	\N
74289	SPECIFIC_DAY	3	0	2011-03-19	40199	59221	\N	\N
74290	SPECIFIC_DAY	3	7	2010-09-13	40199	59221	\N	\N
74291	SPECIFIC_DAY	3	7	2010-12-07	40199	59221	\N	\N
74292	SPECIFIC_DAY	3	0	2010-11-01	40199	59221	\N	\N
74293	SPECIFIC_DAY	3	7	2011-02-25	40199	59221	\N	\N
74294	SPECIFIC_DAY	3	7	2011-04-07	40199	59221	\N	\N
74295	SPECIFIC_DAY	3	7	2010-12-01	40199	59221	\N	\N
74296	SPECIFIC_DAY	3	7	2011-02-08	40199	59221	\N	\N
74297	SPECIFIC_DAY	3	7	2011-01-13	40199	59221	\N	\N
74298	SPECIFIC_DAY	3	0	2010-11-20	40199	59221	\N	\N
74299	SPECIFIC_DAY	3	0	2010-09-25	40199	59221	\N	\N
74300	SPECIFIC_DAY	3	7	2010-09-29	40199	59221	\N	\N
74301	SPECIFIC_DAY	3	0	2011-04-17	40199	59221	\N	\N
74302	SPECIFIC_DAY	3	7	2011-03-10	40199	59221	\N	\N
74303	SPECIFIC_DAY	3	7	2010-10-25	40199	59221	\N	\N
74304	SPECIFIC_DAY	3	7	2010-10-29	40199	59221	\N	\N
74305	SPECIFIC_DAY	3	7	2011-01-03	40199	59221	\N	\N
74306	SPECIFIC_DAY	3	7	2011-03-16	40199	59221	\N	\N
74307	SPECIFIC_DAY	3	7	2011-01-14	40199	59221	\N	\N
74308	SPECIFIC_DAY	3	7	2010-09-16	40199	59221	\N	\N
74309	SPECIFIC_DAY	3	7	2011-01-20	40199	59221	\N	\N
74310	SPECIFIC_DAY	3	7	2011-05-19	40199	59221	\N	\N
74311	SPECIFIC_DAY	3	0	2011-02-20	40199	59221	\N	\N
74312	SPECIFIC_DAY	3	7	2010-11-11	40199	59221	\N	\N
74313	SPECIFIC_DAY	3	7	2011-01-12	40199	59221	\N	\N
74314	SPECIFIC_DAY	3	7	2011-02-09	40199	59221	\N	\N
74315	SPECIFIC_DAY	3	7	2011-04-14	40199	59221	\N	\N
74316	SPECIFIC_DAY	3	0	2010-09-11	40199	59221	\N	\N
74317	SPECIFIC_DAY	3	7	2011-01-11	40199	59221	\N	\N
74318	SPECIFIC_DAY	3	0	2010-12-05	40199	59221	\N	\N
74319	SPECIFIC_DAY	3	7	2011-05-04	40199	59221	\N	\N
74320	SPECIFIC_DAY	3	0	2010-12-25	40199	59221	\N	\N
74321	SPECIFIC_DAY	3	7	2010-10-21	40199	59221	\N	\N
74322	SPECIFIC_DAY	3	7	2010-11-12	40199	59221	\N	\N
74323	SPECIFIC_DAY	3	7	2011-02-04	40199	59221	\N	\N
74324	SPECIFIC_DAY	3	7	2010-12-27	40199	59221	\N	\N
74325	SPECIFIC_DAY	3	7	2011-03-01	40199	59221	\N	\N
74326	SPECIFIC_DAY	3	7	2010-11-19	40199	59221	\N	\N
74327	SPECIFIC_DAY	3	7	2010-12-23	40199	59221	\N	\N
74328	SPECIFIC_DAY	3	7	2011-03-08	40199	59221	\N	\N
74329	SPECIFIC_DAY	3	7	2010-12-03	40199	59221	\N	\N
74330	SPECIFIC_DAY	3	0	2011-03-20	40199	59221	\N	\N
74331	SPECIFIC_DAY	3	7	2011-02-03	40199	59221	\N	\N
74332	SPECIFIC_DAY	3	7	2011-01-24	40199	59221	\N	\N
74333	SPECIFIC_DAY	3	7	2010-10-14	40199	59221	\N	\N
74334	SPECIFIC_DAY	3	7	2011-04-18	40199	59221	\N	\N
74335	SPECIFIC_DAY	3	0	2011-01-09	40199	59221	\N	\N
74336	SPECIFIC_DAY	3	7	2011-02-11	40199	59221	\N	\N
74337	SPECIFIC_DAY	3	7	2010-11-04	40199	59221	\N	\N
74338	SPECIFIC_DAY	3	7	2011-05-23	40199	59221	\N	\N
74339	SPECIFIC_DAY	3	0	2011-04-16	40199	59221	\N	\N
74340	SPECIFIC_DAY	3	7	2011-05-05	40199	59221	\N	\N
74341	SPECIFIC_DAY	3	7	2010-12-24	40199	59221	\N	\N
74342	SPECIFIC_DAY	3	7	2011-02-17	40199	59221	\N	\N
74343	SPECIFIC_DAY	3	7	2011-02-14	40199	59221	\N	\N
74344	SPECIFIC_DAY	3	7	2011-02-07	40199	59221	\N	\N
74345	SPECIFIC_DAY	3	7	2011-01-31	40199	59221	\N	\N
74346	SPECIFIC_DAY	3	7	2011-01-07	40199	59221	\N	\N
74347	SPECIFIC_DAY	3	7	2010-10-04	40199	59221	\N	\N
74348	SPECIFIC_DAY	3	0	2011-02-06	40199	59221	\N	\N
74349	SPECIFIC_DAY	3	7	2011-04-15	40199	59221	\N	\N
74350	SPECIFIC_DAY	3	7	2010-09-28	40199	59221	\N	\N
74351	SPECIFIC_DAY	3	0	2011-05-15	40199	59221	\N	\N
74352	SPECIFIC_DAY	3	7	2011-04-25	40199	59221	\N	\N
74353	SPECIFIC_DAY	3	7	2011-02-16	40199	59221	\N	\N
74354	SPECIFIC_DAY	3	0	2011-05-01	40199	59221	\N	\N
74355	SPECIFIC_DAY	3	0	2011-05-14	40199	59221	\N	\N
74356	SPECIFIC_DAY	3	7	2011-01-10	40199	59221	\N	\N
74357	SPECIFIC_DAY	3	0	2010-10-16	40199	59221	\N	\N
74358	SPECIFIC_DAY	3	7	2010-09-22	40199	59221	\N	\N
74359	SPECIFIC_DAY	3	7	2011-05-20	40199	59221	\N	\N
74360	SPECIFIC_DAY	3	0	2010-12-04	40199	59221	\N	\N
74361	SPECIFIC_DAY	3	7	2011-04-11	40199	59221	\N	\N
74362	SPECIFIC_DAY	3	0	2010-09-19	40199	59221	\N	\N
74363	SPECIFIC_DAY	3	0	2011-05-21	40199	59221	\N	\N
74364	SPECIFIC_DAY	3	7	2011-03-03	40199	59221	\N	\N
74365	SPECIFIC_DAY	3	0	2011-02-19	40199	59221	\N	\N
74366	SPECIFIC_DAY	3	7	2011-01-28	40199	59221	\N	\N
74367	SPECIFIC_DAY	3	7	2010-10-22	40199	59221	\N	\N
74368	SPECIFIC_DAY	3	0	2011-01-02	40199	59221	\N	\N
74369	SPECIFIC_DAY	3	7	2011-04-01	40199	59221	\N	\N
74370	SPECIFIC_DAY	3	7	2011-03-23	40199	59221	\N	\N
74371	SPECIFIC_DAY	3	7	2010-11-24	40199	59221	\N	\N
74372	SPECIFIC_DAY	3	7	2010-12-09	40199	59221	\N	\N
74373	SPECIFIC_DAY	3	0	2010-12-18	40199	59221	\N	\N
74374	SPECIFIC_DAY	3	7	2011-05-13	40199	59221	\N	\N
74375	SPECIFIC_DAY	3	7	2011-03-17	40199	59221	\N	\N
74376	SPECIFIC_DAY	3	7	2010-12-10	40199	59221	\N	\N
74377	SPECIFIC_DAY	3	0	2010-11-28	40199	59221	\N	\N
74378	SPECIFIC_DAY	3	0	2011-04-23	40199	59221	\N	\N
74379	SPECIFIC_DAY	3	0	2010-10-23	40199	59221	\N	\N
74380	SPECIFIC_DAY	3	0	2011-05-07	40199	59221	\N	\N
74381	SPECIFIC_DAY	3	7	2011-04-20	40199	59221	\N	\N
74382	SPECIFIC_DAY	3	0	2011-01-23	40199	59221	\N	\N
74383	SPECIFIC_DAY	3	7	2011-02-10	40199	59221	\N	\N
74384	SPECIFIC_DAY	3	7	2011-04-08	40199	59221	\N	\N
74385	SPECIFIC_DAY	3	7	2011-05-09	40199	59221	\N	\N
74386	SPECIFIC_DAY	3	0	2010-11-21	40199	59221	\N	\N
74387	SPECIFIC_DAY	3	7	2010-11-16	40199	59221	\N	\N
74388	SPECIFIC_DAY	3	0	2010-12-12	40199	59221	\N	\N
74389	SPECIFIC_DAY	3	7	2011-04-22	40199	59221	\N	\N
74390	SPECIFIC_DAY	3	7	2011-05-10	40199	59221	\N	\N
74391	SPECIFIC_DAY	3	7	2010-11-26	40199	59221	\N	\N
74392	SPECIFIC_DAY	3	0	2010-10-17	40199	59221	\N	\N
74393	SPECIFIC_DAY	3	0	2011-04-02	40199	59221	\N	\N
74394	SPECIFIC_DAY	3	7	2011-02-28	40199	59221	\N	\N
74395	SPECIFIC_DAY	3	0	2011-04-03	40199	59221	\N	\N
74396	SPECIFIC_DAY	3	7	2011-01-25	40199	59221	\N	\N
74397	SPECIFIC_DAY	3	0	2011-01-15	40199	59221	\N	\N
74398	SPECIFIC_DAY	3	7	2011-01-26	40199	59221	\N	\N
74399	SPECIFIC_DAY	3	0	2011-04-10	40199	59221	\N	\N
74400	SPECIFIC_DAY	3	0	2010-10-31	40199	59221	\N	\N
74401	SPECIFIC_DAY	3	7	2011-04-06	40199	59221	\N	\N
74402	SPECIFIC_DAY	3	0	2010-11-13	40199	59221	\N	\N
74403	SPECIFIC_DAY	3	0	2011-03-26	40199	59221	\N	\N
74404	SPECIFIC_DAY	3	7	2010-11-18	40199	59221	\N	\N
74405	SPECIFIC_DAY	3	0	2010-11-06	40199	59221	\N	\N
74406	SPECIFIC_DAY	3	7	2011-03-30	40199	59221	\N	\N
74407	SPECIFIC_DAY	3	7	2010-09-27	40199	59221	\N	\N
74408	SPECIFIC_DAY	3	0	2011-03-06	40199	59221	\N	\N
74409	SPECIFIC_DAY	3	7	2010-10-27	40199	59221	\N	\N
74410	SPECIFIC_DAY	3	7	2010-12-17	40199	59221	\N	\N
74411	SPECIFIC_DAY	3	7	2011-05-18	40199	59221	\N	\N
74412	SPECIFIC_DAY	3	0	2010-12-06	40199	59221	\N	\N
74413	SPECIFIC_DAY	3	7	2010-11-08	40199	59221	\N	\N
74414	SPECIFIC_DAY	3	0	2010-10-30	40199	59221	\N	\N
74415	SPECIFIC_DAY	3	0	2010-12-26	40199	59221	\N	\N
74416	SPECIFIC_DAY	3	7	2011-01-17	40199	59221	\N	\N
74417	SPECIFIC_DAY	3	7	2011-05-12	40199	59221	\N	\N
74418	SPECIFIC_DAY	3	7	2011-03-14	40199	59221	\N	\N
74419	SPECIFIC_DAY	3	0	2011-04-09	40199	59221	\N	\N
74420	SPECIFIC_DAY	3	7	2011-05-25	40199	59221	\N	\N
74421	SPECIFIC_DAY	3	0	2011-01-22	40199	59221	\N	\N
74422	SPECIFIC_DAY	3	7	2010-11-17	40199	59221	\N	\N
74423	SPECIFIC_DAY	3	7	2011-05-16	40199	59221	\N	\N
74424	SPECIFIC_DAY	3	7	2010-09-20	40199	59221	\N	\N
74425	SPECIFIC_DAY	3	7	2010-10-13	40199	59221	\N	\N
74426	SPECIFIC_DAY	3	7	2010-12-21	40199	59221	\N	\N
74427	SPECIFIC_DAY	3	7	2011-02-21	40199	59221	\N	\N
74428	SPECIFIC_DAY	3	7	2011-05-03	40199	59221	\N	\N
74429	SPECIFIC_DAY	3	7	2010-09-14	40199	59221	\N	\N
74430	SPECIFIC_DAY	3	0	2010-12-08	40199	59221	\N	\N
74431	SPECIFIC_DAY	3	0	2011-01-29	40199	59221	\N	\N
74432	SPECIFIC_DAY	3	7	2010-10-11	40199	59221	\N	\N
74433	SPECIFIC_DAY	3	7	2011-05-17	40199	59221	\N	\N
74434	SPECIFIC_DAY	3	7	2010-12-20	40199	59221	\N	\N
74435	SPECIFIC_DAY	3	7	2011-05-11	40199	59221	\N	\N
74436	SPECIFIC_DAY	3	7	2011-04-29	40199	59221	\N	\N
74437	SPECIFIC_DAY	3	7	2010-09-15	40199	59221	\N	\N
74438	SPECIFIC_DAY	3	0	2010-10-24	40199	59221	\N	\N
74439	SPECIFIC_DAY	3	7	2010-11-09	40199	59221	\N	\N
74440	SPECIFIC_DAY	3	7	2011-03-24	40199	59221	\N	\N
74441	SPECIFIC_DAY	3	7	2012-12-11	40199	59222	\N	\N
74442	SPECIFIC_DAY	3	7	2011-10-04	40199	59222	\N	\N
74443	SPECIFIC_DAY	3	0	2012-10-27	40199	59222	\N	\N
74444	SPECIFIC_DAY	3	7	2012-11-15	40199	59222	\N	\N
74445	SPECIFIC_DAY	3	7	2011-08-29	40199	59222	\N	\N
74446	SPECIFIC_DAY	3	0	2011-10-30	40199	59222	\N	\N
74447	SPECIFIC_DAY	3	7	2011-11-15	40199	59222	\N	\N
74448	SPECIFIC_DAY	3	7	2012-03-26	40199	59222	\N	\N
74449	SPECIFIC_DAY	3	7	2011-11-25	40199	59222	\N	\N
74450	SPECIFIC_DAY	3	0	2012-09-23	40199	59222	\N	\N
74451	SPECIFIC_DAY	3	7	2012-07-23	40199	59222	\N	\N
74452	SPECIFIC_DAY	3	7	2011-08-23	40199	59222	\N	\N
74453	SPECIFIC_DAY	3	7	2012-08-31	40199	59222	\N	\N
74454	SPECIFIC_DAY	3	0	2011-09-17	40199	59222	\N	\N
74455	SPECIFIC_DAY	3	7	2012-07-18	40199	59222	\N	\N
74456	SPECIFIC_DAY	3	0	2011-12-04	40199	59222	\N	\N
74457	SPECIFIC_DAY	3	7	2012-03-07	40199	59222	\N	\N
74458	SPECIFIC_DAY	3	7	2011-06-10	40199	59222	\N	\N
74459	SPECIFIC_DAY	3	7	2012-06-07	40199	59222	\N	\N
74460	SPECIFIC_DAY	3	7	2011-07-25	40199	59222	\N	\N
74461	SPECIFIC_DAY	3	7	2012-12-18	40199	59222	\N	\N
74462	SPECIFIC_DAY	3	7	2013-01-31	40199	59222	\N	\N
74463	SPECIFIC_DAY	3	0	2012-02-12	40199	59222	\N	\N
74464	SPECIFIC_DAY	3	7	2012-06-18	40199	59222	\N	\N
74465	SPECIFIC_DAY	3	7	2011-07-18	40199	59222	\N	\N
74466	SPECIFIC_DAY	3	7	2013-02-11	40199	59222	\N	\N
74467	SPECIFIC_DAY	3	7	2011-07-05	40199	59222	\N	\N
74468	SPECIFIC_DAY	3	0	2011-07-16	40199	59222	\N	\N
74469	SPECIFIC_DAY	3	0	2012-07-01	40199	59222	\N	\N
74470	SPECIFIC_DAY	3	7	2013-01-21	40199	59222	\N	\N
74471	SPECIFIC_DAY	3	0	2013-01-20	40199	59222	\N	\N
74472	SPECIFIC_DAY	3	7	2012-07-11	40199	59222	\N	\N
74473	SPECIFIC_DAY	3	7	2011-09-07	40199	59222	\N	\N
74474	SPECIFIC_DAY	3	0	2012-03-25	40199	59222	\N	\N
74475	SPECIFIC_DAY	3	7	2011-06-08	40199	59222	\N	\N
74476	SPECIFIC_DAY	3	7	2012-04-23	40199	59222	\N	\N
74477	SPECIFIC_DAY	3	7	2011-08-26	40199	59222	\N	\N
74478	SPECIFIC_DAY	3	7	2012-03-29	40199	59222	\N	\N
74479	SPECIFIC_DAY	3	7	2011-12-15	40199	59222	\N	\N
74480	SPECIFIC_DAY	3	7	2013-02-05	40199	59222	\N	\N
74481	SPECIFIC_DAY	3	7	2012-09-25	40199	59222	\N	\N
74482	SPECIFIC_DAY	3	0	2011-08-20	40199	59222	\N	\N
74483	SPECIFIC_DAY	3	7	2012-07-12	40199	59222	\N	\N
74484	SPECIFIC_DAY	3	7	2012-06-13	40199	59222	\N	\N
74485	SPECIFIC_DAY	3	7	2012-07-25	40199	59222	\N	\N
74486	SPECIFIC_DAY	3	7	2011-09-16	40199	59222	\N	\N
74487	SPECIFIC_DAY	3	7	2011-11-30	40199	59222	\N	\N
74488	SPECIFIC_DAY	3	7	2011-10-18	40199	59222	\N	\N
74489	SPECIFIC_DAY	3	7	2012-05-15	40199	59222	\N	\N
74490	SPECIFIC_DAY	3	7	2012-05-14	40199	59222	\N	\N
74491	SPECIFIC_DAY	3	7	2013-01-18	40199	59222	\N	\N
74492	SPECIFIC_DAY	3	7	2012-12-26	40199	59222	\N	\N
74493	SPECIFIC_DAY	3	0	2011-11-06	40199	59222	\N	\N
74494	SPECIFIC_DAY	3	0	2011-08-21	40199	59222	\N	\N
74495	SPECIFIC_DAY	3	0	2012-11-03	40199	59222	\N	\N
74496	SPECIFIC_DAY	3	7	2012-03-30	40199	59222	\N	\N
74497	SPECIFIC_DAY	3	0	2011-06-18	40199	59222	\N	\N
74498	SPECIFIC_DAY	3	0	2012-04-14	40199	59222	\N	\N
74499	SPECIFIC_DAY	3	0	2012-02-05	40199	59222	\N	\N
74500	SPECIFIC_DAY	3	0	2011-07-24	40199	59222	\N	\N
74501	SPECIFIC_DAY	3	7	2012-07-02	40199	59222	\N	\N
74502	SPECIFIC_DAY	3	7	2012-09-03	40199	59222	\N	\N
74503	SPECIFIC_DAY	3	7	2012-08-28	40199	59222	\N	\N
74504	SPECIFIC_DAY	3	0	2012-07-14	40199	59222	\N	\N
74505	SPECIFIC_DAY	3	7	2011-07-06	40199	59222	\N	\N
74506	SPECIFIC_DAY	3	7	2011-06-20	40199	59222	\N	\N
74507	SPECIFIC_DAY	3	7	2011-06-30	40199	59222	\N	\N
74508	SPECIFIC_DAY	3	7	2011-06-23	40199	59222	\N	\N
74509	SPECIFIC_DAY	3	0	2012-12-29	40199	59222	\N	\N
74510	SPECIFIC_DAY	3	0	2012-06-24	40199	59222	\N	\N
74511	SPECIFIC_DAY	3	7	2012-03-20	40199	59222	\N	\N
74512	SPECIFIC_DAY	3	7	2011-09-15	40199	59222	\N	\N
74513	SPECIFIC_DAY	3	7	2011-11-18	40199	59222	\N	\N
74514	SPECIFIC_DAY	3	0	2011-10-08	40199	59222	\N	\N
74515	SPECIFIC_DAY	3	7	2012-05-09	40199	59222	\N	\N
74516	SPECIFIC_DAY	3	7	2011-12-01	40199	59222	\N	\N
74517	SPECIFIC_DAY	3	0	2011-05-29	40199	59222	\N	\N
74518	SPECIFIC_DAY	3	7	2011-07-11	40199	59222	\N	\N
74519	SPECIFIC_DAY	3	7	2012-10-16	40199	59222	\N	\N
74520	SPECIFIC_DAY	3	0	2011-06-26	40199	59222	\N	\N
74521	SPECIFIC_DAY	3	7	2012-12-05	40199	59222	\N	\N
74522	SPECIFIC_DAY	3	7	2012-05-29	40199	59222	\N	\N
74523	SPECIFIC_DAY	3	7	2011-09-27	40199	59222	\N	\N
74524	SPECIFIC_DAY	3	7	2011-09-02	40199	59222	\N	\N
74525	SPECIFIC_DAY	3	7	2012-11-30	40199	59222	\N	\N
74526	SPECIFIC_DAY	3	7	2012-06-11	40199	59222	\N	\N
74527	SPECIFIC_DAY	3	0	2012-07-07	40199	59222	\N	\N
74528	SPECIFIC_DAY	3	7	2012-02-14	40199	59222	\N	\N
74529	SPECIFIC_DAY	3	7	2011-06-24	40199	59222	\N	\N
74530	SPECIFIC_DAY	3	7	2011-10-13	40199	59222	\N	\N
74531	SPECIFIC_DAY	3	7	2012-07-19	40199	59222	\N	\N
74532	SPECIFIC_DAY	3	7	2011-08-25	40199	59222	\N	\N
74533	SPECIFIC_DAY	3	0	2011-11-19	40199	59222	\N	\N
74534	SPECIFIC_DAY	3	7	2012-04-13	40199	59222	\N	\N
74535	SPECIFIC_DAY	3	7	2012-09-11	40199	59222	\N	\N
74536	SPECIFIC_DAY	3	0	2013-01-27	40199	59222	\N	\N
74537	SPECIFIC_DAY	3	7	2012-01-10	40199	59222	\N	\N
74538	SPECIFIC_DAY	3	7	2012-02-28	40199	59222	\N	\N
74539	SPECIFIC_DAY	3	0	2012-03-03	40199	59222	\N	\N
74540	SPECIFIC_DAY	3	7	2012-02-08	40199	59222	\N	\N
74541	SPECIFIC_DAY	3	0	2012-05-12	40199	59222	\N	\N
74542	SPECIFIC_DAY	3	0	2012-10-07	40199	59222	\N	\N
74543	SPECIFIC_DAY	3	0	2012-06-02	40199	59222	\N	\N
74544	SPECIFIC_DAY	3	0	2012-11-17	40199	59222	\N	\N
74545	SPECIFIC_DAY	3	7	2012-08-24	40199	59222	\N	\N
74546	SPECIFIC_DAY	3	7	2013-01-03	40199	59222	\N	\N
74547	SPECIFIC_DAY	3	7	2012-06-08	40199	59222	\N	\N
74548	SPECIFIC_DAY	3	7	2012-01-12	40199	59222	\N	\N
74549	SPECIFIC_DAY	3	7	2011-07-27	40199	59222	\N	\N
74550	SPECIFIC_DAY	3	7	2012-03-21	40199	59222	\N	\N
74551	SPECIFIC_DAY	3	0	2011-08-13	40199	59222	\N	\N
74552	SPECIFIC_DAY	3	7	2011-06-13	40199	59222	\N	\N
74553	SPECIFIC_DAY	3	0	2012-08-26	40199	59222	\N	\N
74554	SPECIFIC_DAY	3	7	2012-11-21	40199	59222	\N	\N
74555	SPECIFIC_DAY	3	7	2012-01-26	40199	59222	\N	\N
74556	SPECIFIC_DAY	3	7	2012-04-27	40199	59222	\N	\N
74557	SPECIFIC_DAY	3	7	2012-11-13	40199	59222	\N	\N
74558	SPECIFIC_DAY	3	7	2012-03-13	40199	59222	\N	\N
74559	SPECIFIC_DAY	3	7	2012-12-07	40199	59222	\N	\N
74560	SPECIFIC_DAY	3	0	2012-08-11	40199	59222	\N	\N
74561	SPECIFIC_DAY	3	0	2012-01-28	40199	59222	\N	\N
74562	SPECIFIC_DAY	3	7	2012-03-01	40199	59222	\N	\N
74563	SPECIFIC_DAY	3	7	2012-04-04	40199	59222	\N	\N
74564	SPECIFIC_DAY	3	7	2012-12-20	40199	59222	\N	\N
74565	SPECIFIC_DAY	3	7	2011-09-20	40199	59222	\N	\N
74566	SPECIFIC_DAY	3	7	2011-08-02	40199	59222	\N	\N
74567	SPECIFIC_DAY	3	7	2011-07-13	40199	59222	\N	\N
74568	SPECIFIC_DAY	3	7	2012-07-10	40199	59222	\N	\N
74569	SPECIFIC_DAY	3	7	2012-07-03	40199	59222	\N	\N
74570	SPECIFIC_DAY	3	0	2011-06-25	40199	59222	\N	\N
74571	SPECIFIC_DAY	3	0	2011-12-03	40199	59222	\N	\N
74572	SPECIFIC_DAY	3	7	2012-10-08	40199	59222	\N	\N
74573	SPECIFIC_DAY	3	0	2012-05-26	40199	59222	\N	\N
74574	SPECIFIC_DAY	3	7	2012-02-07	40199	59222	\N	\N
74575	SPECIFIC_DAY	3	0	2011-12-24	40199	59222	\N	\N
74576	SPECIFIC_DAY	3	0	2011-12-31	40199	59222	\N	\N
74577	SPECIFIC_DAY	3	7	2012-10-18	40199	59222	\N	\N
74578	SPECIFIC_DAY	3	7	2011-12-05	40199	59222	\N	\N
74579	SPECIFIC_DAY	3	0	2012-03-31	40199	59222	\N	\N
74580	SPECIFIC_DAY	3	7	2013-01-07	40199	59222	\N	\N
74581	SPECIFIC_DAY	3	7	2012-11-20	40199	59222	\N	\N
74582	SPECIFIC_DAY	3	7	2012-01-11	40199	59222	\N	\N
74583	SPECIFIC_DAY	3	7	2011-05-27	40199	59222	\N	\N
74584	SPECIFIC_DAY	3	7	2013-01-25	40199	59222	\N	\N
74585	SPECIFIC_DAY	3	7	2011-06-28	40199	59222	\N	\N
74586	SPECIFIC_DAY	3	0	2012-04-01	40199	59222	\N	\N
74587	SPECIFIC_DAY	3	0	2012-06-16	40199	59222	\N	\N
74588	SPECIFIC_DAY	3	7	2012-08-17	40199	59222	\N	\N
74589	SPECIFIC_DAY	3	7	2012-03-05	40199	59222	\N	\N
74590	SPECIFIC_DAY	3	7	2012-06-21	40199	59222	\N	\N
74591	SPECIFIC_DAY	3	7	2012-04-17	40199	59222	\N	\N
74592	SPECIFIC_DAY	3	7	2012-03-19	40199	59222	\N	\N
74593	SPECIFIC_DAY	3	7	2012-08-10	40199	59222	\N	\N
74594	SPECIFIC_DAY	3	7	2011-08-18	40199	59222	\N	\N
74595	SPECIFIC_DAY	3	7	2011-11-24	40199	59222	\N	\N
74596	SPECIFIC_DAY	3	7	2011-08-09	40199	59222	\N	\N
74597	SPECIFIC_DAY	3	7	2012-04-16	40199	59222	\N	\N
74598	SPECIFIC_DAY	3	7	2011-09-28	40199	59222	\N	\N
74599	SPECIFIC_DAY	3	7	2011-08-12	40199	59222	\N	\N
74600	SPECIFIC_DAY	3	7	2012-12-25	40199	59222	\N	\N
74601	SPECIFIC_DAY	3	0	2012-09-02	40199	59222	\N	\N
74602	SPECIFIC_DAY	3	0	2012-10-14	40199	59222	\N	\N
74603	SPECIFIC_DAY	3	0	2012-12-30	40199	59222	\N	\N
74604	SPECIFIC_DAY	3	7	2012-04-03	40199	59222	\N	\N
74605	SPECIFIC_DAY	3	7	2013-02-12	40199	59222	\N	\N
74606	SPECIFIC_DAY	3	7	2012-03-08	40199	59222	\N	\N
74607	SPECIFIC_DAY	3	7	2012-05-30	40199	59222	\N	\N
74608	SPECIFIC_DAY	3	7	2012-11-09	40199	59222	\N	\N
74609	SPECIFIC_DAY	3	7	2012-01-02	40199	59222	\N	\N
74610	SPECIFIC_DAY	3	0	2013-01-05	40199	59222	\N	\N
74611	SPECIFIC_DAY	3	7	2011-08-08	40199	59222	\N	\N
74612	SPECIFIC_DAY	3	7	2011-10-06	40199	59222	\N	\N
74613	SPECIFIC_DAY	3	7	2012-12-14	40199	59222	\N	\N
74614	SPECIFIC_DAY	3	0	2012-01-14	40199	59222	\N	\N
74615	SPECIFIC_DAY	3	7	2012-02-20	40199	59222	\N	\N
74616	SPECIFIC_DAY	3	7	2012-11-05	40199	59222	\N	\N
74617	SPECIFIC_DAY	3	7	2012-07-26	40199	59222	\N	\N
74618	SPECIFIC_DAY	3	0	2012-11-25	40199	59222	\N	\N
74619	SPECIFIC_DAY	3	7	2011-11-07	40199	59222	\N	\N
74620	SPECIFIC_DAY	3	7	2012-06-19	40199	59222	\N	\N
74621	SPECIFIC_DAY	3	0	2012-04-22	40199	59222	\N	\N
74622	SPECIFIC_DAY	3	7	2011-08-24	40199	59222	\N	\N
74623	SPECIFIC_DAY	3	7	2011-12-29	40199	59222	\N	\N
74624	SPECIFIC_DAY	3	7	2011-09-01	40199	59222	\N	\N
74625	SPECIFIC_DAY	3	7	2011-10-05	40199	59222	\N	\N
74626	SPECIFIC_DAY	3	0	2012-10-06	40199	59222	\N	\N
74627	SPECIFIC_DAY	3	7	2012-10-11	40199	59222	\N	\N
74628	SPECIFIC_DAY	3	0	2012-04-21	40199	59222	\N	\N
74629	SPECIFIC_DAY	3	0	2011-11-26	40199	59222	\N	\N
74630	SPECIFIC_DAY	3	7	2012-12-17	40199	59222	\N	\N
74631	SPECIFIC_DAY	3	7	2012-06-01	40199	59222	\N	\N
74632	SPECIFIC_DAY	3	7	2013-02-08	40199	59222	\N	\N
74633	SPECIFIC_DAY	3	7	2012-11-29	40199	59222	\N	\N
74634	SPECIFIC_DAY	3	0	2012-08-19	40199	59222	\N	\N
74635	SPECIFIC_DAY	3	7	2011-10-07	40199	59222	\N	\N
74636	SPECIFIC_DAY	3	7	2012-05-11	40199	59222	\N	\N
74637	SPECIFIC_DAY	3	7	2012-04-06	40199	59222	\N	\N
74638	SPECIFIC_DAY	3	7	2012-02-10	40199	59222	\N	\N
74639	SPECIFIC_DAY	3	0	2011-09-18	40199	59222	\N	\N
74640	SPECIFIC_DAY	3	7	2011-10-12	40199	59222	\N	\N
74641	SPECIFIC_DAY	3	7	2011-11-02	40199	59222	\N	\N
74642	SPECIFIC_DAY	3	7	2012-08-14	40199	59222	\N	\N
74643	SPECIFIC_DAY	3	7	2012-12-04	40199	59222	\N	\N
74644	SPECIFIC_DAY	3	7	2012-02-23	40199	59222	\N	\N
74645	SPECIFIC_DAY	3	7	2012-10-04	40199	59222	\N	\N
74646	SPECIFIC_DAY	3	7	2011-08-01	40199	59222	\N	\N
74647	SPECIFIC_DAY	3	7	2012-05-10	40199	59222	\N	\N
74648	SPECIFIC_DAY	3	7	2013-01-29	40199	59222	\N	\N
74649	SPECIFIC_DAY	3	7	2012-08-09	40199	59222	\N	\N
74650	SPECIFIC_DAY	3	7	2011-08-19	40199	59222	\N	\N
74651	SPECIFIC_DAY	3	0	2012-09-01	40199	59222	\N	\N
74652	SPECIFIC_DAY	3	0	2012-11-18	40199	59222	\N	\N
74653	SPECIFIC_DAY	3	7	2011-07-26	40199	59222	\N	\N
74654	SPECIFIC_DAY	3	7	2012-06-12	40199	59222	\N	\N
74655	SPECIFIC_DAY	3	0	2013-01-06	40199	59222	\N	\N
74656	SPECIFIC_DAY	3	0	2011-06-12	40199	59222	\N	\N
74657	SPECIFIC_DAY	3	7	2012-04-18	40199	59222	\N	\N
74658	SPECIFIC_DAY	3	7	2011-10-14	40199	59222	\N	\N
74659	SPECIFIC_DAY	3	7	2013-01-08	40199	59222	\N	\N
74660	SPECIFIC_DAY	3	7	2012-05-08	40199	59222	\N	\N
74661	SPECIFIC_DAY	3	7	2012-09-28	40199	59222	\N	\N
74662	SPECIFIC_DAY	3	7	2013-01-11	40199	59222	\N	\N
74663	SPECIFIC_DAY	3	7	2011-06-27	40199	59222	\N	\N
74664	SPECIFIC_DAY	3	0	2011-11-20	40199	59222	\N	\N
74665	SPECIFIC_DAY	3	7	2012-04-30	40199	59222	\N	\N
74666	SPECIFIC_DAY	3	7	2012-05-23	40199	59222	\N	\N
74667	SPECIFIC_DAY	3	7	2011-09-14	40199	59222	\N	\N
74668	SPECIFIC_DAY	3	7	2011-12-14	40199	59222	\N	\N
74669	SPECIFIC_DAY	3	7	2011-07-01	40199	59222	\N	\N
74670	SPECIFIC_DAY	3	7	2012-08-03	40199	59222	\N	\N
74671	SPECIFIC_DAY	3	7	2012-09-12	40199	59222	\N	\N
74672	SPECIFIC_DAY	3	7	2011-06-16	40199	59222	\N	\N
74673	SPECIFIC_DAY	3	0	2011-08-07	40199	59222	\N	\N
74674	SPECIFIC_DAY	3	7	2012-11-07	40199	59222	\N	\N
74675	SPECIFIC_DAY	3	7	2012-04-25	40199	59222	\N	\N
74676	SPECIFIC_DAY	3	0	2011-12-10	40199	59222	\N	\N
74677	SPECIFIC_DAY	3	7	2012-10-10	40199	59222	\N	\N
74678	SPECIFIC_DAY	3	0	2011-10-23	40199	59222	\N	\N
74679	SPECIFIC_DAY	3	7	2013-01-24	40199	59222	\N	\N
74680	SPECIFIC_DAY	3	7	2012-07-06	40199	59222	\N	\N
74681	SPECIFIC_DAY	3	7	2012-01-13	40199	59222	\N	\N
74682	SPECIFIC_DAY	3	7	2011-11-14	40199	59222	\N	\N
74683	SPECIFIC_DAY	3	7	2012-03-28	40199	59222	\N	\N
74684	SPECIFIC_DAY	3	7	2011-11-22	40199	59222	\N	\N
74685	SPECIFIC_DAY	3	0	2012-06-10	40199	59222	\N	\N
74686	SPECIFIC_DAY	3	7	2011-10-19	40199	59222	\N	\N
74687	SPECIFIC_DAY	3	7	2011-10-21	40199	59222	\N	\N
74688	SPECIFIC_DAY	3	0	2011-08-28	40199	59222	\N	\N
74689	SPECIFIC_DAY	3	7	2012-04-12	40199	59222	\N	\N
74690	SPECIFIC_DAY	3	7	2012-05-02	40199	59222	\N	\N
74691	SPECIFIC_DAY	3	7	2012-01-20	40199	59222	\N	\N
74692	SPECIFIC_DAY	3	0	2012-12-15	40199	59222	\N	\N
74693	SPECIFIC_DAY	3	0	2011-09-03	40199	59222	\N	\N
74694	SPECIFIC_DAY	3	7	2011-10-27	40199	59222	\N	\N
74695	SPECIFIC_DAY	3	7	2013-01-14	40199	59222	\N	\N
74696	SPECIFIC_DAY	3	7	2012-10-01	40199	59222	\N	\N
74697	SPECIFIC_DAY	3	7	2012-08-08	40199	59222	\N	\N
74698	SPECIFIC_DAY	3	7	2012-03-06	40199	59222	\N	\N
74699	SPECIFIC_DAY	3	0	2011-10-09	40199	59222	\N	\N
74700	SPECIFIC_DAY	3	7	2013-01-04	40199	59222	\N	\N
74701	SPECIFIC_DAY	3	0	2011-10-16	40199	59222	\N	\N
74702	SPECIFIC_DAY	3	0	2011-12-17	40199	59222	\N	\N
74703	SPECIFIC_DAY	3	7	2012-12-06	40199	59222	\N	\N
74704	SPECIFIC_DAY	3	7	2012-08-29	40199	59222	\N	\N
74705	SPECIFIC_DAY	3	7	2012-11-02	40199	59222	\N	\N
74706	SPECIFIC_DAY	3	0	2012-10-13	40199	59222	\N	\N
74707	SPECIFIC_DAY	3	7	2011-10-17	40199	59222	\N	\N
74708	SPECIFIC_DAY	3	7	2012-01-25	40199	59222	\N	\N
74709	SPECIFIC_DAY	3	7	2011-06-03	40199	59222	\N	\N
74710	SPECIFIC_DAY	3	0	2012-01-08	40199	59222	\N	\N
74711	SPECIFIC_DAY	3	7	2012-03-02	40199	59222	\N	\N
74712	SPECIFIC_DAY	3	7	2012-05-22	40199	59222	\N	\N
74713	SPECIFIC_DAY	3	0	2012-08-04	40199	59222	\N	\N
74714	SPECIFIC_DAY	3	0	2012-12-23	40199	59222	\N	\N
74715	SPECIFIC_DAY	3	0	2011-10-29	40199	59222	\N	\N
74716	SPECIFIC_DAY	3	7	2013-02-13	40199	59222	\N	\N
74717	SPECIFIC_DAY	3	7	2012-05-24	40199	59222	\N	\N
74718	SPECIFIC_DAY	3	7	2013-01-09	40199	59222	\N	\N
74719	SPECIFIC_DAY	3	0	2012-04-29	40199	59222	\N	\N
74720	SPECIFIC_DAY	3	7	2012-02-01	40199	59222	\N	\N
74721	SPECIFIC_DAY	3	0	2012-06-17	40199	59222	\N	\N
74722	SPECIFIC_DAY	3	0	2011-07-09	40199	59222	\N	\N
74723	SPECIFIC_DAY	3	0	2012-02-26	40199	59222	\N	\N
74724	SPECIFIC_DAY	3	7	2012-02-22	40199	59222	\N	\N
74725	SPECIFIC_DAY	3	7	2011-11-23	40199	59222	\N	\N
74726	SPECIFIC_DAY	3	7	2012-10-31	40199	59222	\N	\N
74727	SPECIFIC_DAY	3	7	2011-12-23	40199	59222	\N	\N
74728	SPECIFIC_DAY	3	0	2012-09-30	40199	59222	\N	\N
74729	SPECIFIC_DAY	3	0	2011-09-24	40199	59222	\N	\N
74730	SPECIFIC_DAY	3	7	2012-08-22	40199	59222	\N	\N
74731	SPECIFIC_DAY	3	7	2011-12-16	40199	59222	\N	\N
74732	SPECIFIC_DAY	3	7	2013-01-28	40199	59222	\N	\N
74733	SPECIFIC_DAY	3	7	2011-07-19	40199	59222	\N	\N
74734	SPECIFIC_DAY	3	7	2012-06-05	40199	59222	\N	\N
74735	SPECIFIC_DAY	3	7	2012-08-21	40199	59222	\N	\N
74736	SPECIFIC_DAY	3	0	2012-06-03	40199	59222	\N	\N
74737	SPECIFIC_DAY	3	7	2011-07-12	40199	59222	\N	\N
74738	SPECIFIC_DAY	3	7	2012-04-09	40199	59222	\N	\N
74739	SPECIFIC_DAY	3	7	2012-05-01	40199	59222	\N	\N
74740	SPECIFIC_DAY	3	0	2012-02-04	40199	59222	\N	\N
74741	SPECIFIC_DAY	3	7	2011-08-11	40199	59222	\N	\N
74742	SPECIFIC_DAY	3	7	2012-11-06	40199	59222	\N	\N
74743	SPECIFIC_DAY	3	7	2012-09-21	40199	59222	\N	\N
74744	SPECIFIC_DAY	3	7	2011-11-04	40199	59222	\N	\N
74745	SPECIFIC_DAY	3	7	2011-10-03	40199	59222	\N	\N
74746	SPECIFIC_DAY	3	7	2012-11-08	40199	59222	\N	\N
74747	SPECIFIC_DAY	3	7	2013-02-06	40199	59222	\N	\N
74748	SPECIFIC_DAY	3	0	2012-09-29	40199	59222	\N	\N
74749	SPECIFIC_DAY	3	7	2012-06-28	40199	59222	\N	\N
74750	SPECIFIC_DAY	3	7	2012-06-29	40199	59222	\N	\N
74751	SPECIFIC_DAY	3	7	2012-02-13	40199	59222	\N	\N
74752	SPECIFIC_DAY	3	0	2012-05-05	40199	59222	\N	\N
74753	SPECIFIC_DAY	3	7	2012-10-12	40199	59222	\N	\N
74754	SPECIFIC_DAY	3	7	2012-11-19	40199	59222	\N	\N
74755	SPECIFIC_DAY	3	0	2011-07-10	40199	59222	\N	\N
74756	SPECIFIC_DAY	3	7	2012-03-27	40199	59222	\N	\N
74757	SPECIFIC_DAY	3	0	2011-07-02	40199	59222	\N	\N
74758	SPECIFIC_DAY	3	7	2011-11-03	40199	59222	\N	\N
74759	SPECIFIC_DAY	3	0	2012-04-07	40199	59222	\N	\N
74760	SPECIFIC_DAY	3	0	2012-09-09	40199	59222	\N	\N
74761	SPECIFIC_DAY	3	7	2012-08-06	40199	59222	\N	\N
74762	SPECIFIC_DAY	3	7	2012-12-19	40199	59222	\N	\N
74763	SPECIFIC_DAY	3	7	2011-06-22	40199	59222	\N	\N
74764	SPECIFIC_DAY	3	0	2012-01-21	40199	59222	\N	\N
74765	SPECIFIC_DAY	3	7	2011-08-22	40199	59222	\N	\N
74766	SPECIFIC_DAY	3	7	2013-01-30	40199	59222	\N	\N
74767	SPECIFIC_DAY	3	0	2012-06-23	40199	59222	\N	\N
74768	SPECIFIC_DAY	3	0	2012-12-02	40199	59222	\N	\N
74769	SPECIFIC_DAY	3	7	2011-09-23	40199	59222	\N	\N
74770	SPECIFIC_DAY	3	0	2012-03-24	40199	59222	\N	\N
74771	SPECIFIC_DAY	3	7	2012-01-18	40199	59222	\N	\N
74772	SPECIFIC_DAY	3	7	2012-12-10	40199	59222	\N	\N
74773	SPECIFIC_DAY	3	7	2011-09-08	40199	59222	\N	\N
74774	SPECIFIC_DAY	3	7	2012-08-23	40199	59222	\N	\N
74775	SPECIFIC_DAY	3	7	2012-12-21	40199	59222	\N	\N
74776	SPECIFIC_DAY	3	7	2012-05-07	40199	59222	\N	\N
74777	SPECIFIC_DAY	3	7	2012-03-23	40199	59222	\N	\N
74778	SPECIFIC_DAY	3	0	2011-06-05	40199	59222	\N	\N
74779	SPECIFIC_DAY	3	7	2012-09-10	40199	59222	\N	\N
74780	SPECIFIC_DAY	3	7	2011-12-02	40199	59222	\N	\N
74781	SPECIFIC_DAY	3	7	2012-10-05	40199	59222	\N	\N
74782	SPECIFIC_DAY	3	7	2012-06-04	40199	59222	\N	\N
74783	SPECIFIC_DAY	3	7	2012-11-16	40199	59222	\N	\N
74784	SPECIFIC_DAY	3	7	2013-01-01	40199	59222	\N	\N
74785	SPECIFIC_DAY	3	7	2011-12-30	40199	59222	\N	\N
74786	SPECIFIC_DAY	3	7	2012-05-28	40199	59222	\N	\N
74787	SPECIFIC_DAY	3	7	2012-07-24	40199	59222	\N	\N
74788	SPECIFIC_DAY	3	0	2012-10-21	40199	59222	\N	\N
74789	SPECIFIC_DAY	3	0	2012-12-09	40199	59222	\N	\N
74790	SPECIFIC_DAY	3	7	2012-11-12	40199	59222	\N	\N
74791	SPECIFIC_DAY	3	0	2011-09-11	40199	59222	\N	\N
74792	SPECIFIC_DAY	3	7	2012-10-24	40199	59222	\N	\N
74793	SPECIFIC_DAY	3	0	2012-11-11	40199	59222	\N	\N
74794	SPECIFIC_DAY	3	7	2011-07-22	40199	59222	\N	\N
74795	SPECIFIC_DAY	3	0	2013-01-26	40199	59222	\N	\N
74796	SPECIFIC_DAY	3	7	2012-02-21	40199	59222	\N	\N
74797	SPECIFIC_DAY	3	7	2011-11-28	40199	59222	\N	\N
74798	SPECIFIC_DAY	3	7	2012-01-27	40199	59222	\N	\N
74799	SPECIFIC_DAY	3	7	2012-04-11	40199	59222	\N	\N
74800	SPECIFIC_DAY	3	7	2011-11-10	40199	59222	\N	\N
74801	SPECIFIC_DAY	3	7	2012-07-05	40199	59222	\N	\N
74802	SPECIFIC_DAY	3	0	2011-08-14	40199	59222	\N	\N
74803	SPECIFIC_DAY	3	0	2011-10-01	40199	59222	\N	\N
74804	SPECIFIC_DAY	3	7	2013-01-10	40199	59222	\N	\N
74805	SPECIFIC_DAY	3	7	2012-01-03	40199	59222	\N	\N
74806	SPECIFIC_DAY	3	0	2012-08-05	40199	59222	\N	\N
74807	SPECIFIC_DAY	3	7	2012-08-27	40199	59222	\N	\N
74808	SPECIFIC_DAY	3	0	2011-05-28	40199	59222	\N	\N
74809	SPECIFIC_DAY	3	7	2012-05-21	40199	59222	\N	\N
74810	SPECIFIC_DAY	3	7	2011-08-15	40199	59222	\N	\N
74811	SPECIFIC_DAY	3	7	2012-05-18	40199	59222	\N	\N
74812	SPECIFIC_DAY	3	0	2011-10-22	40199	59222	\N	\N
74813	SPECIFIC_DAY	3	7	2011-08-17	40199	59222	\N	\N
74814	SPECIFIC_DAY	3	0	2012-03-10	40199	59222	\N	\N
74815	SPECIFIC_DAY	3	7	2011-10-24	40199	59222	\N	\N
74816	SPECIFIC_DAY	3	7	2012-09-20	40199	59222	\N	\N
74817	SPECIFIC_DAY	3	7	2012-10-17	40199	59222	\N	\N
74818	SPECIFIC_DAY	3	0	2011-09-04	40199	59222	\N	\N
74819	SPECIFIC_DAY	3	7	2012-04-05	40199	59222	\N	\N
74820	SPECIFIC_DAY	3	0	2012-05-20	40199	59222	\N	\N
74821	SPECIFIC_DAY	3	0	2012-03-11	40199	59222	\N	\N
74822	SPECIFIC_DAY	3	0	2012-12-22	40199	59222	\N	\N
74823	SPECIFIC_DAY	3	7	2012-09-27	40199	59222	\N	\N
74824	SPECIFIC_DAY	3	7	2012-09-06	40199	59222	\N	\N
74825	SPECIFIC_DAY	3	7	2012-04-26	40199	59222	\N	\N
74826	SPECIFIC_DAY	3	7	2012-01-23	40199	59222	\N	\N
74827	SPECIFIC_DAY	3	7	2012-12-12	40199	59222	\N	\N
74828	SPECIFIC_DAY	3	7	2012-10-23	40199	59222	\N	\N
74829	SPECIFIC_DAY	3	7	2011-09-29	40199	59222	\N	\N
74830	SPECIFIC_DAY	3	0	2012-01-15	40199	59222	\N	\N
74831	SPECIFIC_DAY	3	7	2012-09-18	40199	59222	\N	\N
74832	SPECIFIC_DAY	3	0	2013-01-12	40199	59222	\N	\N
74833	SPECIFIC_DAY	3	7	2012-08-01	40199	59222	\N	\N
74834	SPECIFIC_DAY	3	7	2011-12-08	40199	59222	\N	\N
74835	SPECIFIC_DAY	3	0	2012-10-28	40199	59222	\N	\N
74836	SPECIFIC_DAY	3	7	2011-12-12	40199	59222	\N	\N
74837	SPECIFIC_DAY	3	7	2011-11-01	40199	59222	\N	\N
74838	SPECIFIC_DAY	3	7	2011-07-07	40199	59222	\N	\N
74839	SPECIFIC_DAY	3	0	2012-08-12	40199	59222	\N	\N
74840	SPECIFIC_DAY	3	7	2012-06-22	40199	59222	\N	\N
74841	SPECIFIC_DAY	3	7	2013-01-15	40199	59222	\N	\N
74842	SPECIFIC_DAY	3	7	2011-09-06	40199	59222	\N	\N
74843	SPECIFIC_DAY	3	7	2012-11-26	40199	59222	\N	\N
74844	SPECIFIC_DAY	3	7	2011-07-28	40199	59222	\N	\N
74845	SPECIFIC_DAY	3	7	2011-07-08	40199	59222	\N	\N
74846	SPECIFIC_DAY	3	0	2011-09-10	40199	59222	\N	\N
74847	SPECIFIC_DAY	3	7	2012-07-13	40199	59222	\N	\N
74848	SPECIFIC_DAY	3	0	2012-02-11	40199	59222	\N	\N
74849	SPECIFIC_DAY	3	0	2011-07-03	40199	59222	\N	\N
74850	SPECIFIC_DAY	3	7	2012-09-07	40199	59222	\N	\N
74851	SPECIFIC_DAY	3	7	2012-03-14	40199	59222	\N	\N
74852	SPECIFIC_DAY	3	7	2012-07-31	40199	59222	\N	\N
74853	SPECIFIC_DAY	3	0	2012-03-17	40199	59222	\N	\N
74854	SPECIFIC_DAY	3	0	2012-07-08	40199	59222	\N	\N
74855	SPECIFIC_DAY	3	0	2012-05-27	40199	59222	\N	\N
74856	SPECIFIC_DAY	3	7	2012-03-16	40199	59222	\N	\N
74857	SPECIFIC_DAY	3	0	2012-04-15	40199	59222	\N	\N
74858	SPECIFIC_DAY	3	7	2012-12-03	40199	59222	\N	\N
74859	SPECIFIC_DAY	3	0	2012-08-18	40199	59222	\N	\N
74860	SPECIFIC_DAY	3	0	2011-12-18	40199	59222	\N	\N
74861	SPECIFIC_DAY	3	7	2012-02-09	40199	59222	\N	\N
74862	SPECIFIC_DAY	3	0	2012-02-18	40199	59222	\N	\N
74863	SPECIFIC_DAY	3	7	2011-11-21	40199	59222	\N	\N
74864	SPECIFIC_DAY	3	7	2011-11-09	40199	59222	\N	\N
74865	SPECIFIC_DAY	3	7	2011-10-11	40199	59222	\N	\N
74866	SPECIFIC_DAY	3	0	2011-11-13	40199	59222	\N	\N
74867	SPECIFIC_DAY	3	0	2011-08-27	40199	59222	\N	\N
74868	SPECIFIC_DAY	3	7	2012-08-13	40199	59222	\N	\N
74869	SPECIFIC_DAY	3	0	2012-12-16	40199	59222	\N	\N
74870	SPECIFIC_DAY	3	0	2012-11-10	40199	59222	\N	\N
74871	SPECIFIC_DAY	3	0	2012-10-20	40199	59222	\N	\N
74872	SPECIFIC_DAY	3	7	2011-12-07	40199	59222	\N	\N
74873	SPECIFIC_DAY	3	0	2012-09-16	40199	59222	\N	\N
74874	SPECIFIC_DAY	3	7	2011-12-19	40199	59222	\N	\N
74875	SPECIFIC_DAY	3	7	2012-11-01	40199	59222	\N	\N
74876	SPECIFIC_DAY	3	0	2012-11-24	40199	59222	\N	\N
74877	SPECIFIC_DAY	3	0	2012-04-28	40199	59222	\N	\N
74878	SPECIFIC_DAY	3	7	2012-05-25	40199	59222	\N	\N
74879	SPECIFIC_DAY	3	7	2011-06-17	40199	59222	\N	\N
74880	SPECIFIC_DAY	3	7	2011-08-31	40199	59222	\N	\N
74881	SPECIFIC_DAY	3	0	2011-07-30	40199	59222	\N	\N
74882	SPECIFIC_DAY	3	7	2011-11-11	40199	59222	\N	\N
74883	SPECIFIC_DAY	3	7	2012-10-19	40199	59222	\N	\N
74884	SPECIFIC_DAY	3	0	2011-06-11	40199	59222	\N	\N
74885	SPECIFIC_DAY	3	0	2011-06-04	40199	59222	\N	\N
74886	SPECIFIC_DAY	3	7	2012-02-03	40199	59222	\N	\N
74887	SPECIFIC_DAY	3	7	2011-06-15	40199	59222	\N	\N
74888	SPECIFIC_DAY	3	7	2012-11-27	40199	59222	\N	\N
74889	SPECIFIC_DAY	3	7	2012-06-25	40199	59222	\N	\N
74890	SPECIFIC_DAY	3	7	2013-01-17	40199	59222	\N	\N
74891	SPECIFIC_DAY	3	7	2011-12-06	40199	59222	\N	\N
74892	SPECIFIC_DAY	3	7	2012-01-04	40199	59222	\N	\N
74893	SPECIFIC_DAY	3	7	2011-12-28	40199	59222	\N	\N
74894	SPECIFIC_DAY	3	0	2011-07-31	40199	59222	\N	\N
74895	SPECIFIC_DAY	3	0	2011-07-23	40199	59222	\N	\N
74896	SPECIFIC_DAY	3	7	2011-12-27	40199	59222	\N	\N
74897	SPECIFIC_DAY	3	7	2012-01-17	40199	59222	\N	\N
74898	SPECIFIC_DAY	3	7	2011-10-31	40199	59222	\N	\N
74899	SPECIFIC_DAY	3	7	2012-07-30	40199	59222	\N	\N
74900	SPECIFIC_DAY	3	7	2012-01-06	40199	59222	\N	\N
74901	SPECIFIC_DAY	3	7	2012-04-20	40199	59222	\N	\N
74902	SPECIFIC_DAY	3	7	2011-09-09	40199	59222	\N	\N
74903	SPECIFIC_DAY	3	0	2012-07-29	40199	59222	\N	\N
74904	SPECIFIC_DAY	3	0	2012-05-13	40199	59222	\N	\N
74905	SPECIFIC_DAY	3	7	2013-02-01	40199	59222	\N	\N
74906	SPECIFIC_DAY	3	7	2011-05-26	40199	59222	\N	\N
74907	SPECIFIC_DAY	3	7	2011-10-25	40199	59222	\N	\N
74908	SPECIFIC_DAY	3	7	2011-08-04	40199	59222	\N	\N
74909	SPECIFIC_DAY	3	7	2011-08-03	40199	59222	\N	\N
74910	SPECIFIC_DAY	3	7	2011-12-20	40199	59222	\N	\N
74911	SPECIFIC_DAY	3	7	2012-02-17	40199	59222	\N	\N
74912	SPECIFIC_DAY	3	0	2012-06-30	40199	59222	\N	\N
74913	SPECIFIC_DAY	3	0	2011-09-25	40199	59222	\N	\N
74914	SPECIFIC_DAY	3	7	2012-02-02	40199	59222	\N	\N
74915	SPECIFIC_DAY	3	7	2012-03-15	40199	59222	\N	\N
74916	SPECIFIC_DAY	3	7	2011-08-30	40199	59222	\N	\N
74917	SPECIFIC_DAY	3	0	2011-08-06	40199	59222	\N	\N
74918	SPECIFIC_DAY	3	7	2011-06-21	40199	59222	\N	\N
74919	SPECIFIC_DAY	3	7	2011-07-04	40199	59222	\N	\N
74920	SPECIFIC_DAY	3	7	2011-09-05	40199	59222	\N	\N
74921	SPECIFIC_DAY	3	7	2012-05-31	40199	59222	\N	\N
74922	SPECIFIC_DAY	3	7	2012-01-09	40199	59222	\N	\N
74923	SPECIFIC_DAY	3	7	2011-07-21	40199	59222	\N	\N
74924	SPECIFIC_DAY	3	7	2012-07-20	40199	59222	\N	\N
74925	SPECIFIC_DAY	3	7	2012-07-09	40199	59222	\N	\N
74926	SPECIFIC_DAY	3	7	2012-09-13	40199	59222	\N	\N
74927	SPECIFIC_DAY	3	7	2011-08-05	40199	59222	\N	\N
74928	SPECIFIC_DAY	3	7	2013-01-23	40199	59222	\N	\N
74929	SPECIFIC_DAY	3	0	2011-07-17	40199	59222	\N	\N
74930	SPECIFIC_DAY	3	7	2011-09-13	40199	59222	\N	\N
74931	SPECIFIC_DAY	3	7	2011-09-12	40199	59222	\N	\N
74932	SPECIFIC_DAY	3	0	2013-02-09	40199	59222	\N	\N
74933	SPECIFIC_DAY	3	7	2011-06-29	40199	59222	\N	\N
74934	SPECIFIC_DAY	3	0	2012-05-06	40199	59222	\N	\N
74935	SPECIFIC_DAY	3	0	2012-02-25	40199	59222	\N	\N
74936	SPECIFIC_DAY	3	7	2011-11-17	40199	59222	\N	\N
74937	SPECIFIC_DAY	3	7	2011-09-26	40199	59222	\N	\N
74938	SPECIFIC_DAY	3	7	2012-02-29	40199	59222	\N	\N
74939	SPECIFIC_DAY	3	0	2011-10-15	40199	59222	\N	\N
74940	SPECIFIC_DAY	3	7	2011-05-31	40199	59222	\N	\N
74941	SPECIFIC_DAY	3	0	2011-06-19	40199	59222	\N	\N
74942	SPECIFIC_DAY	3	7	2012-11-28	40199	59222	\N	\N
74943	SPECIFIC_DAY	3	7	2011-07-15	40199	59222	\N	\N
74944	SPECIFIC_DAY	3	7	2012-06-20	40199	59222	\N	\N
74945	SPECIFIC_DAY	3	7	2011-11-08	40199	59222	\N	\N
74946	SPECIFIC_DAY	3	7	2012-05-03	40199	59222	\N	\N
74947	SPECIFIC_DAY	3	7	2012-10-30	40199	59222	\N	\N
74948	SPECIFIC_DAY	3	7	2011-08-10	40199	59222	\N	\N
74949	SPECIFIC_DAY	3	7	2012-10-02	40199	59222	\N	\N
74950	SPECIFIC_DAY	3	0	2012-07-15	40199	59222	\N	\N
74951	SPECIFIC_DAY	3	7	2012-05-04	40199	59222	\N	\N
74952	SPECIFIC_DAY	3	7	2011-10-26	40199	59222	\N	\N
74953	SPECIFIC_DAY	3	7	2012-09-19	40199	59222	\N	\N
74954	SPECIFIC_DAY	3	7	2011-06-14	40199	59222	\N	\N
74955	SPECIFIC_DAY	3	7	2012-01-05	40199	59222	\N	\N
74956	SPECIFIC_DAY	3	0	2012-01-22	40199	59222	\N	\N
74957	SPECIFIC_DAY	3	0	2012-07-28	40199	59222	\N	\N
74958	SPECIFIC_DAY	3	0	2013-02-10	40199	59222	\N	\N
74959	SPECIFIC_DAY	3	7	2012-09-24	40199	59222	\N	\N
74960	SPECIFIC_DAY	3	7	2012-06-27	40199	59222	\N	\N
74961	SPECIFIC_DAY	3	7	2011-09-22	40199	59222	\N	\N
74962	SPECIFIC_DAY	3	7	2012-03-12	40199	59222	\N	\N
74963	SPECIFIC_DAY	3	7	2011-07-20	40199	59222	\N	\N
74964	SPECIFIC_DAY	3	0	2012-03-04	40199	59222	\N	\N
74965	SPECIFIC_DAY	3	0	2011-11-05	40199	59222	\N	\N
74966	SPECIFIC_DAY	3	0	2012-09-15	40199	59222	\N	\N
74967	SPECIFIC_DAY	3	7	2012-11-14	40199	59222	\N	\N
74968	SPECIFIC_DAY	3	7	2012-07-17	40199	59222	\N	\N
74969	SPECIFIC_DAY	3	7	2012-06-15	40199	59222	\N	\N
74970	SPECIFIC_DAY	3	7	2013-01-16	40199	59222	\N	\N
74971	SPECIFIC_DAY	3	7	2012-01-19	40199	59222	\N	\N
74972	SPECIFIC_DAY	3	0	2012-12-08	40199	59222	\N	\N
74973	SPECIFIC_DAY	3	7	2012-08-20	40199	59222	\N	\N
74974	SPECIFIC_DAY	3	0	2012-06-09	40199	59222	\N	\N
74975	SPECIFIC_DAY	3	0	2012-09-08	40199	59222	\N	\N
74976	SPECIFIC_DAY	3	0	2011-12-11	40199	59222	\N	\N
74977	SPECIFIC_DAY	3	0	2012-08-25	40199	59222	\N	\N
74978	SPECIFIC_DAY	3	7	2012-06-06	40199	59222	\N	\N
74979	SPECIFIC_DAY	3	7	2011-12-21	40199	59222	\N	\N
74980	SPECIFIC_DAY	3	0	2012-09-22	40199	59222	\N	\N
74981	SPECIFIC_DAY	3	7	2012-11-22	40199	59222	\N	\N
74982	SPECIFIC_DAY	3	7	2012-03-09	40199	59222	\N	\N
74983	SPECIFIC_DAY	3	7	2012-09-14	40199	59222	\N	\N
74984	SPECIFIC_DAY	3	7	2012-10-25	40199	59222	\N	\N
74985	SPECIFIC_DAY	3	0	2012-07-21	40199	59222	\N	\N
74986	SPECIFIC_DAY	3	7	2012-02-06	40199	59222	\N	\N
74987	SPECIFIC_DAY	3	7	2011-07-29	40199	59222	\N	\N
74988	SPECIFIC_DAY	3	7	2011-12-26	40199	59222	\N	\N
74989	SPECIFIC_DAY	3	7	2013-02-04	40199	59222	\N	\N
74990	SPECIFIC_DAY	3	0	2012-07-22	40199	59222	\N	\N
74991	SPECIFIC_DAY	3	7	2012-10-03	40199	59222	\N	\N
74992	SPECIFIC_DAY	3	7	2011-07-14	40199	59222	\N	\N
74993	SPECIFIC_DAY	3	7	2012-10-26	40199	59222	\N	\N
74994	SPECIFIC_DAY	3	7	2012-02-15	40199	59222	\N	\N
74995	SPECIFIC_DAY	3	7	2012-07-04	40199	59222	\N	\N
74996	SPECIFIC_DAY	3	7	2012-09-26	40199	59222	\N	\N
74997	SPECIFIC_DAY	3	7	2012-02-27	40199	59222	\N	\N
74998	SPECIFIC_DAY	3	7	2012-08-07	40199	59222	\N	\N
74999	SPECIFIC_DAY	3	7	2012-06-26	40199	59222	\N	\N
75000	SPECIFIC_DAY	3	0	2011-10-02	40199	59222	\N	\N
75001	SPECIFIC_DAY	3	0	2011-11-27	40199	59222	\N	\N
75002	SPECIFIC_DAY	3	0	2013-01-19	40199	59222	\N	\N
75003	SPECIFIC_DAY	3	7	2012-09-05	40199	59222	\N	\N
75004	SPECIFIC_DAY	3	0	2013-02-02	40199	59222	\N	\N
75005	SPECIFIC_DAY	3	7	2012-12-27	40199	59222	\N	\N
75006	SPECIFIC_DAY	3	7	2012-01-16	40199	59222	\N	\N
75007	SPECIFIC_DAY	3	7	2011-11-16	40199	59222	\N	\N
75008	SPECIFIC_DAY	3	7	2012-01-31	40199	59222	\N	\N
75009	SPECIFIC_DAY	3	7	2012-08-02	40199	59222	\N	\N
75010	SPECIFIC_DAY	3	7	2011-08-16	40199	59222	\N	\N
75011	SPECIFIC_DAY	3	0	2012-04-08	40199	59222	\N	\N
75012	SPECIFIC_DAY	3	7	2012-04-02	40199	59222	\N	\N
75013	SPECIFIC_DAY	3	7	2012-10-29	40199	59222	\N	\N
75014	SPECIFIC_DAY	3	7	2012-09-17	40199	59222	\N	\N
75015	SPECIFIC_DAY	3	0	2011-11-12	40199	59222	\N	\N
75016	SPECIFIC_DAY	3	0	2013-02-03	40199	59222	\N	\N
75017	SPECIFIC_DAY	3	0	2012-12-01	40199	59222	\N	\N
75018	SPECIFIC_DAY	3	7	2012-02-24	40199	59222	\N	\N
75019	SPECIFIC_DAY	3	7	2012-06-14	40199	59222	\N	\N
75020	SPECIFIC_DAY	3	7	2011-12-13	40199	59222	\N	\N
75021	SPECIFIC_DAY	3	7	2012-01-30	40199	59222	\N	\N
75022	SPECIFIC_DAY	3	7	2012-05-16	40199	59222	\N	\N
75023	SPECIFIC_DAY	3	7	2011-12-22	40199	59222	\N	\N
75024	SPECIFIC_DAY	3	7	2013-01-02	40199	59222	\N	\N
75025	SPECIFIC_DAY	3	7	2012-10-22	40199	59222	\N	\N
75026	SPECIFIC_DAY	3	0	2012-05-19	40199	59222	\N	\N
75027	SPECIFIC_DAY	3	0	2012-11-04	40199	59222	\N	\N
75028	SPECIFIC_DAY	3	7	2012-12-31	40199	59222	\N	\N
75029	SPECIFIC_DAY	3	7	2012-04-19	40199	59222	\N	\N
75030	SPECIFIC_DAY	3	7	2011-05-30	40199	59222	\N	\N
75031	SPECIFIC_DAY	3	7	2012-08-15	40199	59222	\N	\N
75032	SPECIFIC_DAY	3	0	2012-03-18	40199	59222	\N	\N
75033	SPECIFIC_DAY	3	7	2012-08-30	40199	59222	\N	\N
75034	SPECIFIC_DAY	3	7	2012-05-17	40199	59222	\N	\N
75035	SPECIFIC_DAY	3	7	2012-08-16	40199	59222	\N	\N
75036	SPECIFIC_DAY	3	7	2011-09-21	40199	59222	\N	\N
75037	SPECIFIC_DAY	3	7	2013-02-07	40199	59222	\N	\N
75038	SPECIFIC_DAY	3	7	2011-06-01	40199	59222	\N	\N
75039	SPECIFIC_DAY	3	7	2011-12-09	40199	59222	\N	\N
75040	SPECIFIC_DAY	3	7	2012-07-16	40199	59222	\N	\N
75041	SPECIFIC_DAY	3	7	2012-02-16	40199	59222	\N	\N
75042	SPECIFIC_DAY	3	7	2011-06-02	40199	59222	\N	\N
75043	SPECIFIC_DAY	3	7	2011-11-29	40199	59222	\N	\N
75044	SPECIFIC_DAY	3	7	2011-06-06	40199	59222	\N	\N
75045	SPECIFIC_DAY	3	7	2011-06-07	40199	59222	\N	\N
75046	SPECIFIC_DAY	3	0	2012-01-29	40199	59222	\N	\N
75047	SPECIFIC_DAY	3	7	2011-10-28	40199	59222	\N	\N
75048	SPECIFIC_DAY	3	7	2012-12-24	40199	59222	\N	\N
75049	SPECIFIC_DAY	3	7	2012-11-23	40199	59222	\N	\N
75050	SPECIFIC_DAY	3	0	2012-01-01	40199	59222	\N	\N
75051	SPECIFIC_DAY	3	7	2012-10-09	40199	59222	\N	\N
75052	SPECIFIC_DAY	3	7	2011-09-19	40199	59222	\N	\N
75053	SPECIFIC_DAY	3	7	2011-10-20	40199	59222	\N	\N
75054	SPECIFIC_DAY	3	7	2012-09-04	40199	59222	\N	\N
75055	SPECIFIC_DAY	3	0	2012-01-07	40199	59222	\N	\N
75056	SPECIFIC_DAY	3	0	2013-01-13	40199	59222	\N	\N
75057	SPECIFIC_DAY	3	7	2012-12-28	40199	59222	\N	\N
75058	SPECIFIC_DAY	3	7	2012-01-24	40199	59222	\N	\N
75059	SPECIFIC_DAY	3	7	2012-04-24	40199	59222	\N	\N
75060	SPECIFIC_DAY	3	0	2011-12-25	40199	59222	\N	\N
75061	SPECIFIC_DAY	3	7	2012-04-10	40199	59222	\N	\N
75062	SPECIFIC_DAY	3	7	2012-07-27	40199	59222	\N	\N
75063	SPECIFIC_DAY	3	7	2012-03-22	40199	59222	\N	\N
75064	SPECIFIC_DAY	3	7	2013-01-22	40199	59222	\N	\N
75065	SPECIFIC_DAY	3	7	2011-09-30	40199	59222	\N	\N
75066	SPECIFIC_DAY	3	7	2011-06-09	40199	59222	\N	\N
75067	SPECIFIC_DAY	3	0	2012-02-19	40199	59222	\N	\N
75068	SPECIFIC_DAY	3	7	2012-10-15	40199	59222	\N	\N
75069	SPECIFIC_DAY	3	7	2012-12-13	40199	59222	\N	\N
75070	SPECIFIC_DAY	3	7	2011-10-10	40199	59222	\N	\N
75071	SPECIFIC_DAY	3	7	2012-05-03	40199	59201	\N	\N
75072	SPECIFIC_DAY	3	7	2011-05-31	40199	59201	\N	\N
75073	SPECIFIC_DAY	3	0	2012-03-03	40199	59201	\N	\N
75074	SPECIFIC_DAY	3	7	2011-12-28	40199	59201	\N	\N
75075	SPECIFIC_DAY	3	7	2012-03-09	40199	59201	\N	\N
75076	SPECIFIC_DAY	3	7	2012-08-10	40199	59201	\N	\N
75077	SPECIFIC_DAY	3	7	2012-03-21	40199	59201	\N	\N
75078	SPECIFIC_DAY	3	0	2011-07-30	40199	59201	\N	\N
75079	SPECIFIC_DAY	3	7	2011-12-14	40199	59201	\N	\N
75080	SPECIFIC_DAY	3	7	2012-04-03	40199	59201	\N	\N
75081	SPECIFIC_DAY	3	0	2012-06-24	40199	59201	\N	\N
75082	SPECIFIC_DAY	3	7	2011-07-27	40199	59201	\N	\N
75083	SPECIFIC_DAY	3	7	2012-12-20	40199	59201	\N	\N
75084	SPECIFIC_DAY	3	0	2011-11-19	40199	59201	\N	\N
75085	SPECIFIC_DAY	3	7	2012-10-09	40199	59201	\N	\N
75086	SPECIFIC_DAY	3	7	2012-09-04	40199	59201	\N	\N
75087	SPECIFIC_DAY	3	7	2011-08-11	40199	59201	\N	\N
75088	SPECIFIC_DAY	3	7	2011-09-07	40199	59201	\N	\N
75089	SPECIFIC_DAY	3	0	2012-08-19	40199	59201	\N	\N
75090	SPECIFIC_DAY	3	7	2012-05-14	40199	59201	\N	\N
75091	SPECIFIC_DAY	3	7	2011-08-15	40199	59201	\N	\N
75092	SPECIFIC_DAY	3	7	2011-12-02	40199	59201	\N	\N
75093	SPECIFIC_DAY	3	7	2012-12-18	40199	59201	\N	\N
75094	SPECIFIC_DAY	3	0	2011-07-03	40199	59201	\N	\N
75095	SPECIFIC_DAY	3	7	2012-04-17	40199	59201	\N	\N
75096	SPECIFIC_DAY	3	7	2011-11-04	40199	59201	\N	\N
75097	SPECIFIC_DAY	3	7	2012-01-05	40199	59201	\N	\N
75098	SPECIFIC_DAY	3	0	2012-08-25	40199	59201	\N	\N
75099	SPECIFIC_DAY	3	7	2011-12-30	40199	59201	\N	\N
75100	SPECIFIC_DAY	3	7	2012-02-15	40199	59201	\N	\N
75101	SPECIFIC_DAY	3	7	2012-03-01	40199	59201	\N	\N
75102	SPECIFIC_DAY	3	7	2013-02-07	40199	59201	\N	\N
75103	SPECIFIC_DAY	3	7	2012-10-17	40199	59201	\N	\N
75104	SPECIFIC_DAY	3	0	2012-05-05	40199	59201	\N	\N
75105	SPECIFIC_DAY	3	7	2012-01-25	40199	59201	\N	\N
75106	SPECIFIC_DAY	3	7	2011-12-27	40199	59201	\N	\N
75107	SPECIFIC_DAY	3	0	2011-08-28	40199	59201	\N	\N
75108	SPECIFIC_DAY	3	7	2012-11-22	40199	59201	\N	\N
75109	SPECIFIC_DAY	3	7	2012-12-26	40199	59201	\N	\N
75110	SPECIFIC_DAY	3	7	2011-06-03	40199	59201	\N	\N
75111	SPECIFIC_DAY	3	7	2012-11-14	40199	59201	\N	\N
75112	SPECIFIC_DAY	3	7	2012-04-18	40199	59201	\N	\N
75113	SPECIFIC_DAY	3	7	2012-09-07	40199	59201	\N	\N
75114	SPECIFIC_DAY	3	7	2012-02-07	40199	59201	\N	\N
75115	SPECIFIC_DAY	3	0	2011-12-24	40199	59201	\N	\N
75116	SPECIFIC_DAY	3	0	2011-12-10	40199	59201	\N	\N
75117	SPECIFIC_DAY	3	7	2011-06-06	40199	59201	\N	\N
75118	SPECIFIC_DAY	3	7	2012-11-15	40199	59201	\N	\N
75119	SPECIFIC_DAY	3	7	2012-07-19	40199	59201	\N	\N
75120	SPECIFIC_DAY	3	7	2011-10-07	40199	59201	\N	\N
75121	SPECIFIC_DAY	3	7	2011-08-26	40199	59201	\N	\N
75122	SPECIFIC_DAY	3	7	2011-11-11	40199	59201	\N	\N
75123	SPECIFIC_DAY	3	7	2012-12-06	40199	59201	\N	\N
75124	SPECIFIC_DAY	3	7	2011-08-03	40199	59201	\N	\N
75125	SPECIFIC_DAY	3	7	2012-03-20	40199	59201	\N	\N
75126	SPECIFIC_DAY	3	7	2011-11-08	40199	59201	\N	\N
75127	SPECIFIC_DAY	3	7	2012-05-08	40199	59201	\N	\N
75128	SPECIFIC_DAY	3	7	2012-04-25	40199	59201	\N	\N
75129	SPECIFIC_DAY	3	7	2011-10-05	40199	59201	\N	\N
75130	SPECIFIC_DAY	3	7	2012-04-12	40199	59201	\N	\N
75131	SPECIFIC_DAY	3	7	2011-09-09	40199	59201	\N	\N
75132	SPECIFIC_DAY	3	0	2012-06-23	40199	59201	\N	\N
75133	SPECIFIC_DAY	3	7	2012-05-04	40199	59201	\N	\N
75134	SPECIFIC_DAY	3	7	2012-05-30	40199	59201	\N	\N
75135	SPECIFIC_DAY	3	7	2012-06-12	40199	59201	\N	\N
75136	SPECIFIC_DAY	3	7	2012-11-28	40199	59201	\N	\N
75137	SPECIFIC_DAY	3	7	2011-08-29	40199	59201	\N	\N
75138	SPECIFIC_DAY	3	0	2012-10-07	40199	59201	\N	\N
75139	SPECIFIC_DAY	3	0	2012-06-16	40199	59201	\N	\N
75140	SPECIFIC_DAY	3	7	2012-01-27	40199	59201	\N	\N
75141	SPECIFIC_DAY	3	0	2012-12-08	40199	59201	\N	\N
75142	SPECIFIC_DAY	3	7	2012-12-21	40199	59201	\N	\N
75143	SPECIFIC_DAY	3	7	2012-07-27	40199	59201	\N	\N
75144	SPECIFIC_DAY	3	0	2011-08-07	40199	59201	\N	\N
75145	SPECIFIC_DAY	3	7	2013-01-29	40199	59201	\N	\N
75146	SPECIFIC_DAY	3	7	2012-07-09	40199	59201	\N	\N
75147	SPECIFIC_DAY	3	0	2013-01-06	40199	59201	\N	\N
75148	SPECIFIC_DAY	3	0	2012-03-04	40199	59201	\N	\N
75149	SPECIFIC_DAY	3	0	2011-09-11	40199	59201	\N	\N
75150	SPECIFIC_DAY	3	7	2012-11-01	40199	59201	\N	\N
75151	SPECIFIC_DAY	3	7	2011-09-14	40199	59201	\N	\N
75152	SPECIFIC_DAY	3	7	2013-01-01	40199	59201	\N	\N
75153	SPECIFIC_DAY	3	7	2012-01-11	40199	59201	\N	\N
75154	SPECIFIC_DAY	3	0	2011-09-04	40199	59201	\N	\N
75155	SPECIFIC_DAY	3	7	2012-10-01	40199	59201	\N	\N
75156	SPECIFIC_DAY	3	7	2012-03-29	40199	59201	\N	\N
75157	SPECIFIC_DAY	3	0	2011-08-21	40199	59201	\N	\N
75158	SPECIFIC_DAY	3	7	2011-06-02	40199	59201	\N	\N
75159	SPECIFIC_DAY	3	0	2011-12-31	40199	59201	\N	\N
75160	SPECIFIC_DAY	3	0	2012-08-11	40199	59201	\N	\N
75161	SPECIFIC_DAY	3	0	2011-09-03	40199	59201	\N	\N
75162	SPECIFIC_DAY	3	7	2012-03-16	40199	59201	\N	\N
75163	SPECIFIC_DAY	3	7	2012-02-21	40199	59201	\N	\N
75164	SPECIFIC_DAY	3	7	2012-11-07	40199	59201	\N	\N
75165	SPECIFIC_DAY	3	0	2011-10-08	40199	59201	\N	\N
75166	SPECIFIC_DAY	3	7	2013-02-11	40199	59201	\N	\N
75167	SPECIFIC_DAY	3	7	2011-06-30	40199	59201	\N	\N
75168	SPECIFIC_DAY	3	7	2012-11-06	40199	59201	\N	\N
75169	SPECIFIC_DAY	3	7	2013-01-14	40199	59201	\N	\N
75170	SPECIFIC_DAY	3	0	2012-04-14	40199	59201	\N	\N
75171	SPECIFIC_DAY	3	7	2012-01-17	40199	59201	\N	\N
75172	SPECIFIC_DAY	3	7	2012-05-22	40199	59201	\N	\N
75173	SPECIFIC_DAY	3	7	2012-12-25	40199	59201	\N	\N
75174	SPECIFIC_DAY	3	0	2012-03-31	40199	59201	\N	\N
75175	SPECIFIC_DAY	3	7	2011-09-06	40199	59201	\N	\N
75176	SPECIFIC_DAY	3	7	2012-02-13	40199	59201	\N	\N
75177	SPECIFIC_DAY	3	7	2011-07-15	40199	59201	\N	\N
75178	SPECIFIC_DAY	3	7	2012-02-27	40199	59201	\N	\N
75179	SPECIFIC_DAY	3	7	2012-04-23	40199	59201	\N	\N
75180	SPECIFIC_DAY	3	7	2011-12-20	40199	59201	\N	\N
75181	SPECIFIC_DAY	3	7	2012-11-19	40199	59201	\N	\N
75182	SPECIFIC_DAY	3	0	2011-11-13	40199	59201	\N	\N
75183	SPECIFIC_DAY	3	7	2011-07-20	40199	59201	\N	\N
75184	SPECIFIC_DAY	3	7	2012-11-09	40199	59201	\N	\N
75185	SPECIFIC_DAY	3	7	2011-10-04	40199	59201	\N	\N
75186	SPECIFIC_DAY	3	0	2012-01-28	40199	59201	\N	\N
75187	SPECIFIC_DAY	3	7	2011-08-16	40199	59201	\N	\N
75188	SPECIFIC_DAY	3	0	2012-10-27	40199	59201	\N	\N
75189	SPECIFIC_DAY	3	7	2013-01-11	40199	59201	\N	\N
75190	SPECIFIC_DAY	3	7	2011-05-30	40199	59201	\N	\N
75191	SPECIFIC_DAY	3	7	2011-12-16	40199	59201	\N	\N
75192	SPECIFIC_DAY	3	7	2012-04-30	40199	59201	\N	\N
75193	SPECIFIC_DAY	3	7	2011-11-09	40199	59201	\N	\N
75194	SPECIFIC_DAY	3	7	2012-09-05	40199	59201	\N	\N
75195	SPECIFIC_DAY	3	7	2012-07-18	40199	59201	\N	\N
75196	SPECIFIC_DAY	3	7	2012-05-02	40199	59201	\N	\N
75197	SPECIFIC_DAY	3	7	2011-10-19	40199	59201	\N	\N
75198	SPECIFIC_DAY	3	0	2012-05-19	40199	59201	\N	\N
75199	SPECIFIC_DAY	3	7	2012-11-02	40199	59201	\N	\N
75200	SPECIFIC_DAY	3	0	2011-08-20	40199	59201	\N	\N
75201	SPECIFIC_DAY	3	7	2012-10-18	40199	59201	\N	\N
75202	SPECIFIC_DAY	3	7	2012-05-16	40199	59201	\N	\N
75203	SPECIFIC_DAY	3	0	2013-01-27	40199	59201	\N	\N
75204	SPECIFIC_DAY	3	0	2011-10-22	40199	59201	\N	\N
75205	SPECIFIC_DAY	3	7	2012-09-12	40199	59201	\N	\N
75206	SPECIFIC_DAY	3	7	2013-02-06	40199	59201	\N	\N
75207	SPECIFIC_DAY	3	7	2012-10-25	40199	59201	\N	\N
75208	SPECIFIC_DAY	3	0	2012-09-16	40199	59201	\N	\N
75209	SPECIFIC_DAY	3	7	2011-11-14	40199	59201	\N	\N
75210	SPECIFIC_DAY	3	7	2012-08-20	40199	59201	\N	\N
75211	SPECIFIC_DAY	3	7	2012-08-02	40199	59201	\N	\N
75212	SPECIFIC_DAY	3	7	2011-09-28	40199	59201	\N	\N
75213	SPECIFIC_DAY	3	7	2012-11-05	40199	59201	\N	\N
75214	SPECIFIC_DAY	3	7	2012-01-06	40199	59201	\N	\N
75215	SPECIFIC_DAY	3	7	2012-09-26	40199	59201	\N	\N
75216	SPECIFIC_DAY	3	7	2012-03-02	40199	59201	\N	\N
75217	SPECIFIC_DAY	3	7	2011-11-18	40199	59201	\N	\N
75218	SPECIFIC_DAY	3	7	2011-12-05	40199	59201	\N	\N
75219	SPECIFIC_DAY	3	7	2012-02-01	40199	59201	\N	\N
75220	SPECIFIC_DAY	3	0	2012-09-30	40199	59201	\N	\N
75221	SPECIFIC_DAY	3	0	2011-09-17	40199	59201	\N	\N
75222	SPECIFIC_DAY	3	7	2011-08-09	40199	59201	\N	\N
75223	SPECIFIC_DAY	3	7	2012-09-21	40199	59201	\N	\N
75224	SPECIFIC_DAY	3	7	2013-01-17	40199	59201	\N	\N
75225	SPECIFIC_DAY	3	7	2011-09-21	40199	59201	\N	\N
75226	SPECIFIC_DAY	3	7	2012-03-26	40199	59201	\N	\N
75227	SPECIFIC_DAY	3	7	2012-09-19	40199	59201	\N	\N
75228	SPECIFIC_DAY	3	0	2011-05-29	40199	59201	\N	\N
75229	SPECIFIC_DAY	3	0	2012-04-28	40199	59201	\N	\N
75230	SPECIFIC_DAY	3	7	2011-09-29	40199	59201	\N	\N
75231	SPECIFIC_DAY	3	7	2013-01-25	40199	59201	\N	\N
75232	SPECIFIC_DAY	3	0	2011-10-30	40199	59201	\N	\N
75233	SPECIFIC_DAY	3	7	2013-01-16	40199	59201	\N	\N
75234	SPECIFIC_DAY	3	7	2011-06-07	40199	59201	\N	\N
75235	SPECIFIC_DAY	3	7	2012-11-30	40199	59201	\N	\N
75236	SPECIFIC_DAY	3	7	2012-08-03	40199	59201	\N	\N
75237	SPECIFIC_DAY	3	7	2011-11-29	40199	59201	\N	\N
75238	SPECIFIC_DAY	3	7	2013-02-08	40199	59201	\N	\N
75239	SPECIFIC_DAY	3	7	2012-07-12	40199	59201	\N	\N
75240	SPECIFIC_DAY	3	0	2013-02-09	40199	59201	\N	\N
75241	SPECIFIC_DAY	3	0	2013-01-12	40199	59201	\N	\N
75242	SPECIFIC_DAY	3	0	2013-01-13	40199	59201	\N	\N
75243	SPECIFIC_DAY	3	7	2011-08-04	40199	59201	\N	\N
75244	SPECIFIC_DAY	3	7	2012-01-20	40199	59201	\N	\N
75245	SPECIFIC_DAY	3	7	2012-06-07	40199	59201	\N	\N
75246	SPECIFIC_DAY	3	0	2012-01-21	40199	59201	\N	\N
75247	SPECIFIC_DAY	3	7	2011-05-26	40199	59201	\N	\N
75248	SPECIFIC_DAY	3	7	2012-04-19	40199	59201	\N	\N
75249	SPECIFIC_DAY	3	0	2012-09-09	40199	59201	\N	\N
75250	SPECIFIC_DAY	3	7	2012-10-05	40199	59201	\N	\N
75251	SPECIFIC_DAY	3	0	2012-04-29	40199	59201	\N	\N
75252	SPECIFIC_DAY	3	7	2011-11-25	40199	59201	\N	\N
75253	SPECIFIC_DAY	3	7	2012-10-12	40199	59201	\N	\N
75254	SPECIFIC_DAY	3	7	2013-02-12	40199	59201	\N	\N
75255	SPECIFIC_DAY	3	7	2012-03-28	40199	59201	\N	\N
75256	SPECIFIC_DAY	3	7	2012-10-16	40199	59201	\N	\N
75257	SPECIFIC_DAY	3	0	2011-12-25	40199	59201	\N	\N
75258	SPECIFIC_DAY	3	0	2011-06-04	40199	59201	\N	\N
75259	SPECIFIC_DAY	3	7	2012-06-05	40199	59201	\N	\N
75260	SPECIFIC_DAY	3	7	2012-09-14	40199	59201	\N	\N
75261	SPECIFIC_DAY	3	7	2011-09-26	40199	59201	\N	\N
75262	SPECIFIC_DAY	3	7	2012-01-31	40199	59201	\N	\N
75263	SPECIFIC_DAY	3	7	2012-03-14	40199	59201	\N	\N
75264	SPECIFIC_DAY	3	7	2012-10-08	40199	59201	\N	\N
75265	SPECIFIC_DAY	3	7	2012-08-14	40199	59201	\N	\N
75266	SPECIFIC_DAY	3	0	2012-05-27	40199	59201	\N	\N
75267	SPECIFIC_DAY	3	7	2012-08-16	40199	59201	\N	\N
75268	SPECIFIC_DAY	3	7	2012-11-12	40199	59201	\N	\N
75269	SPECIFIC_DAY	3	7	2012-12-12	40199	59201	\N	\N
75270	SPECIFIC_DAY	3	7	2012-06-14	40199	59201	\N	\N
75271	SPECIFIC_DAY	3	0	2012-07-21	40199	59201	\N	\N
75272	SPECIFIC_DAY	3	0	2011-10-29	40199	59201	\N	\N
75273	SPECIFIC_DAY	3	0	2012-02-18	40199	59201	\N	\N
75274	SPECIFIC_DAY	3	7	2011-12-26	40199	59201	\N	\N
75275	SPECIFIC_DAY	3	7	2012-10-15	40199	59201	\N	\N
75276	SPECIFIC_DAY	3	7	2012-02-28	40199	59201	\N	\N
75277	SPECIFIC_DAY	3	7	2012-05-31	40199	59201	\N	\N
75278	SPECIFIC_DAY	3	0	2012-07-14	40199	59201	\N	\N
75279	SPECIFIC_DAY	3	7	2011-07-21	40199	59201	\N	\N
75280	SPECIFIC_DAY	3	7	2011-08-10	40199	59201	\N	\N
75281	SPECIFIC_DAY	3	7	2011-10-24	40199	59201	\N	\N
75282	SPECIFIC_DAY	3	7	2011-10-06	40199	59201	\N	\N
75283	SPECIFIC_DAY	3	7	2012-03-22	40199	59201	\N	\N
75284	SPECIFIC_DAY	3	7	2012-07-13	40199	59201	\N	\N
75285	SPECIFIC_DAY	3	7	2012-12-28	40199	59201	\N	\N
75286	SPECIFIC_DAY	3	7	2012-08-23	40199	59201	\N	\N
75287	SPECIFIC_DAY	3	7	2011-07-07	40199	59201	\N	\N
75288	SPECIFIC_DAY	3	7	2012-05-21	40199	59201	\N	\N
75289	SPECIFIC_DAY	3	7	2012-05-25	40199	59201	\N	\N
75290	SPECIFIC_DAY	3	7	2011-07-29	40199	59201	\N	\N
75291	SPECIFIC_DAY	3	7	2012-04-20	40199	59201	\N	\N
75292	SPECIFIC_DAY	3	0	2011-10-16	40199	59201	\N	\N
75293	SPECIFIC_DAY	3	7	2012-08-01	40199	59201	\N	\N
75294	SPECIFIC_DAY	3	7	2012-06-08	40199	59201	\N	\N
75295	SPECIFIC_DAY	3	7	2013-01-04	40199	59201	\N	\N
75296	SPECIFIC_DAY	3	7	2012-12-24	40199	59201	\N	\N
75297	SPECIFIC_DAY	3	7	2011-10-12	40199	59201	\N	\N
75298	SPECIFIC_DAY	3	7	2012-08-30	40199	59201	\N	\N
75299	SPECIFIC_DAY	3	0	2011-09-24	40199	59201	\N	\N
75300	SPECIFIC_DAY	3	7	2011-09-13	40199	59201	\N	\N
75301	SPECIFIC_DAY	3	7	2012-02-29	40199	59201	\N	\N
75302	SPECIFIC_DAY	3	7	2013-01-28	40199	59201	\N	\N
75303	SPECIFIC_DAY	3	7	2011-07-28	40199	59201	\N	\N
75304	SPECIFIC_DAY	3	7	2011-10-10	40199	59201	\N	\N
75305	SPECIFIC_DAY	3	0	2013-02-02	40199	59201	\N	\N
75306	SPECIFIC_DAY	3	0	2011-08-06	40199	59201	\N	\N
75307	SPECIFIC_DAY	3	7	2011-07-04	40199	59201	\N	\N
75308	SPECIFIC_DAY	3	7	2012-02-02	40199	59201	\N	\N
75309	SPECIFIC_DAY	3	7	2012-01-23	40199	59201	\N	\N
75310	SPECIFIC_DAY	3	0	2012-10-21	40199	59201	\N	\N
75311	SPECIFIC_DAY	3	0	2012-06-17	40199	59201	\N	\N
75312	SPECIFIC_DAY	3	0	2011-12-18	40199	59201	\N	\N
75313	SPECIFIC_DAY	3	0	2012-12-01	40199	59201	\N	\N
75314	SPECIFIC_DAY	3	7	2011-11-07	40199	59201	\N	\N
75315	SPECIFIC_DAY	3	0	2013-01-26	40199	59201	\N	\N
75316	SPECIFIC_DAY	3	7	2011-08-05	40199	59201	\N	\N
75317	SPECIFIC_DAY	3	0	2012-02-19	40199	59201	\N	\N
75318	SPECIFIC_DAY	3	7	2011-06-01	40199	59201	\N	\N
75319	SPECIFIC_DAY	3	7	2012-05-23	40199	59201	\N	\N
75320	SPECIFIC_DAY	3	7	2012-12-31	40199	59201	\N	\N
75321	SPECIFIC_DAY	3	0	2012-07-22	40199	59201	\N	\N
75322	SPECIFIC_DAY	3	0	2012-12-02	40199	59201	\N	\N
75323	SPECIFIC_DAY	3	7	2011-11-17	40199	59201	\N	\N
75324	SPECIFIC_DAY	3	7	2012-09-06	40199	59201	\N	\N
75325	SPECIFIC_DAY	3	7	2012-07-20	40199	59201	\N	\N
75326	SPECIFIC_DAY	3	7	2012-01-03	40199	59201	\N	\N
75327	SPECIFIC_DAY	3	7	2012-02-03	40199	59201	\N	\N
75328	SPECIFIC_DAY	3	7	2011-10-13	40199	59201	\N	\N
75329	SPECIFIC_DAY	3	7	2011-05-27	40199	59201	\N	\N
75330	SPECIFIC_DAY	3	7	2011-08-30	40199	59201	\N	\N
75331	SPECIFIC_DAY	3	0	2012-07-29	40199	59201	\N	\N
75332	SPECIFIC_DAY	3	7	2011-11-22	40199	59201	\N	\N
75333	SPECIFIC_DAY	3	7	2012-06-21	40199	59201	\N	\N
75334	SPECIFIC_DAY	3	7	2012-12-04	40199	59201	\N	\N
75335	SPECIFIC_DAY	3	0	2012-05-12	40199	59201	\N	\N
75336	SPECIFIC_DAY	3	0	2011-12-03	40199	59201	\N	\N
75337	SPECIFIC_DAY	3	7	2012-10-26	40199	59201	\N	\N
75338	SPECIFIC_DAY	3	7	2012-02-23	40199	59201	\N	\N
75339	SPECIFIC_DAY	3	0	2011-10-09	40199	59201	\N	\N
75340	SPECIFIC_DAY	3	7	2012-06-25	40199	59201	\N	\N
75341	SPECIFIC_DAY	3	7	2012-04-10	40199	59201	\N	\N
75342	SPECIFIC_DAY	3	0	2011-11-26	40199	59201	\N	\N
75343	SPECIFIC_DAY	3	0	2012-12-29	40199	59201	\N	\N
75344	SPECIFIC_DAY	3	7	2011-06-16	40199	59201	\N	\N
75345	SPECIFIC_DAY	3	7	2012-07-25	40199	59201	\N	\N
75346	SPECIFIC_DAY	3	7	2012-09-13	40199	59201	\N	\N
75347	SPECIFIC_DAY	3	7	2012-05-29	40199	59201	\N	\N
75348	SPECIFIC_DAY	3	7	2012-07-26	40199	59201	\N	\N
75349	SPECIFIC_DAY	3	0	2011-07-31	40199	59201	\N	\N
75350	SPECIFIC_DAY	3	7	2012-10-22	40199	59201	\N	\N
75351	SPECIFIC_DAY	3	0	2012-07-28	40199	59201	\N	\N
75352	SPECIFIC_DAY	3	0	2012-11-24	40199	59201	\N	\N
75353	SPECIFIC_DAY	3	7	2013-01-21	40199	59201	\N	\N
75354	SPECIFIC_DAY	3	7	2012-05-01	40199	59201	\N	\N
75355	SPECIFIC_DAY	3	7	2012-03-12	40199	59201	\N	\N
75356	SPECIFIC_DAY	3	7	2011-12-19	40199	59201	\N	\N
75357	SPECIFIC_DAY	3	7	2011-10-31	40199	59201	\N	\N
75358	SPECIFIC_DAY	3	7	2011-06-27	40199	59201	\N	\N
75359	SPECIFIC_DAY	3	7	2012-06-27	40199	59201	\N	\N
75360	SPECIFIC_DAY	3	0	2011-07-24	40199	59201	\N	\N
75361	SPECIFIC_DAY	3	7	2011-06-20	40199	59201	\N	\N
75362	SPECIFIC_DAY	3	0	2011-11-27	40199	59201	\N	\N
75363	SPECIFIC_DAY	3	7	2012-08-08	40199	59201	\N	\N
75364	SPECIFIC_DAY	3	0	2012-07-07	40199	59201	\N	\N
75365	SPECIFIC_DAY	3	0	2012-04-01	40199	59201	\N	\N
75366	SPECIFIC_DAY	3	7	2012-03-05	40199	59201	\N	\N
75367	SPECIFIC_DAY	3	7	2013-01-10	40199	59201	\N	\N
75368	SPECIFIC_DAY	3	7	2011-11-28	40199	59201	\N	\N
75369	SPECIFIC_DAY	3	7	2012-01-16	40199	59201	\N	\N
75370	SPECIFIC_DAY	3	7	2012-08-22	40199	59201	\N	\N
75371	SPECIFIC_DAY	3	7	2011-12-01	40199	59201	\N	\N
75372	SPECIFIC_DAY	3	7	2011-11-01	40199	59201	\N	\N
75373	SPECIFIC_DAY	3	0	2012-11-17	40199	59201	\N	\N
75374	SPECIFIC_DAY	3	7	2011-11-02	40199	59201	\N	\N
75375	SPECIFIC_DAY	3	7	2011-10-28	40199	59201	\N	\N
75376	SPECIFIC_DAY	3	0	2011-06-11	40199	59201	\N	\N
75377	SPECIFIC_DAY	3	7	2012-08-15	40199	59201	\N	\N
75378	SPECIFIC_DAY	3	0	2012-09-15	40199	59201	\N	\N
75379	SPECIFIC_DAY	3	0	2012-02-25	40199	59201	\N	\N
75380	SPECIFIC_DAY	3	7	2012-10-19	40199	59201	\N	\N
75381	SPECIFIC_DAY	3	7	2011-07-18	40199	59201	\N	\N
75382	SPECIFIC_DAY	3	7	2012-08-21	40199	59201	\N	\N
75383	SPECIFIC_DAY	3	7	2011-07-12	40199	59201	\N	\N
75384	SPECIFIC_DAY	3	7	2011-09-01	40199	59201	\N	\N
75385	SPECIFIC_DAY	3	7	2012-11-16	40199	59201	\N	\N
75386	SPECIFIC_DAY	3	7	2011-08-31	40199	59201	\N	\N
75387	SPECIFIC_DAY	3	7	2012-05-10	40199	59201	\N	\N
75388	SPECIFIC_DAY	3	0	2011-07-23	40199	59201	\N	\N
75389	SPECIFIC_DAY	3	7	2012-07-03	40199	59201	\N	\N
75390	SPECIFIC_DAY	3	7	2011-12-12	40199	59201	\N	\N
75391	SPECIFIC_DAY	3	0	2012-12-23	40199	59201	\N	\N
75392	SPECIFIC_DAY	3	0	2012-03-11	40199	59201	\N	\N
75393	SPECIFIC_DAY	3	7	2013-02-05	40199	59201	\N	\N
75394	SPECIFIC_DAY	3	7	2012-12-14	40199	59201	\N	\N
75395	SPECIFIC_DAY	3	7	2011-08-08	40199	59201	\N	\N
75396	SPECIFIC_DAY	3	7	2012-12-13	40199	59201	\N	\N
75397	SPECIFIC_DAY	3	7	2011-08-01	40199	59201	\N	\N
75398	SPECIFIC_DAY	3	7	2011-09-15	40199	59201	\N	\N
75399	SPECIFIC_DAY	3	7	2013-01-23	40199	59201	\N	\N
75400	SPECIFIC_DAY	3	7	2012-12-05	40199	59201	\N	\N
75401	SPECIFIC_DAY	3	7	2012-02-14	40199	59201	\N	\N
75402	SPECIFIC_DAY	3	7	2012-05-07	40199	59201	\N	\N
75403	SPECIFIC_DAY	3	7	2011-06-13	40199	59201	\N	\N
75404	SPECIFIC_DAY	3	7	2011-11-10	40199	59201	\N	\N
75405	SPECIFIC_DAY	3	7	2012-02-17	40199	59201	\N	\N
75406	SPECIFIC_DAY	3	7	2012-06-26	40199	59201	\N	\N
75407	SPECIFIC_DAY	3	7	2012-01-02	40199	59201	\N	\N
75408	SPECIFIC_DAY	3	0	2013-01-05	40199	59201	\N	\N
75409	SPECIFIC_DAY	3	7	2012-12-11	40199	59201	\N	\N
75410	SPECIFIC_DAY	3	7	2012-07-06	40199	59201	\N	\N
75411	SPECIFIC_DAY	3	0	2013-02-10	40199	59201	\N	\N
75412	SPECIFIC_DAY	3	7	2012-02-09	40199	59201	\N	\N
75413	SPECIFIC_DAY	3	7	2011-06-08	40199	59201	\N	\N
75414	SPECIFIC_DAY	3	0	2011-09-10	40199	59201	\N	\N
75415	SPECIFIC_DAY	3	7	2011-07-08	40199	59201	\N	\N
75416	SPECIFIC_DAY	3	0	2012-05-13	40199	59201	\N	\N
75417	SPECIFIC_DAY	3	7	2012-04-16	40199	59201	\N	\N
75418	SPECIFIC_DAY	3	7	2012-06-28	40199	59201	\N	\N
75419	SPECIFIC_DAY	3	7	2012-09-11	40199	59201	\N	\N
75420	SPECIFIC_DAY	3	7	2011-10-26	40199	59201	\N	\N
75421	SPECIFIC_DAY	3	7	2011-11-21	40199	59201	\N	\N
75422	SPECIFIC_DAY	3	7	2012-10-10	40199	59201	\N	\N
75423	SPECIFIC_DAY	3	0	2012-12-16	40199	59201	\N	\N
75424	SPECIFIC_DAY	3	0	2012-02-26	40199	59201	\N	\N
75425	SPECIFIC_DAY	3	7	2011-09-30	40199	59201	\N	\N
75426	SPECIFIC_DAY	3	7	2011-08-18	40199	59201	\N	\N
75427	SPECIFIC_DAY	3	0	2011-06-18	40199	59201	\N	\N
75428	SPECIFIC_DAY	3	7	2012-07-24	40199	59201	\N	\N
75429	SPECIFIC_DAY	3	0	2012-06-02	40199	59201	\N	\N
75430	SPECIFIC_DAY	3	0	2012-01-14	40199	59201	\N	\N
75431	SPECIFIC_DAY	3	7	2012-08-17	40199	59201	\N	\N
75432	SPECIFIC_DAY	3	7	2011-09-08	40199	59201	\N	\N
75433	SPECIFIC_DAY	3	0	2012-02-04	40199	59201	\N	\N
75434	SPECIFIC_DAY	3	7	2012-07-10	40199	59201	\N	\N
75435	SPECIFIC_DAY	3	0	2012-02-12	40199	59201	\N	\N
75436	SPECIFIC_DAY	3	7	2011-10-14	40199	59201	\N	\N
75437	SPECIFIC_DAY	3	7	2011-06-23	40199	59201	\N	\N
75438	SPECIFIC_DAY	3	7	2012-06-11	40199	59201	\N	\N
75439	SPECIFIC_DAY	3	0	2011-07-16	40199	59201	\N	\N
75440	SPECIFIC_DAY	3	0	2012-01-15	40199	59201	\N	\N
75441	SPECIFIC_DAY	3	7	2011-12-07	40199	59201	\N	\N
75442	SPECIFIC_DAY	3	7	2012-08-06	40199	59201	\N	\N
75443	SPECIFIC_DAY	3	0	2012-11-03	40199	59201	\N	\N
75444	SPECIFIC_DAY	3	7	2012-08-24	40199	59201	\N	\N
75445	SPECIFIC_DAY	3	7	2012-10-24	40199	59201	\N	\N
75446	SPECIFIC_DAY	3	7	2012-02-20	40199	59201	\N	\N
75447	SPECIFIC_DAY	3	7	2012-03-08	40199	59201	\N	\N
75448	SPECIFIC_DAY	3	7	2011-08-17	40199	59201	\N	\N
75449	SPECIFIC_DAY	3	0	2012-09-08	40199	59201	\N	\N
75450	SPECIFIC_DAY	3	0	2012-11-04	40199	59201	\N	\N
75451	SPECIFIC_DAY	3	7	2011-09-02	40199	59201	\N	\N
75452	SPECIFIC_DAY	3	7	2011-10-17	40199	59201	\N	\N
75453	SPECIFIC_DAY	3	7	2011-07-26	40199	59201	\N	\N
75454	SPECIFIC_DAY	3	7	2012-06-04	40199	59201	\N	\N
75455	SPECIFIC_DAY	3	7	2012-12-27	40199	59201	\N	\N
75456	SPECIFIC_DAY	3	7	2011-07-14	40199	59201	\N	\N
75457	SPECIFIC_DAY	3	7	2012-06-19	40199	59201	\N	\N
75458	SPECIFIC_DAY	3	7	2012-01-18	40199	59201	\N	\N
75459	SPECIFIC_DAY	3	0	2012-10-20	40199	59201	\N	\N
75460	SPECIFIC_DAY	3	7	2012-10-31	40199	59201	\N	\N
75461	SPECIFIC_DAY	3	7	2012-09-24	40199	59201	\N	\N
75462	SPECIFIC_DAY	3	0	2012-05-06	40199	59201	\N	\N
75463	SPECIFIC_DAY	3	7	2011-07-01	40199	59201	\N	\N
75464	SPECIFIC_DAY	3	0	2011-07-10	40199	59201	\N	\N
75465	SPECIFIC_DAY	3	7	2011-06-24	40199	59201	\N	\N
75466	SPECIFIC_DAY	3	0	2012-08-26	40199	59201	\N	\N
75467	SPECIFIC_DAY	3	7	2011-12-13	40199	59201	\N	\N
75468	SPECIFIC_DAY	3	7	2011-10-18	40199	59201	\N	\N
75469	SPECIFIC_DAY	3	0	2012-09-23	40199	59201	\N	\N
75470	SPECIFIC_DAY	3	0	2011-12-17	40199	59201	\N	\N
75471	SPECIFIC_DAY	3	7	2011-08-02	40199	59201	\N	\N
75472	SPECIFIC_DAY	3	7	2011-09-20	40199	59201	\N	\N
75473	SPECIFIC_DAY	3	7	2011-10-03	40199	59201	\N	\N
75474	SPECIFIC_DAY	3	7	2011-06-28	40199	59201	\N	\N
75475	SPECIFIC_DAY	3	0	2012-01-29	40199	59201	\N	\N
75476	SPECIFIC_DAY	3	0	2012-05-20	40199	59201	\N	\N
75477	SPECIFIC_DAY	3	7	2012-06-20	40199	59201	\N	\N
75478	SPECIFIC_DAY	3	7	2012-12-10	40199	59201	\N	\N
75479	SPECIFIC_DAY	3	7	2012-01-12	40199	59201	\N	\N
75480	SPECIFIC_DAY	3	7	2011-08-22	40199	59201	\N	\N
75481	SPECIFIC_DAY	3	7	2012-02-08	40199	59201	\N	\N
75482	SPECIFIC_DAY	3	7	2012-01-26	40199	59201	\N	\N
75483	SPECIFIC_DAY	3	7	2011-11-30	40199	59201	\N	\N
75484	SPECIFIC_DAY	3	0	2012-09-22	40199	59201	\N	\N
75485	SPECIFIC_DAY	3	7	2012-12-17	40199	59201	\N	\N
75486	SPECIFIC_DAY	3	7	2011-07-13	40199	59201	\N	\N
75487	SPECIFIC_DAY	3	7	2012-08-27	40199	59201	\N	\N
75488	SPECIFIC_DAY	3	7	2012-07-17	40199	59201	\N	\N
75489	SPECIFIC_DAY	3	7	2012-07-30	40199	59201	\N	\N
75490	SPECIFIC_DAY	3	7	2012-08-13	40199	59201	\N	\N
75491	SPECIFIC_DAY	3	0	2012-09-02	40199	59201	\N	\N
75492	SPECIFIC_DAY	3	0	2012-12-22	40199	59201	\N	\N
75493	SPECIFIC_DAY	3	7	2012-08-09	40199	59201	\N	\N
75494	SPECIFIC_DAY	3	7	2012-01-09	40199	59201	\N	\N
75495	SPECIFIC_DAY	3	0	2012-11-18	40199	59201	\N	\N
75496	SPECIFIC_DAY	3	7	2012-12-07	40199	59201	\N	\N
75497	SPECIFIC_DAY	3	7	2011-12-23	40199	59201	\N	\N
75498	SPECIFIC_DAY	3	7	2012-11-20	40199	59201	\N	\N
75499	SPECIFIC_DAY	3	7	2012-05-11	40199	59201	\N	\N
75500	SPECIFIC_DAY	3	7	2013-01-22	40199	59201	\N	\N
75501	SPECIFIC_DAY	3	0	2012-03-25	40199	59201	\N	\N
75502	SPECIFIC_DAY	3	7	2012-10-23	40199	59201	\N	\N
75503	SPECIFIC_DAY	3	7	2012-09-28	40199	59201	\N	\N
75504	SPECIFIC_DAY	3	7	2011-11-23	40199	59201	\N	\N
75505	SPECIFIC_DAY	3	7	2011-09-22	40199	59201	\N	\N
75506	SPECIFIC_DAY	3	7	2011-09-27	40199	59201	\N	\N
75507	SPECIFIC_DAY	3	0	2012-08-18	40199	59201	\N	\N
75508	SPECIFIC_DAY	3	7	2011-06-09	40199	59201	\N	\N
75509	SPECIFIC_DAY	3	0	2012-04-07	40199	59201	\N	\N
75510	SPECIFIC_DAY	3	0	2012-04-15	40199	59201	\N	\N
75511	SPECIFIC_DAY	3	7	2012-08-29	40199	59201	\N	\N
75512	SPECIFIC_DAY	3	7	2012-04-04	40199	59201	\N	\N
75513	SPECIFIC_DAY	3	7	2012-04-24	40199	59201	\N	\N
75514	SPECIFIC_DAY	3	7	2012-10-02	40199	59201	\N	\N
75515	SPECIFIC_DAY	3	0	2011-05-28	40199	59201	\N	\N
75516	SPECIFIC_DAY	3	7	2011-10-21	40199	59201	\N	\N
75517	SPECIFIC_DAY	3	7	2011-07-11	40199	59201	\N	\N
75518	SPECIFIC_DAY	3	7	2011-11-15	40199	59201	\N	\N
75519	SPECIFIC_DAY	3	0	2011-06-26	40199	59201	\N	\N
75520	SPECIFIC_DAY	3	0	2012-12-09	40199	59201	\N	\N
75521	SPECIFIC_DAY	3	7	2011-10-25	40199	59201	\N	\N
75522	SPECIFIC_DAY	3	0	2012-09-29	40199	59201	\N	\N
75523	SPECIFIC_DAY	3	7	2011-12-29	40199	59201	\N	\N
75524	SPECIFIC_DAY	3	7	2012-04-11	40199	59201	\N	\N
75525	SPECIFIC_DAY	3	0	2012-08-04	40199	59201	\N	\N
75526	SPECIFIC_DAY	3	0	2011-10-15	40199	59201	\N	\N
75527	SPECIFIC_DAY	3	7	2011-08-12	40199	59201	\N	\N
75528	SPECIFIC_DAY	3	7	2012-10-04	40199	59201	\N	\N
75529	SPECIFIC_DAY	3	7	2011-06-14	40199	59201	\N	\N
75530	SPECIFIC_DAY	3	7	2012-07-11	40199	59201	\N	\N
75531	SPECIFIC_DAY	3	7	2011-10-20	40199	59201	\N	\N
75532	SPECIFIC_DAY	3	7	2011-10-11	40199	59201	\N	\N
75533	SPECIFIC_DAY	3	7	2012-09-10	40199	59201	\N	\N
75534	SPECIFIC_DAY	3	7	2012-04-02	40199	59201	\N	\N
75535	SPECIFIC_DAY	3	0	2011-12-04	40199	59201	\N	\N
75536	SPECIFIC_DAY	3	0	2011-11-12	40199	59201	\N	\N
75537	SPECIFIC_DAY	3	0	2012-11-25	40199	59201	\N	\N
75538	SPECIFIC_DAY	3	7	2012-09-20	40199	59201	\N	\N
75539	SPECIFIC_DAY	3	7	2012-05-17	40199	59201	\N	\N
75540	SPECIFIC_DAY	3	7	2013-01-08	40199	59201	\N	\N
75541	SPECIFIC_DAY	3	7	2012-10-03	40199	59201	\N	\N
75542	SPECIFIC_DAY	3	7	2012-03-30	40199	59201	\N	\N
75543	SPECIFIC_DAY	3	0	2012-10-14	40199	59201	\N	\N
75544	SPECIFIC_DAY	3	7	2011-12-08	40199	59201	\N	\N
75545	SPECIFIC_DAY	3	7	2013-01-24	40199	59201	\N	\N
75546	SPECIFIC_DAY	3	7	2012-10-30	40199	59201	\N	\N
75547	SPECIFIC_DAY	3	7	2012-11-27	40199	59201	\N	\N
75548	SPECIFIC_DAY	3	7	2011-08-24	40199	59201	\N	\N
75549	SPECIFIC_DAY	3	7	2011-09-19	40199	59201	\N	\N
75550	SPECIFIC_DAY	3	0	2011-11-20	40199	59201	\N	\N
75551	SPECIFIC_DAY	3	0	2012-03-24	40199	59201	\N	\N
75552	SPECIFIC_DAY	3	7	2011-10-27	40199	59201	\N	\N
75553	SPECIFIC_DAY	3	0	2011-10-02	40199	59201	\N	\N
75554	SPECIFIC_DAY	3	0	2011-07-17	40199	59201	\N	\N
75555	SPECIFIC_DAY	3	0	2011-07-09	40199	59201	\N	\N
75556	SPECIFIC_DAY	3	7	2013-01-07	40199	59201	\N	\N
75557	SPECIFIC_DAY	3	0	2011-11-05	40199	59201	\N	\N
75558	SPECIFIC_DAY	3	7	2012-05-24	40199	59201	\N	\N
75559	SPECIFIC_DAY	3	7	2012-10-29	40199	59201	\N	\N
75560	SPECIFIC_DAY	3	7	2012-09-27	40199	59201	\N	\N
75561	SPECIFIC_DAY	3	7	2012-06-22	40199	59201	\N	\N
75562	SPECIFIC_DAY	3	7	2012-03-19	40199	59201	\N	\N
75563	SPECIFIC_DAY	3	7	2012-02-10	40199	59201	\N	\N
75564	SPECIFIC_DAY	3	7	2012-11-08	40199	59201	\N	\N
75565	SPECIFIC_DAY	3	7	2012-07-31	40199	59201	\N	\N
75566	SPECIFIC_DAY	3	0	2013-01-19	40199	59201	\N	\N
75567	SPECIFIC_DAY	3	0	2012-04-22	40199	59201	\N	\N
75568	SPECIFIC_DAY	3	7	2013-01-31	40199	59201	\N	\N
75569	SPECIFIC_DAY	3	7	2011-08-19	40199	59201	\N	\N
75570	SPECIFIC_DAY	3	0	2012-02-05	40199	59201	\N	\N
75571	SPECIFIC_DAY	3	0	2012-01-22	40199	59201	\N	\N
75572	SPECIFIC_DAY	3	0	2011-06-05	40199	59201	\N	\N
75573	SPECIFIC_DAY	3	0	2012-08-12	40199	59201	\N	\N
75574	SPECIFIC_DAY	3	0	2012-10-28	40199	59201	\N	\N
75575	SPECIFIC_DAY	3	0	2012-11-10	40199	59201	\N	\N
75576	SPECIFIC_DAY	3	7	2012-03-23	40199	59201	\N	\N
75577	SPECIFIC_DAY	3	7	2011-06-10	40199	59201	\N	\N
75578	SPECIFIC_DAY	3	7	2012-04-09	40199	59201	\N	\N
75579	SPECIFIC_DAY	3	7	2012-11-23	40199	59201	\N	\N
75580	SPECIFIC_DAY	3	7	2012-01-19	40199	59201	\N	\N
75581	SPECIFIC_DAY	3	7	2013-01-15	40199	59201	\N	\N
75582	SPECIFIC_DAY	3	7	2011-09-05	40199	59201	\N	\N
75583	SPECIFIC_DAY	3	0	2011-08-14	40199	59201	\N	\N
75584	SPECIFIC_DAY	3	0	2011-07-02	40199	59201	\N	\N
75585	SPECIFIC_DAY	3	7	2011-07-19	40199	59201	\N	\N
75586	SPECIFIC_DAY	3	7	2012-05-15	40199	59201	\N	\N
75587	SPECIFIC_DAY	3	7	2011-07-05	40199	59201	\N	\N
75588	SPECIFIC_DAY	3	0	2012-03-18	40199	59201	\N	\N
75589	SPECIFIC_DAY	3	7	2012-06-01	40199	59201	\N	\N
75590	SPECIFIC_DAY	3	7	2013-01-18	40199	59201	\N	\N
75591	SPECIFIC_DAY	3	7	2012-03-13	40199	59201	\N	\N
75592	SPECIFIC_DAY	3	7	2012-11-21	40199	59201	\N	\N
75593	SPECIFIC_DAY	3	7	2011-06-29	40199	59201	\N	\N
75594	SPECIFIC_DAY	3	7	2012-03-15	40199	59201	\N	\N
75595	SPECIFIC_DAY	3	0	2011-10-23	40199	59201	\N	\N
75596	SPECIFIC_DAY	3	0	2012-01-08	40199	59201	\N	\N
75597	SPECIFIC_DAY	3	7	2012-03-07	40199	59201	\N	\N
75598	SPECIFIC_DAY	3	0	2011-10-01	40199	59201	\N	\N
75599	SPECIFIC_DAY	3	7	2012-06-18	40199	59201	\N	\N
75600	SPECIFIC_DAY	3	7	2011-11-24	40199	59201	\N	\N
75601	SPECIFIC_DAY	3	0	2012-03-17	40199	59201	\N	\N
75602	SPECIFIC_DAY	3	7	2011-09-16	40199	59201	\N	\N
75603	SPECIFIC_DAY	3	7	2012-06-15	40199	59201	\N	\N
75604	SPECIFIC_DAY	3	0	2011-08-13	40199	59201	\N	\N
75605	SPECIFIC_DAY	3	0	2011-06-19	40199	59201	\N	\N
75606	SPECIFIC_DAY	3	0	2012-07-08	40199	59201	\N	\N
75607	SPECIFIC_DAY	3	7	2011-06-21	40199	59201	\N	\N
75608	SPECIFIC_DAY	3	7	2012-11-13	40199	59201	\N	\N
75609	SPECIFIC_DAY	3	7	2012-12-03	40199	59201	\N	\N
75610	SPECIFIC_DAY	3	7	2013-01-30	40199	59201	\N	\N
75611	SPECIFIC_DAY	3	7	2011-11-03	40199	59201	\N	\N
75612	SPECIFIC_DAY	3	7	2011-12-15	40199	59201	\N	\N
75613	SPECIFIC_DAY	3	7	2013-01-02	40199	59201	\N	\N
75614	SPECIFIC_DAY	3	7	2012-07-16	40199	59201	\N	\N
75615	SPECIFIC_DAY	3	7	2011-12-21	40199	59201	\N	\N
75616	SPECIFIC_DAY	3	7	2011-06-17	40199	59201	\N	\N
75617	SPECIFIC_DAY	3	7	2012-01-30	40199	59201	\N	\N
75618	SPECIFIC_DAY	3	0	2012-04-08	40199	59201	\N	\N
75619	SPECIFIC_DAY	3	7	2012-09-03	40199	59201	\N	\N
75620	SPECIFIC_DAY	3	0	2012-06-30	40199	59201	\N	\N
75621	SPECIFIC_DAY	3	7	2011-08-23	40199	59201	\N	\N
75622	SPECIFIC_DAY	3	7	2012-03-27	40199	59201	\N	\N
75623	SPECIFIC_DAY	3	7	2012-04-27	40199	59201	\N	\N
75624	SPECIFIC_DAY	3	7	2012-06-06	40199	59201	\N	\N
75625	SPECIFIC_DAY	3	7	2012-10-11	40199	59201	\N	\N
75626	SPECIFIC_DAY	3	0	2011-08-27	40199	59201	\N	\N
75627	SPECIFIC_DAY	3	7	2012-04-05	40199	59201	\N	\N
75628	SPECIFIC_DAY	3	7	2012-05-18	40199	59201	\N	\N
75629	SPECIFIC_DAY	3	0	2011-06-12	40199	59201	\N	\N
75630	SPECIFIC_DAY	3	7	2013-01-09	40199	59201	\N	\N
75631	SPECIFIC_DAY	3	7	2012-02-24	40199	59201	\N	\N
75632	SPECIFIC_DAY	3	7	2012-01-10	40199	59201	\N	\N
75633	SPECIFIC_DAY	3	7	2011-09-23	40199	59201	\N	\N
75634	SPECIFIC_DAY	3	0	2011-09-18	40199	59201	\N	\N
75635	SPECIFIC_DAY	3	7	2012-03-06	40199	59201	\N	\N
75636	SPECIFIC_DAY	3	7	2011-09-12	40199	59201	\N	\N
75637	SPECIFIC_DAY	3	0	2012-10-06	40199	59201	\N	\N
75638	SPECIFIC_DAY	3	0	2012-11-11	40199	59201	\N	\N
75639	SPECIFIC_DAY	3	0	2012-04-21	40199	59201	\N	\N
75640	SPECIFIC_DAY	3	0	2012-06-03	40199	59201	\N	\N
75641	SPECIFIC_DAY	3	0	2012-09-01	40199	59201	\N	\N
75642	SPECIFIC_DAY	3	7	2012-07-23	40199	59201	\N	\N
75643	SPECIFIC_DAY	3	7	2013-02-04	40199	59201	\N	\N
75644	SPECIFIC_DAY	3	7	2012-05-09	40199	59201	\N	\N
75645	SPECIFIC_DAY	3	7	2012-11-29	40199	59201	\N	\N
75646	SPECIFIC_DAY	3	7	2011-12-09	40199	59201	\N	\N
75647	SPECIFIC_DAY	3	7	2012-08-31	40199	59201	\N	\N
75648	SPECIFIC_DAY	3	0	2012-10-13	40199	59201	\N	\N
75649	SPECIFIC_DAY	3	7	2012-06-29	40199	59201	\N	\N
75650	SPECIFIC_DAY	3	7	2012-04-06	40199	59201	\N	\N
75651	SPECIFIC_DAY	3	0	2013-01-20	40199	59201	\N	\N
75652	SPECIFIC_DAY	3	7	2012-11-26	40199	59201	\N	\N
75653	SPECIFIC_DAY	3	7	2013-02-13	40199	59201	\N	\N
75654	SPECIFIC_DAY	3	0	2011-09-25	40199	59201	\N	\N
75655	SPECIFIC_DAY	3	0	2012-06-10	40199	59201	\N	\N
75656	SPECIFIC_DAY	3	7	2012-07-05	40199	59201	\N	\N
75657	SPECIFIC_DAY	3	0	2012-08-05	40199	59201	\N	\N
75658	SPECIFIC_DAY	3	0	2012-02-11	40199	59201	\N	\N
75659	SPECIFIC_DAY	3	0	2012-01-01	40199	59201	\N	\N
75660	SPECIFIC_DAY	3	7	2012-06-13	40199	59201	\N	\N
75661	SPECIFIC_DAY	3	7	2012-02-22	40199	59201	\N	\N
75662	SPECIFIC_DAY	3	7	2011-12-22	40199	59201	\N	\N
75663	SPECIFIC_DAY	3	0	2012-12-30	40199	59201	\N	\N
75664	SPECIFIC_DAY	3	7	2012-09-18	40199	59201	\N	\N
75665	SPECIFIC_DAY	3	0	2011-06-25	40199	59201	\N	\N
75666	SPECIFIC_DAY	3	7	2012-04-13	40199	59201	\N	\N
75667	SPECIFIC_DAY	3	0	2012-06-09	40199	59201	\N	\N
75668	SPECIFIC_DAY	3	0	2012-07-01	40199	59201	\N	\N
75669	SPECIFIC_DAY	3	7	2012-12-19	40199	59201	\N	\N
75670	SPECIFIC_DAY	3	7	2012-05-28	40199	59201	\N	\N
75671	SPECIFIC_DAY	3	0	2013-02-03	40199	59201	\N	\N
75672	SPECIFIC_DAY	3	0	2012-01-07	40199	59201	\N	\N
75673	SPECIFIC_DAY	3	7	2012-02-16	40199	59201	\N	\N
75674	SPECIFIC_DAY	3	0	2011-11-06	40199	59201	\N	\N
75675	SPECIFIC_DAY	3	7	2012-09-25	40199	59201	\N	\N
75676	SPECIFIC_DAY	3	0	2011-12-11	40199	59201	\N	\N
75677	SPECIFIC_DAY	3	7	2012-07-02	40199	59201	\N	\N
75678	SPECIFIC_DAY	3	7	2011-06-15	40199	59201	\N	\N
75679	SPECIFIC_DAY	3	7	2011-11-16	40199	59201	\N	\N
75680	SPECIFIC_DAY	3	0	2012-07-15	40199	59201	\N	\N
75681	SPECIFIC_DAY	3	0	2012-03-10	40199	59201	\N	\N
75682	SPECIFIC_DAY	3	7	2012-07-04	40199	59201	\N	\N
75683	SPECIFIC_DAY	3	7	2012-09-17	40199	59201	\N	\N
75684	SPECIFIC_DAY	3	7	2012-04-26	40199	59201	\N	\N
75685	SPECIFIC_DAY	3	7	2012-02-06	40199	59201	\N	\N
75686	SPECIFIC_DAY	3	0	2012-12-15	40199	59201	\N	\N
75687	SPECIFIC_DAY	3	7	2011-08-25	40199	59201	\N	\N
75688	SPECIFIC_DAY	3	7	2011-07-22	40199	59201	\N	\N
75689	SPECIFIC_DAY	3	7	2012-01-04	40199	59201	\N	\N
75690	SPECIFIC_DAY	3	7	2012-01-24	40199	59201	\N	\N
75691	SPECIFIC_DAY	3	0	2012-05-26	40199	59201	\N	\N
75692	SPECIFIC_DAY	3	7	2011-07-06	40199	59201	\N	\N
75693	SPECIFIC_DAY	3	7	2012-08-28	40199	59201	\N	\N
75694	SPECIFIC_DAY	3	7	2011-06-22	40199	59201	\N	\N
75695	SPECIFIC_DAY	3	7	2013-02-01	40199	59201	\N	\N
75696	SPECIFIC_DAY	3	7	2011-07-25	40199	59201	\N	\N
75697	SPECIFIC_DAY	3	7	2012-01-13	40199	59201	\N	\N
75698	SPECIFIC_DAY	3	7	2011-12-06	40199	59201	\N	\N
75699	SPECIFIC_DAY	3	7	2012-08-07	40199	59201	\N	\N
75700	SPECIFIC_DAY	3	7	2013-01-03	40199	59201	\N	\N
75701	SPECIFIC_DAY	3	0	2010-01-10	49302	68693	\N	\N
75702	SPECIFIC_DAY	3	0	2010-01-09	49302	68693	\N	\N
75703	SPECIFIC_DAY	3	7	2010-01-05	49302	68693	\N	\N
75704	SPECIFIC_DAY	3	7	2010-01-08	49302	68693	\N	\N
75705	SPECIFIC_DAY	3	7	2010-01-11	49302	68693	\N	\N
75706	SPECIFIC_DAY	3	0	2010-01-06	49302	68693	\N	\N
75707	SPECIFIC_DAY	3	7	2010-01-12	49302	68693	\N	\N
75708	SPECIFIC_DAY	3	7	2010-01-07	49302	68693	\N	\N
75709	SPECIFIC_DAY	3	7	2010-01-18	49302	68694	\N	\N
75710	SPECIFIC_DAY	3	7	2010-01-14	49302	68694	\N	\N
75711	SPECIFIC_DAY	3	0	2010-01-16	49302	68694	\N	\N
75712	SPECIFIC_DAY	3	0	2010-01-17	49302	68694	\N	\N
75713	SPECIFIC_DAY	3	7	2010-01-13	49302	68694	\N	\N
75714	SPECIFIC_DAY	3	7	2010-01-15	49302	68694	\N	\N
75715	SPECIFIC_DAY	3	26	2011-03-08	37573	60439	\N	\N
75716	SPECIFIC_DAY	3	26	2011-03-09	37573	60439	\N	\N
75717	SPECIFIC_DAY	3	19	2011-03-13	37573	60439	\N	\N
75718	SPECIFIC_DAY	3	26	2011-03-11	37573	60439	\N	\N
75719	SPECIFIC_DAY	3	25	2011-03-17	37573	60439	\N	\N
75720	SPECIFIC_DAY	3	19	2011-03-12	37573	60439	\N	\N
75721	SPECIFIC_DAY	3	26	2011-03-10	37573	60439	\N	\N
75722	SPECIFIC_DAY	3	26	2011-03-15	37573	60439	\N	\N
75723	SPECIFIC_DAY	3	26	2011-03-14	37573	60439	\N	\N
75724	SPECIFIC_DAY	3	26	2011-03-16	37573	60439	\N	\N
75725	SPECIFIC_DAY	3	2	2009-12-18	49313	68706	\N	\N
75726	SPECIFIC_DAY	3	0	2009-12-26	49313	68706	\N	\N
75727	SPECIFIC_DAY	3	2	2009-12-21	49313	68706	\N	\N
75728	SPECIFIC_DAY	3	0	2009-12-19	49313	68706	\N	\N
75729	SPECIFIC_DAY	3	0	2009-12-27	49313	68706	\N	\N
75730	SPECIFIC_DAY	3	2	2009-12-14	49313	68706	\N	\N
75731	SPECIFIC_DAY	3	2	2009-12-16	49313	68706	\N	\N
75732	SPECIFIC_DAY	3	0	2009-12-20	49313	68706	\N	\N
75733	SPECIFIC_DAY	3	2	2009-12-17	49313	68706	\N	\N
75734	SPECIFIC_DAY	3	1	2009-12-29	49313	68706	\N	\N
75735	SPECIFIC_DAY	3	0	2009-12-25	49313	68706	\N	\N
75736	SPECIFIC_DAY	3	2	2009-12-15	49313	68706	\N	\N
75737	SPECIFIC_DAY	3	2	2009-12-22	49313	68706	\N	\N
75738	SPECIFIC_DAY	3	2	2009-12-28	49313	68706	\N	\N
75739	SPECIFIC_DAY	3	2	2009-12-23	49313	68706	\N	\N
75740	SPECIFIC_DAY	3	2	2009-12-24	49313	68706	\N	\N
75741	SPECIFIC_DAY	3	0	2010-01-16	49313	68707	\N	\N
75742	SPECIFIC_DAY	3	2	2010-01-20	49313	68707	\N	\N
75743	SPECIFIC_DAY	3	0	2010-01-10	49313	68707	\N	\N
75744	SPECIFIC_DAY	3	2	2010-01-14	49313	68707	\N	\N
75745	SPECIFIC_DAY	3	2	2010-01-12	49313	68707	\N	\N
75746	SPECIFIC_DAY	3	2	2010-01-07	49313	68707	\N	\N
75747	SPECIFIC_DAY	3	2	2010-01-19	49313	68707	\N	\N
75748	SPECIFIC_DAY	3	2	2010-01-05	49313	68707	\N	\N
75749	SPECIFIC_DAY	3	2	2010-01-18	49313	68707	\N	\N
75750	SPECIFIC_DAY	3	0	2010-01-03	49313	68707	\N	\N
75751	SPECIFIC_DAY	3	0	2010-01-17	49313	68707	\N	\N
75752	SPECIFIC_DAY	3	2	2010-01-11	49313	68707	\N	\N
75753	SPECIFIC_DAY	3	2	2010-01-04	49313	68707	\N	\N
75754	SPECIFIC_DAY	3	0	2010-01-09	49313	68707	\N	\N
75755	SPECIFIC_DAY	3	0	2010-01-01	49313	68707	\N	\N
75756	SPECIFIC_DAY	3	2	2010-01-15	49313	68707	\N	\N
75757	SPECIFIC_DAY	3	2	2009-12-31	49313	68707	\N	\N
75758	SPECIFIC_DAY	3	0	2010-01-02	49313	68707	\N	\N
75759	SPECIFIC_DAY	3	2	2010-01-13	49313	68707	\N	\N
75760	SPECIFIC_DAY	3	2	2010-01-08	49313	68707	\N	\N
75761	SPECIFIC_DAY	3	2	2009-12-30	49313	68707	\N	\N
75762	SPECIFIC_DAY	3	0	2010-01-06	49313	68707	\N	\N
75763	SPECIFIC_DAY	3	0	2010-01-16	49309	60449	\N	\N
75764	SPECIFIC_DAY	3	0	2010-01-10	49309	60449	\N	\N
75765	SPECIFIC_DAY	3	7	2010-01-22	49309	60449	\N	\N
75766	SPECIFIC_DAY	3	0	2009-12-27	49309	60449	\N	\N
75767	SPECIFIC_DAY	3	7	2010-01-26	49309	60449	\N	\N
75768	SPECIFIC_DAY	3	0	2010-01-31	49309	60449	\N	\N
75769	SPECIFIC_DAY	3	7	2010-01-04	49309	60449	\N	\N
75770	SPECIFIC_DAY	3	0	2010-01-02	49309	60449	\N	\N
75771	SPECIFIC_DAY	3	7	2010-01-28	49309	60449	\N	\N
75772	SPECIFIC_DAY	3	7	2010-01-20	49309	60449	\N	\N
75773	SPECIFIC_DAY	3	0	2010-01-06	49309	60449	\N	\N
75774	SPECIFIC_DAY	3	7	2010-02-10	49309	60449	\N	\N
75775	SPECIFIC_DAY	3	7	2010-02-11	49309	60449	\N	\N
75776	SPECIFIC_DAY	3	7	2010-01-07	49309	60449	\N	\N
75777	SPECIFIC_DAY	3	0	2010-01-17	49309	60449	\N	\N
75778	SPECIFIC_DAY	3	0	2010-01-03	49309	60449	\N	\N
75779	SPECIFIC_DAY	3	7	2010-01-18	49309	60449	\N	\N
75780	SPECIFIC_DAY	3	7	2009-12-22	49309	60449	\N	\N
75781	SPECIFIC_DAY	3	0	2009-12-26	49309	60449	\N	\N
75782	SPECIFIC_DAY	3	0	2010-02-14	49309	60449	\N	\N
75783	SPECIFIC_DAY	3	7	2010-02-18	49309	60449	\N	\N
75784	SPECIFIC_DAY	3	7	2010-02-02	49309	60449	\N	\N
75785	SPECIFIC_DAY	3	7	2010-02-05	49309	60449	\N	\N
75786	SPECIFIC_DAY	3	7	2009-12-28	49309	60449	\N	\N
75787	SPECIFIC_DAY	3	7	2010-01-11	49309	60449	\N	\N
75788	SPECIFIC_DAY	3	7	2010-02-12	49309	60449	\N	\N
75789	SPECIFIC_DAY	3	7	2010-01-14	49309	60449	\N	\N
75790	SPECIFIC_DAY	3	7	2010-02-04	49309	60449	\N	\N
75791	SPECIFIC_DAY	3	7	2010-01-08	49309	60449	\N	\N
75792	SPECIFIC_DAY	3	0	2010-01-30	49309	60449	\N	\N
75793	SPECIFIC_DAY	3	7	2010-01-12	49309	60449	\N	\N
75794	SPECIFIC_DAY	3	7	2010-02-01	49309	60449	\N	\N
75795	SPECIFIC_DAY	3	7	2010-01-29	49309	60449	\N	\N
75796	SPECIFIC_DAY	3	7	2010-02-08	49309	60449	\N	\N
75797	SPECIFIC_DAY	3	0	2010-01-24	49309	60449	\N	\N
75798	SPECIFIC_DAY	3	0	2010-01-09	49309	60449	\N	\N
75799	SPECIFIC_DAY	3	0	2010-02-17	49309	60449	\N	\N
75800	SPECIFIC_DAY	3	7	2009-12-30	49309	60449	\N	\N
75801	SPECIFIC_DAY	3	0	2010-02-13	49309	60449	\N	\N
75802	SPECIFIC_DAY	3	7	2010-01-25	49309	60449	\N	\N
75803	SPECIFIC_DAY	3	0	2009-12-25	49309	60449	\N	\N
75804	SPECIFIC_DAY	3	0	2010-02-07	49309	60449	\N	\N
75805	SPECIFIC_DAY	3	7	2009-12-23	49309	60449	\N	\N
75806	SPECIFIC_DAY	3	0	2010-01-23	49309	60449	\N	\N
75807	SPECIFIC_DAY	3	7	2010-02-15	49309	60449	\N	\N
75808	SPECIFIC_DAY	3	7	2010-01-19	49309	60449	\N	\N
75809	SPECIFIC_DAY	3	7	2009-12-29	49309	60449	\N	\N
75810	SPECIFIC_DAY	3	7	2009-12-24	49309	60449	\N	\N
75811	SPECIFIC_DAY	3	7	2010-01-05	49309	60449	\N	\N
75812	SPECIFIC_DAY	3	7	2010-02-19	49309	60449	\N	\N
75813	SPECIFIC_DAY	3	7	2010-02-16	49309	60449	\N	\N
75814	SPECIFIC_DAY	3	7	2010-02-03	49309	60449	\N	\N
75815	SPECIFIC_DAY	3	7	2010-01-13	49309	60449	\N	\N
75816	SPECIFIC_DAY	3	7	2010-01-15	49309	60449	\N	\N
75817	SPECIFIC_DAY	3	7	2010-01-21	49309	60449	\N	\N
75818	SPECIFIC_DAY	3	7	2010-02-09	49309	60449	\N	\N
75819	SPECIFIC_DAY	3	7	2009-12-31	49309	60449	\N	\N
75820	SPECIFIC_DAY	3	0	2010-02-06	49309	60449	\N	\N
75821	SPECIFIC_DAY	3	7	2010-01-27	49309	60449	\N	\N
75822	SPECIFIC_DAY	3	0	2010-01-01	49309	60449	\N	\N
75823	SPECIFIC_DAY	3	7	2010-06-25	49309	60450	\N	\N
75824	SPECIFIC_DAY	3	0	2010-05-29	49309	60450	\N	\N
75825	SPECIFIC_DAY	3	7	2010-06-07	49309	60450	\N	\N
75826	SPECIFIC_DAY	3	7	2010-05-24	49309	60450	\N	\N
75827	SPECIFIC_DAY	3	7	2010-06-08	49309	60450	\N	\N
75828	SPECIFIC_DAY	3	7	2010-05-27	49309	60450	\N	\N
75829	SPECIFIC_DAY	3	7	2010-07-02	49309	60450	\N	\N
75830	SPECIFIC_DAY	3	7	2010-05-28	49309	60450	\N	\N
75831	SPECIFIC_DAY	3	0	2010-05-09	49309	60450	\N	\N
75832	SPECIFIC_DAY	3	7	2010-05-21	49309	60450	\N	\N
75833	SPECIFIC_DAY	3	7	2010-06-29	49309	60450	\N	\N
75834	SPECIFIC_DAY	3	0	2010-06-20	49309	60450	\N	\N
75835	SPECIFIC_DAY	3	7	2010-05-18	49309	60450	\N	\N
75836	SPECIFIC_DAY	3	7	2010-05-14	49309	60450	\N	\N
75837	SPECIFIC_DAY	3	7	2010-06-16	49309	60450	\N	\N
75838	SPECIFIC_DAY	3	7	2010-05-07	49309	60450	\N	\N
75839	SPECIFIC_DAY	3	7	2010-06-03	49309	60450	\N	\N
75840	SPECIFIC_DAY	3	7	2010-06-11	49309	60450	\N	\N
75841	SPECIFIC_DAY	3	7	2010-06-18	49309	60450	\N	\N
75842	SPECIFIC_DAY	3	0	2010-05-17	49309	60450	\N	\N
75843	SPECIFIC_DAY	3	7	2010-06-28	49309	60450	\N	\N
75844	SPECIFIC_DAY	3	7	2010-07-01	49309	60450	\N	\N
75845	SPECIFIC_DAY	3	7	2010-06-30	49309	60450	\N	\N
75846	SPECIFIC_DAY	3	7	2010-05-31	49309	60450	\N	\N
75847	SPECIFIC_DAY	3	7	2010-05-20	49309	60450	\N	\N
75848	SPECIFIC_DAY	3	0	2010-05-23	49309	60450	\N	\N
75849	SPECIFIC_DAY	3	7	2010-05-26	49309	60450	\N	\N
75850	SPECIFIC_DAY	3	0	2010-05-15	49309	60450	\N	\N
75851	SPECIFIC_DAY	3	0	2010-06-19	49309	60450	\N	\N
75852	SPECIFIC_DAY	3	7	2010-05-10	49309	60450	\N	\N
75853	SPECIFIC_DAY	3	7	2010-06-10	49309	60450	\N	\N
75854	SPECIFIC_DAY	3	0	2010-06-06	49309	60450	\N	\N
75855	SPECIFIC_DAY	3	0	2010-06-12	49309	60450	\N	\N
75856	SPECIFIC_DAY	3	0	2010-05-08	49309	60450	\N	\N
75857	SPECIFIC_DAY	3	7	2010-05-11	49309	60450	\N	\N
75858	SPECIFIC_DAY	3	7	2010-06-04	49309	60450	\N	\N
75859	SPECIFIC_DAY	3	7	2010-06-24	49309	60450	\N	\N
75860	SPECIFIC_DAY	3	7	2010-06-02	49309	60450	\N	\N
75861	SPECIFIC_DAY	3	7	2010-06-15	49309	60450	\N	\N
75862	SPECIFIC_DAY	3	7	2010-06-23	49309	60450	\N	\N
75863	SPECIFIC_DAY	3	7	2010-06-14	49309	60450	\N	\N
75864	SPECIFIC_DAY	3	0	2010-05-22	49309	60450	\N	\N
75865	SPECIFIC_DAY	3	7	2010-06-09	49309	60450	\N	\N
75866	SPECIFIC_DAY	3	7	2010-06-17	49309	60450	\N	\N
75867	SPECIFIC_DAY	3	0	2010-05-30	49309	60450	\N	\N
75868	SPECIFIC_DAY	3	0	2010-06-05	49309	60450	\N	\N
75869	SPECIFIC_DAY	3	7	2010-06-01	49309	60450	\N	\N
75870	SPECIFIC_DAY	3	7	2010-05-25	49309	60450	\N	\N
75871	SPECIFIC_DAY	3	7	2010-05-19	49309	60450	\N	\N
75872	SPECIFIC_DAY	3	7	2010-05-12	49309	60450	\N	\N
75873	SPECIFIC_DAY	3	0	2010-06-13	49309	60450	\N	\N
75874	SPECIFIC_DAY	3	0	2010-06-26	49309	60450	\N	\N
75875	SPECIFIC_DAY	3	0	2010-06-27	49309	60450	\N	\N
75876	SPECIFIC_DAY	3	7	2010-06-21	49309	60450	\N	\N
75877	SPECIFIC_DAY	3	0	2010-05-16	49309	60450	\N	\N
75878	SPECIFIC_DAY	3	7	2010-05-13	49309	60450	\N	\N
75879	SPECIFIC_DAY	3	7	2010-06-22	49309	60450	\N	\N
75880	SPECIFIC_DAY	3	7	2010-01-19	49300	68691	\N	\N
75881	SPECIFIC_DAY	3	7	2010-01-18	49300	68691	\N	\N
75882	SPECIFIC_DAY	3	7	2010-01-14	49300	68691	\N	\N
75883	SPECIFIC_DAY	3	7	2010-01-15	49300	68691	\N	\N
75884	SPECIFIC_DAY	3	0	2010-01-16	49300	68691	\N	\N
75885	SPECIFIC_DAY	3	0	2010-01-17	49300	68691	\N	\N
75886	SPECIFIC_DAY	3	7	2010-04-09	49309	60438	\N	\N
75887	SPECIFIC_DAY	3	0	2010-04-10	49309	60438	\N	\N
75888	SPECIFIC_DAY	3	7	2010-03-03	49309	60438	\N	\N
75889	SPECIFIC_DAY	3	7	2010-02-23	49309	60438	\N	\N
75890	SPECIFIC_DAY	3	7	2010-03-23	49309	60438	\N	\N
75891	SPECIFIC_DAY	3	0	2010-04-24	49309	60438	\N	\N
75892	SPECIFIC_DAY	3	0	2010-03-13	49309	60438	\N	\N
75893	SPECIFIC_DAY	3	7	2010-04-06	49309	60438	\N	\N
75894	SPECIFIC_DAY	3	7	2010-05-05	49309	60438	\N	\N
75895	SPECIFIC_DAY	3	7	2010-04-29	49309	60438	\N	\N
75896	SPECIFIC_DAY	3	7	2010-03-09	49309	60438	\N	\N
75897	SPECIFIC_DAY	3	7	2010-04-21	49309	60438	\N	\N
75898	SPECIFIC_DAY	3	7	2010-03-22	49309	60438	\N	\N
75899	SPECIFIC_DAY	3	0	2010-02-20	49309	60438	\N	\N
75900	SPECIFIC_DAY	3	7	2010-02-22	49309	60438	\N	\N
75901	SPECIFIC_DAY	3	0	2010-04-03	49309	60438	\N	\N
75902	SPECIFIC_DAY	3	0	2010-04-02	49309	60438	\N	\N
75903	SPECIFIC_DAY	3	7	2010-04-13	49309	60438	\N	\N
75904	SPECIFIC_DAY	3	7	2010-03-18	49309	60438	\N	\N
75905	SPECIFIC_DAY	3	7	2010-04-16	49309	60438	\N	\N
75906	SPECIFIC_DAY	3	0	2010-04-04	49309	60438	\N	\N
75907	SPECIFIC_DAY	3	7	2010-04-30	49309	60438	\N	\N
75908	SPECIFIC_DAY	3	0	2010-04-18	49309	60438	\N	\N
75909	SPECIFIC_DAY	3	0	2010-04-05	49309	60438	\N	\N
75910	SPECIFIC_DAY	3	7	2010-04-07	49309	60438	\N	\N
75911	SPECIFIC_DAY	3	7	2010-04-23	49309	60438	\N	\N
75912	SPECIFIC_DAY	3	0	2010-03-06	49309	60438	\N	\N
75913	SPECIFIC_DAY	3	0	2010-02-28	49309	60438	\N	\N
75914	SPECIFIC_DAY	3	7	2010-03-24	49309	60438	\N	\N
75915	SPECIFIC_DAY	3	0	2010-02-21	49309	60438	\N	\N
75916	SPECIFIC_DAY	3	7	2010-03-05	49309	60438	\N	\N
75917	SPECIFIC_DAY	3	7	2010-03-08	49309	60438	\N	\N
75918	SPECIFIC_DAY	3	7	2010-04-28	49309	60438	\N	\N
75919	SPECIFIC_DAY	3	7	2010-03-10	49309	60438	\N	\N
75920	SPECIFIC_DAY	3	7	2010-05-06	49309	60438	\N	\N
75921	SPECIFIC_DAY	3	0	2010-04-01	49309	60438	\N	\N
75922	SPECIFIC_DAY	3	7	2010-03-26	49309	60438	\N	\N
75923	SPECIFIC_DAY	3	0	2010-05-02	49309	60438	\N	\N
75924	SPECIFIC_DAY	3	7	2010-03-12	49309	60438	\N	\N
75925	SPECIFIC_DAY	3	7	2010-05-03	49309	60438	\N	\N
75926	SPECIFIC_DAY	3	0	2010-04-17	49309	60438	\N	\N
75927	SPECIFIC_DAY	3	0	2010-03-14	49309	60438	\N	\N
75928	SPECIFIC_DAY	3	7	2010-03-04	49309	60438	\N	\N
75929	SPECIFIC_DAY	3	7	2010-03-31	49309	60438	\N	\N
75930	SPECIFIC_DAY	3	7	2010-04-08	49309	60438	\N	\N
75931	SPECIFIC_DAY	3	0	2010-02-27	49309	60438	\N	\N
75932	SPECIFIC_DAY	3	7	2010-03-15	49309	60438	\N	\N
75933	SPECIFIC_DAY	3	7	2010-02-26	49309	60438	\N	\N
75934	SPECIFIC_DAY	3	7	2010-03-11	49309	60438	\N	\N
75935	SPECIFIC_DAY	3	7	2010-03-29	49309	60438	\N	\N
75936	SPECIFIC_DAY	3	0	2010-03-21	49309	60438	\N	\N
75937	SPECIFIC_DAY	3	7	2010-03-30	49309	60438	\N	\N
75938	SPECIFIC_DAY	3	7	2010-04-26	49309	60438	\N	\N
75939	SPECIFIC_DAY	3	7	2010-05-04	49309	60438	\N	\N
75940	SPECIFIC_DAY	3	0	2010-03-07	49309	60438	\N	\N
75941	SPECIFIC_DAY	3	0	2010-03-28	49309	60438	\N	\N
75942	SPECIFIC_DAY	3	7	2010-04-12	49309	60438	\N	\N
75943	SPECIFIC_DAY	3	0	2010-03-20	49309	60438	\N	\N
75944	SPECIFIC_DAY	3	7	2010-04-20	49309	60438	\N	\N
75945	SPECIFIC_DAY	3	7	2010-02-25	49309	60438	\N	\N
75946	SPECIFIC_DAY	3	0	2010-03-19	49309	60438	\N	\N
75947	SPECIFIC_DAY	3	7	2010-03-25	49309	60438	\N	\N
75948	SPECIFIC_DAY	3	7	2010-03-02	49309	60438	\N	\N
75949	SPECIFIC_DAY	3	7	2010-04-15	49309	60438	\N	\N
75950	SPECIFIC_DAY	3	7	2010-04-19	49309	60438	\N	\N
75951	SPECIFIC_DAY	3	7	2010-03-17	49309	60438	\N	\N
75952	SPECIFIC_DAY	3	7	2010-04-27	49309	60438	\N	\N
75953	SPECIFIC_DAY	3	7	2010-02-24	49309	60438	\N	\N
75954	SPECIFIC_DAY	3	7	2010-03-01	49309	60438	\N	\N
75955	SPECIFIC_DAY	3	0	2010-03-27	49309	60438	\N	\N
75956	SPECIFIC_DAY	3	0	2010-04-11	49309	60438	\N	\N
75957	SPECIFIC_DAY	3	0	2010-04-25	49309	60438	\N	\N
75958	SPECIFIC_DAY	3	0	2010-05-01	49309	60438	\N	\N
75959	SPECIFIC_DAY	3	7	2010-04-22	49309	60438	\N	\N
75960	SPECIFIC_DAY	3	7	2010-04-14	49309	60438	\N	\N
75961	SPECIFIC_DAY	3	7	2010-03-16	49309	60438	\N	\N
75962	SPECIFIC_DAY	3	7	2010-01-20	49300	66154	\N	\N
75963	SPECIFIC_DAY	3	7	2010-01-21	49300	66154	\N	\N
75964	SPECIFIC_DAY	3	7	2010-01-22	49300	66154	\N	\N
69413	SPECIFIC_DAY	3	0	2010-01-18	49297	68684	\N	\N
69414	SPECIFIC_DAY	3	0	2010-01-21	49297	68684	\N	\N
69415	SPECIFIC_DAY	3	8	2010-01-05	49297	68684	\N	\N
69416	SPECIFIC_DAY	3	1	2010-01-08	49297	68684	\N	\N
69417	SPECIFIC_DAY	3	0	2010-01-22	49297	68684	\N	\N
69418	SPECIFIC_DAY	3	0	2010-01-12	49297	68684	\N	\N
69419	SPECIFIC_DAY	3	1	2010-01-07	49297	68684	\N	\N
69420	SPECIFIC_DAY	3	0	2010-01-16	49297	68684	\N	\N
69421	SPECIFIC_DAY	3	7	2010-01-27	49297	68684	\N	\N
69422	SPECIFIC_DAY	3	0	2010-01-19	49297	68684	\N	\N
69423	SPECIFIC_DAY	3	0	2010-01-25	49297	68684	\N	\N
69424	SPECIFIC_DAY	3	0	2010-01-24	49297	68684	\N	\N
69425	SPECIFIC_DAY	3	0	2010-01-23	49297	68684	\N	\N
69426	SPECIFIC_DAY	3	0	2010-01-15	49297	68684	\N	\N
69427	SPECIFIC_DAY	3	0	2010-01-20	49297	68684	\N	\N
69428	SPECIFIC_DAY	3	0	2010-01-13	49297	68684	\N	\N
69429	SPECIFIC_DAY	3	0	2010-01-26	49297	68684	\N	\N
69430	SPECIFIC_DAY	3	0	2010-01-14	49297	68684	\N	\N
69431	SPECIFIC_DAY	3	1	2010-01-11	49297	68684	\N	\N
69432	SPECIFIC_DAY	3	1	2010-01-09	49297	68684	\N	\N
69433	SPECIFIC_DAY	3	1	2010-01-06	49297	68684	\N	\N
69434	SPECIFIC_DAY	3	1	2010-01-10	49297	68684	\N	\N
69435	SPECIFIC_DAY	3	0	2010-01-17	49297	68684	\N	\N
69436	SPECIFIC_DAY	3	21	2010-01-28	49297	68685	\N	\N
69437	SPECIFIC_DAY	3	7	2009-12-16	49297	68686	\N	\N
69438	SPECIFIC_DAY	3	7	2009-12-18	49297	68686	\N	\N
69439	SPECIFIC_DAY	3	7	2009-12-17	49297	68686	\N	\N
69440	SPECIFIC_DAY	3	7	2009-12-29	49297	68687	\N	\N
69441	SPECIFIC_DAY	3	7	2009-12-30	49297	68687	\N	\N
69442	SPECIFIC_DAY	3	7	2009-12-31	49297	68687	\N	\N
69443	SPECIFIC_DAY	3	2	2009-12-19	49297	68688	\N	\N
69444	SPECIFIC_DAY	3	2	2009-12-20	49297	68688	\N	\N
69445	SPECIFIC_DAY	3	9	2009-12-21	49297	68688	\N	\N
69446	SPECIFIC_DAY	3	8	2009-12-22	49297	68688	\N	\N
69447	SPECIFIC_DAY	3	7	2009-12-28	49297	68689	\N	\N
69448	SPECIFIC_DAY	3	0	2009-12-26	49297	68689	\N	\N
69449	SPECIFIC_DAY	3	0	2009-12-25	49297	68689	\N	\N
69450	SPECIFIC_DAY	3	0	2009-12-27	49297	68689	\N	\N
69451	SPECIFIC_DAY	3	7	2009-12-23	49297	68689	\N	\N
69452	SPECIFIC_DAY	3	7	2009-12-24	49297	68689	\N	\N
69453	SPECIFIC_DAY	3	10	2010-01-04	49297	68690	\N	\N
69454	SPECIFIC_DAY	3	4	2010-01-01	49297	68690	\N	\N
69455	SPECIFIC_DAY	3	4	2010-01-02	49297	68690	\N	\N
69456	SPECIFIC_DAY	3	3	2010-01-03	49297	68690	\N	\N
69457	SPECIFIC_DAY	3	13	2010-01-21	36159	60446	\N	\N
69458	SPECIFIC_DAY	3	6	2010-01-09	36159	60446	\N	\N
69459	SPECIFIC_DAY	3	6	2010-01-13	36159	60446	\N	\N
69460	SPECIFIC_DAY	3	13	2010-01-20	36159	60446	\N	\N
69461	SPECIFIC_DAY	3	13	2010-01-25	36159	60446	\N	\N
69462	SPECIFIC_DAY	3	6	2010-01-24	36159	60446	\N	\N
69463	SPECIFIC_DAY	3	6	2010-01-12	36159	60446	\N	\N
69464	SPECIFIC_DAY	3	6	2010-01-15	36159	60446	\N	\N
69465	SPECIFIC_DAY	3	6	2010-01-14	36159	60446	\N	\N
69466	SPECIFIC_DAY	3	6	2010-01-16	36159	60446	\N	\N
69467	SPECIFIC_DAY	3	13	2010-01-27	36159	60446	\N	\N
69468	SPECIFIC_DAY	3	13	2010-01-22	36159	60446	\N	\N
69469	SPECIFIC_DAY	3	13	2010-01-08	36159	60446	\N	\N
69470	SPECIFIC_DAY	3	6	2010-01-23	36159	60446	\N	\N
69471	SPECIFIC_DAY	3	6	2010-01-11	36159	60446	\N	\N
69472	SPECIFIC_DAY	3	13	2010-01-28	36159	60446	\N	\N
69473	SPECIFIC_DAY	3	13	2010-01-18	36159	60446	\N	\N
69474	SPECIFIC_DAY	3	6	2010-01-10	36159	60446	\N	\N
69475	SPECIFIC_DAY	3	13	2010-01-19	36159	60446	\N	\N
69476	SPECIFIC_DAY	3	6	2010-01-17	36159	60446	\N	\N
69477	SPECIFIC_DAY	3	13	2010-01-26	36159	60446	\N	\N
69478	SPECIFIC_DAY	3	14	2010-01-07	36159	60446	\N	\N
69479	SPECIFIC_DAY	3	9	2009-12-27	36159	60447	\N	\N
69480	SPECIFIC_DAY	3	9	2010-01-06	36159	60447	\N	\N
69481	SPECIFIC_DAY	3	16	2009-12-29	36159	60447	\N	\N
69482	SPECIFIC_DAY	3	9	2010-01-02	36159	60447	\N	\N
69483	SPECIFIC_DAY	3	16	2010-01-04	36159	60447	\N	\N
69484	SPECIFIC_DAY	3	16	2009-12-31	36159	60447	\N	\N
69485	SPECIFIC_DAY	3	16	2010-01-05	36159	60447	\N	\N
69486	SPECIFIC_DAY	3	9	2010-01-03	36159	60447	\N	\N
69487	SPECIFIC_DAY	3	17	2009-12-22	36159	60447	\N	\N
69488	SPECIFIC_DAY	3	9	2009-12-25	36159	60447	\N	\N
69489	SPECIFIC_DAY	3	17	2009-12-23	36159	60447	\N	\N
69490	SPECIFIC_DAY	3	9	2010-01-01	36159	60447	\N	\N
69491	SPECIFIC_DAY	3	9	2009-12-26	36159	60447	\N	\N
69492	SPECIFIC_DAY	3	16	2009-12-28	36159	60447	\N	\N
69493	SPECIFIC_DAY	3	16	2009-12-30	36159	60447	\N	\N
69494	SPECIFIC_DAY	3	17	2009-12-24	36159	60447	\N	\N
69495	SPECIFIC_DAY	3	7	2010-01-04	49300	68697	\N	\N
69496	SPECIFIC_DAY	3	0	2010-01-03	49300	68697	\N	\N
69497	SPECIFIC_DAY	3	0	2010-01-02	49300	68697	\N	\N
69498	SPECIFIC_DAY	3	7	2009-12-31	49300	68697	\N	\N
69499	SPECIFIC_DAY	3	7	2009-12-30	49300	68697	\N	\N
69500	SPECIFIC_DAY	3	0	2010-01-01	49300	68697	\N	\N
69501	SPECIFIC_DAY	3	0	2010-01-06	49300	68698	\N	\N
69502	SPECIFIC_DAY	3	7	2010-01-05	49300	68698	\N	\N
69503	SPECIFIC_DAY	3	7	2010-01-13	49300	68698	\N	\N
69504	SPECIFIC_DAY	3	7	2010-01-12	49300	68698	\N	\N
69505	SPECIFIC_DAY	3	7	2010-01-08	49300	68698	\N	\N
69506	SPECIFIC_DAY	3	0	2010-01-10	49300	68698	\N	\N
69507	SPECIFIC_DAY	3	7	2010-01-07	49300	68698	\N	\N
69508	SPECIFIC_DAY	3	0	2010-01-09	49300	68698	\N	\N
69509	SPECIFIC_DAY	3	7	2010-01-11	49300	68698	\N	\N
69510	SPECIFIC_DAY	3	7	2010-01-26	49300	68699	\N	\N
69511	SPECIFIC_DAY	3	0	2010-01-24	49300	68699	\N	\N
69512	SPECIFIC_DAY	3	3	2010-01-28	49300	68699	\N	\N
69513	SPECIFIC_DAY	3	7	2010-01-25	49300	68699	\N	\N
69514	SPECIFIC_DAY	3	0	2010-01-23	49300	68699	\N	\N
69515	SPECIFIC_DAY	3	7	2010-01-27	49300	68699	\N	\N
69516	SPECIFIC_DAY	3	7	2009-12-28	49300	68700	\N	\N
69517	SPECIFIC_DAY	3	7	2009-12-23	49300	68700	\N	\N
69518	SPECIFIC_DAY	3	0	2009-12-20	49300	68700	\N	\N
69519	SPECIFIC_DAY	3	0	2009-12-27	49300	68700	\N	\N
69520	SPECIFIC_DAY	3	7	2009-12-29	49300	68700	\N	\N
69521	SPECIFIC_DAY	3	0	2009-12-19	49300	68700	\N	\N
69522	SPECIFIC_DAY	3	0	2009-12-25	49300	68700	\N	\N
69523	SPECIFIC_DAY	3	7	2009-12-21	49300	68700	\N	\N
69524	SPECIFIC_DAY	3	7	2009-12-22	49300	68700	\N	\N
69525	SPECIFIC_DAY	3	7	2009-12-24	49300	68700	\N	\N
69526	SPECIFIC_DAY	3	0	2009-12-26	49300	68700	\N	\N
69811	SPECIFIC_DAY	3	7	2010-09-02	49309	61409	\N	\N
69812	SPECIFIC_DAY	3	7	2010-08-16	49309	61409	\N	\N
69813	SPECIFIC_DAY	3	7	2010-09-09	49309	61409	\N	\N
69814	SPECIFIC_DAY	3	7	2010-07-29	49309	61409	\N	\N
69815	SPECIFIC_DAY	3	0	2010-07-10	49309	61409	\N	\N
69816	SPECIFIC_DAY	3	7	2010-08-02	49309	61409	\N	\N
69817	SPECIFIC_DAY	3	7	2010-07-27	49309	61409	\N	\N
69818	SPECIFIC_DAY	3	7	2010-07-16	49309	61409	\N	\N
69819	SPECIFIC_DAY	3	7	2010-07-15	49309	61409	\N	\N
69820	SPECIFIC_DAY	3	7	2010-08-19	49309	61409	\N	\N
69821	SPECIFIC_DAY	3	7	2010-07-13	49309	61409	\N	\N
69822	SPECIFIC_DAY	3	7	2010-07-14	49309	61409	\N	\N
69823	SPECIFIC_DAY	3	0	2010-08-21	49309	61409	\N	\N
69824	SPECIFIC_DAY	3	7	2010-08-13	49309	61409	\N	\N
69825	SPECIFIC_DAY	3	7	2010-07-09	49309	61409	\N	\N
69826	SPECIFIC_DAY	3	7	2010-08-03	49309	61409	\N	\N
69827	SPECIFIC_DAY	3	0	2010-07-04	49309	61409	\N	\N
69828	SPECIFIC_DAY	3	7	2010-08-20	49309	61409	\N	\N
69829	SPECIFIC_DAY	3	0	2010-07-03	49309	61409	\N	\N
69830	SPECIFIC_DAY	3	0	2010-09-05	49309	61409	\N	\N
69831	SPECIFIC_DAY	3	7	2010-08-23	49309	61409	\N	\N
69832	SPECIFIC_DAY	3	0	2010-07-11	49309	61409	\N	\N
69833	SPECIFIC_DAY	3	7	2010-07-20	49309	61409	\N	\N
69834	SPECIFIC_DAY	3	7	2010-07-21	49309	61409	\N	\N
69835	SPECIFIC_DAY	3	7	2010-07-19	49309	61409	\N	\N
69836	SPECIFIC_DAY	3	7	2010-07-07	49309	61409	\N	\N
69837	SPECIFIC_DAY	3	7	2010-08-31	49309	61409	\N	\N
69838	SPECIFIC_DAY	3	7	2010-08-27	49309	61409	\N	\N
69839	SPECIFIC_DAY	3	7	2010-08-25	49309	61409	\N	\N
69840	SPECIFIC_DAY	3	0	2010-07-24	49309	61409	\N	\N
69841	SPECIFIC_DAY	3	0	2010-08-07	49309	61409	\N	\N
69842	SPECIFIC_DAY	3	7	2010-08-12	49309	61409	\N	\N
69843	SPECIFIC_DAY	3	0	2010-08-28	49309	61409	\N	\N
69844	SPECIFIC_DAY	3	0	2010-08-29	49309	61409	\N	\N
69845	SPECIFIC_DAY	3	7	2010-07-23	49309	61409	\N	\N
69846	SPECIFIC_DAY	3	0	2010-09-04	49309	61409	\N	\N
69847	SPECIFIC_DAY	3	7	2010-08-24	49309	61409	\N	\N
69848	SPECIFIC_DAY	3	7	2010-08-06	49309	61409	\N	\N
69849	SPECIFIC_DAY	3	0	2010-07-31	49309	61409	\N	\N
69850	SPECIFIC_DAY	3	0	2010-07-25	49309	61409	\N	\N
69851	SPECIFIC_DAY	3	7	2010-08-30	49309	61409	\N	\N
69852	SPECIFIC_DAY	3	7	2010-07-26	49309	61409	\N	\N
69853	SPECIFIC_DAY	3	7	2010-09-01	49309	61409	\N	\N
69854	SPECIFIC_DAY	3	7	2010-07-05	49309	61409	\N	\N
69855	SPECIFIC_DAY	3	0	2010-08-15	49309	61409	\N	\N
69856	SPECIFIC_DAY	3	7	2010-08-05	49309	61409	\N	\N
69857	SPECIFIC_DAY	3	7	2010-09-08	49309	61409	\N	\N
69858	SPECIFIC_DAY	3	7	2010-07-28	49309	61409	\N	\N
69859	SPECIFIC_DAY	3	0	2010-07-18	49309	61409	\N	\N
69860	SPECIFIC_DAY	3	7	2010-09-10	49309	61409	\N	\N
69861	SPECIFIC_DAY	3	0	2010-08-22	49309	61409	\N	\N
69862	SPECIFIC_DAY	3	0	2010-08-08	49309	61409	\N	\N
69863	SPECIFIC_DAY	3	7	2010-09-07	49309	61409	\N	\N
69864	SPECIFIC_DAY	3	7	2010-08-10	49309	61409	\N	\N
69865	SPECIFIC_DAY	3	7	2010-09-06	49309	61409	\N	\N
69866	SPECIFIC_DAY	3	7	2010-08-26	49309	61409	\N	\N
69867	SPECIFIC_DAY	3	7	2010-08-09	49309	61409	\N	\N
69868	SPECIFIC_DAY	3	7	2010-08-11	49309	61409	\N	\N
69869	SPECIFIC_DAY	3	7	2010-09-03	49309	61409	\N	\N
69870	SPECIFIC_DAY	3	0	2010-08-01	49309	61409	\N	\N
69871	SPECIFIC_DAY	3	7	2010-08-04	49309	61409	\N	\N
69872	SPECIFIC_DAY	3	7	2010-07-12	49309	61409	\N	\N
69873	SPECIFIC_DAY	3	7	2010-08-18	49309	61409	\N	\N
69874	SPECIFIC_DAY	3	0	2010-08-14	49309	61409	\N	\N
69875	SPECIFIC_DAY	3	0	2010-07-17	49309	61409	\N	\N
69876	SPECIFIC_DAY	3	7	2010-07-08	49309	61409	\N	\N
69877	SPECIFIC_DAY	3	7	2010-08-17	49309	61409	\N	\N
69878	SPECIFIC_DAY	3	7	2010-07-06	49309	61409	\N	\N
69879	SPECIFIC_DAY	3	7	2010-07-30	49309	61409	\N	\N
69880	SPECIFIC_DAY	3	7	2010-07-22	49309	61409	\N	\N
69881	SPECIFIC_DAY	3	0	2010-04-02	37573	59217	\N	\N
69882	SPECIFIC_DAY	3	0	2010-04-17	37573	59217	\N	\N
69883	SPECIFIC_DAY	3	9	2011-01-12	37573	59217	\N	\N
69884	SPECIFIC_DAY	3	9	2010-07-22	37573	59217	\N	\N
69885	SPECIFIC_DAY	3	9	2010-12-13	37573	59217	\N	\N
69886	SPECIFIC_DAY	3	9	2010-03-05	37573	59217	\N	\N
69887	SPECIFIC_DAY	3	9	2010-03-02	37573	59217	\N	\N
69888	SPECIFIC_DAY	3	9	2010-11-04	37573	59217	\N	\N
69889	SPECIFIC_DAY	3	0	2010-01-24	37573	59217	\N	\N
69890	SPECIFIC_DAY	3	0	2010-12-05	37573	59217	\N	\N
69891	SPECIFIC_DAY	3	0	2010-07-04	37573	59217	\N	\N
69892	SPECIFIC_DAY	3	0	2010-09-05	37573	59217	\N	\N
69893	SPECIFIC_DAY	3	9	2010-05-05	37573	59217	\N	\N
69894	SPECIFIC_DAY	3	9	2010-10-22	37573	59217	\N	\N
69895	SPECIFIC_DAY	3	9	2010-06-18	37573	59217	\N	\N
69896	SPECIFIC_DAY	3	0	2010-05-30	37573	59217	\N	\N
69897	SPECIFIC_DAY	3	9	2010-12-23	37573	59217	\N	\N
69898	SPECIFIC_DAY	3	0	2010-08-28	37573	59217	\N	\N
69899	SPECIFIC_DAY	3	9	2010-01-13	37573	59217	\N	\N
69900	SPECIFIC_DAY	3	9	2010-03-29	37573	59217	\N	\N
69901	SPECIFIC_DAY	3	0	2010-03-19	37573	59217	\N	\N
69902	SPECIFIC_DAY	3	0	2010-09-18	37573	59217	\N	\N
69903	SPECIFIC_DAY	3	9	2010-08-18	37573	59217	\N	\N
69904	SPECIFIC_DAY	3	9	2010-10-14	37573	59217	\N	\N
69905	SPECIFIC_DAY	3	9	2010-06-11	37573	59217	\N	\N
69906	SPECIFIC_DAY	3	9	2010-01-22	37573	59217	\N	\N
69907	SPECIFIC_DAY	3	9	2011-01-24	37573	59217	\N	\N
69908	SPECIFIC_DAY	3	9	2011-02-02	37573	59217	\N	\N
69909	SPECIFIC_DAY	3	9	2010-08-05	37573	59217	\N	\N
69910	SPECIFIC_DAY	3	9	2010-03-12	37573	59217	\N	\N
69911	SPECIFIC_DAY	3	0	2010-11-07	37573	59217	\N	\N
69912	SPECIFIC_DAY	3	9	2010-10-05	37573	59217	\N	\N
69913	SPECIFIC_DAY	3	0	2010-04-24	37573	59217	\N	\N
69914	SPECIFIC_DAY	3	9	2010-03-03	37573	59217	\N	\N
69915	SPECIFIC_DAY	3	9	2010-10-27	37573	59217	\N	\N
69916	SPECIFIC_DAY	3	9	2010-11-05	37573	59217	\N	\N
69917	SPECIFIC_DAY	3	9	2010-01-26	37573	59217	\N	\N
69918	SPECIFIC_DAY	3	9	2010-10-25	37573	59217	\N	\N
69919	SPECIFIC_DAY	3	9	2010-07-20	37573	59217	\N	\N
69920	SPECIFIC_DAY	3	9	2010-03-15	37573	59217	\N	\N
69921	SPECIFIC_DAY	3	9	2010-11-12	37573	59217	\N	\N
69922	SPECIFIC_DAY	3	0	2010-01-17	37573	59217	\N	\N
69923	SPECIFIC_DAY	3	9	2010-10-08	37573	59217	\N	\N
69924	SPECIFIC_DAY	3	9	2010-12-02	37573	59217	\N	\N
69925	SPECIFIC_DAY	3	0	2010-12-11	37573	59217	\N	\N
69926	SPECIFIC_DAY	3	9	2010-06-15	37573	59217	\N	\N
69927	SPECIFIC_DAY	3	0	2010-08-08	37573	59217	\N	\N
69928	SPECIFIC_DAY	3	9	2011-02-24	37573	59217	\N	\N
69929	SPECIFIC_DAY	3	0	2010-03-20	37573	59217	\N	\N
69930	SPECIFIC_DAY	3	0	2010-09-11	37573	59217	\N	\N
69931	SPECIFIC_DAY	3	9	2010-08-16	37573	59217	\N	\N
69932	SPECIFIC_DAY	3	9	2010-06-24	37573	59217	\N	\N
69933	SPECIFIC_DAY	3	0	2010-06-13	37573	59217	\N	\N
69934	SPECIFIC_DAY	3	9	2010-03-18	37573	59217	\N	\N
69935	SPECIFIC_DAY	3	0	2010-05-23	37573	59217	\N	\N
69936	SPECIFIC_DAY	3	0	2010-08-21	37573	59217	\N	\N
69937	SPECIFIC_DAY	3	9	2010-04-26	37573	59217	\N	\N
69938	SPECIFIC_DAY	3	9	2010-05-07	37573	59217	\N	\N
69939	SPECIFIC_DAY	3	9	2010-02-10	37573	59217	\N	\N
69940	SPECIFIC_DAY	3	9	2010-02-12	37573	59217	\N	\N
69941	SPECIFIC_DAY	3	9	2010-05-25	37573	59217	\N	\N
69942	SPECIFIC_DAY	3	0	2011-02-06	37573	59217	\N	\N
69943	SPECIFIC_DAY	3	9	2010-04-28	37573	59217	\N	\N
69944	SPECIFIC_DAY	3	9	2011-01-11	37573	59217	\N	\N
69945	SPECIFIC_DAY	3	9	2010-12-22	37573	59217	\N	\N
69946	SPECIFIC_DAY	3	0	2010-02-14	37573	59217	\N	\N
69947	SPECIFIC_DAY	3	9	2010-04-20	37573	59217	\N	\N
69948	SPECIFIC_DAY	3	9	2011-01-05	37573	59217	\N	\N
69949	SPECIFIC_DAY	3	9	2010-02-02	37573	59217	\N	\N
69950	SPECIFIC_DAY	3	9	2010-01-28	37573	59217	\N	\N
69951	SPECIFIC_DAY	3	9	2010-06-21	37573	59217	\N	\N
69952	SPECIFIC_DAY	3	0	2010-07-24	37573	59217	\N	\N
69953	SPECIFIC_DAY	3	9	2010-01-18	37573	59217	\N	\N
69954	SPECIFIC_DAY	3	9	2010-04-21	37573	59217	\N	\N
69955	SPECIFIC_DAY	3	9	2010-08-27	37573	59217	\N	\N
69956	SPECIFIC_DAY	3	9	2010-09-24	37573	59217	\N	\N
69957	SPECIFIC_DAY	3	9	2010-01-20	37573	59217	\N	\N
69958	SPECIFIC_DAY	3	9	2010-05-14	37573	59217	\N	\N
69959	SPECIFIC_DAY	3	9	2010-12-17	37573	59217	\N	\N
69960	SPECIFIC_DAY	3	9	2010-09-14	37573	59217	\N	\N
69961	SPECIFIC_DAY	3	9	2010-08-12	37573	59217	\N	\N
69962	SPECIFIC_DAY	3	9	2011-02-14	37573	59217	\N	\N
69963	SPECIFIC_DAY	3	9	2010-05-03	37573	59217	\N	\N
69964	SPECIFIC_DAY	3	9	2010-03-24	37573	59217	\N	\N
69965	SPECIFIC_DAY	3	0	2010-12-04	37573	59217	\N	\N
69966	SPECIFIC_DAY	3	0	2010-05-29	37573	59217	\N	\N
69967	SPECIFIC_DAY	3	9	2010-10-20	37573	59217	\N	\N
69968	SPECIFIC_DAY	3	0	2010-04-04	37573	59217	\N	\N
69969	SPECIFIC_DAY	3	0	2010-04-11	37573	59217	\N	\N
69970	SPECIFIC_DAY	3	9	2010-09-27	37573	59217	\N	\N
69971	SPECIFIC_DAY	3	0	2010-12-12	37573	59217	\N	\N
69972	SPECIFIC_DAY	3	9	2010-02-18	37573	59217	\N	\N
69973	SPECIFIC_DAY	3	9	2011-01-10	37573	59217	\N	\N
69974	SPECIFIC_DAY	3	0	2010-05-01	37573	59217	\N	\N
69975	SPECIFIC_DAY	3	9	2010-03-04	37573	59217	\N	\N
69976	SPECIFIC_DAY	3	0	2010-06-05	37573	59217	\N	\N
69977	SPECIFIC_DAY	3	9	2010-11-25	37573	59217	\N	\N
69978	SPECIFIC_DAY	3	9	2010-02-26	37573	59217	\N	\N
69979	SPECIFIC_DAY	3	9	2010-10-21	37573	59217	\N	\N
69980	SPECIFIC_DAY	3	9	2010-02-03	37573	59217	\N	\N
69981	SPECIFIC_DAY	3	9	2010-09-06	37573	59217	\N	\N
69982	SPECIFIC_DAY	3	9	2010-06-01	37573	59217	\N	\N
69983	SPECIFIC_DAY	3	9	2010-10-01	37573	59217	\N	\N
69984	SPECIFIC_DAY	3	0	2011-01-15	37573	59217	\N	\N
69985	SPECIFIC_DAY	3	9	2010-04-19	37573	59217	\N	\N
69986	SPECIFIC_DAY	3	0	2010-02-27	37573	59217	\N	\N
69987	SPECIFIC_DAY	3	9	2010-03-26	37573	59217	\N	\N
69988	SPECIFIC_DAY	3	9	2010-02-23	37573	59217	\N	\N
69989	SPECIFIC_DAY	3	9	2011-02-21	37573	59217	\N	\N
69990	SPECIFIC_DAY	3	9	2010-07-15	37573	59217	\N	\N
69991	SPECIFIC_DAY	3	9	2010-10-06	37573	59217	\N	\N
69992	SPECIFIC_DAY	3	0	2010-07-18	37573	59217	\N	\N
69993	SPECIFIC_DAY	3	9	2010-06-04	37573	59217	\N	\N
69994	SPECIFIC_DAY	3	0	2011-01-08	37573	59217	\N	\N
69995	SPECIFIC_DAY	3	9	2010-03-23	37573	59217	\N	\N
69996	SPECIFIC_DAY	3	9	2010-05-18	37573	59217	\N	\N
69997	SPECIFIC_DAY	3	9	2010-10-11	37573	59217	\N	\N
69998	SPECIFIC_DAY	3	0	2011-03-06	37573	59217	\N	\N
69999	SPECIFIC_DAY	3	9	2011-02-22	37573	59217	\N	\N
70000	SPECIFIC_DAY	3	9	2011-02-04	37573	59217	\N	\N
70001	SPECIFIC_DAY	3	0	2010-10-12	37573	59217	\N	\N
70002	SPECIFIC_DAY	3	9	2010-10-15	37573	59217	\N	\N
70003	SPECIFIC_DAY	3	9	2010-12-14	37573	59217	\N	\N
70004	SPECIFIC_DAY	3	9	2010-05-19	37573	59217	\N	\N
70005	SPECIFIC_DAY	3	9	2010-04-08	37573	59217	\N	\N
70006	SPECIFIC_DAY	3	0	2011-01-02	37573	59217	\N	\N
70007	SPECIFIC_DAY	3	9	2010-04-12	37573	59217	\N	\N
70008	SPECIFIC_DAY	3	9	2010-08-10	37573	59217	\N	\N
70009	SPECIFIC_DAY	3	9	2010-05-11	37573	59217	\N	\N
70010	SPECIFIC_DAY	3	0	2011-01-01	37573	59217	\N	\N
70011	SPECIFIC_DAY	3	9	2010-11-16	37573	59217	\N	\N
70012	SPECIFIC_DAY	3	9	2011-03-01	37573	59217	\N	\N
70013	SPECIFIC_DAY	3	0	2010-05-02	37573	59217	\N	\N
70014	SPECIFIC_DAY	3	9	2010-03-17	37573	59217	\N	\N
70015	SPECIFIC_DAY	3	9	2010-04-16	37573	59217	\N	\N
70016	SPECIFIC_DAY	3	0	2010-01-09	37573	59217	\N	\N
70017	SPECIFIC_DAY	3	0	2010-06-19	37573	59217	\N	\N
70018	SPECIFIC_DAY	3	0	2011-02-12	37573	59217	\N	\N
70019	SPECIFIC_DAY	3	9	2010-11-18	37573	59217	\N	\N
70020	SPECIFIC_DAY	3	9	2011-02-10	37573	59217	\N	\N
70021	SPECIFIC_DAY	3	9	2010-05-28	37573	59217	\N	\N
70022	SPECIFIC_DAY	3	0	2010-05-09	37573	59217	\N	\N
70023	SPECIFIC_DAY	3	9	2010-05-26	37573	59217	\N	\N
70024	SPECIFIC_DAY	3	9	2010-08-26	37573	59217	\N	\N
70025	SPECIFIC_DAY	3	9	2010-08-30	37573	59217	\N	\N
70026	SPECIFIC_DAY	3	9	2010-06-10	37573	59217	\N	\N
70027	SPECIFIC_DAY	3	9	2011-02-15	37573	59217	\N	\N
70028	SPECIFIC_DAY	3	9	2010-06-09	37573	59217	\N	\N
70029	SPECIFIC_DAY	3	9	2010-12-01	37573	59217	\N	\N
70030	SPECIFIC_DAY	3	0	2010-05-15	37573	59217	\N	\N
70031	SPECIFIC_DAY	3	9	2011-02-16	37573	59217	\N	\N
70032	SPECIFIC_DAY	3	9	2010-09-01	37573	59217	\N	\N
70033	SPECIFIC_DAY	3	0	2010-08-07	37573	59217	\N	\N
70034	SPECIFIC_DAY	3	9	2010-06-29	37573	59217	\N	\N
70035	SPECIFIC_DAY	3	9	2010-08-19	37573	59217	\N	\N
70036	SPECIFIC_DAY	3	9	2011-01-19	37573	59217	\N	\N
70037	SPECIFIC_DAY	3	9	2010-06-30	37573	59217	\N	\N
70038	SPECIFIC_DAY	3	9	2010-05-06	37573	59217	\N	\N
70039	SPECIFIC_DAY	3	0	2011-02-27	37573	59217	\N	\N
70040	SPECIFIC_DAY	3	0	2010-07-25	37573	59217	\N	\N
70041	SPECIFIC_DAY	3	9	2010-12-31	37573	59217	\N	\N
70042	SPECIFIC_DAY	3	9	2010-09-02	37573	59217	\N	\N
70043	SPECIFIC_DAY	3	0	2010-01-06	37573	59217	\N	\N
70044	SPECIFIC_DAY	3	0	2010-10-23	37573	59217	\N	\N
70045	SPECIFIC_DAY	3	9	2011-01-25	37573	59217	\N	\N
70046	SPECIFIC_DAY	3	0	2010-10-03	37573	59217	\N	\N
70047	SPECIFIC_DAY	3	0	2010-08-14	37573	59217	\N	\N
70048	SPECIFIC_DAY	3	9	2010-02-11	37573	59217	\N	\N
70049	SPECIFIC_DAY	3	9	2010-01-14	37573	59217	\N	\N
70050	SPECIFIC_DAY	3	0	2010-12-08	37573	59217	\N	\N
70051	SPECIFIC_DAY	3	0	2010-06-27	37573	59217	\N	\N
70052	SPECIFIC_DAY	3	9	2010-08-17	37573	59217	\N	\N
70053	SPECIFIC_DAY	3	0	2010-10-16	37573	59217	\N	\N
70054	SPECIFIC_DAY	3	0	2010-05-16	37573	59217	\N	\N
70055	SPECIFIC_DAY	3	9	2010-12-15	37573	59217	\N	\N
70056	SPECIFIC_DAY	3	9	2011-02-11	37573	59217	\N	\N
70057	SPECIFIC_DAY	3	9	2010-05-21	37573	59217	\N	\N
70058	SPECIFIC_DAY	3	0	2010-02-17	37573	59217	\N	\N
70059	SPECIFIC_DAY	3	9	2010-10-28	37573	59217	\N	\N
70060	SPECIFIC_DAY	3	9	2010-11-17	37573	59217	\N	\N
70061	SPECIFIC_DAY	3	9	2011-01-14	37573	59217	\N	\N
70062	SPECIFIC_DAY	3	9	2010-09-03	37573	59217	\N	\N
70063	SPECIFIC_DAY	3	9	2010-11-15	37573	59217	\N	\N
70064	SPECIFIC_DAY	3	9	2010-06-25	37573	59217	\N	\N
70065	SPECIFIC_DAY	3	0	2011-02-13	37573	59217	\N	\N
70066	SPECIFIC_DAY	3	9	2010-10-29	37573	59217	\N	\N
70067	SPECIFIC_DAY	3	9	2010-08-13	37573	59217	\N	\N
70068	SPECIFIC_DAY	3	9	2010-09-21	37573	59217	\N	\N
70069	SPECIFIC_DAY	3	9	2010-07-28	37573	59217	\N	\N
70070	SPECIFIC_DAY	3	0	2011-02-19	37573	59217	\N	\N
70071	SPECIFIC_DAY	3	0	2010-10-24	37573	59217	\N	\N
70072	SPECIFIC_DAY	3	9	2011-01-31	37573	59217	\N	\N
70073	SPECIFIC_DAY	3	0	2011-02-26	37573	59217	\N	\N
70074	SPECIFIC_DAY	3	0	2011-01-30	37573	59217	\N	\N
70075	SPECIFIC_DAY	3	9	2010-03-31	37573	59217	\N	\N
70076	SPECIFIC_DAY	3	9	2010-03-30	37573	59217	\N	\N
70077	SPECIFIC_DAY	3	0	2010-02-20	37573	59217	\N	\N
70078	SPECIFIC_DAY	3	9	2010-09-20	37573	59217	\N	\N
70079	SPECIFIC_DAY	3	9	2010-04-22	37573	59217	\N	\N
70080	SPECIFIC_DAY	3	9	2010-11-23	37573	59217	\N	\N
70081	SPECIFIC_DAY	3	9	2011-02-25	37573	59217	\N	\N
70082	SPECIFIC_DAY	3	0	2010-10-10	37573	59217	\N	\N
70083	SPECIFIC_DAY	3	9	2010-12-30	37573	59217	\N	\N
70084	SPECIFIC_DAY	3	9	2010-08-04	37573	59217	\N	\N
70085	SPECIFIC_DAY	3	0	2010-03-13	37573	59217	\N	\N
70086	SPECIFIC_DAY	3	9	2010-03-09	37573	59217	\N	\N
70087	SPECIFIC_DAY	3	0	2010-01-30	37573	59217	\N	\N
70088	SPECIFIC_DAY	3	0	2010-03-27	37573	59217	\N	\N
70089	SPECIFIC_DAY	3	0	2010-03-21	37573	59217	\N	\N
70090	SPECIFIC_DAY	3	9	2011-01-28	37573	59217	\N	\N
70091	SPECIFIC_DAY	3	0	2010-07-11	37573	59217	\N	\N
70092	SPECIFIC_DAY	3	9	2010-05-04	37573	59217	\N	\N
70093	SPECIFIC_DAY	3	0	2010-03-14	37573	59217	\N	\N
70094	SPECIFIC_DAY	3	9	2011-01-21	37573	59217	\N	\N
70095	SPECIFIC_DAY	3	0	2010-01-23	37573	59217	\N	\N
70096	SPECIFIC_DAY	3	0	2011-02-20	37573	59217	\N	\N
70097	SPECIFIC_DAY	3	0	2010-03-28	37573	59217	\N	\N
70098	SPECIFIC_DAY	3	0	2010-03-07	37573	59217	\N	\N
70099	SPECIFIC_DAY	3	9	2011-02-07	37573	59217	\N	\N
70100	SPECIFIC_DAY	3	9	2010-07-08	37573	59217	\N	\N
70101	SPECIFIC_DAY	3	0	2010-10-09	37573	59217	\N	\N
70102	SPECIFIC_DAY	3	9	2010-01-25	37573	59217	\N	\N
70103	SPECIFIC_DAY	3	0	2011-01-16	37573	59217	\N	\N
70104	SPECIFIC_DAY	3	9	2010-07-01	37573	59217	\N	\N
70105	SPECIFIC_DAY	3	9	2010-04-09	37573	59217	\N	\N
70106	SPECIFIC_DAY	3	9	2010-07-12	37573	59217	\N	\N
70107	SPECIFIC_DAY	3	9	2010-06-16	37573	59217	\N	\N
70108	SPECIFIC_DAY	3	9	2011-02-03	37573	59217	\N	\N
70109	SPECIFIC_DAY	3	9	2010-04-06	37573	59217	\N	\N
70110	SPECIFIC_DAY	3	9	2011-03-07	37573	59217	\N	\N
70111	SPECIFIC_DAY	3	0	2010-11-21	37573	59217	\N	\N
70112	SPECIFIC_DAY	3	0	2010-06-26	37573	59217	\N	\N
70113	SPECIFIC_DAY	3	9	2010-11-11	37573	59217	\N	\N
70114	SPECIFIC_DAY	3	0	2010-02-07	37573	59217	\N	\N
70115	SPECIFIC_DAY	3	0	2010-01-10	37573	59217	\N	\N
70116	SPECIFIC_DAY	3	9	2010-05-10	37573	59217	\N	\N
70117	SPECIFIC_DAY	3	9	2010-05-24	37573	59217	\N	\N
70118	SPECIFIC_DAY	3	9	2010-07-06	37573	59217	\N	\N
70119	SPECIFIC_DAY	3	9	2010-08-20	37573	59217	\N	\N
70120	SPECIFIC_DAY	3	9	2010-07-16	37573	59217	\N	\N
70121	SPECIFIC_DAY	3	0	2010-11-20	37573	59217	\N	\N
70122	SPECIFIC_DAY	3	9	2010-09-10	37573	59217	\N	\N
70123	SPECIFIC_DAY	3	0	2010-08-22	37573	59217	\N	\N
70124	SPECIFIC_DAY	3	9	2011-03-02	37573	59217	\N	\N
70125	SPECIFIC_DAY	3	9	2010-07-30	37573	59217	\N	\N
70126	SPECIFIC_DAY	3	9	2010-03-16	37573	59217	\N	\N
70127	SPECIFIC_DAY	3	0	2010-06-06	37573	59217	\N	\N
70128	SPECIFIC_DAY	3	9	2010-08-03	37573	59217	\N	\N
70129	SPECIFIC_DAY	3	9	2010-12-29	37573	59217	\N	\N
70130	SPECIFIC_DAY	3	9	2010-04-23	37573	59217	\N	\N
70131	SPECIFIC_DAY	3	9	2010-10-26	37573	59217	\N	\N
70132	SPECIFIC_DAY	3	9	2010-09-09	37573	59217	\N	\N
70133	SPECIFIC_DAY	3	9	2010-06-28	37573	59217	\N	\N
70134	SPECIFIC_DAY	3	9	2010-07-07	37573	59217	\N	\N
70135	SPECIFIC_DAY	3	9	2010-11-30	37573	59217	\N	\N
70136	SPECIFIC_DAY	3	9	2010-08-06	37573	59217	\N	\N
70137	SPECIFIC_DAY	3	9	2010-09-28	37573	59217	\N	\N
70138	SPECIFIC_DAY	3	0	2011-02-05	37573	59217	\N	\N
70139	SPECIFIC_DAY	3	9	2010-11-08	37573	59217	\N	\N
70140	SPECIFIC_DAY	3	9	2010-08-31	37573	59217	\N	\N
70141	SPECIFIC_DAY	3	9	2010-09-15	37573	59217	\N	\N
70142	SPECIFIC_DAY	3	9	2010-03-11	37573	59217	\N	\N
70143	SPECIFIC_DAY	3	9	2010-08-23	37573	59217	\N	\N
70144	SPECIFIC_DAY	3	9	2010-03-10	37573	59217	\N	\N
70145	SPECIFIC_DAY	3	0	2010-01-16	37573	59217	\N	\N
70146	SPECIFIC_DAY	3	9	2010-06-14	37573	59217	\N	\N
70147	SPECIFIC_DAY	3	0	2010-04-01	37573	59217	\N	\N
70148	SPECIFIC_DAY	3	0	2010-10-30	37573	59217	\N	\N
70149	SPECIFIC_DAY	3	9	2010-09-23	37573	59217	\N	\N
70150	SPECIFIC_DAY	3	9	2010-02-19	37573	59217	\N	\N
70151	SPECIFIC_DAY	3	9	2010-09-08	37573	59217	\N	\N
70152	SPECIFIC_DAY	3	0	2010-12-26	37573	59217	\N	\N
70153	SPECIFIC_DAY	3	9	2010-07-26	37573	59217	\N	\N
70154	SPECIFIC_DAY	3	9	2010-01-08	37573	59217	\N	\N
70155	SPECIFIC_DAY	3	9	2011-03-04	37573	59217	\N	\N
70156	SPECIFIC_DAY	3	9	2010-11-03	37573	59217	\N	\N
70157	SPECIFIC_DAY	3	0	2010-08-29	37573	59217	\N	\N
70158	SPECIFIC_DAY	3	0	2010-10-31	37573	59217	\N	\N
70159	SPECIFIC_DAY	3	9	2010-04-14	37573	59217	\N	\N
70160	SPECIFIC_DAY	3	0	2010-09-12	37573	59217	\N	\N
70161	SPECIFIC_DAY	3	9	2010-11-10	37573	59217	\N	\N
70162	SPECIFIC_DAY	3	9	2010-01-07	37573	59217	\N	\N
70163	SPECIFIC_DAY	3	9	2010-01-15	37573	59217	\N	\N
70164	SPECIFIC_DAY	3	0	2010-07-31	37573	59217	\N	\N
70165	SPECIFIC_DAY	3	0	2010-08-01	37573	59217	\N	\N
70166	SPECIFIC_DAY	3	9	2010-03-08	37573	59217	\N	\N
70167	SPECIFIC_DAY	3	9	2010-02-09	37573	59217	\N	\N
70168	SPECIFIC_DAY	3	9	2010-10-07	37573	59217	\N	\N
70169	SPECIFIC_DAY	3	9	2010-02-08	37573	59217	\N	\N
70170	SPECIFIC_DAY	3	0	2010-02-21	37573	59217	\N	\N
70171	SPECIFIC_DAY	3	9	2011-02-17	37573	59217	\N	\N
70172	SPECIFIC_DAY	3	9	2010-08-02	37573	59217	\N	\N
70173	SPECIFIC_DAY	3	9	2010-11-02	37573	59217	\N	\N
70174	SPECIFIC_DAY	3	9	2010-07-13	37573	59217	\N	\N
70175	SPECIFIC_DAY	3	0	2010-06-12	37573	59217	\N	\N
70176	SPECIFIC_DAY	3	9	2010-12-07	37573	59217	\N	\N
70177	SPECIFIC_DAY	3	9	2010-11-19	37573	59217	\N	\N
70178	SPECIFIC_DAY	3	9	2010-07-09	37573	59217	\N	\N
70179	SPECIFIC_DAY	3	9	2010-04-27	37573	59217	\N	\N
70180	SPECIFIC_DAY	3	9	2010-08-09	37573	59217	\N	\N
70181	SPECIFIC_DAY	3	9	2010-05-27	37573	59217	\N	\N
70182	SPECIFIC_DAY	3	9	2010-01-29	37573	59217	\N	\N
70183	SPECIFIC_DAY	3	0	2010-12-18	37573	59217	\N	\N
70184	SPECIFIC_DAY	3	9	2010-03-25	37573	59217	\N	\N
70185	SPECIFIC_DAY	3	9	2010-01-19	37573	59217	\N	\N
70186	SPECIFIC_DAY	3	0	2010-01-31	37573	59217	\N	\N
70187	SPECIFIC_DAY	3	9	2010-11-24	37573	59217	\N	\N
70188	SPECIFIC_DAY	3	9	2010-05-12	37573	59217	\N	\N
70189	SPECIFIC_DAY	3	9	2010-12-09	37573	59217	\N	\N
70190	SPECIFIC_DAY	3	9	2010-06-22	37573	59217	\N	\N
70191	SPECIFIC_DAY	3	9	2011-01-18	37573	59217	\N	\N
70192	SPECIFIC_DAY	3	9	2010-02-04	37573	59217	\N	\N
70193	SPECIFIC_DAY	3	9	2010-06-02	37573	59217	\N	\N
70194	SPECIFIC_DAY	3	9	2010-12-21	37573	59217	\N	\N
70195	SPECIFIC_DAY	3	9	2010-10-13	37573	59217	\N	\N
70196	SPECIFIC_DAY	3	9	2011-01-27	37573	59217	\N	\N
70197	SPECIFIC_DAY	3	9	2010-04-07	37573	59217	\N	\N
70198	SPECIFIC_DAY	3	0	2011-01-23	37573	59217	\N	\N
70199	SPECIFIC_DAY	3	0	2010-11-13	37573	59217	\N	\N
70200	SPECIFIC_DAY	3	9	2011-02-01	37573	59217	\N	\N
70201	SPECIFIC_DAY	3	0	2010-04-03	37573	59217	\N	\N
70202	SPECIFIC_DAY	3	0	2010-12-19	37573	59217	\N	\N
70203	SPECIFIC_DAY	3	0	2010-11-27	37573	59217	\N	\N
70204	SPECIFIC_DAY	3	0	2011-01-22	37573	59217	\N	\N
70205	SPECIFIC_DAY	3	9	2011-02-23	37573	59217	\N	\N
70206	SPECIFIC_DAY	3	9	2011-02-08	37573	59217	\N	\N
70207	SPECIFIC_DAY	3	9	2010-08-24	37573	59217	\N	\N
70208	SPECIFIC_DAY	3	9	2011-01-07	37573	59217	\N	\N
70209	SPECIFIC_DAY	3	0	2010-09-19	37573	59217	\N	\N
70210	SPECIFIC_DAY	3	0	2010-10-02	37573	59217	\N	\N
70211	SPECIFIC_DAY	3	0	2010-11-01	37573	59217	\N	\N
70212	SPECIFIC_DAY	3	0	2010-12-06	37573	59217	\N	\N
70213	SPECIFIC_DAY	3	0	2010-02-06	37573	59217	\N	\N
70214	SPECIFIC_DAY	3	9	2010-06-23	37573	59217	\N	\N
70215	SPECIFIC_DAY	3	9	2010-12-03	37573	59217	\N	\N
70216	SPECIFIC_DAY	3	9	2010-12-20	37573	59217	\N	\N
70217	SPECIFIC_DAY	3	9	2011-02-09	37573	59217	\N	\N
70218	SPECIFIC_DAY	3	9	2010-01-05	37573	59217	\N	\N
70219	SPECIFIC_DAY	3	9	2010-05-13	37573	59217	\N	\N
70220	SPECIFIC_DAY	3	9	2011-02-28	37573	59217	\N	\N
70221	SPECIFIC_DAY	3	9	2010-09-17	37573	59217	\N	\N
70222	SPECIFIC_DAY	3	9	2010-01-11	37573	59217	\N	\N
70223	SPECIFIC_DAY	3	9	2010-02-25	37573	59217	\N	\N
70224	SPECIFIC_DAY	3	0	2010-12-25	37573	59217	\N	\N
70225	SPECIFIC_DAY	3	0	2010-10-17	37573	59217	\N	\N
70226	SPECIFIC_DAY	3	9	2011-03-03	37573	59217	\N	\N
70227	SPECIFIC_DAY	3	9	2010-09-07	37573	59217	\N	\N
70228	SPECIFIC_DAY	3	0	2010-09-26	37573	59217	\N	\N
70229	SPECIFIC_DAY	3	0	2011-01-09	37573	59217	\N	\N
70230	SPECIFIC_DAY	3	9	2010-04-15	37573	59217	\N	\N
70231	SPECIFIC_DAY	3	9	2010-02-05	37573	59217	\N	\N
70232	SPECIFIC_DAY	3	9	2010-06-03	37573	59217	\N	\N
70233	SPECIFIC_DAY	3	9	2010-01-21	37573	59217	\N	\N
70234	SPECIFIC_DAY	3	0	2010-04-25	37573	59217	\N	\N
70235	SPECIFIC_DAY	3	0	2010-07-17	37573	59217	\N	\N
70236	SPECIFIC_DAY	3	9	2010-01-12	37573	59217	\N	\N
70237	SPECIFIC_DAY	3	0	2010-11-06	37573	59217	\N	\N
70238	SPECIFIC_DAY	3	9	2010-10-04	37573	59217	\N	\N
70239	SPECIFIC_DAY	3	9	2010-09-16	37573	59217	\N	\N
70240	SPECIFIC_DAY	3	9	2010-07-21	37573	59217	\N	\N
70241	SPECIFIC_DAY	3	9	2010-08-11	37573	59217	\N	\N
70242	SPECIFIC_DAY	3	9	2010-08-25	37573	59217	\N	\N
70243	SPECIFIC_DAY	3	0	2010-08-15	37573	59217	\N	\N
70244	SPECIFIC_DAY	3	0	2010-05-17	37573	59217	\N	\N
70245	SPECIFIC_DAY	3	0	2011-01-29	37573	59217	\N	\N
70246	SPECIFIC_DAY	3	0	2010-04-18	37573	59217	\N	\N
70247	SPECIFIC_DAY	3	0	2010-07-03	37573	59217	\N	\N
70248	SPECIFIC_DAY	3	9	2010-10-19	37573	59217	\N	\N
70249	SPECIFIC_DAY	3	0	2010-06-20	37573	59217	\N	\N
70250	SPECIFIC_DAY	3	9	2011-01-20	37573	59217	\N	\N
70251	SPECIFIC_DAY	3	9	2010-09-13	37573	59217	\N	\N
70252	SPECIFIC_DAY	3	0	2010-11-14	37573	59217	\N	\N
70253	SPECIFIC_DAY	3	9	2010-09-29	37573	59217	\N	\N
70254	SPECIFIC_DAY	3	9	2010-04-13	37573	59217	\N	\N
70255	SPECIFIC_DAY	3	0	2010-05-22	37573	59217	\N	\N
70256	SPECIFIC_DAY	3	0	2010-05-08	37573	59217	\N	\N
70257	SPECIFIC_DAY	3	0	2010-04-05	37573	59217	\N	\N
70258	SPECIFIC_DAY	3	9	2010-05-20	37573	59217	\N	\N
70259	SPECIFIC_DAY	3	9	2011-02-18	37573	59217	\N	\N
70260	SPECIFIC_DAY	3	0	2010-02-28	37573	59217	\N	\N
70261	SPECIFIC_DAY	3	9	2010-09-30	37573	59217	\N	\N
70262	SPECIFIC_DAY	3	9	2010-07-29	37573	59217	\N	\N
70263	SPECIFIC_DAY	3	9	2010-11-22	37573	59217	\N	\N
70264	SPECIFIC_DAY	3	9	2010-04-30	37573	59217	\N	\N
70265	SPECIFIC_DAY	3	0	2010-09-25	37573	59217	\N	\N
70266	SPECIFIC_DAY	3	9	2010-02-22	37573	59217	\N	\N
70267	SPECIFIC_DAY	3	9	2010-11-09	37573	59217	\N	\N
70268	SPECIFIC_DAY	3	9	2010-06-08	37573	59217	\N	\N
70269	SPECIFIC_DAY	3	9	2010-02-01	37573	59217	\N	\N
70270	SPECIFIC_DAY	3	9	2010-03-22	37573	59217	\N	\N
70271	SPECIFIC_DAY	3	9	2011-01-06	37573	59217	\N	\N
70272	SPECIFIC_DAY	3	9	2010-11-29	37573	59217	\N	\N
70273	SPECIFIC_DAY	3	9	2010-07-14	37573	59217	\N	\N
70274	SPECIFIC_DAY	3	9	2010-07-27	37573	59217	\N	\N
70275	SPECIFIC_DAY	3	9	2010-01-27	37573	59217	\N	\N
70276	SPECIFIC_DAY	3	0	2010-11-28	37573	59217	\N	\N
70277	SPECIFIC_DAY	3	9	2011-01-26	37573	59217	\N	\N
70278	SPECIFIC_DAY	3	9	2010-03-01	37573	59217	\N	\N
70279	SPECIFIC_DAY	3	0	2010-03-06	37573	59217	\N	\N
70280	SPECIFIC_DAY	3	9	2010-02-16	37573	59217	\N	\N
70281	SPECIFIC_DAY	3	9	2010-11-26	37573	59217	\N	\N
70282	SPECIFIC_DAY	3	9	2010-07-05	37573	59217	\N	\N
70283	SPECIFIC_DAY	3	0	2010-09-04	37573	59217	\N	\N
70284	SPECIFIC_DAY	3	9	2010-09-22	37573	59217	\N	\N
70285	SPECIFIC_DAY	3	9	2010-05-31	37573	59217	\N	\N
70286	SPECIFIC_DAY	3	9	2011-01-13	37573	59217	\N	\N
70287	SPECIFIC_DAY	3	9	2010-07-19	37573	59217	\N	\N
70288	SPECIFIC_DAY	3	0	2010-07-10	37573	59217	\N	\N
70289	SPECIFIC_DAY	3	9	2010-06-17	37573	59217	\N	\N
70290	SPECIFIC_DAY	3	9	2010-04-29	37573	59217	\N	\N
70291	SPECIFIC_DAY	3	9	2010-06-07	37573	59217	\N	\N
70292	SPECIFIC_DAY	3	9	2010-12-28	37573	59217	\N	\N
70293	SPECIFIC_DAY	3	9	2010-02-24	37573	59217	\N	\N
70294	SPECIFIC_DAY	3	9	2010-02-15	37573	59217	\N	\N
70295	SPECIFIC_DAY	3	9	2011-01-03	37573	59217	\N	\N
70296	SPECIFIC_DAY	3	0	2010-04-10	37573	59217	\N	\N
70297	SPECIFIC_DAY	3	9	2011-01-17	37573	59217	\N	\N
70298	SPECIFIC_DAY	3	0	2010-02-13	37573	59217	\N	\N
70299	SPECIFIC_DAY	3	9	2011-01-04	37573	59217	\N	\N
70300	SPECIFIC_DAY	3	9	2010-12-10	37573	59217	\N	\N
70301	SPECIFIC_DAY	3	0	2011-03-05	37573	59217	\N	\N
70302	SPECIFIC_DAY	3	9	2010-07-23	37573	59217	\N	\N
70303	SPECIFIC_DAY	3	9	2010-12-24	37573	59217	\N	\N
70304	SPECIFIC_DAY	3	9	2010-12-16	37573	59217	\N	\N
70305	SPECIFIC_DAY	3	9	2010-10-18	37573	59217	\N	\N
70306	SPECIFIC_DAY	3	9	2010-12-27	37573	59217	\N	\N
70307	SPECIFIC_DAY	3	9	2010-07-02	37573	59217	\N	\N
70308	SPECIFIC_DAY	3	0	2010-09-18	49309	68681	\N	\N
70309	SPECIFIC_DAY	3	7	2010-09-16	49309	68681	\N	\N
70310	SPECIFIC_DAY	3	7	2010-09-20	49309	68681	\N	\N
70311	SPECIFIC_DAY	3	7	2010-09-15	49309	68681	\N	\N
70312	SPECIFIC_DAY	3	0	2010-09-11	49309	68681	\N	\N
70313	SPECIFIC_DAY	3	7	2010-09-21	49309	68681	\N	\N
70314	SPECIFIC_DAY	3	7	2010-09-14	49309	68681	\N	\N
70315	SPECIFIC_DAY	3	7	2010-09-17	49309	68681	\N	\N
70316	SPECIFIC_DAY	3	0	2010-09-19	49309	68681	\N	\N
70317	SPECIFIC_DAY	3	7	2010-09-13	49309	68681	\N	\N
70318	SPECIFIC_DAY	3	0	2010-09-12	49309	68681	\N	\N
70319	SPECIFIC_DAY	3	4	2010-01-29	49300	68682	\N	\N
70320	SPECIFIC_DAY	3	0	2011-04-02	37573	60440	\N	\N
70321	SPECIFIC_DAY	3	7	2011-04-06	37573	60440	\N	\N
70322	SPECIFIC_DAY	3	7	2011-03-22	37573	60440	\N	\N
70323	SPECIFIC_DAY	3	7	2011-04-05	37573	60440	\N	\N
70324	SPECIFIC_DAY	3	7	2011-03-31	37573	60440	\N	\N
70325	SPECIFIC_DAY	3	7	2011-03-18	37573	60440	\N	\N
70326	SPECIFIC_DAY	3	0	2011-03-19	37573	60440	\N	\N
70327	SPECIFIC_DAY	3	7	2011-04-04	37573	60440	\N	\N
70328	SPECIFIC_DAY	3	0	2011-03-20	37573	60440	\N	\N
70329	SPECIFIC_DAY	3	0	2011-04-03	37573	60440	\N	\N
70330	SPECIFIC_DAY	3	7	2011-03-25	37573	60440	\N	\N
70331	SPECIFIC_DAY	3	7	2011-03-21	37573	60440	\N	\N
70332	SPECIFIC_DAY	3	0	2011-03-26	37573	60440	\N	\N
70333	SPECIFIC_DAY	3	7	2011-03-23	37573	60440	\N	\N
70334	SPECIFIC_DAY	3	7	2011-03-24	37573	60440	\N	\N
70335	SPECIFIC_DAY	3	7	2011-03-29	37573	60440	\N	\N
70336	SPECIFIC_DAY	3	0	2011-03-27	37573	60440	\N	\N
70337	SPECIFIC_DAY	3	7	2011-03-30	37573	60440	\N	\N
70338	SPECIFIC_DAY	3	7	2011-04-01	37573	60440	\N	\N
70339	SPECIFIC_DAY	3	7	2011-03-28	37573	60440	\N	\N
70340	SPECIFIC_DAY	3	0	2011-05-07	37573	60441	\N	\N
70341	SPECIFIC_DAY	3	0	2011-04-10	37573	60441	\N	\N
70342	SPECIFIC_DAY	3	7	2011-05-13	37573	60441	\N	\N
70343	SPECIFIC_DAY	3	7	2011-04-12	37573	60441	\N	\N
70344	SPECIFIC_DAY	3	7	2011-04-13	37573	60441	\N	\N
70345	SPECIFIC_DAY	3	7	2011-04-18	37573	60441	\N	\N
70346	SPECIFIC_DAY	3	7	2011-04-20	37573	60441	\N	\N
70347	SPECIFIC_DAY	3	7	2011-05-10	37573	60441	\N	\N
70348	SPECIFIC_DAY	3	7	2011-05-05	37573	60441	\N	\N
70349	SPECIFIC_DAY	3	7	2011-04-29	37573	60441	\N	\N
70350	SPECIFIC_DAY	3	7	2011-04-07	37573	60441	\N	\N
70351	SPECIFIC_DAY	3	7	2011-04-27	37573	60441	\N	\N
70352	SPECIFIC_DAY	3	7	2011-04-22	37573	60441	\N	\N
70353	SPECIFIC_DAY	3	7	2011-05-03	37573	60441	\N	\N
70354	SPECIFIC_DAY	3	0	2011-04-09	37573	60441	\N	\N
70355	SPECIFIC_DAY	3	7	2011-05-16	37573	60441	\N	\N
70356	SPECIFIC_DAY	3	0	2011-04-17	37573	60441	\N	\N
70357	SPECIFIC_DAY	3	7	2011-04-19	37573	60441	\N	\N
70358	SPECIFIC_DAY	3	0	2011-04-16	37573	60441	\N	\N
70359	SPECIFIC_DAY	3	0	2011-05-01	37573	60441	\N	\N
70360	SPECIFIC_DAY	3	0	2011-04-24	37573	60441	\N	\N
70361	SPECIFIC_DAY	3	7	2011-05-06	37573	60441	\N	\N
70362	SPECIFIC_DAY	3	7	2011-04-26	37573	60441	\N	\N
70363	SPECIFIC_DAY	3	0	2011-05-15	37573	60441	\N	\N
70364	SPECIFIC_DAY	3	7	2011-05-04	37573	60441	\N	\N
70365	SPECIFIC_DAY	3	7	2011-04-11	37573	60441	\N	\N
70366	SPECIFIC_DAY	3	0	2011-05-14	37573	60441	\N	\N
70367	SPECIFIC_DAY	3	7	2011-05-02	37573	60441	\N	\N
70368	SPECIFIC_DAY	3	7	2011-05-09	37573	60441	\N	\N
70369	SPECIFIC_DAY	3	7	2011-04-08	37573	60441	\N	\N
70370	SPECIFIC_DAY	3	7	2011-04-15	37573	60441	\N	\N
70371	SPECIFIC_DAY	3	7	2011-04-21	37573	60441	\N	\N
70372	SPECIFIC_DAY	3	7	2011-04-25	37573	60441	\N	\N
70373	SPECIFIC_DAY	3	0	2011-05-08	37573	60441	\N	\N
70374	SPECIFIC_DAY	3	7	2011-05-11	37573	60441	\N	\N
70375	SPECIFIC_DAY	3	0	2011-04-30	37573	60441	\N	\N
70376	SPECIFIC_DAY	3	7	2011-04-28	37573	60441	\N	\N
70377	SPECIFIC_DAY	3	7	2011-04-14	37573	60441	\N	\N
70378	SPECIFIC_DAY	3	0	2011-04-23	37573	60441	\N	\N
70379	SPECIFIC_DAY	3	7	2011-05-12	37573	60441	\N	\N
70380	SPECIFIC_DAY	3	82	2011-05-17	37573	60442	\N	\N
70381	SPECIFIC_DAY	3	82	2011-05-18	37573	60442	\N	\N
70382	SPECIFIC_DAY	3	81	2011-05-19	37573	60442	\N	\N
70383	SPECIFIC_DAY	3	30	2011-05-21	37573	60443	\N	\N
70384	SPECIFIC_DAY	3	30	2011-05-22	37573	60443	\N	\N
70385	SPECIFIC_DAY	3	38	2011-05-20	37573	60443	\N	\N
70386	SPECIFIC_DAY	3	65	2011-05-24	37573	60444	\N	\N
70387	SPECIFIC_DAY	3	66	2011-05-23	37573	60444	\N	\N
70388	SPECIFIC_DAY	3	65	2011-05-25	37573	60444	\N	\N
70389	SPECIFIC_DAY	3	0	2010-06-26	40199	59220	\N	\N
70390	SPECIFIC_DAY	3	7	2010-04-15	40199	59220	\N	\N
70391	SPECIFIC_DAY	3	7	2009-12-24	40199	59220	\N	\N
70392	SPECIFIC_DAY	3	0	2010-08-22	40199	59220	\N	\N
70393	SPECIFIC_DAY	3	7	2010-08-11	40199	59220	\N	\N
70394	SPECIFIC_DAY	3	0	2010-01-24	40199	59220	\N	\N
70395	SPECIFIC_DAY	3	7	2010-07-15	40199	59220	\N	\N
70396	SPECIFIC_DAY	3	7	2010-07-27	40199	59220	\N	\N
70397	SPECIFIC_DAY	3	7	2010-06-21	40199	59220	\N	\N
70398	SPECIFIC_DAY	3	7	2010-06-02	40199	59220	\N	\N
70399	SPECIFIC_DAY	3	7	2010-07-01	40199	59220	\N	\N
70400	SPECIFIC_DAY	3	7	2010-05-07	40199	59220	\N	\N
70401	SPECIFIC_DAY	3	7	2010-02-10	40199	59220	\N	\N
70402	SPECIFIC_DAY	3	7	2010-02-23	40199	59220	\N	\N
70403	SPECIFIC_DAY	3	0	2010-09-05	40199	59220	\N	\N
70404	SPECIFIC_DAY	3	7	2010-02-19	40199	59220	\N	\N
70405	SPECIFIC_DAY	3	7	2010-05-28	40199	59220	\N	\N
70406	SPECIFIC_DAY	3	7	2010-02-01	40199	59220	\N	\N
70407	SPECIFIC_DAY	3	7	2010-09-07	40199	59220	\N	\N
70408	SPECIFIC_DAY	3	7	2010-04-09	40199	59220	\N	\N
70409	SPECIFIC_DAY	3	0	2010-09-04	40199	59220	\N	\N
70410	SPECIFIC_DAY	3	7	2010-04-22	40199	59220	\N	\N
70411	SPECIFIC_DAY	3	0	2010-07-31	40199	59220	\N	\N
70412	SPECIFIC_DAY	3	0	2009-12-25	40199	59220	\N	\N
70413	SPECIFIC_DAY	3	7	2010-04-28	40199	59220	\N	\N
70414	SPECIFIC_DAY	3	0	2010-07-11	40199	59220	\N	\N
70415	SPECIFIC_DAY	3	7	2010-05-14	40199	59220	\N	\N
70416	SPECIFIC_DAY	3	7	2010-02-22	40199	59220	\N	\N
70417	SPECIFIC_DAY	3	0	2010-08-21	40199	59220	\N	\N
70418	SPECIFIC_DAY	3	7	2010-05-12	40199	59220	\N	\N
70419	SPECIFIC_DAY	3	7	2010-07-23	40199	59220	\N	\N
70420	SPECIFIC_DAY	3	7	2010-08-23	40199	59220	\N	\N
70421	SPECIFIC_DAY	3	7	2010-02-05	40199	59220	\N	\N
70422	SPECIFIC_DAY	3	0	2010-04-02	40199	59220	\N	\N
70423	SPECIFIC_DAY	3	7	2010-05-27	40199	59220	\N	\N
70424	SPECIFIC_DAY	3	7	2010-03-02	40199	59220	\N	\N
70425	SPECIFIC_DAY	3	7	2010-08-27	40199	59220	\N	\N
70426	SPECIFIC_DAY	3	7	2010-09-08	40199	59220	\N	\N
70427	SPECIFIC_DAY	3	7	2010-01-25	40199	59220	\N	\N
70428	SPECIFIC_DAY	3	7	2010-03-12	40199	59220	\N	\N
70429	SPECIFIC_DAY	3	7	2010-02-12	40199	59220	\N	\N
70430	SPECIFIC_DAY	3	7	2010-02-25	40199	59220	\N	\N
70431	SPECIFIC_DAY	3	7	2010-05-13	40199	59220	\N	\N
70432	SPECIFIC_DAY	3	7	2010-04-19	40199	59220	\N	\N
70433	SPECIFIC_DAY	3	7	2010-07-28	40199	59220	\N	\N
70434	SPECIFIC_DAY	3	0	2010-05-17	40199	59220	\N	\N
70435	SPECIFIC_DAY	3	7	2010-08-17	40199	59220	\N	\N
70436	SPECIFIC_DAY	3	0	2010-03-20	40199	59220	\N	\N
70437	SPECIFIC_DAY	3	0	2010-05-01	40199	59220	\N	\N
70438	SPECIFIC_DAY	3	7	2010-08-02	40199	59220	\N	\N
70439	SPECIFIC_DAY	3	0	2009-12-19	40199	59220	\N	\N
70440	SPECIFIC_DAY	3	7	2010-06-04	40199	59220	\N	\N
70441	SPECIFIC_DAY	3	0	2010-04-24	40199	59220	\N	\N
70442	SPECIFIC_DAY	3	7	2010-02-03	40199	59220	\N	\N
70443	SPECIFIC_DAY	3	7	2010-08-31	40199	59220	\N	\N
70444	SPECIFIC_DAY	3	7	2010-03-10	40199	59220	\N	\N
70445	SPECIFIC_DAY	3	0	2010-01-03	40199	59220	\N	\N
70446	SPECIFIC_DAY	3	7	2010-09-06	40199	59220	\N	\N
70447	SPECIFIC_DAY	3	0	2010-06-13	40199	59220	\N	\N
70448	SPECIFIC_DAY	3	7	2010-05-19	40199	59220	\N	\N
70449	SPECIFIC_DAY	3	7	2010-06-24	40199	59220	\N	\N
70450	SPECIFIC_DAY	3	7	2010-08-09	40199	59220	\N	\N
70451	SPECIFIC_DAY	3	7	2010-08-06	40199	59220	\N	\N
70452	SPECIFIC_DAY	3	0	2010-01-30	40199	59220	\N	\N
70453	SPECIFIC_DAY	3	7	2010-01-29	40199	59220	\N	\N
70454	SPECIFIC_DAY	3	0	2010-08-28	40199	59220	\N	\N
70455	SPECIFIC_DAY	3	0	2010-03-13	40199	59220	\N	\N
70456	SPECIFIC_DAY	3	0	2010-07-17	40199	59220	\N	\N
70457	SPECIFIC_DAY	3	7	2010-02-16	40199	59220	\N	\N
70458	SPECIFIC_DAY	3	7	2010-08-20	40199	59220	\N	\N
70459	SPECIFIC_DAY	3	0	2010-02-13	40199	59220	\N	\N
70460	SPECIFIC_DAY	3	7	2010-05-26	40199	59220	\N	\N
70461	SPECIFIC_DAY	3	0	2010-06-19	40199	59220	\N	\N
70462	SPECIFIC_DAY	3	7	2010-01-15	40199	59220	\N	\N
70463	SPECIFIC_DAY	3	7	2010-04-12	40199	59220	\N	\N
70464	SPECIFIC_DAY	3	0	2010-01-17	40199	59220	\N	\N
70465	SPECIFIC_DAY	3	0	2010-05-16	40199	59220	\N	\N
70466	SPECIFIC_DAY	3	7	2010-05-03	40199	59220	\N	\N
70467	SPECIFIC_DAY	3	0	2010-02-21	40199	59220	\N	\N
70468	SPECIFIC_DAY	3	7	2010-06-10	40199	59220	\N	\N
70469	SPECIFIC_DAY	3	7	2010-01-11	40199	59220	\N	\N
70470	SPECIFIC_DAY	3	7	2010-06-18	40199	59220	\N	\N
70471	SPECIFIC_DAY	3	7	2010-05-06	40199	59220	\N	\N
70472	SPECIFIC_DAY	3	7	2010-02-04	40199	59220	\N	\N
70473	SPECIFIC_DAY	3	0	2010-01-23	40199	59220	\N	\N
70474	SPECIFIC_DAY	3	7	2010-03-01	40199	59220	\N	\N
70475	SPECIFIC_DAY	3	7	2010-04-26	40199	59220	\N	\N
70476	SPECIFIC_DAY	3	7	2010-04-07	40199	59220	\N	\N
70477	SPECIFIC_DAY	3	0	2010-07-24	40199	59220	\N	\N
70478	SPECIFIC_DAY	3	0	2010-04-11	40199	59220	\N	\N
70479	SPECIFIC_DAY	3	0	2010-05-29	40199	59220	\N	\N
70480	SPECIFIC_DAY	3	7	2010-04-27	40199	59220	\N	\N
70481	SPECIFIC_DAY	3	7	2010-01-18	40199	59220	\N	\N
70482	SPECIFIC_DAY	3	0	2009-12-27	40199	59220	\N	\N
70483	SPECIFIC_DAY	3	7	2010-08-30	40199	59220	\N	\N
70484	SPECIFIC_DAY	3	0	2010-03-07	40199	59220	\N	\N
70485	SPECIFIC_DAY	3	7	2010-05-21	40199	59220	\N	\N
70486	SPECIFIC_DAY	3	0	2010-07-10	40199	59220	\N	\N
70487	SPECIFIC_DAY	3	7	2010-05-04	40199	59220	\N	\N
70488	SPECIFIC_DAY	3	0	2010-01-02	40199	59220	\N	\N
70489	SPECIFIC_DAY	3	7	2010-07-30	40199	59220	\N	\N
70490	SPECIFIC_DAY	3	0	2010-05-02	40199	59220	\N	\N
70491	SPECIFIC_DAY	3	7	2010-02-24	40199	59220	\N	\N
70492	SPECIFIC_DAY	3	0	2010-04-01	40199	59220	\N	\N
70493	SPECIFIC_DAY	3	7	2010-03-04	40199	59220	\N	\N
70494	SPECIFIC_DAY	3	0	2010-06-20	40199	59220	\N	\N
70495	SPECIFIC_DAY	3	0	2010-04-03	40199	59220	\N	\N
70496	SPECIFIC_DAY	3	7	2010-04-08	40199	59220	\N	\N
70497	SPECIFIC_DAY	3	7	2010-06-09	40199	59220	\N	\N
70498	SPECIFIC_DAY	3	0	2010-01-10	40199	59220	\N	\N
70499	SPECIFIC_DAY	3	0	2010-05-30	40199	59220	\N	\N
70500	SPECIFIC_DAY	3	7	2010-07-12	40199	59220	\N	\N
70501	SPECIFIC_DAY	3	0	2010-01-06	40199	59220	\N	\N
70502	SPECIFIC_DAY	3	7	2010-03-08	40199	59220	\N	\N
70503	SPECIFIC_DAY	3	0	2010-03-27	40199	59220	\N	\N
70504	SPECIFIC_DAY	3	7	2010-03-09	40199	59220	\N	\N
70505	SPECIFIC_DAY	3	7	2010-06-28	40199	59220	\N	\N
70506	SPECIFIC_DAY	3	0	2010-02-28	40199	59220	\N	\N
70507	SPECIFIC_DAY	3	7	2010-07-06	40199	59220	\N	\N
70508	SPECIFIC_DAY	3	7	2010-04-21	40199	59220	\N	\N
70509	SPECIFIC_DAY	3	7	2010-08-24	40199	59220	\N	\N
70510	SPECIFIC_DAY	3	7	2010-03-24	40199	59220	\N	\N
70511	SPECIFIC_DAY	3	0	2010-08-01	40199	59220	\N	\N
70512	SPECIFIC_DAY	3	7	2010-03-23	40199	59220	\N	\N
70513	SPECIFIC_DAY	3	7	2010-03-29	40199	59220	\N	\N
70514	SPECIFIC_DAY	3	7	2010-07-22	40199	59220	\N	\N
70515	SPECIFIC_DAY	3	0	2010-07-18	40199	59220	\N	\N
70516	SPECIFIC_DAY	3	7	2010-07-29	40199	59220	\N	\N
70517	SPECIFIC_DAY	3	7	2009-12-22	40199	59220	\N	\N
70518	SPECIFIC_DAY	3	0	2010-02-14	40199	59220	\N	\N
70519	SPECIFIC_DAY	3	0	2009-12-31	40199	59220	\N	\N
70520	SPECIFIC_DAY	3	7	2010-06-25	40199	59220	\N	\N
70521	SPECIFIC_DAY	3	7	2010-07-02	40199	59220	\N	\N
70522	SPECIFIC_DAY	3	7	2010-06-17	40199	59220	\N	\N
70523	SPECIFIC_DAY	3	7	2010-04-23	40199	59220	\N	\N
70524	SPECIFIC_DAY	3	7	2010-08-04	40199	59220	\N	\N
70525	SPECIFIC_DAY	3	7	2010-04-13	40199	59220	\N	\N
70526	SPECIFIC_DAY	3	0	2010-03-28	40199	59220	\N	\N
70527	SPECIFIC_DAY	3	7	2010-01-12	40199	59220	\N	\N
70528	SPECIFIC_DAY	3	7	2010-01-20	40199	59220	\N	\N
70529	SPECIFIC_DAY	3	7	2010-01-08	40199	59220	\N	\N
70530	SPECIFIC_DAY	3	7	2010-03-22	40199	59220	\N	\N
70531	SPECIFIC_DAY	3	7	2010-08-05	40199	59220	\N	\N
70532	SPECIFIC_DAY	3	7	2010-05-24	40199	59220	\N	\N
70533	SPECIFIC_DAY	3	0	2010-07-04	40199	59220	\N	\N
70534	SPECIFIC_DAY	3	7	2010-07-08	40199	59220	\N	\N
70535	SPECIFIC_DAY	3	0	2009-12-20	40199	59220	\N	\N
70536	SPECIFIC_DAY	3	7	2010-01-19	40199	59220	\N	\N
70537	SPECIFIC_DAY	3	7	2010-06-07	40199	59220	\N	\N
70538	SPECIFIC_DAY	3	7	2009-12-21	40199	59220	\N	\N
70539	SPECIFIC_DAY	3	0	2010-03-19	40199	59220	\N	\N
70540	SPECIFIC_DAY	3	0	2009-12-29	40199	59220	\N	\N
70541	SPECIFIC_DAY	3	7	2010-08-12	40199	59220	\N	\N
70542	SPECIFIC_DAY	3	0	2010-08-15	40199	59220	\N	\N
70543	SPECIFIC_DAY	3	7	2010-04-20	40199	59220	\N	\N
70544	SPECIFIC_DAY	3	0	2010-02-27	40199	59220	\N	\N
70545	SPECIFIC_DAY	3	7	2010-06-23	40199	59220	\N	\N
70546	SPECIFIC_DAY	3	7	2010-07-07	40199	59220	\N	\N
70547	SPECIFIC_DAY	3	0	2009-12-30	40199	59220	\N	\N
70548	SPECIFIC_DAY	3	0	2010-02-06	40199	59220	\N	\N
70549	SPECIFIC_DAY	3	0	2010-05-09	40199	59220	\N	\N
70550	SPECIFIC_DAY	3	0	2010-04-10	40199	59220	\N	\N
70551	SPECIFIC_DAY	3	0	2010-06-06	40199	59220	\N	\N
70552	SPECIFIC_DAY	3	0	2010-03-06	40199	59220	\N	\N
70553	SPECIFIC_DAY	3	7	2010-07-05	40199	59220	\N	\N
70554	SPECIFIC_DAY	3	0	2010-02-17	40199	59220	\N	\N
70555	SPECIFIC_DAY	3	7	2010-06-03	40199	59220	\N	\N
70556	SPECIFIC_DAY	3	7	2010-06-01	40199	59220	\N	\N
70557	SPECIFIC_DAY	3	7	2010-01-27	40199	59220	\N	\N
70558	SPECIFIC_DAY	3	7	2010-04-14	40199	59220	\N	\N
70559	SPECIFIC_DAY	3	7	2010-07-26	40199	59220	\N	\N
70560	SPECIFIC_DAY	3	0	2010-04-04	40199	59220	\N	\N
70561	SPECIFIC_DAY	3	0	2010-06-27	40199	59220	\N	\N
70562	SPECIFIC_DAY	3	7	2010-05-20	40199	59220	\N	\N
70563	SPECIFIC_DAY	3	7	2010-03-18	40199	59220	\N	\N
70564	SPECIFIC_DAY	3	7	2010-01-21	40199	59220	\N	\N
70565	SPECIFIC_DAY	3	7	2010-02-26	40199	59220	\N	\N
70566	SPECIFIC_DAY	3	7	2009-12-17	40199	59220	\N	\N
70567	SPECIFIC_DAY	3	7	2010-02-18	40199	59220	\N	\N
70568	SPECIFIC_DAY	3	7	2010-08-16	40199	59220	\N	\N
70569	SPECIFIC_DAY	3	7	2010-01-26	40199	59220	\N	\N
70570	SPECIFIC_DAY	3	0	2010-05-23	40199	59220	\N	\N
70571	SPECIFIC_DAY	3	7	2010-05-25	40199	59220	\N	\N
70572	SPECIFIC_DAY	3	7	2010-01-05	40199	59220	\N	\N
70573	SPECIFIC_DAY	3	7	2010-06-30	40199	59220	\N	\N
70574	SPECIFIC_DAY	3	0	2010-06-12	40199	59220	\N	\N
70575	SPECIFIC_DAY	3	7	2010-09-02	40199	59220	\N	\N
70576	SPECIFIC_DAY	3	7	2010-02-15	40199	59220	\N	\N
70577	SPECIFIC_DAY	3	0	2010-07-25	40199	59220	\N	\N
70578	SPECIFIC_DAY	3	7	2010-05-10	40199	59220	\N	\N
70579	SPECIFIC_DAY	3	7	2010-03-05	40199	59220	\N	\N
70580	SPECIFIC_DAY	3	7	2010-08-19	40199	59220	\N	\N
70581	SPECIFIC_DAY	3	0	2009-12-26	40199	59220	\N	\N
70582	SPECIFIC_DAY	3	7	2010-03-26	40199	59220	\N	\N
70583	SPECIFIC_DAY	3	7	2010-03-17	40199	59220	\N	\N
70584	SPECIFIC_DAY	3	0	2010-06-05	40199	59220	\N	\N
70585	SPECIFIC_DAY	3	7	2010-08-10	40199	59220	\N	\N
70586	SPECIFIC_DAY	3	7	2010-05-11	40199	59220	\N	\N
70587	SPECIFIC_DAY	3	0	2010-04-05	40199	59220	\N	\N
70588	SPECIFIC_DAY	3	0	2010-03-14	40199	59220	\N	\N
70589	SPECIFIC_DAY	3	0	2010-08-14	40199	59220	\N	\N
70590	SPECIFIC_DAY	3	7	2010-08-03	40199	59220	\N	\N
70591	SPECIFIC_DAY	3	7	2010-06-22	40199	59220	\N	\N
70592	SPECIFIC_DAY	3	0	2010-02-07	40199	59220	\N	\N
70593	SPECIFIC_DAY	3	7	2010-02-09	40199	59220	\N	\N
70594	SPECIFIC_DAY	3	7	2010-05-18	40199	59220	\N	\N
70595	SPECIFIC_DAY	3	7	2010-07-16	40199	59220	\N	\N
70596	SPECIFIC_DAY	3	7	2010-07-09	40199	59220	\N	\N
70597	SPECIFIC_DAY	3	7	2010-03-16	40199	59220	\N	\N
70598	SPECIFIC_DAY	3	7	2010-07-20	40199	59220	\N	\N
70599	SPECIFIC_DAY	3	7	2010-06-16	40199	59220	\N	\N
70600	SPECIFIC_DAY	3	7	2010-03-31	40199	59220	\N	\N
70601	SPECIFIC_DAY	3	0	2009-12-28	40199	59220	\N	\N
70602	SPECIFIC_DAY	3	7	2010-01-28	40199	59220	\N	\N
70603	SPECIFIC_DAY	3	7	2010-04-06	40199	59220	\N	\N
70604	SPECIFIC_DAY	3	7	2010-04-30	40199	59220	\N	\N
70605	SPECIFIC_DAY	3	7	2010-02-02	40199	59220	\N	\N
70606	SPECIFIC_DAY	3	7	2010-02-08	40199	59220	\N	\N
70607	SPECIFIC_DAY	3	7	2010-03-11	40199	59220	\N	\N
70608	SPECIFIC_DAY	3	7	2009-12-18	40199	59220	\N	\N
70609	SPECIFIC_DAY	3	7	2010-06-15	40199	59220	\N	\N
70610	SPECIFIC_DAY	3	7	2010-06-29	40199	59220	\N	\N
70611	SPECIFIC_DAY	3	7	2010-06-08	40199	59220	\N	\N
70612	SPECIFIC_DAY	3	7	2010-08-18	40199	59220	\N	\N
70613	SPECIFIC_DAY	3	7	2009-12-15	40199	59220	\N	\N
70614	SPECIFIC_DAY	3	7	2010-01-13	40199	59220	\N	\N
70615	SPECIFIC_DAY	3	0	2010-01-01	40199	59220	\N	\N
70616	SPECIFIC_DAY	3	0	2010-03-21	40199	59220	\N	\N
70617	SPECIFIC_DAY	3	7	2010-08-25	40199	59220	\N	\N
70618	SPECIFIC_DAY	3	7	2010-09-01	40199	59220	\N	\N
70619	SPECIFIC_DAY	3	7	2010-01-07	40199	59220	\N	\N
70620	SPECIFIC_DAY	3	7	2010-07-13	40199	59220	\N	\N
70621	SPECIFIC_DAY	3	7	2010-04-29	40199	59220	\N	\N
70622	SPECIFIC_DAY	3	0	2010-01-16	40199	59220	\N	\N
70623	SPECIFIC_DAY	3	7	2010-07-19	40199	59220	\N	\N
70624	SPECIFIC_DAY	3	0	2010-04-17	40199	59220	\N	\N
70625	SPECIFIC_DAY	3	7	2010-06-11	40199	59220	\N	\N
70626	SPECIFIC_DAY	3	0	2010-05-22	40199	59220	\N	\N
70627	SPECIFIC_DAY	3	0	2010-05-08	40199	59220	\N	\N
70628	SPECIFIC_DAY	3	0	2010-08-08	40199	59220	\N	\N
70629	SPECIFIC_DAY	3	7	2010-01-04	40199	59220	\N	\N
70630	SPECIFIC_DAY	3	0	2010-04-18	40199	59220	\N	\N
70631	SPECIFIC_DAY	3	0	2010-01-31	40199	59220	\N	\N
70632	SPECIFIC_DAY	3	7	2010-08-13	40199	59220	\N	\N
70633	SPECIFIC_DAY	3	7	2010-03-15	40199	59220	\N	\N
70634	SPECIFIC_DAY	3	0	2010-05-15	40199	59220	\N	\N
70635	SPECIFIC_DAY	3	7	2010-06-14	40199	59220	\N	\N
70636	SPECIFIC_DAY	3	7	2010-07-21	40199	59220	\N	\N
70637	SPECIFIC_DAY	3	0	2010-08-29	40199	59220	\N	\N
70638	SPECIFIC_DAY	3	0	2010-08-07	40199	59220	\N	\N
70639	SPECIFIC_DAY	3	7	2010-03-03	40199	59220	\N	\N
70640	SPECIFIC_DAY	3	7	2010-05-31	40199	59220	\N	\N
70641	SPECIFIC_DAY	3	7	2010-07-14	40199	59220	\N	\N
70642	SPECIFIC_DAY	3	7	2010-08-26	40199	59220	\N	\N
70643	SPECIFIC_DAY	3	0	2010-07-03	40199	59220	\N	\N
70644	SPECIFIC_DAY	3	7	2010-01-14	40199	59220	\N	\N
70645	SPECIFIC_DAY	3	0	2010-01-09	40199	59220	\N	\N
70646	SPECIFIC_DAY	3	0	2010-02-20	40199	59220	\N	\N
70647	SPECIFIC_DAY	3	7	2010-01-22	40199	59220	\N	\N
70648	SPECIFIC_DAY	3	7	2010-05-05	40199	59220	\N	\N
70649	SPECIFIC_DAY	3	7	2010-03-30	40199	59220	\N	\N
70650	SPECIFIC_DAY	3	7	2010-04-16	40199	59220	\N	\N
70651	SPECIFIC_DAY	3	7	2010-02-11	40199	59220	\N	\N
70652	SPECIFIC_DAY	3	7	2010-09-03	40199	59220	\N	\N
70653	SPECIFIC_DAY	3	7	2009-12-16	40199	59220	\N	\N
70654	SPECIFIC_DAY	3	7	2009-12-23	40199	59220	\N	\N
70655	SPECIFIC_DAY	3	7	2010-09-09	40199	59220	\N	\N
70656	SPECIFIC_DAY	3	7	2010-03-25	40199	59220	\N	\N
70657	SPECIFIC_DAY	3	0	2010-04-25	40199	59220	\N	\N
70658	SPECIFIC_DAY	3	7	2010-11-02	40199	59221	\N	\N
70659	SPECIFIC_DAY	3	0	2011-03-12	40199	59221	\N	\N
70660	SPECIFIC_DAY	3	7	2010-12-15	40199	59221	\N	\N
70661	SPECIFIC_DAY	3	7	2011-01-27	40199	59221	\N	\N
70662	SPECIFIC_DAY	3	0	2010-12-11	40199	59221	\N	\N
70663	SPECIFIC_DAY	3	7	2010-12-16	40199	59221	\N	\N
70664	SPECIFIC_DAY	3	7	2011-02-22	40199	59221	\N	\N
70665	SPECIFIC_DAY	3	0	2011-01-16	40199	59221	\N	\N
70666	SPECIFIC_DAY	3	7	2010-10-08	40199	59221	\N	\N
70667	SPECIFIC_DAY	3	7	2010-10-01	40199	59221	\N	\N
70668	SPECIFIC_DAY	3	7	2010-11-05	40199	59221	\N	\N
70669	SPECIFIC_DAY	3	7	2010-10-07	40199	59221	\N	\N
70670	SPECIFIC_DAY	3	7	2011-03-02	40199	59221	\N	\N
70671	SPECIFIC_DAY	3	7	2010-11-23	40199	59221	\N	\N
70672	SPECIFIC_DAY	3	7	2011-04-04	40199	59221	\N	\N
70673	SPECIFIC_DAY	3	7	2011-03-29	40199	59221	\N	\N
70674	SPECIFIC_DAY	3	7	2010-10-05	40199	59221	\N	\N
70675	SPECIFIC_DAY	3	7	2010-12-30	40199	59221	\N	\N
70676	SPECIFIC_DAY	3	7	2011-02-01	40199	59221	\N	\N
70677	SPECIFIC_DAY	3	7	2010-10-19	40199	59221	\N	\N
70678	SPECIFIC_DAY	3	7	2011-04-19	40199	59221	\N	\N
70679	SPECIFIC_DAY	3	0	2011-03-13	40199	59221	\N	\N
70680	SPECIFIC_DAY	3	0	2010-10-02	40199	59221	\N	\N
70681	SPECIFIC_DAY	3	0	2010-11-07	40199	59221	\N	\N
70682	SPECIFIC_DAY	3	7	2011-03-07	40199	59221	\N	\N
70683	SPECIFIC_DAY	3	0	2011-02-05	40199	59221	\N	\N
70684	SPECIFIC_DAY	3	7	2010-11-30	40199	59221	\N	\N
70685	SPECIFIC_DAY	3	0	2011-01-30	40199	59221	\N	\N
70686	SPECIFIC_DAY	3	7	2011-02-15	40199	59221	\N	\N
70687	SPECIFIC_DAY	3	7	2011-01-21	40199	59221	\N	\N
70688	SPECIFIC_DAY	3	7	2010-09-10	40199	59221	\N	\N
70689	SPECIFIC_DAY	3	7	2010-12-29	40199	59221	\N	\N
70690	SPECIFIC_DAY	3	0	2011-02-27	40199	59221	\N	\N
70691	SPECIFIC_DAY	3	7	2011-03-25	40199	59221	\N	\N
70692	SPECIFIC_DAY	3	7	2010-09-21	40199	59221	\N	\N
70693	SPECIFIC_DAY	3	0	2011-04-30	40199	59221	\N	\N
70694	SPECIFIC_DAY	3	7	2011-03-04	40199	59221	\N	\N
70695	SPECIFIC_DAY	3	7	2010-10-26	40199	59221	\N	\N
70696	SPECIFIC_DAY	3	7	2011-03-18	40199	59221	\N	\N
70697	SPECIFIC_DAY	3	7	2011-05-06	40199	59221	\N	\N
70698	SPECIFIC_DAY	3	7	2011-04-27	40199	59221	\N	\N
70699	SPECIFIC_DAY	3	0	2010-11-27	40199	59221	\N	\N
70700	SPECIFIC_DAY	3	0	2010-09-26	40199	59221	\N	\N
70701	SPECIFIC_DAY	3	0	2010-11-14	40199	59221	\N	\N
70702	SPECIFIC_DAY	3	7	2011-04-13	40199	59221	\N	\N
70703	SPECIFIC_DAY	3	7	2011-01-06	40199	59221	\N	\N
70704	SPECIFIC_DAY	3	7	2010-09-23	40199	59221	\N	\N
70705	SPECIFIC_DAY	3	7	2010-10-15	40199	59221	\N	\N
70706	SPECIFIC_DAY	3	7	2010-12-28	40199	59221	\N	\N
70707	SPECIFIC_DAY	3	0	2010-09-18	40199	59221	\N	\N
70708	SPECIFIC_DAY	3	7	2010-09-24	40199	59221	\N	\N
70709	SPECIFIC_DAY	3	7	2010-10-20	40199	59221	\N	\N
70710	SPECIFIC_DAY	3	7	2011-03-31	40199	59221	\N	\N
70711	SPECIFIC_DAY	3	7	2011-03-28	40199	59221	\N	\N
70712	SPECIFIC_DAY	3	7	2011-01-05	40199	59221	\N	\N
70713	SPECIFIC_DAY	3	0	2011-01-08	40199	59221	\N	\N
70714	SPECIFIC_DAY	3	7	2011-01-04	40199	59221	\N	\N
70715	SPECIFIC_DAY	3	7	2010-10-06	40199	59221	\N	\N
70716	SPECIFIC_DAY	3	7	2011-02-24	40199	59221	\N	\N
70717	SPECIFIC_DAY	3	7	2011-03-22	40199	59221	\N	\N
70718	SPECIFIC_DAY	3	0	2010-12-19	40199	59221	\N	\N
70719	SPECIFIC_DAY	3	0	2011-05-22	40199	59221	\N	\N
70720	SPECIFIC_DAY	3	7	2011-04-05	40199	59221	\N	\N
70721	SPECIFIC_DAY	3	7	2010-12-13	40199	59221	\N	\N
70722	SPECIFIC_DAY	3	7	2011-01-19	40199	59221	\N	\N
70723	SPECIFIC_DAY	3	7	2011-02-02	40199	59221	\N	\N
70724	SPECIFIC_DAY	3	7	2011-02-18	40199	59221	\N	\N
70725	SPECIFIC_DAY	3	0	2010-09-12	40199	59221	\N	\N
70726	SPECIFIC_DAY	3	7	2010-11-29	40199	59221	\N	\N
70727	SPECIFIC_DAY	3	7	2010-12-14	40199	59221	\N	\N
70728	SPECIFIC_DAY	3	7	2010-11-15	40199	59221	\N	\N
70729	SPECIFIC_DAY	3	7	2011-03-21	40199	59221	\N	\N
70730	SPECIFIC_DAY	3	0	2011-03-27	40199	59221	\N	\N
70731	SPECIFIC_DAY	3	7	2011-01-18	40199	59221	\N	\N
70732	SPECIFIC_DAY	3	0	2011-02-13	40199	59221	\N	\N
70733	SPECIFIC_DAY	3	0	2010-10-12	40199	59221	\N	\N
70734	SPECIFIC_DAY	3	7	2010-10-28	40199	59221	\N	\N
70735	SPECIFIC_DAY	3	0	2011-04-24	40199	59221	\N	\N
70736	SPECIFIC_DAY	3	7	2010-10-18	40199	59221	\N	\N
70737	SPECIFIC_DAY	3	0	2011-01-01	40199	59221	\N	\N
70738	SPECIFIC_DAY	3	7	2010-11-03	40199	59221	\N	\N
70739	SPECIFIC_DAY	3	0	2011-03-05	40199	59221	\N	\N
70740	SPECIFIC_DAY	3	7	2011-03-15	40199	59221	\N	\N
70741	SPECIFIC_DAY	3	7	2011-04-28	40199	59221	\N	\N
70742	SPECIFIC_DAY	3	7	2010-12-22	40199	59221	\N	\N
70743	SPECIFIC_DAY	3	7	2011-02-23	40199	59221	\N	\N
70744	SPECIFIC_DAY	3	7	2011-04-12	40199	59221	\N	\N
70745	SPECIFIC_DAY	3	7	2010-09-30	40199	59221	\N	\N
70746	SPECIFIC_DAY	3	7	2010-09-17	40199	59221	\N	\N
70747	SPECIFIC_DAY	3	7	2010-11-25	40199	59221	\N	\N
70748	SPECIFIC_DAY	3	7	2011-04-26	40199	59221	\N	\N
70749	SPECIFIC_DAY	3	7	2010-12-31	40199	59221	\N	\N
70750	SPECIFIC_DAY	3	7	2010-11-10	40199	59221	\N	\N
70751	SPECIFIC_DAY	3	7	2010-12-02	40199	59221	\N	\N
70752	SPECIFIC_DAY	3	7	2011-04-21	40199	59221	\N	\N
70753	SPECIFIC_DAY	3	0	2010-10-03	40199	59221	\N	\N
70754	SPECIFIC_DAY	3	7	2011-05-24	40199	59221	\N	\N
70755	SPECIFIC_DAY	3	0	2011-05-08	40199	59221	\N	\N
70756	SPECIFIC_DAY	3	0	2010-10-09	40199	59221	\N	\N
70757	SPECIFIC_DAY	3	7	2011-03-09	40199	59221	\N	\N
70758	SPECIFIC_DAY	3	0	2011-02-12	40199	59221	\N	\N
70759	SPECIFIC_DAY	3	7	2011-05-02	40199	59221	\N	\N
70760	SPECIFIC_DAY	3	0	2011-02-26	40199	59221	\N	\N
70761	SPECIFIC_DAY	3	0	2010-10-10	40199	59221	\N	\N
70762	SPECIFIC_DAY	3	7	2010-11-22	40199	59221	\N	\N
70763	SPECIFIC_DAY	3	7	2011-03-11	40199	59221	\N	\N
70764	SPECIFIC_DAY	3	0	2011-03-19	40199	59221	\N	\N
70765	SPECIFIC_DAY	3	7	2010-09-13	40199	59221	\N	\N
70766	SPECIFIC_DAY	3	7	2010-12-07	40199	59221	\N	\N
70767	SPECIFIC_DAY	3	0	2010-11-01	40199	59221	\N	\N
70768	SPECIFIC_DAY	3	7	2011-02-25	40199	59221	\N	\N
70769	SPECIFIC_DAY	3	7	2011-04-07	40199	59221	\N	\N
70770	SPECIFIC_DAY	3	7	2010-12-01	40199	59221	\N	\N
70771	SPECIFIC_DAY	3	7	2011-02-08	40199	59221	\N	\N
70772	SPECIFIC_DAY	3	7	2011-01-13	40199	59221	\N	\N
70773	SPECIFIC_DAY	3	0	2010-11-20	40199	59221	\N	\N
70774	SPECIFIC_DAY	3	0	2010-09-25	40199	59221	\N	\N
70775	SPECIFIC_DAY	3	7	2010-09-29	40199	59221	\N	\N
70776	SPECIFIC_DAY	3	0	2011-04-17	40199	59221	\N	\N
70777	SPECIFIC_DAY	3	7	2011-03-10	40199	59221	\N	\N
70778	SPECIFIC_DAY	3	7	2010-10-25	40199	59221	\N	\N
70779	SPECIFIC_DAY	3	7	2010-10-29	40199	59221	\N	\N
70780	SPECIFIC_DAY	3	7	2011-01-03	40199	59221	\N	\N
70781	SPECIFIC_DAY	3	7	2011-03-16	40199	59221	\N	\N
70782	SPECIFIC_DAY	3	7	2011-01-14	40199	59221	\N	\N
70783	SPECIFIC_DAY	3	7	2010-09-16	40199	59221	\N	\N
70784	SPECIFIC_DAY	3	7	2011-01-20	40199	59221	\N	\N
70785	SPECIFIC_DAY	3	7	2011-05-19	40199	59221	\N	\N
70786	SPECIFIC_DAY	3	0	2011-02-20	40199	59221	\N	\N
70787	SPECIFIC_DAY	3	7	2010-11-11	40199	59221	\N	\N
70788	SPECIFIC_DAY	3	7	2011-01-12	40199	59221	\N	\N
70789	SPECIFIC_DAY	3	7	2011-02-09	40199	59221	\N	\N
70790	SPECIFIC_DAY	3	7	2011-04-14	40199	59221	\N	\N
70791	SPECIFIC_DAY	3	0	2010-09-11	40199	59221	\N	\N
70792	SPECIFIC_DAY	3	7	2011-01-11	40199	59221	\N	\N
70793	SPECIFIC_DAY	3	0	2010-12-05	40199	59221	\N	\N
70794	SPECIFIC_DAY	3	7	2011-05-04	40199	59221	\N	\N
70795	SPECIFIC_DAY	3	0	2010-12-25	40199	59221	\N	\N
70796	SPECIFIC_DAY	3	7	2010-10-21	40199	59221	\N	\N
70797	SPECIFIC_DAY	3	7	2010-11-12	40199	59221	\N	\N
70798	SPECIFIC_DAY	3	7	2011-02-04	40199	59221	\N	\N
70799	SPECIFIC_DAY	3	7	2010-12-27	40199	59221	\N	\N
70800	SPECIFIC_DAY	3	7	2011-03-01	40199	59221	\N	\N
70801	SPECIFIC_DAY	3	7	2010-11-19	40199	59221	\N	\N
70802	SPECIFIC_DAY	3	7	2010-12-23	40199	59221	\N	\N
70803	SPECIFIC_DAY	3	7	2011-03-08	40199	59221	\N	\N
70804	SPECIFIC_DAY	3	7	2010-12-03	40199	59221	\N	\N
70805	SPECIFIC_DAY	3	0	2011-03-20	40199	59221	\N	\N
70806	SPECIFIC_DAY	3	7	2011-02-03	40199	59221	\N	\N
70807	SPECIFIC_DAY	3	7	2011-01-24	40199	59221	\N	\N
70808	SPECIFIC_DAY	3	7	2010-10-14	40199	59221	\N	\N
70809	SPECIFIC_DAY	3	7	2011-04-18	40199	59221	\N	\N
70810	SPECIFIC_DAY	3	0	2011-01-09	40199	59221	\N	\N
70811	SPECIFIC_DAY	3	7	2011-02-11	40199	59221	\N	\N
70812	SPECIFIC_DAY	3	7	2010-11-04	40199	59221	\N	\N
70813	SPECIFIC_DAY	3	7	2011-05-23	40199	59221	\N	\N
70814	SPECIFIC_DAY	3	0	2011-04-16	40199	59221	\N	\N
70815	SPECIFIC_DAY	3	7	2011-05-05	40199	59221	\N	\N
70816	SPECIFIC_DAY	3	7	2010-12-24	40199	59221	\N	\N
70817	SPECIFIC_DAY	3	7	2011-02-17	40199	59221	\N	\N
70818	SPECIFIC_DAY	3	7	2011-02-14	40199	59221	\N	\N
70819	SPECIFIC_DAY	3	7	2011-02-07	40199	59221	\N	\N
70820	SPECIFIC_DAY	3	7	2011-01-31	40199	59221	\N	\N
70821	SPECIFIC_DAY	3	7	2011-01-07	40199	59221	\N	\N
70822	SPECIFIC_DAY	3	7	2010-10-04	40199	59221	\N	\N
70823	SPECIFIC_DAY	3	0	2011-02-06	40199	59221	\N	\N
70824	SPECIFIC_DAY	3	7	2011-04-15	40199	59221	\N	\N
70825	SPECIFIC_DAY	3	7	2010-09-28	40199	59221	\N	\N
70826	SPECIFIC_DAY	3	0	2011-05-15	40199	59221	\N	\N
70827	SPECIFIC_DAY	3	7	2011-04-25	40199	59221	\N	\N
70828	SPECIFIC_DAY	3	7	2011-02-16	40199	59221	\N	\N
70829	SPECIFIC_DAY	3	0	2011-05-01	40199	59221	\N	\N
70830	SPECIFIC_DAY	3	0	2011-05-14	40199	59221	\N	\N
70831	SPECIFIC_DAY	3	7	2011-01-10	40199	59221	\N	\N
70832	SPECIFIC_DAY	3	0	2010-10-16	40199	59221	\N	\N
70833	SPECIFIC_DAY	3	7	2010-09-22	40199	59221	\N	\N
70834	SPECIFIC_DAY	3	7	2011-05-20	40199	59221	\N	\N
70835	SPECIFIC_DAY	3	0	2010-12-04	40199	59221	\N	\N
70836	SPECIFIC_DAY	3	7	2011-04-11	40199	59221	\N	\N
70837	SPECIFIC_DAY	3	0	2010-09-19	40199	59221	\N	\N
70838	SPECIFIC_DAY	3	0	2011-05-21	40199	59221	\N	\N
70839	SPECIFIC_DAY	3	7	2011-03-03	40199	59221	\N	\N
70840	SPECIFIC_DAY	3	0	2011-02-19	40199	59221	\N	\N
70841	SPECIFIC_DAY	3	7	2011-01-28	40199	59221	\N	\N
70842	SPECIFIC_DAY	3	7	2010-10-22	40199	59221	\N	\N
70843	SPECIFIC_DAY	3	0	2011-01-02	40199	59221	\N	\N
70844	SPECIFIC_DAY	3	7	2011-04-01	40199	59221	\N	\N
70845	SPECIFIC_DAY	3	7	2011-03-23	40199	59221	\N	\N
70846	SPECIFIC_DAY	3	7	2010-11-24	40199	59221	\N	\N
70847	SPECIFIC_DAY	3	7	2010-12-09	40199	59221	\N	\N
70848	SPECIFIC_DAY	3	0	2010-12-18	40199	59221	\N	\N
70849	SPECIFIC_DAY	3	7	2011-05-13	40199	59221	\N	\N
70850	SPECIFIC_DAY	3	7	2011-03-17	40199	59221	\N	\N
70851	SPECIFIC_DAY	3	7	2010-12-10	40199	59221	\N	\N
70852	SPECIFIC_DAY	3	0	2010-11-28	40199	59221	\N	\N
70853	SPECIFIC_DAY	3	0	2011-04-23	40199	59221	\N	\N
70854	SPECIFIC_DAY	3	0	2010-10-23	40199	59221	\N	\N
70855	SPECIFIC_DAY	3	0	2011-05-07	40199	59221	\N	\N
70856	SPECIFIC_DAY	3	7	2011-04-20	40199	59221	\N	\N
70857	SPECIFIC_DAY	3	0	2011-01-23	40199	59221	\N	\N
70858	SPECIFIC_DAY	3	7	2011-02-10	40199	59221	\N	\N
70859	SPECIFIC_DAY	3	7	2011-04-08	40199	59221	\N	\N
70860	SPECIFIC_DAY	3	7	2011-05-09	40199	59221	\N	\N
70861	SPECIFIC_DAY	3	0	2010-11-21	40199	59221	\N	\N
70862	SPECIFIC_DAY	3	7	2010-11-16	40199	59221	\N	\N
70863	SPECIFIC_DAY	3	0	2010-12-12	40199	59221	\N	\N
70864	SPECIFIC_DAY	3	7	2011-04-22	40199	59221	\N	\N
70865	SPECIFIC_DAY	3	7	2011-05-10	40199	59221	\N	\N
70866	SPECIFIC_DAY	3	7	2010-11-26	40199	59221	\N	\N
70867	SPECIFIC_DAY	3	0	2010-10-17	40199	59221	\N	\N
70868	SPECIFIC_DAY	3	0	2011-04-02	40199	59221	\N	\N
70869	SPECIFIC_DAY	3	7	2011-02-28	40199	59221	\N	\N
70870	SPECIFIC_DAY	3	0	2011-04-03	40199	59221	\N	\N
70871	SPECIFIC_DAY	3	7	2011-01-25	40199	59221	\N	\N
70872	SPECIFIC_DAY	3	0	2011-01-15	40199	59221	\N	\N
70873	SPECIFIC_DAY	3	7	2011-01-26	40199	59221	\N	\N
70874	SPECIFIC_DAY	3	0	2011-04-10	40199	59221	\N	\N
70875	SPECIFIC_DAY	3	0	2010-10-31	40199	59221	\N	\N
70876	SPECIFIC_DAY	3	7	2011-04-06	40199	59221	\N	\N
70877	SPECIFIC_DAY	3	0	2010-11-13	40199	59221	\N	\N
70878	SPECIFIC_DAY	3	0	2011-03-26	40199	59221	\N	\N
70879	SPECIFIC_DAY	3	7	2010-11-18	40199	59221	\N	\N
70880	SPECIFIC_DAY	3	0	2010-11-06	40199	59221	\N	\N
70881	SPECIFIC_DAY	3	7	2011-03-30	40199	59221	\N	\N
70882	SPECIFIC_DAY	3	7	2010-09-27	40199	59221	\N	\N
70883	SPECIFIC_DAY	3	0	2011-03-06	40199	59221	\N	\N
70884	SPECIFIC_DAY	3	7	2010-10-27	40199	59221	\N	\N
70885	SPECIFIC_DAY	3	7	2010-12-17	40199	59221	\N	\N
70886	SPECIFIC_DAY	3	7	2011-05-18	40199	59221	\N	\N
70887	SPECIFIC_DAY	3	0	2010-12-06	40199	59221	\N	\N
70888	SPECIFIC_DAY	3	7	2010-11-08	40199	59221	\N	\N
70889	SPECIFIC_DAY	3	0	2010-10-30	40199	59221	\N	\N
70890	SPECIFIC_DAY	3	0	2010-12-26	40199	59221	\N	\N
70891	SPECIFIC_DAY	3	7	2011-01-17	40199	59221	\N	\N
70892	SPECIFIC_DAY	3	7	2011-05-12	40199	59221	\N	\N
70893	SPECIFIC_DAY	3	7	2011-03-14	40199	59221	\N	\N
70894	SPECIFIC_DAY	3	0	2011-04-09	40199	59221	\N	\N
70895	SPECIFIC_DAY	3	7	2011-05-25	40199	59221	\N	\N
70896	SPECIFIC_DAY	3	0	2011-01-22	40199	59221	\N	\N
70897	SPECIFIC_DAY	3	7	2010-11-17	40199	59221	\N	\N
70898	SPECIFIC_DAY	3	7	2011-05-16	40199	59221	\N	\N
70899	SPECIFIC_DAY	3	7	2010-09-20	40199	59221	\N	\N
70900	SPECIFIC_DAY	3	7	2010-10-13	40199	59221	\N	\N
70901	SPECIFIC_DAY	3	7	2010-12-21	40199	59221	\N	\N
70902	SPECIFIC_DAY	3	7	2011-02-21	40199	59221	\N	\N
70903	SPECIFIC_DAY	3	7	2011-05-03	40199	59221	\N	\N
70904	SPECIFIC_DAY	3	7	2010-09-14	40199	59221	\N	\N
70905	SPECIFIC_DAY	3	0	2010-12-08	40199	59221	\N	\N
70906	SPECIFIC_DAY	3	0	2011-01-29	40199	59221	\N	\N
70907	SPECIFIC_DAY	3	7	2010-10-11	40199	59221	\N	\N
70908	SPECIFIC_DAY	3	7	2011-05-17	40199	59221	\N	\N
70909	SPECIFIC_DAY	3	7	2010-12-20	40199	59221	\N	\N
70910	SPECIFIC_DAY	3	7	2011-05-11	40199	59221	\N	\N
70911	SPECIFIC_DAY	3	7	2011-04-29	40199	59221	\N	\N
70912	SPECIFIC_DAY	3	7	2010-09-15	40199	59221	\N	\N
70913	SPECIFIC_DAY	3	0	2010-10-24	40199	59221	\N	\N
70914	SPECIFIC_DAY	3	7	2010-11-09	40199	59221	\N	\N
70915	SPECIFIC_DAY	3	7	2011-03-24	40199	59221	\N	\N
70916	SPECIFIC_DAY	3	7	2012-12-11	40199	59222	\N	\N
70917	SPECIFIC_DAY	3	7	2011-10-04	40199	59222	\N	\N
70918	SPECIFIC_DAY	3	0	2012-10-27	40199	59222	\N	\N
70919	SPECIFIC_DAY	3	7	2012-11-15	40199	59222	\N	\N
70920	SPECIFIC_DAY	3	7	2011-08-29	40199	59222	\N	\N
70921	SPECIFIC_DAY	3	0	2011-10-30	40199	59222	\N	\N
70922	SPECIFIC_DAY	3	7	2011-11-15	40199	59222	\N	\N
70923	SPECIFIC_DAY	3	7	2012-03-26	40199	59222	\N	\N
70924	SPECIFIC_DAY	3	7	2011-11-25	40199	59222	\N	\N
70925	SPECIFIC_DAY	3	0	2012-09-23	40199	59222	\N	\N
70926	SPECIFIC_DAY	3	7	2012-07-23	40199	59222	\N	\N
70927	SPECIFIC_DAY	3	7	2011-08-23	40199	59222	\N	\N
70928	SPECIFIC_DAY	3	7	2012-08-31	40199	59222	\N	\N
70929	SPECIFIC_DAY	3	0	2011-09-17	40199	59222	\N	\N
70930	SPECIFIC_DAY	3	7	2012-07-18	40199	59222	\N	\N
70931	SPECIFIC_DAY	3	0	2011-12-04	40199	59222	\N	\N
70932	SPECIFIC_DAY	3	7	2012-03-07	40199	59222	\N	\N
70933	SPECIFIC_DAY	3	7	2011-06-10	40199	59222	\N	\N
70934	SPECIFIC_DAY	3	7	2012-06-07	40199	59222	\N	\N
70935	SPECIFIC_DAY	3	7	2011-07-25	40199	59222	\N	\N
70936	SPECIFIC_DAY	3	7	2012-12-18	40199	59222	\N	\N
70937	SPECIFIC_DAY	3	7	2013-01-31	40199	59222	\N	\N
70938	SPECIFIC_DAY	3	0	2012-02-12	40199	59222	\N	\N
70939	SPECIFIC_DAY	3	7	2012-06-18	40199	59222	\N	\N
70940	SPECIFIC_DAY	3	7	2011-07-18	40199	59222	\N	\N
70941	SPECIFIC_DAY	3	7	2013-02-11	40199	59222	\N	\N
70942	SPECIFIC_DAY	3	7	2011-07-05	40199	59222	\N	\N
70943	SPECIFIC_DAY	3	0	2011-07-16	40199	59222	\N	\N
70944	SPECIFIC_DAY	3	0	2012-07-01	40199	59222	\N	\N
70945	SPECIFIC_DAY	3	7	2013-01-21	40199	59222	\N	\N
70946	SPECIFIC_DAY	3	0	2013-01-20	40199	59222	\N	\N
70947	SPECIFIC_DAY	3	7	2012-07-11	40199	59222	\N	\N
70948	SPECIFIC_DAY	3	7	2011-09-07	40199	59222	\N	\N
70949	SPECIFIC_DAY	3	0	2012-03-25	40199	59222	\N	\N
70950	SPECIFIC_DAY	3	7	2011-06-08	40199	59222	\N	\N
70951	SPECIFIC_DAY	3	7	2012-04-23	40199	59222	\N	\N
70952	SPECIFIC_DAY	3	7	2011-08-26	40199	59222	\N	\N
70953	SPECIFIC_DAY	3	7	2012-03-29	40199	59222	\N	\N
70954	SPECIFIC_DAY	3	7	2011-12-15	40199	59222	\N	\N
70955	SPECIFIC_DAY	3	7	2013-02-05	40199	59222	\N	\N
70956	SPECIFIC_DAY	3	7	2012-09-25	40199	59222	\N	\N
70957	SPECIFIC_DAY	3	0	2011-08-20	40199	59222	\N	\N
70958	SPECIFIC_DAY	3	7	2012-07-12	40199	59222	\N	\N
70959	SPECIFIC_DAY	3	7	2012-06-13	40199	59222	\N	\N
70960	SPECIFIC_DAY	3	7	2012-07-25	40199	59222	\N	\N
70961	SPECIFIC_DAY	3	7	2011-09-16	40199	59222	\N	\N
70962	SPECIFIC_DAY	3	7	2011-11-30	40199	59222	\N	\N
70963	SPECIFIC_DAY	3	7	2011-10-18	40199	59222	\N	\N
70964	SPECIFIC_DAY	3	7	2012-05-15	40199	59222	\N	\N
70965	SPECIFIC_DAY	3	7	2012-05-14	40199	59222	\N	\N
70966	SPECIFIC_DAY	3	7	2013-01-18	40199	59222	\N	\N
70967	SPECIFIC_DAY	3	7	2012-12-26	40199	59222	\N	\N
70968	SPECIFIC_DAY	3	0	2011-11-06	40199	59222	\N	\N
70969	SPECIFIC_DAY	3	0	2011-08-21	40199	59222	\N	\N
70970	SPECIFIC_DAY	3	0	2012-11-03	40199	59222	\N	\N
70971	SPECIFIC_DAY	3	7	2012-03-30	40199	59222	\N	\N
70972	SPECIFIC_DAY	3	0	2011-06-18	40199	59222	\N	\N
70973	SPECIFIC_DAY	3	0	2012-04-14	40199	59222	\N	\N
70974	SPECIFIC_DAY	3	0	2012-02-05	40199	59222	\N	\N
70975	SPECIFIC_DAY	3	0	2011-07-24	40199	59222	\N	\N
70976	SPECIFIC_DAY	3	7	2012-07-02	40199	59222	\N	\N
70977	SPECIFIC_DAY	3	7	2012-09-03	40199	59222	\N	\N
70978	SPECIFIC_DAY	3	7	2012-08-28	40199	59222	\N	\N
70979	SPECIFIC_DAY	3	0	2012-07-14	40199	59222	\N	\N
70980	SPECIFIC_DAY	3	7	2011-07-06	40199	59222	\N	\N
70981	SPECIFIC_DAY	3	7	2011-06-20	40199	59222	\N	\N
70982	SPECIFIC_DAY	3	7	2011-06-30	40199	59222	\N	\N
70983	SPECIFIC_DAY	3	7	2011-06-23	40199	59222	\N	\N
70984	SPECIFIC_DAY	3	0	2012-12-29	40199	59222	\N	\N
70985	SPECIFIC_DAY	3	0	2012-06-24	40199	59222	\N	\N
70986	SPECIFIC_DAY	3	7	2012-03-20	40199	59222	\N	\N
70987	SPECIFIC_DAY	3	7	2011-09-15	40199	59222	\N	\N
70988	SPECIFIC_DAY	3	7	2011-11-18	40199	59222	\N	\N
70989	SPECIFIC_DAY	3	0	2011-10-08	40199	59222	\N	\N
70990	SPECIFIC_DAY	3	7	2012-05-09	40199	59222	\N	\N
70991	SPECIFIC_DAY	3	7	2011-12-01	40199	59222	\N	\N
70992	SPECIFIC_DAY	3	0	2011-05-29	40199	59222	\N	\N
70993	SPECIFIC_DAY	3	7	2011-07-11	40199	59222	\N	\N
70994	SPECIFIC_DAY	3	7	2012-10-16	40199	59222	\N	\N
70995	SPECIFIC_DAY	3	0	2011-06-26	40199	59222	\N	\N
70996	SPECIFIC_DAY	3	7	2012-12-05	40199	59222	\N	\N
70997	SPECIFIC_DAY	3	7	2012-05-29	40199	59222	\N	\N
70998	SPECIFIC_DAY	3	7	2011-09-27	40199	59222	\N	\N
70999	SPECIFIC_DAY	3	7	2011-09-02	40199	59222	\N	\N
71000	SPECIFIC_DAY	3	7	2012-11-30	40199	59222	\N	\N
71001	SPECIFIC_DAY	3	7	2012-06-11	40199	59222	\N	\N
71002	SPECIFIC_DAY	3	0	2012-07-07	40199	59222	\N	\N
71003	SPECIFIC_DAY	3	7	2012-02-14	40199	59222	\N	\N
71004	SPECIFIC_DAY	3	7	2011-06-24	40199	59222	\N	\N
71005	SPECIFIC_DAY	3	7	2011-10-13	40199	59222	\N	\N
71006	SPECIFIC_DAY	3	7	2012-07-19	40199	59222	\N	\N
71007	SPECIFIC_DAY	3	7	2011-08-25	40199	59222	\N	\N
71008	SPECIFIC_DAY	3	0	2011-11-19	40199	59222	\N	\N
71009	SPECIFIC_DAY	3	7	2012-04-13	40199	59222	\N	\N
71010	SPECIFIC_DAY	3	7	2012-09-11	40199	59222	\N	\N
71011	SPECIFIC_DAY	3	0	2013-01-27	40199	59222	\N	\N
71012	SPECIFIC_DAY	3	7	2012-01-10	40199	59222	\N	\N
71013	SPECIFIC_DAY	3	7	2012-02-28	40199	59222	\N	\N
71014	SPECIFIC_DAY	3	0	2012-03-03	40199	59222	\N	\N
71015	SPECIFIC_DAY	3	7	2012-02-08	40199	59222	\N	\N
71016	SPECIFIC_DAY	3	0	2012-05-12	40199	59222	\N	\N
71017	SPECIFIC_DAY	3	0	2012-10-07	40199	59222	\N	\N
71018	SPECIFIC_DAY	3	0	2012-06-02	40199	59222	\N	\N
71019	SPECIFIC_DAY	3	0	2012-11-17	40199	59222	\N	\N
71020	SPECIFIC_DAY	3	7	2012-08-24	40199	59222	\N	\N
71021	SPECIFIC_DAY	3	7	2013-01-03	40199	59222	\N	\N
71022	SPECIFIC_DAY	3	7	2012-06-08	40199	59222	\N	\N
71023	SPECIFIC_DAY	3	7	2012-01-12	40199	59222	\N	\N
71024	SPECIFIC_DAY	3	7	2011-07-27	40199	59222	\N	\N
71025	SPECIFIC_DAY	3	7	2012-03-21	40199	59222	\N	\N
71026	SPECIFIC_DAY	3	0	2011-08-13	40199	59222	\N	\N
71027	SPECIFIC_DAY	3	7	2011-06-13	40199	59222	\N	\N
71028	SPECIFIC_DAY	3	0	2012-08-26	40199	59222	\N	\N
71029	SPECIFIC_DAY	3	7	2012-11-21	40199	59222	\N	\N
71030	SPECIFIC_DAY	3	7	2012-01-26	40199	59222	\N	\N
71031	SPECIFIC_DAY	3	7	2012-04-27	40199	59222	\N	\N
71032	SPECIFIC_DAY	3	7	2012-11-13	40199	59222	\N	\N
71033	SPECIFIC_DAY	3	7	2012-03-13	40199	59222	\N	\N
71034	SPECIFIC_DAY	3	7	2012-12-07	40199	59222	\N	\N
71035	SPECIFIC_DAY	3	0	2012-08-11	40199	59222	\N	\N
71036	SPECIFIC_DAY	3	0	2012-01-28	40199	59222	\N	\N
71037	SPECIFIC_DAY	3	7	2012-03-01	40199	59222	\N	\N
71038	SPECIFIC_DAY	3	7	2012-04-04	40199	59222	\N	\N
71039	SPECIFIC_DAY	3	7	2012-12-20	40199	59222	\N	\N
71040	SPECIFIC_DAY	3	7	2011-09-20	40199	59222	\N	\N
71041	SPECIFIC_DAY	3	7	2011-08-02	40199	59222	\N	\N
71042	SPECIFIC_DAY	3	7	2011-07-13	40199	59222	\N	\N
71043	SPECIFIC_DAY	3	7	2012-07-10	40199	59222	\N	\N
71044	SPECIFIC_DAY	3	7	2012-07-03	40199	59222	\N	\N
71045	SPECIFIC_DAY	3	0	2011-06-25	40199	59222	\N	\N
71046	SPECIFIC_DAY	3	0	2011-12-03	40199	59222	\N	\N
71047	SPECIFIC_DAY	3	7	2012-10-08	40199	59222	\N	\N
71048	SPECIFIC_DAY	3	0	2012-05-26	40199	59222	\N	\N
71049	SPECIFIC_DAY	3	7	2012-02-07	40199	59222	\N	\N
71050	SPECIFIC_DAY	3	0	2011-12-24	40199	59222	\N	\N
71051	SPECIFIC_DAY	3	0	2011-12-31	40199	59222	\N	\N
71052	SPECIFIC_DAY	3	7	2012-10-18	40199	59222	\N	\N
71053	SPECIFIC_DAY	3	7	2011-12-05	40199	59222	\N	\N
71054	SPECIFIC_DAY	3	0	2012-03-31	40199	59222	\N	\N
71055	SPECIFIC_DAY	3	7	2013-01-07	40199	59222	\N	\N
71056	SPECIFIC_DAY	3	7	2012-11-20	40199	59222	\N	\N
71057	SPECIFIC_DAY	3	7	2012-01-11	40199	59222	\N	\N
71058	SPECIFIC_DAY	3	7	2011-05-27	40199	59222	\N	\N
71059	SPECIFIC_DAY	3	7	2013-01-25	40199	59222	\N	\N
71060	SPECIFIC_DAY	3	7	2011-06-28	40199	59222	\N	\N
71061	SPECIFIC_DAY	3	0	2012-04-01	40199	59222	\N	\N
71062	SPECIFIC_DAY	3	0	2012-06-16	40199	59222	\N	\N
71063	SPECIFIC_DAY	3	7	2012-08-17	40199	59222	\N	\N
71064	SPECIFIC_DAY	3	7	2012-03-05	40199	59222	\N	\N
71065	SPECIFIC_DAY	3	7	2012-06-21	40199	59222	\N	\N
71066	SPECIFIC_DAY	3	7	2012-04-17	40199	59222	\N	\N
71067	SPECIFIC_DAY	3	7	2012-03-19	40199	59222	\N	\N
71068	SPECIFIC_DAY	3	7	2012-08-10	40199	59222	\N	\N
71069	SPECIFIC_DAY	3	7	2011-08-18	40199	59222	\N	\N
71070	SPECIFIC_DAY	3	7	2011-11-24	40199	59222	\N	\N
71071	SPECIFIC_DAY	3	7	2011-08-09	40199	59222	\N	\N
71072	SPECIFIC_DAY	3	7	2012-04-16	40199	59222	\N	\N
71073	SPECIFIC_DAY	3	7	2011-09-28	40199	59222	\N	\N
71074	SPECIFIC_DAY	3	7	2011-08-12	40199	59222	\N	\N
71075	SPECIFIC_DAY	3	7	2012-12-25	40199	59222	\N	\N
71076	SPECIFIC_DAY	3	0	2012-09-02	40199	59222	\N	\N
71077	SPECIFIC_DAY	3	0	2012-10-14	40199	59222	\N	\N
71078	SPECIFIC_DAY	3	0	2012-12-30	40199	59222	\N	\N
71079	SPECIFIC_DAY	3	7	2012-04-03	40199	59222	\N	\N
71080	SPECIFIC_DAY	3	7	2013-02-12	40199	59222	\N	\N
71081	SPECIFIC_DAY	3	7	2012-03-08	40199	59222	\N	\N
71082	SPECIFIC_DAY	3	7	2012-05-30	40199	59222	\N	\N
71083	SPECIFIC_DAY	3	7	2012-11-09	40199	59222	\N	\N
71084	SPECIFIC_DAY	3	7	2012-01-02	40199	59222	\N	\N
71085	SPECIFIC_DAY	3	0	2013-01-05	40199	59222	\N	\N
71086	SPECIFIC_DAY	3	7	2011-08-08	40199	59222	\N	\N
71087	SPECIFIC_DAY	3	7	2011-10-06	40199	59222	\N	\N
71088	SPECIFIC_DAY	3	7	2012-12-14	40199	59222	\N	\N
71089	SPECIFIC_DAY	3	0	2012-01-14	40199	59222	\N	\N
71090	SPECIFIC_DAY	3	7	2012-02-20	40199	59222	\N	\N
71091	SPECIFIC_DAY	3	7	2012-11-05	40199	59222	\N	\N
71092	SPECIFIC_DAY	3	7	2012-07-26	40199	59222	\N	\N
71093	SPECIFIC_DAY	3	0	2012-11-25	40199	59222	\N	\N
71094	SPECIFIC_DAY	3	7	2011-11-07	40199	59222	\N	\N
71095	SPECIFIC_DAY	3	7	2012-06-19	40199	59222	\N	\N
71096	SPECIFIC_DAY	3	0	2012-04-22	40199	59222	\N	\N
71097	SPECIFIC_DAY	3	7	2011-08-24	40199	59222	\N	\N
71098	SPECIFIC_DAY	3	7	2011-12-29	40199	59222	\N	\N
71099	SPECIFIC_DAY	3	7	2011-09-01	40199	59222	\N	\N
71100	SPECIFIC_DAY	3	7	2011-10-05	40199	59222	\N	\N
71101	SPECIFIC_DAY	3	0	2012-10-06	40199	59222	\N	\N
71102	SPECIFIC_DAY	3	7	2012-10-11	40199	59222	\N	\N
71103	SPECIFIC_DAY	3	0	2012-04-21	40199	59222	\N	\N
71104	SPECIFIC_DAY	3	0	2011-11-26	40199	59222	\N	\N
71105	SPECIFIC_DAY	3	7	2012-12-17	40199	59222	\N	\N
71106	SPECIFIC_DAY	3	7	2012-06-01	40199	59222	\N	\N
71107	SPECIFIC_DAY	3	7	2013-02-08	40199	59222	\N	\N
71108	SPECIFIC_DAY	3	7	2012-11-29	40199	59222	\N	\N
71109	SPECIFIC_DAY	3	0	2012-08-19	40199	59222	\N	\N
71110	SPECIFIC_DAY	3	7	2011-10-07	40199	59222	\N	\N
71111	SPECIFIC_DAY	3	7	2012-05-11	40199	59222	\N	\N
71112	SPECIFIC_DAY	3	7	2012-04-06	40199	59222	\N	\N
71113	SPECIFIC_DAY	3	7	2012-02-10	40199	59222	\N	\N
71114	SPECIFIC_DAY	3	0	2011-09-18	40199	59222	\N	\N
71115	SPECIFIC_DAY	3	7	2011-10-12	40199	59222	\N	\N
71116	SPECIFIC_DAY	3	7	2011-11-02	40199	59222	\N	\N
71117	SPECIFIC_DAY	3	7	2012-08-14	40199	59222	\N	\N
71118	SPECIFIC_DAY	3	7	2012-12-04	40199	59222	\N	\N
71119	SPECIFIC_DAY	3	7	2012-02-23	40199	59222	\N	\N
71120	SPECIFIC_DAY	3	7	2012-10-04	40199	59222	\N	\N
71121	SPECIFIC_DAY	3	7	2011-08-01	40199	59222	\N	\N
71122	SPECIFIC_DAY	3	7	2012-05-10	40199	59222	\N	\N
71123	SPECIFIC_DAY	3	7	2013-01-29	40199	59222	\N	\N
71124	SPECIFIC_DAY	3	7	2012-08-09	40199	59222	\N	\N
71125	SPECIFIC_DAY	3	7	2011-08-19	40199	59222	\N	\N
71126	SPECIFIC_DAY	3	0	2012-09-01	40199	59222	\N	\N
71127	SPECIFIC_DAY	3	0	2012-11-18	40199	59222	\N	\N
71128	SPECIFIC_DAY	3	7	2011-07-26	40199	59222	\N	\N
71129	SPECIFIC_DAY	3	7	2012-06-12	40199	59222	\N	\N
71130	SPECIFIC_DAY	3	0	2013-01-06	40199	59222	\N	\N
71131	SPECIFIC_DAY	3	0	2011-06-12	40199	59222	\N	\N
71132	SPECIFIC_DAY	3	7	2012-04-18	40199	59222	\N	\N
71133	SPECIFIC_DAY	3	7	2011-10-14	40199	59222	\N	\N
71134	SPECIFIC_DAY	3	7	2013-01-08	40199	59222	\N	\N
71135	SPECIFIC_DAY	3	7	2012-05-08	40199	59222	\N	\N
71136	SPECIFIC_DAY	3	7	2012-09-28	40199	59222	\N	\N
71137	SPECIFIC_DAY	3	7	2013-01-11	40199	59222	\N	\N
71138	SPECIFIC_DAY	3	7	2011-06-27	40199	59222	\N	\N
71139	SPECIFIC_DAY	3	0	2011-11-20	40199	59222	\N	\N
71140	SPECIFIC_DAY	3	7	2012-04-30	40199	59222	\N	\N
71141	SPECIFIC_DAY	3	7	2012-05-23	40199	59222	\N	\N
71142	SPECIFIC_DAY	3	7	2011-09-14	40199	59222	\N	\N
71143	SPECIFIC_DAY	3	7	2011-12-14	40199	59222	\N	\N
71144	SPECIFIC_DAY	3	7	2011-07-01	40199	59222	\N	\N
71145	SPECIFIC_DAY	3	7	2012-08-03	40199	59222	\N	\N
71146	SPECIFIC_DAY	3	7	2012-09-12	40199	59222	\N	\N
71147	SPECIFIC_DAY	3	7	2011-06-16	40199	59222	\N	\N
71148	SPECIFIC_DAY	3	0	2011-08-07	40199	59222	\N	\N
71149	SPECIFIC_DAY	3	7	2012-11-07	40199	59222	\N	\N
71150	SPECIFIC_DAY	3	7	2012-04-25	40199	59222	\N	\N
71151	SPECIFIC_DAY	3	0	2011-12-10	40199	59222	\N	\N
71152	SPECIFIC_DAY	3	7	2012-10-10	40199	59222	\N	\N
71153	SPECIFIC_DAY	3	0	2011-10-23	40199	59222	\N	\N
71154	SPECIFIC_DAY	3	7	2013-01-24	40199	59222	\N	\N
71155	SPECIFIC_DAY	3	7	2012-07-06	40199	59222	\N	\N
71156	SPECIFIC_DAY	3	7	2012-01-13	40199	59222	\N	\N
71157	SPECIFIC_DAY	3	7	2011-11-14	40199	59222	\N	\N
71158	SPECIFIC_DAY	3	7	2012-03-28	40199	59222	\N	\N
71159	SPECIFIC_DAY	3	7	2011-11-22	40199	59222	\N	\N
71160	SPECIFIC_DAY	3	0	2012-06-10	40199	59222	\N	\N
71161	SPECIFIC_DAY	3	7	2011-10-19	40199	59222	\N	\N
71162	SPECIFIC_DAY	3	7	2011-10-21	40199	59222	\N	\N
71163	SPECIFIC_DAY	3	0	2011-08-28	40199	59222	\N	\N
71164	SPECIFIC_DAY	3	7	2012-04-12	40199	59222	\N	\N
71165	SPECIFIC_DAY	3	7	2012-05-02	40199	59222	\N	\N
71166	SPECIFIC_DAY	3	7	2012-01-20	40199	59222	\N	\N
71167	SPECIFIC_DAY	3	0	2012-12-15	40199	59222	\N	\N
71168	SPECIFIC_DAY	3	0	2011-09-03	40199	59222	\N	\N
71169	SPECIFIC_DAY	3	7	2011-10-27	40199	59222	\N	\N
71170	SPECIFIC_DAY	3	7	2013-01-14	40199	59222	\N	\N
71171	SPECIFIC_DAY	3	7	2012-10-01	40199	59222	\N	\N
71172	SPECIFIC_DAY	3	7	2012-08-08	40199	59222	\N	\N
71173	SPECIFIC_DAY	3	7	2012-03-06	40199	59222	\N	\N
71174	SPECIFIC_DAY	3	0	2011-10-09	40199	59222	\N	\N
71175	SPECIFIC_DAY	3	7	2013-01-04	40199	59222	\N	\N
71176	SPECIFIC_DAY	3	0	2011-10-16	40199	59222	\N	\N
71177	SPECIFIC_DAY	3	0	2011-12-17	40199	59222	\N	\N
71178	SPECIFIC_DAY	3	7	2012-12-06	40199	59222	\N	\N
71179	SPECIFIC_DAY	3	7	2012-08-29	40199	59222	\N	\N
71180	SPECIFIC_DAY	3	7	2012-11-02	40199	59222	\N	\N
71181	SPECIFIC_DAY	3	0	2012-10-13	40199	59222	\N	\N
71182	SPECIFIC_DAY	3	7	2011-10-17	40199	59222	\N	\N
71183	SPECIFIC_DAY	3	7	2012-01-25	40199	59222	\N	\N
71184	SPECIFIC_DAY	3	7	2011-06-03	40199	59222	\N	\N
71185	SPECIFIC_DAY	3	0	2012-01-08	40199	59222	\N	\N
71186	SPECIFIC_DAY	3	7	2012-03-02	40199	59222	\N	\N
71187	SPECIFIC_DAY	3	7	2012-05-22	40199	59222	\N	\N
71188	SPECIFIC_DAY	3	0	2012-08-04	40199	59222	\N	\N
71189	SPECIFIC_DAY	3	0	2012-12-23	40199	59222	\N	\N
71190	SPECIFIC_DAY	3	0	2011-10-29	40199	59222	\N	\N
71191	SPECIFIC_DAY	3	7	2013-02-13	40199	59222	\N	\N
71192	SPECIFIC_DAY	3	7	2012-05-24	40199	59222	\N	\N
71193	SPECIFIC_DAY	3	7	2013-01-09	40199	59222	\N	\N
71194	SPECIFIC_DAY	3	0	2012-04-29	40199	59222	\N	\N
71195	SPECIFIC_DAY	3	7	2012-02-01	40199	59222	\N	\N
71196	SPECIFIC_DAY	3	0	2012-06-17	40199	59222	\N	\N
71197	SPECIFIC_DAY	3	0	2011-07-09	40199	59222	\N	\N
71198	SPECIFIC_DAY	3	0	2012-02-26	40199	59222	\N	\N
71199	SPECIFIC_DAY	3	7	2012-02-22	40199	59222	\N	\N
71200	SPECIFIC_DAY	3	7	2011-11-23	40199	59222	\N	\N
71201	SPECIFIC_DAY	3	7	2012-10-31	40199	59222	\N	\N
71202	SPECIFIC_DAY	3	7	2011-12-23	40199	59222	\N	\N
71203	SPECIFIC_DAY	3	0	2012-09-30	40199	59222	\N	\N
71204	SPECIFIC_DAY	3	0	2011-09-24	40199	59222	\N	\N
71205	SPECIFIC_DAY	3	7	2012-08-22	40199	59222	\N	\N
71206	SPECIFIC_DAY	3	7	2011-12-16	40199	59222	\N	\N
71207	SPECIFIC_DAY	3	7	2013-01-28	40199	59222	\N	\N
71208	SPECIFIC_DAY	3	7	2011-07-19	40199	59222	\N	\N
71209	SPECIFIC_DAY	3	7	2012-06-05	40199	59222	\N	\N
71210	SPECIFIC_DAY	3	7	2012-08-21	40199	59222	\N	\N
71211	SPECIFIC_DAY	3	0	2012-06-03	40199	59222	\N	\N
71212	SPECIFIC_DAY	3	7	2011-07-12	40199	59222	\N	\N
71213	SPECIFIC_DAY	3	7	2012-04-09	40199	59222	\N	\N
71214	SPECIFIC_DAY	3	7	2012-05-01	40199	59222	\N	\N
71215	SPECIFIC_DAY	3	0	2012-02-04	40199	59222	\N	\N
71216	SPECIFIC_DAY	3	7	2011-08-11	40199	59222	\N	\N
71217	SPECIFIC_DAY	3	7	2012-11-06	40199	59222	\N	\N
71218	SPECIFIC_DAY	3	7	2012-09-21	40199	59222	\N	\N
71219	SPECIFIC_DAY	3	7	2011-11-04	40199	59222	\N	\N
71220	SPECIFIC_DAY	3	7	2011-10-03	40199	59222	\N	\N
71221	SPECIFIC_DAY	3	7	2012-11-08	40199	59222	\N	\N
71222	SPECIFIC_DAY	3	7	2013-02-06	40199	59222	\N	\N
71223	SPECIFIC_DAY	3	0	2012-09-29	40199	59222	\N	\N
71224	SPECIFIC_DAY	3	7	2012-06-28	40199	59222	\N	\N
71225	SPECIFIC_DAY	3	7	2012-06-29	40199	59222	\N	\N
71226	SPECIFIC_DAY	3	7	2012-02-13	40199	59222	\N	\N
71227	SPECIFIC_DAY	3	0	2012-05-05	40199	59222	\N	\N
71228	SPECIFIC_DAY	3	7	2012-10-12	40199	59222	\N	\N
71229	SPECIFIC_DAY	3	7	2012-11-19	40199	59222	\N	\N
71230	SPECIFIC_DAY	3	0	2011-07-10	40199	59222	\N	\N
71231	SPECIFIC_DAY	3	7	2012-03-27	40199	59222	\N	\N
71232	SPECIFIC_DAY	3	0	2011-07-02	40199	59222	\N	\N
71233	SPECIFIC_DAY	3	7	2011-11-03	40199	59222	\N	\N
71234	SPECIFIC_DAY	3	0	2012-04-07	40199	59222	\N	\N
71235	SPECIFIC_DAY	3	0	2012-09-09	40199	59222	\N	\N
71236	SPECIFIC_DAY	3	7	2012-08-06	40199	59222	\N	\N
71237	SPECIFIC_DAY	3	7	2012-12-19	40199	59222	\N	\N
71238	SPECIFIC_DAY	3	7	2011-06-22	40199	59222	\N	\N
71239	SPECIFIC_DAY	3	0	2012-01-21	40199	59222	\N	\N
71240	SPECIFIC_DAY	3	7	2011-08-22	40199	59222	\N	\N
71241	SPECIFIC_DAY	3	7	2013-01-30	40199	59222	\N	\N
71242	SPECIFIC_DAY	3	0	2012-06-23	40199	59222	\N	\N
71243	SPECIFIC_DAY	3	0	2012-12-02	40199	59222	\N	\N
71244	SPECIFIC_DAY	3	7	2011-09-23	40199	59222	\N	\N
71245	SPECIFIC_DAY	3	0	2012-03-24	40199	59222	\N	\N
71246	SPECIFIC_DAY	3	7	2012-01-18	40199	59222	\N	\N
71247	SPECIFIC_DAY	3	7	2012-12-10	40199	59222	\N	\N
71248	SPECIFIC_DAY	3	7	2011-09-08	40199	59222	\N	\N
71249	SPECIFIC_DAY	3	7	2012-08-23	40199	59222	\N	\N
71250	SPECIFIC_DAY	3	7	2012-12-21	40199	59222	\N	\N
71251	SPECIFIC_DAY	3	7	2012-05-07	40199	59222	\N	\N
71252	SPECIFIC_DAY	3	7	2012-03-23	40199	59222	\N	\N
71253	SPECIFIC_DAY	3	0	2011-06-05	40199	59222	\N	\N
71254	SPECIFIC_DAY	3	7	2012-09-10	40199	59222	\N	\N
71255	SPECIFIC_DAY	3	7	2011-12-02	40199	59222	\N	\N
71256	SPECIFIC_DAY	3	7	2012-10-05	40199	59222	\N	\N
71257	SPECIFIC_DAY	3	7	2012-06-04	40199	59222	\N	\N
71258	SPECIFIC_DAY	3	7	2012-11-16	40199	59222	\N	\N
71259	SPECIFIC_DAY	3	7	2013-01-01	40199	59222	\N	\N
71260	SPECIFIC_DAY	3	7	2011-12-30	40199	59222	\N	\N
71261	SPECIFIC_DAY	3	7	2012-05-28	40199	59222	\N	\N
71262	SPECIFIC_DAY	3	7	2012-07-24	40199	59222	\N	\N
71263	SPECIFIC_DAY	3	0	2012-10-21	40199	59222	\N	\N
71264	SPECIFIC_DAY	3	0	2012-12-09	40199	59222	\N	\N
71265	SPECIFIC_DAY	3	7	2012-11-12	40199	59222	\N	\N
71266	SPECIFIC_DAY	3	0	2011-09-11	40199	59222	\N	\N
71267	SPECIFIC_DAY	3	7	2012-10-24	40199	59222	\N	\N
71268	SPECIFIC_DAY	3	0	2012-11-11	40199	59222	\N	\N
71269	SPECIFIC_DAY	3	7	2011-07-22	40199	59222	\N	\N
71270	SPECIFIC_DAY	3	0	2013-01-26	40199	59222	\N	\N
71271	SPECIFIC_DAY	3	7	2012-02-21	40199	59222	\N	\N
71272	SPECIFIC_DAY	3	7	2011-11-28	40199	59222	\N	\N
71273	SPECIFIC_DAY	3	7	2012-01-27	40199	59222	\N	\N
71274	SPECIFIC_DAY	3	7	2012-04-11	40199	59222	\N	\N
71275	SPECIFIC_DAY	3	7	2011-11-10	40199	59222	\N	\N
71276	SPECIFIC_DAY	3	7	2012-07-05	40199	59222	\N	\N
71277	SPECIFIC_DAY	3	0	2011-08-14	40199	59222	\N	\N
71278	SPECIFIC_DAY	3	0	2011-10-01	40199	59222	\N	\N
71279	SPECIFIC_DAY	3	7	2013-01-10	40199	59222	\N	\N
71280	SPECIFIC_DAY	3	7	2012-01-03	40199	59222	\N	\N
71281	SPECIFIC_DAY	3	0	2012-08-05	40199	59222	\N	\N
71282	SPECIFIC_DAY	3	7	2012-08-27	40199	59222	\N	\N
71283	SPECIFIC_DAY	3	0	2011-05-28	40199	59222	\N	\N
71284	SPECIFIC_DAY	3	7	2012-05-21	40199	59222	\N	\N
71285	SPECIFIC_DAY	3	7	2011-08-15	40199	59222	\N	\N
71286	SPECIFIC_DAY	3	7	2012-05-18	40199	59222	\N	\N
71287	SPECIFIC_DAY	3	0	2011-10-22	40199	59222	\N	\N
71288	SPECIFIC_DAY	3	7	2011-08-17	40199	59222	\N	\N
71289	SPECIFIC_DAY	3	0	2012-03-10	40199	59222	\N	\N
71290	SPECIFIC_DAY	3	7	2011-10-24	40199	59222	\N	\N
71291	SPECIFIC_DAY	3	7	2012-09-20	40199	59222	\N	\N
71292	SPECIFIC_DAY	3	7	2012-10-17	40199	59222	\N	\N
71293	SPECIFIC_DAY	3	0	2011-09-04	40199	59222	\N	\N
71294	SPECIFIC_DAY	3	7	2012-04-05	40199	59222	\N	\N
71295	SPECIFIC_DAY	3	0	2012-05-20	40199	59222	\N	\N
71296	SPECIFIC_DAY	3	0	2012-03-11	40199	59222	\N	\N
71297	SPECIFIC_DAY	3	0	2012-12-22	40199	59222	\N	\N
71298	SPECIFIC_DAY	3	7	2012-09-27	40199	59222	\N	\N
71299	SPECIFIC_DAY	3	7	2012-09-06	40199	59222	\N	\N
71300	SPECIFIC_DAY	3	7	2012-04-26	40199	59222	\N	\N
71301	SPECIFIC_DAY	3	7	2012-01-23	40199	59222	\N	\N
71302	SPECIFIC_DAY	3	7	2012-12-12	40199	59222	\N	\N
71303	SPECIFIC_DAY	3	7	2012-10-23	40199	59222	\N	\N
71304	SPECIFIC_DAY	3	7	2011-09-29	40199	59222	\N	\N
71305	SPECIFIC_DAY	3	0	2012-01-15	40199	59222	\N	\N
71306	SPECIFIC_DAY	3	7	2012-09-18	40199	59222	\N	\N
71307	SPECIFIC_DAY	3	0	2013-01-12	40199	59222	\N	\N
71308	SPECIFIC_DAY	3	7	2012-08-01	40199	59222	\N	\N
71309	SPECIFIC_DAY	3	7	2011-12-08	40199	59222	\N	\N
71310	SPECIFIC_DAY	3	0	2012-10-28	40199	59222	\N	\N
71311	SPECIFIC_DAY	3	7	2011-12-12	40199	59222	\N	\N
71312	SPECIFIC_DAY	3	7	2011-11-01	40199	59222	\N	\N
71313	SPECIFIC_DAY	3	7	2011-07-07	40199	59222	\N	\N
71314	SPECIFIC_DAY	3	0	2012-08-12	40199	59222	\N	\N
71315	SPECIFIC_DAY	3	7	2012-06-22	40199	59222	\N	\N
71316	SPECIFIC_DAY	3	7	2013-01-15	40199	59222	\N	\N
71317	SPECIFIC_DAY	3	7	2011-09-06	40199	59222	\N	\N
71318	SPECIFIC_DAY	3	7	2012-11-26	40199	59222	\N	\N
71319	SPECIFIC_DAY	3	7	2011-07-28	40199	59222	\N	\N
71320	SPECIFIC_DAY	3	7	2011-07-08	40199	59222	\N	\N
71321	SPECIFIC_DAY	3	0	2011-09-10	40199	59222	\N	\N
71322	SPECIFIC_DAY	3	7	2012-07-13	40199	59222	\N	\N
71323	SPECIFIC_DAY	3	0	2012-02-11	40199	59222	\N	\N
71324	SPECIFIC_DAY	3	0	2011-07-03	40199	59222	\N	\N
71325	SPECIFIC_DAY	3	7	2012-09-07	40199	59222	\N	\N
71326	SPECIFIC_DAY	3	7	2012-03-14	40199	59222	\N	\N
71327	SPECIFIC_DAY	3	7	2012-07-31	40199	59222	\N	\N
71328	SPECIFIC_DAY	3	0	2012-03-17	40199	59222	\N	\N
71329	SPECIFIC_DAY	3	0	2012-07-08	40199	59222	\N	\N
71330	SPECIFIC_DAY	3	0	2012-05-27	40199	59222	\N	\N
71331	SPECIFIC_DAY	3	7	2012-03-16	40199	59222	\N	\N
71332	SPECIFIC_DAY	3	0	2012-04-15	40199	59222	\N	\N
71333	SPECIFIC_DAY	3	7	2012-12-03	40199	59222	\N	\N
71334	SPECIFIC_DAY	3	0	2012-08-18	40199	59222	\N	\N
71335	SPECIFIC_DAY	3	0	2011-12-18	40199	59222	\N	\N
71336	SPECIFIC_DAY	3	7	2012-02-09	40199	59222	\N	\N
71337	SPECIFIC_DAY	3	0	2012-02-18	40199	59222	\N	\N
71338	SPECIFIC_DAY	3	7	2011-11-21	40199	59222	\N	\N
71339	SPECIFIC_DAY	3	7	2011-11-09	40199	59222	\N	\N
71340	SPECIFIC_DAY	3	7	2011-10-11	40199	59222	\N	\N
71341	SPECIFIC_DAY	3	0	2011-11-13	40199	59222	\N	\N
71342	SPECIFIC_DAY	3	0	2011-08-27	40199	59222	\N	\N
71343	SPECIFIC_DAY	3	7	2012-08-13	40199	59222	\N	\N
71344	SPECIFIC_DAY	3	0	2012-12-16	40199	59222	\N	\N
71345	SPECIFIC_DAY	3	0	2012-11-10	40199	59222	\N	\N
71346	SPECIFIC_DAY	3	0	2012-10-20	40199	59222	\N	\N
71347	SPECIFIC_DAY	3	7	2011-12-07	40199	59222	\N	\N
71348	SPECIFIC_DAY	3	0	2012-09-16	40199	59222	\N	\N
71349	SPECIFIC_DAY	3	7	2011-12-19	40199	59222	\N	\N
71350	SPECIFIC_DAY	3	7	2012-11-01	40199	59222	\N	\N
71351	SPECIFIC_DAY	3	0	2012-11-24	40199	59222	\N	\N
71352	SPECIFIC_DAY	3	0	2012-04-28	40199	59222	\N	\N
71353	SPECIFIC_DAY	3	7	2012-05-25	40199	59222	\N	\N
71354	SPECIFIC_DAY	3	7	2011-06-17	40199	59222	\N	\N
71355	SPECIFIC_DAY	3	7	2011-08-31	40199	59222	\N	\N
71356	SPECIFIC_DAY	3	0	2011-07-30	40199	59222	\N	\N
71357	SPECIFIC_DAY	3	7	2011-11-11	40199	59222	\N	\N
71358	SPECIFIC_DAY	3	7	2012-10-19	40199	59222	\N	\N
71359	SPECIFIC_DAY	3	0	2011-06-11	40199	59222	\N	\N
71360	SPECIFIC_DAY	3	0	2011-06-04	40199	59222	\N	\N
71361	SPECIFIC_DAY	3	7	2012-02-03	40199	59222	\N	\N
71362	SPECIFIC_DAY	3	7	2011-06-15	40199	59222	\N	\N
71363	SPECIFIC_DAY	3	7	2012-11-27	40199	59222	\N	\N
71364	SPECIFIC_DAY	3	7	2012-06-25	40199	59222	\N	\N
71365	SPECIFIC_DAY	3	7	2013-01-17	40199	59222	\N	\N
71366	SPECIFIC_DAY	3	7	2011-12-06	40199	59222	\N	\N
71367	SPECIFIC_DAY	3	7	2012-01-04	40199	59222	\N	\N
71368	SPECIFIC_DAY	3	7	2011-12-28	40199	59222	\N	\N
71369	SPECIFIC_DAY	3	0	2011-07-31	40199	59222	\N	\N
71370	SPECIFIC_DAY	3	0	2011-07-23	40199	59222	\N	\N
71371	SPECIFIC_DAY	3	7	2011-12-27	40199	59222	\N	\N
71372	SPECIFIC_DAY	3	7	2012-01-17	40199	59222	\N	\N
71373	SPECIFIC_DAY	3	7	2011-10-31	40199	59222	\N	\N
71374	SPECIFIC_DAY	3	7	2012-07-30	40199	59222	\N	\N
71375	SPECIFIC_DAY	3	7	2012-01-06	40199	59222	\N	\N
71376	SPECIFIC_DAY	3	7	2012-04-20	40199	59222	\N	\N
71377	SPECIFIC_DAY	3	7	2011-09-09	40199	59222	\N	\N
71378	SPECIFIC_DAY	3	0	2012-07-29	40199	59222	\N	\N
71379	SPECIFIC_DAY	3	0	2012-05-13	40199	59222	\N	\N
71380	SPECIFIC_DAY	3	7	2013-02-01	40199	59222	\N	\N
71381	SPECIFIC_DAY	3	7	2011-05-26	40199	59222	\N	\N
71382	SPECIFIC_DAY	3	7	2011-10-25	40199	59222	\N	\N
71383	SPECIFIC_DAY	3	7	2011-08-04	40199	59222	\N	\N
71384	SPECIFIC_DAY	3	7	2011-08-03	40199	59222	\N	\N
71385	SPECIFIC_DAY	3	7	2011-12-20	40199	59222	\N	\N
71386	SPECIFIC_DAY	3	7	2012-02-17	40199	59222	\N	\N
71387	SPECIFIC_DAY	3	0	2012-06-30	40199	59222	\N	\N
71388	SPECIFIC_DAY	3	0	2011-09-25	40199	59222	\N	\N
71389	SPECIFIC_DAY	3	7	2012-02-02	40199	59222	\N	\N
71390	SPECIFIC_DAY	3	7	2012-03-15	40199	59222	\N	\N
71391	SPECIFIC_DAY	3	7	2011-08-30	40199	59222	\N	\N
71392	SPECIFIC_DAY	3	0	2011-08-06	40199	59222	\N	\N
71393	SPECIFIC_DAY	3	7	2011-06-21	40199	59222	\N	\N
71394	SPECIFIC_DAY	3	7	2011-07-04	40199	59222	\N	\N
71395	SPECIFIC_DAY	3	7	2011-09-05	40199	59222	\N	\N
71396	SPECIFIC_DAY	3	7	2012-05-31	40199	59222	\N	\N
71397	SPECIFIC_DAY	3	7	2012-01-09	40199	59222	\N	\N
71398	SPECIFIC_DAY	3	7	2011-07-21	40199	59222	\N	\N
71399	SPECIFIC_DAY	3	7	2012-07-20	40199	59222	\N	\N
71400	SPECIFIC_DAY	3	7	2012-07-09	40199	59222	\N	\N
71401	SPECIFIC_DAY	3	7	2012-09-13	40199	59222	\N	\N
71402	SPECIFIC_DAY	3	7	2011-08-05	40199	59222	\N	\N
71403	SPECIFIC_DAY	3	7	2013-01-23	40199	59222	\N	\N
71404	SPECIFIC_DAY	3	0	2011-07-17	40199	59222	\N	\N
71405	SPECIFIC_DAY	3	7	2011-09-13	40199	59222	\N	\N
71406	SPECIFIC_DAY	3	7	2011-09-12	40199	59222	\N	\N
71407	SPECIFIC_DAY	3	0	2013-02-09	40199	59222	\N	\N
71408	SPECIFIC_DAY	3	7	2011-06-29	40199	59222	\N	\N
71409	SPECIFIC_DAY	3	0	2012-05-06	40199	59222	\N	\N
71410	SPECIFIC_DAY	3	0	2012-02-25	40199	59222	\N	\N
71411	SPECIFIC_DAY	3	7	2011-11-17	40199	59222	\N	\N
71412	SPECIFIC_DAY	3	7	2011-09-26	40199	59222	\N	\N
71413	SPECIFIC_DAY	3	7	2012-02-29	40199	59222	\N	\N
71414	SPECIFIC_DAY	3	0	2011-10-15	40199	59222	\N	\N
71415	SPECIFIC_DAY	3	7	2011-05-31	40199	59222	\N	\N
71416	SPECIFIC_DAY	3	0	2011-06-19	40199	59222	\N	\N
71417	SPECIFIC_DAY	3	7	2012-11-28	40199	59222	\N	\N
71418	SPECIFIC_DAY	3	7	2011-07-15	40199	59222	\N	\N
71419	SPECIFIC_DAY	3	7	2012-06-20	40199	59222	\N	\N
71420	SPECIFIC_DAY	3	7	2011-11-08	40199	59222	\N	\N
71421	SPECIFIC_DAY	3	7	2012-05-03	40199	59222	\N	\N
71422	SPECIFIC_DAY	3	7	2012-10-30	40199	59222	\N	\N
71423	SPECIFIC_DAY	3	7	2011-08-10	40199	59222	\N	\N
71424	SPECIFIC_DAY	3	7	2012-10-02	40199	59222	\N	\N
71425	SPECIFIC_DAY	3	0	2012-07-15	40199	59222	\N	\N
71426	SPECIFIC_DAY	3	7	2012-05-04	40199	59222	\N	\N
71427	SPECIFIC_DAY	3	7	2011-10-26	40199	59222	\N	\N
71428	SPECIFIC_DAY	3	7	2012-09-19	40199	59222	\N	\N
71429	SPECIFIC_DAY	3	7	2011-06-14	40199	59222	\N	\N
71430	SPECIFIC_DAY	3	7	2012-01-05	40199	59222	\N	\N
71431	SPECIFIC_DAY	3	0	2012-01-22	40199	59222	\N	\N
71432	SPECIFIC_DAY	3	0	2012-07-28	40199	59222	\N	\N
71433	SPECIFIC_DAY	3	0	2013-02-10	40199	59222	\N	\N
71434	SPECIFIC_DAY	3	7	2012-09-24	40199	59222	\N	\N
71435	SPECIFIC_DAY	3	7	2012-06-27	40199	59222	\N	\N
71436	SPECIFIC_DAY	3	7	2011-09-22	40199	59222	\N	\N
71437	SPECIFIC_DAY	3	7	2012-03-12	40199	59222	\N	\N
71438	SPECIFIC_DAY	3	7	2011-07-20	40199	59222	\N	\N
71439	SPECIFIC_DAY	3	0	2012-03-04	40199	59222	\N	\N
71440	SPECIFIC_DAY	3	0	2011-11-05	40199	59222	\N	\N
71441	SPECIFIC_DAY	3	0	2012-09-15	40199	59222	\N	\N
71442	SPECIFIC_DAY	3	7	2012-11-14	40199	59222	\N	\N
71443	SPECIFIC_DAY	3	7	2012-07-17	40199	59222	\N	\N
71444	SPECIFIC_DAY	3	7	2012-06-15	40199	59222	\N	\N
71445	SPECIFIC_DAY	3	7	2013-01-16	40199	59222	\N	\N
71446	SPECIFIC_DAY	3	7	2012-01-19	40199	59222	\N	\N
71447	SPECIFIC_DAY	3	0	2012-12-08	40199	59222	\N	\N
71448	SPECIFIC_DAY	3	7	2012-08-20	40199	59222	\N	\N
71449	SPECIFIC_DAY	3	0	2012-06-09	40199	59222	\N	\N
71450	SPECIFIC_DAY	3	0	2012-09-08	40199	59222	\N	\N
71451	SPECIFIC_DAY	3	0	2011-12-11	40199	59222	\N	\N
71452	SPECIFIC_DAY	3	0	2012-08-25	40199	59222	\N	\N
71453	SPECIFIC_DAY	3	7	2012-06-06	40199	59222	\N	\N
71454	SPECIFIC_DAY	3	7	2011-12-21	40199	59222	\N	\N
71455	SPECIFIC_DAY	3	0	2012-09-22	40199	59222	\N	\N
71456	SPECIFIC_DAY	3	7	2012-11-22	40199	59222	\N	\N
71457	SPECIFIC_DAY	3	7	2012-03-09	40199	59222	\N	\N
71458	SPECIFIC_DAY	3	7	2012-09-14	40199	59222	\N	\N
71459	SPECIFIC_DAY	3	7	2012-10-25	40199	59222	\N	\N
71460	SPECIFIC_DAY	3	0	2012-07-21	40199	59222	\N	\N
71461	SPECIFIC_DAY	3	7	2012-02-06	40199	59222	\N	\N
71462	SPECIFIC_DAY	3	7	2011-07-29	40199	59222	\N	\N
71463	SPECIFIC_DAY	3	7	2011-12-26	40199	59222	\N	\N
71464	SPECIFIC_DAY	3	7	2013-02-04	40199	59222	\N	\N
71465	SPECIFIC_DAY	3	0	2012-07-22	40199	59222	\N	\N
71466	SPECIFIC_DAY	3	7	2012-10-03	40199	59222	\N	\N
71467	SPECIFIC_DAY	3	7	2011-07-14	40199	59222	\N	\N
71468	SPECIFIC_DAY	3	7	2012-10-26	40199	59222	\N	\N
71469	SPECIFIC_DAY	3	7	2012-02-15	40199	59222	\N	\N
71470	SPECIFIC_DAY	3	7	2012-07-04	40199	59222	\N	\N
71471	SPECIFIC_DAY	3	7	2012-09-26	40199	59222	\N	\N
71472	SPECIFIC_DAY	3	7	2012-02-27	40199	59222	\N	\N
71473	SPECIFIC_DAY	3	7	2012-08-07	40199	59222	\N	\N
71474	SPECIFIC_DAY	3	7	2012-06-26	40199	59222	\N	\N
71475	SPECIFIC_DAY	3	0	2011-10-02	40199	59222	\N	\N
71476	SPECIFIC_DAY	3	0	2011-11-27	40199	59222	\N	\N
71477	SPECIFIC_DAY	3	0	2013-01-19	40199	59222	\N	\N
71478	SPECIFIC_DAY	3	7	2012-09-05	40199	59222	\N	\N
71479	SPECIFIC_DAY	3	0	2013-02-02	40199	59222	\N	\N
71480	SPECIFIC_DAY	3	7	2012-12-27	40199	59222	\N	\N
71481	SPECIFIC_DAY	3	7	2012-01-16	40199	59222	\N	\N
71482	SPECIFIC_DAY	3	7	2011-11-16	40199	59222	\N	\N
71483	SPECIFIC_DAY	3	7	2012-01-31	40199	59222	\N	\N
71484	SPECIFIC_DAY	3	7	2012-08-02	40199	59222	\N	\N
71485	SPECIFIC_DAY	3	7	2011-08-16	40199	59222	\N	\N
71486	SPECIFIC_DAY	3	0	2012-04-08	40199	59222	\N	\N
71487	SPECIFIC_DAY	3	7	2012-04-02	40199	59222	\N	\N
71488	SPECIFIC_DAY	3	7	2012-10-29	40199	59222	\N	\N
71489	SPECIFIC_DAY	3	7	2012-09-17	40199	59222	\N	\N
71490	SPECIFIC_DAY	3	0	2011-11-12	40199	59222	\N	\N
71491	SPECIFIC_DAY	3	0	2013-02-03	40199	59222	\N	\N
71492	SPECIFIC_DAY	3	0	2012-12-01	40199	59222	\N	\N
71493	SPECIFIC_DAY	3	7	2012-02-24	40199	59222	\N	\N
71494	SPECIFIC_DAY	3	7	2012-06-14	40199	59222	\N	\N
71495	SPECIFIC_DAY	3	7	2011-12-13	40199	59222	\N	\N
71496	SPECIFIC_DAY	3	7	2012-01-30	40199	59222	\N	\N
71497	SPECIFIC_DAY	3	7	2012-05-16	40199	59222	\N	\N
71498	SPECIFIC_DAY	3	7	2011-12-22	40199	59222	\N	\N
71499	SPECIFIC_DAY	3	7	2013-01-02	40199	59222	\N	\N
71500	SPECIFIC_DAY	3	7	2012-10-22	40199	59222	\N	\N
71501	SPECIFIC_DAY	3	0	2012-05-19	40199	59222	\N	\N
71502	SPECIFIC_DAY	3	0	2012-11-04	40199	59222	\N	\N
71503	SPECIFIC_DAY	3	7	2012-12-31	40199	59222	\N	\N
71504	SPECIFIC_DAY	3	7	2012-04-19	40199	59222	\N	\N
71505	SPECIFIC_DAY	3	7	2011-05-30	40199	59222	\N	\N
71506	SPECIFIC_DAY	3	7	2012-08-15	40199	59222	\N	\N
71507	SPECIFIC_DAY	3	0	2012-03-18	40199	59222	\N	\N
71508	SPECIFIC_DAY	3	7	2012-08-30	40199	59222	\N	\N
71509	SPECIFIC_DAY	3	7	2012-05-17	40199	59222	\N	\N
71510	SPECIFIC_DAY	3	7	2012-08-16	40199	59222	\N	\N
71511	SPECIFIC_DAY	3	7	2011-09-21	40199	59222	\N	\N
71512	SPECIFIC_DAY	3	7	2013-02-07	40199	59222	\N	\N
71513	SPECIFIC_DAY	3	7	2011-06-01	40199	59222	\N	\N
71514	SPECIFIC_DAY	3	7	2011-12-09	40199	59222	\N	\N
71515	SPECIFIC_DAY	3	7	2012-07-16	40199	59222	\N	\N
71516	SPECIFIC_DAY	3	7	2012-02-16	40199	59222	\N	\N
71517	SPECIFIC_DAY	3	7	2011-06-02	40199	59222	\N	\N
71518	SPECIFIC_DAY	3	7	2011-11-29	40199	59222	\N	\N
71519	SPECIFIC_DAY	3	7	2011-06-06	40199	59222	\N	\N
71520	SPECIFIC_DAY	3	7	2011-06-07	40199	59222	\N	\N
71521	SPECIFIC_DAY	3	0	2012-01-29	40199	59222	\N	\N
71522	SPECIFIC_DAY	3	7	2011-10-28	40199	59222	\N	\N
71523	SPECIFIC_DAY	3	7	2012-12-24	40199	59222	\N	\N
71524	SPECIFIC_DAY	3	7	2012-11-23	40199	59222	\N	\N
71525	SPECIFIC_DAY	3	0	2012-01-01	40199	59222	\N	\N
71526	SPECIFIC_DAY	3	7	2012-10-09	40199	59222	\N	\N
71527	SPECIFIC_DAY	3	7	2011-09-19	40199	59222	\N	\N
71528	SPECIFIC_DAY	3	7	2011-10-20	40199	59222	\N	\N
71529	SPECIFIC_DAY	3	7	2012-09-04	40199	59222	\N	\N
71530	SPECIFIC_DAY	3	0	2012-01-07	40199	59222	\N	\N
71531	SPECIFIC_DAY	3	0	2013-01-13	40199	59222	\N	\N
71532	SPECIFIC_DAY	3	7	2012-12-28	40199	59222	\N	\N
71533	SPECIFIC_DAY	3	7	2012-01-24	40199	59222	\N	\N
71534	SPECIFIC_DAY	3	7	2012-04-24	40199	59222	\N	\N
71535	SPECIFIC_DAY	3	0	2011-12-25	40199	59222	\N	\N
71536	SPECIFIC_DAY	3	7	2012-04-10	40199	59222	\N	\N
71537	SPECIFIC_DAY	3	7	2012-07-27	40199	59222	\N	\N
71538	SPECIFIC_DAY	3	7	2012-03-22	40199	59222	\N	\N
71539	SPECIFIC_DAY	3	7	2013-01-22	40199	59222	\N	\N
71540	SPECIFIC_DAY	3	7	2011-09-30	40199	59222	\N	\N
71541	SPECIFIC_DAY	3	7	2011-06-09	40199	59222	\N	\N
71542	SPECIFIC_DAY	3	0	2012-02-19	40199	59222	\N	\N
71543	SPECIFIC_DAY	3	7	2012-10-15	40199	59222	\N	\N
71544	SPECIFIC_DAY	3	7	2012-12-13	40199	59222	\N	\N
71545	SPECIFIC_DAY	3	7	2011-10-10	40199	59222	\N	\N
71546	SPECIFIC_DAY	3	7	2012-05-03	40199	59201	\N	\N
71547	SPECIFIC_DAY	3	7	2011-05-31	40199	59201	\N	\N
71548	SPECIFIC_DAY	3	0	2012-03-03	40199	59201	\N	\N
71549	SPECIFIC_DAY	3	7	2011-12-28	40199	59201	\N	\N
71550	SPECIFIC_DAY	3	7	2012-03-09	40199	59201	\N	\N
71551	SPECIFIC_DAY	3	7	2012-08-10	40199	59201	\N	\N
71552	SPECIFIC_DAY	3	7	2012-03-21	40199	59201	\N	\N
71553	SPECIFIC_DAY	3	0	2011-07-30	40199	59201	\N	\N
71554	SPECIFIC_DAY	3	7	2011-12-14	40199	59201	\N	\N
71555	SPECIFIC_DAY	3	7	2012-04-03	40199	59201	\N	\N
71556	SPECIFIC_DAY	3	0	2012-06-24	40199	59201	\N	\N
71557	SPECIFIC_DAY	3	7	2011-07-27	40199	59201	\N	\N
71558	SPECIFIC_DAY	3	7	2012-12-20	40199	59201	\N	\N
71559	SPECIFIC_DAY	3	0	2011-11-19	40199	59201	\N	\N
71560	SPECIFIC_DAY	3	7	2012-10-09	40199	59201	\N	\N
71561	SPECIFIC_DAY	3	7	2012-09-04	40199	59201	\N	\N
71562	SPECIFIC_DAY	3	7	2011-08-11	40199	59201	\N	\N
71563	SPECIFIC_DAY	3	7	2011-09-07	40199	59201	\N	\N
71564	SPECIFIC_DAY	3	0	2012-08-19	40199	59201	\N	\N
71565	SPECIFIC_DAY	3	7	2012-05-14	40199	59201	\N	\N
71566	SPECIFIC_DAY	3	7	2011-08-15	40199	59201	\N	\N
71567	SPECIFIC_DAY	3	7	2011-12-02	40199	59201	\N	\N
71568	SPECIFIC_DAY	3	7	2012-12-18	40199	59201	\N	\N
71569	SPECIFIC_DAY	3	0	2011-07-03	40199	59201	\N	\N
71570	SPECIFIC_DAY	3	7	2012-04-17	40199	59201	\N	\N
71571	SPECIFIC_DAY	3	7	2011-11-04	40199	59201	\N	\N
71572	SPECIFIC_DAY	3	7	2012-01-05	40199	59201	\N	\N
71573	SPECIFIC_DAY	3	0	2012-08-25	40199	59201	\N	\N
71574	SPECIFIC_DAY	3	7	2011-12-30	40199	59201	\N	\N
71575	SPECIFIC_DAY	3	7	2012-02-15	40199	59201	\N	\N
71576	SPECIFIC_DAY	3	7	2012-03-01	40199	59201	\N	\N
71577	SPECIFIC_DAY	3	7	2013-02-07	40199	59201	\N	\N
71578	SPECIFIC_DAY	3	7	2012-10-17	40199	59201	\N	\N
71579	SPECIFIC_DAY	3	0	2012-05-05	40199	59201	\N	\N
71580	SPECIFIC_DAY	3	7	2012-01-25	40199	59201	\N	\N
71581	SPECIFIC_DAY	3	7	2011-12-27	40199	59201	\N	\N
71582	SPECIFIC_DAY	3	0	2011-08-28	40199	59201	\N	\N
71583	SPECIFIC_DAY	3	7	2012-11-22	40199	59201	\N	\N
71584	SPECIFIC_DAY	3	7	2012-12-26	40199	59201	\N	\N
71585	SPECIFIC_DAY	3	7	2011-06-03	40199	59201	\N	\N
71586	SPECIFIC_DAY	3	7	2012-11-14	40199	59201	\N	\N
71587	SPECIFIC_DAY	3	7	2012-04-18	40199	59201	\N	\N
71588	SPECIFIC_DAY	3	7	2012-09-07	40199	59201	\N	\N
71589	SPECIFIC_DAY	3	7	2012-02-07	40199	59201	\N	\N
71590	SPECIFIC_DAY	3	0	2011-12-24	40199	59201	\N	\N
71591	SPECIFIC_DAY	3	0	2011-12-10	40199	59201	\N	\N
71592	SPECIFIC_DAY	3	7	2011-06-06	40199	59201	\N	\N
71593	SPECIFIC_DAY	3	7	2012-11-15	40199	59201	\N	\N
71594	SPECIFIC_DAY	3	7	2012-07-19	40199	59201	\N	\N
71595	SPECIFIC_DAY	3	7	2011-10-07	40199	59201	\N	\N
71596	SPECIFIC_DAY	3	7	2011-08-26	40199	59201	\N	\N
71597	SPECIFIC_DAY	3	7	2011-11-11	40199	59201	\N	\N
71598	SPECIFIC_DAY	3	7	2012-12-06	40199	59201	\N	\N
71599	SPECIFIC_DAY	3	7	2011-08-03	40199	59201	\N	\N
71600	SPECIFIC_DAY	3	7	2012-03-20	40199	59201	\N	\N
71601	SPECIFIC_DAY	3	7	2011-11-08	40199	59201	\N	\N
71602	SPECIFIC_DAY	3	7	2012-05-08	40199	59201	\N	\N
71603	SPECIFIC_DAY	3	7	2012-04-25	40199	59201	\N	\N
71604	SPECIFIC_DAY	3	7	2011-10-05	40199	59201	\N	\N
71605	SPECIFIC_DAY	3	7	2012-04-12	40199	59201	\N	\N
71606	SPECIFIC_DAY	3	7	2011-09-09	40199	59201	\N	\N
71607	SPECIFIC_DAY	3	0	2012-06-23	40199	59201	\N	\N
71608	SPECIFIC_DAY	3	7	2012-05-04	40199	59201	\N	\N
71609	SPECIFIC_DAY	3	7	2012-05-30	40199	59201	\N	\N
71610	SPECIFIC_DAY	3	7	2012-06-12	40199	59201	\N	\N
71611	SPECIFIC_DAY	3	7	2012-11-28	40199	59201	\N	\N
71612	SPECIFIC_DAY	3	7	2011-08-29	40199	59201	\N	\N
71613	SPECIFIC_DAY	3	0	2012-10-07	40199	59201	\N	\N
71614	SPECIFIC_DAY	3	0	2012-06-16	40199	59201	\N	\N
71615	SPECIFIC_DAY	3	7	2012-01-27	40199	59201	\N	\N
71616	SPECIFIC_DAY	3	0	2012-12-08	40199	59201	\N	\N
71617	SPECIFIC_DAY	3	7	2012-12-21	40199	59201	\N	\N
71618	SPECIFIC_DAY	3	7	2012-07-27	40199	59201	\N	\N
71619	SPECIFIC_DAY	3	0	2011-08-07	40199	59201	\N	\N
71620	SPECIFIC_DAY	3	7	2013-01-29	40199	59201	\N	\N
71621	SPECIFIC_DAY	3	7	2012-07-09	40199	59201	\N	\N
71622	SPECIFIC_DAY	3	0	2013-01-06	40199	59201	\N	\N
71623	SPECIFIC_DAY	3	0	2012-03-04	40199	59201	\N	\N
71624	SPECIFIC_DAY	3	0	2011-09-11	40199	59201	\N	\N
71625	SPECIFIC_DAY	3	7	2012-11-01	40199	59201	\N	\N
71626	SPECIFIC_DAY	3	7	2011-09-14	40199	59201	\N	\N
71627	SPECIFIC_DAY	3	7	2013-01-01	40199	59201	\N	\N
71628	SPECIFIC_DAY	3	7	2012-01-11	40199	59201	\N	\N
71629	SPECIFIC_DAY	3	0	2011-09-04	40199	59201	\N	\N
71630	SPECIFIC_DAY	3	7	2012-10-01	40199	59201	\N	\N
71631	SPECIFIC_DAY	3	7	2012-03-29	40199	59201	\N	\N
71632	SPECIFIC_DAY	3	0	2011-08-21	40199	59201	\N	\N
71633	SPECIFIC_DAY	3	7	2011-06-02	40199	59201	\N	\N
71634	SPECIFIC_DAY	3	0	2011-12-31	40199	59201	\N	\N
71635	SPECIFIC_DAY	3	0	2012-08-11	40199	59201	\N	\N
71636	SPECIFIC_DAY	3	0	2011-09-03	40199	59201	\N	\N
71637	SPECIFIC_DAY	3	7	2012-03-16	40199	59201	\N	\N
71638	SPECIFIC_DAY	3	7	2012-02-21	40199	59201	\N	\N
71639	SPECIFIC_DAY	3	7	2012-11-07	40199	59201	\N	\N
71640	SPECIFIC_DAY	3	0	2011-10-08	40199	59201	\N	\N
71641	SPECIFIC_DAY	3	7	2013-02-11	40199	59201	\N	\N
71642	SPECIFIC_DAY	3	7	2011-06-30	40199	59201	\N	\N
71643	SPECIFIC_DAY	3	7	2012-11-06	40199	59201	\N	\N
71644	SPECIFIC_DAY	3	7	2013-01-14	40199	59201	\N	\N
71645	SPECIFIC_DAY	3	0	2012-04-14	40199	59201	\N	\N
71646	SPECIFIC_DAY	3	7	2012-01-17	40199	59201	\N	\N
71647	SPECIFIC_DAY	3	7	2012-05-22	40199	59201	\N	\N
71648	SPECIFIC_DAY	3	7	2012-12-25	40199	59201	\N	\N
71649	SPECIFIC_DAY	3	0	2012-03-31	40199	59201	\N	\N
71650	SPECIFIC_DAY	3	7	2011-09-06	40199	59201	\N	\N
71651	SPECIFIC_DAY	3	7	2012-02-13	40199	59201	\N	\N
71652	SPECIFIC_DAY	3	7	2011-07-15	40199	59201	\N	\N
71653	SPECIFIC_DAY	3	7	2012-02-27	40199	59201	\N	\N
71654	SPECIFIC_DAY	3	7	2012-04-23	40199	59201	\N	\N
71655	SPECIFIC_DAY	3	7	2011-12-20	40199	59201	\N	\N
71656	SPECIFIC_DAY	3	7	2012-11-19	40199	59201	\N	\N
71657	SPECIFIC_DAY	3	0	2011-11-13	40199	59201	\N	\N
71658	SPECIFIC_DAY	3	7	2011-07-20	40199	59201	\N	\N
71659	SPECIFIC_DAY	3	7	2012-11-09	40199	59201	\N	\N
71660	SPECIFIC_DAY	3	7	2011-10-04	40199	59201	\N	\N
71661	SPECIFIC_DAY	3	0	2012-01-28	40199	59201	\N	\N
71662	SPECIFIC_DAY	3	7	2011-08-16	40199	59201	\N	\N
71663	SPECIFIC_DAY	3	0	2012-10-27	40199	59201	\N	\N
71664	SPECIFIC_DAY	3	7	2013-01-11	40199	59201	\N	\N
71665	SPECIFIC_DAY	3	7	2011-05-30	40199	59201	\N	\N
71666	SPECIFIC_DAY	3	7	2011-12-16	40199	59201	\N	\N
71667	SPECIFIC_DAY	3	7	2012-04-30	40199	59201	\N	\N
71668	SPECIFIC_DAY	3	7	2011-11-09	40199	59201	\N	\N
71669	SPECIFIC_DAY	3	7	2012-09-05	40199	59201	\N	\N
71670	SPECIFIC_DAY	3	7	2012-07-18	40199	59201	\N	\N
71671	SPECIFIC_DAY	3	7	2012-05-02	40199	59201	\N	\N
71672	SPECIFIC_DAY	3	7	2011-10-19	40199	59201	\N	\N
71673	SPECIFIC_DAY	3	0	2012-05-19	40199	59201	\N	\N
71674	SPECIFIC_DAY	3	7	2012-11-02	40199	59201	\N	\N
71675	SPECIFIC_DAY	3	0	2011-08-20	40199	59201	\N	\N
71676	SPECIFIC_DAY	3	7	2012-10-18	40199	59201	\N	\N
71677	SPECIFIC_DAY	3	7	2012-05-16	40199	59201	\N	\N
71678	SPECIFIC_DAY	3	0	2013-01-27	40199	59201	\N	\N
71679	SPECIFIC_DAY	3	0	2011-10-22	40199	59201	\N	\N
71680	SPECIFIC_DAY	3	7	2012-09-12	40199	59201	\N	\N
71681	SPECIFIC_DAY	3	7	2013-02-06	40199	59201	\N	\N
71682	SPECIFIC_DAY	3	7	2012-10-25	40199	59201	\N	\N
71683	SPECIFIC_DAY	3	0	2012-09-16	40199	59201	\N	\N
71684	SPECIFIC_DAY	3	7	2011-11-14	40199	59201	\N	\N
71685	SPECIFIC_DAY	3	7	2012-08-20	40199	59201	\N	\N
71686	SPECIFIC_DAY	3	7	2012-08-02	40199	59201	\N	\N
71687	SPECIFIC_DAY	3	7	2011-09-28	40199	59201	\N	\N
71688	SPECIFIC_DAY	3	7	2012-11-05	40199	59201	\N	\N
71689	SPECIFIC_DAY	3	7	2012-01-06	40199	59201	\N	\N
71690	SPECIFIC_DAY	3	7	2012-09-26	40199	59201	\N	\N
71691	SPECIFIC_DAY	3	7	2012-03-02	40199	59201	\N	\N
71692	SPECIFIC_DAY	3	7	2011-11-18	40199	59201	\N	\N
71693	SPECIFIC_DAY	3	7	2011-12-05	40199	59201	\N	\N
71694	SPECIFIC_DAY	3	7	2012-02-01	40199	59201	\N	\N
71695	SPECIFIC_DAY	3	0	2012-09-30	40199	59201	\N	\N
71696	SPECIFIC_DAY	3	0	2011-09-17	40199	59201	\N	\N
71697	SPECIFIC_DAY	3	7	2011-08-09	40199	59201	\N	\N
71698	SPECIFIC_DAY	3	7	2012-09-21	40199	59201	\N	\N
71699	SPECIFIC_DAY	3	7	2013-01-17	40199	59201	\N	\N
71700	SPECIFIC_DAY	3	7	2011-09-21	40199	59201	\N	\N
71701	SPECIFIC_DAY	3	7	2012-03-26	40199	59201	\N	\N
71702	SPECIFIC_DAY	3	7	2012-09-19	40199	59201	\N	\N
71703	SPECIFIC_DAY	3	0	2011-05-29	40199	59201	\N	\N
71704	SPECIFIC_DAY	3	0	2012-04-28	40199	59201	\N	\N
71705	SPECIFIC_DAY	3	7	2011-09-29	40199	59201	\N	\N
71706	SPECIFIC_DAY	3	7	2013-01-25	40199	59201	\N	\N
71707	SPECIFIC_DAY	3	0	2011-10-30	40199	59201	\N	\N
71708	SPECIFIC_DAY	3	7	2013-01-16	40199	59201	\N	\N
71709	SPECIFIC_DAY	3	7	2011-06-07	40199	59201	\N	\N
71710	SPECIFIC_DAY	3	7	2012-11-30	40199	59201	\N	\N
71711	SPECIFIC_DAY	3	7	2012-08-03	40199	59201	\N	\N
71712	SPECIFIC_DAY	3	7	2011-11-29	40199	59201	\N	\N
71713	SPECIFIC_DAY	3	7	2013-02-08	40199	59201	\N	\N
71714	SPECIFIC_DAY	3	7	2012-07-12	40199	59201	\N	\N
71715	SPECIFIC_DAY	3	0	2013-02-09	40199	59201	\N	\N
71716	SPECIFIC_DAY	3	0	2013-01-12	40199	59201	\N	\N
71717	SPECIFIC_DAY	3	0	2013-01-13	40199	59201	\N	\N
71718	SPECIFIC_DAY	3	7	2011-08-04	40199	59201	\N	\N
71719	SPECIFIC_DAY	3	7	2012-01-20	40199	59201	\N	\N
71720	SPECIFIC_DAY	3	7	2012-06-07	40199	59201	\N	\N
71721	SPECIFIC_DAY	3	0	2012-01-21	40199	59201	\N	\N
71722	SPECIFIC_DAY	3	7	2011-05-26	40199	59201	\N	\N
71723	SPECIFIC_DAY	3	7	2012-04-19	40199	59201	\N	\N
71724	SPECIFIC_DAY	3	0	2012-09-09	40199	59201	\N	\N
71725	SPECIFIC_DAY	3	7	2012-10-05	40199	59201	\N	\N
71726	SPECIFIC_DAY	3	0	2012-04-29	40199	59201	\N	\N
71727	SPECIFIC_DAY	3	7	2011-11-25	40199	59201	\N	\N
71728	SPECIFIC_DAY	3	7	2012-10-12	40199	59201	\N	\N
71729	SPECIFIC_DAY	3	7	2013-02-12	40199	59201	\N	\N
71730	SPECIFIC_DAY	3	7	2012-03-28	40199	59201	\N	\N
71731	SPECIFIC_DAY	3	7	2012-10-16	40199	59201	\N	\N
71732	SPECIFIC_DAY	3	0	2011-12-25	40199	59201	\N	\N
71733	SPECIFIC_DAY	3	0	2011-06-04	40199	59201	\N	\N
71734	SPECIFIC_DAY	3	7	2012-06-05	40199	59201	\N	\N
71735	SPECIFIC_DAY	3	7	2012-09-14	40199	59201	\N	\N
71736	SPECIFIC_DAY	3	7	2011-09-26	40199	59201	\N	\N
71737	SPECIFIC_DAY	3	7	2012-01-31	40199	59201	\N	\N
71738	SPECIFIC_DAY	3	7	2012-03-14	40199	59201	\N	\N
71739	SPECIFIC_DAY	3	7	2012-10-08	40199	59201	\N	\N
71740	SPECIFIC_DAY	3	7	2012-08-14	40199	59201	\N	\N
71741	SPECIFIC_DAY	3	0	2012-05-27	40199	59201	\N	\N
71742	SPECIFIC_DAY	3	7	2012-08-16	40199	59201	\N	\N
71743	SPECIFIC_DAY	3	7	2012-11-12	40199	59201	\N	\N
71744	SPECIFIC_DAY	3	7	2012-12-12	40199	59201	\N	\N
71745	SPECIFIC_DAY	3	7	2012-06-14	40199	59201	\N	\N
71746	SPECIFIC_DAY	3	0	2012-07-21	40199	59201	\N	\N
71747	SPECIFIC_DAY	3	0	2011-10-29	40199	59201	\N	\N
71748	SPECIFIC_DAY	3	0	2012-02-18	40199	59201	\N	\N
71749	SPECIFIC_DAY	3	7	2011-12-26	40199	59201	\N	\N
71750	SPECIFIC_DAY	3	7	2012-10-15	40199	59201	\N	\N
71751	SPECIFIC_DAY	3	7	2012-02-28	40199	59201	\N	\N
71752	SPECIFIC_DAY	3	7	2012-05-31	40199	59201	\N	\N
71753	SPECIFIC_DAY	3	0	2012-07-14	40199	59201	\N	\N
71754	SPECIFIC_DAY	3	7	2011-07-21	40199	59201	\N	\N
71755	SPECIFIC_DAY	3	7	2011-08-10	40199	59201	\N	\N
71756	SPECIFIC_DAY	3	7	2011-10-24	40199	59201	\N	\N
71757	SPECIFIC_DAY	3	7	2011-10-06	40199	59201	\N	\N
71758	SPECIFIC_DAY	3	7	2012-03-22	40199	59201	\N	\N
71759	SPECIFIC_DAY	3	7	2012-07-13	40199	59201	\N	\N
71760	SPECIFIC_DAY	3	7	2012-12-28	40199	59201	\N	\N
71761	SPECIFIC_DAY	3	7	2012-08-23	40199	59201	\N	\N
71762	SPECIFIC_DAY	3	7	2011-07-07	40199	59201	\N	\N
71763	SPECIFIC_DAY	3	7	2012-05-21	40199	59201	\N	\N
71764	SPECIFIC_DAY	3	7	2012-05-25	40199	59201	\N	\N
71765	SPECIFIC_DAY	3	7	2011-07-29	40199	59201	\N	\N
71766	SPECIFIC_DAY	3	7	2012-04-20	40199	59201	\N	\N
71767	SPECIFIC_DAY	3	0	2011-10-16	40199	59201	\N	\N
71768	SPECIFIC_DAY	3	7	2012-08-01	40199	59201	\N	\N
71769	SPECIFIC_DAY	3	7	2012-06-08	40199	59201	\N	\N
71770	SPECIFIC_DAY	3	7	2013-01-04	40199	59201	\N	\N
71771	SPECIFIC_DAY	3	7	2012-12-24	40199	59201	\N	\N
71772	SPECIFIC_DAY	3	7	2011-10-12	40199	59201	\N	\N
71773	SPECIFIC_DAY	3	7	2012-08-30	40199	59201	\N	\N
71774	SPECIFIC_DAY	3	0	2011-09-24	40199	59201	\N	\N
71775	SPECIFIC_DAY	3	7	2011-09-13	40199	59201	\N	\N
71776	SPECIFIC_DAY	3	7	2012-02-29	40199	59201	\N	\N
71777	SPECIFIC_DAY	3	7	2013-01-28	40199	59201	\N	\N
71778	SPECIFIC_DAY	3	7	2011-07-28	40199	59201	\N	\N
71779	SPECIFIC_DAY	3	7	2011-10-10	40199	59201	\N	\N
71780	SPECIFIC_DAY	3	0	2013-02-02	40199	59201	\N	\N
71781	SPECIFIC_DAY	3	0	2011-08-06	40199	59201	\N	\N
71782	SPECIFIC_DAY	3	7	2011-07-04	40199	59201	\N	\N
71783	SPECIFIC_DAY	3	7	2012-02-02	40199	59201	\N	\N
71784	SPECIFIC_DAY	3	7	2012-01-23	40199	59201	\N	\N
71785	SPECIFIC_DAY	3	0	2012-10-21	40199	59201	\N	\N
71786	SPECIFIC_DAY	3	0	2012-06-17	40199	59201	\N	\N
71787	SPECIFIC_DAY	3	0	2011-12-18	40199	59201	\N	\N
71788	SPECIFIC_DAY	3	0	2012-12-01	40199	59201	\N	\N
71789	SPECIFIC_DAY	3	7	2011-11-07	40199	59201	\N	\N
71790	SPECIFIC_DAY	3	0	2013-01-26	40199	59201	\N	\N
71791	SPECIFIC_DAY	3	7	2011-08-05	40199	59201	\N	\N
71792	SPECIFIC_DAY	3	0	2012-02-19	40199	59201	\N	\N
71793	SPECIFIC_DAY	3	7	2011-06-01	40199	59201	\N	\N
71794	SPECIFIC_DAY	3	7	2012-05-23	40199	59201	\N	\N
71795	SPECIFIC_DAY	3	7	2012-12-31	40199	59201	\N	\N
71796	SPECIFIC_DAY	3	0	2012-07-22	40199	59201	\N	\N
71797	SPECIFIC_DAY	3	0	2012-12-02	40199	59201	\N	\N
71798	SPECIFIC_DAY	3	7	2011-11-17	40199	59201	\N	\N
71799	SPECIFIC_DAY	3	7	2012-09-06	40199	59201	\N	\N
71800	SPECIFIC_DAY	3	7	2012-07-20	40199	59201	\N	\N
71801	SPECIFIC_DAY	3	7	2012-01-03	40199	59201	\N	\N
71802	SPECIFIC_DAY	3	7	2012-02-03	40199	59201	\N	\N
71803	SPECIFIC_DAY	3	7	2011-10-13	40199	59201	\N	\N
71804	SPECIFIC_DAY	3	7	2011-05-27	40199	59201	\N	\N
71805	SPECIFIC_DAY	3	7	2011-08-30	40199	59201	\N	\N
71806	SPECIFIC_DAY	3	0	2012-07-29	40199	59201	\N	\N
71807	SPECIFIC_DAY	3	7	2011-11-22	40199	59201	\N	\N
71808	SPECIFIC_DAY	3	7	2012-06-21	40199	59201	\N	\N
71809	SPECIFIC_DAY	3	7	2012-12-04	40199	59201	\N	\N
71810	SPECIFIC_DAY	3	0	2012-05-12	40199	59201	\N	\N
71811	SPECIFIC_DAY	3	0	2011-12-03	40199	59201	\N	\N
71812	SPECIFIC_DAY	3	7	2012-10-26	40199	59201	\N	\N
71813	SPECIFIC_DAY	3	7	2012-02-23	40199	59201	\N	\N
71814	SPECIFIC_DAY	3	0	2011-10-09	40199	59201	\N	\N
71815	SPECIFIC_DAY	3	7	2012-06-25	40199	59201	\N	\N
71816	SPECIFIC_DAY	3	7	2012-04-10	40199	59201	\N	\N
71817	SPECIFIC_DAY	3	0	2011-11-26	40199	59201	\N	\N
71818	SPECIFIC_DAY	3	0	2012-12-29	40199	59201	\N	\N
71819	SPECIFIC_DAY	3	7	2011-06-16	40199	59201	\N	\N
71820	SPECIFIC_DAY	3	7	2012-07-25	40199	59201	\N	\N
71821	SPECIFIC_DAY	3	7	2012-09-13	40199	59201	\N	\N
71822	SPECIFIC_DAY	3	7	2012-05-29	40199	59201	\N	\N
71823	SPECIFIC_DAY	3	7	2012-07-26	40199	59201	\N	\N
71824	SPECIFIC_DAY	3	0	2011-07-31	40199	59201	\N	\N
71825	SPECIFIC_DAY	3	7	2012-10-22	40199	59201	\N	\N
71826	SPECIFIC_DAY	3	0	2012-07-28	40199	59201	\N	\N
71827	SPECIFIC_DAY	3	0	2012-11-24	40199	59201	\N	\N
71828	SPECIFIC_DAY	3	7	2013-01-21	40199	59201	\N	\N
71829	SPECIFIC_DAY	3	7	2012-05-01	40199	59201	\N	\N
71830	SPECIFIC_DAY	3	7	2012-03-12	40199	59201	\N	\N
71831	SPECIFIC_DAY	3	7	2011-12-19	40199	59201	\N	\N
71832	SPECIFIC_DAY	3	7	2011-10-31	40199	59201	\N	\N
71833	SPECIFIC_DAY	3	7	2011-06-27	40199	59201	\N	\N
71834	SPECIFIC_DAY	3	7	2012-06-27	40199	59201	\N	\N
71835	SPECIFIC_DAY	3	0	2011-07-24	40199	59201	\N	\N
71836	SPECIFIC_DAY	3	7	2011-06-20	40199	59201	\N	\N
71837	SPECIFIC_DAY	3	0	2011-11-27	40199	59201	\N	\N
71838	SPECIFIC_DAY	3	7	2012-08-08	40199	59201	\N	\N
71839	SPECIFIC_DAY	3	0	2012-07-07	40199	59201	\N	\N
71840	SPECIFIC_DAY	3	0	2012-04-01	40199	59201	\N	\N
71841	SPECIFIC_DAY	3	7	2012-03-05	40199	59201	\N	\N
71842	SPECIFIC_DAY	3	7	2013-01-10	40199	59201	\N	\N
71843	SPECIFIC_DAY	3	7	2011-11-28	40199	59201	\N	\N
71844	SPECIFIC_DAY	3	7	2012-01-16	40199	59201	\N	\N
71845	SPECIFIC_DAY	3	7	2012-08-22	40199	59201	\N	\N
71846	SPECIFIC_DAY	3	7	2011-12-01	40199	59201	\N	\N
71847	SPECIFIC_DAY	3	7	2011-11-01	40199	59201	\N	\N
71848	SPECIFIC_DAY	3	0	2012-11-17	40199	59201	\N	\N
71849	SPECIFIC_DAY	3	7	2011-11-02	40199	59201	\N	\N
71850	SPECIFIC_DAY	3	7	2011-10-28	40199	59201	\N	\N
71851	SPECIFIC_DAY	3	0	2011-06-11	40199	59201	\N	\N
71852	SPECIFIC_DAY	3	7	2012-08-15	40199	59201	\N	\N
71853	SPECIFIC_DAY	3	0	2012-09-15	40199	59201	\N	\N
71854	SPECIFIC_DAY	3	0	2012-02-25	40199	59201	\N	\N
71855	SPECIFIC_DAY	3	7	2012-10-19	40199	59201	\N	\N
71856	SPECIFIC_DAY	3	7	2011-07-18	40199	59201	\N	\N
71857	SPECIFIC_DAY	3	7	2012-08-21	40199	59201	\N	\N
71858	SPECIFIC_DAY	3	7	2011-07-12	40199	59201	\N	\N
71859	SPECIFIC_DAY	3	7	2011-09-01	40199	59201	\N	\N
71860	SPECIFIC_DAY	3	7	2012-11-16	40199	59201	\N	\N
71861	SPECIFIC_DAY	3	7	2011-08-31	40199	59201	\N	\N
71862	SPECIFIC_DAY	3	7	2012-05-10	40199	59201	\N	\N
71863	SPECIFIC_DAY	3	0	2011-07-23	40199	59201	\N	\N
71864	SPECIFIC_DAY	3	7	2012-07-03	40199	59201	\N	\N
71865	SPECIFIC_DAY	3	7	2011-12-12	40199	59201	\N	\N
71866	SPECIFIC_DAY	3	0	2012-12-23	40199	59201	\N	\N
71867	SPECIFIC_DAY	3	0	2012-03-11	40199	59201	\N	\N
71868	SPECIFIC_DAY	3	7	2013-02-05	40199	59201	\N	\N
71869	SPECIFIC_DAY	3	7	2012-12-14	40199	59201	\N	\N
71870	SPECIFIC_DAY	3	7	2011-08-08	40199	59201	\N	\N
71871	SPECIFIC_DAY	3	7	2012-12-13	40199	59201	\N	\N
71872	SPECIFIC_DAY	3	7	2011-08-01	40199	59201	\N	\N
71873	SPECIFIC_DAY	3	7	2011-09-15	40199	59201	\N	\N
71874	SPECIFIC_DAY	3	7	2013-01-23	40199	59201	\N	\N
71875	SPECIFIC_DAY	3	7	2012-12-05	40199	59201	\N	\N
71876	SPECIFIC_DAY	3	7	2012-02-14	40199	59201	\N	\N
71877	SPECIFIC_DAY	3	7	2012-05-07	40199	59201	\N	\N
71878	SPECIFIC_DAY	3	7	2011-06-13	40199	59201	\N	\N
71879	SPECIFIC_DAY	3	7	2011-11-10	40199	59201	\N	\N
71880	SPECIFIC_DAY	3	7	2012-02-17	40199	59201	\N	\N
71881	SPECIFIC_DAY	3	7	2012-06-26	40199	59201	\N	\N
71882	SPECIFIC_DAY	3	7	2012-01-02	40199	59201	\N	\N
71883	SPECIFIC_DAY	3	0	2013-01-05	40199	59201	\N	\N
71884	SPECIFIC_DAY	3	7	2012-12-11	40199	59201	\N	\N
71885	SPECIFIC_DAY	3	7	2012-07-06	40199	59201	\N	\N
71886	SPECIFIC_DAY	3	0	2013-02-10	40199	59201	\N	\N
71887	SPECIFIC_DAY	3	7	2012-02-09	40199	59201	\N	\N
71888	SPECIFIC_DAY	3	7	2011-06-08	40199	59201	\N	\N
71889	SPECIFIC_DAY	3	0	2011-09-10	40199	59201	\N	\N
71890	SPECIFIC_DAY	3	7	2011-07-08	40199	59201	\N	\N
71891	SPECIFIC_DAY	3	0	2012-05-13	40199	59201	\N	\N
71892	SPECIFIC_DAY	3	7	2012-04-16	40199	59201	\N	\N
71893	SPECIFIC_DAY	3	7	2012-06-28	40199	59201	\N	\N
71894	SPECIFIC_DAY	3	7	2012-09-11	40199	59201	\N	\N
71895	SPECIFIC_DAY	3	7	2011-10-26	40199	59201	\N	\N
71896	SPECIFIC_DAY	3	7	2011-11-21	40199	59201	\N	\N
71897	SPECIFIC_DAY	3	7	2012-10-10	40199	59201	\N	\N
71898	SPECIFIC_DAY	3	0	2012-12-16	40199	59201	\N	\N
71899	SPECIFIC_DAY	3	0	2012-02-26	40199	59201	\N	\N
71900	SPECIFIC_DAY	3	7	2011-09-30	40199	59201	\N	\N
71901	SPECIFIC_DAY	3	7	2011-08-18	40199	59201	\N	\N
71902	SPECIFIC_DAY	3	0	2011-06-18	40199	59201	\N	\N
71903	SPECIFIC_DAY	3	7	2012-07-24	40199	59201	\N	\N
71904	SPECIFIC_DAY	3	0	2012-06-02	40199	59201	\N	\N
71905	SPECIFIC_DAY	3	0	2012-01-14	40199	59201	\N	\N
71906	SPECIFIC_DAY	3	7	2012-08-17	40199	59201	\N	\N
71907	SPECIFIC_DAY	3	7	2011-09-08	40199	59201	\N	\N
71908	SPECIFIC_DAY	3	0	2012-02-04	40199	59201	\N	\N
71909	SPECIFIC_DAY	3	7	2012-07-10	40199	59201	\N	\N
71910	SPECIFIC_DAY	3	0	2012-02-12	40199	59201	\N	\N
71911	SPECIFIC_DAY	3	7	2011-10-14	40199	59201	\N	\N
71912	SPECIFIC_DAY	3	7	2011-06-23	40199	59201	\N	\N
71913	SPECIFIC_DAY	3	7	2012-06-11	40199	59201	\N	\N
71914	SPECIFIC_DAY	3	0	2011-07-16	40199	59201	\N	\N
71915	SPECIFIC_DAY	3	0	2012-01-15	40199	59201	\N	\N
71916	SPECIFIC_DAY	3	7	2011-12-07	40199	59201	\N	\N
71917	SPECIFIC_DAY	3	7	2012-08-06	40199	59201	\N	\N
71918	SPECIFIC_DAY	3	0	2012-11-03	40199	59201	\N	\N
71919	SPECIFIC_DAY	3	7	2012-08-24	40199	59201	\N	\N
71920	SPECIFIC_DAY	3	7	2012-10-24	40199	59201	\N	\N
71921	SPECIFIC_DAY	3	7	2012-02-20	40199	59201	\N	\N
71922	SPECIFIC_DAY	3	7	2012-03-08	40199	59201	\N	\N
71923	SPECIFIC_DAY	3	7	2011-08-17	40199	59201	\N	\N
71924	SPECIFIC_DAY	3	0	2012-09-08	40199	59201	\N	\N
71925	SPECIFIC_DAY	3	0	2012-11-04	40199	59201	\N	\N
71926	SPECIFIC_DAY	3	7	2011-09-02	40199	59201	\N	\N
71927	SPECIFIC_DAY	3	7	2011-10-17	40199	59201	\N	\N
71928	SPECIFIC_DAY	3	7	2011-07-26	40199	59201	\N	\N
71929	SPECIFIC_DAY	3	7	2012-06-04	40199	59201	\N	\N
71930	SPECIFIC_DAY	3	7	2012-12-27	40199	59201	\N	\N
71931	SPECIFIC_DAY	3	7	2011-07-14	40199	59201	\N	\N
71932	SPECIFIC_DAY	3	7	2012-06-19	40199	59201	\N	\N
71933	SPECIFIC_DAY	3	7	2012-01-18	40199	59201	\N	\N
71934	SPECIFIC_DAY	3	0	2012-10-20	40199	59201	\N	\N
71935	SPECIFIC_DAY	3	7	2012-10-31	40199	59201	\N	\N
71936	SPECIFIC_DAY	3	7	2012-09-24	40199	59201	\N	\N
71937	SPECIFIC_DAY	3	0	2012-05-06	40199	59201	\N	\N
71938	SPECIFIC_DAY	3	7	2011-07-01	40199	59201	\N	\N
71939	SPECIFIC_DAY	3	0	2011-07-10	40199	59201	\N	\N
71940	SPECIFIC_DAY	3	7	2011-06-24	40199	59201	\N	\N
71941	SPECIFIC_DAY	3	0	2012-08-26	40199	59201	\N	\N
71942	SPECIFIC_DAY	3	7	2011-12-13	40199	59201	\N	\N
71943	SPECIFIC_DAY	3	7	2011-10-18	40199	59201	\N	\N
71944	SPECIFIC_DAY	3	0	2012-09-23	40199	59201	\N	\N
71945	SPECIFIC_DAY	3	0	2011-12-17	40199	59201	\N	\N
71946	SPECIFIC_DAY	3	7	2011-08-02	40199	59201	\N	\N
71947	SPECIFIC_DAY	3	7	2011-09-20	40199	59201	\N	\N
71948	SPECIFIC_DAY	3	7	2011-10-03	40199	59201	\N	\N
71949	SPECIFIC_DAY	3	7	2011-06-28	40199	59201	\N	\N
71950	SPECIFIC_DAY	3	0	2012-01-29	40199	59201	\N	\N
71951	SPECIFIC_DAY	3	0	2012-05-20	40199	59201	\N	\N
71952	SPECIFIC_DAY	3	7	2012-06-20	40199	59201	\N	\N
71953	SPECIFIC_DAY	3	7	2012-12-10	40199	59201	\N	\N
71954	SPECIFIC_DAY	3	7	2012-01-12	40199	59201	\N	\N
71955	SPECIFIC_DAY	3	7	2011-08-22	40199	59201	\N	\N
71956	SPECIFIC_DAY	3	7	2012-02-08	40199	59201	\N	\N
71957	SPECIFIC_DAY	3	7	2012-01-26	40199	59201	\N	\N
71958	SPECIFIC_DAY	3	7	2011-11-30	40199	59201	\N	\N
71959	SPECIFIC_DAY	3	0	2012-09-22	40199	59201	\N	\N
71960	SPECIFIC_DAY	3	7	2012-12-17	40199	59201	\N	\N
71961	SPECIFIC_DAY	3	7	2011-07-13	40199	59201	\N	\N
71962	SPECIFIC_DAY	3	7	2012-08-27	40199	59201	\N	\N
71963	SPECIFIC_DAY	3	7	2012-07-17	40199	59201	\N	\N
71964	SPECIFIC_DAY	3	7	2012-07-30	40199	59201	\N	\N
71965	SPECIFIC_DAY	3	7	2012-08-13	40199	59201	\N	\N
71966	SPECIFIC_DAY	3	0	2012-09-02	40199	59201	\N	\N
71967	SPECIFIC_DAY	3	0	2012-12-22	40199	59201	\N	\N
71968	SPECIFIC_DAY	3	7	2012-08-09	40199	59201	\N	\N
71969	SPECIFIC_DAY	3	7	2012-01-09	40199	59201	\N	\N
71970	SPECIFIC_DAY	3	0	2012-11-18	40199	59201	\N	\N
71971	SPECIFIC_DAY	3	7	2012-12-07	40199	59201	\N	\N
71972	SPECIFIC_DAY	3	7	2011-12-23	40199	59201	\N	\N
71973	SPECIFIC_DAY	3	7	2012-11-20	40199	59201	\N	\N
71974	SPECIFIC_DAY	3	7	2012-05-11	40199	59201	\N	\N
71975	SPECIFIC_DAY	3	7	2013-01-22	40199	59201	\N	\N
71976	SPECIFIC_DAY	3	0	2012-03-25	40199	59201	\N	\N
71977	SPECIFIC_DAY	3	7	2012-10-23	40199	59201	\N	\N
71978	SPECIFIC_DAY	3	7	2012-09-28	40199	59201	\N	\N
71979	SPECIFIC_DAY	3	7	2011-11-23	40199	59201	\N	\N
71980	SPECIFIC_DAY	3	7	2011-09-22	40199	59201	\N	\N
71981	SPECIFIC_DAY	3	7	2011-09-27	40199	59201	\N	\N
71982	SPECIFIC_DAY	3	0	2012-08-18	40199	59201	\N	\N
71983	SPECIFIC_DAY	3	7	2011-06-09	40199	59201	\N	\N
71984	SPECIFIC_DAY	3	0	2012-04-07	40199	59201	\N	\N
71985	SPECIFIC_DAY	3	0	2012-04-15	40199	59201	\N	\N
71986	SPECIFIC_DAY	3	7	2012-08-29	40199	59201	\N	\N
71987	SPECIFIC_DAY	3	7	2012-04-04	40199	59201	\N	\N
71988	SPECIFIC_DAY	3	7	2012-04-24	40199	59201	\N	\N
71989	SPECIFIC_DAY	3	7	2012-10-02	40199	59201	\N	\N
71990	SPECIFIC_DAY	3	0	2011-05-28	40199	59201	\N	\N
71991	SPECIFIC_DAY	3	7	2011-10-21	40199	59201	\N	\N
71992	SPECIFIC_DAY	3	7	2011-07-11	40199	59201	\N	\N
71993	SPECIFIC_DAY	3	7	2011-11-15	40199	59201	\N	\N
71994	SPECIFIC_DAY	3	0	2011-06-26	40199	59201	\N	\N
71995	SPECIFIC_DAY	3	0	2012-12-09	40199	59201	\N	\N
71996	SPECIFIC_DAY	3	7	2011-10-25	40199	59201	\N	\N
71997	SPECIFIC_DAY	3	0	2012-09-29	40199	59201	\N	\N
71998	SPECIFIC_DAY	3	7	2011-12-29	40199	59201	\N	\N
71999	SPECIFIC_DAY	3	7	2012-04-11	40199	59201	\N	\N
72000	SPECIFIC_DAY	3	0	2012-08-04	40199	59201	\N	\N
72001	SPECIFIC_DAY	3	0	2011-10-15	40199	59201	\N	\N
72002	SPECIFIC_DAY	3	7	2011-08-12	40199	59201	\N	\N
72003	SPECIFIC_DAY	3	7	2012-10-04	40199	59201	\N	\N
72004	SPECIFIC_DAY	3	7	2011-06-14	40199	59201	\N	\N
72005	SPECIFIC_DAY	3	7	2012-07-11	40199	59201	\N	\N
72006	SPECIFIC_DAY	3	7	2011-10-20	40199	59201	\N	\N
72007	SPECIFIC_DAY	3	7	2011-10-11	40199	59201	\N	\N
72008	SPECIFIC_DAY	3	7	2012-09-10	40199	59201	\N	\N
72009	SPECIFIC_DAY	3	7	2012-04-02	40199	59201	\N	\N
72010	SPECIFIC_DAY	3	0	2011-12-04	40199	59201	\N	\N
72011	SPECIFIC_DAY	3	0	2011-11-12	40199	59201	\N	\N
72012	SPECIFIC_DAY	3	0	2012-11-25	40199	59201	\N	\N
72013	SPECIFIC_DAY	3	7	2012-09-20	40199	59201	\N	\N
72014	SPECIFIC_DAY	3	7	2012-05-17	40199	59201	\N	\N
72015	SPECIFIC_DAY	3	7	2013-01-08	40199	59201	\N	\N
72016	SPECIFIC_DAY	3	7	2012-10-03	40199	59201	\N	\N
72017	SPECIFIC_DAY	3	7	2012-03-30	40199	59201	\N	\N
72018	SPECIFIC_DAY	3	0	2012-10-14	40199	59201	\N	\N
72019	SPECIFIC_DAY	3	7	2011-12-08	40199	59201	\N	\N
72020	SPECIFIC_DAY	3	7	2013-01-24	40199	59201	\N	\N
72021	SPECIFIC_DAY	3	7	2012-10-30	40199	59201	\N	\N
72022	SPECIFIC_DAY	3	7	2012-11-27	40199	59201	\N	\N
72023	SPECIFIC_DAY	3	7	2011-08-24	40199	59201	\N	\N
72024	SPECIFIC_DAY	3	7	2011-09-19	40199	59201	\N	\N
72025	SPECIFIC_DAY	3	0	2011-11-20	40199	59201	\N	\N
72026	SPECIFIC_DAY	3	0	2012-03-24	40199	59201	\N	\N
72027	SPECIFIC_DAY	3	7	2011-10-27	40199	59201	\N	\N
72028	SPECIFIC_DAY	3	0	2011-10-02	40199	59201	\N	\N
72029	SPECIFIC_DAY	3	0	2011-07-17	40199	59201	\N	\N
72030	SPECIFIC_DAY	3	0	2011-07-09	40199	59201	\N	\N
72031	SPECIFIC_DAY	3	7	2013-01-07	40199	59201	\N	\N
72032	SPECIFIC_DAY	3	0	2011-11-05	40199	59201	\N	\N
72033	SPECIFIC_DAY	3	7	2012-05-24	40199	59201	\N	\N
72034	SPECIFIC_DAY	3	7	2012-10-29	40199	59201	\N	\N
72035	SPECIFIC_DAY	3	7	2012-09-27	40199	59201	\N	\N
72036	SPECIFIC_DAY	3	7	2012-06-22	40199	59201	\N	\N
72037	SPECIFIC_DAY	3	7	2012-03-19	40199	59201	\N	\N
72038	SPECIFIC_DAY	3	7	2012-02-10	40199	59201	\N	\N
72039	SPECIFIC_DAY	3	7	2012-11-08	40199	59201	\N	\N
72040	SPECIFIC_DAY	3	7	2012-07-31	40199	59201	\N	\N
72041	SPECIFIC_DAY	3	0	2013-01-19	40199	59201	\N	\N
72042	SPECIFIC_DAY	3	0	2012-04-22	40199	59201	\N	\N
72043	SPECIFIC_DAY	3	7	2013-01-31	40199	59201	\N	\N
72044	SPECIFIC_DAY	3	7	2011-08-19	40199	59201	\N	\N
72045	SPECIFIC_DAY	3	0	2012-02-05	40199	59201	\N	\N
72046	SPECIFIC_DAY	3	0	2012-01-22	40199	59201	\N	\N
72047	SPECIFIC_DAY	3	0	2011-06-05	40199	59201	\N	\N
72048	SPECIFIC_DAY	3	0	2012-08-12	40199	59201	\N	\N
72049	SPECIFIC_DAY	3	0	2012-10-28	40199	59201	\N	\N
72050	SPECIFIC_DAY	3	0	2012-11-10	40199	59201	\N	\N
72051	SPECIFIC_DAY	3	7	2012-03-23	40199	59201	\N	\N
72052	SPECIFIC_DAY	3	7	2011-06-10	40199	59201	\N	\N
72053	SPECIFIC_DAY	3	7	2012-04-09	40199	59201	\N	\N
72054	SPECIFIC_DAY	3	7	2012-11-23	40199	59201	\N	\N
72055	SPECIFIC_DAY	3	7	2012-01-19	40199	59201	\N	\N
72056	SPECIFIC_DAY	3	7	2013-01-15	40199	59201	\N	\N
72057	SPECIFIC_DAY	3	7	2011-09-05	40199	59201	\N	\N
72058	SPECIFIC_DAY	3	0	2011-08-14	40199	59201	\N	\N
72059	SPECIFIC_DAY	3	0	2011-07-02	40199	59201	\N	\N
72060	SPECIFIC_DAY	3	7	2011-07-19	40199	59201	\N	\N
72061	SPECIFIC_DAY	3	7	2012-05-15	40199	59201	\N	\N
72062	SPECIFIC_DAY	3	7	2011-07-05	40199	59201	\N	\N
72063	SPECIFIC_DAY	3	0	2012-03-18	40199	59201	\N	\N
72064	SPECIFIC_DAY	3	7	2012-06-01	40199	59201	\N	\N
72065	SPECIFIC_DAY	3	7	2013-01-18	40199	59201	\N	\N
72066	SPECIFIC_DAY	3	7	2012-03-13	40199	59201	\N	\N
72067	SPECIFIC_DAY	3	7	2012-11-21	40199	59201	\N	\N
72068	SPECIFIC_DAY	3	7	2011-06-29	40199	59201	\N	\N
72069	SPECIFIC_DAY	3	7	2012-03-15	40199	59201	\N	\N
72070	SPECIFIC_DAY	3	0	2011-10-23	40199	59201	\N	\N
72071	SPECIFIC_DAY	3	0	2012-01-08	40199	59201	\N	\N
72072	SPECIFIC_DAY	3	7	2012-03-07	40199	59201	\N	\N
72073	SPECIFIC_DAY	3	0	2011-10-01	40199	59201	\N	\N
72074	SPECIFIC_DAY	3	7	2012-06-18	40199	59201	\N	\N
72075	SPECIFIC_DAY	3	7	2011-11-24	40199	59201	\N	\N
72076	SPECIFIC_DAY	3	0	2012-03-17	40199	59201	\N	\N
72077	SPECIFIC_DAY	3	7	2011-09-16	40199	59201	\N	\N
72078	SPECIFIC_DAY	3	7	2012-06-15	40199	59201	\N	\N
72079	SPECIFIC_DAY	3	0	2011-08-13	40199	59201	\N	\N
72080	SPECIFIC_DAY	3	0	2011-06-19	40199	59201	\N	\N
72081	SPECIFIC_DAY	3	0	2012-07-08	40199	59201	\N	\N
72082	SPECIFIC_DAY	3	7	2011-06-21	40199	59201	\N	\N
72083	SPECIFIC_DAY	3	7	2012-11-13	40199	59201	\N	\N
72084	SPECIFIC_DAY	3	7	2012-12-03	40199	59201	\N	\N
72085	SPECIFIC_DAY	3	7	2013-01-30	40199	59201	\N	\N
72086	SPECIFIC_DAY	3	7	2011-11-03	40199	59201	\N	\N
72087	SPECIFIC_DAY	3	7	2011-12-15	40199	59201	\N	\N
72088	SPECIFIC_DAY	3	7	2013-01-02	40199	59201	\N	\N
72089	SPECIFIC_DAY	3	7	2012-07-16	40199	59201	\N	\N
72090	SPECIFIC_DAY	3	7	2011-12-21	40199	59201	\N	\N
72091	SPECIFIC_DAY	3	7	2011-06-17	40199	59201	\N	\N
72092	SPECIFIC_DAY	3	7	2012-01-30	40199	59201	\N	\N
72093	SPECIFIC_DAY	3	0	2012-04-08	40199	59201	\N	\N
72094	SPECIFIC_DAY	3	7	2012-09-03	40199	59201	\N	\N
72095	SPECIFIC_DAY	3	0	2012-06-30	40199	59201	\N	\N
72096	SPECIFIC_DAY	3	7	2011-08-23	40199	59201	\N	\N
72097	SPECIFIC_DAY	3	7	2012-03-27	40199	59201	\N	\N
72098	SPECIFIC_DAY	3	7	2012-04-27	40199	59201	\N	\N
72099	SPECIFIC_DAY	3	7	2012-06-06	40199	59201	\N	\N
72100	SPECIFIC_DAY	3	7	2012-10-11	40199	59201	\N	\N
72101	SPECIFIC_DAY	3	0	2011-08-27	40199	59201	\N	\N
72102	SPECIFIC_DAY	3	7	2012-04-05	40199	59201	\N	\N
72103	SPECIFIC_DAY	3	7	2012-05-18	40199	59201	\N	\N
72104	SPECIFIC_DAY	3	0	2011-06-12	40199	59201	\N	\N
72105	SPECIFIC_DAY	3	7	2013-01-09	40199	59201	\N	\N
72106	SPECIFIC_DAY	3	7	2012-02-24	40199	59201	\N	\N
72107	SPECIFIC_DAY	3	7	2012-01-10	40199	59201	\N	\N
72108	SPECIFIC_DAY	3	7	2011-09-23	40199	59201	\N	\N
72109	SPECIFIC_DAY	3	0	2011-09-18	40199	59201	\N	\N
72110	SPECIFIC_DAY	3	7	2012-03-06	40199	59201	\N	\N
72111	SPECIFIC_DAY	3	7	2011-09-12	40199	59201	\N	\N
72112	SPECIFIC_DAY	3	0	2012-10-06	40199	59201	\N	\N
72113	SPECIFIC_DAY	3	0	2012-11-11	40199	59201	\N	\N
72114	SPECIFIC_DAY	3	0	2012-04-21	40199	59201	\N	\N
72115	SPECIFIC_DAY	3	0	2012-06-03	40199	59201	\N	\N
72116	SPECIFIC_DAY	3	0	2012-09-01	40199	59201	\N	\N
72117	SPECIFIC_DAY	3	7	2012-07-23	40199	59201	\N	\N
72118	SPECIFIC_DAY	3	7	2013-02-04	40199	59201	\N	\N
72119	SPECIFIC_DAY	3	7	2012-05-09	40199	59201	\N	\N
72120	SPECIFIC_DAY	3	7	2012-11-29	40199	59201	\N	\N
72121	SPECIFIC_DAY	3	7	2011-12-09	40199	59201	\N	\N
72122	SPECIFIC_DAY	3	7	2012-08-31	40199	59201	\N	\N
72123	SPECIFIC_DAY	3	0	2012-10-13	40199	59201	\N	\N
72124	SPECIFIC_DAY	3	7	2012-06-29	40199	59201	\N	\N
72125	SPECIFIC_DAY	3	7	2012-04-06	40199	59201	\N	\N
72126	SPECIFIC_DAY	3	0	2013-01-20	40199	59201	\N	\N
72127	SPECIFIC_DAY	3	7	2012-11-26	40199	59201	\N	\N
72128	SPECIFIC_DAY	3	7	2013-02-13	40199	59201	\N	\N
72129	SPECIFIC_DAY	3	0	2011-09-25	40199	59201	\N	\N
72130	SPECIFIC_DAY	3	0	2012-06-10	40199	59201	\N	\N
72131	SPECIFIC_DAY	3	7	2012-07-05	40199	59201	\N	\N
72132	SPECIFIC_DAY	3	0	2012-08-05	40199	59201	\N	\N
72133	SPECIFIC_DAY	3	0	2012-02-11	40199	59201	\N	\N
72134	SPECIFIC_DAY	3	0	2012-01-01	40199	59201	\N	\N
72135	SPECIFIC_DAY	3	7	2012-06-13	40199	59201	\N	\N
72136	SPECIFIC_DAY	3	7	2012-02-22	40199	59201	\N	\N
72137	SPECIFIC_DAY	3	7	2011-12-22	40199	59201	\N	\N
72138	SPECIFIC_DAY	3	0	2012-12-30	40199	59201	\N	\N
72139	SPECIFIC_DAY	3	7	2012-09-18	40199	59201	\N	\N
72140	SPECIFIC_DAY	3	0	2011-06-25	40199	59201	\N	\N
72141	SPECIFIC_DAY	3	7	2012-04-13	40199	59201	\N	\N
72142	SPECIFIC_DAY	3	0	2012-06-09	40199	59201	\N	\N
72143	SPECIFIC_DAY	3	0	2012-07-01	40199	59201	\N	\N
72144	SPECIFIC_DAY	3	7	2012-12-19	40199	59201	\N	\N
72145	SPECIFIC_DAY	3	7	2012-05-28	40199	59201	\N	\N
72146	SPECIFIC_DAY	3	0	2013-02-03	40199	59201	\N	\N
72147	SPECIFIC_DAY	3	0	2012-01-07	40199	59201	\N	\N
72148	SPECIFIC_DAY	3	7	2012-02-16	40199	59201	\N	\N
72149	SPECIFIC_DAY	3	0	2011-11-06	40199	59201	\N	\N
72150	SPECIFIC_DAY	3	7	2012-09-25	40199	59201	\N	\N
72151	SPECIFIC_DAY	3	0	2011-12-11	40199	59201	\N	\N
72152	SPECIFIC_DAY	3	7	2012-07-02	40199	59201	\N	\N
72153	SPECIFIC_DAY	3	7	2011-06-15	40199	59201	\N	\N
72154	SPECIFIC_DAY	3	7	2011-11-16	40199	59201	\N	\N
72155	SPECIFIC_DAY	3	0	2012-07-15	40199	59201	\N	\N
72156	SPECIFIC_DAY	3	0	2012-03-10	40199	59201	\N	\N
72157	SPECIFIC_DAY	3	7	2012-07-04	40199	59201	\N	\N
72158	SPECIFIC_DAY	3	7	2012-09-17	40199	59201	\N	\N
72159	SPECIFIC_DAY	3	7	2012-04-26	40199	59201	\N	\N
72160	SPECIFIC_DAY	3	7	2012-02-06	40199	59201	\N	\N
72161	SPECIFIC_DAY	3	0	2012-12-15	40199	59201	\N	\N
72162	SPECIFIC_DAY	3	7	2011-08-25	40199	59201	\N	\N
72163	SPECIFIC_DAY	3	7	2011-07-22	40199	59201	\N	\N
72164	SPECIFIC_DAY	3	7	2012-01-04	40199	59201	\N	\N
72165	SPECIFIC_DAY	3	7	2012-01-24	40199	59201	\N	\N
72166	SPECIFIC_DAY	3	0	2012-05-26	40199	59201	\N	\N
72167	SPECIFIC_DAY	3	7	2011-07-06	40199	59201	\N	\N
72168	SPECIFIC_DAY	3	7	2012-08-28	40199	59201	\N	\N
72169	SPECIFIC_DAY	3	7	2011-06-22	40199	59201	\N	\N
72170	SPECIFIC_DAY	3	7	2013-02-01	40199	59201	\N	\N
72171	SPECIFIC_DAY	3	7	2011-07-25	40199	59201	\N	\N
72172	SPECIFIC_DAY	3	7	2012-01-13	40199	59201	\N	\N
72173	SPECIFIC_DAY	3	7	2011-12-06	40199	59201	\N	\N
72174	SPECIFIC_DAY	3	7	2012-08-07	40199	59201	\N	\N
72175	SPECIFIC_DAY	3	7	2013-01-03	40199	59201	\N	\N
72176	SPECIFIC_DAY	3	0	2010-01-10	49302	68693	\N	\N
72177	SPECIFIC_DAY	3	0	2010-01-09	49302	68693	\N	\N
72178	SPECIFIC_DAY	3	7	2010-01-05	49302	68693	\N	\N
72179	SPECIFIC_DAY	3	7	2010-01-08	49302	68693	\N	\N
72180	SPECIFIC_DAY	3	7	2010-01-11	49302	68693	\N	\N
72181	SPECIFIC_DAY	3	0	2010-01-06	49302	68693	\N	\N
72182	SPECIFIC_DAY	3	7	2010-01-12	49302	68693	\N	\N
72183	SPECIFIC_DAY	3	7	2010-01-07	49302	68693	\N	\N
72184	SPECIFIC_DAY	3	7	2010-01-18	49302	68694	\N	\N
72185	SPECIFIC_DAY	3	7	2010-01-14	49302	68694	\N	\N
72186	SPECIFIC_DAY	3	0	2010-01-16	49302	68694	\N	\N
72187	SPECIFIC_DAY	3	0	2010-01-17	49302	68694	\N	\N
72188	SPECIFIC_DAY	3	7	2010-01-13	49302	68694	\N	\N
72189	SPECIFIC_DAY	3	7	2010-01-15	49302	68694	\N	\N
72190	SPECIFIC_DAY	3	26	2011-03-08	37573	60439	\N	\N
72191	SPECIFIC_DAY	3	26	2011-03-09	37573	60439	\N	\N
72192	SPECIFIC_DAY	3	19	2011-03-13	37573	60439	\N	\N
72193	SPECIFIC_DAY	3	26	2011-03-11	37573	60439	\N	\N
72194	SPECIFIC_DAY	3	25	2011-03-17	37573	60439	\N	\N
72195	SPECIFIC_DAY	3	19	2011-03-12	37573	60439	\N	\N
72196	SPECIFIC_DAY	3	26	2011-03-10	37573	60439	\N	\N
72197	SPECIFIC_DAY	3	26	2011-03-15	37573	60439	\N	\N
72198	SPECIFIC_DAY	3	26	2011-03-14	37573	60439	\N	\N
72199	SPECIFIC_DAY	3	26	2011-03-16	37573	60439	\N	\N
72238	SPECIFIC_DAY	3	0	2010-01-16	49309	60449	\N	\N
72239	SPECIFIC_DAY	3	0	2010-01-10	49309	60449	\N	\N
72240	SPECIFIC_DAY	3	7	2010-01-22	49309	60449	\N	\N
72241	SPECIFIC_DAY	3	0	2009-12-27	49309	60449	\N	\N
72242	SPECIFIC_DAY	3	7	2010-01-26	49309	60449	\N	\N
72243	SPECIFIC_DAY	3	0	2010-01-31	49309	60449	\N	\N
72244	SPECIFIC_DAY	3	7	2010-01-04	49309	60449	\N	\N
72245	SPECIFIC_DAY	3	0	2010-01-02	49309	60449	\N	\N
72246	SPECIFIC_DAY	3	7	2010-01-28	49309	60449	\N	\N
72247	SPECIFIC_DAY	3	7	2010-01-20	49309	60449	\N	\N
72248	SPECIFIC_DAY	3	0	2010-01-06	49309	60449	\N	\N
72249	SPECIFIC_DAY	3	7	2010-02-10	49309	60449	\N	\N
72250	SPECIFIC_DAY	3	7	2010-02-11	49309	60449	\N	\N
72251	SPECIFIC_DAY	3	7	2010-01-07	49309	60449	\N	\N
72252	SPECIFIC_DAY	3	0	2010-01-17	49309	60449	\N	\N
72253	SPECIFIC_DAY	3	0	2010-01-03	49309	60449	\N	\N
72254	SPECIFIC_DAY	3	7	2010-01-18	49309	60449	\N	\N
72255	SPECIFIC_DAY	3	7	2009-12-22	49309	60449	\N	\N
72256	SPECIFIC_DAY	3	0	2009-12-26	49309	60449	\N	\N
72257	SPECIFIC_DAY	3	0	2010-02-14	49309	60449	\N	\N
72258	SPECIFIC_DAY	3	7	2010-02-18	49309	60449	\N	\N
72259	SPECIFIC_DAY	3	7	2010-02-02	49309	60449	\N	\N
72260	SPECIFIC_DAY	3	7	2010-02-05	49309	60449	\N	\N
72261	SPECIFIC_DAY	3	7	2009-12-28	49309	60449	\N	\N
72262	SPECIFIC_DAY	3	7	2010-01-11	49309	60449	\N	\N
72263	SPECIFIC_DAY	3	7	2010-02-12	49309	60449	\N	\N
72264	SPECIFIC_DAY	3	7	2010-01-14	49309	60449	\N	\N
72265	SPECIFIC_DAY	3	7	2010-02-04	49309	60449	\N	\N
72266	SPECIFIC_DAY	3	7	2010-01-08	49309	60449	\N	\N
72267	SPECIFIC_DAY	3	0	2010-01-30	49309	60449	\N	\N
72268	SPECIFIC_DAY	3	7	2010-01-12	49309	60449	\N	\N
72269	SPECIFIC_DAY	3	7	2010-02-01	49309	60449	\N	\N
72270	SPECIFIC_DAY	3	7	2010-01-29	49309	60449	\N	\N
72271	SPECIFIC_DAY	3	7	2010-02-08	49309	60449	\N	\N
72272	SPECIFIC_DAY	3	0	2010-01-24	49309	60449	\N	\N
72273	SPECIFIC_DAY	3	0	2010-01-09	49309	60449	\N	\N
72274	SPECIFIC_DAY	3	0	2010-02-17	49309	60449	\N	\N
72275	SPECIFIC_DAY	3	7	2009-12-30	49309	60449	\N	\N
72276	SPECIFIC_DAY	3	0	2010-02-13	49309	60449	\N	\N
72277	SPECIFIC_DAY	3	7	2010-01-25	49309	60449	\N	\N
72278	SPECIFIC_DAY	3	0	2009-12-25	49309	60449	\N	\N
72279	SPECIFIC_DAY	3	0	2010-02-07	49309	60449	\N	\N
72280	SPECIFIC_DAY	3	7	2009-12-23	49309	60449	\N	\N
72281	SPECIFIC_DAY	3	0	2010-01-23	49309	60449	\N	\N
72282	SPECIFIC_DAY	3	7	2010-02-15	49309	60449	\N	\N
72283	SPECIFIC_DAY	3	7	2010-01-19	49309	60449	\N	\N
72284	SPECIFIC_DAY	3	7	2009-12-29	49309	60449	\N	\N
72285	SPECIFIC_DAY	3	7	2009-12-24	49309	60449	\N	\N
72286	SPECIFIC_DAY	3	7	2010-01-05	49309	60449	\N	\N
72287	SPECIFIC_DAY	3	7	2010-02-19	49309	60449	\N	\N
72288	SPECIFIC_DAY	3	7	2010-02-16	49309	60449	\N	\N
72289	SPECIFIC_DAY	3	7	2010-02-03	49309	60449	\N	\N
72290	SPECIFIC_DAY	3	7	2010-01-13	49309	60449	\N	\N
72291	SPECIFIC_DAY	3	7	2010-01-15	49309	60449	\N	\N
72292	SPECIFIC_DAY	3	7	2010-01-21	49309	60449	\N	\N
72293	SPECIFIC_DAY	3	7	2010-02-09	49309	60449	\N	\N
72294	SPECIFIC_DAY	3	7	2009-12-31	49309	60449	\N	\N
72295	SPECIFIC_DAY	3	0	2010-02-06	49309	60449	\N	\N
72296	SPECIFIC_DAY	3	7	2010-01-27	49309	60449	\N	\N
72297	SPECIFIC_DAY	3	0	2010-01-01	49309	60449	\N	\N
72298	SPECIFIC_DAY	3	7	2010-06-25	49309	60450	\N	\N
72299	SPECIFIC_DAY	3	0	2010-05-29	49309	60450	\N	\N
72300	SPECIFIC_DAY	3	7	2010-06-07	49309	60450	\N	\N
72301	SPECIFIC_DAY	3	7	2010-05-24	49309	60450	\N	\N
72302	SPECIFIC_DAY	3	7	2010-06-08	49309	60450	\N	\N
72303	SPECIFIC_DAY	3	7	2010-05-27	49309	60450	\N	\N
72304	SPECIFIC_DAY	3	7	2010-07-02	49309	60450	\N	\N
72305	SPECIFIC_DAY	3	7	2010-05-28	49309	60450	\N	\N
72306	SPECIFIC_DAY	3	0	2010-05-09	49309	60450	\N	\N
72307	SPECIFIC_DAY	3	7	2010-05-21	49309	60450	\N	\N
72308	SPECIFIC_DAY	3	7	2010-06-29	49309	60450	\N	\N
72309	SPECIFIC_DAY	3	0	2010-06-20	49309	60450	\N	\N
72310	SPECIFIC_DAY	3	7	2010-05-18	49309	60450	\N	\N
72311	SPECIFIC_DAY	3	7	2010-05-14	49309	60450	\N	\N
72312	SPECIFIC_DAY	3	7	2010-06-16	49309	60450	\N	\N
72313	SPECIFIC_DAY	3	7	2010-05-07	49309	60450	\N	\N
72314	SPECIFIC_DAY	3	7	2010-06-03	49309	60450	\N	\N
72315	SPECIFIC_DAY	3	7	2010-06-11	49309	60450	\N	\N
72316	SPECIFIC_DAY	3	7	2010-06-18	49309	60450	\N	\N
72317	SPECIFIC_DAY	3	0	2010-05-17	49309	60450	\N	\N
72318	SPECIFIC_DAY	3	7	2010-06-28	49309	60450	\N	\N
72319	SPECIFIC_DAY	3	7	2010-07-01	49309	60450	\N	\N
72320	SPECIFIC_DAY	3	7	2010-06-30	49309	60450	\N	\N
72321	SPECIFIC_DAY	3	7	2010-05-31	49309	60450	\N	\N
72322	SPECIFIC_DAY	3	7	2010-05-20	49309	60450	\N	\N
72323	SPECIFIC_DAY	3	0	2010-05-23	49309	60450	\N	\N
72324	SPECIFIC_DAY	3	7	2010-05-26	49309	60450	\N	\N
72325	SPECIFIC_DAY	3	0	2010-05-15	49309	60450	\N	\N
72326	SPECIFIC_DAY	3	0	2010-06-19	49309	60450	\N	\N
72327	SPECIFIC_DAY	3	7	2010-05-10	49309	60450	\N	\N
72328	SPECIFIC_DAY	3	7	2010-06-10	49309	60450	\N	\N
72329	SPECIFIC_DAY	3	0	2010-06-06	49309	60450	\N	\N
72330	SPECIFIC_DAY	3	0	2010-06-12	49309	60450	\N	\N
72331	SPECIFIC_DAY	3	0	2010-05-08	49309	60450	\N	\N
72332	SPECIFIC_DAY	3	7	2010-05-11	49309	60450	\N	\N
72333	SPECIFIC_DAY	3	7	2010-06-04	49309	60450	\N	\N
72334	SPECIFIC_DAY	3	7	2010-06-24	49309	60450	\N	\N
72335	SPECIFIC_DAY	3	7	2010-06-02	49309	60450	\N	\N
72336	SPECIFIC_DAY	3	7	2010-06-15	49309	60450	\N	\N
72337	SPECIFIC_DAY	3	7	2010-06-23	49309	60450	\N	\N
72338	SPECIFIC_DAY	3	7	2010-06-14	49309	60450	\N	\N
72339	SPECIFIC_DAY	3	0	2010-05-22	49309	60450	\N	\N
72340	SPECIFIC_DAY	3	7	2010-06-09	49309	60450	\N	\N
72341	SPECIFIC_DAY	3	7	2010-06-17	49309	60450	\N	\N
72342	SPECIFIC_DAY	3	0	2010-05-30	49309	60450	\N	\N
72343	SPECIFIC_DAY	3	0	2010-06-05	49309	60450	\N	\N
72344	SPECIFIC_DAY	3	7	2010-06-01	49309	60450	\N	\N
72345	SPECIFIC_DAY	3	7	2010-05-25	49309	60450	\N	\N
72346	SPECIFIC_DAY	3	7	2010-05-19	49309	60450	\N	\N
72347	SPECIFIC_DAY	3	7	2010-05-12	49309	60450	\N	\N
72348	SPECIFIC_DAY	3	0	2010-06-13	49309	60450	\N	\N
72349	SPECIFIC_DAY	3	0	2010-06-26	49309	60450	\N	\N
72350	SPECIFIC_DAY	3	0	2010-06-27	49309	60450	\N	\N
72351	SPECIFIC_DAY	3	7	2010-06-21	49309	60450	\N	\N
72352	SPECIFIC_DAY	3	0	2010-05-16	49309	60450	\N	\N
72353	SPECIFIC_DAY	3	7	2010-05-13	49309	60450	\N	\N
72354	SPECIFIC_DAY	3	7	2010-06-22	49309	60450	\N	\N
72355	SPECIFIC_DAY	3	7	2010-01-19	49300	68691	\N	\N
72356	SPECIFIC_DAY	3	7	2010-01-18	49300	68691	\N	\N
72357	SPECIFIC_DAY	3	7	2010-01-14	49300	68691	\N	\N
72358	SPECIFIC_DAY	3	7	2010-01-15	49300	68691	\N	\N
72359	SPECIFIC_DAY	3	0	2010-01-16	49300	68691	\N	\N
72360	SPECIFIC_DAY	3	0	2010-01-17	49300	68691	\N	\N
72361	SPECIFIC_DAY	3	7	2010-04-09	49309	60438	\N	\N
72362	SPECIFIC_DAY	3	0	2010-04-10	49309	60438	\N	\N
72363	SPECIFIC_DAY	3	7	2010-03-03	49309	60438	\N	\N
72364	SPECIFIC_DAY	3	7	2010-02-23	49309	60438	\N	\N
72365	SPECIFIC_DAY	3	7	2010-03-23	49309	60438	\N	\N
72366	SPECIFIC_DAY	3	0	2010-04-24	49309	60438	\N	\N
72367	SPECIFIC_DAY	3	0	2010-03-13	49309	60438	\N	\N
72368	SPECIFIC_DAY	3	7	2010-04-06	49309	60438	\N	\N
72369	SPECIFIC_DAY	3	7	2010-05-05	49309	60438	\N	\N
72370	SPECIFIC_DAY	3	7	2010-04-29	49309	60438	\N	\N
72371	SPECIFIC_DAY	3	7	2010-03-09	49309	60438	\N	\N
72372	SPECIFIC_DAY	3	7	2010-04-21	49309	60438	\N	\N
72373	SPECIFIC_DAY	3	7	2010-03-22	49309	60438	\N	\N
72374	SPECIFIC_DAY	3	0	2010-02-20	49309	60438	\N	\N
72375	SPECIFIC_DAY	3	7	2010-02-22	49309	60438	\N	\N
72376	SPECIFIC_DAY	3	0	2010-04-03	49309	60438	\N	\N
72377	SPECIFIC_DAY	3	0	2010-04-02	49309	60438	\N	\N
72378	SPECIFIC_DAY	3	7	2010-04-13	49309	60438	\N	\N
72379	SPECIFIC_DAY	3	7	2010-03-18	49309	60438	\N	\N
72380	SPECIFIC_DAY	3	7	2010-04-16	49309	60438	\N	\N
72381	SPECIFIC_DAY	3	0	2010-04-04	49309	60438	\N	\N
72382	SPECIFIC_DAY	3	7	2010-04-30	49309	60438	\N	\N
72383	SPECIFIC_DAY	3	0	2010-04-18	49309	60438	\N	\N
72384	SPECIFIC_DAY	3	0	2010-04-05	49309	60438	\N	\N
72385	SPECIFIC_DAY	3	7	2010-04-07	49309	60438	\N	\N
72386	SPECIFIC_DAY	3	7	2010-04-23	49309	60438	\N	\N
72387	SPECIFIC_DAY	3	0	2010-03-06	49309	60438	\N	\N
72388	SPECIFIC_DAY	3	0	2010-02-28	49309	60438	\N	\N
72389	SPECIFIC_DAY	3	7	2010-03-24	49309	60438	\N	\N
72390	SPECIFIC_DAY	3	0	2010-02-21	49309	60438	\N	\N
72391	SPECIFIC_DAY	3	7	2010-03-05	49309	60438	\N	\N
72392	SPECIFIC_DAY	3	7	2010-03-08	49309	60438	\N	\N
72393	SPECIFIC_DAY	3	7	2010-04-28	49309	60438	\N	\N
72394	SPECIFIC_DAY	3	7	2010-03-10	49309	60438	\N	\N
72395	SPECIFIC_DAY	3	7	2010-05-06	49309	60438	\N	\N
72396	SPECIFIC_DAY	3	0	2010-04-01	49309	60438	\N	\N
72397	SPECIFIC_DAY	3	7	2010-03-26	49309	60438	\N	\N
72398	SPECIFIC_DAY	3	0	2010-05-02	49309	60438	\N	\N
72399	SPECIFIC_DAY	3	7	2010-03-12	49309	60438	\N	\N
72400	SPECIFIC_DAY	3	7	2010-05-03	49309	60438	\N	\N
72401	SPECIFIC_DAY	3	0	2010-04-17	49309	60438	\N	\N
72402	SPECIFIC_DAY	3	0	2010-03-14	49309	60438	\N	\N
72403	SPECIFIC_DAY	3	7	2010-03-04	49309	60438	\N	\N
72404	SPECIFIC_DAY	3	7	2010-03-31	49309	60438	\N	\N
72405	SPECIFIC_DAY	3	7	2010-04-08	49309	60438	\N	\N
72406	SPECIFIC_DAY	3	0	2010-02-27	49309	60438	\N	\N
72407	SPECIFIC_DAY	3	7	2010-03-15	49309	60438	\N	\N
72408	SPECIFIC_DAY	3	7	2010-02-26	49309	60438	\N	\N
72409	SPECIFIC_DAY	3	7	2010-03-11	49309	60438	\N	\N
72410	SPECIFIC_DAY	3	7	2010-03-29	49309	60438	\N	\N
72411	SPECIFIC_DAY	3	0	2010-03-21	49309	60438	\N	\N
72412	SPECIFIC_DAY	3	7	2010-03-30	49309	60438	\N	\N
72413	SPECIFIC_DAY	3	7	2010-04-26	49309	60438	\N	\N
72414	SPECIFIC_DAY	3	7	2010-05-04	49309	60438	\N	\N
72415	SPECIFIC_DAY	3	0	2010-03-07	49309	60438	\N	\N
72416	SPECIFIC_DAY	3	0	2010-03-28	49309	60438	\N	\N
72417	SPECIFIC_DAY	3	7	2010-04-12	49309	60438	\N	\N
72418	SPECIFIC_DAY	3	0	2010-03-20	49309	60438	\N	\N
72419	SPECIFIC_DAY	3	7	2010-04-20	49309	60438	\N	\N
72420	SPECIFIC_DAY	3	7	2010-02-25	49309	60438	\N	\N
72421	SPECIFIC_DAY	3	0	2010-03-19	49309	60438	\N	\N
72422	SPECIFIC_DAY	3	7	2010-03-25	49309	60438	\N	\N
72423	SPECIFIC_DAY	3	7	2010-03-02	49309	60438	\N	\N
72424	SPECIFIC_DAY	3	7	2010-04-15	49309	60438	\N	\N
72425	SPECIFIC_DAY	3	7	2010-04-19	49309	60438	\N	\N
72426	SPECIFIC_DAY	3	7	2010-03-17	49309	60438	\N	\N
72427	SPECIFIC_DAY	3	7	2010-04-27	49309	60438	\N	\N
72428	SPECIFIC_DAY	3	7	2010-02-24	49309	60438	\N	\N
72429	SPECIFIC_DAY	3	7	2010-03-01	49309	60438	\N	\N
72430	SPECIFIC_DAY	3	0	2010-03-27	49309	60438	\N	\N
72431	SPECIFIC_DAY	3	0	2010-04-11	49309	60438	\N	\N
72432	SPECIFIC_DAY	3	0	2010-04-25	49309	60438	\N	\N
72433	SPECIFIC_DAY	3	0	2010-05-01	49309	60438	\N	\N
72434	SPECIFIC_DAY	3	7	2010-04-22	49309	60438	\N	\N
72435	SPECIFIC_DAY	3	7	2010-04-14	49309	60438	\N	\N
72436	SPECIFIC_DAY	3	7	2010-03-16	49309	60438	\N	\N
72437	SPECIFIC_DAY	3	7	2010-01-20	49300	66154	\N	\N
72438	SPECIFIC_DAY	3	7	2010-01-21	49300	66154	\N	\N
72439	SPECIFIC_DAY	3	7	2010-01-22	49300	66154	\N	\N
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY dependency (id, version, origin, destination, type) FROM stdin;
9273344	6	27876	27878	0
13271342	18	40109	40101	0
18940370	29	58228	58229	0
18940325	29	58185	58232	0
2523137	12	1222	1223	0
2523136	12	1221	1222	0
2752524	7	3137	3150	0
2752535	7	3137	3150	0
2752514	7	3137	3150	0
2752520	7	3137	3150	0
2129932	13	1218	1219	0
2752515	7	3131	3151	0
2752525	7	3131	3151	0
2752536	7	3131	3151	0
1245231	8	3132	3131	0
1245234	8	3132	3131	0
1245229	8	3133	3137	0
1245232	8	3133	3137	0
1245230	8	3136	3133	0
1245233	8	3136	3133	0
2752521	7	3131	3151	0
2129927	5	3141	3142	0
2129929	5	3139	3140	0
2129928	5	3139	3142	0
13271320	16	40109	40101	0
13271307	18	40099	40100	0
13271083	18	40099	40100	0
18940419	29	58185	58232	0
1245205	7	1212	1214	0
1245192	7	1212	1214	0
1245206	6	1214	1216	0
1245191	7	1215	1213	0
1245204	7	1215	1213	0
13271316	18	40099	40100	0
13271300	18	40102	40099	0
18940397	29	58185	58232	0
18940437	29	58185	58232	0
12582947	2	36769	36771	0
13271076	18	40102	40099	0
18940360	29	58185	58232	0
18940422	29	58189	58183	0
12582948	2	36769	36771	0
13271309	18	40102	40099	0
13271306	18	40100	40110	0
13271315	18	40100	40110	0
13271082	18	40100	40110	0
18940326	29	58181	58209	0
13271321	16	40109	40108	0
12582924	13	36771	38389	0
12582946	5	36766	36769	0
12582932	8	36768	36766	0
12582941	8	36768	36766	0
12582934	8	38380	38388	0
12582943	8	38380	38388	0
12582925	8	38380	38388	0
12582927	8	38380	38388	0
12582929	8	38380	38388	0
12582933	8	38388	36768	0
12582942	8	38388	36768	0
12582928	8	38388	36768	0
12582926	8	38388	36768	0
12582949	2	36769	36771	0
18940363	29	58181	58209	0
13271343	18	40109	40108	0
13271319	16	40109	40107	0
13271341	18	40109	40107	0
13271313	18	40106	40110	0
13271304	18	40106	40110	0
13271080	18	40106	40110	0
13271081	18	40110	40111	0
13271314	18	40110	40111	0
13271305	18	40110	40111	0
13271308	18	40102	40103	0
13271075	18	40102	40103	0
13271299	18	40102	40103	0
18940402	29	58181	58209	0
13271301	18	40103	40104	0
13271077	18	40103	40104	0
13271310	18	40103	40104	0
13271311	18	40104	40105	0
13271302	18	40104	40105	0
13271078	18	40104	40105	0
18940403	29	58208	58181	0
13271303	18	40105	40106	0
18940364	29	58208	58181	0
13271079	18	40105	40106	0
13271312	18	40105	40106	0
18940320	29	58208	58181	0
18940327	29	58208	58181	0
18940421	29	58207	58216	0
18940399	29	58207	58216	0
18940362	29	58207	58216	0
18940404	29	58223	58226	0
18940446	29	58223	58226	0
18940428	29	58223	58226	0
18940365	29	58223	58226	0
18940405	29	58224	58225	0
18940447	29	58224	58225	0
18940066	39	58185	58232	0
18940033	39	58185	58232	0
18940018	39	58185	58232	0
18940331	29	58185	58232	0
18940034	39	58185	58214	0
18940067	39	58185	58214	0
18940019	39	58185	58214	0
18940440	29	58189	58183	0
18940423	29	58236	58189	0
18940441	29	58236	58189	0
13271358	3	40111	40110	0
18940444	29	58194	58182	0
18940053	39	58207	58181	0
13271352	5	\N	\N	0
13271354	5	\N	\N	0
13271355	5	\N	\N	0
13271353	5	\N	\N	0
18940011	39	58207	58181	0
13271362	3	40110	40115	0
13271363	3	40111	40110	0
18940059	39	58179	58200	0
18940028	39	58179	58200	0
18939926	39	58179	58200	0
18939996	39	58179	58200	0
18940013	39	58179	58200	0
18939927	39	58201	58202	0
18940029	39	58201	58202	0
18940014	39	58201	58202	0
18939997	39	58201	58202	0
18940060	39	58201	58202	0
18940061	39	58202	58203	0
18940030	39	58202	58203	0
18939928	39	58202	58203	0
18940015	39	58202	58203	0
18939998	39	58202	58203	0
18940031	39	58203	58204	0
18940016	39	58203	58204	0
18940062	39	58203	58204	0
18939929	39	58203	58204	0
18939999	39	58203	58204	0
18940032	39	58204	58205	0
18940063	39	58204	58205	0
18940017	39	58204	58205	0
18940361	29	58216	58217	0
18940332	29	58216	58217	0
18940398	29	58216	58217	0
18940049	39	58197	58192	0
18940051	39	58192	58198	0
18940384	29	58223	58226	0
18940385	29	58224	58225	0
18940429	29	58224	58225	0
18940448	29	58230	58224	0
18940386	29	58230	58224	0
18940406	29	58230	58224	0
18940430	29	58230	58224	0
18940366	29	58230	58224	0
18940367	29	58226	58228	0
18940431	29	58226	58228	0
18940449	29	58226	58228	0
18940407	29	58226	58228	0
18940387	29	58226	58228	0
18940368	29	58227	58230	0
18940388	29	58227	58230	0
18940408	29	58227	58230	0
18940450	29	58227	58230	0
18940432	29	58227	58230	0
18940369	29	58229	58227	0
18940409	29	58229	58227	0
18940433	29	58229	58227	0
18940451	29	58229	58227	0
18940389	29	58229	58227	0
18940452	29	58228	58229	0
18940434	29	58228	58229	0
18940390	29	58228	58229	0
18940410	29	58228	58229	0
18940020	39	58232	58231	0
18940035	39	58232	58231	0
18940068	39	58232	58231	0
18940338	29	58185	58232	0
18940379	29	58185	58232	0
18940064	39	58187	58188	0
18940065	39	58190	58187	0
18940056	39	58188	58221	0
18940400	29	58189	58183	0
18940401	29	\N	58189	0
18940050	39	58190	58198	0
18940058	39	58237	58190	0
18940426	29	58194	58182	0
18940324	29	58208	58181	0
18940026	39	58207	58181	0
18939994	39	58207	58181	0
18940339	29	58216	58217	0
18940420	29	58216	58217	0
18940380	29	58216	58217	0
18940438	29	58216	58217	0
18940340	29	58207	58216	0
18940381	29	58207	58216	0
18940333	29	58207	58216	0
18940439	29	58207	58216	0
18940436	29	58196	58197	0
18940055	39	58221	58236	0
18940054	29	\N	\N	0
18940069	39	58214	58213	0
18940036	39	58214	58213	0
18940021	39	58214	58213	0
18940427	29	58198	58194	0
18940445	29	58198	58194	0
18940341	29	58181	58209	0
18940424	29	58181	58209	0
18940025	39	58181	58209	0
18940442	29	58181	58209	0
18940334	29	58181	58209	0
18940052	39	58181	58209	0
18940323	29	58181	58209	0
18940382	29	58181	58209	0
18939993	39	58181	58209	0
18940010	39	58181	58209	0
18940383	29	58208	58181	0
18940443	29	58208	58181	0
18940425	29	58208	58181	0
18940335	29	58208	58181	0
18940342	29	58208	58181	0
18940012	39	58209	58201	0
18940057	39	58209	58201	0
18939995	39	58209	58201	0
18940027	39	58209	58201	0
18940000	39	58204	58205	0
18939930	39	58204	58205	0
18940022	39	58176	58177	0
18939931	39	58176	58177	0
18940070	39	58176	58177	0
18940001	39	58176	58177	0
18940037	39	58176	58177	0
18940002	39	58177	58178	0
18940071	39	58177	58178	0
18940038	39	58177	58178	0
18939932	39	58177	58178	0
18940023	39	58177	58178	0
18940003	39	58178	58179	0
18939933	39	58178	58179	0
18940024	39	58178	58179	0
18940039	39	58178	58179	0
18940072	39	58178	58179	0
18940453	29	58210	58211	0
18940343	29	58210	58211	0
18940371	29	58210	58211	0
18940391	29	58210	58211	0
18940411	29	58210	58211	0
18940435	29	58210	58211	0
18940048	39	58196	58197	0
18940392	29	58196	58197	0
18940372	29	58196	58197	0
18940454	29	58196	58197	0
18940336	29	58196	58197	0
18940344	29	58196	58197	0
18940412	29	58196	58197	0
18940328	29	58196	58197	0
\.


--
-- Data for Name: derivedallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY derivedallocation (id, version, resource_allocation_id, configurationunit) FROM stdin;
\.


--
-- Data for Name: description_values; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values (description_value_id, fieldname, value) FROM stdin;
3636	Incidencias	Incidencia 
26664	incidencias	No indidencia...
\.


--
-- Data for Name: description_values_in_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY description_values_in_line (description_value_id, fieldname, value) FROM stdin;
3738	Incidencia	Ninguna destacada
3739	Incidencia	Nada...
3740	Incidencia	Nada...
7171	Incidencia	Retraso por causa de falta de material
7172	Incidencia	Nada que destacar
7173	Incidencia	Nada que destacar
8201	Incidencia	Non houbo
8202	Incidencia	Non houbo
8203	Incidencia	Non houbo
8204	Incidencia	Non houbo
8205	Incidencia	Perdemos 4 horas por tronada...
8206	Incidencia	Non houbo
8207	Incidencia	Non houbo
8208	Incidencia	Non houbo
17473	Incidencia	.
17474	Incidencia	.
17475	Incidencia	.
17476	Incidencia	.
17477	Incidencia	.
17478	Incidencia	.
17479	Incidencia	.
18887	Incidencia	No
\.


--
-- Data for Name: directadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY directadvanceassignment (advance_assignment_id, direct_order_element_id, maxvalue) FROM stdin;
3056	1022	100.00
3099	1126	100.00
3115	1127	100.00
3130	1128	100.00
6178	1129	100.00
6179	1130	100.00
6894	1180	100.00
6895	1181	100.00
6902	1182	100.00
16659	1150	100.00
16660	1151	100.00
16662	1152	100.00
16663	1153	100.00
6186	1154	100.00
\.


--
-- Data for Name: generic_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY generic_resource_allocation (resource_allocation_id) FROM stdin;
3940
3950
3951
3952
3953
3955
3981
3982
3983
3984
3985
6367
6368
6369
8588
8589
19897
19898
19899
19901
24143
28093
29808
36966
38582
38583
38595
38596
38597
38598
38600
38601
41013
41014
41046
41047
41048
41050
41051
41052
41053
41054
41061
41065
41066
41067
41068
41069
41072
41073
41074
41075
41076
41077
\.


--
-- Data for Name: heading_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY heading_field (heading_id, fieldname, length, index, positionnumber) FROM stdin;
2526	Incidencias	200	0	\N
21109	incidencias	300	0	\N
\.


--
-- Data for Name: hibernate_unique_key; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hibernate_unique_key (next_hi) FROM stdin;
960
960
960
960
960
\.


--
-- Data for Name: hour_cost; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hour_cost (id, version, pricecost, initdate, enddate, type_of_work_hours_id, cost_category_id) FROM stdin;
1414	1	10.00	2009-12-07	2010-12-07	1217	1313
1415	1	15.00	2009-12-07	2010-12-07	1212	1313
20907	1	10.00	2010-01-02	\N	1217	1315
1419	3	15.00	2009-12-07	\N	1212	1315
1418	3	10.00	2009-12-07	2010-01-01	1217	1315
31815	2	30.00	2009-12-10	\N	31714	1314
1417	3	8.00	2009-12-07	2010-12-07	1217	1314
1416	3	15.00	2009-12-07	2010-12-07	1212	1314
\.


--
-- Data for Name: hoursgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursgroup (id, version, name, resourcetype, workinghours, percentage, fixedpercentage, parent_order_line) FROM stdin;
32933	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	32832
27790	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	27604
27791	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	430	1.00	f	27606
27792	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	27607
27793	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27608
27794	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	500	1.00	f	27609
1435	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1356
1436	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1358
35980	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	35791
2863	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	1.00	f	1150
2864	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	300	1.00	f	1151
1437	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1359
1438	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	110	1.00	f	1362
2865	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1152
2866	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	250	1.00	f	1153
2867	19	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	140	1.00	f	1154
1439	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1363
1440	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	400	1.00	f	1364
1441	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1365
1855	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
1856	9	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
35981	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	16	1.00	f	35792
32932	3	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	32831
29507	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	29321
29508	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29323
29509	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29324
29510	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	29325
29511	5	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	29326
2880	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1180
1891	5	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\007MACHINE	100	0.50	f	1180
2881	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	350	1.00	f	1181
2882	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1182
2883	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1183
2843	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	1.00	f	1126
1457	10	New hours group 2	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
2844	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1127
32983	4	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	200	1.00	f	32884
2845	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	300	1.00	f	1128
2846	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	100	0.50	f	1129
2847	21	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	50	0.50	f	1130
35982	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35793
35986	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35797
38282	6	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	70	1.00	f	38080
50511	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50387
35983	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	35794
35984	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	126	1.00	f	35795
35985	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35796
35987	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	35798
50512	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50388
50513	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50389
40045	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39885
40046	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	39886
40047	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39887
40035	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	39872
40036	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39873
40037	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39875
40038	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	39876
40039	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	39878
40040	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	11	1.00	f	39879
40041	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39880
40042	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39881
40043	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39882
40044	8	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	39884
50555	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50644
50556	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50645
50557	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50647
50558	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50649
50559	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50651
50560	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50652
50561	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50653
50562	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50654
50563	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50655
50564	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50656
50565	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50657
50566	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50658
50567	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50659
50518	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50395
50519	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50396
50521	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50601
50522	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	84	1.00	f	50602
50568	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50660
50569	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50661
50570	9	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	224	1.00	f	50662
50189	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	7	1.00	f	50361
50190	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50362
50191	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50363
50192	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50364
50575	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50670
50576	7	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50671
50193	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50366
50517	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50394
50194	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	49	1.00	f	50367
50195	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	4	1.00	f	50368
50196	10	\N	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50370
50500	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	21	1.00	f	50372
50501	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50373
50502	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	24	1.00	f	50374
50503	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50375
50504	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50377
50505	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	35	1.00	f	50379
50506	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	42	1.00	f	50381
50507	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50382
50508	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50383
50509	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50385
50510	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	14	1.00	f	50386
50514	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	28	1.00	f	50390
50515	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	105	1.00	f	50392
50516	10	New hours group 0	\\254\\355\\000\\005~r\\0009org.navalplanner.business.resources.entities.ResourceEnum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006WORKER	56	1.00	f	50393
\.


--
-- Data for Name: hoursperday; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY hoursperday (base_calendar_id, hours, day_id) FROM stdin;
303	8	0
303	8	1
303	8	2
303	8	3
303	8	4
303	0	5
303	0	6
26361	8	0
31916	24	0
31916	24	1
31916	24	2
31916	24	3
31916	24	4
31916	0	5
31916	0	6
36362	7	0
36362	7	1
36362	7	2
36362	7	3
36362	7	4
49498	7	0
49498	7	1
49498	7	2
49498	7	3
49498	7	4
49500	7	0
49500	7	1
49500	7	2
49500	7	3
49500	7	4
\.


--
-- Data for Name: indirectadvanceassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY indirectadvanceassignment (advance_assignment_id, indirect_order_element_id) FROM stdin;
16661	1149
2932	1149
6187	1035
27689	27605
27690	27603
2945	1179
6896	1179
29406	29322
29407	29320
35867	35766
3052	1357
3053	1361
3054	1360
3042	1325
2739	1022
3100	1022
49251	50360
49252	50371
49253	50376
49254	50378
49255	50380
39934	39874
39935	39877
39936	39883
39924	39823
49256	50384
49257	50391
49258	50398
49267	50643
49268	50646
49269	50648
49270	50650
49273	50669
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label (id, version, name, label_type_id) FROM stdin;
912	18	Vulcano	809
910	1	Cubierta	808
911	1	Motores	808
914	1	1 (Bajo)	810
916	1	2 (Medio)	810
913	17	Navantia	809
909	7	Bodega	808
915	9	3 (Alto)	810
\.


--
-- Data for Name: label_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY label_type (id, version, name) FROM stdin;
808	1	Zonas
809	1	Cliente
810	1	Riesgo
\.


--
-- Data for Name: line_field; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY line_field (heading_id, fieldname, length, index, positionnumber) FROM stdin;
2527	Incidencias2	201	0	\N
2525	Incidencia	200	0	\N
\.


--
-- Data for Name: machine; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine (machine_id, code, name, description) FROM stdin;
7272	pleg2	Plegadora A	Pleg. Desc.
1727	cod2	Torno A	Desc
\.


--
-- Data for Name: machine_configuration_unit_required_criterions; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machine_configuration_unit_required_criterions (id, criterion_id) FROM stdin;
1919	107
26462	107
21614	108
\.


--
-- Data for Name: machineworkerassignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkerassignment (id, version, startdate, finishdate, configuration_id, worker_id) FROM stdin;
26563	4	2009-12-09 23:57:32.242	2009-12-25 00:00:00	26462	1726
32017	1	2009-12-10 17:14:26.615	2010-12-10 00:00:00	21614	1718
21513	4	2009-12-09 10:26:10.315	\N	1919	1724
\.


--
-- Data for Name: machineworkersconfigurationunit; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY machineworkersconfigurationunit (id, version, name, alpha, machine) FROM stdin;
26462	4	New configuration unit	0.50	7272
21614	4	New configuration unit	0.25	1727
1919	6	Seleccion de criterios	1.00	1727
\.


--
-- Data for Name: material; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material (id, version, code, description, default_unit_price, unit_type, disabled, category_id) FROM stdin;
1121	6	cod1.1	tubo 3/4 pulgadas	6.00	3	f	1023
1123	7	cod2.2	Tubos 20mm	7.00	3	f	1022
1122	7	cod2.1	Tubos 12mm	6.50	3	f	1022
1124	7	cod3.1	Tornillos hexagonales	0.45	3	f	1024
25856	2	cod3.1.1	Tornillos 304	55.00	3	f	1024
1125	8	cod3	Tornillo 304	0.50	\N	f	1021
31613	1	kjgkjhg	gfdhgfd	5.00	3	f	31512
\.


--
-- Data for Name: material_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_assigment (id, version, units, unit_price, estimated_availability, status, order_element_id, material_id) FROM stdin;
20829	3	2	0.45	2009-12-07 16:23:24.094	0	1325	1124
20828	3	5	0.50	2009-12-07 16:23:24.094	1	1325	1125
20825	3	0	6.00	2009-12-07 16:23:24.094	1	1325	1121
20826	3	2	0.45	2009-12-07 16:23:24.094	1	1325	1124
20827	3	0	6.50	2009-12-07 16:23:24.094	1	1325	1122
20824	3	6	7.00	2009-12-07 16:23:24.094	1	1325	1123
20881	2	0	6.50	\N	1	1356	1122
20882	2	0	7.00	\N	1	1356	1123
20883	2	0	6.00	\N	1	1356	1121
3549	6	6	0.50	2009-12-07 13:59:19.527	1	1022	1125
3548	6	8	6.50	2009-12-07 13:59:19.527	1	1022	1122
3547	6	10	6.00	2009-12-07 13:59:19.527	1	1022	1121
25964	4	0	3.00	2009-11-02 00:00:00	0	1035	1121
25971	3	0	55.00	2009-11-02 00:00:00	1	1035	25856
25972	3	0	6.50	2009-11-02 00:00:00	1	1035	1122
25963	4	0	3.00	2009-11-02 00:00:00	2	1035	1121
25983	2	0	7.00	\N	0	1152	1123
\.


--
-- Data for Name: material_category; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY material_category (id, version, name, parent_id) FROM stdin;
1020	8	Tubos	\N
1023	7	Cemento	1020
1022	7	Acero	1020
1021	8	Tornillos	\N
1024	7	Hexagonales	1021
31512	1	exemplo	1024
58479	1	Imported materials without category	\N
\.


--
-- Data for Name: naval_profile; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_profile (id, version, profilename) FROM stdin;
\.


--
-- Data for Name: naval_user; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY naval_user (id, version, loginname, password, email, disabled) FROM stdin;
58681	4	user	c35c71570b3f45bb21a588107e7cb946b3c50bf2cd9e885d3876de669a73df1133aabe8b69d24db37837c6f26f9e7bc35dc34ee04c8f9a51d53ed7d82859f80e	\N	f
58682	3	admin	e02a1a8809e830cf7b7c875e43c16e684ed02a818c7ac25aeadd515432f908ea041447720c194d6b0ec19a1c3dd97f7b378efaab4dd8efd46de568adf3f44c9a	\N	f
58683	2	wsreader	9134100ea9446b87a04cda86febe02900e53ca5af2f5b9422c5120bc3291079a7de3ea91ec72e944167e3fbcb97d35a2a904ee66bacf3727a67f7e5bf9fdaadc	\N	f
58684	1	wswriter	a3d23705b1bb5ededfc890707b8e3331760206a6ceb213469fdf320dbe889170c2da17106005c5d057c51462621d7d77f33e005e6b9f1cddec6fa8c9b7a66eb8	\N	f
\.


--
-- Data for Name: order_element_label; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_element_label (order_element_id, label_id) FROM stdin;
1022	913
1127	909
1127	915
1128	915
1035	912
1130	915
\.


--
-- Data for Name: order_table; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY order_table (orderelementid, responsible, customer, dependenciesconstraintshavepriority, base_calendar_id) FROM stdin;
1325	Xavi	...	t	202
1022	Xavi	...	t	202
1035	Xavi	\N	t	202
27603	Xavi.	\N	t	202
29320	Responsable	Cliente	t	202
32883	asdf	\N	t	202
35766	Xavier Castaño García	\N	t	202
39823	Xavier Castaño	\N	t	36260
1179	Xavi	\N	t	202
49125	Xavi	Xunta de Galicia	t	36260
\.


--
-- Data for Name: orderelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderelement (id, version, name, initdate, deadline, mandatoryinit, mandatoryend, description, code, schedulingstatetype, parent, positionincontainer) FROM stdin;
27609	5	Exemplo6	\N	\N	f	f	\N	ped5.6	4	27603	3
1325	7	Contratación de muebles habitaciones	2009-12-07 16:23:24.094	2010-05-07 00:00:00	f	f	Desc.	ped4	4	\N	\N
1356	6	Tarefa1	\N	\N	f	f	\N	ped4.1	0	1325	0
1035	20	Contratación de pintado de casco	2009-11-02 00:00:00	2010-03-25 00:00:00	f	f	Desc.	ped2	3	\N	\N
1149	19	Coordinación	\N	\N	f	f	\N	ped2.1	3	1035	0
1150	19	Reuniones seguimiento 	\N	\N	f	f	\N	ped2.2	0	1149	0
1151	19	Seguimiento proyecto	\N	\N	f	f	\N	ped2.3	0	1149	1
1152	19	Montaje andamios	\N	\N	f	f	\N	ped2.4	0	1035	1
1153	19	Pintado cubierta	\N	\N	f	f	\N	ped2.5	0	1035	2
1154	19	Desmontaje andamios	\N	\N	f	f	\N	ped2.6	0	1035	3
1357	6	Tarefa2	\N	\N	f	f	\N	ped4.2	0	1325	1
1358	6	Subtarefa1.1	\N	\N	f	f	\N	ped4.3	1	1357	0
1359	6	Subtarefa1.2	\N	\N	f	f	\N	ped4.4	1	1357	1
1360	6	Tarefa3	\N	\N	f	f	\N	ped4.5	2	1325	2
1361	6	Subtarefa3.1	\N	\N	f	f	\N	ped4.6	2	1360	0
1362	6	Subsubtarefa3.1.1	\N	\N	f	f	\N	ped4.7	0	1361	0
1363	6	Subsubtarefa3.1.2	\N	\N	f	f	\N	ped4.8	4	1361	1
1364	6	Tarefa4	\N	\N	f	f	\N	ped4.9	0	1325	3
1365	6	Tarefa5	\N	\N	f	f	\N	ped4.10	0	1325	4
1022	22	Contratación de motores	2009-12-07 13:59:19.527	2009-12-25 00:00:00	f	f	Desc	ped1	4	\N	\N
1126	21	Adquisición de piezas	\N	\N	f	f	\N	ped1.1	0	1022	0
1179	7	Entrega de hélices	2009-12-07 16:12:52.395	2009-12-25 00:00:00	f	f	Desc.	ped3	4	\N	\N
1180	7	Tarea1	\N	\N	f	f	\N	ped3.1	0	1179	0
1127	21	Montaje piezas	\N	\N	f	f	\N	ped1.2	0	1022	1
1128	21	Prueba del motor	\N	\N	f	f	\N	ped1.3	0	1022	2
1129	21	Instalación de motor	\N	\N	f	f	\N	ped1.4	0	1022	3
1130	21	Validación funcionamiento	\N	\N	f	f	\N	ped1.5	0	1022	4
32832	3	Nuevo elemento de pedido	\N	\N	f	f	\N	hhhhh	4	29320	5
1181	7	Tarea2	\N	\N	f	f	\N	ped3.2	0	1179	1
1182	7	Tarea3	\N	\N	f	f	\N	ped3.3	0	1179	2
1183	7	Tarea4	\N	\N	f	f	\N	ped3.4	0	1179	3
35766	11	Portal web para Hospital Modelo	2010-01-22 00:00:00	2010-03-26 00:00:00	f	f	Desarrollo de un portal web para el Hospital Modelo de A Coruña	eng-typo3-17128	4	\N	\N
35797	10	Entorno	\N	\N	f	f	\N	ent	0	35766	7
38080	6	Diseño gráfico	\N	\N	f	f	\N	dis	0	35766	8
29320	5	Pedido de exemplo 2	2009-12-10 01:15:12.433	2010-04-16 00:00:00	f	f	Desc.	ped6	2	\N	\N
29321	5	Exemplo11	\N	\N	f	f	\N	ped6.1	0	29320	0
29322	5	Exemplo12	\N	\N	f	f	\N	ped6.2	3	29320	1
27603	5	Pedido de exemplo 	2009-12-10 00:10:01.713	2010-04-15 00:00:00	f	f	...	ped5	2	\N	\N
27604	5	Exemplo1	\N	\N	f	f	\N	ped5.1	4	27603	0
27605	5	Exemplo2	\N	\N	f	f	\N	ped5.2	2	27603	1
32883	4	pedido bug	2009-12-11 10:20:44.566	2010-01-01 00:00:00	f	f	asdf	codbug	3	\N	\N
32884	4	Exemplo	\N	\N	f	f	\N	codbug1	0	32883	0
27606	5	Exemplo3	\N	\N	f	f	\N	ped5.3	4	27605	0
27607	5	Exemplo4	\N	\N	f	f	\N	ped5.4	0	27605	1
27608	5	Exemplo5	\N	\N	f	f	\N	ped5.5	0	27603	2
35791	10	Coordinación	\N	\N	f	f	\N	coor	0	35766	0
35792	10	Análisis	\N	\N	f	f	\N	ana	0	35766	1
29323	5	Exemplo13	\N	\N	f	f	\N	ped6.3	0	29322	0
29324	5	Exemplo14	\N	\N	f	f	\N	ped6.4	0	29322	1
29325	5	Exemplo15	\N	\N	f	f	\N	ped6.5	0	29320	2
29326	5	Exemplo16	\N	\N	f	f	\N	ped6.6	4	29320	3
32831	3	Nuevo elemento de pedido	\N	\N	f	f	\N	jjjjj	4	29320	4
35793	10	Migración contenidos	\N	\N	f	f	\N	con	0	35766	2
35794	10	Módulo de usuarios	\N	\N	f	f	\N	usu	0	35766	3
35795	10	Plantillas y gestión de contenidos	\N	\N	f	f	\N	plant	0	35766	4
35796	10	Gestión de especialidades	\N	\N	f	f	\N	esp	0	35766	5
35798	10	Pruebas	\N	\N	f	f	\N	prue	0	35766	6
39823	9	Desenvolvemento dunha aplicación middleware para impresión de tickets	2009-12-14 00:00:00	2010-01-29 00:00:00	f	f	Desc.	eng-LAMP-17134	4	\N	\N
39872	8	Coordinación	\N	\N	f	f	\N	coor1	0	39823	0
39873	8	Análisis	\N	\N	f	f	\N	ana1	0	39823	1
39874	8	Módulo de comunicación con SEDA	\N	\N	f	f	\N	comseda1	3	39823	2
39875	8	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	\N	f	f	\N	comseda1.1	0	39874	0
39876	8	Implementación de páxina de impresión e fluxo de impresión	\N	\N	f	f	\N	comseda1.2	0	39874	1
39877	8	Módulo de comunicación con JANTO	\N	\N	f	f	\N	comjanto1	3	39823	3
39878	8	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	\N	f	f	\N	comjanto1.1	0	39877	0
39879	8	Mecanismo de sesión e xestión de estado	\N	\N	f	f	\N	comjanto1.2	0	39877	1
39880	8	Obtención de listado de entrada pendentes	\N	\N	f	f	\N	comjanto1.3	0	39877	2
39881	8	Obtención de información para impresión de cada entrada	\N	\N	f	f	\N	comjanto1.4	0	39877	3
39882	8	Notificación de resultado de impresión de entrada	\N	\N	f	f	\N	comjanto1.5	0	39877	4
39883	8	Entorno	\N	\N	f	f	\N	ent1	3	39823	4
39884	8	Gestión de respositorios – Integración	\N	\N	f	f	\N	ent1.1	0	39883	0
39885	8	Montaje entorno de trabajo	\N	\N	f	f	\N	ent1.2	0	39883	1
39886	8	Implantación en producción	\N	\N	f	f	\N	ent1.3	0	39883	2
50643	9	Módulo de arquitectura tecnolóxica	\N	\N	f	f	\N	arq42	3	49125	10
50644	9	Enlazar a axuda de usuario	\N	\N	f	f	\N	arq43	0	50643	0
50645	9	Desenvolvemento de paquetes  Ubuntu	\N	\N	f	f	\N	arq44	0	50643	1
50646	9	Módulo de documentación de API	\N	\N	f	f	\N	doc45	3	49125	11
50647	9	Documentación das API's públicas	\N	\N	f	f	\N	doc46	0	50646	0
50648	9	Módulo de arquivo histórico	\N	\N	f	f	\N	his47	3	49125	12
50649	9	Pasar pedidos a histórico	\N	\N	f	f	\N	his48	0	50648	0
50650	9	Módulo de extracción de informes	\N	\N	f	f	\N	inf49	3	49125	13
50651	9	Integración de Jasper Reports	\N	\N	f	f	\N	inf50	0	50650	0
50652	9	Informes sobre organizacións de traballo	\N	\N	f	f	\N	inf51	0	50650	1
50653	9	Informe sobre partes de traballo	\N	\N	f	f	\N	inf52	0	50650	2
39887	8	Pruebas	\N	\N	f	f	\N	ent1.4	0	39823	5
49125	12	Proxecto para o desenvolvemento dun sistema de xestión da produción para o sector do auxiliar do naval	2009-12-14 00:00:00	2010-01-30 00:00:00	f	f	\N	eng-java-16062	4	\N	\N
50654	9	Informes de horas traballadas por un traballador	\N	\N	f	f	\N	inf53	0	50650	3
50655	9	Lista de avances de planificación da empresa	\N	\N	f	f	\N	inf54	0	50650	4
50656	9	Lista de avances de traballo da empresa	\N	\N	f	f	\N	inf55	0	50650	5
50657	9	Informe de horas estimadas/horas realizadas	\N	\N	f	f	\N	inf56	0	50650	6
50658	9	Horas realizadas organizadas por tipo de traballo	\N	\N	f	f	\N	inf57	0	50650	7
50659	9	Horas estimadas/realizadas por tipo de traballo	\N	\N	f	f	\N	inf58	0	50650	8
50660	9	Informe de traballador indicando custos por hora	\N	\N	f	f	\N	inf59	0	50650	9
50661	9	Coordinación	\N	\N	f	f	\N	coor60	0	49125	14
50662	9	Análise	\N	\N	f	f	\N	ana61	0	49125	15
50360	10	Módulo de xestión de usuarios	\N	\N	f	f	\N	user1	3	49125	0
50361	10	Xestión de usuarios	\N	\N	f	f	\N	user2	0	50360	0
50362	10	Xestión de roles	\N	\N	f	f	\N	user3	0	50360	1
50363	10	Xestión de perfiles	\N	\N	f	f	\N	user4	0	50360	2
50364	10	Xestión de roles e pedidos	\N	\N	f	f	\N	user5	0	50360	3
50365	10	Módulo de organización do traballo	\N	\N	f	f	\N	org6	3	49125	1
50366	10	Xestión de código único	\N	\N	f	f	\N	org7	0	50365	0
50367	10	Revisión formulario de pedidos	\N	\N	f	f	\N	org8	0	50365	1
50368	10	Filtrado no listado de pedidos	\N	\N	f	f	\N	org9	0	50365	2
50369	10	Módulo de recursos	\N	\N	f	f	\N	rec10	3	49125	2
50370	10	Recursos Virtuais	\N	\N	f	f	\N	rec11	0	50369	0
50371	10	Módulo de planificación	\N	\N	f	f	\N	plan12	3	49125	3
50372	10	Compartir estado entre pestanas planificación	\N	\N	f	f	\N	plan13	0	50371	0
50373	10	Técnica de recálculo de planificación	\N	\N	f	f	\N	plan14	0	50371	1
50374	10	Filtrado de pedidos e tarefas de un pedido	\N	\N	f	f	\N	plan15	0	50371	2
50669	7	Módulo de asignación de recursos	\N	\N	f	f	\N	asig38	3	49125	16
50670	7	Interpolación polinómica na asignación avanzada	\N	\N	f	f	\N	asig62	0	50669	0
50671	7	Asignación automática de configuración de máquina	\N	\N	f	f	\N	asig63	0	50669	1
50384	10	Módulo de integración con subcontratas	\N	\N	f	f	\N	sub25	3	49125	7
50385	10	Administración de subcontratas	\N	\N	f	f	\N	sub26	0	50384	0
50386	10	Formato de intercambio	\N	\N	f	f	\N	sub27	0	50384	1
50387	10	Fluxo de importación/exportación	\N	\N	f	f	\N	sub28	0	50384	2
50388	10	Interfaz de xestión de subcontración nos pedidos	\N	\N	f	f	\N	sub29	0	50384	3
50389	10	Converter en fitos subcontratacións	\N	\N	f	f	\N	sub30	0	50384	4
50390	10	Avance e custo de subcontratas en Técnica de Valor Gañado	\N	\N	f	f	\N	sub31	0	50384	5
50391	10	Módulo de Exportación-Importación	\N	\N	f	f	\N	imp32	3	49125	8
50392	10	Definir workflows ERP pedidos	\N	\N	f	f	\N	imp33	0	50391	0
50393	10	Formato de intercambio de pedidos  e elementos de pedido	\N	\N	f	f	\N	imp34	0	50391	1
50394	10	Formato de intercambio de información de avances	\N	\N	f	f	\N	imp35	0	50391	2
50395	10	Formato de intercambio de recursos	\N	\N	f	f	\N	imp36	0	50391	3
50396	10	Formato de intercambio de materiais	\N	\N	f	f	\N	imp37	0	50391	4
50398	10	Módulo de presentación	\N	\N	f	f	\N	pres39	3	49125	9
50601	10	Imprimir o diagrama de Gantt en varias páxinas	\N	\N	f	f	\N	pres40	0	50398	0
50602	10	Imprimir información de pantalla  do planificador	\N	\N	f	f	\N	pres41	0	50398	1
50375	10	Modelos de pedidos e planificación	\N	\N	f	f	\N	plan16	0	50371	3
50376	10	Módulo de partes de traballo	\N	\N	f	f	\N	part17	3	49125	4
50377	10	Procura de partes de traballo	\N	\N	f	f	\N	part18	0	50376	0
50378	10	Módulo de materiais	\N	\N	f	f	\N	mat19	3	49125	5
50379	10	Informe de necesidades de materiais 	\N	\N	f	f	\N	mat20	0	50378	0
50380	10	Módulo de xestión da calidade	\N	\N	f	f	\N	cal21	3	49125	6
50381	10	Administración de checklists	\N	\N	f	f	\N	cal22	0	50380	0
50382	10	Cubrir formularios de calidade en planificación 	\N	\N	f	f	\N	cal23	0	50380	1
50383	10	Incorporar as listas de chequeo nos modelos de planificación	\N	\N	f	f	\N	cal24	0	50380	2
\.


--
-- Data for Name: orderline; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderline (orderelementid) FROM stdin;
1126
1127
1128
1129
1130
1150
1151
1152
1153
1154
1180
1181
1182
1183
1356
1358
1359
1362
1363
1364
1365
27604
27606
27607
27608
27609
29321
29323
29324
29325
29326
32831
32832
32884
35791
35792
35793
35794
35795
35796
35797
35798
38080
39872
39873
39875
39876
39878
39879
39880
39881
39882
39884
39885
39886
39887
50361
50362
50363
50364
50366
50367
50368
50370
50372
50373
50374
50375
50377
50379
50381
50382
50383
50385
50386
50387
50388
50389
50390
50392
50393
50394
50395
50396
50601
50602
50644
50645
50647
50649
50651
50652
50653
50654
50655
50656
50657
50658
50659
50660
50661
50662
50670
50671
\.


--
-- Data for Name: orderlinegroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY orderlinegroup (orderelementid) FROM stdin;
1022
1035
1149
1179
1325
1357
1360
1361
27603
27605
29320
29322
32883
35766
39823
39874
39877
39883
49125
50360
50365
50369
50371
50376
50378
50380
50384
50391
50398
50643
50646
50648
50650
50669
\.


--
-- Data for Name: ordersequence; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY ordersequence (id, version, prefix, lastvalue, numberofdigits, active) FROM stdin;
58580	1	PREFIX	0	5	t
\.


--
-- Data for Name: profile_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY profile_roles (profileid, elt) FROM stdin;
\.


--
-- Data for Name: quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form (id, version, name, description, qualityformtype) FROM stdin;
\.


--
-- Data for Name: quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY quality_form_items (quality_form_id, name, percentage, "position", idx) FROM stdin;
\.


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resource (id, version, calendar) FROM stdin;
49313	2	49395
49297	6	58790
36159	5	58786
37573	4	58785
49300	3	58784
49304	6	58782
40199	9	58789
49309	7	58783
1720	2	206
1718	2	205
1724	5	208
1722	3	207
7272	6	7373
1726	7	209
1727	9	210
37575	2	37674
49315	2	49396
49302	4	58787
49289	5	58788
\.


--
-- Data for Name: resourceallocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourceallocation (id, version, resourcesperday, task, assignment_function) FROM stdin;
6367	3	1.00	3141	\N
6369	4	0.69	3139	24953
6368	4	0.50	3139	\N
19903	3	1.00	3140	\N
3984	6	0.69	3131	\N
3981	8	1.00	3133	\N
3985	8	1.00	3133	\N
8589	3	1.00	3136	\N
8588	3	1.00	3137	\N
3983	6	1.00	3132	\N
3982	6	1.00	3132	\N
41065	6	0.75	40099	\N
41074	6	0.75	40099	\N
41076	6	0.75	40099	\N
41072	6	0.75	40099	\N
3940	6	1.00	1212	\N
19901	3	1.00	1214	\N
3952	5	2.08	1213	\N
3951	5	2.08	1213	\N
3950	5	0.25	1216	\N
3953	5	1.00	1215	\N
41067	6	0.75	40099	\N
41075	6	0.75	40100	\N
41077	6	0.75	40100	\N
41073	6	0.75	40100	\N
41066	6	0.75	40100	\N
41068	6	0.75	40100	\N
41013	18	0.48	40108	\N
29807	0	1.00	29595	\N
29808	3	0.36	29593	\N
19898	3	1.00	1223	\N
19899	3	0.82	1221	\N
19897	3	1.00	1222	\N
3955	16	1.36	1218	\N
24143	4	0.87	1219	\N
28093	2	1.02	27878	\N
31014	3	1.00	27876	\N
41014	18	0.75	40109	\N
41050	14	1.00	40111	\N
41069	6	0.07	40098	\N
38596	3	0.11	36765	\N
38601	1	0.04	36770	\N
38595	3	1.00	36766	\N
38582	13	0.42	38380	\N
38597	3	1.00	36767	\N
38583	7	1.00	36768	\N
38600	2	0.44	36771	\N
38598	3	1.00	36769	\N
36966	17	0.09	36764	37371
41061	12	0.75	40103	\N
41051	14	0.75	40104	\N
41046	14	1.00	40104	\N
41052	14	0.75	40105	\N
41047	14	1.00	40105	\N
41048	14	1.00	40106	\N
41053	14	0.75	40106	\N
41054	10	0.11	40097	\N
66069	5	1.00	58190	\N
61490	5	1.00	58190	\N
61430	5	1.00	58190	\N
61474	5	1.00	58190	\N
61505	5	1.00	58190	\N
66055	5	0.29	58234	\N
61508	5	0.46	58234	\N
66054	5	0.29	58234	\N
59217	25	1.25	58181	\N
66078	5	1.00	58182	\N
61494	5	1.00	58182	\N
66056	5	1.00	58182	\N
60446	16	2.73	58231	\N
60410	16	0.30	58231	\N
59285	16	0.30	58231	\N
60431	16	0.30	58231	\N
59276	16	0.30	58231	\N
60447	16	3.33	58232	\N
59286	16	0.33	58232	\N
60432	16	0.33	58232	\N
59277	16	0.33	58232	\N
60411	16	0.33	58232	\N
59275	16	1.00	58185	\N
59265	16	1.00	58185	\N
60430	16	1.00	58185	\N
60409	16	1.00	58185	\N
59284	16	1.00	58185	\N
60445	16	1.00	58185	\N
60436	16	1.20	58213	\N
60412	16	1.20	58213	\N
60451	16	1.20	58213	\N
60413	16	1.00	58214	\N
60452	16	1.00	58214	\N
60437	16	1.00	58214	\N
61409	15	1.00	58194	\N
61480	5	1.00	58182	\N
61427	5	1.00	58182	\N
61411	5	1.00	58182	\N
61453	5	1.00	58182	\N
61466	5	1.00	58182	\N
66079	5	1.00	58183	\N
61467	5	1.00	58183	\N
61495	5	1.00	58183	\N
61481	5	1.00	58183	\N
66057	5	1.00	58183	\N
61454	5	1.00	58183	\N
60404	16	1.00	58201	\N
59253	16	1.00	58201	\N
59240	16	1.00	58201	\N
60425	16	1.00	58201	\N
59279	16	1.00	58201	\N
60440	16	1.00	58201	\N
59270	16	1.00	58201	\N
59260	16	1.00	58201	\N
60426	16	1.00	58202	\N
59271	16	1.00	58202	\N
59254	16	1.00	58202	\N
59280	16	1.00	58202	\N
60405	16	1.00	58202	\N
59241	16	1.00	58202	\N
59261	16	1.00	58202	\N
60441	16	1.00	58202	\N
59255	16	1.67	58203	\N
59242	16	1.67	58203	\N
60406	16	1.67	58203	\N
60442	16	11.67	58203	\N
59272	16	1.67	58203	\N
60427	16	1.67	58203	\N
59281	16	1.67	58203	\N
59262	16	1.67	58203	\N
59256	16	1.00	58204	\N
59282	16	1.00	58204	\N
60428	16	1.00	58204	\N
59263	16	1.00	58204	\N
66080	5	1.00	58223	\N
66081	5	1.00	58226	\N
66082	5	1.50	58228	\N
66089	5	1.00	58187	\N
66066	5	1.00	58187	\N
61471	5	1.00	58187	\N
61487	5	1.00	58187	\N
61428	5	1.00	58187	\N
61502	5	1.00	58187	\N
61456	5	1.00	58187	\N
61472	5	1.00	58188	\N
61488	5	1.00	58188	\N
66090	5	1.00	58188	\N
61429	5	1.00	58188	\N
61457	5	1.00	58188	\N
66067	5	1.00	58188	\N
61503	5	1.00	58188	\N
66068	5	1.00	58189	\N
66091	5	1.00	58189	\N
61473	5	1.00	58189	\N
61489	5	1.00	58189	\N
61458	5	1.00	58189	\N
61504	5	1.00	58189	\N
61459	5	1.00	58190	\N
60443	16	14.00	58204	\N
59273	16	1.00	58204	\N
60407	16	1.00	58204	\N
60444	16	9.33	58205	\N
59274	16	1.33	58205	\N
59257	16	1.33	58205	\N
60429	16	1.33	58205	\N
60408	16	1.33	58205	\N
59283	16	1.33	58205	\N
59264	16	1.33	58205	\N
59189	30	1.00	58176	\N
59220	25	1.00	58177	\N
59191	25	1.00	58177	\N
59199	25	1.00	58177	\N
59194	25	1.00	58177	\N
59200	25	1.00	58178	\N
59195	25	1.00	58178	\N
59221	25	1.00	58178	\N
59222	25	1.00	58179	\N
59201	25	1.00	58179	\N
61498	5	1.00	58216	\N
66062	5	1.00	58216	\N
61483	5	1.00	58216	\N
66085	5	1.00	58216	\N
66063	5	1.00	58217	\N
61499	5	1.00	58217	\N
66086	5	1.00	58217	\N
61484	5	1.00	58217	\N
61470	5	0.50	58207	\N
61500	5	0.50	58207	\N
66087	5	0.50	58207	\N
66065	5	0.50	58207	\N
61469	5	0.50	58207	\N
61501	5	0.50	58207	\N
66064	5	0.50	58207	\N
66088	5	0.50	58207	\N
61485	5	0.50	58207	\N
61486	5	0.50	58207	\N
59218	25	1.00	58208	\N
60403	16	1.67	58209	\N
59232	16	1.67	58209	\N
59239	16	1.67	58209	\N
59259	16	1.67	58209	\N
59278	16	1.67	58209	\N
60439	16	4.38	58209	\N
60424	16	1.67	58209	\N
59252	16	1.67	58209	\N
66058	5	1.00	58221	\N
61455	5	1.00	58221	\N
66144	5	1.00	58221	\N
68691	5	1.00	58221	\N
66083	5	1.00	58221	\N
61496	5	1.00	58221	\N
61468	5	1.00	58221	\N
61482	5	1.00	58221	\N
60423	16	1.00	58192	\N
60438	16	1.00	58192	\N
66076	5	1.00	58236	\N
61506	5	1.00	58236	\N
61451	5	1.00	58236	\N
66132	5	1.00	58236	\N
61464	5	1.00	58236	\N
66154	5	1.00	58236	\N
61492	5	1.00	58236	\N
61478	5	1.00	58236	\N
61479	5	1.00	58237	\N
61507	5	1.00	58237	\N
66077	5	1.00	58237	\N
61465	5	1.00	58237	\N
66133	5	1.00	58237	\N
61493	5	1.00	58237	\N
61426	5	1.00	58237	\N
61452	5	1.00	58237	\N
68680	5	1.00	58237	\N
68706	3	0.25	58210	\N
68683	5	1.00	58223	\N
66136	5	1.00	58223	\N
66137	5	1.50	58224	\N
68684	5	1.50	58224	\N
68685	5	3.00	58225	\N
66138	5	3.00	58225	\N
68686	5	1.00	58226	\N
66139	5	1.00	58226	\N
66140	5	1.00	58227	\N
68687	5	1.00	58227	\N
68688	5	1.50	58228	\N
66141	5	1.50	58228	\N
66142	5	1.00	58229	\N
68689	5	1.00	58229	\N
68690	5	3.00	58230	\N
66143	5	3.00	58230	\N
68697	5	1.00	58187	\N
66150	5	1.00	58187	\N
68698	5	1.00	58188	\N
66151	5	1.00	58188	\N
68699	5	1.00	58189	\N
66152	5	1.00	58189	\N
66092	5	1.00	58190	\N
66153	5	1.00	58190	\N
68700	5	1.00	58190	\N
66134	5	1.00	58182	\N
68681	5	1.00	58182	\N
68682	5	1.00	58183	\N
66135	5	1.00	58183	\N
68693	5	1.00	58216	\N
66146	5	1.00	58216	\N
68694	5	1.00	58217	\N
66147	5	1.00	58217	\N
68696	5	0.50	58207	\N
68695	5	0.50	58207	\N
66148	5	0.50	58207	\N
66149	5	0.50	58207	\N
59269	16	1.67	58209	\N
60448	16	1.00	58196	\N
60433	16	1.00	58196	\N
68704	3	0.25	58210	\N
68705	3	0.25	58211	\N
60434	16	1.00	58197	\N
60449	16	1.00	58197	\N
60435	16	1.00	58198	\N
60450	16	1.00	58198	\N
68692	5	0.16	58219	\N
66145	5	0.16	58219	\N
66084	5	0.16	58219	\N
61497	5	0.16	58219	\N
66059	5	0.16	58219	\N
66060	5	0.52	58235	\N
66061	5	0.52	58235	\N
68707	3	0.25	58211	\N
\.


--
-- Data for Name: resourcecalendar; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resourcecalendar (base_calendar_id, capacity) FROM stdin;
205	\N
206	\N
207	\N
208	\N
209	\N
210	\N
7373	\N
36259	\N
37673	\N
37674	\N
40299	\N
49389	\N
49390	\N
49391	\N
49392	\N
49393	\N
49394	\N
49396	\N
58787	1
58788	1
49395	\N
58790	1
58786	1
58785	1
58784	1
58782	1
58789	1
58783	1
\.


--
-- Data for Name: resources_cost_category_assignment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY resources_cost_category_assignment (id, version, initdate, enddate, cost_category_id, resource_id) FROM stdin;
26058	1	2009-12-09	\N	1315	1724
21009	3	2009-12-09	2009-12-25	1314	1726
3434	5	2009-12-26	\N	1313	1726
\.


--
-- Data for Name: specific_resource_allocation; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY specific_resource_allocation (resource_allocation_id, resource) FROM stdin;
68683	49297
66080	49297
19903	1724
66136	49297
66137	49297
68684	49297
68685	49297
66138	49297
29807	1722
31014	1720
68686	49297
66139	49297
66081	49297
68704	49313
66140	49297
68687	49297
68705	49313
68688	49297
66082	49297
66141	49297
66142	49297
68689	49297
68690	49297
66143	49297
60446	36159
60410	36159
59285	36159
60431	36159
59276	36159
60447	36159
59286	36159
60432	36159
59277	36159
60411	36159
68697	49300
68691	49300
66083	49300
61496	49300
61468	49300
61482	49300
60423	49309
60438	49309
66076	49300
61506	49300
61451	49300
66132	49300
61464	49300
66154	49300
61492	49300
61478	49300
61479	49300
61507	49300
66077	49300
61465	49300
66133	49300
61493	49300
61426	49300
61452	49300
68680	49300
59275	36159
59265	36159
60430	36159
60409	36159
59284	36159
60445	36159
66089	49300
66066	49300
61471	49300
61487	49300
61428	49300
61502	49300
66150	49300
61456	49300
61472	49300
68698	49300
61488	49300
66090	49300
66151	49300
61429	49300
61457	49300
66067	49300
61503	49300
66068	49300
68699	49300
66091	49300
61473	49300
66152	49300
61489	49300
61458	49300
61504	49300
66092	49300
61459	49300
66069	49300
61490	49300
61430	49300
66153	49300
61474	49300
68700	49300
61505	49300
60436	36159
60412	36159
60451	36159
60413	36159
60452	36159
60437	36159
66055	49289
61508	49304
66054	49302
61409	49309
59217	37573
66134	49309
68681	49309
66078	49309
61494	49309
66056	49309
61480	49309
61427	49309
61411	49309
61453	49309
61466	49309
68682	49300
66079	49300
61467	49300
61495	49300
61481	49300
66135	49300
66057	49300
61454	49300
60404	37573
59253	37573
59240	37573
60425	37573
59279	37573
60440	37573
59270	37573
59260	37573
60426	37573
59271	37573
59254	37573
59280	37573
68706	49313
68707	49313
60405	37573
59241	37573
59261	37573
60441	37573
59255	37573
59242	37573
60406	37573
60442	37573
59272	37573
60427	37573
59281	37573
59262	37573
59256	37573
59282	37573
60428	37573
59263	37573
60443	37573
59273	37573
60407	37573
60444	37573
59274	37573
59257	37573
60429	37573
60408	37573
59283	37573
59264	37573
59189	40199
59220	40199
59191	40199
59199	40199
59194	40199
59200	40199
59195	40199
59221	40199
59222	40199
59201	40199
68693	49302
61498	49302
66062	49302
61483	49302
66146	49302
66085	49302
66063	49302
61499	49302
68694	49302
66086	49302
61484	49302
66147	49302
61470	49302
61500	49289
66087	49289
66065	49302
61469	49289
68696	49302
68695	49289
66148	49289
66149	49302
61501	49302
66064	49289
66088	49302
61485	49289
61486	49302
59218	37573
60403	37573
59232	37573
59239	37573
59259	37573
59278	37573
60439	37573
60424	37573
59252	37573
59269	37573
60448	49309
60433	49309
60434	49309
60449	49309
60435	49309
60450	49309
68692	49289
66145	49289
66084	49289
61497	49289
66059	49289
66060	49289
66061	49302
66058	49300
61455	49300
66144	49300
\.


--
-- Data for Name: stretches; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretches (assignment_function_id, date, lengthpercentage, amountworkpercentage, stretch_position) FROM stdin;
4245	2009-12-08	0.10	0.20	0
4245	2009-12-12	0.40	0.55	1
4245	2009-12-15	0.60	0.80	2
4245	2009-12-20	1.00	1.00	3
24953	2009-12-10	0.10	0.05	0
24953	2009-12-12	0.20	0.15	1
24953	2009-12-20	0.50	0.45	2
24953	2010-01-01	1.00	1.00	3
37371	2010-02-16	0.40	0.10	0
37371	2010-03-26	1.00	1.00	1
\.


--
-- Data for Name: stretchesfunction; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY stretchesfunction (assignment_function_id) FROM stdin;
4245
24953
37371
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task (task_element_id, calculatedvalue, startconstrainttype, constraintdate) FROM stdin;
1212	1	1	2009-11-28 16:06:06.476
1214	1	0	\N
1213	2	0	\N
1216	1	0	\N
1215	1	1	2009-12-15 02:35:46.838
40097	2	0	\N
40098	2	0	\N
40099	1	1	2010-01-26 06:00:00
40100	1	0	\N
40102	1	0	\N
40103	1	0	\N
40104	1	0	\N
40105	1	0	\N
40106	1	0	\N
40108	2	0	\N
40109	1	0	\N
40110	1	0	\N
40111	1	1	2010-02-05 04:48:00
3141	1	1	2010-02-26 03:54:19.558
3139	1	0	\N
3142	1	0	\N
3140	1	0	\N
27878	2	0	\N
27876	1	0	\N
33027	1	0	\N
33028	1	0	\N
29593	2	1	2010-01-11 12:05:14.108
29595	0	1	2010-01-07 20:25:18.472
33032	1	0	\N
1218	2	0	\N
1219	2	0	\N
1221	2	1	2009-12-18 18:15:42.474
1222	1	0	\N
1223	1	0	\N
3131	2	0	\N
3132	1	1	2010-03-01 19:34:15.194
3133	1	0	\N
3136	1	1	2010-02-07 21:34:41.378
3137	1	1	2010-04-09 05:03:29.372
36765	2	1	2010-01-20 21:07:33.24
36770	2	0	\N
36766	1	0	\N
38380	2	0	\N
36767	1	1	2010-02-18 22:17:25.42
36768	1	0	\N
36771	2	1	2010-03-19 04:15:21.12
36769	1	1	2010-03-16 03:11:51.036
36764	2	0	\N
58188	1	0	\N
58189	1	0	\N
58190	1	0	\N
58213	1	0	\N
58214	1	0	\N
58234	2	0	\N
58194	1	0	\N
58181	1	0	\N
58182	1	0	\N
58183	1	0	\N
58200	1	0	\N
58201	1	0	\N
58202	1	0	\N
58203	2	0	\N
58204	2	0	\N
58205	2	0	\N
58176	1	0	\N
58177	1	0	\N
58178	1	0	\N
58179	1	0	\N
58216	1	0	\N
58217	1	0	\N
58207	1	0	\N
58208	1	0	\N
58209	2	0	\N
58210	1	0	\N
58211	1	0	\N
58196	1	0	\N
58197	1	0	\N
58198	1	0	\N
58219	2	0	\N
58235	2	0	\N
58221	1	0	\N
58192	1	0	\N
58236	1	0	\N
58237	1	0	\N
58223	1	0	\N
58224	2	0	\N
58225	2	0	\N
58226	1	0	\N
58227	1	0	\N
58228	2	0	\N
58229	1	0	\N
58230	2	0	\N
58231	2	0	\N
58232	2	0	\N
58185	1	0	\N
58187	1	0	\N
\.


--
-- Data for Name: task_quality_form; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form (id, version, quality_form_id, order_element_id) FROM stdin;
\.


--
-- Data for Name: task_quality_form_items; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_quality_form_items (task_quality_form_id, name, percentage, "position", passed, date, idx) FROM stdin;
\.


--
-- Data for Name: task_source_hours_groups; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY task_source_hours_groups (task_source_id, hours_group_id) FROM stdin;
1217	2847
1217	2846
1217	2844
1217	2843
1217	2845
1220	2863
1220	2864
36772	35987
36772	35986
1224	2863
1224	2864
1224	2865
1224	2866
1224	2867
36772	35983
36772	35981
36772	35982
36772	35985
36772	35984
36772	35980
3134	1439
3134	1438
3135	1439
3135	1438
3131	1435
3132	1436
3138	1439
3138	1435
3138	1438
3138	1440
3138	1441
3138	1436
3138	1437
3132	1437
3133	1438
3136	1440
3137	1441
3143	2881
3143	2880
3143	2883
3143	2882
1212	2843
3139	2880
3139	1891
3140	2881
3141	2882
3142	2883
1213	1457
1213	2844
1214	2845
1215	2846
1215	1855
1216	1856
1216	2847
40097	40035
40098	40036
40099	40037
40100	40038
40102	40039
1218	2863
1219	2864
1221	2865
1222	2866
1223	2867
40103	40040
27877	27792
27877	27791
40104	40041
27879	27792
27879	27793
27879	27794
27879	27791
27879	27790
40105	40042
40106	40043
40108	40044
40109	40045
40110	40046
40111	40047
58176	50189
58177	50190
58178	50191
58179	50192
58180	50189
58180	50190
58180	50191
58180	50192
58181	50193
27876	27792
27878	27793
58182	50194
29594	29509
29594	29508
58183	50195
29596	29511
29596	29507
29596	29510
29596	29509
29596	29508
58184	50193
36764	35980
36765	35981
36766	35982
33027	29507
29593	29508
33028	29509
29595	29510
36767	35983
33033	32983
33032	32983
36768	35984
36769	35985
36771	35987
36770	35986
38380	38282
58184	50194
58184	50195
58185	50196
58186	50196
40101	40038
40101	40037
58187	50500
58188	50501
58189	50502
58190	50503
58191	50500
40107	40043
40107	40041
40107	40040
40107	40039
40107	40042
58191	50501
58191	50502
58191	50503
58192	50504
40112	40045
40112	40046
40112	40044
40112	40047
40113	40045
40113	40043
40113	40040
40113	40046
40113	40039
40113	40037
40113	40036
40113	40041
40113	40038
40113	40044
40113	40035
40113	40047
40113	40042
58193	50504
58194	50505
58195	50505
58196	50506
58197	50507
58198	50508
58199	50507
58199	50508
58199	50506
58200	50509
58201	50510
58202	50511
58203	50512
58204	50513
58205	50514
58206	50513
58206	50514
58206	50510
58206	50509
58206	50512
58206	50511
58207	50515
58208	50516
58209	50517
58210	50518
58211	50519
58212	50515
58212	50519
58212	50517
58212	50518
58212	50516
58213	50521
58214	50522
58215	50522
58215	50521
58216	50555
58217	50556
58218	50555
58218	50556
58219	50557
58220	50557
58221	50558
58222	50558
58223	50559
58224	50560
58225	50561
58226	50562
58227	50563
58228	50564
58229	50565
58230	50566
58231	50567
58232	50568
58233	50568
58233	50563
58233	50562
58233	50565
58233	50564
58233	50566
58233	50560
58233	50561
58233	50559
58233	50567
58234	50569
58235	50570
58236	50575
58237	50576
58238	50576
58238	50575
58239	50563
58239	50196
58239	50501
58239	50194
58239	50517
58239	50518
58239	50192
58239	50521
58239	50505
58239	50568
58239	50569
58239	50195
58239	50565
58239	50566
58239	50509
58239	50516
58239	50570
58239	50564
58239	50506
58239	50561
58239	50513
58239	50189
58239	50500
58239	50507
58239	50576
58239	50504
58239	50502
58239	50575
58239	50522
58239	50193
58239	50514
58239	50558
58239	50557
58239	50510
58239	50562
58239	50556
58239	50191
58239	50503
58239	50512
58239	50190
58239	50555
58239	50515
58239	50508
58239	50519
58239	50560
58239	50559
58239	50511
58239	50567
\.


--
-- Data for Name: taskelement; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskelement (id, version, name, notes, startdate, enddate, deadline, parent, base_calendar_id, positioninparent) FROM stdin;
3141	10	Tarea3	\N	2010-02-26 03:54:19.558	2010-03-11 03:54:19.558	\N	3143	\N	2
3139	11	Tarea1	\N	2009-12-07 16:12:52.395	2010-01-01 16:12:52.395	\N	3143	\N	0
3142	10	Tarea4	\N	2010-03-11 03:54:19.558	2010-03-23 15:54:19.558	\N	3143	\N	3
3140	11	Tarea2	\N	2010-01-01 16:12:52.395	2010-02-25 16:12:52.395	\N	3143	\N	1
3143	10	\N	\N	2009-12-07 16:12:52.395	2010-03-23 15:54:19.558	2009-12-25	\N	\N	\N
1212	27	Adquisición de piezas	\N	2009-12-07 13:59:19.527	2009-12-24 13:59:19.527	\N	1217	\N	0
1214	27	Prueba del motor	\N	2009-12-24 13:59:19.527	2010-02-18 13:59:19.527	\N	1217	\N	2
1213	27	Montaje piezas	\N	2010-01-08 02:35:46.838	2010-01-16 02:35:46.838	\N	1217	\N	1
1216	27	Validación funcionamiento	\N	2010-02-18 13:59:19.527	2010-03-25 13:59:19.527	\N	1217	\N	4
1215	27	Instalación de motor	\N	2009-12-15 02:35:46.838	2010-01-08 02:35:46.838	\N	1217	\N	3
1217	27	\N	\N	2009-12-07 13:59:19.527	2010-03-25 13:59:19.527	2009-12-25	\N	\N	\N
36769	26	Gestión de especialidades	\N	2010-03-17 00:00:00	2010-03-19 00:00:00	\N	36772	\N	5
1218	33	Reuniones seguimiento 	\N	2009-11-02 00:00:00	2010-02-27 00:00:00	\N	1220	\N	0
1219	33	Seguimiento proyecto	\N	2010-02-27 00:00:00	2010-04-29 00:00:00	\N	1220	\N	1
1220	32	Coordinación	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	\N	1224	\N	0
1221	33	Montaje andamios	\N	2009-12-18 18:15:42.474	2010-02-12 18:15:42.474	\N	1224	\N	1
1222	33	Pintado cubierta	\N	2010-02-12 18:15:42.474	2010-03-30 18:15:42.474	\N	1224	\N	2
1223	33	Desmontaje andamios	\N	2010-03-30 18:15:42.474	2010-04-23 18:15:42.474	\N	1224	\N	3
1224	32	\N	\N	2009-11-02 00:00:00	2010-04-29 00:00:00	2010-03-25	\N	\N	\N
33032	3	\N	\N	\N	\N	\N	33033	\N	0
33033	3	\N	\N	\N	\N	2010-01-01	\N	\N	\N
36764	26	Coordinación	\N	2010-01-22 00:00:00	2010-03-26 00:00:00	\N	36772	\N	0
36772	26	\N	\N	2010-01-22 00:00:00	2010-03-26 15:02:48.34	2010-03-26	\N	\N	\N
40115	5	Entrega	\N	2010-02-12 15:36:00	2010-02-12 15:36:00	\N	40113	\N	5
3150	11	validacion previa	\N	2010-04-24 21:34:41.378	2010-04-24 21:34:41.378	\N	1224	\N	4
3131	12	Tarefa1	\N	2010-04-05 19:34:15.194	2010-04-23 19:34:15.194	\N	3138	\N	0
3132	12	Tarefa2	\N	2010-03-01 19:34:15.194	2010-04-05 19:34:15.194	\N	3138	\N	1
3133	12	Subsubtarefa3.1.1	\N	2010-03-29 21:34:41.378	2010-04-11 21:34:41.378	\N	3134	\N	0
27878	12	Exemplo5	\N	2010-01-16 00:10:01.713	2010-04-13 00:10:01.713	\N	27879	\N	1
27877	12	Exemplo2	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27879	\N	0
3151	11	entrega	\N	2010-04-23 19:34:15.194	2010-04-23 19:34:15.194	\N	1224	\N	5
27876	12	Exemplo4	\N	2009-12-10 00:10:01.713	2010-01-16 00:10:01.713	\N	27877	\N	0
27879	12	\N	\N	2009-12-10 00:10:01.713	2010-04-13 00:10:01.713	2010-04-15	\N	\N	\N
36765	26	Análisis	\N	2010-01-22 00:00:00	2010-02-18 20:21:57.46	\N	36772	\N	1
38389	11	Entrega	\N	2010-03-26 15:02:48.34	2010-03-26 15:02:48.34	\N	36772	\N	10
36770	26	Entorno	\N	2010-01-22 00:00:00	2010-03-25 20:19:23.46	\N	36772	\N	6
3134	12	Subtarefa3.1	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3135	\N	0
3135	12	Tarefa3	\N	2009-12-07 16:23:24.094	2010-04-11 21:34:41.378	\N	3138	\N	2
3136	12	Tarefa4	\N	2010-02-07 21:34:41.378	2010-03-29 21:34:41.378	\N	3138	\N	3
3137	12	Tarefa5	\N	2010-04-11 21:34:41.378	2010-04-24 21:34:41.378	\N	3138	\N	4
3138	12	\N	\N	2009-12-07 16:23:24.094	2010-04-24 21:34:41.378	2010-05-07	\N	\N	\N
36766	26	Migración contenidos	\N	2010-03-16 00:00:00	2010-03-17 00:00:00	\N	36772	\N	2
29593	6	Exemplo13	\N	2010-01-11 12:05:14.108	2010-04-19 12:05:14.108	\N	29594	\N	0
29594	6	Exemplo12	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	\N	29596	\N	0
29595	6	Exemplo15	\N	2010-01-07 20:25:18.472	2010-01-19 20:25:18.472	\N	29596	\N	1
29596	6	\N	\N	2009-12-10 01:15:12.433	2010-04-19 12:05:14.108	2010-04-16	\N	\N	\N
38380	19	Diseño gráfico	\N	2010-01-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	8
36767	26	Módulo de usuarios	\N	2010-02-18 22:17:25.42	2010-02-19 22:17:25.42	\N	36772	\N	3
38388	11	Entrega de diseño	\N	2010-02-22 00:00:00	2010-02-22 00:00:00	\N	36772	\N	9
36768	26	Plantillas y gestión de contenidos	\N	2010-02-22 00:00:00	2010-03-16 00:00:00	\N	36772	\N	4
33027	2	\N	\N	\N	\N	\N	29596	\N	2
33028	2	\N	\N	\N	\N	\N	29594	\N	1
58185	45	Recursos Virtuais	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58186	\N	0
58187	45	Compartir estado entre pestanas planificación	\N	2009-12-30 00:00:00	2010-01-05 00:00:00	\N	58191	\N	0
58188	45	Técnica de recálculo de planificación	\N	2010-01-05 00:00:00	2010-01-14 00:00:00	\N	58191	\N	1
58189	45	Filtrado de pedidos e tarefas de un pedido	\N	2010-01-23 00:00:00	2010-01-29 00:00:00	\N	58191	\N	2
58190	45	Modelos de pedidos e planificación	\N	2009-12-19 00:00:00	2009-12-30 00:00:00	\N	58191	\N	3
36771	26	Pruebas	\N	2010-03-19 04:15:21.12	2010-03-25 23:26:51.20	\N	36772	\N	7
58213	45	Imprimir o diagrama de Gantt en varias páxinas	\N	2010-01-19 00:00:00	2010-01-28 00:00:00	\N	58215	\N	0
58195	45	Módulo de materiais	\N	2009-12-14 00:00:00	2010-09-11 00:00:00	\N	58239	\N	5
58194	45	Informe de necesidades de materiais 	\N	2010-07-03 00:00:00	2010-09-11 00:00:00	\N	58195	\N	0
58180	45	Módulo de xestión de usuarios	\N	2009-12-14 00:00:00	2013-02-14 00:00:00	\N	58239	\N	0
58214	45	Imprimir información de pantalla  do planificador	\N	2009-12-22 00:00:00	2010-01-19 00:00:00	\N	58215	\N	1
58176	45	Xestión de usuarios	\N	2009-12-14 00:00:00	2009-12-15 00:00:00	\N	58180	\N	0
58177	45	Xestión de roles	\N	2009-12-15 00:00:00	2010-09-10 00:00:00	\N	58180	\N	1
40097	27	Coordinación	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	0
58178	45	Xestión de perfiles	\N	2010-09-10 00:00:00	2011-05-26 00:00:00	\N	58180	\N	2
58179	45	Xestión de roles e pedidos	\N	2011-05-26 00:00:00	2013-02-14 00:00:00	\N	58180	\N	3
40098	27	Análisis	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	1
40099	27	Implementación de páxina de xestión de pendentes e fluxo implicado	\N	2010-01-26 06:00:00	2010-01-29 06:00:00	\N	40101	\N	0
40100	27	Implementación de páxina de impresión e fluxo de impresión	\N	2010-01-29 06:00:00	2010-02-05 06:00:00	\N	40101	\N	1
40101	27	Módulo de comunicación con SEDA	\N	2010-01-14 00:00:00	2010-02-05 06:00:00	\N	40113	\N	2
40102	27	Montaxe infraestrutura php e soporte de consultas de servicios web	\N	2010-01-14 00:00:00	2010-01-19 03:36:00	\N	40107	\N	0
40103	27	Mecanismo de sesión e xestión de estado	\N	2010-01-19 03:36:00	2010-01-21 03:36:00	\N	40107	\N	1
40104	27	Obtención de listado de entrada pendentes	\N	2010-01-21 03:36:00	2010-01-22 03:36:00	\N	40107	\N	2
40105	27	Obtención de información para impresión de cada entrada	\N	2010-01-22 03:36:00	2010-01-23 03:36:00	\N	40107	\N	3
40106	27	Notificación de resultado de impresión de entrada	\N	2010-01-23 03:36:00	2010-01-26 03:36:00	\N	40107	\N	4
40107	27	Módulo de comunicación con JANTO	\N	2010-01-14 00:00:00	2010-01-26 03:36:00	\N	40113	\N	3
40108	27	Gestión de respositorios – Integración	\N	2010-01-14 00:00:00	2010-02-12 00:00:00	\N	40112	\N	0
40109	27	Montaje entorno de trabajo	\N	2010-01-11 00:00:00	2010-01-14 00:00:00	\N	40112	\N	1
40110	27	Implantación en producción	\N	2010-02-10 19:12:00	2010-02-11 22:48:00	\N	40112	\N	2
40112	27	Entorno	\N	2010-01-11 00:00:00	2010-02-12 00:00:00	\N	40113	\N	4
40111	27	Prueba	\N	2010-02-05 04:48:00	2010-02-10 19:12:00	\N	40113	\N	6
40113	27	\N	\N	2010-01-11 00:00:00	2010-02-12 15:36:00	2010-02-12	\N	\N	\N
58186	45	Módulo de recursos	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58239	\N	2
58191	45	Módulo de planificación	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	3
58184	45	Módulo de organización do traballo	\N	2009-12-14 00:00:00	2011-03-08 00:00:00	\N	58239	\N	1
58181	45	Xestión de código único	\N	2010-01-05 00:00:00	2011-03-08 00:00:00	\N	58184	\N	0
58182	45	Revisión formulario de pedidos	\N	2010-09-11 00:00:00	2010-09-22 00:00:00	\N	58184	\N	1
58183	45	Filtrado no listado de pedidos	\N	2010-01-29 00:00:00	2010-01-30 00:00:00	\N	58184	\N	2
58206	45	Módulo de integración con subcontratas	\N	2009-12-14 00:00:00	2013-02-16 08:00:00	\N	58239	\N	7
58200	45	Administración de subcontratas	\N	2013-02-14 00:00:00	2013-02-16 08:00:00	\N	58206	\N	0
58201	45	Formato de intercambio	\N	2011-03-18 00:00:00	2011-04-07 00:00:00	\N	58206	\N	1
58202	45	Fluxo de importación/exportación	\N	2011-04-07 00:00:00	2011-05-17 00:00:00	\N	58206	\N	2
58203	45	Interfaz de xestión de subcontración nos pedidos	\N	2011-05-17 00:00:00	2011-05-20 00:00:00	\N	58206	\N	3
58204	45	Converter en fitos subcontratacións	\N	2011-05-20 00:00:00	2011-05-23 00:00:00	\N	58206	\N	4
58205	45	Avance e custo de subcontratas en Técnica de Valor Gañado	\N	2011-05-23 00:00:00	2011-05-26 00:00:00	\N	58206	\N	5
58212	45	Módulo de Exportación-Importación	\N	2009-12-14 00:00:00	2011-03-18 00:00:00	\N	58239	\N	8
58207	45	Definir workflows ERP pedidos	\N	2009-12-14 00:00:00	2010-01-05 00:00:00	\N	58212	\N	0
58208	45	Formato de intercambio de pedidos  e elementos de pedido	\N	2009-12-14 00:00:00	2009-12-24 00:00:00	\N	58212	\N	1
58209	45	Formato de intercambio de información de avances	\N	2011-03-08 00:00:00	2011-03-18 00:00:00	\N	58212	\N	2
58210	45	Formato de intercambio de recursos	\N	2009-12-14 00:00:00	2009-12-30 00:00:00	\N	58212	\N	3
58211	45	Formato de intercambio de materiais	\N	2009-12-30 00:00:00	2010-01-21 00:00:00	\N	58212	\N	4
58199	45	Módulo de xestión da calidade	\N	2009-12-14 00:00:00	2010-07-03 00:00:00	\N	58239	\N	6
58196	45	Administración de checklists	\N	2009-12-14 00:00:00	2009-12-22 00:00:00	\N	58199	\N	0
58197	45	Cubrir formularios de calidade en planificación 	\N	2009-12-22 00:00:00	2010-02-20 00:00:00	\N	58199	\N	1
58198	45	Incorporar as listas de chequeo nos modelos de planificación	\N	2010-05-07 00:00:00	2010-07-03 00:00:00	\N	58199	\N	2
58193	45	Módulo de partes de traballo	\N	2009-12-14 00:00:00	2010-05-07 00:00:00	\N	58239	\N	4
58192	45	Procura de partes de traballo	\N	2010-02-20 00:00:00	2010-05-07 00:00:00	\N	58193	\N	0
58233	45	Módulo de extracción de informes	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	13
58223	45	Integración de Jasper Reports	\N	2009-12-14 00:00:00	2009-12-16 00:00:00	\N	58233	\N	0
58224	45	Informes sobre organizacións de traballo	\N	2010-01-05 00:00:00	2010-01-28 00:00:00	\N	58233	\N	1
58225	45	Informe sobre partes de traballo	\N	2010-01-28 00:00:00	2010-01-29 00:00:00	\N	58233	\N	2
58226	45	Informes de horas traballadas por un traballador	\N	2009-12-16 00:00:00	2009-12-19 00:00:00	\N	58233	\N	3
58227	45	Lista de avances de planificación da empresa	\N	2009-12-29 00:00:00	2010-01-01 00:00:00	\N	58233	\N	4
58228	45	Lista de avances de traballo da empresa	\N	2009-12-19 00:00:00	2009-12-23 00:00:00	\N	58233	\N	5
58229	45	Informe de horas estimadas/horas realizadas	\N	2009-12-23 00:00:00	2009-12-29 00:00:00	\N	58233	\N	6
58230	45	Horas realizadas organizadas por tipo de traballo	\N	2010-01-01 00:00:00	2010-01-05 00:00:00	\N	58233	\N	7
58231	45	Horas estimadas/realizadas por tipo de traballo	\N	2010-01-07 00:00:00	2010-01-29 00:00:00	\N	58233	\N	8
58232	45	Informe de traballador indicando custos por hora	\N	2009-12-22 00:00:00	2010-01-07 00:00:00	\N	58233	\N	9
58215	45	Módulo de presentación	\N	2009-12-14 00:00:00	2010-01-28 00:00:00	\N	58239	\N	9
58234	45	Coordinación	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	14
58218	45	Módulo de arquitectura tecnolóxica	\N	2009-12-14 00:00:00	2010-01-19 00:00:00	\N	58239	\N	10
58216	45	Enlazar a axuda de usuario	\N	2010-01-05 00:00:00	2010-01-13 00:00:00	\N	58218	\N	0
58217	45	Desenvolvemento de paquetes  Ubuntu	\N	2010-01-13 00:00:00	2010-01-19 00:00:00	\N	58218	\N	1
58220	45	Módulo de documentación de API	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	11
58219	45	Documentación das API's públicas	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58220	\N	0
58235	45	Análise	\N	2009-12-14 00:00:00	2010-01-29 00:00:00	\N	58239	\N	15
58222	45	Módulo de arquivo histórico	\N	2009-12-14 00:00:00	2010-01-20 00:00:00	\N	58239	\N	12
58221	45	Pasar pedidos a histórico	\N	2010-01-14 00:00:00	2010-01-20 00:00:00	\N	58222	\N	0
58238	45	Módulo de asignación de recursos	\N	2009-12-14 00:00:00	2010-01-23 00:00:00	\N	58239	\N	16
58236	45	Interpolación polinómica na asignación avanzada	\N	2010-01-20 00:00:00	2010-01-23 00:00:00	\N	58238	\N	0
58237	45	Asignación automática de configuración de máquina	\N	2009-12-14 00:00:00	2009-12-19 00:00:00	\N	58238	\N	1
58239	45	\N	\N	2009-12-14 00:00:00	2013-02-16 08:00:00	2010-01-30	\N	\N	\N
\.


--
-- Data for Name: taskgroup; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskgroup (task_element_id) FROM stdin;
1217
1220
1224
3134
3135
3138
3143
27877
27879
29594
29596
33033
36772
40101
40107
40112
40113
58180
58184
58186
58191
58193
58195
58199
58206
58212
58215
58218
58220
58222
58233
58238
58239
\.


--
-- Data for Name: taskmilestone; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY taskmilestone (task_element_id) FROM stdin;
3150
3151
38388
38389
40115
\.


--
-- Data for Name: tasksource; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY tasksource (id, version, orderelement) FROM stdin;
33032	3	32884
1218	19	1150
1219	19	1151
1220	19	1149
1221	19	1152
1222	19	1153
1223	19	1154
1224	19	1035
33033	3	32883
3139	6	1180
3140	6	1181
3141	6	1182
3142	6	1183
3143	6	1179
27876	5	27607
3131	5	1356
3132	5	1357
3133	5	1362
3134	5	1361
3135	5	1360
3136	5	1364
3137	5	1365
3138	5	1325
1212	20	1126
1213	20	1127
1214	20	1128
1215	20	1129
1216	20	1130
1217	20	1022
27877	5	27605
27878	5	27608
27879	5	27603
36764	8	35791
36765	8	35792
36766	8	35793
36767	8	35794
36768	8	35795
36769	8	35796
36771	8	35798
36770	8	35797
38380	5	38080
36772	8	35766
29593	5	29323
29594	5	29322
29595	5	29325
29596	5	29320
33027	2	29321
33028	2	29324
58176	2	50361
58177	2	50362
58178	2	50363
58179	2	50364
58180	2	50360
58181	2	50366
58182	2	50367
58183	2	50368
58184	2	50365
58185	2	50370
58186	2	50369
58187	2	50372
58188	2	50373
58189	2	50374
58190	2	50375
58191	2	50371
58192	2	50377
58193	2	50376
58194	2	50379
40097	7	39872
40098	7	39873
40099	7	39875
40100	7	39876
40101	7	39874
40102	7	39878
40103	7	39879
40104	7	39880
40105	7	39881
40106	7	39882
40107	7	39877
40108	7	39884
40109	7	39885
40110	7	39886
40112	7	39883
40111	7	39887
40113	7	39823
58195	2	50378
58196	2	50381
58197	2	50382
58198	2	50383
58199	2	50380
58200	2	50385
58201	2	50386
58202	2	50387
58203	2	50388
58204	2	50389
58205	2	50390
58206	2	50384
58207	2	50392
58208	2	50393
58209	2	50394
58210	2	50395
58211	2	50396
58212	2	50391
58213	2	50601
58214	2	50602
58215	2	50398
58216	2	50644
58217	2	50645
58218	2	50643
58219	2	50647
58220	2	50646
58221	2	50649
58222	2	50648
58223	2	50651
58224	2	50652
58225	2	50653
58226	2	50654
58227	2	50655
58228	2	50656
58229	2	50657
58230	2	50658
58231	2	50659
58232	2	50660
58233	2	50650
58234	2	50661
58235	2	50662
58236	2	50670
58237	2	50671
58238	2	50669
58239	2	49125
\.


--
-- Data for Name: type_of_work_hours; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY type_of_work_hours (id, version, name, code, defaultprice, enabled) FROM stdin;
1212	1	EXTRAORDINARIA	Cod1	15.00	t
1217	1	NORMAL	Cod2	10.00	t
31714	1	FESTIVOS	FESTIVOS	30.00	t
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_profiles (user_id, profile_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY user_roles (userid, elt) FROM stdin;
58681	ROLE_BASIC_USER
58682	ROLE_ADMINISTRATION
58682	ROLE_BASIC_USER
58683	ROLE_WS_READER
58684	ROLE_WS_WRITER
58684	ROLE_WS_READER
\.


--
-- Data for Name: virtualworker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY virtualworker (virtualworker_id, observations) FROM stdin;
\.


--
-- Data for Name: work_report; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report (id, version, date, work_report_type_id, resource_id, order_element_id) FROM stdin;
3636	1	2009-12-04 00:00:00	2526	1718	1126
3637	2	\N	2525	1722	\N
3638	1	\N	2525	1722	\N
7070	1	\N	2525	1724	\N
8100	1	\N	2525	1718	\N
17372	1	\N	2525	1722	\N
18786	1	\N	2525	1722	\N
26664	1	\N	21109	1718	1152
\.


--
-- Data for Name: work_report_label_type_assigment; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_label_type_assigment (id, version, labelssharedbylines, index, label_type_id, label_id, work_report_type_id, positionnumber) FROM stdin;
910	0	f	0	810	914	2526	\N
911	0	t	0	808	909	2527	\N
909	1	t	0	809	913	2525	\N
21210	1	t	1	808	910	21109	\N
\.


--
-- Data for Name: work_report_line; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_line (id, version, numhours, date, clockstart, clockfinish, work_report_id, resource_id, order_element_id, type_work_hours_id) FROM stdin;
3737	1	6	2009-12-04 00:00:00	1970-01-01 08:10:00	1970-01-01 14:11:00	3636	1718	1126	1212
3738	2	20	2009-12-07 00:00:00	\N	\N	3637	1722	1126	1217
3739	1	8	2009-12-07 00:00:00	\N	\N	3638	1722	1128	1217
3740	1	8	2009-12-04 00:00:00	\N	\N	3638	1722	1128	1217
7171	1	50	2009-12-07 00:00:00	\N	\N	7070	1724	1182	1217
7172	1	40	2009-12-08 00:00:00	\N	\N	7070	1724	1180	1217
7173	1	30	2009-12-09 00:00:00	\N	\N	7070	1724	1181	1217
8201	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8202	1	8	2009-12-15 00:00:00	\N	\N	8100	1718	1181	1217
8203	1	8	2009-12-11 00:00:00	\N	\N	8100	1718	1181	1217
8204	1	8	2009-12-08 00:00:00	\N	\N	8100	1718	1180	1217
8205	1	8	2009-12-14 00:00:00	\N	\N	8100	1718	1181	1217
8206	1	8	2009-12-10 00:00:00	\N	\N	8100	1718	1180	1217
8207	1	8	2009-12-07 00:00:00	\N	\N	8100	1718	1180	1217
8208	1	8	2009-12-09 00:00:00	\N	\N	8100	1718	1180	1217
17473	1	30	2009-12-09 00:00:00	\N	\N	17372	1722	1152	1217
17474	1	10	2009-12-10 00:00:00	\N	\N	17372	1722	1149	1217
17475	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1152	1217
17476	1	10	2009-12-07 00:00:00	\N	\N	17372	1722	1149	1217
17477	1	10	2009-12-09 00:00:00	\N	\N	17372	1722	1149	1217
17478	1	30	2009-12-10 00:00:00	\N	\N	17372	1722	1152	1217
17479	1	10	2009-12-08 00:00:00	\N	\N	17372	1722	1149	1217
18887	1	20	2009-12-07 00:00:00	\N	\N	18786	1722	1152	1217
26765	1	20	2009-12-09 00:00:00	\N	\N	26664	1718	1152	1217
\.


--
-- Data for Name: work_report_type; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY work_report_type (id, version, name, code, dateissharedbylines, resourceissharedinlines, orderelementissharedinlines, hoursmanagement) FROM stdin;
2526	1	Tipo2	cod2	t	t	t	1
2527	1	Tipo3	cod3	t	f	t	2
2525	4	Tipo1	cod1	f	t	f	0
21109	4	tipo4	codparte5	f	t	t	0
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY worker (worker_id, firstname, surname, nif) FROM stdin;
1720	Samuel	Lopez	22222222B
1718	Marcos	Cancela	11111111A
1724	Isabel	Dopacio	44444444D
1722	Andres	Lafuente	33333333C
1726	Silvia	Martinez	55555555E
37575	Pedro	Figueras	88888888H
49315	Proba1	Proba2	34343434C
49302	José María 	Casanova Crespo	44444444E
49289	Javier	Morán Rúa	11111111B
49313	Fernando	Bellas	10000000C
49297	Diego	Pino García	22222222C
36159	Lorenzo	Tilve Álvaro	66666666E
37573	Manuel	Rego Casasnovas	77777777G
49300	Oscar	González Fernández	33333333D
49304	Xavier	Castaño García	55555555F
40199	Jacobo	Aragunde	99999999H
49309	Susana	Montes	77777777P
\.


--
-- Data for Name: workreports_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreports_labels (work_report_id, label_id) FROM stdin;
3637	913
3638	913
7070	913
8100	913
17372	913
18786	913
26664	911
\.


--
-- Data for Name: workreportslines_labels; Type: TABLE DATA; Schema: public; Owner: naval
--

COPY workreportslines_labels (work_report_line_id, label_id) FROM stdin;
3737	914
\.


--
-- Name: advanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT advanceassignment_pkey PRIMARY KEY (id);


--
-- Name: advancemeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT advancemeasurement_pkey PRIMARY KEY (id);


--
-- Name: advancetype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_pkey PRIMARY KEY (id);


--
-- Name: advancetype_unitname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY advancetype
    ADD CONSTRAINT advancetype_unitname_key UNIQUE (unitname);


--
-- Name: all_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT all_criterions_pkey PRIMARY KEY (generic_resource_allocation_id, criterion_id);


--
-- Name: assignment_function_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY assignment_function
    ADD CONSTRAINT assignment_function_pkey PRIMARY KEY (id);


--
-- Name: basecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY basecalendar
    ADD CONSTRAINT basecalendar_pkey PRIMARY KEY (id);


--
-- Name: calendaravailability_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT calendaravailability_pkey PRIMARY KEY (id);


--
-- Name: calendardata_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT calendardata_pkey PRIMARY KEY (id);


--
-- Name: calendarexception_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT calendarexception_pkey PRIMARY KEY (id);


--
-- Name: calendarexceptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_name_key UNIQUE (name);


--
-- Name: calendarexceptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY calendarexceptiontype
    ADD CONSTRAINT calendarexceptiontype_pkey PRIMARY KEY (id);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (id);


--
-- Name: cost_category_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_name_key UNIQUE (name);


--
-- Name: cost_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY cost_category
    ADD CONSTRAINT cost_category_pkey PRIMARY KEY (id);


--
-- Name: criterion_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_name_key UNIQUE (name, id_criterion_type);


--
-- Name: criterion_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT criterion_pkey PRIMARY KEY (id);


--
-- Name: criterionrequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT criterionrequirement_pkey PRIMARY KEY (id);


--
-- Name: criterionsatisfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT criterionsatisfaction_pkey PRIMARY KEY (id);


--
-- Name: criteriontype_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_name_key UNIQUE (name);


--
-- Name: criteriontype_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY criteriontype
    ADD CONSTRAINT criteriontype_pkey PRIMARY KEY (id);


--
-- Name: day_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT day_assignment_pkey PRIMARY KEY (id);


--
-- Name: dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: derivedallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT derivedallocation_pkey PRIMARY KEY (id);


--
-- Name: directadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT directadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: generic_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT generic_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: hour_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT hour_cost_pkey PRIMARY KEY (id);


--
-- Name: hoursgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT hoursgroup_pkey PRIMARY KEY (id);


--
-- Name: hoursperday_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT hoursperday_pkey PRIMARY KEY (base_calendar_id, day_id);


--
-- Name: indirectadvanceassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT indirectadvanceassignment_pkey PRIMARY KEY (advance_assignment_id);


--
-- Name: label_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_name_key UNIQUE (name, label_type_id);


--
-- Name: label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_name_key UNIQUE (name);


--
-- Name: label_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY label_type
    ADD CONSTRAINT label_type_pkey PRIMARY KEY (id);


--
-- Name: machine_configuration_unit_required_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT machine_configuration_unit_required_criterions_pkey PRIMARY KEY (id, criterion_id);


--
-- Name: machine_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT machine_pkey PRIMARY KEY (machine_id);


--
-- Name: machineworkerassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT machineworkerassignment_pkey PRIMARY KEY (id);


--
-- Name: machineworkersconfigurationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT machineworkersconfigurationunit_pkey PRIMARY KEY (id);


--
-- Name: material_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT material_assigment_pkey PRIMARY KEY (id);


--
-- Name: material_category_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT material_category_pkey PRIMARY KEY (id);


--
-- Name: material_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_code_key UNIQUE (code);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_pkey PRIMARY KEY (id);


--
-- Name: naval_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_profile
    ADD CONSTRAINT naval_profile_profilename_key UNIQUE (profilename);


--
-- Name: naval_user_loginname_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_loginname_key UNIQUE (loginname);


--
-- Name: naval_user_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY naval_user
    ADD CONSTRAINT naval_user_pkey PRIMARY KEY (id);


--
-- Name: order_element_label_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT order_element_label_pkey PRIMARY KEY (order_element_id, label_id);


--
-- Name: order_table_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT order_table_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT orderelement_pkey PRIMARY KEY (id);


--
-- Name: orderline_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT orderline_pkey PRIMARY KEY (orderelementid);


--
-- Name: orderlinegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT orderlinegroup_pkey PRIMARY KEY (orderelementid);


--
-- Name: ordersequence_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY ordersequence
    ADD CONSTRAINT ordersequence_pkey PRIMARY KEY (id);


--
-- Name: quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT quality_form_items_pkey PRIMARY KEY (quality_form_id, idx);


--
-- Name: quality_form_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_name_key UNIQUE (name);


--
-- Name: quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY quality_form
    ADD CONSTRAINT quality_form_pkey PRIMARY KEY (id);


--
-- Name: resource_calendar_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_calendar_key UNIQUE (calendar);


--
-- Name: resource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resourceallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT resourceallocation_pkey PRIMARY KEY (id);


--
-- Name: resourcecalendar_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT resourcecalendar_pkey PRIMARY KEY (base_calendar_id);


--
-- Name: resources_cost_category_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT resources_cost_category_assignment_pkey PRIMARY KEY (id);


--
-- Name: specific_resource_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT specific_resource_allocation_pkey PRIMARY KEY (resource_allocation_id);


--
-- Name: stretches_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT stretches_pkey PRIMARY KEY (assignment_function_id, stretch_position);


--
-- Name: stretchesfunction_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT stretchesfunction_pkey PRIMARY KEY (assignment_function_id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (task_element_id);


--
-- Name: task_quality_form_items_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT task_quality_form_items_pkey PRIMARY KEY (task_quality_form_id, idx);


--
-- Name: task_quality_form_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT task_quality_form_pkey PRIMARY KEY (id);


--
-- Name: task_source_hours_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT task_source_hours_groups_pkey PRIMARY KEY (task_source_id, hours_group_id);


--
-- Name: taskelement_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT taskelement_pkey PRIMARY KEY (id);


--
-- Name: taskgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT taskgroup_pkey PRIMARY KEY (task_element_id);


--
-- Name: taskmilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT taskmilestone_pkey PRIMARY KEY (task_element_id);


--
-- Name: tasksource_orderelement_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_orderelement_key UNIQUE (orderelement);


--
-- Name: tasksource_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT tasksource_pkey PRIMARY KEY (id);


--
-- Name: type_of_work_hours_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_code_key UNIQUE (code);


--
-- Name: type_of_work_hours_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_name_key UNIQUE (name);


--
-- Name: type_of_work_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY type_of_work_hours
    ADD CONSTRAINT type_of_work_hours_pkey PRIMARY KEY (id);


--
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id, profile_id);


--
-- Name: virtualworker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT virtualworker_pkey PRIMARY KEY (virtualworker_id);


--
-- Name: work_report_label_type_assigment_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT work_report_label_type_assigment_pkey PRIMARY KEY (id);


--
-- Name: work_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT work_report_line_pkey PRIMARY KEY (id);


--
-- Name: work_report_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT work_report_pkey PRIMARY KEY (id);


--
-- Name: work_report_type_code_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_code_key UNIQUE (code);


--
-- Name: work_report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_name_key UNIQUE (name);


--
-- Name: work_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY work_report_type
    ADD CONSTRAINT work_report_type_pkey PRIMARY KEY (id);


--
-- Name: worker_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (worker_id);


--
-- Name: workreports_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT workreports_labels_pkey PRIMARY KEY (work_report_id, label_id);


--
-- Name: workreportslines_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: naval; Tablespace: 
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT workreportslines_labels_pkey PRIMARY KEY (work_report_line_id, label_id);


--
-- Name: fk109ac09e8b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09e8b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fk109ac09eefda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form
    ADD CONSTRAINT fk109ac09eefda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1961a43d415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY heading_field
    ADD CONSTRAINT fk1961a43d415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a222131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fk1a95a22248d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a22248d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk1a95a222efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report
    ADD CONSTRAINT fk1a95a222efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk1a9afa91a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk1a9afa91adad7e51; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendarexception
    ADD CONSTRAINT fk1a9afa91adad7e51 FOREIGN KEY (calendar_exception_id) REFERENCES calendarexceptiontype(id);


--
-- Name: fk27a9a54936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk27a9a54936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk3a79eb0261f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb0261f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk3a79eb02e036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02e036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fk3a79eb02efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3a79eb02f41d57f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionrequirement
    ADD CONSTRAINT fk3a79eb02f41d57f2 FOREIGN KEY (parent) REFERENCES criterionrequirement(id);


--
-- Name: fk3afdc2bd75ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd75ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fk3afdc2bd87b470f0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY derivedallocation
    ADD CONSTRAINT fk3afdc2bd87b470f0 FOREIGN KEY (configurationunit) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk3d1ffd21218d7620; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd21218d7620 FOREIGN KEY (indirect_order_element_id) REFERENCES orderelement(id);


--
-- Name: fk3d1ffd212f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd212f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fk3d1ffd218202350f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY indirectadvanceassignment
    ADD CONSTRAINT fk3d1ffd218202350f FOREIGN KEY (indirect_order_element_id) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk3f30d9ad8c4c676c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9ad8c4c676c FOREIGN KEY (criterion) REFERENCES criterion(id);


--
-- Name: fk3f30d9adeae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterionsatisfaction
    ADD CONSTRAINT fk3f30d9adeae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fk401dc6acffeb5538; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkersconfigurationunit
    ADD CONSTRAINT fk401dc6acffeb5538 FOREIGN KEY (machine) REFERENCES machine(machine_id);


--
-- Name: fk407955279578651e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material
    ADD CONSTRAINT fk407955279578651e FOREIGN KEY (category_id) REFERENCES material_category(id);


--
-- Name: fk41e073ae15671e92; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073ae15671e92 FOREIGN KEY (assignment_function) REFERENCES assignment_function(id);


--
-- Name: fk41e073aeff61540d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourceallocation
    ADD CONSTRAINT fk41e073aeff61540d FOREIGN KEY (task) REFERENCES task(task_element_id);


--
-- Name: fk44d86d4707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY label
    ADD CONSTRAINT fk44d86d4707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fk5280da49161d6c65; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY virtualworker
    ADD CONSTRAINT fk5280da49161d6c65 FOREIGN KEY (virtualworker_id) REFERENCES worker(worker_id);


--
-- Name: fk5863798ca44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resourcecalendar
    ADD CONSTRAINT fk5863798ca44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk593d3b4b1a5e11f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretchesfunction
    ADD CONSTRAINT fk593d3b4b1a5e11f8 FOREIGN KEY (assignment_function_id) REFERENCES assignment_function(id);


--
-- Name: fk5c13eccf415884f6; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY line_field
    ADD CONSTRAINT fk5c13eccf415884f6 FOREIGN KEY (heading_id) REFERENCES work_report_type(id);


--
-- Name: fk6017744297b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderline
    ADD CONSTRAINT fk6017744297b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk62b2994b4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskmilestone
    ADD CONSTRAINT fk62b2994b4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk70d5d997a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk70d5d997a5f3c581; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskelement
    ADD CONSTRAINT fk70d5d997a5f3c581 FOREIGN KEY (parent) REFERENCES taskgroup(task_element_id);


--
-- Name: fk7540af6b1545e7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6b1545e7a FOREIGN KEY (origin) REFERENCES taskelement(id);


--
-- Name: fk7540af6be838f362; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY dependency
    ADD CONSTRAINT fk7540af6be838f362 FOREIGN KEY (destination) REFERENCES taskelement(id);


--
-- Name: fk75a2f39da44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39da44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fk75a2f39df82680f8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_table
    ADD CONSTRAINT fk75a2f39df82680f8 FOREIGN KEY (orderelementid) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fk7980035061f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk7980035061f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk79800350b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY all_criterions
    ADD CONSTRAINT fk79800350b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fk7d2eeb5d97b1c209; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderlinegroup
    ADD CONSTRAINT fk7d2eeb5d97b1c209 FOREIGN KEY (orderelementid) REFERENCES orderelement(id);


--
-- Name: fk7daad5cd5078e161; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cd5078e161 FOREIGN KEY (work_report_line_id) REFERENCES work_report_line(id);


--
-- Name: fk7daad5cdc1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreportslines_labels
    ADD CONSTRAINT fk7daad5cdc1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fk808010cfb216ed4c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advanceassignment
    ADD CONSTRAINT fk808010cfb216ed4c FOREIGN KEY (advance_type_id) REFERENCES advancetype(id);


--
-- Name: fk80e79bda4936bb8c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY taskgroup
    ADD CONSTRAINT fk80e79bda4936bb8c FOREIGN KEY (task_element_id) REFERENCES taskelement(id);


--
-- Name: fk82ca26e5fec79eb0; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values
    ADD CONSTRAINT fk82ca26e5fec79eb0 FOREIGN KEY (description_value_id) REFERENCES work_report(id);


--
-- Name: fk8746516b53669f2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_category
    ADD CONSTRAINT fk8746516b53669f2 FOREIGN KEY (parent_id) REFERENCES material_category(id);


--
-- Name: fk8ca5223648d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca5223648d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fk8ca52236c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resources_cost_category_assignment
    ADD CONSTRAINT fk8ca52236c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fk8e542e8114a5c61; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e8114a5c61 FOREIGN KEY (id_criterion_type) REFERENCES criteriontype(id);


--
-- Name: fk8e542e813a156175; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY criterion
    ADD CONSTRAINT fk8e542e813a156175 FOREIGN KEY (parent) REFERENCES criterion(id);


--
-- Name: fk9469dc27937680b7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine
    ADD CONSTRAINT fk9469dc27937680b7 FOREIGN KEY (machine_id) REFERENCES resource(id);


--
-- Name: fk95548d7861f02c44; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7861f02c44 FOREIGN KEY (criterion_id) REFERENCES criterion(id);


--
-- Name: fk95548d7875999a91; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machine_configuration_unit_required_criterions
    ADD CONSTRAINT fk95548d7875999a91 FOREIGN KEY (id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fk991fdde5567ad13; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fdde5567ad13 FOREIGN KEY (user_id) REFERENCES naval_user(id);


--
-- Name: fk991fddeedc4db41; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT fk991fddeedc4db41 FOREIGN KEY (profile_id) REFERENCES naval_profile(id);


--
-- Name: fk9ac73f9e40901220; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY worker
    ADD CONSTRAINT fk9ac73f9e40901220 FOREIGN KEY (worker_id) REFERENCES resource(id);


--
-- Name: fka01aabd9a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendaravailability
    ADD CONSTRAINT fka01aabd9a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fka01fe4ee8c80ccb7; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4ee8c80ccb7 FOREIGN KEY (task_source_id) REFERENCES tasksource(id);


--
-- Name: fka01fe4eee036cfed; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_source_hours_groups
    ADD CONSTRAINT fka01fe4eee036cfed FOREIGN KEY (hours_group_id) REFERENCES hoursgroup(id);


--
-- Name: fka2d2a4d6cc119699; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY configuration
    ADD CONSTRAINT fka2d2a4d6cc119699 FOREIGN KEY (configuration_id) REFERENCES basecalendar(id);


--
-- Name: fkadeba4bf87fa6b5d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY task_quality_form_items
    ADD CONSTRAINT fkadeba4bf87fa6b5d FOREIGN KEY (task_quality_form_id) REFERENCES task_quality_form(id);


--
-- Name: fkb05e6e203d72bc6f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e203d72bc6f FOREIGN KEY (id) REFERENCES taskelement(id);


--
-- Name: fkb05e6e2067faf86e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY tasksource
    ADD CONSTRAINT fkb05e6e2067faf86e FOREIGN KEY (orderelement) REFERENCES orderelement(id);


--
-- Name: fkbb2f91fa2f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91fa2f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkbb2f91faa9e53843; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY advancemeasurement
    ADD CONSTRAINT fkbb2f91faa9e53843 FOREIGN KEY (advance_assignment_id) REFERENCES directadvanceassignment(advance_assignment_id);


--
-- Name: fkbb493f501b8e7cf2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f501b8e7cf2 FOREIGN KEY (derived_allocation_id) REFERENCES derivedallocation(id);


--
-- Name: fkbb493f5048d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f5048d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkbb493f506394139; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f506394139 FOREIGN KEY (specific_resource_allocation_id) REFERENCES specific_resource_allocation(resource_allocation_id);


--
-- Name: fkbb493f50b1524a73; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY day_assignment
    ADD CONSTRAINT fkbb493f50b1524a73 FOREIGN KEY (generic_resource_allocation_id) REFERENCES generic_resource_allocation(resource_allocation_id);


--
-- Name: fkc001d52efd5e49bc; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursperday
    ADD CONSTRAINT fkc001d52efd5e49bc FOREIGN KEY (base_calendar_id) REFERENCES calendardata(id);


--
-- Name: fkc5b10467f3909054; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY profile_roles
    ADD CONSTRAINT fkc5b10467f3909054 FOREIGN KEY (profileid) REFERENCES naval_profile(id);


--
-- Name: fkc6c799292c57f12a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT fkc6c799292c57f12a FOREIGN KEY (userid) REFERENCES naval_user(id);


--
-- Name: fkcf1f2cd01ed629ea; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hoursgroup
    ADD CONSTRAINT fkcf1f2cd01ed629ea FOREIGN KEY (parent_order_line) REFERENCES orderline(orderelementid);


--
-- Name: fkd7d7eb1286b2de7a; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb1286b2de7a FOREIGN KEY (configuration_id) REFERENCES machineworkersconfigurationunit(id);


--
-- Name: fkd7d7eb129bebcf10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY machineworkerassignment
    ADD CONSTRAINT fkd7d7eb129bebcf10 FOREIGN KEY (worker_id) REFERENCES worker(worker_id);


--
-- Name: fkd9f8f120131853a1; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120131853a1 FOREIGN KEY (work_report_type_id) REFERENCES work_report_type(id);


--
-- Name: fkd9f8f120707cd777; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120707cd777 FOREIGN KEY (label_type_id) REFERENCES label_type(id);


--
-- Name: fkd9f8f120c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_label_type_assigment
    ADD CONSTRAINT fkd9f8f120c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkdbbb4fee1e635c19; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY orderelement
    ADD CONSTRAINT fkdbbb4fee1e635c19 FOREIGN KEY (parent) REFERENCES orderlinegroup(orderelementid);


--
-- Name: fke203860c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fke203860efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY order_element_label
    ADD CONSTRAINT fke203860efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fke3758148c29ad8eb; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148c29ad8eb FOREIGN KEY (cost_category_id) REFERENCES cost_category(id);


--
-- Name: fke3758148d5b6184d; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY hour_cost
    ADD CONSTRAINT fke3758148d5b6184d FOREIGN KEY (type_of_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fke9754bc58b37665c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY quality_form_items
    ADD CONSTRAINT fke9754bc58b37665c FOREIGN KEY (quality_form_id) REFERENCES quality_form(id);


--
-- Name: fkeb02c3f148d21790; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f148d21790 FOREIGN KEY (resource_id) REFERENCES resource(id);


--
-- Name: fkeb02c3f1e7e1020b; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1e7e1020b FOREIGN KEY (type_work_hours_id) REFERENCES type_of_work_hours(id);


--
-- Name: fkeb02c3f1efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: fkeb02c3f1f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY work_report_line
    ADD CONSTRAINT fkeb02c3f1f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkee374673ae0677b8; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY stretches
    ADD CONSTRAINT fkee374673ae0677b8 FOREIGN KEY (assignment_function_id) REFERENCES stretchesfunction(assignment_function_id);


--
-- Name: fkef86282ee893ce10; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY resource
    ADD CONSTRAINT fkef86282ee893ce10 FOREIGN KEY (calendar) REFERENCES resourcecalendar(base_calendar_id);


--
-- Name: fkf0e8572475ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e8572475ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkf0e85724eae850b2; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY specific_resource_allocation
    ADD CONSTRAINT fkf0e85724eae850b2 FOREIGN KEY (resource) REFERENCES resource(id);


--
-- Name: fkf2a5f7475c390c4; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY description_values_in_line
    ADD CONSTRAINT fkf2a5f7475c390c4 FOREIGN KEY (description_value_id) REFERENCES work_report_line(id);


--
-- Name: fkf4bee4287fa34e3f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee4287fa34e3f FOREIGN KEY (parent) REFERENCES basecalendar(id);


--
-- Name: fkf4bee428a44abee3; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY calendardata
    ADD CONSTRAINT fkf4bee428a44abee3 FOREIGN KEY (base_calendar_id) REFERENCES basecalendar(id);


--
-- Name: fkf788b34975ed79ba; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY generic_resource_allocation
    ADD CONSTRAINT fkf788b34975ed79ba FOREIGN KEY (resource_allocation_id) REFERENCES resourceallocation(id);


--
-- Name: fkfc7b7be62f2d3aec; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be62f2d3aec FOREIGN KEY (advance_assignment_id) REFERENCES advanceassignment(id);


--
-- Name: fkfc7b7be6a1127ce5; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY directadvanceassignment
    ADD CONSTRAINT fkfc7b7be6a1127ce5 FOREIGN KEY (direct_order_element_id) REFERENCES orderelement(id);


--
-- Name: fkfd423ff0c1c2746e; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0c1c2746e FOREIGN KEY (label_id) REFERENCES label(id);


--
-- Name: fkfd423ff0f1a3177c; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY workreports_labels
    ADD CONSTRAINT fkfd423ff0f1a3177c FOREIGN KEY (work_report_id) REFERENCES work_report(id);


--
-- Name: fkfd509405b5c68337; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405b5c68337 FOREIGN KEY (material_id) REFERENCES material(id);


--
-- Name: fkfd509405efda874f; Type: FK CONSTRAINT; Schema: public; Owner: naval
--

ALTER TABLE ONLY material_assigment
    ADD CONSTRAINT fkfd509405efda874f FOREIGN KEY (order_element_id) REFERENCES orderelement(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

